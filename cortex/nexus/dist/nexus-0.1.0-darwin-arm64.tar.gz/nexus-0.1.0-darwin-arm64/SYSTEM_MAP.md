# Cortex/Nexus — System Map

> **Phoenix-aktuell seit 2026-05-12.** Zeigt nur Pfade, die wirklich existieren.
> Pointer-Variante seit Sprint Cleanup 2026-04-29.

---

## 0. Netzwerk-Schicht — Cortex-Mesh

Geräteübergreifende Vernetzung via Tailscale-Mesh. SSH von jedem Mac zu jedem
anderen ohne Portfreigabe.

```
piranha-marlin.ts.net (Tailnet)
├── cluster-mini-02     (Apple M2, Home;                 100.127.125.48,    online)
├── cluster-mini-04     (Apple M2, Home;                 100.80.43.49,      online — seit 2026-05-15)
├── praxis-studio       (Mac Studio Zi2;                 100.119.241.21,    online)
├── macbookpro-silicon  (SSMD-MacBookPro-M5, M5 Pro;     100.93.193.44,     online — seit 2026-05-06)
├── macbookpro-intel    (SSMD-MacBookPro, Intel i7;      100.115.230.94,    node-taken-over via Migration → M5)
├── ipad173             (iPad;                           100.105.151.95,    online)
└── [iphone-ss geplant]
```

**Spec:** `Nexus/specs/cortex-mesh/` · **Tutorial:** `Second Brain/30 Tutorials/Netzwerk & Sysadmin/09-cortex-mesh-tailscale.md` · **Einstieg:** „Cortex-Mesh fortsetzen"

---

## 1. Wo finde ich was?

| Was suchst du? | Pfad |
|---|---|
| **Session-Init / Hauptsteuerung** | `Nexus/CLAUDE.md` |
| **Autonomy-Contract — Index (Pflicht-Lesung)** | `Nexus/_rules/AUTONOMY_CONTRACT.md` |
| **Glossar (Pflicht-Lesung)** | `Nexus/_rules/glossary.md` |
| **Risiko-Level R0–R3 (Detail)** | `Nexus/_rules/risk-levels.md` |
| **Mode × Risiko + Switch-Befehle** | `Nexus/_rules/modes.md` |
| **Stop-Bedingungen (alle Modi)** | `Nexus/_rules/stop-conditions.md` |
| **Tasks: State-Machine + Pflichtfelder + Pre-Flight** | `Nexus/_rules/tasks.md` |
| **Verifikation vor `done`** | `Nexus/_rules/verification.md` |
| **Retention / Anti-Müll** | `Nexus/_rules/retention.md` |
| **AI-Cooperation (Claude × Codex Peer)** | `Nexus/_rules/ai-cooperation.md` |
| **Multi-AI-Boundaries (andere KIs am Nexus)** | `Nexus/_rules/multi-ai-boundaries.md` |
| **Tier-3-Hardstops (Single Source)** | `Nexus/agent/modes/tier3.md` |
| **Lesson-Persistenz-Anker** | `Nexus/_rules/lesson-anchors.md` |
| **User-Direktiven (Stracke-spezifisch)** | `Nexus/_rules/user-directives.md` |
| **Security-Regeln (Tokens, Secrets, Logging)** | `Nexus/_rules/security.md` |
| **Medical-Domain (DSGVO, Patient-Tags, SmartQ)** | `Nexus/_rules/medical-domain.md` |
| **Sync-Policy (Runtime-Aggregat)** | `Nexus/_rules/sync-policy.md` |
| **Mode-Briefings (autonomy / safe)** | `Nexus/agent/modes/autonomy.md` · `safe.md` |
| **Goldene Regeln (Aggregat-Snapshot)** | `Nexus/_memory/golden-rules.md` |
| **Claude-Codex-Kooperationskonzept** | `Nexus/specs/claude-codex-cooperation/00_KONZEPT.md` |
| **Architecture-Refactor 2026-05** | `Nexus/specs/architecture-refactor-2026-05/00_AUDIT.md` |
| **Cortex-Public-Skeleton (Sanexio-Geschäftsmodell)** | `Nexus/specs/cortex-public-skeleton/00_KONZEPT.md` |
| **Multi-Device-Multi-AI-Architektur** | `Nexus/specs/multi-device-multi-ai/00_KONZEPT.md` |
| **Nutzer-Profil** | `Nexus/_memory/USER.md` |
| **Pointer-Index zum Vault** | `Nexus/_memory/KNOWLEDGE.md` |
| **Memory-DB (SQLite, FTS5, gitignored)** | `Nexus/_memory/memory.db` |
| **Spawn-Queue-DB (gitignored)** | `Nexus/_memory/spawn-queue.db` |
| **Session-Logs (gitignored)** | `Nexus/_memory/logs/` |
| **Projekt-Tabelle** | `Nexus/_projects/INDEX.md` |
| **Tutorials (Single Source)** | `Second Brain/30 Tutorials/` |
| **Shared Library (PDF, OCR, medical, rename, steuer)** | `Nexus/_lib/` |
| **Cortex-Agent (Hermes-style, Python)** | `Nexus/agent/` |
| **Agent-Skills (Python, `@skill`-Funktionen)** | `Nexus/agent/skills/builtin/` · Index: `Nexus/agent/skills/INDEX.md` |
| **Claude-Code-Skill-Pakete (`.skill`-ZIPs)** | `Nexus/skills/` |
| **Cron-Recipes + Runner** | `Nexus/agent/cron/` |
| **Mode-Hook (UserPromptSubmit)** | `Nexus/tools/cortex-mode/bin/inject.sh` |
| **Connexio (read-only Kontextfläche)** | `Nexus/agent/connexio/` |
| **Connexio-Outbound** | `Nexus/agent/connexio_outbound/` |
| **Gateway (OpenClaw-style, TS/Bun)** | `Nexus/gateway/` |
| **Tools (cortex-mode, session-start-digest, telegram-inbox-hook)** | `Nexus/tools/` |
| **Geräte-Registry** | `Nexus/.config/devices.json` |
| **Auto-Sync-Skript** | `Nexus/nexus-sync.sh` |

---

## 2. Geltende Regeln in einem Satz

- **R-Level (Autonomy Contract)** R0 read-only frei · R1 Projektarbeit frei · R2 Nexus nur Vorschlag + Stracke-Freigabe · R3 immer Stop
- **Mode** autonomy = durchziehen, Welle-Ende-Debrief · safe = 4-Phasen mit Phase-2-Approval-Gate · R3 bleibt immer Stop
- **Hierarchie bei Kollision** Stracke > freigegebene Nexus-Policy > Projekt-Policy > Task-Manifest > Agent-Default
- **GitHub ist Truth** vor Edit `git pull --ff-only` in Nexus + Projekt; nach Welle commit + push
- **Live-Push** Production-Domain (`.com`) niemals autonom, auch nicht im Autonomy-Mode

Volldetail: `_rules/AUTONOMY_CONTRACT.md` (Index) verweist auf alle
spezialisierten Regel-Files in `_rules/` (siehe Tabelle oben).

---

## 3. Aktive Cron-Jobs

| Job | Frequenz | LaunchAgent |
|---|---|---|
| `nexus-sync.sh` | alle 5 Min | `com.cortex.nexus-sync` |

Weitere Cron-Recipes (memory-nudge, sanitizer-probe, backup-audit,
tutorial-drift) sind in `Nexus/agent/cron/recipes/` als TOML hinterlegt;
Aktivierung pro Geraet ueber `~/Library/LaunchAgents/`.

Pattern und Setup: `Nexus/agent/cron/`.

---

## 4. Multi-Device + Multi-AI

Cortex existiert auf mehreren Macs gleichzeitig. **Sync ausschliesslich
ueber GitHub** (`Sanexio/nexus`, `Sanexio/cortex-web`, …).

**Boundary (v2 seit 2026-05-12):** `~/Cortex/Nexus/` ist R2.
Direkter Filesystem-Schreibzugriff durch Codex/Cursor/Cline ist verboten.
Erlaubt sind Vorschläge über `projects/_ai-cooperation-outbox/`,
projektlokale Reviews/Tasks und später freigegebene Branch-/PR-Vorschläge.
Detail: `_rules/multi-ai-boundaries.md` (seit 2026-05-16 eigene Datei).

---

## 5. Neues Projekt integrieren

Schritte: `Nexus/CLAUDE.md` → Abschnitt „Neues Projekt integrieren".

---

## 6. Phoenix-Reset Status

Vollstaendiger Hard-Reset 2026-05-08/09 — alte Steuerungs-Files (`_rules/`-
Stack, altes `_memory/`, `tools/cortex-*`) entfernt. Backup im
`pre-phoenix-reset-2026-05-08`-Branch (origin) und in `_archive/phoenix-pre-reset/`
(lokal, gitignored).

Welle 1 AI-Cooperation (2026-05-12) hat `ai-cooperation.md`,
`AUTONOMY_CONTRACT.md` und `multi-ai-boundaries.md` v2 freigegeben.

Welle 2 Drift-Cleanup (2026-05-12) hat diese SYSTEM_MAP.md, `Cortex/AGENTS.md`
und die Cortex-Web-Pflicht-Lesungen aktualisiert.

---

*Letzte Strukturänderung: 2026-05-16 — Architecture-Refactor Priorität 3
(User-Layer auslagern: security.md/medical-domain.md, sync-policy.md,
Skills-Disambiguierung, Public-Skeleton-Spec-Stub).*
