# Skills — Skill-Pakete für Claude Code

> **Disambiguierung (wichtig!):** Im Cortex gibt es **zwei** unabhängige
> Skill-Systeme. Diese Datei beschreibt nur das `.skill`-Paket-System für
> Claude Code. Das **andere** System sind Python-`@skill`-Funktionen unter
> `agent/skills/builtin/`, aufrufbar via `cortex-agent skill run <name>`
> (siehe `agent/skills/INDEX.md`).
>
> | System | Pfad | Aufruf | Zweck |
> |---|---|---|---|
> | Python-`@skill` | `agent/skills/builtin/*.py` | `cortex-agent skill run …` | Operative Cortex-Skills (doctor, sanitizer, capture-lesson, …) |
> | Claude-Code-`.skill` | `Nexus/skills/*.skill` (dieses Verzeichnis) | von Claude Code automatisch geladen | User-eigene Domänen-Skills (Design, Workflow, SmartQ, …) |

## Übersicht

Dieses Verzeichnis enthält die `.skill`-Paketdateien, die als Quelldateien
für die installierten Skills in `~/.claude/skills/` dienen.

## Zusammenhang: .skill-Dateien ↔ .claude/skills/

| Datei hier                  | Installierter Skill in `.claude/skills/` |
|-----------------------------|------------------------------------------|
| `doc-workflow.skill`        | `doc-workflow/`                          |
| `file-renamer.skill`        | *(wird über _lib/rename/ referenziert)*  |
| `gdrive-sync.skill`         | `gdrive-sync/`                           |
| `smartq-dashboard.skill`    | `smartq-dashboard/`                      |
| `frontend-design/`          | `frontend-design/`  *(NEU — Design-Skill)*|
| `ui-ux-pro-max/`            | `ui-ux-pro-max/`  *(NEU — Design-System)* |
| `21st-dev-magic/`           | `21st-dev-magic/`  *(NEU — Komponenten)*  |

## Workflow

1. **Skill erstellen/ändern**: Mit dem `skill-creator` Skill
2. **Skill installieren**: `.skill`-Datei wird in `.claude/skills/` entpackt
3. **Sync**: Über `gdrive-sync` werden Skills zwischen Geräten synchronisiert

## Hinweis

Die `.skill`-Dateien hier sind die **transportable Paketform**.
Die aktiven Skills (mit SKILL.md, Konfiguration etc.) leben in `.claude/skills/`.
