#!/usr/bin/env bash
# photo-crop-verify.sh — Card-Crop-Vision-Check für Profilfotos.
#
# Erzeugt Desktop- und Mobile-Screenshots einer Team-/Profil-Card und
# legt sie in einem Audit-Ordner ab, sodass Claude sie via Read-Tool
# inspizieren kann.
#
# Usage:
#   ./photo-crop-verify.sh --slug=<data-slug> \
#                          --base=<URL> \
#                          [--auth=<user:pass>] \
#                          [--path=/team/] \
#                          [--outdir=<dir>]
#
# Beispiel:
#   ./photo-crop-verify.sh \
#       --slug=emily-boehne \
#       --base=https://westend-hausarzt.de \
#       --auth=praxis:Sanexio
#
# Vorbedingungen:
#   - node + playwright lokal installiert (npx kann das nachziehen)
#   - die Card hat das Attribut data-slug="<slug>" auf einem Element,
#     das mit .pxz-team-card oder vergleichbarem CSS-Selector existiert
#
# Exit-Codes: 0 = ok, 1 = fail, 2 = config

set -euo pipefail

SLUG=""
BASE=""
AUTH=""
PATH_REL="/team/"
OUTDIR=""

for arg in "$@"; do
  case "$arg" in
    --slug=*)   SLUG="${arg#*=}" ;;
    --base=*)   BASE="${arg#*=}" ;;
    --auth=*)   AUTH="${arg#*=}" ;;
    --path=*)   PATH_REL="${arg#*=}" ;;
    --outdir=*) OUTDIR="${arg#*=}" ;;
    *) echo "unknown arg: $arg" >&2; exit 2 ;;
  esac
done

if [ -z "$SLUG" ] || [ -z "$BASE" ]; then
  echo "Usage: $0 --slug=<data-slug> --base=<URL> [--auth=user:pass] [--path=/team/]" >&2
  exit 2
fi

if [ -z "$OUTDIR" ]; then
  OUTDIR="$(pwd)/_audit/photo-crop"
fi
mkdir -p "$OUTDIR"

USER=""
PASS=""
if [ -n "$AUTH" ]; then
  USER="${AUTH%%:*}"
  PASS="${AUTH#*:}"
fi

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

# JSON-escape values via python (portable across bash versions)
jsesc() { python3 -c 'import json,sys; print(json.dumps(sys.argv[1]))' "$1"; }

J_SLUG=$(jsesc "$SLUG")
J_BASE=$(jsesc "$BASE")
J_PATH=$(jsesc "$PATH_REL")
J_USER=$(jsesc "$USER")
J_PASS=$(jsesc "$PASS")
J_OUTDIR=$(jsesc "$OUTDIR")

cat > "$WORK/check.mjs" <<JS
import { chromium } from 'playwright';

const SLUG    = $J_SLUG;
const BASE    = $J_BASE;
const PATH_   = $J_PATH;
const USER    = $J_USER;
const PASS    = $J_PASS;
const OUTDIR  = $J_OUTDIR;

const browser = await chromium.launch();
const viewports = [
  { name: 'desktop', width: 1440, height: 900 },
  { name: 'mobile',  width: 390,  height: 844 },
];

let failures = 0;
for (const vp of viewports) {
  const ctxOpts = {
    viewport: { width: vp.width, height: vp.height },
    ignoreHTTPSErrors: true,
  };
  if (USER) ctxOpts.httpCredentials = { username: USER, password: PASS };
  const ctx = await browser.newContext(ctxOpts);
  const page = await ctx.newPage();

  // Capture image loads to flag 404s on the actual photo
  const imgStatus = new Map();
  page.on('response', r => {
    const u = r.url();
    if (u.includes('/uploads/') && (u.match(/\\.(jpe?g|webp|png)/i))) {
      imgStatus.set(u, r.status());
    }
  });

  const cacheBust = '?v=' + Date.now();
  const url = BASE + PATH_ + cacheBust;
  await page.goto(url, { waitUntil: 'networkidle' });

  // Cookie-Banner / Consent-Overlays vorab dismissen, damit sie nicht
  // die Card überlagern (Mobile besonders kritisch).
  const dismissSelectors = [
    '.pxz-cc-btn-accept-all',
    '[data-pxz-cookie-accept-all]',
    '[data-pxz-cookie-accept]',
    '.pxz-cookie-accept-all',
    '#cookie-accept',
    'button:has-text("Alle akzeptieren")',
    'button:has-text("Akzeptieren")',
    'button:has-text("Accept all")',
    'button:has-text("Tout accepter")',
    'button:has-text("Aceptar todo")',
    'button:has-text("Accetta tutto")',
    'button:has-text("Aceitar tudo")',
  ];
  for (const sel of dismissSelectors) {
    try {
      const el = page.locator(sel).first();
      if (await el.count() && await el.isVisible()) {
        await el.click({ timeout: 1500 });
        await page.waitForTimeout(300);
        break;
      }
    } catch (e) { /* selector not present, ignore */ }
  }

  const card = page.locator('[data-slug="' + SLUG + '"]').first();
  const count = await card.count();
  if (!count) {
    console.error('NOT_FOUND: data-slug="' + SLUG + '" auf ' + url);
    failures++;
    await ctx.close();
    continue;
  }
  await card.scrollIntoViewIfNeeded();
  await page.waitForTimeout(800);

  const file = OUTDIR + '/' + SLUG + '-' + vp.name + '.png';
  await card.screenshot({ path: file });
  console.log('SAVED ' + file + ' (' + vp.width + 'x' + vp.height + ')');

  // Image-Load Check für Slug
  const slugImgs = [...imgStatus.entries()].filter(([u]) => u.includes(SLUG));
  if (!slugImgs.length) {
    console.warn('WARN no image-response found containing slug "' + SLUG + '" — Card zeigt evtl. Initialen-Fallback');
  } else {
    for (const [u, s] of slugImgs) {
      console.log('  img: ' + s + ' ' + u);
      if (s >= 400) failures++;
    }
  }

  await ctx.close();
}

await browser.close();
process.exit(failures ? 1 : 0);
JS

# Ensure playwright is available. Cache a venv-style install under
# ~/.cache/photo-crop-verify so we don't re-npm every run.
CACHE_DIR="$HOME/.cache/photo-crop-verify"
if ! (cd "$CACHE_DIR" 2>/dev/null && node -e "import('playwright')" 2>/dev/null); then
  mkdir -p "$CACHE_DIR"
  ( cd "$CACHE_DIR" && \
    [ -f package.json ] || npm init -y >/dev/null 2>&1 ; \
    npm i --silent playwright@1 >/dev/null 2>&1 ; \
    npx --no-install playwright install chromium >/dev/null 2>&1 || true )
fi

cp "$WORK/check.mjs" "$CACHE_DIR/check.mjs"
( cd "$CACHE_DIR" && node check.mjs )

echo ""
echo "Next step: Lass Claude die Screenshots inspizieren:"
echo "  Read $OUTDIR/$SLUG-desktop.png"
echo "  Read $OUTDIR/$SLUG-mobile.png"
echo ""
echo "Bewertungs-Checkliste:"
echo "  ✅ Augen im oberen Drittel (25-40% von oben in der Card)"
echo "  ✅ Mund klar sichtbar, nicht am unteren Rand gekappt"
echo "  ✅ Kinn vollständig sichtbar, Headroom unten"
echo "  ✅ Stirn nicht über-headroomed (max 10% Card-Höhe oben)"
