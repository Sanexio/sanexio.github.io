---
name: photo-crop-verify
slug: photo-crop-verify
version: 1.0.0
created: 2026-05-16
last_evolved: null
runs: 0
success_rate: null
description: Vor jedem Profilfoto-Upload visuelle Card-Crop-Inspektion via headless Screenshot, bevor "fertig" gemeldet wird — verhindert abgeschnittene Gesichter (Mund/Kinn weg) wegen falschem object-position.
trigger_pattern: |
  Dieser Skill wird VERBINDLICH ausgelöst, wenn:
  - Ein neues Profilfoto/Avatar/Team-Foto in wp-content/uploads/ landet
  - Das Foto in einer Team-/Profil-Card oder einem Hero gerendert wird
  - CSS-`object-position` an einer Bild-Card geändert wird
  - Dr. Stracke fragt "passt das Bild?" / "ist der Crop ok?"
  - Vor jedem Commit, der ein Foto + Card-Layout berührt
  Niemals nur auf "Foto existiert und HTTP 200" abstellen — das sagt nichts
  über den sichtbaren Ausschnitt.
required_tools: [Bash, Read, Edit, Write]
applies_in: both
---

# photo-crop-verify

## Zweck

Verhindert, dass Profilfotos mit abgeschnittenem Gesicht (Mund/Kinn weg
oder Stirn weg) live gehen. Pflicht-Schritt bei jedem neuen Avatar oder
geänderten `object-position`.

Bisheriger Ablauf war: Foto hochladen → HTTP 200 prüfen → fertig melden.
Das übersieht den Cover-Crop-Bug komplett, weil das Bild aus Server-Sicht
korrekt ausgeliefert wird — nur eben nicht in dem Ausschnitt, den die
Card-CSS daraus macht.

## Wann anwenden

- **Pflicht** bei jedem neuen Foto unter `wp-content/uploads/.../{slug}.jpg`,
  das in einer Team-/Profil-/Hero-Card gerendert wird.
- **Pflicht** bei jeder Änderung an `assets/css/team.css` oder vergleichbaren
  Card-Stylesheets, die `object-position`, `aspect-ratio` oder `object-fit`
  betrifft.
- **Auch** bei reiner CSS-Pro-Slug-Override-Ergänzung, weil die
  Wirkung auf andere Slugs unklar bleibt, bis sie visuell geprüft ist.

## Schritte

1. **Bild + Card-Slug identifizieren.**
   - Foto-Pfad: `wp-content/uploads/<jahr>/<monat>/<slug>.jpg` (+ ggf. `.webp`).
   - Card-Slug: aus `template-team.php` oder `team.json` ableiten
     (data-slug-Attribut), nicht raten.

2. **Originalfoto-Dimensionen prüfen.**
   ```
   sips -g pixelWidth -g pixelHeight <path>
   ```
   Notieren: Breite × Höhe und ungefähre Position von Augen / Mund / Kinn
   in % der Bildhöhe (durch Lesen des Bildes mit dem Read-Tool).

3. **Card-Render-Seite headless screenshotten.**
   - Default: `/team/` (oder Profil-Detail-URL bei Single-Profile-Pages).
   - Viewport: mindestens 1440×900 Desktop UND 390×844 Mobile (zwei Shots).
   - Tool: `tools/photo-crop-verify.sh` (siehe unten).
   - Output: `_audit/photo-crop/<slug>-desktop.png` + `<slug>-mobile.png`.

4. **Screenshots mit Read-Tool öffnen und visuell prüfen.**
   Es gibt zwei Bildkategorien, die getrennte Regeln haben:

   **A) PORTRAIT (Kopf + Schultern, Hauptfall bei Team-Cards):**
   - **MUSS:** komplettes Gesicht sichtbar — von Haaransatz/Haarspitze
     bis Kinn-Spitze. Alle Gesichtsteile (Stirn, Augenbrauen, Augen,
     Nase, Mund, Kinn) ohne Anschnitt.
   - **MUSS NICHT:** Hals oder Schultern müssen NICHT komplett drin
     sein — Anschnitt unter dem Kinn ist ok.
   - **VERBOTEN:** Wand-/Hintergrund-Streifen sichtbar (= Card-Akzent-
     Farbe oder Originalfoto-Hintergrund-Wand zwischen Bild-Inhalt und
     Card-Rand). Das Foto muss bis an die Card-Ränder reichen.
   - **WUNSCH:** Augen ungefähr im oberen Drittel (25-40%), wirkt
     natürlich; aber „Gesicht komplett + kein Hintergrund" hat Vorrang.

   **B) GANZKÖRPER / GRUPPENBILD (Person/Personen vollständig):**
   - **MUSS:** komplette Person(en) im Bild — von Haaransatz bis Füße
     (oder bis zur abgeschnittenen Stelle des Originalfotos).
   - **VERBOTEN:** Kopf, Hände oder Füße angeschnitten.
   - **VERBOTEN:** Hintergrund-Streifen zwischen Person und Card-Rand
     (Card-Akzent-Farbe sichtbar).

   **Hintergrund-Detection-Heuristik:** schaue auf die obersten und
   untersten 5 % der Card-Pixel-Reihen. Wenn dort eine flächige Farbe
   sichtbar ist, die NICHT zum Foto gehört (heller Beige der Original-
   Studio-Wand, weiße Card-Fläche, gelbe/amber Akzentfläche der Card),
   ist das ein Hintergrund-Streifen → Bewertung ❌.

   **Symmetrie:** Gesicht horizontal mittig, keine seitliche Verschiebung.

5. **Beurteilung niederschreiben** (in Auftragsantwort):
   - ✅ Crop ok → Commit/Push-OK.
   - ⚠ Crop suboptimal → Fix-Vorschlag (CSS oder Foto-Recrop).
   - ❌ Gesicht/Person teils weg ODER Hintergrund-Streifen → Fix
     Pflicht, Push blockieren.

6. **Bei Fix — zwei Wege, in dieser Reihenfolge versuchen:**

   **Weg 1: CSS-`object-position`-Override** (geringer Eingriff).
   - Funktioniert, wenn die ganze Gesicht-Vertikale (Haaransatz bis
     Kinn) in den Card-Sichtbereich passt.
   - Beispiel: hochformatiges 824×1117-Bild in 4:3-Container hat 618 px
     sichtbare Vertikal-Range. Gesicht (Haaransatz bis Kinn) muss ≤ 618 px
     hoch sein. Wenn ja: object-position zentriert (`50% 50%`) oder
     entsprechend verschoben.
   - Faustregel: bei Hochformat-Quelle Y häufig im Bereich 45-55%.

   **Weg 2: Foto vor-croppen** (wenn Gesicht-Vertikal zu groß für Card).
   - Strukturelle Lösung: Originalfoto so zuschneiden, dass das
     Verhältnis besser zur Card-Ratio passt (z. B. von 1:1.36 auf 1:1.15).
     Bei Passfotos: oben Wand-Headroom + unten Schulteranschnitt
     wegschneiden.
   - Tools: `sips -c <newH> <newW> <file>` oder ImageMagick `magick
     convert -gravity center -crop <W>x<H>+0+0`.
   - Danach Bild + Webp-Variante neu hochladen + Cache-Bust.

7. **Re-Verify nach Fix:** Schritt 3-5 wiederholen, bis ✅. Niemals
   nur den Fix committen ohne Re-Verify — beim Emily-Vorfall 2026-05-16
   war Iteration 1 (38%) zwar besser, aber im 4:3 immer noch Kinn-knapp.

## Erfolgskriterium

Beide Screenshots (Desktop + Mobile) zeigen:
- Augen im oberen Drittel der Card.
- Mund und Kinn vollständig sichtbar.
- Kein seitlicher Beschnitt des Gesichts.

Erst dann darf "fertig" gemeldet werden.

## Bekannte Fallstricke

- **HTTP-200 ≠ Crop-OK.** Vorfall 2026-05-16 Emily Böhne: Foto war live
  abrufbar, aber Mund + Kinn waren wegen default `object-position: 50% 0%`
  abgeschnitten. Hat zu User-Reklamation geführt. Lesson: Vision-Check
  ist obligatorisch.
- **Mobile-Override nicht vergessen.** `team.css` hat ab `max-width: 540px`
  ein eigenes `object-position`-Setting. Pro-Slug-Override muss ggf. auch
  für Mobile gesetzt werden oder hinter dem Media-Query stehen.
- **Bild-Format-Vielfalt.** Manche Ärzte-Fotos sind 1:1, andere 1:1.36
  (Passfoto-Hochformat). Die globale Default-CSS passt nur für die enge
  1:1-Variante. Bei Hochformat fast immer Override nötig.
- **Picture-Tag-Cache.** Browser cachen `<picture>` aggressiv. Bei Re-Verify
  den Cache-Buster `?ver=<PXZ_VERSION>` mitgeben (das Theme tut das
  automatisch, aber im Playwright-Run `?v=<timestamp>` an die URL hängen).
- **Initialen-Fallback maskiert das Problem.** Wenn das Foto fehlt
  (404), zeigt die Card nur die Initialen (z. B. "EB") — sieht "ok" aus,
  ist aber nicht das Foto. Vor Crop-Check immer prüfen, dass das `<img>`
  auch wirklich lädt (`fetch`-Status im Playwright-Run mitloggen).

## Beispiel-Aufruf

```
Trigger: Dr. Stracke: "Foto von Lisa Müller liegt jetzt auf .de"
Aktion:  bash tools/photo-crop-verify.sh \
            --slug=lisa-mueller \
            --site=de \
            --base="https://westend-hausarzt.de" \
            --auth="praxis:Sanexio"
         → Screenshots Desktop + Mobile in _audit/photo-crop/
         → Claude liest beide PNGs via Read-Tool
         → Beurteilung an Dr. Stracke vor "fertig"-Meldung
```

## Versionierungs-Hinweise

- v1.0.0 (2026-05-16): Initialversion, motiviert durch Emily-Böhne-Vorfall
  am 2026-05-16. CSS-Fix war einfach (Pro-Slug `object-position: 50% 38%`),
  aber das Versäumnis lag im fehlenden Vision-Check vor "fertig".
- v1.1.0 (2026-05-16): User-Direktive nachgeschärft — Bewertungsregel
  präzisiert (komplettes Gesicht/Person + kein Hintergrund-Streifen,
  Hintergrund-Detection-Heuristik), Fix-Wege A/B (CSS-Override ODER
  Foto-Recrop) explizit, Re-Verify-Pflicht nach jeder Iteration. Emily-
  Iteration 2 (Y=50% statt 38%) ist Erst-Anwendung der verschärften Regel.
