---
name: <Skill-Name>
slug: <slug-hier>
version: 1.0.0
created: 2026-05-05
last_evolved: null
runs: 0
success_rate: null
description: <Ein-Satz-Zweck dieses Skills>
trigger_pattern: |
  <Beschreibung wann dieser Skill eingesetzt werden soll.
   Mehrzeilig erlaubt. Dr. Stracke und Claude lesen das, um zu
   entscheiden, ob der Skill passt.>
required_tools: [Read, Edit, Bash, Grep]
applies_in: both
---

# <Skill-Name>

## Zweck

<Was leistet dieser Skill? In 2-3 Sätzen.>

## Wann anwenden

<Konkrete Trigger-Bedingungen, mehr Detail als trigger_pattern.>

## Schritte

1. <Schritt 1, kurz und ausführbar>
2. <Schritt 2>
3. <Schritt 3>
   - <Sub-Schritt>
4. <...>

## Erfolgskriterium

<Wie weiß man, dass der Skill erfolgreich war? Konkret messbar.>

## Bekannte Fallstricke

- <Fallstrick 1 — was ging schon mal schief, wie vermeiden>
- <Fallstrick 2>

## Beispiel-Aufruf

```
Trigger: Dr. Stracke sagt "..."
Erwartete Aktion: ...
Erwartetes Ergebnis: ...
```

## Versionierungs-Hinweise

- v1.0.0 (2026-05-05): Initialversion.
