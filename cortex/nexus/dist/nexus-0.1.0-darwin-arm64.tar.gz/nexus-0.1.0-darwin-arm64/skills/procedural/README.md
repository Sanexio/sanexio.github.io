---
name: Cortex Procedural Skills
version: 1.0.0
status: produktiv (Sprint F3, 2026-05-05)
zweck: Hermes-kompatibles Procedural-Memory-Format für wiederverwendbare Lösungsmuster
related: tools/cortex-curator, tools/cortex-skills-evolver, tools/cortex-skills
---

# Cortex Procedural Skills

> **Abgrenzung:** Dieses Verzeichnis ist NICHT für Claude-Code-Plugin-Pakete
> (`*.skill` in `Nexus/skills/`). Hier liegen **Procedural Skills** —
> wiederverwendbare Lösungsmuster, die der `cortex-curator` aus erfolgreichen
> Welle-Workflows extrahiert (Hermes-Pattern: Procedural Memory).

## Verzeichnis-Layout

```
Nexus/skills/procedural/
├── README.md                   ← diese Datei
├── _template/SKILL.md          ← Vorlage
├── <skill-slug>/
│   ├── SKILL.md                ← Skill-Definition (Frontmatter + Markdown-Body)
│   ├── examples/               ← (optional) Beispiel-Anwendungen
│   └── _runs/                  ← (optional) lokale Run-Logs
└── ...
```

## Skill-Format

Siehe `_template/SKILL.md`. Pflicht-Frontmatter:

| Feld | Bedeutung |
|---|---|
| `name` | Lesbarer Name |
| `slug` | URL-tauglicher Identifier (kebab-case) |
| `version` | SemVer (1.0.0) |
| `created` | ISO-Datum |
| `last_evolved` | null oder ISO-Datum (vom Evolver gesetzt) |
| `runs` | Anzahl bisheriger Aufrufe |
| `success_rate` | null oder Float 0-1 |
| `description` | 1-Satz-Zweck |
| `trigger_pattern` | Wann der Skill aufgerufen werden soll |
| `required_tools` | Liste der benötigten Claude-Code-Tools |
| `applies_in` | safe-mode, autonomy-mode, both |

## Wie Skills entstehen

1. **Manuell:** Du legst `procedural/<slug>/SKILL.md` an, kopierst aus
   `_template/SKILL.md`, füllst aus.
2. **Automatisch:** `cortex-curator` Detector `skill-from-task` erkennt
   wiederkehrende komplexe Workflows in Welle-Logs, schlägt Skill in
   `_memory/curator-queue.md` vor. Approval → Skill-Datei wird angelegt.

## Wie Skills sich verbessern

`cortex-skills-evolver` läuft periodisch (oder nach jedem Skill-Run):
1. Liest Run-Logs in `tools/cortex-skills/_runs/<skill>/`.
2. Vergleicht erfolgreiche vs. fehlgeschlagene Runs.
3. Schlägt Skill-Diff vor → `_memory/skill-evolution-queue.md`.
4. Approval → Skill-Datei wird gepatched, `last_evolved` aktualisiert.

## Wie Skills ausgeführt werden

In Claude Code: Claude liest aus `Nexus/skills/procedural/<slug>/SKILL.md`
und folgt den Schritten. Bei jedem Aufruf wird ein Run-Log in
`tools/cortex-skills/_runs/<slug>/` geschrieben (über
`tools/cortex-skills/bin/log-run.sh`).

## Beziehung zu `Nexus/skills/*.skill`

| Aspekt | `*.skill`-Pakete | Procedural Skills (hier) |
|---|---|---|
| Zweck | Tool-/Plugin-Integration für Claude Code | Lösungsmuster für wiederkehrende Aufgaben |
| Format | ZIP-artige Pakete + `.claude/skills/` Install | Markdown mit Frontmatter |
| Erstellt von | manuell + `skill-creator` | manuell + `cortex-curator` |
| Sync | über `gdrive-sync` | über Nexus-Git |

Beide ergänzen sich, ersetzen sich nicht.
