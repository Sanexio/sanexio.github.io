# 25 — Theme-Render-Quelle prüfen, bevor du in die WP-DB schreibst

> Aus Session 42 (2026-04-25). Anti-Pattern-Lerneffekt: Wer Daten in die WordPress-Datenbank schreibt (z.B. Menü-Items, Widgets, Customizer-Settings), muss zuerst verifizieren, dass das Theme diese Daten überhaupt liest. Custom-Themes — gerade Cortex-Web-Adapter-Themes — umgehen das WP-Standard-System oft komplett.

## Was passiert ist (Praxis-Theme S42)

Aufgabe: „Header-Menü neu strukturieren — 7 Top-Level mit Submenüs".

Mein erster Versuch:
1. WP-CLI `menu item add-post` 53× → Items im `main-menu` (term_id=5) angelegt
2. SQL-Updates für Parent-Hierarchie und Reihenfolge
3. HTTP-Sweep grün — alle Slugs liefern 200
4. Live-Probe: Dr. Stracke sieht **nichts** vom neuen Menü

**Ursache:** Das Praxis-Theme rendert das Header-Nav nicht über `wp_nav_menu()`, sondern über `template-parts/header-nav.php`, das die Items aus **`inc/nav-data.php`** (PHP-Array) liest. Das WP-Menü-System ist tote Infrastruktur — DB-Items werden nirgendwo gerendert.

Symmetrisch sind im Praxis-Theme:
- Footer (Legal, Spalten, Tagline) → `inc/footer-data.php`
- Standortdaten (Adresse, Telefon, Öffnungszeiten) → `inc/practice-data.php`
- Team/Ärzte → `inc/team-data.php`
- Homepage-Texte → `inc/homepage-data.php`

## Der Quick-Check

Vor jeder DB-Schreibaktion auf einem Custom-Theme:

```bash
# 1) Findet das Theme das WP-Menü-System überhaupt?
grep -rn "wp_nav_menu\|register_nav_menus" wp-content/themes/<name>/

# 2) Wenn ja: Welche Theme-Locations sind registriert?
grep -rn "register_nav_menus" wp-content/themes/<name>/functions.php

# 3) Wenn nein: Wo kommen die Nav-Daten her?
grep -rn "primary\b\|nav_data\|nav_items\|menu_data" wp-content/themes/<name>/inc/
```

**Heuristik:** Wenn das Theme `inc/<bereich>-data.php`-Dateien hat (nav-data, footer-data, practice-data, team-data, homepage-data), ist sehr wahrscheinlich der **Code** die Single-Source — nicht die DB.

## Warum das so ist (Cortex-Web-Architektur)

Das Praxis-Theme ist Teil von Cortex-Web (Common-Trunk-Architektur, CW-001 „Trunk is Master"). Daten wandern Trunk → Adapter → Site, nicht Site → DB. PHP-Array ist:

- **deterministisch** — gleicher Code ⇒ gleiches Output
- **git-versioniert** — jede Änderung im Commit-Log
- **cross-site-portierbar** — der gleiche Trunk speist Praxis-WP und Juvantis-Shopify

DB-Inhalte würden den Trunk-Sync brechen, weil die DB nicht im Git ist.

## Wann doch in die DB schreiben?

Klar DB-basiert sind:

| Datenart | Speicher | Pflege-Weg |
|---|---|---|
| **Page-Inhalte** | `wp_posts` `post_type='page'` | WP-Admin Editor oder REST-API |
| **Permalinks** (post_name) | `wp_posts` | WP-Admin oder direkter SQL-Update |
| **WPML-Translations** | `wp_icl_translations` | WPML-Plugin oder direkter SQL |
| **Redirects** (Praxis-Theme) | `inc/redirects.php` (Code) | Code-Edit |
| **Header-Nav** (Praxis-Theme) | `inc/nav-data.php` (Code) | Code-Edit |
| **Footer** (Praxis-Theme) | `inc/footer-data.php` (Code) | Code-Edit |
| **Standorte** (Praxis-Theme) | `inc/practice-data.php` (Code) | Code-Edit |
| **Team/Ärzte** (Praxis-Theme) | `inc/team-data.php` (Code) | Code-Edit |
| **Homepage-Texte** (Praxis-Theme) | `inc/homepage-data.php` (Code) | Code-Edit |

## Übung

Du sollst die Telefonnummer im Footer ändern. Wo gehst du hin?

❌ **Falsch:** WP-Admin → Customizer → Footer → Telefonnummer
✅ **Richtig:** `wp-content/themes/praxiszentrum/inc/practice-data.php` editieren, `PXZ_VERSION` bumpen, committen.

Was wäre falsch an „WP-Admin"-Variante? Es gäbe vielleicht eine Eingabe-UI, aber das Theme liest den Wert nicht aus der DB — er bleibt unsichtbar.

## Pattern-Datei

`Nexus/_memory/patterns/theme-rendering-source-check.md` (Vor-Aktions-Check als Code-Snippet zum Copy-Paste).

## Memory

`feedback_praxis_nav_via_code.md` (Status-quo-Entscheidung Dr. Stracke 2026-04-25): Praxis-Theme bleibt PHP-Code-First, NICHT auf WP-Admin-Menü-System umstellen.

## Cross-Reference

- Tutorial 18 — Single Source of Truth für Stammdaten
- Tutorial 20 — Navigation-Restrukturierung und Mobile-Drawer
- Tutorial 24 — Doppelte Render-Quellen aufspüren (verwandtes Anti-Pattern: zwei Render-Stellen für eine Komponente)
