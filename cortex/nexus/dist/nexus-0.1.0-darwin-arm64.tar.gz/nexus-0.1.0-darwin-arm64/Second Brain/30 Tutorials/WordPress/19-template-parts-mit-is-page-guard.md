# 23 · Template-Parts mit `is_page()`-Guard: wiederverwendbare Sections
> Cortex-Web Session 24, 2026-04-22. Praxis-Webseite, Blocksy Child Theme.
> Bauteil: Cross-Link-Cards auf `/praxis/` ohne Duplizierung des Templates.

---

## Was

Wenn genau **eine** Seite eine zusätzliche Section braucht, die andere Seiten
des gleichen Templates NICHT zeigen sollen, gibt es drei Wege:

1. **Neues Page-Template duplizieren** (`template-praxis.php`). → Mehrarbeit,
   Drift-Risiko (Template-Fixes müssen in beide Dateien).
2. **Section in den WP-Editor-Content einbetten**. → Funktioniert, aber
   redaktionell: Struktur versteckt sich im HTML-Editor, schlecht
   wartbar, kein Theme-Versioning.
3. **Template-Part + Guard**: die Section lebt im Theme, wird aber nur
   gerendert, wenn `is_page('slug')` passt. → Beste Lösung für
   1 Seite ≠ Editor-Content.

Dieses Tutorial zeigt Weg 3.

## Warum

- **Single Source für die Section-Markup**: Das Template-Part ist ein
  normales PHP-File unter `template-parts/`, wird mit `get_template_part()`
  eingezogen.
- **Guard ist slug-basiert**: `is_page('praxis')` bleibt stabil, auch wenn
  die Page-ID wechselt (z. B. nach Re-Import).
- **Kein CSS-/JS-Leak auf andere Seiten**: Styles hängen am
  `.pxz-praxis-crosslinks*`-Namespace, rendern wird aber erst wenn der
  Guard greift — kein Overhead auf `/impressum/` & Co.
- **Wartbar**: Templates-Fixes laufen weiterhin zentral in
  `template-standard.php`.

## Wie (Schritt für Schritt)

### 1. Template-Part anlegen

`template-parts/praxis-crosslinks.php`:

```php
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$links = [
  [
    'href' => '/leistungen/',
    'title' => 'Leistungen',
    'sub' => 'Ambulantes Leistungsspektrum …',
  ],
  [
    'href' => '/diagnostik/',
    'title' => 'Diagnostik',
    'sub' => 'Sonographie, EKG, Labor …',
  ],
];
?>
<section class="pxz-praxis-crosslinks">
  <ul class="pxz-praxis-crosslinks-grid">
    <?php foreach ( $links as $link ) : ?>
      <li class="pxz-card">
        <a href="<?php echo esc_url( home_url( $link['href'] ) ); ?>">
          <h3><?php echo esc_html( $link['title'] ); ?></h3>
          <p><?php echo esc_html( $link['sub'] ); ?></p>
        </a>
      </li>
    <?php endforeach; ?>
  </ul>
</section>
```

### 2. Guard im Template einbauen

Im gemeinsamen Template (`template-standard.php`):

```php
<?php
// Cross-Links nur auf /praxis/, nicht auf Impressum/Datenschutz/Team etc.
if ( is_page( 'praxis' ) ) {
    get_template_part( 'template-parts/praxis-crosslinks' );
}
?>
```

Platziert zwischen Content-Block und CTA-Block, damit der Lesefluss
Content → Teaser → CTA-Handlungsaufforderung bleibt.

### 3. Styles an passende CSS-Datei anhängen

Da `/praxis/` `standard.css` lädt, das CSS dort anhängen. Namespace
`.pxz-praxis-crosslinks*` verhindert Kollisionen.

### 4. Version-Bump für Cache-Buster

```php
define( 'PXZ_VERSION', '2.7.19' );
```

Sonst cached WP das alte `standard.css` und die neuen Styles greifen nicht.

## Verifikation

```bash
# 1. Gibt es die Cards auf /praxis/?
curl -s http://<local>.local/praxis/ | grep -c "pxz-praxis-crosslinks-card"
# → 2 (1 pro Card)

# 2. Sind sie WIRKLICH nicht auf anderen Seiten?
curl -s http://<local>.local/impressum/ | grep -c "pxz-praxis-crosslinks"
# → 0  (Guard greift)

# 3. Cache-Buster aktiv?
curl -s http://<local>.local/praxis/ | grep -oE 'standard\.css\?ver=[0-9.]+'
# → standard.css?ver=2.7.19
```

## Häufige Fehler

- **`is_page(ID)` statt `is_page('slug')`**: Nach Import wechselt ID,
  Guard bricht. → Immer Slug nutzen.
- **Vergessener Version-Bump**: Neue Styles werden aus WP-Cache ausgeliefert,
  Änderung wird nicht sichtbar. → `PXZ_VERSION` in jeder Session erhöhen.
- **Template-Part-Datei falsch benannt**: `get_template_part( 'foo/bar' )`
  sucht unter `foo-bar.php` oder `foo/bar.php` — Strikt auf Theme-Struktur
  achten.
- **Section ohne Namespace**: `.card` kollidiert mit Parent-Theme. Immer
  eigenen Präfix (`.pxz-praxis-crosslinks-*`).

## Wann ist dieses Pattern NICHT richtig

- **3+ Seiten brauchen dieselbe Section**: Dann lohnt sich ein generisches
  Template-Part mit Custom-Field-gesteuerten Daten (Post-Meta statt Array).
- **Inhalt muss von einer Redaktion pflegbar sein**: Dann WP-Editor +
  Reusable-Block. Theme-Code zu ändern, ist nicht redakteursfreundlich.

## Bezug zum Cortex-Web-Kontext

Das Pattern ist in der Praxis-Webseite ab Session 24 im Einsatz für die
Cross-Links von `/praxis/` → `/leistungen/` + `/diagnostik/`. Spec:
`projects/Cortex-Web/sites/praxis-webseite/specs/sprint-2/S2.4c_praxis-crosslinks.md`.
