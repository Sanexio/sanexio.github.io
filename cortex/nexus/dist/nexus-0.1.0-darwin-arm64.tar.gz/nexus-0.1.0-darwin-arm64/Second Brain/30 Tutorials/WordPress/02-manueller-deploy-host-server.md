---
type: tutorial
aliases: [Deploy, Manueller-Deploy, WordPress-Deploy, Host-Server, domainfactory, LAMP, LEMP]
tags:
  - tutorial
  - wordpress
  - deploy
  - mysql
  - php
  - sftp
  - rsync
  - host-server
  - praxis-webseite
created: 2026-05-05
context: Sprint nach Webseiten-Redesign — Dr. Stracke will den Hostserver-Pfad selbst verstehen
related:
  - "[[WordPress Grundlagen]]"
  - "[[Webentwicklung Grundlagen]]"
  - "[[Netzwerk & Sysadmin/10-remote-zugriff-local-dev]]"
  - "[[WordPress/04-wp-rest-api-adapter-mit-application-passwords]]"
---

# 02 — Manueller Deploy einer WordPress-Seite zum Host-Server

> **Ziel dieses Tutorials:** Du verstehst, was technisch passiert, wenn die
> redesignte Praxis-Webseite vom **Cluster-Mini-02 (Local by Flywheel)**
> auf den **domainfactory-Hostserver** geschoben wird — und du kannst
> es im Notfall auch ohne Claude oder Automation Schritt fuer Schritt
> selbst tun.
>
> **Voraussetzung:** [[WordPress Grundlagen]] gelesen,
> [[Webentwicklung Grundlagen]] gelesen.
> **Lesezeit:** ~25 Minuten · **Praktische Durchfuehrung:** 1-2 Stunden
> beim ersten Mal.

---

## 1. Warum manuell deployen?

Im Cortex-Workflow gibt es **drei Wege**, eine Aenderung von lokal auf
Live zu bringen:

| Weg | Wann sinnvoll | Aufwand |
|---|---|---|
| **WP-REST-API** (Application Password + JSON) | Inhalts-Edits, Feld fuer Feld | gering |
| **Selektiver SFTP-Push einzelner Theme-Files** | Theme-CSS / einzelne PHP-Datei | mittel |
| **Voller manueller Deploy** (Files + Datenbank) | Redesign, neues Theme, Page-Restrukturierung | hoch |

Beim **Redesign** reicht ein REST-Push nicht: viele Pages aendern sich
gleichzeitig, Templates werden umbenannt, neue Custom-Fields kommen dazu,
manchmal wechselt sogar das Theme selbst. Dann muessen **Code (Files) und
Inhalte (Datenbank) konsistent zusammen** auf den Host-Server.

> **Goldene Regel beim Redesign:** Files und Datenbank gehoeren zusammen.
> Wer nur Files pusht, hat ein neues Theme — aber alte Inhalte, die
> es nicht mehr versteht. Wer nur die DB pusht, hat neue Inhalte —
> aber alte PHP-Templates, die sie nicht rendern koennen. Resultat in
> beiden Faellen: kaputte Site.

---

## 2. Die zwei Haelften einer WordPress-Seite

WordPress besteht physikalisch aus **zwei voellig getrennten Welten**, die
nur zur Laufzeit zusammenfinden:

### 2.1 Die Datei-Haelfte (Filesystem)

Liegt im Web-Root des Servers. Bei einer Standard-Installation:

```
public_html/                     <- Web-Root (von domainfactory bereitgestellt)
├── index.php                    <- WordPress-Bootstrap
├── wp-load.php                  <- laedt wp-config + Kern
├── wp-config.php                <- DB-Zugang + Salts (NIE oeffentlich)
├── .htaccess                    <- Apache-Rewrite-Regeln (Permalinks)
├── wp-admin/                    <- Admin-Backend (nicht anfassen)
├── wp-includes/                 <- WordPress-Kern (nicht anfassen)
└── wp-content/                  <- HIER spielt sich dein Leben ab
    ├── themes/
    │   └── praxiszentrum/       <- DEIN Theme
    ├── plugins/                 <- alle Plugins
    └── uploads/                 <- alle Bilder/PDFs (sortiert nach JJJJ/MM/)
```

**Was hier drin steht, ist Code und Assets.** Es weiss nichts ueber
konkrete Inhalte (Texte, Doctor-Beschreibungen, Termin-Mails). Ein
Theme ist sozusagen ein leeres Haus — Tapeten, Fenster, Treppen sind
da, aber kein Mobiliar.

### 2.2 Die Datenbank-Haelfte (MySQL/MariaDB)

Liegt in einer komplett anderen Software (dem Datenbank-Server, meist
MariaDB) und wird **nicht** ueber das Filesystem deployed. Sie enthaelt
die eigentlichen Inhalte.

**Wichtige Tabellen einer WP-Datenbank:**

| Tabelle | Inhalt |
|---|---|
| `wp_posts` | Pages, Posts, Revisionen, Anhaenge — eine Zeile pro Seite |
| `wp_postmeta` | Custom Fields zu Pages (z. B. welches Template) |
| `wp_options` | Globale Einstellungen (Site-URL, aktive Plugins, Permalink-Struktur) |
| `wp_users` / `wp_usermeta` | Benutzerkonten und ihre Rollen |
| `wp_terms` / `wp_term_taxonomy` / `wp_term_relationships` | Kategorien, Tags, Custom-Taxonomien |
| `wp_icl_translations` | (WPML-Plugin) Sprach-Verknuepfungen |

**Was hier drin steht, sind die Inhalte.** Ohne DB ist die Webseite leer
(genauer: WP zeigt eine Fehlerseite, weil es nicht mal seine
eigenen Optionen lesen kann).

> **Merksatz:** Files = Code. DB = Inhalt. Beides muss beim Redesign
> gemeinsam wandern.

---

## 3. Der LAMP/LEMP-Stack — warum brauchst du was?

WordPress ist eine **PHP-Anwendung**, die auf einem **Webserver** laeuft
und ihre Inhalte aus einer **Datenbank** holt. Auf einem Linux-Hoster
nennt man die Kombi **LAMP** oder **LEMP**:

```
┌──────────────────────────────────────────────────────┐
│  L — Linux       (Betriebssystem auf dem Server)     │
│  A — Apache      (Webserver, alternative: Nginx=LEMP)│
│  M — MySQL       (Datenbank, heute meist MariaDB)    │
│  P — PHP         (Programmiersprache, in der WP laeuft)│
└──────────────────────────────────────────────────────┘
```

Was wer beitraegt:

| Komponente | Aufgabe | Bei domainfactory |
|---|---|---|
| **Linux** | OS auf dem Hoster, alles laeuft drauf | Ja, im Hintergrund verwaltet |
| **Apache** | Empfaengt HTTP-Anfragen, leitet PHP-Anfragen an PHP weiter, liefert statische Files (CSS, JS, Bilder) direkt aus | Ja, Standard bei domainfactory |
| **PHP** | Fuehrt WordPress' PHP-Dateien aus (z. B. `index.php`, `page.php`), erzeugt HTML | Ja — Version waehlbar im Kundencenter (8.1/8.2/8.3) |
| **MySQL/MariaDB** | Speichert Inhalte, Pages, Optionen | Ja — separater DB-Server, Zugang ueber Hostname `db1234.dbnetz.de` o.ae. |

**Ein einzelner Page-Aufruf laeuft ab wie folgt:**

```
1. Browser tippt:           westend-hausarzt.com/team/
2. DNS:                     westend-hausarzt.com -> domainfactory-IP
3. Apache:                  bekommt HTTP GET /team/
4. .htaccess (Apache):      „dafuer gibt's keine echte Datei /team/, also
                             route an /index.php" (Permalink-Magie)
5. Apache uebergibt an PHP: /index.php mit Param REQUEST_URI=/team/
6. PHP lae:                 wp-load.php → wp-config.php → Kern
7. WP fragt MySQL:          „Gibt's eine Page mit slug=team?" -> ja, ID 17
8. WP waehlt Template:      page-team.php (oder template-team.php), liest
                             aus wp-content/themes/praxiszentrum/
9. Template ruft Funktionen wp_head(), the_content(), wp_footer() auf —
   die selbst MySQL fragen, um Header/Inhalt/Footer zu rendern
10. PHP gibt fertiges HTML  an Apache zurueck
11. Apache liefert HTML      an den Browser aus
12. Browser rendert + holt   CSS, JS, Bilder (statisch von Apache)
```

> **Warum ist das wichtig fuer den Deploy?** Weil jeder Schritt eine eigene
> Fehlerquelle ist. Wenn nach dem Deploy die Site weiss bleibt, muss man
> wissen, ob der Fehler in Apache (Logs in `/var/log/apache2/`), in PHP
> (Fehler-Log oft in `wp-content/debug.log` wenn `WP_DEBUG_LOG=true`),
> oder in MySQL (DB-Connection-Error, falsche Credentials) liegt.

---

## 4. PHP — was du minimal verstehen musst

PHP ist die Programmiersprache, in der WordPress geschrieben ist. Du
musst keinen PHP-Code schreiben koennen, aber drei Dinge solltest du
verstehen:

### 4.1 PHP wird auf dem Server ausgefuehrt, nicht im Browser

Wenn du im Browser auf eine .php-Datei zugreifst, **siehst du nie den
PHP-Code** — nur das HTML, das er erzeugt hat. „View Source" im Browser
zeigt das fertige HTML.

### 4.2 PHP-Versionen sind nicht rueckwaerts-kompatibel

WordPress 6.x braucht **mindestens PHP 7.4**, empfohlen 8.1 oder 8.2.
Wenn der Hoster auf einer aelteren Version laeuft (PHP 7.2), bricht die
Site beim ersten Aufruf mit „Fatal Error: syntax error" ab.

**Vor dem Deploy pruefen:**

```bash
# Lokal (Local by Flywheel)
php -v

# Im domainfactory-Kundencenter:
# Konto -> Webhosting -> PHP-Version (waehlbar pro Domain)
```

> **Falle:** Plugins koennen mit der einen PHP-Version laufen, mit der
> anderen nicht. WPML 4.7 hat z. B. mit PHP 8.4 Deprecation-Warnings.
> Wenn du lokal mit 8.2 entwickelst und der Hoster auf 8.4 steht, kann
> es im Live-Stack krachen, obwohl es lokal lief. **Beide Versionen
> identisch halten** ist die einfachste Loesung.

### 4.3 Fehler-Logging einschalten

In `wp-config.php` (vor dem `That's all, stop editing!`-Kommentar):

```php
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );        // schreibt in wp-content/debug.log
define( 'WP_DEBUG_DISPLAY', false );   // KEINE Fehler im Frontend zeigen
@ini_set( 'display_errors', 0 );
```

Im Live-Stack: **DISPLAY immer false**, sonst sehen Patienten PHP-Stack-
Traces. Wenn der Deploy schiefgeht, ist `wp-content/debug.log` der erste
Ort, an dem du nachschaust.

---

## 5. MySQL / MariaDB — die Datenbank verstehen

Die Datenbank ist eigentlich ein eigenes Programm (`mysqld`), das auf
einem Port (Standard: 3306) lauscht und SQL-Anfragen entgegennimmt.

### 5.1 MySQL vs. MariaDB

- **MySQL** — original Oracle, kommerzieller Hintergrund.
- **MariaDB** — Open-Source-Fork, in Linux-Distros heute Standard, fast
  100 % kompatibel zu MySQL.

In der Praxis ist es egal, welche Variante laeuft. Das `mysql`-Kommando
auf der Konsole funktioniert in beiden.

### 5.2 Wichtige Konzepte

| Begriff | Bedeutung |
|---|---|
| **Datenbank** (Database) | Eine Sammlung von Tabellen. Fuer eine WP-Site gibt's genau eine. Bei domainfactory haben sie Namen wie `db1234567_wp`. |
| **Tabelle** (Table) | Vergleichbar einer Excel-Tabelle: feste Spalten, viele Zeilen. |
| **Zeile** (Row) | Ein einzelner Datensatz, z. B. eine Page. |
| **Spalte** (Column) | Ein Feld, z. B. `post_title` oder `post_content`. |
| **PRIMARY KEY** | Eindeutige ID-Spalte (`ID` bei `wp_posts`). |
| **Charset / Collation** | Zeichensatz (`utf8mb4`) und Sortierreihenfolge (`utf8mb4_unicode_ci`). MUSS auf Local und Host gleich sein, sonst kommt **Mojibake**. |
| **DB-User** | Loginname fuer den DB-Server. WP braucht GRANT-Rechte fuer SELECT/INSERT/UPDATE/DELETE auf der eigenen DB. |
| **DB-Host** | Hostname des DB-Servers. Bei domainfactory NICHT `localhost`, sondern was im Kundencenter steht (z. B. `db1234.dbnetz.de`). |

### 5.3 Wo die Site-URL in der DB steckt

Eine WordPress-DB enthaelt die **Site-URL an mehreren Stellen** —
weshalb beim Deploy ein **Search-Replace** noetig ist:

| Tabelle | Spalte | Was steht drin |
|---|---|---|
| `wp_options` | `option_value` (Zeilen `siteurl`, `home`) | `https://gpmedicalcenter…local` |
| `wp_posts` | `post_content`, `guid` | Bilder mit absoluter URL `<img src="https://…local/wp-content/uploads/…">` |
| `wp_postmeta` | `meta_value` | Theme-Custom-Fields, oft mit URLs |
| `wp_options` | `option_value` (serialisiert) | `widget_*`, `theme_mods_*`, etc. |

Wenn du nur per SQL `REPLACE()` machst, **bricht** die PHP-Serialisierung,
wo Strings mit Laengenangabe gespeichert sind (`s:43:"https://…"`). Daher
**immer** mit einem serialization-aware Tool (`wp search-replace` oder
WP-CLI im Bootstrap-Skript) arbeiten.

---

## 6. Apache vs. Nginx — Webserver in 1 Minute

Du musst es nicht aussuchen — domainfactory entscheidet das fuer dich
(Apache mit `.htaccess`-Support).

| Aspekt | Apache | Nginx |
|---|---|---|
| Konfig pro Verzeichnis | Ja, `.htaccess` | Nein, nur central |
| WordPress-Permalinks | `mod_rewrite` per `.htaccess` | im Server-Block |
| Bei domainfactory? | Standard | nein |
| Bei Local by Flywheel? | optional | Nginx ist Default |

**Was im Deploy zaehlt:** die `.htaccess` muss korrekt sein, sonst
funktionieren die Permalinks nicht (alle Unterseiten geben 404 trotz
korrekter DB-Inhalte). Standard-`.htaccess` fuer WP:

```apache
# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
RewriteBase /
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>
# END WordPress
```

Die wird normalerweise von WP automatisch gepflegt, sobald du im Admin
unter „Einstellungen → Permalinks" auf Speichern klickst.

---

## 7. Der Host-Server (domainfactory) — Zugang in der Praxis

domainfactory ist der Hoster der Praxis-Webseite. Du musst drei
Zugangsarten kennen:

### 7.1 Kundencenter (Browser)

URL: `https://login.df.eu/`. Hier steht alles zum Vertrag, PHP-Version,
Mail-Konten, Datenbank-Anlage, FTP-User. **Aendere PHP-Version oder
Mail-Konfig nur hier**, nie ueber FTP.

### 7.2 SFTP (Datei-Zugriff)

SFTP = SSH File Transfer Protocol. Sicherer Nachfolger von FTP.

**Zugangsdaten** stehen im Kundencenter unter „FTP-Zugaenge" (oder
„Webspace-Zugaenge"):

| Feld | Beispiel |
|---|---|
| Server | `ssh.df.eu` oder `ftp.westend-hausarzt.com` |
| Port | 22 (SFTP) |
| User | `df1234567` (deine Webspace-Kennung) |
| Passwort | wird im Kundencenter gesetzt |

**SSH-Key statt Passwort** ist sicherer und schneller — im Kundencenter
hochladen.

**Tools, mit denen du SFTP nutzt:**

| Tool | Wofuer |
|---|---|
| **Cyberduck / FileZilla** (GUI) | Drag-and-Drop, fuer einzelne Files |
| **`sftp`** (Terminal) | scriptbar, fuer Batch |
| **`rsync` ueber SSH** | inkrementell (nur geaenderte Files), schnellste Variante fuer ganze Theme-Ordner |

### 7.3 SSH (Shell-Zugriff, nicht alle Tarife)

Manche Hosting-Pakete bei domainfactory bieten **echtes SSH** an —
dann kannst du dich auf dem Server einloggen und z. B. `wp-cli`
direkt dort ausfuehren. Das vereinfacht den Deploy massiv. Bei
Standard-Webhosting-Paketen ist das oft nur SFTP, kein interaktives SSH.

**Pruefen, ob SSH geht:**

```bash
ssh df1234567@ssh.df.eu
# Erfolg: du bekommst eine Bash-Prompt, kannst `ls`, `php -v` etc.
# Fehler: „This service allows sftp connections only."
```

### 7.4 Datenbank-Zugang

Bei domainfactory bekommt jede DB einen eigenen Host. Die Zugangsdaten
stehen im Kundencenter unter „Datenbanken":

| Feld | Beispiel |
|---|---|
| DB-Host | `db1234.dbnetz.de` |
| DB-Name | `db1234567_wp` |
| DB-User | `db1234567_wp` (oft identisch mit DB-Name) |
| DB-Pass | wird im Kundencenter gesetzt |

**Zwei Wege, die DB anzusprechen:**

| Weg | Tool |
|---|---|
| Browser-basiert | **phpMyAdmin** (im Kundencenter verlinkt) |
| Konsole | **`mysql`-CLI** ueber SSH (wenn der Tarif SSH erlaubt) — sonst lokal mit `--host=db1234.dbnetz.de` (Achtung: domainfactory blockt extern oft den DB-Port) |

---

## 8. Vor dem Deploy — was vorbereitet werden muss

### 8.1 Backup, Backup, Backup

**Vor jedem Deploy** auf den Live-Server:

1. **Live-Files**: per SFTP komplett spiegeln in
   `~/Cortex/projects/Cortex-Web/_backups/<datum>/files/`
2. **Live-DB**: `mysqldump` ziehen in
   `~/Cortex/projects/Cortex-Web/_backups/<datum>/db.sql`
3. **Beides committen** (oder zumindest tarball + Hash notieren) —
   im Notfall ist das dein Roll-Back.

```bash
# Files: per rsync ziehen
rsync -avz df1234567@ssh.df.eu:public_html/ \
    ~/Cortex/projects/Cortex-Web/_backups/$(date +%F)/files/

# DB: per SSH und mysqldump
ssh df1234567@ssh.df.eu \
    "mysqldump --single-transaction --quick \
        -h db1234.dbnetz.de -u db1234567_wp -p'PASSWORD' db1234567_wp" \
    > ~/Cortex/projects/Cortex-Web/_backups/$(date +%F)/db.sql
```

### 8.2 Wartungsmodus aktivieren

Damit kein Patient waehrend des Deploys eine halb-kaputte Seite sieht:

```bash
# Auf dem Server (oder via SFTP eine Datei .maintenance ablegen)
echo "<?php \$upgrading = time(); ?>" > public_html/.maintenance
```

Solange diese Datei existiert, zeigt WP eine Wartungs-Meldung. Nach
dem Deploy **wieder loeschen**, sonst bleibt die Seite gesperrt.

### 8.3 PHP-Version-Match pruefen

```bash
# Lokal
php -v
# Live (per SSH)
ssh df1234567@ssh.df.eu php -v
```

Beide sollten **gleiche Major.Minor**-Version haben (z. B. beide 8.2.x).
Sonst Live anpassen im Kundencenter, **bevor** der Deploy laeuft.

### 8.4 Inventar der zu deployenden Komponenten

Schreibe vor dem Deploy auf:

- [ ] Welche Theme-Files haben sich geaendert?
  (Kommando: `git diff --stat HEAD~5 -- wp-content/themes/praxiszentrum/`)
- [ ] Wurden Plugins aktiviert / deaktiviert / aktualisiert?
- [ ] Sind neue Pages oder Posts dazugekommen?
- [ ] Haben sich URL-Strukturen geaendert (Permalinks)?
- [ ] Sind neue `wp_options` dazugekommen (z. B. neues Theme-Setting)?

---

## 9. Schritt 1: Dateien rueberbringen

Drei Wege, in Reihenfolge der Effizienz:

### 9.1 Variante A: rsync ueber SSH (empfohlen)

```bash
# Aus dem Local-by-Flywheel-Site-Pfad
cd "/Users/cluster-mini-02/Local Sites/gpmedicalcenter…/app/public/"

rsync -avz --delete \
    --exclude=".git/" \
    --exclude="wp-config.php" \
    --exclude="wp-content/uploads/" \
    --exclude="wp-content/cache/" \
    --exclude="wp-content/debug.log" \
    wp-content/themes/praxiszentrum/ \
    df1234567@ssh.df.eu:public_html/wp-content/themes/praxiszentrum/
```

**Wichtig:**

- `-avz` = archive + verbose + compressed (Standard fuer Web-Deploy)
- `--delete` = Dateien, die lokal weg sind, auch remote loeschen.
  **Vorsicht** bei `wp-content/uploads/` — die lebt auf Live laenger
  als auf Local, deshalb explizit ausschliessen.
- `--exclude=wp-config.php` = NIEMALS lokale `wp-config.php` ueber die
  Live-Version druebergebuegelt — Datenbank-Credentials sind
  unterschiedlich, sonst geht die Site sofort offline.

### 9.2 Variante B: SFTP-GUI (Cyberduck, FileZilla)

Bei kleinen Aenderungen oder wenn rsync nicht verfuegbar ist:

1. Cyberduck oeffnen, mit `df1234567@ssh.df.eu` verbinden.
2. Im linken Fenster lokales Theme-Verzeichnis, im rechten remote
   `/public_html/wp-content/themes/praxiszentrum/`.
3. Geaenderte Files markieren, rueberziehen. Ueberschreiben bestaetigen.

Nachteile: keine Inkrementalitaet, manuell, fehleranfaellig bei vielen
Files.

### 9.3 Variante C: Git-Pull auf dem Server

Wenn dein Theme ein eigenes Git-Repo hat **und** der Server SSH erlaubt:

```bash
ssh df1234567@ssh.df.eu
cd public_html/wp-content/themes/praxiszentrum/
git pull origin main
```

Sauberster Weg, weil deterministisch — was im Repo steht, ist auf dem
Server. **Nur** nutzen, wenn du das Theme-Repo strikt versionierst und
keine ungespeicherten Edits direkt auf dem Server vornimmst.

### 9.4 Was NICHT mitgepusht wird

| Datei / Ordner | Warum nicht |
|---|---|
| `wp-config.php` | Andere DB-Credentials lokal vs. Live |
| `wp-content/uploads/` | Live hat oft mehr (Patienten-Uploads, Bilder die nur live entstanden) |
| `wp-content/cache/` | Cache regeneriert sich selbst |
| `wp-content/debug.log` | Nur lokales Debug |
| `.git/`, `.local/`, `node_modules/` | Build-Artefakte, gehoeren nicht ins Web-Root |

---

## 10. Schritt 2: Datenbank rueberbringen

Der heikelste Schritt beim Redesign. Ablauf:

### 10.1 Lokal: DB exportieren

```bash
# Local-by-Flywheel hat eigenes mysql-Binary
LOCAL_MYSQL="/Applications/Local.app/Contents/Resources/extraResources/lightning-services/mysql-8.0.35+4/bin/darwin/bin/mysql"
LOCAL_DUMP="${LOCAL_MYSQL%/*}/mysqldump"

cd "/Users/cluster-mini-02/Local Sites/gpmedicalcenter…/app/public/"

"$LOCAL_DUMP" \
    --socket=/Users/cluster-mini-02/Library/Application\ Support/Local/run/SOCKET-ID/mysql/mysqld.sock \
    --user=root --password=root \
    --single-transaction --quick \
    --default-character-set=utf8mb4 \
    local | gzip > /tmp/wp-local-$(date +%F).sql.gz
```

(Den genauen Socket-Pfad findest du in Local UI → Database → „Open MySQL
Manager" oder im SHELL-Tab.)

### 10.2 URLs in der Dump-Datei ersetzen — VORSICHT

Die einfache Variante (NUR fuer Strings ohne PHP-Serialisierung):

```bash
gunzip -c /tmp/wp-local-2026-05-05.sql.gz \
    | sed 's|gpmedicalcenter\.local|westend-hausarzt.com|g' \
    > /tmp/wp-deploy-2026-05-05.sql
```

**Warum das gefaehrlich ist:** PHP-serialisierte Strings (`s:43:"https://…";`)
haben eine **Laengen-Angabe** in Bytes. Wenn die alte URL 27 Zeichen
hatte und die neue 24, stimmt die `:43:` nicht mehr — beim naechsten
WordPress-Read kommt `unserialize() Fehler`, Plugin-Crash.

**Die richtige Variante** ist `wp search-replace`, das **nach dem Import**
auf der Live-DB laeuft und PHP-Serialisierung respektiert:

```bash
# Auf dem Server (per SSH)
ssh df1234567@ssh.df.eu
cd public_html/
wp search-replace 'https://gpmedicalcenter.local' 'https://westend-hausarzt.com' \
    --all-tables --precise --recurse-objects
```

`--precise` zwingt PHP-Aware-Mode, `--recurse-objects` geht in
verschachtelte Arrays rein, `--all-tables` checkt auch Plugin-Tables.

### 10.3 Live: Backup der bisherigen DB ziehen (siehe §8.1)

### 10.4 Live: alte DB leeren oder neue Tabellen anlegen

Beim Redesign **wirst du in der Regel die ganze DB ersetzen**.

**Variante 1 — phpMyAdmin (Browser):**

1. Kundencenter -> phpMyAdmin oeffnen
2. DB `db1234567_wp` auswaehlen
3. Reiter „Operationen" -> „Datenbank loeschen"
4. Neu anlegen mit gleichem Namen, Charset `utf8mb4`,
   Collation `utf8mb4_unicode_ci`

**Variante 2 — per SSH:**

```bash
ssh df1234567@ssh.df.eu
mysql -h db1234.dbnetz.de -u db1234567_wp -p
> DROP DATABASE db1234567_wp;
> CREATE DATABASE db1234567_wp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
> EXIT;
```

### 10.5 Live: Dump importieren

```bash
# Dump auf Server kopieren (rsync oder scp)
scp /tmp/wp-deploy-2026-05-05.sql df1234567@ssh.df.eu:/tmp/

# Auf Server: importieren
ssh df1234567@ssh.df.eu
mysql -h db1234.dbnetz.de -u db1234567_wp -p db1234567_wp < /tmp/wp-deploy-2026-05-05.sql
```

Dauert je nach DB-Groesse 30 Sekunden bis 5 Minuten.

### 10.6 Live: Search-Replace ausfuehren (siehe §10.2 oben)

### 10.7 Live: rewrite_rules fluschen

Damit Permalinks funktionieren:

```bash
wp rewrite flush --hard
# alternativ im Admin: Einstellungen -> Permalinks -> Speichern (ohne Aenderung)
```

---

## 11. Schritt 3: wp-config.php anpassen

Die Live-`wp-config.php` darf **NIE** mit der lokalen ueberschrieben werden.
Sie unterscheidet sich in:

```php
// LOKAL
define( 'DB_NAME',     'local' );
define( 'DB_USER',     'root' );
define( 'DB_PASSWORD', 'root' );
define( 'DB_HOST',     'localhost' );
define( 'WP_HOME',     'https://gpmedicalcenter.local' );
define( 'WP_SITEURL',  'https://gpmedicalcenter.local' );

// LIVE
define( 'DB_NAME',     'db1234567_wp' );
define( 'DB_USER',     'db1234567_wp' );
define( 'DB_PASSWORD', '<aus Kundencenter>' );
define( 'DB_HOST',     'db1234.dbnetz.de' );
define( 'WP_HOME',     'https://westend-hausarzt.com' );
define( 'WP_SITEURL',  'https://westend-hausarzt.com' );

// Salts MUESSEN unterschiedlich sein zwischen Local und Live —
// neue auf https://api.wordpress.org/secret-key/1.1/salt/ generieren
define( 'AUTH_KEY',         '...' );
define( 'SECURE_AUTH_KEY',  '...' );
// ... (8 Salt-Konstanten insgesamt)
```

**Workflow:**

1. Live-`wp-config.php` per SFTP auf Cluster-Mini-02 ziehen, **vor** dem
   Deploy als `wp-config.live.php` lokal speichern (nie ins Repo!).
2. Nach dem Deploy: pruefen, ob die Live-`wp-config.php` noch da ist.
   Falls rsync sie geloescht hat (sollte durch `--exclude` verhindert
   sein), die gespeicherte Kopie zurueckspielen.

> **Sicherheits-Warnung:** `wp-config.php` enthaelt Klartext-Passwoerter.
> NIE in Git committen. Auch nicht in private Repos. Permissions auf
> dem Server: `chmod 600 wp-config.php`.

---

## 12. Schritt 4: Permalinks, Cache, Smoke-Tests

### 12.1 Permalinks fluschen (Pflicht)

```bash
wp rewrite flush --hard
```

Oder im Browser: `wp-admin/options-permalink.php` -> Speichern.

### 12.2 Caches leeren

| Cache-Typ | Wie leeren |
|---|---|
| **WP-Object-Cache** | `wp cache flush` |
| **WP-Transients** | `wp transient delete --all` |
| **Plugin-Cache** (WP Super Cache, W3TC) | im Plugin-UI „Cache leeren" |
| **Browser-Cache** | beim Smoke-Test mit Cmd-Shift-R hart neu laden |
| **CDN** (falls genutzt) | im CDN-Kundencenter „Purge All" |

### 12.3 .maintenance loeschen

```bash
ssh df1234567@ssh.df.eu rm public_html/.maintenance
```

### 12.4 Smoke-Tests — Pflicht-Checkliste

In dieser Reihenfolge:

- [ ] **Homepage** `https://westend-hausarzt.com/` laedt, kein 500/502
- [ ] **Login** unter `/wp-admin/` funktioniert
- [ ] **2-3 zufaellige Pages** (Team, Kontakt, eine Detail-Page)
- [ ] **Bilder** werden geladen (kein Mojibake im Filename, kein 404)
- [ ] **Kontaktformular** abschicken (Test-Submit, Mail kommt an)
- [ ] **Sprach-Switch** WPML: DE -> EN -> FR -> Original
- [ ] **Permalinks**: `/team/dr-stracke/` ohne 404
- [ ] **Browser-DevTools-Console**: keine roten Fehler
- [ ] **Mobile-Ansicht** (Chrome-DevTools-Device-Mode)
- [ ] **HTTPS-Lock** im Browser, kein Mixed-Content-Warning

Wenn ein Test fehlschlaegt: `wp-content/debug.log` und Apache-Error-Log
zuerst lesen, **bevor** weitere Aenderungen gemacht werden.

---

## 13. Rollback-Strategie

Wenn nach dem Deploy was nicht geht und sich nicht innerhalb von 15
Minuten fixen laesst: **rollback**, nicht weiter-debuggen unter Druck.

### 13.1 Rollback Files

```bash
# Auf dem Server: alte Files aus Backup zurueck
rsync -avz --delete \
    ~/Cortex/projects/Cortex-Web/_backups/2026-05-04/files/wp-content/themes/praxiszentrum/ \
    df1234567@ssh.df.eu:public_html/wp-content/themes/praxiszentrum/
```

### 13.2 Rollback DB

```bash
# Per SSH: alte DB importieren
ssh df1234567@ssh.df.eu
mysql -h db1234.dbnetz.de -u db1234567_wp -p
> DROP DATABASE db1234567_wp;
> CREATE DATABASE db1234567_wp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
> EXIT;

scp ~/Cortex/projects/Cortex-Web/_backups/2026-05-04/db.sql \
    df1234567@ssh.df.eu:/tmp/

ssh df1234567@ssh.df.eu \
    "mysql -h db1234.dbnetz.de -u db1234567_wp -p'PASSWORD' db1234567_wp < /tmp/db.sql"
```

### 13.3 Permalinks neu fluschen

```bash
wp rewrite flush --hard
```

---

## 14. Haeufige Fallstricke

| Symptom | Ursache | Loesung |
|---|---|---|
| **HTTP 500** auf Homepage | PHP-Version-Mismatch oder Plugin-Crash | `wp-content/debug.log` lesen, falsche PHP-Version im Kundencenter umstellen |
| **Weisse Seite** | PHP-Memory-Limit zu klein, oder Fatal Error mit `display_errors=off` | `define('WP_DEBUG_DISPLAY', true)` temporaer + Reload, dann sieht man den Error |
| **Mojibake** (`Ã¤` statt `ä`) | DB-Charset-Mismatch | Beide DBs auf `utf8mb4` + `utf8mb4_unicode_ci`. Re-Import mit `--default-character-set=utf8mb4` |
| **Login geht nicht / Loop** | Salts in `wp-config.php` falsch oder Session-Cookies durch URL-Wechsel kaputt | Salts neu generieren, `wp_options.siteurl` und `home` per SQL pruefen |
| **Bilder 404** | absolute URLs in `post_content` zeigen auf alte Domain | `wp search-replace` nochmal, `--all-tables --precise` |
| **Permalinks 404** | `.htaccess` fehlt oder `mod_rewrite` aus | `.htaccess` neu erzeugen via `wp rewrite flush --hard`, im Kundencenter pruefen ob `mod_rewrite` an |
| **Plugin meldet `unserialize()` failed** | Search-Replace mit `sed` durchgefuehrt, Laengen-Angabe kaputt | DB aus Backup zurueck, dann `wp search-replace` mit `--precise` |
| **DB-Connection-Error** | `wp-config.php` mit lokalen Credentials ueberschrieben | Backup-Kopie der Live-`wp-config.php` zurueck |
| **WPML zeigt Sprach-Switcher nicht** | `wp_icl_translations` und `wp_icl_languages` fehlen im Dump | mysqldump muss `--all-databases`-Mode oder explizite Tabellen-Liste haben — **nicht** nur die Standard-WP-Tables |
| **Theme greift, Inhalte fehlen** | DB nicht importiert oder falsche DB-Auswahl | DB-Name in `wp-config.php` und im Kundencenter abgleichen |

---

## 15. Sicherheits-Checkliste nach dem Deploy

- [ ] `wp-config.php` ist `chmod 600`
- [ ] `wp-config.php` enthaelt KEINE Debug-Display-Flags mehr
  (`WP_DEBUG_DISPLAY=false`, `display_errors=0`)
- [ ] `.maintenance` ist geloescht
- [ ] `wp-content/debug.log` ist geloescht oder leer
- [ ] Alle WP-User haben **starke** Passwoerter; alte Test-Accounts geloescht
- [ ] **Application Passwords** (REST-API-Tokens) geprueft, nicht-genutzte
  revoked
- [ ] HTTPS funktioniert, Cert ist gueltig
- [ ] **wpseo / SEO-Plugins**: Sitemap regeneriert, Search-Console
  benachrichtigt (falls URL-Struktur geaendert)
- [ ] **Backup-Plan** fuer Live-Site aktiv (z. B. UpdraftPlus
  oder externes Tool)

---

## 16. Quick-Reference — Deploy-Befehle in Reihenfolge

```bash
# === VOR DEM DEPLOY ===

# 1. Live-Backup ziehen
DATUM=$(date +%F)
mkdir -p ~/Cortex/projects/Cortex-Web/_backups/$DATUM
rsync -avz df1234567@ssh.df.eu:public_html/ \
    ~/Cortex/projects/Cortex-Web/_backups/$DATUM/files/
ssh df1234567@ssh.df.eu \
    "mysqldump -h db1234.dbnetz.de -u db1234567_wp -p'$DBPASS' \
        --single-transaction --quick db1234567_wp" \
    > ~/Cortex/projects/Cortex-Web/_backups/$DATUM/db-live-pre.sql

# 2. Wartungsmodus an
ssh df1234567@ssh.df.eu \
    "echo '<?php \$upgrading = time(); ?>' > public_html/.maintenance"

# === DEPLOY ===

# 3. Files pushen
cd "/Users/cluster-mini-02/Local Sites/.../app/public/"
rsync -avz --delete \
    --exclude=".git/" --exclude="wp-config.php" \
    --exclude="wp-content/uploads/" --exclude="wp-content/cache/" \
    wp-content/themes/praxiszentrum/ \
    df1234567@ssh.df.eu:public_html/wp-content/themes/praxiszentrum/

# 4. Lokale DB dumpen
"$LOCAL_DUMP" --socket=... --user=root --password=root \
    --single-transaction --default-character-set=utf8mb4 local \
    > /tmp/wp-deploy.sql

# 5. Auf Server hochladen + importieren
scp /tmp/wp-deploy.sql df1234567@ssh.df.eu:/tmp/
ssh df1234567@ssh.df.eu \
    "mysql -h db1234.dbnetz.de -u db1234567_wp -p'$DBPASS' db1234567_wp \
        < /tmp/wp-deploy.sql"

# 6. URLs ersetzen (PHP-aware)
ssh df1234567@ssh.df.eu \
    "cd public_html && wp search-replace \
        'https://gpmedicalcenter.local' 'https://westend-hausarzt.com' \
        --all-tables --precise --recurse-objects"

# 7. Permalinks fluschen + Cache leeren
ssh df1234567@ssh.df.eu \
    "cd public_html && wp rewrite flush --hard && wp cache flush \
        && wp transient delete --all"

# 8. Wartungsmodus aus
ssh df1234567@ssh.df.eu rm public_html/.maintenance

# === SMOKE-TESTS (manuell im Browser, siehe §12.4) ===
```

---

## 17. Glossar — Begriffe in diesem Tutorial

| Begriff | Bedeutung |
|---|---|
| **Apache / Nginx** | Webserver-Software, die HTTP-Anfragen empfaengt und an PHP weitergibt |
| **`.htaccess`** | Apache-Konfig pro Verzeichnis. Bei WP fuer Permalink-Rewrites zustaendig. |
| **Charset / Collation** | DB-Zeichensatz (`utf8mb4`) und Sortierreihenfolge (`utf8mb4_unicode_ci`). |
| **Datenbank-Dump** | SQL-Datei, die alle Tabellen + Inhalte als `INSERT`-Statements enthaelt. Erzeugt von `mysqldump`. |
| **DB-Host** | Hostname des MySQL-Servers. Bei domainfactory NICHT `localhost`. |
| **LAMP / LEMP** | Linux + Apache/Nginx + MySQL + PHP — der klassische Web-Stack. |
| **Mojibake** | Defekt dargestellte Sonderzeichen (`Ã¤` statt `ä`). Folge von Charset-Mismatch beim Import. |
| **Permalink** | URL einer Page (`/team/`). Bei WP per `.htaccess`-Rewrite an `index.php` geleitet. |
| **PHP-Serialisierung** | Format, in dem WP Arrays in `wp_options.option_value` speichert (`a:2:{s:3:"key";...}`). Brueche bei naivem Search-Replace. |
| **rsync** | Inkrementelles Kopier-Tool. Schickt nur geaenderte Files. |
| **Salts** | Geheime Strings in `wp-config.php`, die Cookies und Passwort-Hashes wuerzen. Local und Live MUESSEN unterschiedliche haben. |
| **search-replace** | WP-CLI-Befehl, der URLs in der DB PHP-aware ersetzt. |
| **SFTP** | SSH File Transfer Protocol — sicherer Datei-Upload, Standard-Port 22. |
| **Wartungsmodus** | `.maintenance`-Datei im Web-Root, die WP eine Wartungs-Seite zeigen laesst. |
| **wp-cli** | Kommandozeilen-Werkzeug fuer WordPress. Auf dem Server installiert oder als Phar mitgebracht. |
| **wp-config.php** | Konfig-Datei mit DB-Credentials und Salts. NIEMALS ins Git, Rechte 600. |

---

## 18. Lern-Reihenfolge

1. **Diese Seite** lesen — du verstehst die zwei Haelften (Files + DB)
2. [[WordPress Grundlagen]] — Konzepte rund um WP selbst
3. [[Webentwicklung Grundlagen]] §6 (Hosting) — Domain/DNS/Server-Begriffe
4. [[Netzwerk & Sysadmin/10-remote-zugriff-local-dev]] — wie der lokale
   Stack erreichbar ist (Local-by-Flywheel + Tailscale)
5. **Diese Seite** ein zweites Mal — jetzt mit Praxis-Auge
6. **Trockenuebung** — auf einem Throwaway-Hosting (z. B. Local
   exportieren in eine Test-Subdomain) den Deploy selbst durchspielen,
   bevor du es zum ersten Mal auf der echten Live-Site machst

---

## 19. Verwandte Notizen

- [[_MOC Tutorials]] — Dach-MOC aller Tutorials
- [[WordPress Grundlagen]] — WP-Konzepte und Architektur
- [[Webentwicklung Grundlagen]] — Stack-Hintergrund Frontend/Backend
- [[Netzwerk & Sysadmin/10-remote-zugriff-local-dev]] — Local-Stack-Zugriff
- [[WordPress/04-wp-rest-api-adapter-mit-application-passwords|WP 04 — REST-API + App-Passwords]] — alternativer Inhalts-Push-Weg
- [[WordPress/10-wp-plugin-sicher-entfernen|WP 10 — Plugin sicher entfernen]] — relevant, wenn beim Deploy Plugins ausmustert werden
- [[WordPress/12-utf8-mojibake-und-trunk-ready-inventar|WP 12 — UTF-8 Mojibake]] — Reparatur, wenn Charset beim Deploy gekippt ist
- [[WordPress/01-db-cleanup-fallstricke|WP 01 — DB-Cleanup-Fallstricke]] — was bei direkten DB-Edits schiefgehen kann
- [[Sicherheit & Datenschutz Grundlagen]] — DSGVO-Pflicht bei Live-Daten

---

*Erstellt 2026-05-05 als WP-Modul 02. Anlass: Sprint nach Praxis-Webseiten-
Redesign — Dr. Stracke will den Deploy-Pfad selbst verstehen, um im
Notfall ohne Claude/Automation arbeiten zu koennen.*
