# 14 — WordPress-Plugin sicher entfernen (mit Rollback und Audit)

> **Ziel:** Ein WordPress-Plugin so aus einer Dev- oder Local-Installation entfernen, dass es reproduzierbar, rollback-fähig, regressions-frei und audit-nachvollziehbar passiert. Entstanden aus S2.0f (Session 13, 2026-04-19) — Entfernung des Santapress-Plugins aus der Local-WP-Kopie der Praxis-Webseite.

## 1. Warum nicht einfach „Plugin deinstallieren" im WP-Admin?

Wenn Sie im WP-Admin auf „Deaktivieren" und „Löschen" klicken, passieren im Hintergrund drei Dinge:

1. Das Plugin-Kürzel wird aus einer Option mit dem Namen `active_plugins` entfernt (darüber später mehr).
2. Der Plugin-Ordner wird gelöscht.
3. Eine Funktion namens `register_deactivation_hook()` wird aufgerufen, falls das Plugin eine solche registriert hat.

Das funktioniert für Gelegenheits-Nutzer. Aber für eine ernsthafte Infrastruktur-Änderung fehlen drei Dinge:

- **Kein Rollback.** Ist das Plugin gelöscht, ist es weg. Wenn Sie die alte Version im Zweifel nicht mehr laden können (Version zurückgezogen, Premium-Lizenz abgelaufen), sind Sie angeschmiert.
- **Kein Audit-Trail.** Sie wissen nachher nicht mehr, welche anderen Folgen die Deaktivierung hatte. Hat das Plugin beim Deaktivieren heimlich Daten gelöscht? Sind irgendwo Reste in der Datenbank geblieben?
- **Kein automatisierter Regressions-Test.** Hat die Entfernung eine andere Seite kaputt gemacht? Ein anderes Plugin gebrochen? Eine URL-Route verloren? Man müsste manuell klicken.

Für die **Praxis-Webseite** gilt zusätzlich: Änderungen an der Infrastruktur laufen im Architekten-Modus — mit Spec, Evidenz, Verify-Pipeline, Selbstprüfung. „Deinstallieren per Klick" passt da nicht rein.

## 2. Das 5-Schritt-Protokoll

Jede Plugin-Entfernung läuft in fünf Schritten ab. Die Reihenfolge ist nicht-optional; jede einzelne Abweichung ist bisher einmal in einen dokumentierten Fehler gewandert.

```
T1  Pre-Condition-Snapshot    →  Was ist wahr, bevor wir eingreifen?
T2  Hook-Dependency-Audit     →  Hängt etwas anderes am Plugin?
T3  Deaktivierung + Archive   →  active_plugins-Update, dann Ordner archivieren
T4  Rewrite-Rules regenerieren → WP neue URL-Routen schreiben lassen
T5  Verify-Gate                →  zwei unabhängige Tests, dann fertig
```

Jeder Schritt ist eigenständig rollback-fähig. Wenn einer schiefgeht, kann man zu jedem vorherigen Punkt zurückfallen, ohne den nächsten mitzuziehen.

## 3. T1 — Pre-Condition-Snapshot

Bevor irgendetwas verändert wird, wird der aktuelle Zustand in einer Evidenz-Datei festgehalten. Das ist die Grundlage für zwei Dinge gleichzeitig: Rollback-Fähigkeit und spätere Beweisführung („war die Anzahl Plugins vorher wirklich 26?").

Drei Snapshots sind hier sinnvoll, plus ein vierter als Paranoia-Check:

1. **`active_plugins`** — das ist eine WordPress-Option, die alle aktiven Plugins als serialisiertes PHP-Array enthält. Mehr dazu in Abschnitt 5.
2. **Rewrite-Rules-Größe** — wie viele Bytes belegt die Option `rewrite_rules`. Das ist ein indirekter Indikator, wie groß der Beitrag des zu entfernenden Plugins zu den URL-Routen ist.
3. **Plugin-Ordner-Listing** — wie viele Dateien/Unterordner hat das Plugin, wie groß ist es insgesamt. Das macht die Archivierung später überprüfbar.
4. **`wp_posts`-Count je `post_status`** — „wie viele Posts/Pages existieren, und wie sind sie verteilt". Nur als Paranoia-Check gegen Plugins, die beim Deaktivieren Daten löschen würden.

## 4. T2 — Hook-Dependency-Audit

Nun wird geprüft, ob andere Komponenten auf das zu entfernende Plugin verweisen. Drei Orte sind relevant:

```bash
grep -rli "<plugin-slug>" wp-content/plugins/ --exclude-dir="<plugin-slug>"
grep -rli "<plugin-slug>" wp-content/themes/<active-theme>/
grep -rli "<plugin-slug>" wp-content/mu-plugins/ 2>/dev/null
```

**Wichtige Regel:** Wenn irgendwo ein Treffer kommt, **stopp**. Das bedeutet, ein anderes Plugin oder das aktive Theme nutzt Funktionen des zu entfernenden Plugins. Entfernung ohne weitere Analyse würde andere Komponenten brechen.

Im Santapress-Fall war das Audit leer — 0 externe Referenzen. Santapress stand isoliert.

## 5. T3a — Das Mysterium `active_plugins`

Das hier ist der anspruchsvollste Teil. WordPress speichert die Liste der aktiven Plugins in der Datenbank, in der Tabelle `wp_options`, unter dem Namen `active_plugins`. Der Wert ist ein **PHP-Serialize-String** — kein JSON, keine komma-separierte Liste, sondern ein Format, das PHP intern für seine `serialize()`-Funktion benutzt.

So sieht das aus (gekürzt):

```
a:26:{i:0;s:40:"sitepress-multilingual-cms/sitepress.php";i:1;s:43:"all-in-one-seo-pack/...";...}
```

Das ist ein Array (`a:`) mit 26 Elementen. Jedes Element hat einen Index (`i:0`) und einen String-Wert (`s:40:"..."`). Die Zahl hinter dem `s:` ist die **Länge des Strings**. Wenn Sie einfach nur einen Eintrag löschen würden (z. B. per SQL-String-Replace), würden Sie die Zählung am Anfang (`a:26:`) und die Index-Nummerierung (`i:0`, `i:1`, ...) durcheinanderbringen. WordPress würde den Array dann als kaputt erkennen und keine Plugins mehr laden.

Die richtige Methode ist: den String aus der Datenbank lesen, in PHP deserialisieren, den Eintrag aus dem Array entfernen, das Array neu durchnummerieren, wieder serialisieren und zurückschreiben. Das geht mit einem kleinen PHP-Skript:

```php
<?php
$mysqli = new mysqli('localhost', 'root', 'root', 'local', null, $socket);
$row = $mysqli->query("SELECT option_value FROM wp_options WHERE option_name='active_plugins'")
             ->fetch_assoc();

$arr = unserialize($row['option_value']);                     // a:26:{...} → PHP-Array
$filtered = array_values(                                      // neu nummerieren
    array_filter($arr, fn($p) => stripos($p, 'santapress/') !== 0)
);
$stmt = $mysqli->prepare("UPDATE wp_options SET option_value=? WHERE option_name='active_plugins'");
$stmt->bind_param('s', serialize($filtered));                  // PHP-Array → a:25:{...}
$stmt->execute();
```

Drei technische Details, die oft falsch gemacht werden:

- **`array_values()` ist Pflicht.** Sonst hat Ihr Array nach dem `array_filter()` Löcher in der Nummerierung (`[0 => "...", 2 => "...", 3 => "..."]`). WordPress verlangt aber fortlaufende Indizes.
- **`'localhost'` als Host-Parameter, nicht `null`.** Manche PHP-Versionen interpretieren `null` als „nimm TCP zum Default-Host". Mit `'localhost'` + Socket-Argument nutzt PHP garantiert den Unix-Socket.
- **Prepared Statement statt SQL-String-Konkatenation.** Der Serialize-Wert enthält Anführungszeichen. Ohne Escape bricht SQL. `bind_param()` löst das sauber.

## 6. T3b — Deaktivieren VOR Archivieren

Nachdem `active_plugins` aktualisiert ist, wird der Plugin-Ordner verschoben:

```bash
mv wp-content/plugins/santapress  _archive/santapress-2026-04-19/
```

**Die Reihenfolge ist nicht-optional.** Wenn Sie den Ordner zuerst verschieben und `active_plugins` noch auf den Ordner zeigt, dann passiert Folgendes: WordPress versucht bei jedem Seitenaufruf das Plugin zu laden, findet den Ordner nicht, wirft einen PHP-Warning. Der Warning steht dann in Ihren Apache-Logs und möglicherweise auch in HTTP-Response-Bodies. Das verschmutzt alle nachfolgenden Verify-Checks und macht die Fehlersuche schwerer.

Die richtige Reihenfolge stellt sicher, dass WordPress zu jedem Zeitpunkt einen konsistenten Zustand sieht:

- **Zustand vorher:** Plugin in `active_plugins`, Ordner existiert → WordPress lädt Plugin.
- **Zwischenzustand (wenige ms):** Plugin nicht in `active_plugins`, Ordner existiert noch → WordPress ignoriert Plugin, weil nicht aktiv.
- **Zustand nachher:** Plugin nicht in `active_plugins`, Ordner fehlt → unverändert: WordPress ignoriert.

Kein Zeitpunkt, zu dem WordPress eine kaputte Konfiguration sieht.

## 7. Archive + Verfallsdatum — ein Governance-Pattern

Statt das Plugin einfach zu löschen, wird es in einen `_archive/`-Ordner verschoben. Das kostet Speicherplatz, bringt aber zwei Vorteile:

- **Rollback in einer Sekunde.** Wenn in zwei Tagen auffällt, dass doch etwas am Plugin hing, kann es mit einem `mv` zurückgeschoben und reaktiviert werden. Ohne Archive müsste man die passende Version neu herunterladen — was bei Legacy-Plugins manchmal nicht mehr möglich ist.
- **Audit-Nachvollziehbarkeit.** Die archivierte Version ist der Zustand zur Zeit der Entfernung. Wenn später Fragen auftauchen („war Feature X drin?"), kann man die Original-Datei nachschauen.

Damit aus dem Archive nicht ein dauerhaftes Wildwuchs-Verzeichnis wird, wird **beim Anlegen** ein Verfallsdatum festgelegt:

```markdown
# Archive — <Plugin> (Local-WP)
- Archiviert:     2026-04-19
- Verfallsdatum:  2026-05-19 (30 Tage)
- Löschung:       separate Session nach Verfallsdatum
```

Nach 30 Tagen wird in einer eigenen, kleinen Session entschieden: Wurde Plugin vermisst? Wenn nein → löschen. Wenn ja → reaktivieren und das Archive behalten.

Das ist ein **Governance-Pattern**, kein technisches: Ein Datum zwingt zur bewussten Entscheidung, statt die Archivierung in Vergessenheit geraten zu lassen.

**Hinweis zum Git:** Das Archive selbst gehört nicht ins Repository. Es enthält Binaries (bei Santapress 21 MB), und es ist reversibel über den bloßen Dateisystem-Umzug. In der `.gitignore` wird `_archive/` deshalb ausgeschlossen. Die README mit dem Verfallsdatum lebt nur lokal im Archive-Ordner. Die wichtigen Metadaten (wer hat archiviert, warum, wann löschen) stehen ohnehin in der Spec und im Self-Check, die sehr wohl versioniert sind.

## 8. T4 — Rewrite-Rules regenerieren

WordPress speichert alle registrierten URL-Routen in einer Option namens `rewrite_rules`. Plugins können beim Aktivieren eigene Rewrite-Rules hinzufügen (`/events/`, `/?shop_page=...`, solche Dinge). Wenn das Plugin weg ist, bleiben die Rules aber in der DB stehen.

Die sauberste Methode ist, die Option zu löschen und WordPress beim nächsten Request neu generieren zu lassen:

```bash
# Rules löschen
mysql ... -e "DELETE FROM wp_options WHERE option_name='rewrite_rules';"

# WordPress regeneriert bei Request — 2× aufrufen, damit Rules geschrieben sind
curl -sk "$BASE_URL/" > /dev/null
curl -sk "$BASE_URL/" > /dev/null
```

Das Delta der Rules-Größe ist ein schönes Signal: Wenn `rewrite_rules` vorher 13085 Bytes groß war und nachher 10979 Bytes, dann haben sich 2106 Bytes „verloren" — das waren die Santapress-Routen. Ein **indirekter Beweis**, dass die Entfernung tatsächlich gewirkt hat.

Bei manchen Plugins ist das Delta Null — die haben keine eigenen Routen registriert. Das ist in Ordnung, solange es im Self-Check erklärt wird.

## 9. T5 — Zwei Verify-Dimensionen, zwei Tools

Nach der Entfernung muss geprüft werden, ob die Site noch funktioniert. Das passiert über zwei unabhängige Tools:

**Dimension 1 — Code-/Design-Korrektheit:** Das bestehende `tools/verify.sh`. Es prüft, ob Computed Styles stimmen, ob Layouts nicht kippen, ob Split-Checks passen. Deterministisch, offline, unabhängig vom Plugin-Thema. Wenn verify.sh nach der Plugin-Entfernung rot wird, hat die Entfernung das Theme oder die CSS-Kaskade angegriffen.

**Dimension 2 — Request-Pfad-Verfügbarkeit:** Ein neues Script `tools/smoke-http.sh`, das eine Reihe wichtiger URLs per `curl` anfragt und prüft, ob sie antworten. Die Fail-Regel ist bewusst **schwach**: nur HTTP-5xx-Codes gelten als Fail. 404 und 403 sind OK (vielleicht ist die Seite noch nicht gebaut, vielleicht ist sie passwortgeschützt). 5xx dagegen bedeutet: WordPress wirft einen PHP-Fatal-Error — das ist das echte Signal einer fehlenden Plugin-Abhängigkeit.

```bash
for path in "/" "/karriere/" "/wp-login.php" "/feed/" "/?s=test"; do
  code=$(curl -sk -o /dev/null -w "%{http_code}" "$BASE_URL$path")
  [[ "$code" =~ ^5 ]] && FAIL=1
done
```

Wichtig: **`smoke-http.sh` bleibt ein eigenes Tool**, wird nicht in `verify.sh` integriert. Der Grund steht in Tutorial 13: Code-Korrektheit und Request-Verfügbarkeit sind zwei unterschiedliche Dimensionen. Wenn das Netzwerk wackelt, darf der Code-Smoke nicht mit rot werden.

## 10. Der wp_posts-Paranoia-Check

Der vierte Snapshot aus T1 — der `wp_posts`-Count je `post_status` — wird nachher wiederholt. Die beiden Zahlen müssen identisch sein.

```
                 vor    nach   delta
auto-draft         2       2      0
draft              4       4      0
inherit         2206    2206      0
private          260     260      0
publish          382     382      0
trash              6       6      0
```

Warum? Weil es Plugins gibt, die beim Deaktivieren Daten löschen. Unverhofft, ohne Nachfrage, als `register_deactivation_hook`. Wenn nach der Entfernung die Post-Counts anders aussehen, wurde Inhalt bewegt — und das muss dokumentiert werden, bevor man die Session schließt.

Im Santapress-Fall waren die Zahlen identisch. Die Paranoia war unbegründet, aber das war nicht vorhersehbar — der Check kostet 50 Millisekunden und liefert starke Evidenz.

## 11. Wann greift dieses Protokoll nicht?

Es gibt Grenzen. Das Protokoll ist nicht zuständig für:

- **Plugins mit zerstörerischer `deactivation_hook`-Logik.** Wenn ein Plugin beim Deaktivieren Datenbank-Tabellen droppt oder externe APIs aufruft (Lizenzen zurückgeben, Verbindungen trennen), reicht der Paranoia-Check nicht. In diesem Fall ist vor T1 ein `grep -rn "register_deactivation_hook" <plugin>/` Pflicht, und die gefundene Funktion wird manuell gelesen.
- **Plugins mit Custom Post Types oder Options.** Wenn das Plugin eigene Tabellen oder Options in der DB angelegt hat, bleiben diese nach der Entfernung zurück. Sie sind dann nicht mehr bedient, liegen aber als „Zombie-Daten" herum. Das ist ein separater T6 Data-Cleanup, nicht Teil dieser Entfernung.
- **Produktions-Systeme.** Das hier gilt ausschließlich für Local-/Dev-WordPress. Bei Prod-Systemen kommen Backup-, Staging-, Wartungsfenster-Konzepte dazu, die den Rahmen dieses Tutorials sprengen.

## 12. Zusammenfassung

Eine saubere Plugin-Entfernung ist kein Ein-Klick-Vorgang, sondern ein fünfstufiges Protokoll mit eingebauter Rollback-Fähigkeit und doppelter Verify-Dimension. Die Reihenfolge ist strikt: erst Snapshot, dann Audit, dann Deaktivierung (mit `active_plugins` vor Ordner-mv), dann Rewrite-Rules-Regenerierung, dann Verify.

Zwei Techniken stehen im Zentrum:

- **PHP-Serialize-Array bearbeiten** — nie per SQL-String-Replace, immer via unserialize → filter → reserialize.
- **Archive statt Löschen, mit Verfallsdatum** — reversibel für 30 Tage, danach bewusste Entscheidung.

Das Ergebnis ist eine Plugin-Entfernung, die man in drei Monaten noch nachvollziehen und gegebenenfalls rückgängig machen kann — ohne auf sein Erinnerungsvermögen angewiesen zu sein.

---

## Siehe auch

- Tutorial 12 — CSS-Spezifität & Komponenten-Schichten
- Tutorial 13 — Verify-Probe-Architektur & WordPress-Rewrite-Rule-Grenze
- Pattern `Nexus/_memory/patterns/wp-plugin-safe-removal.md` — Code-Form des Protokolls
- Pattern `Nexus/_memory/patterns/local-wp-mysql-socket.md` — MySQL-Zugriff auf Local-by-Flywheel
- Spec `Cortex-Web/sites/praxis-webseite/specs/sprint-2/S2.0f_santapress-removal.md` — konkreter Anwendungsfall
