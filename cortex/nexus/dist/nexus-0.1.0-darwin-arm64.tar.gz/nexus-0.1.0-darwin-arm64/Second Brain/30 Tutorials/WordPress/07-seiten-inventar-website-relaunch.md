# 10 — Seiten-Inventar für Website-Relaunch

> Angelegt: 2026-04-19 (nach Praxis-Sprint 2 / S2.1)
> Hierarchie: `Second Brain/30 Tutorials/Webentwicklung/Webdesign/`
> Pattern: `Nexus/_memory/patterns/page-inventory.md`

## Was ist ein Seiten-Inventar?

Ein Seiten-Inventar ist **eine Liste aller Seiten, die Ihre neue Website
haben wird** — mit Priorität, Template-Typ und Hinweis, woher der Inhalt
kommt. Es ist die erste und wichtigste Entscheidungsdatei, bevor man
auch nur eine Zeile Template-Code oder Content schreibt.

Man denkt bei „Website" gern zuerst an Design und Texte. Das ist ein Fehler.
Die Frage, die zuerst beantwortet gehört, ist viel langweiliger: **Welche
Seiten enthält die Website überhaupt, und was ist davon Go-Live-kritisch?**

Das Inventar beantwortet genau diese Frage — strukturiert, git-versioniert,
diffbar zwischen Sessions. Es ist kein Design-Dokument und kein
Content-Dokument. Es ist eine **Scope-Entscheidung**.

## Warum ist das wichtig?

Ohne Inventar passieren im Relaunch-Projekt drei Dinge, die in echten
Projekten wiederkehren:

1. **Vergessene Go-Live-Blocker.** Impressum, Datenschutz, 404-Fallback —
   banale Seiten, die vor dem Go-Live rechtlich oder technisch vorhanden
   sein müssen, fallen hinten runter, weil niemand sie in einen Sprint
   geschrieben hat. Das wird an dem Tag bemerkt, an dem die Seite live
   gehen soll.

2. **Inkonsistente Templates.** Wenn die Arzt-Seiten nacheinander gebaut
   werden und niemand eine Häufigkeitsliste hat, bekommt Dr. Barcsay ein
   anderes Layout als Dr. Shahin, weil zwischen den beiden jemand die
   Template-Entscheidung stillschweigend revidiert hat.

3. **Architektur-Drift.** Die Produktiv-Site hat eine andere Content-
   Struktur (z. B. „Check-ups" als Hauptkategorie), die neue soll eine
   andere haben (z. B. „Fachrichtungen"). Ohne expliziten Hinweis im
   Inventar passiert es garantiert, dass im Content-Sprint jemand „mal
   schnell nachschaut, was auf der alten Seite steht" und die
   Architektur-Entscheidung unbemerkt rückgängig macht.

Das Inventar verhindert alle drei, weil es die Entscheidungen schriftlich,
mit Priorität, und mit sichtbarer Kennzeichnung der Architektur-Unterschiede
auf der jeweiligen Zeile festhält.

## Aufbau des Inventars

Eine einzige Markdown-Datei, eine einzige Tabelle. Pro Seite eine Zeile.
Die Pflicht-Spalten (in dieser Reihenfolge):

| Spalte | Was gehört rein? | Beispiel |
|--------|------------------|----------|
| `#` | Laufende Nummer | `5` |
| `slug` | Die URL-Endung der neuen Seite | `kontakt` |
| `titel_de` | So steht es später in der Navigation | `Kontakt` |
| `url_prod` | Die aktuelle URL auf der Live-Seite oder `—` wenn neu | `/kontakt/` |
| `template_typ` | Welche Art von Seite (z. B. `standard`, `arzt`, `fachrichtung`) | `kontakt` |
| `content_quelle` | `prod-seo` (Prod-Text übernehmen + SEO-optimieren), `neu` (komplett neu schreiben) oder `legal-extern` (Anwalt/Generator) | `prod-seo` |
| `prio` | `P0` (MUSS vor Go-Live), `P1` (SOLL, Platzhalter-Fallback) oder `P2` (kann nachgezogen werden) | `P0` |
| `status` | `todo` / `spec` / `impl` / `done` | `todo` |
| `anmerkungen` | Alle offenen Fragen zu dieser einen Seite | `Doctolib-Einbettung offen, siehe Folgeentscheidung Nr. 3` |

Die ersten acht Spalten sind **pflichtbefüllt**. Leere Felder blockieren
den Self-Check. Das ist keine Bürokratie — eine Seite ohne Priorität ist
eine Seite, bei der im Sprint-Endspurt jemand improvisieren muss.

## Die drei Prioritäts-Stufen im Klartext

- **P0 (Go-Live-Blocker):** Ohne diese Seite kann die neue Website NICHT
  online gehen. Rechtlich (Impressum, Datenschutz), technisch (404,
  Startseite) oder inhaltlich (Kontakt, Sprechstunden). In der Praxis:
  Home, Praxis, Team, Sprechstunden, Kontakt, Datenschutz, Impressum,
  404, Fachrichtungen-Landing, Karriere. Das sind in einer Arztpraxis-
  Webseite typischerweise **10 Seiten**.

- **P1 (SOLL, mit Fallback):** Diese Seiten sollen zum Go-Live da sein,
  dürfen aber im Notfall mit einem Platzhalter (Foto, Stub-Text) live
  gehen. Einzel-Arzt-Profile mit Platzhalter-Foto sind P1 — der Arzt
  arbeitet schon, die Biografie kommt zwei Wochen später nach.

- **P2 (nach Go-Live):** Kann in den Wochen nach Go-Live nachgezogen
  werden, ohne dass die Seite dadurch unprofessionell wirkt oder
  Rechtsrisiken entstehen.

Die Faustregel: **Wenn eine Seite fehlt und ein Besucher oder ein Anwalt
deswegen die Seite verlässt / abmahnt, ist es P0.** Sonst P1.

## Was das Inventar NICHT ist

Ein Inventar ist nicht:

- Ein Content-Dokument. Keine Texte werden im Inventar-Sprint geschrieben.
- Ein Design-Dokument. Keine Farben, Fonts oder Layouts.
- Ein Template-Dokument. Keine PHP-Dateien, keine Liquid-Sections.
- Ein SEO-Dokument. Meta-Titles und Keywords kommen im Content-Sprint.
- Ein Crawl-Ergebnis. Man lädt die Sitemap, aber man lädt keine Seiten.

Das Inventar ist **nur** die Frage „Welche Seiten, in welcher Reihenfolge,
aus welcher Quelle?" beantwortet.

## Die wichtigste Quelle: Sitemap.xml

Jede WordPress-Site mit einem halbwegs modernen SEO-Plugin (All in One SEO,
Yoast, Rank Math) exponiert eine Sitemap unter `/sitemap.xml`. Sie
enthält eine Liste aller veröffentlichten Seiten, aber KEINEN Content.
Das passt perfekt zum Inventar-Sprint-Scope.

Die Sitemap sagt Ihnen drei Dinge:

1. **Welche Seiten gibt es aktuell live?** Für jede Inventar-Zeile kann
   eine Prod-URL eingetragen werden (oder `—` bei neuen Seiten).
2. **Architektur-Unterschied sichtbar.** Wenn Ihre Prod-Site 12
   Diagnostik-Seiten hat und keine Fachrichtungs-Seiten, zeigt das die
   Sitemap sofort. Im Inventar wird das als Hinweis auf der
   Fachrichtungen-Landing-Zeile festgehalten.
3. **Legacy-Volumen abschätzen.** Wenn die Prod-Sitemap 180 Seiten
   listet und das neue Inventar nur 27, wissen Sie, dass 150+ Seiten in
   einem späteren „Legacy-Migration"-Sprint landen müssen.

**Wichtig:** Nur die URL-Liste lesen, nicht die einzelnen Seiten
herunterladen. Letzteres ist der Content-Sprint, nicht der Inventar-Sprint.

## Ableitungen: Das Inventar ist mehr als eine Tabelle

Ein gut gebautes Inventar enthält nicht nur die Seiten-Tabelle, sondern
am Ende **vier Ableitungs-Abschnitte**, die den nächsten Sprints die
Phase-1-Arbeit sparen:

### Template-Häufigkeits-Tabelle

Aus der Spalte `template_typ` eine Aggregation bauen: „8× `fachrichtung`,
8× `arzt`, 4× `standard`, je 1× `homepage/kontakt/sprechstunden/team/
fachrichtung-landing/karriere/404`". Das ist die Eingabe für den
Template-Sprint — man weiß, welche Template-Dateien man anlegen muss
und wie oft sie vorkommen.

### Batch-Vorschlag

Die Content-Arbeit wird in Batches organisiert (typisch 2–4 Seiten pro
Batch). Aus dem Inventar lässt sich ein Batch-Vorschlag ableiten, der
nach Priorität gruppiert: „Batch A = Datenschutz + Impressum (P0, blockt
durch Rechtssicherheitsfrage)" usw. Der Content-Sprint übernimmt
diese Reihenfolge oder korrigiert sie — aber er startet nicht bei null.

### Menü-Skizze

Die Top-Level-Navigation einer Website spiegelt typischerweise die
P0-Kernseiten. Die Einzelseiten darunter (Arzt-Profile, einzelne
Fachrichtungen) gehören in Submenüs. Eine grobe Menü-Skizze am Ende
des Inventars ist die Eingabe für den Menü-Sprint.

### QA-Pflichtliste

Die P0-Zeilen mit Status `done` sind das Go-Live-Gate. Vor dem Go-Live
zählt man durch: Sind alle P0-Zeilen auf `done`? Wenn nicht, kein Go-Live.
Diese Liste ist die Eingabe für den QA-Sprint.

## Typische Fallen

- **Copy-Paste aus der Sitemap.** Nicht jede Seite, die es in der
  Prod-Sitemap gibt, gehört in die neue Site. „Corona-Risikofragebogen"
  aus 2020 ist kein Kandidat für die neue Homepage.

- **Zielzahl als Pflicht.** Wenn Ihre Spec sagt „ca. 27 Zeilen" und
  Sie realistisch nur 23 haben, nehmen Sie 23. Füll-Seiten verwässern
  das Inventar.

- **TBD-Zeilen ohne Flag.** Wenn ein Arzt-Name noch nicht bekannt ist,
  gehört die Zeile trotzdem ins Inventar — aber mit `anmerkungen:
  "Name von Dr. Stracke zu bestätigen"`. So bleibt die Liste
  vollständig und der offene Punkt ist dokumentiert.

- **Architektur-Abweichung nur in der Spec.** Wenn Prod und Neu
  unterschiedliche Content-Architekturen haben, schreibt man das auf
  die betroffene Inventar-Zeile, nicht nur in die Spec. Sonst wird
  es im Content-Sprint übersehen.

- **Inventar ohne Regressions-Schutz.** Auch ein reines Docs-Inventar
  muss `tools/verify.sh` am Ende grün laufen lassen. Wenn man
  versehentlich doch etwas am Theme angefasst hat, sieht man das
  sonst erst zwei Sprints später.

## Wann man ein Inventar anlegt

- Bei jedem Website-Relaunch (neue Domain, neues CMS, neues Theme).
- Bei jeder Content-Migration ≥ 10 Seiten.
- Bei jeder Restrukturierung der Haupt-Navigation.
- NICHT bei Einzel-Seiten-Änderungen oder Sprint-1-Mikro-Scopes.

In der Praxis: immer, wenn man beim Planen merkt, dass „die Liste im Kopf"
unübersichtlich wird. Die Schwelle liegt bei etwa 10 Seiten.

## Anwendung im Praxis-Projekt

Das Praxis-Sprint-2-Inventar liegt unter
`projects/Cortex-Web/sites/praxis-webseite/specs/sprint-2/page-inventory.md`.
Es enthält 27 Zeilen: 8 Kernseiten, 9 Fachrichtungen, 9 Ärzte, 1 Karriere.
10× P0, 17× P1, 0× P2.

Die Spec zum Inventar liegt daneben (`S2.1_page-inventory.md`) und die
Selbstprüfung (`evidence/2026-04-19_s2.1_self-check.md`) beweist mit
8/8 Akzeptanzkriterien, dass das Inventar vollständig und widerspruchsfrei
ist.

Der nächste Sprint (S2.2 Template-Typologie) oder alternativ S2.3 Batch A
(Datenschutz + Impressum, sobald die Rechtssicherheitsquelle entschieden
ist) greift auf das Inventar zu.

## Weiterführend

- **Pattern (technisch, für Claude wiederverwendbar):**
  `Nexus/_memory/patterns/page-inventory.md` (7-Schritte-Ablauf,
  Lessons S2.1-LL-1…5).
- **Verwandtes Tutorial (Template-Typologie):** `02-git-bootstrap-und-page-registry.md`
  (Page-Registry-Vertrag, PXZ_VERSION-Policy).
- **Verwandtes Tutorial (Design-Grundlage):** `05-design-tokens-und-cascade.md`
  und `09-vier-schichten-design-tokens.md`.
