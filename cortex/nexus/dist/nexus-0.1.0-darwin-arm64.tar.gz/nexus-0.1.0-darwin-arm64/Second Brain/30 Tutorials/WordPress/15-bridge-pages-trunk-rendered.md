# 19 — Bridge-Pages: WP-Pages aus dem Common-Trunk rendern lassen

> Aus S2.3-checkups (Cortex-Web Praxis-Sprint 2, Session 18, 2026-04-22).
> Erstmals produktiv: `/basic-check/` — eine Praxis-WP-Page, deren Body-Content
> NICHT in WordPress lebt, sondern aus einer YAML-Datei im Cortex-Web-Trunk
> kommt und vom WP-Adapter gerendert wird.

---

## Worum geht's

Im Cortex-Web-Ökosystem teilen sich zwei rechtlich getrennte Sites
(Praxiszentrum WordPress + Juvantis Shopify) eine **Substanz-Schicht** —
den „Common Trunk". Produkte wie der Bluttest „Basic-Check" existieren
**genau einmal** als YAML-Datei (`trunk/content/products/bluttests/basic-check.yaml`)
und werden je nach Site-Kontext anders gerendert:

- Auf Juvantis (Shopify) als kaufbare Produkt-Karte mit Preis und Buchungs-CTA.
- Auf der Praxis-Site (WP) als HWG-konforme Info-Page **ohne** Preis, mit
  Verweis „Mehr erfahren auf sanexio.eu".

Damit das funktioniert, gibt es einen **WP-Adapter**, der die YAML liest,
gegen das Schema validiert, die `views.praxis`-Sicht rendert und das Ergebnis
per WP-REST-API in die Praxis-Site schreibt.

Eine Page, die so funktioniert, nennen wir **Bridge-Page**.

---

## Architektur

```
trunk/content/products/bluttests/basic-check.yaml   (Common Trunk, Single Source of Truth)
        │
        │  bash tools/sync-wp.sh
        ▼
adapters/wordpress/build.mjs        (validiert + rendert views.praxis)
        │
        ▼
adapters/wordpress/content-to-wp-pages.mjs   (REST POST/PUT)
        │
        ▼
WP-Page 9668 /basic-check/
        │
        ▼
template-bridge-product.php
        ├── Hero (Theme-eigen, aus pxz_bridge_*-Meta)
        ├── the_content() ← Body kommt aus dem Trunk
        └── pxz_cross_brand_cta() (Theme-eigen, Cross-Brand-Card)
```

---

## Was lernen wir daraus

### 1. Trennung Body ↔ Frame ist die ganze Idee

- **Body (post_content + Title + Excerpt)** = Adapter-owned. Kommt aus YAML.
  Wer im WP-Admin den Body ändert, riskiert dass der nächste Adapter-Lauf
  die Änderung verwirft — das ist gewollt (CW-001 Trunk-Master-Vertrag).

- **Frame (Hero, Layout, Cross-Brand-CTA, Footer)** = Theme-owned. Lebt im
  Bridge-Template, kennt nicht die YAML.

Diese Trennung wird durch das Migration-Skript erzwungen: für die Bridge-Page
setzt das Skript NUR das Template-Meta + die Hero-Meta, NICHT Title oder
Content. Dadurch entstehen keine Race-Conditions zwischen Skript und Adapter.

### 2. Cross-Brand-CTA als wiederverwendbarer Helper

Statt jedem Bridge-Template einen hardcoded „Mehr auf sanexio.eu"-Block
einzubauen, gibt es einen Registry-Helper:

```php
pxz_cross_brand_cta( 'sanexio', 'basic-check', 'card' );
pxz_cross_brand_cta( 'sanexio', 'basic-check', 'inline' );
```

Die Daten leben in `inc/cross-brand-cta.php` als Registry. Neuer Partner
oder neues Produkt = ein Eintrag mehr. Brand-Disclaimer („eigenständiges
Unternehmen") ist im Pattern verankert, kann nicht vergessen werden.

### 3. Adapter-Output muss vom Theme „gezähmt" werden

Der WP-Adapter emittiert default Gutenberg-Buttons (`<!-- wp:buttons -->`).
Die sehen für eine Bridge-Page hässlich aus. Lösung: CSS, das den Default
verbirgt zugunsten der reicheren xbrand-Card:

```css
.pxz-bridge-content-inner .wp-block-buttons {
  display: none;
}
```

Vorteil: keine Anpassung am Adapter (er bleibt platform-agnostisch), das
Theme entscheidet, wie der Adapter-Output sich präsentiert.

### 4. Roundtrip beweist CW-001 jedes Mal

Adapter-Lauf:

```bash
bash tools/sync-wp.sh trunk/content/products/bluttests/basic-check.yaml
```

Output:

```json
{
  "action": "update",
  "id": 9668,
  "slug": "basic-check",
  "status": "publish"
}
```

`"action": "update"` (statt `"create"`) bedeutet: der Adapter hat die Page
gefunden und überschrieben. Wenn jemand zwischen zwei Adapter-Läufen den
Body manuell ändern würde, wäre die Änderung beim nächsten Lauf weg —
und zwar still. Das ist beabsichtigt: der Trunk ist die einzige Wahrheit.

### 5. MD5-Disziplin: CSS-Audit als Beweis

Beim Sprint-Ende prüfen wir: hat der Sprint Home + Karriere unbeabsichtigt
verändert? Naive Methode: Hash der Page vor/nach. Problem: Karriere hat
ein WPForms-Formular mit pro-Request-Nonce → Hash driftet ohnehin.

Saubere Methode bei DRIFT-Risiko: **CSS-Audit + Negative-Probe**.

```bash
# CSS-Audit: welche Stylesheets sind geladen?
curl -sk "$URL" | grep -oE 'pxz-[a-z-]+-css' | sort -u
# Erwartung Karriere: pxz-components-css, pxz-karriere-css, pxz-nav-css, pxz-tokens-css

# Negative-Probe: sind neue Sprint-Klassen sichtbar?
curl -sk "$URL" | grep -c 'pxz-checkup-hub'   # Erwartung 0
```

Wenn die Enqueue-Liste identisch zur Baseline ist UND die Negative-Probe
0 Hits zeigt, ist die Page strukturell unverändert. Auch dann, wenn der
Hash driftet.

### 6. Wann eignet sich eine Bridge-Page

✓ Strukturierte Daten (Tabelle, Liste, kurze Beschreibung).
✓ Cross-Brand- oder Cross-Site-Kontext (zwei Markenidentitäten).
✓ Stabile Schema-Form (Felder ändern sich selten).

✗ Komplexe redaktionelle Texte (besser klassisch in WP pflegen).
✗ Pages mit Plugins, die `the_content()`-Filter brauchen (Forms, Sliders).
✗ Pages mit häufigen Ad-hoc-Änderungen aus dem Marketing.

---

## Praxisbeispiel: Wie Sie selbst eine zweite Bridge-Page bauen würden

Angenommen, in einem späteren Sprint kommt ein zweites Bluttest-Produkt
„Cardio-Check Plus" hinzu, das ebenfalls auf Juvantis kaufbar und auf der
Praxis-Site informativ verfügbar sein soll.

**Schritt 1:** Trunk-YAML anlegen
`trunk/content/products/bluttests/cardio-check-plus.yaml` analog zu basic-check.

**Schritt 2:** Schema-Validation
`bash tools/validate.sh` muss grün sein.

**Schritt 3:** Cross-Brand-Registry erweitern (`inc/cross-brand-cta.php`):

```php
'cardio-check-plus' => [
    'brand_name'    => 'Sanexio',
    'partner_label' => 'Partnerangebot · Sanexio GmbH',
    'logo'          => 'assets/logo-sanexio.svg',
    'headline'      => 'Cardio-Check Plus direkt online',
    'text'          => '...',
    'cta_label'     => 'Mehr erfahren auf sanexio.eu',
    'url'           => 'https://sanexio.eu/products/cardio-check-plus',
    'disclaimer'    => 'Hinweis: Sanexio ist ein eigenständiges Unternehmen ...',
    'inline_prefix' => 'Selbstzahler-Alternative ohne Praxistermin:',
    'inline_link'   => 'Sanexio Cardio-Check Plus',
],
```

**Schritt 4:** WP-Page anlegen (z. B. via mysqli-Migration, idempotent)
`/cardio-check-plus/`, Template = `template-bridge-product.php`, Hero-Meta gesetzt.

**Schritt 5:** Adapter laufen lassen
`bash tools/sync-wp.sh trunk/content/products/bluttests/cardio-check-plus.yaml`.

Fertig. Eine neue Bridge-Page in 5 Schritten, ohne neues Template, ohne
neuen Renderer.

---

## Fallstricke

- **Page muss vorab existieren.** Der Adapter erkennt die Page über den
  Slug (`product.id` aus YAML). Wenn die Page noch nicht da ist, legt der
  Adapter sie mit `_wp_page_template = ""` an — dann fehlt das Bridge-Layout.
  Lösung: erst Page-Hülle via Migration anlegen (Template-Meta gesetzt),
  dann Adapter laufen lassen.

- **Im WP-Admin direkt editieren ist falsch.** Wer den Body im Backend
  bearbeitet, wundert sich, wenn die Änderung beim nächsten Sync weg ist.
  Lösung: Änderung in der YAML, Sync laufen lassen.

- **Plugin-Cache.** Wenn Caching-Plugins aktiv sind, kann eine sofort
  sichtbare Adapter-Änderung wie ein Bug aussehen. Cache flushen / hard
  reload (Cmd+Shift+R) bringt Klarheit.

---

## Quellen

- Spec: `Cortex-Web/sites/praxis-webseite/specs/sprint-2/S2.3-checkups.md`
- Self-Check: `Cortex-Web/sites/praxis-webseite/specs/sprint-2/evidence/2026-04-22_s2.3-checkups/self-check.md`
- Pattern: `Nexus/_memory/patterns/wp-bridge-page-trunk-renderer.md`
- Pattern: `Nexus/_memory/patterns/wp-cross-brand-cta-registry.md`
- Pattern (erweitert): `Nexus/_memory/patterns/md5-null-delta-version-normalization.md`
- Theme-Implementierung: `praxiszentrum/template-bridge-product.php`,
  `assets/css/bridge-product.css`, `inc/cross-brand-cta.php`,
  `assets/css/cross-brand-cta.css`
- Vorbedingung: Tutorial 06 (WP REST API Adapter mit Application Passwords)
  + Tutorial 07 (Review-Pipeline + Local-WP-Tests)
