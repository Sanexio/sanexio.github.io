# Tutorial 17 — Content-Archive vor Kuration + MD5-Integritäts-Contract

> **Herkunft:** S2.3-D Phase 2 (Cortex-Web / praxis-webseite, Session 16, 2026-04-20).
> **Patterns:** `Nexus/_memory/patterns/content-archive-pre-curation.md` + `yaml-front-matter-md5-contract.md`.

---

## Worum geht es?

Eine Website-Migration lebt von vielen kleinen Schritten: eine Seite nach der anderen wird neu geschrieben, mit Echt-Content versehen, ihrem neuen Template angepasst. Dabei passiert ein unterschätzter Fehler: **Inhalte verschwinden unbemerkt.** Ein Absatz, eine seltene Leistung, ein Honorar-Hinweis — übersehen, überschrieben, weg.

Dieses Tutorial zeigt, wie man das **architektonisch ausschließt**, nicht organisatorisch. Nicht durch Disziplin, sondern durch einen Mechanismus, der sich nicht „vergessen" lässt.

Das Thema hat zwei Ebenen:

1. **Content-Archive vor Kuration** — das Organisations-Prinzip („vorher sichern, dann transformieren").
2. **MD5-Integritäts-Contract** — das technische Mittel, um sicherzustellen, dass die Sicherung nicht leise verfälscht wird.

---

## Teil 1 — Das Prinzip „Separat-Sichern vor Transformieren"

### Klassische Situation

Ihre Prod-Website hat 55 relevante Seiten. Sie starten den Relaunch in einer lokalen WordPress-Umgebung. Cluster für Cluster werden die Seiten neu gestaltet. Am Ende geht die neue Site live.

In diesem Ablauf gibt es einen einzigen Ort, an dem der Original-Text lebt: in der WordPress-Datenbank — und zwar genau **so lange**, bis Sie ihn überschreiben. Nach dem Überschreiben ist er weg (bis auf DB-Backups, die aber schwer zu durchsuchen sind).

### Die Umkehrung

**Bevor Cluster 1 beginnt,** wird jede einzelne Seite einmalig als Datei im Git-Repo abgelegt — als „Aktenschrank". Erst dann wird kuriert.

**Effekt:**

| Vor der Kuration | Nach der Kuration |
|---|---|
| Archive-Datei: Original-Inhalt | Archive-Datei: Original-Inhalt (unverändert) |
| DB: Original-Inhalt | DB: neuer Inhalt |

**Resultat:** Ein `git diff` zwischen Archive und aktueller DB-Fassung zeigt jede ausgelassene oder veränderte Textstelle sofort. Kein Gedächtnis nötig.

### Archive-Hierarchie als Planungs-Artefakt

Die Dateien werden **nicht flach** abgelegt, sondern thematisch:

```
_content-archive/
├── kern/de/           (7 Seiten — P0, Patientenreise-Zentrum)
├── checkups/de/       (6 Seiten — P0, Vorsorge-Angebote)
├── services/de/       (4 Seiten — P1)
├── diagnostik/de/     (10 Seiten — P1)
├── aerzte/de/         (2 Seiten)
├── fachrichtung/de/   (1 Seite)
├── legacy/de/         (~23 Seiten — Alt-Content, teils Löschkandidaten)
├── i18n-dublette/     (EN/FR/ES — meist überflüssig)
└── _status/           (draft + private)
```

Der Ordner-Baum **ist zugleich** der Sprint-Plan: `ls kern/de/` zeigt, was in der nächsten Kurations-Session ansteht. Die Entscheidungs-Last, „was kommt als nächstes", ist damit ohne Nachdenken beantwortbar.

---

## Teil 2 — Der MD5-Integritäts-Contract

Archive-Dateien sind nur so verlässlich wie ihre Integrität. Ein Archiv, dessen Inhalt unbemerkt verändert werden kann, ist kein Archiv.

### Das Problem

Stellen Sie sich vor, jemand öffnet versehentlich eine Archive-Datei im Editor und korrigiert einen Tippfehler im Archive-Body. Sichtbar ist nichts: die Datei „sieht richtig aus". Erst im Vergleich mit der DB würde auffallen, dass sie nicht mehr identisch ist. Aber niemand vergleicht routinemäßig.

Oder: der Import-Lauf produziert versehentlich eine halbe Datei (Schreibvorgang abgebrochen). Wieder: kein Warnsignal beim flüchtigen Blick.

### Die Lösung: drei Hashes, die zwangsweise übereinstimmen müssen

Jede Archive-Datei enthält an einer festen Stelle im Kopfbereich den MD5-Hash ihres Inhalts. Dieser Hash hat **drei Verwendungen**, die alle übereinstimmen müssen:

```
   1                           2                              3
┌──────────────────┐    ┌──────────────────────┐    ┌───────────────────┐
│  Body der Datei  │ == │ content_md5 im Front-│ == │  MD5 aus der DB   │
│  (roh geparst)   │    │ Matter (steht oben)  │    │  (SELECT MD5(…))  │
└──────────────────┘    └──────────────────────┘    └───────────────────┘
```

Wenn eine der drei Seiten abweicht, ist die Datei kompromittiert. Ein Verifier-Skript rechnet es sekundenschnell für alle Dateien nach.

### Dateiformat

```markdown
---
id: 9671
slug: "praxis"
title: "Unsere Praxis"
status: "publish"
cluster: "kern"
priority: "P0"
content_md5: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
extracted_at: "2026-04-20T21:34:12+02:00"
archive_path: "kern/de/praxis-9671.md"
---

<!-- BODY-BEGIN — ab hier ORIGINAL post_content 1:1, keine Änderung erlaubt. content_md5 bezieht sich auf alles NACH dieser Marker-Zeile bis Dateiende (ohne finalen Newline). -->
<p>Unsere Praxis liegt mitten im Frankfurter Westend...</p>
```

**Drei Konstruktions-Regeln:**

1. **`content_md5` ist immer in Anführungszeichen** (`"..."`) — macht das Extrahieren mit einem simplen Regex unzweideutig.
2. **Die Marker-Zeile ist byteweise identisch** in jeder Datei — das erlaubt den simplen Body-Extract via `awk`.
3. **Alles nach der Marker-Zeile bis Dateiende** ist der Body. Kein finaler Newline, kein Footer, keine Extra-Metadaten am Ende.

### Verifier — 80 Zeilen PHP, die alles beweisen

```php
// Pro Datei:
// 1. Lies als Ganzes
// 2. id aus "^id: (\d+)$" extrahieren
// 3. content_md5 aus '^content_md5: "([a-f0-9]{32})"$' extrahieren
// 4. Marker-Zeile finden, Body = alles nach dem \n danach
// 5. body_md5 = md5(body)
// 6. db_md5 = SELECT MD5(post_content) FROM wp_posts WHERE ID = $id
// 7. assert body_md5 === content_md5 === db_md5
```

Bei 189 Dateien läuft das in ~1 Sekunde durch. Output:

```
Total files checked: 189
  OK (3-way match):   189
  FAIL:               0
```

Ein einziger Fehler würde sofort auffallen, mit exakter Datei und der betroffenen ID.

---

## Teil 3 — Warum das in einer Kurations-Session echten Unterschied macht

### Klassischer Ablauf (ohne Archive)

1. WordPress-Backend öffnen, Original-Text lesen
2. Neue Fassung in Cursor/Editor schreiben
3. In WordPress einsetzen, speichern
4. Fertig? Hoffentlich alles übernommen.

**Problem:** Schritt 1 und 2 sind mental getrennt. Wenn zwischendurch Tab gewechselt, Kaffee geholt, Kind gerufen wird — Details aus Schritt 1 können bei Schritt 2 fehlen.

### Ablauf mit Archive

1. `cat _content-archive/kern/de/praxis-9671.md` → Original-Text steht **offen** im Editor
2. Neue Fassung nebenan aufbauen
3. In WordPress einsetzen, speichern
4. `git diff` gegen Archive-Datei → was wurde aus dem Original **nicht** übernommen?

Schritt 4 ist der neue Baustein. Er zeigt schwarz auf weiß jede ausgelassene Stelle — als bewusste Design-Entscheidung („dieser Absatz ist veraltet, weg damit") oder als **Fehler-Kandidat** („oh, das hätte ich mit übernehmen sollen"). Die Entscheidung wird sichtbar, nicht zufällig.

---

## Teil 4 — Wann lohnt sich das Setup?

| Situation | Lohnt? |
|---|:-:|
| Website-Relaunch mit Übernahme bestehender Inhalte | **Ja** — Hauptszenario |
| Migration auf andere Plattform (WP → Shopify, statisch → Headless) | **Ja** — identisches Muster |
| Komplette Neu-Erstellung (keine Inhalts-Übernahme) | Nein |
| < 10 Seiten | Eher nicht — flüchtiger Vergleich reicht |
| Compliance-relevante Dokumentation (Arzt-Website, Bank, Anwalt) | **Ja, immer** |

---

## Referenz-Implementierung

- **Projekt:** Cortex-Web / praxis-webseite, Session 16 (2026-04-20)
- **Spec:** `projects/Cortex-Web/sites/praxis-webseite/specs/sprint-2/S2.3-D_Phase2_content-extraction.md`
- **Generator:** `.../tools/migrations/2026-04-20_s2.3-d-p2_content-extract.php`
- **Verifier:** `.../tools/migrations/2026-04-20_s2.3-d-p2_verify-md5.php`
- **Archive:** `.../.../_content-archive/` (189 Markdown-Dateien)
- **Commits:** `661a4cd` (Spec) + `d5051eb` (194 Files) + `b3e001a` (SESSION_RESUME)

---

## Weitere Tutorials in dieser Linie

- **Tutorial 10** — Seiten-Inventar (die Vorstufe, die das Scope festlegt)
- **Tutorial 16** — UTF-8 Mojibake + Trunk-ready Inventar (die Vor-Sicherungs-Phase)
- **Tutorial 17** — Diese Datei (die Sicherungs-Phase selbst)

Die drei bilden zusammen das **Fundament** jeder seriösen Content-Migration: Scope kennen → Datenqualität sichern → Original archivieren → **dann** erst kurieren.
