# Git-Bootstrap eines Child-Themes + Page-Registry als Verify-Fundament

**Kontext:** Sprint 0 im Projekt `praxis-redesign` (westend-hausarzt.com).
**Stand:** 2026-04-18, nach Abschluss S0.1 + S0.4.
**Zielgruppe:** Dr. Stracke, wenn er später ein zweites WordPress-Theme
(andere Praxis, andere Site) auf dieselbe Weise aufsetzen will.

---

## Was in diesem Modul steht

1. Warum man ein WordPress-Child-Theme **eigenständig** versioniert und
   nicht den ganzen `wp-content/`-Baum.
2. Warum es sinnvoll ist, **zwei Repos** zu führen (Theme-Code vs.
   Prozess-Docs/Tools).
3. Wie `PXZ_VERSION` als Cache-Buster **und** Semver-Marker gleichzeitig
   funktioniert.
4. Was eine „Page-Registry" in der Verify-Pipeline ist und warum sie ab
   der zweiten Seite unverzichtbar wird.

---

## 1. Was versioniert man bei WordPress überhaupt?

Ein WordPress-Site besteht grob aus drei Schichten:

| Schicht | Inhalt | In Git? |
|---|---|---|
| `wp-core` + Plugins | WordPress selbst, zugekauft oder frei | **Nein** — wird von WP/Plugin-Manager verwaltet, Updates per WP-Admin |
| Theme (`wp-content/themes/<name>/`) | **Dein Code** — PHP-Templates, CSS, JS, Assets | **Ja** — das ist das Arbeitsstück |
| DB-Inhalt (Posts, Pages, Options) | Content + Konfig | Separat, per Backup-Tool (Duplicator, Akeeba) |

**Regel:** Git kontrolliert genau eine Schicht — das Theme. Alles andere
wird _nicht_ versioniert. Der Grund: WP-Core + Plugins kommen mit eigenen
Update-Mechanismen; sie in Git zu stopfen, erzeugt Merge-Konflikte bei
jedem Plugin-Update.

Eine sinnvolle Ausnahme sind **Must-Use-Plugins** (`mu-plugins/`), die
projekt-spezifisch sind (z. B. `000-local-mail-redirect.php`, das in
`praxis-redesign` Mail in Local-by-Flywheel auf Mailpit umbiegt). Die
gehören in ein schmales Neben-Repo oder als Unterordner in dasselbe.

---

## 2. Warum zwei Repos, nicht eins

Im `praxis-redesign`-Sprint 0 wurde bewusst für **zwei lokale Repos** optiert:

| Repo | Pfad | Inhalt |
|---|---|---|
| A — Theme | `.../wp-content/themes/praxiszentrum/` | PHP-Templates, CSS, Assets, CHANGELOG, README |
| B — Docs/Tools | `~/Cortex/projects/praxis-redesign/` | SESSION_RESUME, Specs, Regeln, Verify-Tools, Screenshots |

Die Trennung wirkt zunächst umständlich, zahlt sich aber aus:

- **Theme-`git log` bleibt sauber.** Jeder Commit ist eine echte
  Theme-Änderung. Wenn du später im Browser einen Bug siehst und die
  letzten 5 Commits durchgehst, sind da keine „SESSION_RESUME-Update"-
  Zeilen dazwischen.
- **Docs-Commit-Frequenz ist höher.** Prozess-Notizen ändern sich pro
  Session, Theme-Code nicht zwingend. Ein gemeinsames Repo hätte den
  Theme-`git log` mit Dutzenden SESSION_RESUME-Commits zugemüllt.
- **Deployment-Scope klarer.** Zum Prod-Deploy muss nur Repo A gepusht
  werden, nie Repo B. Trennung erzwingt das sauber.

Die Alternative „Theme als Submodule in Docs-Repo" wäre technisch
möglich, kostet aber Submodule-Komplexität, die in einem 1-Entwickler-
Setup nichts einbringt.

---

## 3. `PXZ_VERSION` — Cache-Buster **und** Semver in einem

In `functions.php`:

```php
define( 'PXZ_VERSION', '2.7.3' );

add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'blocksy-parent',
        get_template_directory_uri() . '/style.css', [], PXZ_VERSION );
    wp_enqueue_style( 'praxiszentrum',
        get_stylesheet_uri(), [ 'blocksy-parent' ], PXZ_VERSION );
} );
```

Die Konstante erfüllt zwei Pflichten gleichzeitig:

1. **Cache-Buster.** WordPress hängt `?ver=2.7.3` an jeden
   `wp_enqueue_style`-Aufruf. Ohne Bump sieht der Browser weiter die alte
   CSS-Datei.
2. **Semver-Marker.** Die Version erscheint im gerenderten HTML als
   `<style id="pxz-home-v2-7-3">` (weil der Inline-Block die Version im
   ID nutzt). Damit ist im DevTools direkt sichtbar, welcher Theme-Stand
   im Browser läuft.

### Bump-Policy

| Änderung | Bump | Beispiel |
|---|---|---|
| CSS-Feinjustage einer Sektion | Patch (2.7.3 → 2.7.4) | Padding von Card angepasst |
| Neue Sektion / Layout-Umbau | Minor (2.7.x → 2.8.0) | Homepage-MFA-Block verschlankt |
| Breaking-Change gegen Guidelines | Major (2.x → 3.0.0) | Komponenten-Vertrag ändert sich |

**Goldene Regel:** Kein sichtbarer Theme-Edit ohne Bump. Ohne Bump
cached der Browser, ohne Cache-Miss siehst du dein Ergebnis nicht, und
ohne Ergebnis behauptet man „fertig", obwohl nichts angekommen ist
(das war der Kern von PXZ-E-007 und FK-4 in `FEHLERPROTOKOLL.md`).

---

## 4. Was ist eine Page-Registry?

Die naive Verify-Pipeline kennt nur die Seite, für die sie gebaut wurde.
Das rächt sich sofort, wenn die zweite Seite dazukommt — in
`praxis-redesign` war das die Karriere-Seite, und genau dort schlich
sich PXZ-E-005 ein (Pflicht-Checkbox rendert nicht), weil die Probe
weiter nur die Homepage kannte.

Die **Page-Registry** (`tools/page-registry.mjs`) ist eine einzige
JavaScript-Datei, die alle zu prüfenden Seiten als Datenstruktur
aufführt:

```js
export const pages = [
  {
    slug: "home",
    url: "https://…/",
    viewports: [1440, 768, 430],
    expected: {
      1440: { ".pxz-loc-card--main": { paddingTop: "112px" } },
      768:  { /* … */ },
      430:  { /* … */ },
    },
  },
  {
    slug: "karriere",
    url: "https://…/karriere/",
    viewports: [1440, 768, 430],
    expected: {
      1440: { ".pxz-kar-card": { paddingTop: "112px" } },
      /* … */
    },
    exists: [
      ".wpforms-field-checkbox input[required]",  // DSGVO-Pflichtfeld
    ],
  },
];
```

Der Verify-Runner (`probe-design.mjs`) iteriert blind über diese Daten.
Neue Seite hinzufügen = einen Registry-Eintrag hinzufügen, nichts am
Runner ändern.

### Warum auch `exists:` und nicht nur Computed-Style

Manche Checks sind **keine Style-Assertions**, sondern Existenz-
Zusagen:

- Das Pflicht-Eingabefeld muss da sein (`required`-Attribut).
- Das Formular muss vorhanden sein (`<form id="wpforms-form-…">`).
- Der Hero-Block muss gerendert sein.

Das sind binäre Ja/Nein-Checks, keine CSS-Werte. `exists:` deckt sie
ab, ohne das Schema zu verrenken.

---

## 5. Die Ad-hoc-Probe vor dem ersten Registry-Eintrag

Ein wiederkehrender Fehler: neue Registry-Werte **raten** statt
**messen**. Das führt zu einer ersten fehlschlagenden verify-Runde, die
dann als „Probe falsch, Registry zu korrigieren" durchgeht — obwohl die
Ursache nur unsaubere Vorarbeit ist.

**Richtig:** bevor du `"karriere"` in die Registry einträgst, mess die
tatsächlich gerenderten Werte mit einem Wegwerf-Skript:

```js
// /tmp/probe-karriere.mjs
import { launch } from "puppeteer-core";
const browser = await launch({
  executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  args: ["--ignore-certificate-errors", "--allow-insecure-localhost"],
  headless: true,
});
const page = await browser.newPage();
for (const vp of [1440, 768, 430]) {
  await page.setViewport({ width: vp, height: 1000 });
  await page.goto("https://…/karriere/?v=" + Date.now(), { waitUntil: "networkidle2" });
  const data = await page.evaluate(() => {
    const el = document.querySelector(".pxz-kar-card");
    const cs = getComputedStyle(el);
    return { paddingTop: cs.paddingTop, paddingLeft: cs.paddingLeft };
  });
  console.log(vp, data);
}
await browser.close();
```

Die Zahlen, die dir das Skript liefert (112/96/72 und 96/72/40 im Fall
Karriere), sind die Zahlen, die in die Registry kommen. Dann ist der
erste Probe-Lauf grün und Registry + Code bleiben kohärent.

---

## 6. Wo das hier einzuordnen ist

| Artefakt | Zweck | Pfad |
|---|---|---|
| Pattern (projekt-neutral) | wiederverwendbar für Shopify/WordPress/Static | `Nexus/_memory/patterns/page-registry-verify.md` |
| Fehler-Verweis | warum die Pipeline nicht homepage-only bleiben durfte | `projects/praxis-redesign/_rules/FEHLERPROTOKOLL.md` → PXZ-E-005 |
| Dieses Tutorial | WordPress-spezifische Einordnung für Dr. Stracke | hier |
| Live-Code | funktionierende Umsetzung | `projects/praxis-redesign/tools/page-registry.mjs` + `probe-design.mjs` + `shoot.mjs` |

---

## 7. Wenn du das nochmal machst

Eine 10-Minuten-Checkliste für das nächste WordPress-Projekt:

1. Im Theme-Ordner: `git init -b main`, `.gitignore` (node_modules, .DS_Store, *.log),
   `CHANGELOG.md` (Semver-Einstieg aktuelle Version), `README.md` mit dem
   lokalen WP-CLI-Aufrufmuster.
2. Baseline-Commit: `chore: baseline vX.Y.Z (…)`.
3. Kein Remote. Erst wenn du wirklich ein Backup/Pair-Work brauchst, entscheidest du GitHub oder anders.
4. Neben-Repo für Prozess-Docs/Verify-Tools: `~/Cortex/projects/<name>/`. Auch lokal, auch `git init -b main`.
5. Verify-Runner schreiben (1 Page ist OK), EXPECTED aus Ad-hoc-Probe übernommen, nicht geraten.
6. **Erst beim Schritt von der 1. zur 2. Seite** auf Registry umbauen. Vorher wäre es YAGNI.
