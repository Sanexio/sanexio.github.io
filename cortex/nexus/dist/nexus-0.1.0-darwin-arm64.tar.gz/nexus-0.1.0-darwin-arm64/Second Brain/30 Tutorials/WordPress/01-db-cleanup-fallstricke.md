---
tags: [wordpress, wpml, datenbank, cleanup, troubleshooting]
created: 2026-05-05
context: Welle H (Cleanup vor Live-Deploy) Praxis-Webseite
---

# 01 — WP-DB-Cleanup: Fallstricke und Safe-Patterns

> Lessons-Learned aus dem Cleanup-Sprint Welle H, in dem ich (Claude)
> einen Fehler eingebaut habe, der die ganze Site auf HTTP 500 gezogen hat.

---

## 1. Der Fehler — `_icl_cache` mit Leerstring überschreiben

### Symptom
Frontend, WP-Admin, alle URLs antworten mit HTTP 500. PHP-Log:

```
PHP Fatal error: Uncaught TypeError: Cannot access offset of type string on string
in .../sitepress-multilingual-cms/inc/cache.php:126
```

### Ursache
Beim Cleanup habe ich versucht, den WPML-Cache zu leeren mit:

```sql
UPDATE wp_options SET option_value = "" WHERE option_name = "_icl_cache";
```

WPML speichert in dieser Option ein **PHP-serialisiertes Array**. Beim
nächsten Page-Load liest WPML die Option, will mit `$cache[$key]`
einen Wert holen — der Leerstring ist aber kein Array. PHP wirft
`Cannot access offset of type string on string`. Da der Fehler
in einem `plugins_loaded`-Hook auftritt, ist die ganze Site tot.

### Der Fix
Option komplett löschen, statt auf Leerstring setzen:

```sql
DELETE FROM wp_options WHERE option_name = "_icl_cache";
```

WPML legt sie beim nächsten Render automatisch mit Default-Wert
(leeres Array) wieder an.

### Goldene Regel
> **Eine Option, die ein Plugin als Array oder Objekt erwartet, NIE
> auf einen primitiven Wert (Leerstring, 0, NULL) setzen — immer
> komplett löschen.** Das Plugin entscheidet selbst, mit welchem
> Default es startet.

Konkret betroffene Optionen, die nie auf Leerstring gehen dürfen:
- `_icl_cache` (WPML — serialisiertes Array)
- `WPML(logs)` (WPML — serialisiertes Array)
- Alle `_transient_*` mit Plugin-spezifischem Inhalt
- `widget_*` (WP-Widget-Daten — Objekt-Hierarchie)
- Typisierte Plugin-Settings — wenn unsicher: `DELETE`, nicht `UPDATE`

---

## 2. Safe-Patterns für DB-Cleanup

### 2.1 Vor jeder Schreiboperation — DB-Dump

```bash
MYSQLDUMP="/path/to/mysqldump"
SOCK="/Users/.../Local/run/.../mysql/mysqld.sock"
"$MYSQLDUMP" --socket="$SOCK" -uroot -proot \
  --single-transaction --routines --triggers --no-tablespaces \
  local 2>/dev/null | gzip > backup-$(date +%Y%m%d-%H%M).sql.gz
```

`--single-transaction` macht den Dump ohne Tabellen-Lock auf
InnoDB-Tabellen, `--routines --triggers` nimmt Stored-Procedures mit.

### 2.2 Restore (im Notfall)

```bash
gunzip -c backup-XXX.sql.gz | mysql --socket="$SOCK" -uroot -proot local
```

### 2.3 Plugin sauber deinstallieren

Nicht einfach Verzeichnis löschen — Plugin hat oft `uninstall.php`,
das DB-Tabellen aufräumt. WP-Funktion nutzen:

```php
require_once ABSPATH . 'wp-admin/includes/plugin.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
WP_Filesystem();

deactivate_plugins(['plugin-slug/plugin.php'], true, false);
delete_plugins(['plugin-slug/plugin.php']);
```

Aufruf via PHP-CLI, mit `WP_USE_THEMES=false`, `WP_ADMIN=true` und
`memory_limit=1024M`. Bei Local by Flywheel zusätzlich
`define('DB_HOST', 'localhost:/path/to/mysqld.sock')` BEVOR
`wp-load.php` geladen wird, weil Local die DB über Unix-Socket
exponiert, nicht TCP.

### 2.4 Pages hart löschen — postmeta + wpml-translations mitnehmen

```sql
-- Beispiel: alle trash-Pages permanent löschen
DELETE pm FROM wp_postmeta pm
  JOIN wp_posts p ON p.ID=pm.post_id
 WHERE p.post_type="page" AND p.post_status="trash";

DELETE t FROM wp_icl_translations t
  JOIN wp_posts p ON p.ID=t.element_id
                 AND t.element_type="post_page"
 WHERE p.post_type="page" AND p.post_status="trash";

DELETE FROM wp_posts
 WHERE post_type="page" AND post_status="trash";
```

Reihenfolge: **erst postmeta, dann icl_translations, zuletzt
wp_posts**. Sonst hat man Foreign-Key-mäßige Reste in den
Detail-Tabellen ohne wp_posts-Bezug (Orphan-Postmeta).

### 2.5 Revisions auf N pro Page begrenzen

```sql
DELETE r FROM wp_posts r
WHERE r.post_type="revision"
  AND r.ID NOT IN (
    SELECT ID FROM (
      SELECT ID, post_parent,
             ROW_NUMBER() OVER (
               PARTITION BY post_parent ORDER BY post_modified DESC
             ) AS rn
        FROM wp_posts WHERE post_type="revision"
    ) ranked WHERE rn <= 5
  );

-- danach orphan-postmeta säubern
DELETE pm FROM wp_postmeta pm
LEFT JOIN wp_posts p ON p.ID=pm.post_id
WHERE p.ID IS NULL;
```

ROW_NUMBER() braucht MySQL 8 oder MariaDB 10.2+.

### 2.6 Transients pauschal löschen

```sql
DELETE FROM wp_options
 WHERE option_name LIKE "_transient_%"
    OR option_name LIKE "_site_transient_%";
```

WP regeneriert sie automatisch beim nächsten Aufruf. Sicher.

### 2.7 Plugin-Reste nach Drop löschen

```sql
DELETE FROM wp_options WHERE
  option_name LIKE "wpforms_%" OR
  option_name LIKE "fs_%" OR
  option_name LIKE "google_analytics_%";
  -- pro gedropptes Plugin: passendes Pattern
```

`fs_*` ist Freemius-Account-Daten (autoload=yes, oft 30 KB+) —
fast immer DROP, weil nutzlos ohne Plugin.

---

## 3. Verify-Sweep — Pflicht nach jeder Mutation

```bash
URL_BASE="https://100.127.125.48"   # Tailscale-IP (oder localhost via Master-nginx)
HOST="<site-hostname>"

for path in / /?lang=en /wp-login.php /wichtige-page/; do
  code=$(curl -sk -o /dev/null -w "%{http_code}" \
              -H "Host: $HOST" "$URL_BASE$path" --max-time 10)
  echo "  $code  $path"
done
```

200 für alle URLs — sonst sofort Logs prüfen:

```bash
LOGDIR="/Users/.../Local Sites/<site>/logs"
tail -50 "$LOGDIR/php/error.log"
tail -15 "$LOGDIR/nginx/error.log"
```

PHP-FATAL-Errors zeigen Stack-Trace bis zur Plugin-Datei + Zeile. Das
ist meistens genau die Schreiboperation, die zu aggressiv war.

---

## 4. Mini-Heuristik — was tun, wenn nach Cleanup HTTP 500?

| Erste Vermutung | Diagnose | Fix |
|---|---|---|
| Plugin-Code referenziert gelöschte Option | PHP-Log: `undefined index` / `null` | Option löschen (nicht UPDATE), Plugin regeneriert |
| Option mit kaputtem Typ | PHP-Log: `Cannot access offset … on string` | DELETE statt UPDATE auf Leerstring |
| Plugin-Datei fehlt | nginx-Log: `No such file` / autoload-Fehler | wp-Datei `active_plugins` säubern |
| Theme-Datei fehlt | nginx-Log: `template-XXX.php not found` | `stylesheet`/`template` in wp_options prüfen |
| DB-Connection-Refused | nginx-Log: 502 | mysqld.sock-Pfad in DB_HOST stimmen? |

---

## 5. Verwandte Notizen

- [[10-remote-zugriff-local-dev]] — Lokal entwickeln, remote browsen
- [[09-cortex-mesh-tailscale]] — Tailscale für Multi-Mac-Setup
- [[Arbeitsweise & Prozess/01-architekten-modus]] — Phase 1–4-Disziplin (Backup vor Schreiben)
