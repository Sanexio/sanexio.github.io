# 08 — Cross-Repo-Subsumption mit `git subtree`

> Wie ein eigenständiges Git-Repo unter ein Dach-Repo wandert, ohne dass die
> Historie verloren geht — und ohne dass Sie ein externes Tool installieren müssen.
> Konkretes Beispiel: Cortex-Web Phase 4 (2026-04-19), Subsumierung von
> `praxis-redesign/` unter `Cortex-Web/sites/praxis-webseite/`.

---

## §1 Worum es geht

Stellen Sie sich vor, Sie haben zwei lokale Git-Repos:

```
~/Cortex/projects/praxis-redesign/   ← eigenes .git, 13 Commits, kein Remote
~/Cortex/projects/Cortex-Web/        ← eigenes .git, soll praxis-redesign aufnehmen
```

Sie wollen den Inhalt von `praxis-redesign` unter `Cortex-Web/sites/praxis-webseite/`
einsortieren — und zwar so, dass:

1. Die 13 Commits aus `praxis-redesign` weiterhin lesbar bleiben (Audit-Trail).
2. `Cortex-Web` nach der Operation einen sauberen `git status` hat.
3. `praxis-redesign/` danach komplett gelöscht werden kann.
4. Pre-Flight-Tools (`tools/verify.sh`) am neuen Pfad weiter funktionieren.

Das geht **nicht** mit `git mv` — `git mv` arbeitet INNERHALB eines Repos.
Hier sind es zwei separate Repos.

Es gibt drei Standard-Wege:

| Weg | Tool | Historie | Aufwand |
|-----|------|:--------:|:-------:|
| `git subtree add` | Standard-Git | ✅ alle Commits erreichbar | gering |
| `git filter-repo --to-subdirectory-filter` | extern (Python) | ✅ saubere lineare Historie | hoch |
| `cp` + Single-Import-Commit | nichts | ❌ nur 1 Commit, Original bleibt als Archiv | minimal |

Der häufigste Fall (lokale Repos, mittlere Commit-Zahl, kein Remote) ist
**`git subtree add`**. Den erklärt dieses Tutorial.

---

## §2 Wie `git subtree add` funktioniert (das Mentalmodell)

`git subtree` ist ein Standard-Git-Befehl seit 1.7. Er macht folgendes:

1. **Holt** alle Commits aus dem Source-Repo (wie ein `git fetch`, aber von einem
   lokalen Pfad statt einer URL).
2. **Erzeugt einen Merge-Commit**, der den Source-Branch in das Target-Repo
   einbringt — und zwar mit dem Verzeichnis-Prefix Ihrer Wahl
   (`--prefix=sites/praxis-webseite`).

Der Effekt:

```
Vor dem Befehl:                    Nach dem Befehl:

Cortex-Web/                        Cortex-Web/
├── _rules/                        ├── _rules/
├── adapters/                      ├── adapters/
├── trunk/                         ├── trunk/
└── (kein sites/praxis-webseite)   └── sites/
                                       └── praxis-webseite/   ← NEU
                                           ├── _rules/        ← komplett aus praxis-redesign
                                           ├── tools/
                                           ├── screenshots/
                                           └── …
```

Im `git log`:

```
77adfc7 docs(phase-4): add THEME_POINTER       ← Cortex-Web-eigene Commits davor
94e6e91 Add 'sites/praxis-webseite/' from commit 'c519852…'   ← der Subtree-Add-Merge
c519852 chore: pre-subsumption verify shots    ← Praxis-Commits, neu integriert
4583856 docs: finalize ARCHITECTURE 4b before subsumption
1d75003 docs: SESSION_RESUME after S2.0 token-SSoT (v2.7.5)
…
2f288a3 chore: baseline Sprint-0 start (docs + verify tools, post-v2.7.3)  ← ältester
```

Alle 13 alten Commits sind jetzt im Cortex-Web-Repo erreichbar. Sie behalten
Original-Datum und Autor.

---

## §3 Der konkrete Ablauf — Phase 4 als Live-Beispiel

### Schritt 0: Vorher prüfen

```bash
cd ~/Cortex/projects/praxis-redesign
git status --short                  # MUSS leer sein, sonst Schritt 1 erst
git rev-list --count HEAD           # zählt die Commits (war: 11)
git remote -v                       # idR keins bei lokalen Repos
```

War in Phase 4 `unclean`:
```
M _rules/ARCHITECTURE.md     ← Änderung war nie committed
?? specs/bridge-strategy/     ← 3 neue Dateien, untracked
```

### Schritt 1: Cleanup

Das ist der kniffligste Schritt — was machen Sie mit Modified- und Untracked-Dateien?

**Faustregel:**
- **Modified** → committen (oder explizit verwerfen, wenn obsolet).
- **Untracked, gehört konzeptionell ins Source** → committen.
- **Untracked, gehört konzeptionell ins Dach** → DIREKT ins Dach verschieben und dort
  committen — *bevor* Subtree-Add läuft. Spart einen Umweg.

In Phase 4:
```bash
# Bridge-strategy gehört konzeptionell ins Dach (Common-Trunk-Konzept):
mv ~/Cortex/projects/praxis-redesign/specs/bridge-strategy \
   ~/Cortex/projects/Cortex-Web/specs/

cd ~/Cortex/projects/Cortex-Web
git add specs/bridge-strategy
git commit -m "docs(phase-4): promote bridge-strategy from praxis-redesign"

# Modified ARCHITECTURE.md gehört in praxis-redesign-Historie:
cd ~/Cortex/projects/praxis-redesign
git add _rules/ARCHITECTURE.md
git commit -m "docs: finalize ARCHITECTURE 4b before subsumption"
```

### Schritt 2: Der Kernschritt — `git subtree add`

```bash
cd ~/Cortex/projects/Cortex-Web
git subtree add \
  --prefix=sites/praxis-webseite \
  ~/Cortex/projects/praxis-redesign \
  main
```

Output:
```
git fetch /Users/.../praxis-redesign main
From /Users/.../praxis-redesign
 * branch            main       -> FETCH_HEAD
Added dir 'sites/praxis-webseite'
```

### Schritt 3: Externe-Repo-Pointer (falls nötig)

In Phase 4 hatte `praxis-redesign` einen Verweis auf das WordPress-Theme,
das physisch unter dem Local-by-Flywheel-Pfad lebt — nicht in `praxis-redesign`,
sondern in einem eigenen Drittel-Repo. Das WP-Theme zog **nicht** mit um
(weil Local-by-Flywheel den Pfad braucht).

Lösung: eine Pointer-Datei `sites/praxis-webseite/THEME_POINTER.md`,
die den absoluten Pfad zum Theme + den aktuellen Theme-Commit (HEAD-Hash)
dokumentiert. Bei Theme-Updates wird der Hash dort manuell aktualisiert.

### Schritt 4: Pfad-Updates in Doku

Alle Stellen finden, die noch auf den alten Pfad zeigen:

```bash
grep -rn "projects/praxis-redesign" ~/Cortex/Nexus ~/Cortex/projects/Cortex-Web
```

Klassifizieren:

- **Aktive Verweise** (z. B. „Pflicht-Lesung: `projects/praxis-redesign/...`",
  „cd projects/praxis-redesign", „Pfad: ...") → **umschreiben** auf
  `Cortex-Web/sites/praxis-webseite/`.
- **Historische Verweise** (Logs, Specs, didaktische Tutorials) → **unverändert
  lassen** oder mit Klammer-Hinweis ergänzen: „(vor Phase-4-Subsumierung am
  2026-04-19: `projects/praxis-redesign/...`)".

### Schritt 5: Source-Repo entfernen — ABER VORSICHT mit gitignored Daten

Das ist der gefährlichste Schritt. Dateien in `.gitignore` sind NICHT im
Subtree-Add gewandert — die liegen nur im Source-Verzeichnis.

In Phase 4 war das `.env.sprint1.local` (gitignored, mit echten SFTP-Credentials).
Wenn das `rm -rf` ohne vorherige Migration läuft, sind die Daten weg.

**Pflicht-Sicherheits-Check vor `rm -rf`:**

```bash
# Was ist gitignored und hat Inhalt?
cd ~/Cortex/projects/praxis-redesign
ls -la .env*

# Pro relevante Datei: kopieren + chmod 600 + MD5-Beweis
cp .env.sprint1.local  ~/Cortex/projects/Cortex-Web/sites/praxis-webseite/.env.sprint1.local
chmod 600              ~/Cortex/projects/Cortex-Web/sites/praxis-webseite/.env.sprint1.local
md5  .env.sprint1.local  ~/Cortex/projects/Cortex-Web/sites/praxis-webseite/.env.sprint1.local
# Beide MD5-Hashes müssen identisch sein!

# Sicherstellen, dass die Datei am neuen Ort vom .gitignore abgedeckt ist:
cd ~/Cortex/projects/Cortex-Web
git check-ignore -v sites/praxis-webseite/.env.sprint1.local
# Output sollte zeigen, welche .gitignore-Regel matcht
```

Erst wenn der MD5-Beweis und der `check-ignore`-Beweis stehen:

```bash
rm -rf ~/Cortex/projects/praxis-redesign
```

### Schritt 6: Pre-Flight am neuen Pfad

`node_modules/` ist gitignored, daher nicht im Subtree-Add. Erst neu installieren:

```bash
cd ~/Cortex/projects/Cortex-Web/sites/praxis-webseite
bun install      # oder npm install
```

Dann die Pre-Flight-Tools des Source am neuen Pfad ausführen — sie sollten
exakt das gleiche Ergebnis wie vor der Migration liefern:

```bash
bash tools/verify.sh
```

In Phase 4 zeigte verify.sh nach der Migration weiterhin: §3 Computed-Style
**54/54** + §4 Alignment **10/10** grün. Bedeutet: WordPress-Theme funktioniert
unverändert (dass es ja auch sollte — das WP-Theme wurde gar nicht angefasst).

---

## §4 Was Sie hinterher prüfen müssen (12 Akzeptanzkriterien)

Aus Phase 4 (`Cortex-Web/specs/phase-4/SUBSUMPTION.md` §4):

| AK | Was |
|---:|-----|
| 1 | `sites/<name>/` enthält ≥ N Dateien (N = `git ls-files <source>` aus Pre-Audit) |
| 2 | Promotete Dateien (z. B. bridge-strategy) sind im Dach |
| 3 | Externe-Repo-Pointer enthält aktuellen HEAD-Hash |
| 4 | Source-Commits sind erreichbar (`git log <source-letzter-hash> --oneline`) |
| 5 | Pre-Flight am neuen Pfad grün |
| 6 | Dach-Pre-Flight grün (validate.sh + ggf. review.sh) |
| 7 | Externer Repo unverändert (z. B. WP-Theme HEAD = Pointer-Hash) |
| 8 | Keine aktiven alten Pfad-Verweise mehr |
| 9 | Source-Verzeichnis existiert nicht mehr |
| 10 | Vor Subtree-Add war Source Working-Tree clean |
| 11 | (Wie 7) externer Repo wirklich unverändert |
| 12 | Self-Check-Datei vorhanden |

Jeden AK mit objektivem Befehl messen, Output protokollieren.

---

## §5 Eine wichtige Caveat zur Subtree-Historie

`git log sites/<name>/` zeigt nach `git subtree add` (ohne `--squash`)
**NUR den Subtree-Add-Merge-Commit**, nicht die importierten Commits.

Grund: Die alten Commits hatten zur Original-Zeit den Pfad **ohne** `sites/<name>/`-
Prefix. Git's pfad-basierter Filter erkennt das nicht als Rename, weil
ein Subtree-Add ein Merge ist, kein `git mv`.

**Workaround:** alle Commits sind erreichbar via:

```bash
git log <source-letzter-commit-hash> --oneline
# z. B. git log c519852 --oneline   ← zeigt alle 13 Praxis-Commits
```

Oder über Inhalt:
```bash
git log --all --grep="<source-spezifisches-keyword>"
```

`git log --follow <datei>` funktioniert ebenfalls nicht für migrierte Dateien.

Wer eine pfad-saubere Historie braucht: `git filter-repo --to-subdirectory-filter`
ist die Alternative — Trade-off ist aber die Tool-Installation und ein zusätzlicher
Klon-Schritt.

---

## §6 Wann Sie diesen Pattern NICHT anwenden

- Source und Target liegen beide auf GitHub mit aktiven Pull Requests → eher
  `git submodule` erwägen (synchroner Sub-Repo, beide Branches separat pflegbar).
- Source hat hunderte Commits → `git filter-repo` für sauberere Historie.
- Source und Target haben **gemeinsame Datei-Pfade** → Subtree-Add weigert sich,
  Konflikt-Auflösung nötig.

---

## §7 Variante B — Container ohne Git + Remote-Repo-Pointer (Phase 5)

In Phase 5 (Session 7, 2026-04-19) wurde eine **zweite Art** der Subsumierung
durchgespielt, die von Phase 4 in zwei Punkten abweicht:

1. Der Source-Ordner `Juvantis/juvantis-web/` **ist selbst KEIN Git-Repo**.
   Er ist nur ein Container um `theme/` — und `theme/` ist ein Git-Klon
   eines GitHub-Remote-Branches (`shopify-theme`) mit bidirektionaler
   Shopify-GitHub-Sync.
2. Der Unter-Git-Repo **soll nicht mitwandern**. Grund: bidirektionale
   Auto-Sync + 217 Auto-Commits wären im Cortex-Web-Log störendes Rauschen.

### Die Unterschiede zum Phase-4-Vorgehen

| Aspekt | Phase 4 (praxis-redesign) | **Phase 5 (Juvantis-Web)** |
|--------|---------------------------|----------------------------|
| Source-Parent-Ordner | eigenes Git (11 Commits) | **KEIN Git** |
| `git subtree add` nötig | ✅ | **❌** — einfacher `mv` + `commit` reicht |
| Unter-Git-Repo | — | bleibt bei Juvantis, nicht mitgewandert |
| Pointer-Datei | `THEME_POINTER.md` (lokal) | `SHOPIFY_THEME_POINTER.md` (Remote, Auto-Sync-Doku) |
| Deploy-Skripte | unverändert | **relative Theme-Pfade auf absoluten `$HOME`-Pfad umgestellt** |
| Risiko Live-Site | mittel | niedrig |

### Die 6 Schritte Variante B

```bash
# T0: Pre-Flight Target grün
cd ~/Cortex/projects/Cortex-Web && bash tools/validate.sh

# T1: Spec schreiben
# → specs/phase-5/SUBSUMPTION.md (4 Entscheidungspunkte E1–E4, 12 AKs)

# T2: mv der konzeptionellen Schicht (Deploy-Skript, Backups, Content-Refs)
mkdir -p sites/juvantis-webseite
mv ../Juvantis/juvantis-web/shopify-sync.sh  sites/juvantis-webseite/
mv ../Juvantis/juvantis-web/shopify_export   sites/juvantis-webseite/
mv ../Juvantis/juvantis-web/knowledge-graph  sites/juvantis-webseite/

# T2b: Skripte mit relativen Pfad-Annahmen absolut machen
# shopify-sync.sh: THEME_DIR="$(cd "$(dirname "$0")/theme" && pwd)"  ← kaputt
# → THEME_DIR="$HOME/Cortex/projects/Juvantis/juvantis-web/theme"    ← $HOME-portabel

git add sites/juvantis-webseite && git commit -m "feat(phase-5): transfer …"

# T3: Remote-Repo-Pointer schreiben
# → sites/juvantis-webseite/SHOPIFY_THEME_POINTER.md
#    mit GitHub-URL, Branch, Store-Slug, Theme-ID, Auto-Sync-Charakter
git add sites/juvantis-webseite/SHOPIFY_THEME_POINTER.md
git commit -m "docs(phase-5): add SHOPIFY_THEME_POINTER …"

# T4: README + SESSION_RESUME für die Sub-Site

# T5: Pfad-Referenz-Updates (Nexus MEMORY/CLAUDE/SYSTEM_MAP + Target-Docs)

# T6: Source-Projekt-Doku aktualisieren (Container enthält jetzt nur Unter-Repo)

# T7: Post-Pre-Flight — Unter-Repo-HEAD unverändert bestätigen
git -C ~/Cortex/projects/Juvantis/juvantis-web/theme rev-parse HEAD
# MUSS identisch zu vor-Phase-5-Stand sein
```

### Die 5 Phase-5-Lessons Learned (PH5-LL-1…5)

- **PH5-LL-1:** Subtree-Pattern skaliert nicht bei Remote-Repos mit Auto-Sync
  — Commit-Message-Uniformität-Check vor subtree-add.
- **PH5-LL-2:** Container-ohne-Git ist kein Sonderfall, sondern Normalfall
  bei Multi-Repo-Containern. `mv` + `commit` reicht.
- **PH5-LL-3:** Externer-Repo-Pointer braucht Remote-Felder (GitHub-URL,
  Branch, Store-ID, Auto-Sync-Charakter), wenn Remote aktiv ist.
- **PH5-LL-4:** Skript-Transfer zwischen Parent-Ordnern immer mit
  `grep '\$(dirname\|\$BASH_SOURCE'` nach relativen Pfad-Annahmen prüfen
  und vor `mv` auf absolut umstellen.
- **PH5-LL-5:** `.claude/settings.local.json`-Hooks sind deviceabhängig,
  nie eigenmächtig refactorn.

### Wann Variante A, wann B?

Entscheidungshilfe:

```
Hat der Source-Ordner ein eigenes .git?
├── NEIN → Variante B (dieses Kapitel)
└── JA
    ├── Sind >80% der Commits Auto-Sync-Rauschen? → Variante B + Pointer auf das Unter-Repo
    ├── Ist das Unter-Repo eng mit einer externen Plattform verbunden (Remote, Auto-Sync)? → Variante B
    └── Sonst → Variante A (git subtree add, §2–§6)
```

---

## §8 Querverweise

- **Pattern:** `~/Cortex/Nexus/_memory/patterns/cross-repo-subsumption.md` —
  technisches Vorgehen (Variante A + Variante B), ohne Cortex-Web-Hintergrund.
- **Live-Beispiel-Spec Phase 4:** `~/Cortex/projects/Cortex-Web/specs/phase-4/SUBSUMPTION.md`
  + `evidence/2026-04-19_self-check.md`.
- **Live-Beispiel-Spec Phase 5:** `~/Cortex/projects/Cortex-Web/specs/phase-5/SUBSUMPTION.md`
  + `evidence/2026-04-19_self-check.md`.
- **Git-Grundlagen:** `~/Cortex/Nexus/Second Brain/30 Tutorials/Terminal/02-git.md`.
- **Vorheriges Tutorial:** `07-review-pipeline-und-local-wp-tests.md` — die
  Review-Pipeline, die in T7 als Regressions-Schutz lief.

---

*Erstellt 2026-04-19 (Cortex-Web Session 6 „Session beenden"-Schritt 4).*
*Erweitert 2026-04-19 (Cortex-Web Session 7 „Session beenden"-Schritt 4): §7 Variante B
aus Phase 5 (Juvantis-Web), PH5-LL-1…5.*
