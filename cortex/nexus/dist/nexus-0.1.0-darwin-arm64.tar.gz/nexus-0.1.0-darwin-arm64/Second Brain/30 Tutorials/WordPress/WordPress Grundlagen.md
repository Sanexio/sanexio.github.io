---
type: tutorial
aliases: [WordPress, WP, CMS, Praxis-Webseite, westend-hausarzt, domainfactory]
tags:
  - tutorial
  - wordpress
  - cms
  - praxis-webseite
source: Second Brain/30 Tutorials/WordPress/
---

# WordPress — Grundlagen

> Deine Praxis-Webseite **westend-hausarzt.com** läuft auf WordPress.
> Diese Seite gibt dir den Überblick — von „Was ist eigentlich ein CMS"
> bis zu „Wie ist deine konkrete Installation aufgebaut".

> [!info] Lesezeit: 12 Minuten · Voraussetzung: keine

---

## 1. Was ist WordPress?

WordPress ist ein **CMS** — Content Management System. Eine Software, die im
Browser einen Editor anbietet, mit dem **auch Nicht-Programmierer** Webseiten-
Inhalte pflegen können.

**Drei Zahlen, um die Marktstellung einzuordnen:**
- ~43 % aller Webseiten weltweit laufen auf WordPress (Stand 2025)
- Open Source (kostenlos)
- 60 000+ Plugins, 11 000+ Themes verfügbar

WordPress ist der **De-facto-Standard für Praxis-Webseiten**, kleine bis
mittlere Firmen, Blogs, Vereine. Bei großen E-Commerce-Shops verliert es
gegen Shopify (zu langsam, zu pflege-intensiv).

> **Bei dir:** Praxis-Webseite. Juvantis hingegen läuft auf **Shopify** — bewusst getrennt, weil sich die Anforderungen unterscheiden ([[Webentwicklung Grundlagen]] §5).

---

## 2. WordPress.com vs. WordPress.org — der ständige Verwechsel

| Variante | Was es ist | Wer nutzt es |
|---|---|---|
| **WordPress.org** (Self-Hosted) | Du lädst die Software runter, installierst sie auf einem eigenen Server. Volle Kontrolle, alle Plugins, eigenes Hosting. | **Du** mit westend-hausarzt.com. Auch fast alle Praxen, Firmen, Profis. |
| **WordPress.com** (Hosted) | Anbieter Automattic hostet alles für dich. Eingeschränkt bei Plugins/Themes. Monatsgebühr. | Hobby-Blogger, Schnellstart-Nutzer |

Wenn dich jemand fragt „Welches WordPress?" — bei dir ist es **immer** das Self-Hosted (WP.org).

---

## 3. Die Architektur deiner WordPress-Webseite

```
Browser des Patienten
        │
        │ HTTPS-Request
        ▼
domainfactory-Webserver (Apache/Nginx)
        │
        │ verarbeitet PHP
        ▼
WordPress (Code in /wp-content/, /wp-admin/, /wp-includes/)
        │
        │ liest Inhalte aus
        ▼
MySQL/MariaDB-Datenbank
        │
        │ Tabellen wie wp_posts, wp_options, wp_users
        ▼
Antwort: HTML + CSS + Bilder zurück an Browser
```

**Drei Dateisystem-Bereiche, die zählen:**

| Pfad | Inhalt |
|---|---|
| `/wp-admin/` | Das Admin-Backend (was du im Browser unter `/wp-admin/` siehst) |
| `/wp-includes/` | WordPress-Kern (Funktionen, Klassen) — nie anfassen |
| `/wp-content/` | **Hier passiert dein Leben:** Themes, Plugins, Uploads (Bilder) |

Speziell:
- `/wp-content/themes/praxiszentrum/` — **dein Theme** (Layout, CSS, Templates)
- `/wp-content/plugins/` — alle aktiven Plugins
- `/wp-content/uploads/` — alle hochgeladenen Bilder/PDFs

---

## 4. Inhaltstypen — was wird wo gespeichert?

WordPress unterscheidet zwei Haupt-Inhaltstypen:

| Typ | Was ist es? | Wo? | Beispiele bei dir |
|---|---|---|---|
| **Page** | Statische Seite, hierarchisch (Eltern/Kind möglich) | `wp_posts` mit `post_type='page'` | „Über uns", „Team", „Standorte", „Leistungen" |
| **Post** | Blog-Beitrag, zeitlich sortiert | `wp_posts` mit `post_type='post'` | (bei dir aktuell wenig genutzt) |

Dazu kommen **Custom Post Types** — frei definierbare Inhaltstypen. Beispiele aus dem Web: „Veranstaltung", „Produkt", „Mitarbeiter". Bei dir bisher nicht aktiv genutzt — Team-Daten kommen über `inc/team-data.php` als SSoT (Single Source of Truth) im Theme.

---

## 5. Themes & Plugins — die zwei Hebel der Anpassung

### Theme — bestimmt, **wie** die Seite aussieht

Ein Theme ist ein Paket aus PHP-Templates, CSS, JavaScript, Bildern. Wechselst du das Theme, ändert sich das gesamte Aussehen — Inhalte bleiben.

**Bei dir:**
- Theme-Name: `praxiszentrum`
- Pfad: `/wp-content/themes/praxiszentrum/`
- Eigenes Theme, nicht von der Stange — von uns gebaut + angepasst
- Aktueller Stand: **PXZ 2.7.35** (siehe [[praxis-webseite]])
- Eigenes Git-Repo direkt im Theme-Ordner

### Plugin — bestimmt, **was** die Seite zusätzlich kann

Ein Plugin ist eine PHP-Erweiterung, die spezielle Funktionen ergänzt:
- Cookie-Banner
- Kontaktformular
- WPML (Mehrsprachigkeit)
- SEO-Tools
- Caching, Backup, Sicherheit

**Bei dir aktive Plugins (Auszug):**
- **WPML** — Mehrsprachigkeit (DE, EN, ES, FR)
- **Blocksy** — Theme-Companion (Cookie-Banner, kleine Helper)
- diverse weitere — Liste in `wp plugin list`

> **Faustregel:** Mehr Plugins = mehr Sicherheits-Risiko + mehr Updates. Praxis-Plugins regelmäßig prüfen, inaktive löschen.

---

## 6. Wie ein Page-Aufruf konkret abläuft

Wenn ein Patient `westend-hausarzt.com/team/` aufruft:

```
1. DNS löst westend-hausarzt.com zu domainfactory-Server-IP auf
2. Server empfängt HTTP-Request für /team/
3. WordPress-Bootstrap (index.php → wp-load.php) startet
4. WordPress findet Page mit Slug "team" in der Datenbank
5. Lädt das passende Template aus deinem Theme:
     a) page-team.php  (falls existiert)
     b) sonst page.php
     c) sonst index.php
6. Template ruft die WP-Funktionen auf:
     get_header() → header.php des Themes
     the_content() → den Inhalt aus der Page
     get_footer() → footer.php des Themes
7. Plugins haken sich bei "Hooks" ein
     (z. B. WPML hängt Sprach-Switcher in den Header)
8. Resultat-HTML wird zurückgeschickt → Browser zeigt es an
```

Mehr Tiefe in [[08-wp-page-templates-und-auto-discovery|WP 08 — WP-Page-Templates]].

---

## 7. WP-Admin — was du im Browser sehen kannst

Aufrufbar unter: `https://westend-hausarzt.com/wp-admin/`

| Bereich | Was tust du da? |
|---|---|
| **Dashboard** | Übersicht, Updates-Hinweise |
| **Beiträge / Posts** | Blog-Beiträge (bei dir wenig genutzt) |
| **Seiten / Pages** | **Hauptbereich für dich:** „Team", „Leistungen", „Kontakt" pflegen |
| **Medien** | Bilder, PDFs, Videos hochladen |
| **Design / Customizer** | Theme-Einstellungen, Menüs, Widgets, Custom-CSS |
| **Plugins** | Plugins aktivieren/deaktivieren/aktualisieren |
| **Benutzer** | Konten, Rollen (Admin / Redakteur / Autor / Abonnent) |
| **Einstellungen** | URL, Datum, Uhrzeit, Permalinks, Diskussion |
| **WPML** (Plugin) | Übersetzungen verwalten, Sprachen-Setup |

**Dein Admin-User:** vermutlich `stracke` o. ä. mit Rolle „Administrator".

---

## 8. Lokale Entwicklungs-Umgebung — Local by Flywheel

Du hast WordPress nicht nur in Produktion (domainfactory), sondern auch
**lokal** auf Cluster-Mini-02:

| Umgebung | Wo läuft es? | Wofür? |
|---|---|---|
| **Prod** | domainfactory, `westend-hausarzt.com` | Live-Webseite für Patienten |
| **Dev** | Local by Flywheel auf Cluster-Mini-02 | Testen, Entwickeln, Migrieren |

**Local-Pfad zu deinem Theme:**
```
/Users/cluster-mini-02/Local Sites/gpmedicalcenterwestend-…/
  app/public/wp-content/themes/praxiszentrum/
```

Local-URL (Browser):
```
https://gpmedicalcenterwestend-….local/
```

**Workflow:**
1. Änderungen lokal in Local by Flywheel testen
2. Wenn sauber → ins Theme-Git committen
3. Deploy auf Prod (manuell via SFTP oder automatisierter Sync)

---

## 9. WP-CLI — die Kommandozeile für WordPress

`wp-cli` ist ein Terminal-Tool, mit dem du WordPress-Datenbank und -Inhalte
**ohne Browser** ansprechen kannst. Riesiger Zeitgewinn bei wiederholten
Aufgaben.

**Beispiel — alle Pages auflisten:**

```bash
wp post list --post_type=page --fields=ID,post_title,post_name,post_status \
   --format=csv \
   --path='/Users/cluster-mini-02/Local Sites/.../app/public'
```

**Praktische Use-Cases bei dir:**

| Aufgabe | Befehl |
|---|---|
| Plugin-Liste exportieren | `wp plugin list --status=active` |
| URL global ersetzen (Migration) | `wp search-replace alt.de neu.de --all-tables` |
| Cache leeren | `wp cache flush` + `wp transient delete --all` |
| Sprache abfragen | DB direkt: `wp_icl_languages`-Tabelle |
| Page mit ID 9701 inspizieren | `wp post get 9701` |

Auf Cluster-Mini-02 ist wp-cli über Local by Flywheel verfügbar.

---

## 10. REST-API — der Programm-Zugang

WordPress bietet eine **REST-API** unter `/wp-json/`. Damit kannst du Inhalte
programmgesteuert lesen und schreiben — JSON statt HTML.

**Beispiel — alle Pages als JSON:**
```
https://westend-hausarzt.com/wp-json/wp/v2/pages
```

**Authentifizierung** für schreibende Aufrufe via **Application Passwords**
(seit WordPress 5.6 eingebaut). Mehr in
[[04-wp-rest-api-adapter-mit-application-passwords|WP 04]].

> **Sicherheit:** Application Passwords sind nicht dein Admin-Passwort. Werden bei Verlust/Kompromittierung einzeln revoked. Niemals committen, nicht im Klartext speichern. Siehe [[GLOBAL_RULES]] §Secrets.

---

## 11. Häufige Praxis-Probleme (mit Lösungs-Verweis)

| Problem | Wo das hilft |
|---|---|
| Plugin lässt sich nicht deinstallieren / hängt | [[10-wp-plugin-sicher-entfernen\|WP 10]] |
| Alte Slugs sollen weiterhin auf neue weiterleiten | [[18-wp-nested-pages-und-old-slug-redirects\|WP 18]] |
| Mehrere Render-Quellen erzeugen Doppel-Inhalte | [[Webentwicklung/Webdesign/10-doppelte-render-quellen-aufspueren\|Webdesign 10]] |
| Mojibake (`Ã¤` statt `ä`) in Datenbank | [[12-utf8-mojibake-und-trunk-ready-inventar\|WP 12]] |
| Footer überschreibt eigene Styles | [[20-blocksy-footer-override\|WP 20]] |
| 200 alte Pages migrieren | [[Arbeitsweise & Prozess/08-content-archive-triage\|Arbeitsweise 08]] + [[13-content-archive-md5-contract\|WP 13]] |
| Bridge-Pages zwischen Praxis und Juvantis | [[15-bridge-pages-trunk-rendered\|WP 15]] |

> Die WordPress-Domäne hat seit Sprint F2 Reorg (2026-05-05) **22 Module**
> Praxis-Lessons aus dem Praxis-Webseiten-Sprint. Generische CSS/Token-/
> Type-Scale-Module liegen weiter unter [[Webdesign Grundlagen]].

---

## 12. Module dieser Domäne

**Lernreihenfolge nach Block:** [[LERNPFAD]] — geordnet nach Lifecycle,
Setup, Content-Migration, REST-API, Theme/Templates, Render-Quellen,
Navigation, Verify/Tests.

**Vollständige Liste (22 Module):**

- [[01-db-cleanup-fallstricke|01 — DB-Cleanup-Fallstricke]]
- [[02-manueller-deploy-host-server|02 — Manueller Deploy zum Host-Server]]
- [[03-git-bootstrap-und-page-registry|03 — Git-Bootstrap und Page-Registry]]
- [[04-wp-rest-api-adapter-mit-application-passwords|04 — WP-REST-API-Adapter mit Application Passwords]]
- [[05-review-pipeline-und-local-wp-tests|05 — Review-Pipeline und Local-WP-Tests]]
- [[06-cross-repo-subsumption-mit-git-subtree|06 — Cross-Repo-Subsumption mit Git-Subtree]]
- [[07-seiten-inventar-website-relaunch|07 — Seiten-Inventar bei Website-Relaunch]]
- [[08-wp-page-templates-und-auto-discovery|08 — WP-Page-Templates und Auto-Discovery]]
- [[09-verify-probe-architektur-und-wp-rewrite-grenze|09 — Verify-Probe-Architektur und WP-Rewrite-Grenze]]
- [[10-wp-plugin-sicher-entfernen|10 — WP-Plugin sicher entfernen]]
- [[11-seo-und-header-branding-im-theme|11 — SEO und Header-Branding im Theme]]
- [[12-utf8-mojibake-und-trunk-ready-inventar|12 — UTF8-Mojibake und Trunk-ready-Inventar]]
- [[13-content-archive-md5-contract|13 — Content-Archive mit MD5-Contract]]
- [[14-single-source-of-truth-fuer-stammdaten|14 — Single Source of Truth für Stammdaten]]
- [[15-bridge-pages-trunk-rendered|15 — Bridge-Pages aus Common Trunk gerendert]]
- [[16-navigation-restrukturierung-und-mobile-drawer|16 — Navigation-Restrukturierung und Mobile-Drawer]]
- [[17-detail-pages-mit-cross-navigation|17 — Detail-Pages mit Cross-Navigation]]
- [[18-wp-nested-pages-und-old-slug-redirects|18 — WP-Nested-Pages und Old-Slug-Redirects]]
- [[19-template-parts-mit-is-page-guard|19 — Template-Parts mit is_page-Guard]]
- [[20-blocksy-footer-override|20 — Blocksy-Footer-Override]]
- [[21-theme-render-source-vor-db-schreiben|21 — Theme-Render-Source vor DB-Schreiben]]
- [[22-detail-page-mirror-shopify-zu-wp|22 — Detail-Page-Mirror Shopify zu WP]]

---

## 13. Glossar — Fachbegriffe

> Alle Begriffe, die in diesem Tutorial oder in Code-Sessions zur Praxis-Webseite
> auftauchen. Nach Themenfeld geordnet.

### URLs & Routing
| Begriff | Bedeutung |
|---|---|
| **Slug** | URL-Teil hinter der Domain: `/team/` → Slug ist `team`. Ist immer ASCII (keine Umlaute), damit Linux-Server und Git-Tools sauber damit umgehen. |
| **Permalink** | Vollständige URL einer Page/Post. Bei dir: `/%postname%/`-Struktur (also direkt der Slug ohne Datum-Präfix). |
| **Permalink-Cache / Rewrite Rules** | WordPress merkt sich für jede URL, welcher Page sie gehört. Diese Liste liegt in `wp_options.rewrite_rules` und muss neu generiert werden, wenn Pages direkt in der DB angelegt werden. |
| **Page-Slug-Konflikt** | Mehrere Posts mit identischem `post_name` — WordPress wählt dann eine, die anderen werden ignoriert oder bekommen Suffix `-2`. |

### WordPress-Datenbank
| Begriff | Bedeutung |
|---|---|
| **wp_posts** | DB-Tabelle für **alle** Inhalte: Pages, Posts, Revisionen, Anhänge (Media), sogar Forms (WPForms-Plugin). |
| **wp_postmeta** | DB-Tabelle für Custom Fields und Metadaten an Posts/Pages (z. B. `_wp_page_template` = welche Template-Datei genutzt wird). |
| **wp_options** | DB-Tabelle für globale Einstellungen (Permalink-Struktur, aktiver Theme, Plugin-Konfig etc.). |
| **post_status** | Zustand eines Eintrags: `publish` (öffentlich), `draft` (Entwurf), `private` (nur für Eingeloggte), `trash` (Papierkorb), `inherit` (für Revisionen). |
| **Revision** | WordPress speichert bei jeder Speicherung einer Page eine Kopie der Vor-Version (post_type=`revision`). Sammelt sich an, kann beim Pages-Löschen mit weggeräumt werden. |

### Themes & Templates
| Begriff | Bedeutung |
|---|---|
| **Theme** | Komplettpaket: Design + Templates + CSS + JS, das das Aussehen der Website bestimmt. |
| **Parent-Theme / Child-Theme** | Parent = Basis (bei dir: Blocksy). Child = Anpassungen drüber (bei dir: `praxiszentrum`). Updates am Parent zerstören das Child nicht. |
| **Template** | Eine `.php`-Datei, die für einen bestimmten Page-Typ das HTML rendert. Beispiele: `template-homepage.php` für die Startseite, `template-team.php` für /team/, `single.php` für einzelne Posts. |
| **Template-Hierarchie** | Reihenfolge, in der WP Templates findet: `page-{slug}.php` → `page-{ID}.php` → `template-XXX.php` (wenn Page das gewählt hat) → `page.php` → `index.php`. |
| **Page-Template** | Wenn eine Page-Datei mehrere Templates anbietet (in PHP-Header `Template Name: ...`), kann man im WP-Admin eines auswählen. Wird in `wp_postmeta._wp_page_template` gespeichert. |
| **Template-Part** | Wiederverwendbares HTML-Fragment in `template-parts/<name>.php`, das mehrere Templates per `get_template_part('template-parts/<name>')` einbinden. Bei dir: `template-parts/loc-main.php` rendert den Hauptpraxis-Container auf Home + auf `/standorte/`. Eine Änderung wirkt überall. |
| **`functions.php`** | Zentrale PHP-Datei eines Themes, in der CSS/JS geladen wird, Hooks registriert werden, Konstanten definiert sind. |
| **Theme-Versionierung (z. B. `PXZ_VERSION`)** | Konstante, die bei jeder CSS-/JS-Änderung hochgezählt wird. WP hängt sie als `?ver=2.7.50` an Asset-URLs → Browser holt frische Datei statt Cache. |

### Hooks & Plugins
| Begriff | Bedeutung |
|---|---|
| **Hook** | Punkt im Code, an dem Plugins/Themes „andocken" können. Zwei Sorten: **Action Hooks** (etwas tun) und **Filter Hooks** (Daten verändern). |
| **`pre_get_posts`** | Filter Hook, mit dem Plugins/Themes WP-Datenbankabfragen manipulieren — kann z. B. Pages aus Suchergebnissen ausschließen. |
| **`parse_request`** | Action Hook, der vor der Page-Auflösung läuft — wird oft für Redirects benutzt (z. B. unsere `inc/redirects.php` für Legacy-URLs). |
| **Plugin** | Erweiterungs-Paket im `wp-content/plugins/`-Ordner, kann beliebig viel Funktionalität ergänzen (Forms, SEO, Caching, Sicherheit etc.). |
| **Shortcode** | Platzhalter wie `[gallery]` im Page-Inhalt, den ein Plugin in HTML umwandelt. |

### Custom Fields & Datenpflege
| Begriff | Bedeutung |
|---|---|
| **Custom Field / Metafield** | Zusatz-Datenfeld an Posts/Pages (z. B. „Eyebrow-Text", „Subtitle"). Wird in `wp_postmeta` gespeichert. |
| **ACF (Advanced Custom Fields)** | Plugin, das schöne Eingabe-Felder im WP-Admin baut (z. B. „Hero-Subtitle"-Feld unter jeder Page). Bei dir aktuell **nicht** im Einsatz. |
| **Theme-Customizer** | Globale Theme-Einstellungen (Logo, Farben) — separater Editor unter „Design → Customizer". Bei dir kaum genutzt, weil alles im Code. |
| **Single Source of Truth (SSoT)** | Architektur-Prinzip: jede Information existiert genau einmal, alle anderen Stellen referenzieren sie. Beispiel: Telefonnummer steht **nur** in `inc/practice-data.php`, nicht 5× im Code. |

### Editoren
| Begriff | Bedeutung |
|---|---|
| **Gutenberg / Block Editor** | Moderner WP-Editor mit Blöcken (Absatz, Überschrift, Bild, Spalten etc.). Standard seit WP 5.0. |
| **Classic Editor** | Alter Editor: eine große Textbox mit Word-ähnlicher Toolbar (TinyMCE). Über Plugin nachrüstbar. |
| **WPForms** | Form-Builder-Plugin (Kontakt-Formulare, Fragebögen). Forms sind eigene Posts mit `post_type=wpforms`. |

### CLI & Workflow
| Begriff | Bedeutung |
|---|---|
| **WP-CLI** | Kommandozeilen-Werkzeug für WordPress: `wp post create --post_type=page --post_status=publish ...`. Macht alles, was WP-Admin auch kann — schneller und scriptbar. |
| **Local by Flywheel** | Mac-App, die lokal eine WP-Installation hochfährt (PHP + MySQL + Apache). Bei dir genutzt für die `*.local`-URL deiner Test-Site. |
| **SFTP** | Sicheres Datei-Upload-Protokoll. Theme-Files (PHP/CSS/JS) werden per SFTP von Local nach Live gepusht. |
| **DB-Sync (Pull/Push)** | Datenbank-Inhalt zwischen Local und Live abgleichen. Tools: WP Migrate DB Pro, Local-by-Flywheel-Push, manueller mysqldump. |
| **`flush_rewrite_rules()`** | WP-Funktion, die nach Page-Änderungen die Permalink-Caches neu aufbaut. Wird automatisch beim Speichern einer Page im Admin aufgerufen. |

### Mehrsprachigkeit
| Begriff | Bedeutung |
|---|---|
| **WPML** | Plugin für mehrsprachige WordPress-Sites. Bei dir aktiv mit 6 Sprachen seit S63 (2026-05-02): DE/EN/FR/ES/IT/pt-PT. Cluster-Sweep-Pattern + Hard-Delete-Cleanup für Bulk-Übersetzungen: `Nexus/_memory/patterns/wpml-bridge-cluster-import.md`. |
| **trid** | „Translation-ID" in WPML — alle Sprach-Varianten einer Page tragen dieselbe trid; so weiß WPML, dass DE-Page X und EN-Page Y dasselbe Original meinen. Tabelle: `wp_icl_translations`. |
| **i18n / l10n** | „Internationalization" / „Localization" — Software-Begriffe für Mehrsprachigkeit. |
| **NFD/NFC-Falle** | macOS speichert Umlaute „zerlegt" (`ä` = `a` + `¨`), Linux erwartet „vorkomponiert". Slugs deshalb immer ASCII halten — sonst Konflikte beim Git-Sync. |

### Sonstiges
| Begriff | Bedeutung |
|---|---|
| **Multisite** | Eine WP-Installation, viele Webseiten in einem Netzwerk. Bei dir **nicht** aktiv. |
| **Kategorie / Tag** | Gruppierungs-Mechanismen für Posts (Blog-Beiträge), nicht für Pages. |
| **`wp-content/uploads/`** | Ordner, in dem alle hochgeladenen Bilder landen, sortiert nach `JJJJ/MM/`. Bei dir liegen die Arzt-Fotos unter `2026/04/`. |
| **Mojibake** | Defekt dargestellte Sonderzeichen wie `Á…` oder `?` statt `ä/ö/ü/ß`. Entsteht durch UTF-8↔Win-1252-Doppelkonvertierung in alten DB-Migrationen. Reparatur: Hex-Inspektion + gezielter `str_replace` via WP-Bootstrap, BINARY-LIKE für die Verifikation (sonst false positives durch Collation). |
| **PHP-Serialisierung** | `wp_options`-Werte mit Arrays werden als `s:78:"…"`-Strings gespeichert (Längenangabe in Bytes). Direktes SQL-REPLACE bricht die Längenangabe → Plugin-Crash. **Immer** über `update_option()` per Bootstrap-Skript ändern (re-serialisiert sauber). |

---

## 13b. Mehrsprachigkeit (i18n) — Architektur am Beispiel Praxis-Webseite

Die Praxis-Webseite läuft seit S63/S64 (Mai 2026) in **6 Sprachen**:
DE, EN, FR, ES, IT, pt-PT. Dafür sind zwei separate Entscheidungen
nötig — sie werden in der Praxis oft verwechselt:

| Achse | Was wird entschieden? | Hier gewählt |
|---|---|---|
| **Übersetzungs-Engine** | Wer übersetzt die Texte? | **Claude direkt** (kontextuell, Sie-Form, HWG-konform) |
| **Strukturträger** | Wer verwaltet Sprach-Switcher, Page-Duplikate, URL-Routing? | **WPML-Plugin** (kein WPML-AT-Add-on nötig) |

> [!info] Warum getrennt: Wenn jemand „kein WPML" sagt, kann das (a)
> nur die kostenpflichtige Übersetzungs-Maschine WPML-AT meinen oder (b)
> WPML komplett — zwei sehr verschiedene Architekturen. Immer
> nachfragen.

### Die vier Layer

1. **Layer 1 — WPML-Plugin (Strukturträger):** Sprach-Switcher im
   Header, URL-Routing `/en/...` `/fr/...`, `ICL_LANGUAGE_CODE`-
   Konstante, Page-Duplikate via `wp_icl_translations.trid`.
2. **Layer 2 — Glossar (`inc/i18n-glossary.php`):** 92 medizinisch-
   juristische Begriffe × 6 Sprachen mit Helper `pxz_g($key, $lang)`.
   „Praxisgemeinschaft" → EN „shared medical practice" (NICHT „joint
   practice", andere Rechtsform!). Konsistenz-Versicherung über alle
   Pages.
3. **Layer 3 — Stammdaten-Files:** `inc/<file>.php` mit
   `pxz_<file>_strings($lang)` Lookup-Tabelle. Render liest
   `pxz_current_lang()` (DE-Fallback). 11 Stammdaten-Files (Nav, Footer,
   Practice-Daten, Homepage, Team, Diagnostik, Cookie-Consent, SEO,
   Service-Forms, Termin-Anfrage, Glossar) sind so aufgebaut.
4. **Layer 4 — Page-Inhalte:** WPML-Page-Duplikate; Inhalt von Claude
   direkt geschrieben (mit Glossar-Konsistenz), per `wp post update`
   publiziert.

**Code-Pattern für jedes Daten-File:**

```php
function pxz_x_strings( $lang = 'de' ) {
    $tables = [
        'de' => [ 'title' => 'Termin anfragen', /* … */ ],
        'en' => [ 'title' => 'Request appointment', /* … */ ],
        // … fr, es, it, pt-pt
    ];
    return $tables[ $lang ] ?? $tables['de'];
}

function pxz_x_render() {
    $lang = pxz_current_lang();
    $S    = pxz_x_strings( $lang );
    echo esc_html( $S['title'] );
}
```

**Detail-Pattern:** `Nexus/_memory/patterns/wp-theme-i18n-claude-engine-wpml-shell.md`.

### Translation-Pages anlegen — wenn WPMLs Standard-Werkzeug nicht reicht

Sobald viele Pages Cluster-weise in eine neue Sprache gebracht werden
sollen, stößt das WPML-UI an drei Grenzen:

1. **Slug-Identität:** Templates wie `template-arzt.php` identifizieren
   ihren Render-Kontext über `get_post()->post_name`. Eine EN-Page muss
   daher den **gleichen Slug** wie die DE-Page haben — sonst findet das
   Template ihren Doctor nicht. WPMLs UI vergibt aber suffixierte Slugs
   (`dr-stracke-2`), und auch `wp_insert_post()` ruft intern
   `wp_unique_post_slug()`. **Lösung:** Direct-DB-Insert in `wp_posts`
   umgeht diesen Mechanismus.
2. **Self-Render-Templates:** Templates, die ihre Inhalte aus internen
   PHP-Sprach-Arrays rendern (Pattern aus §13b oben), ignorieren
   `post_content`. Für solche Pages reicht eine reine WPML-Brücke ohne
   Inhalts-Übersetzung — die Sprach-Texte stecken bereits im Theme-Code.
   **Audit vor Insert:** `grep -l "pxz_current_lang" template-*.php`
   findet diese Templates.
3. **Standard-Templates** mit `the_content()` und `pxz_*`-Postmeta
   brauchen Volltext-Übersetzung beider Schichten — Postmeta-Overrides
   im Skript + `post_content` als HEREDOC.

**Bridge-Skript-Pattern** (idempotent, Re-runnable):

```php
// 1. wp_posts (direkt, behält DE-Slug)
$wpdb->insert( $wpdb->posts, [
    'post_status'  => 'publish',
    'post_name'    => $de_slug,        // identisch zu DE
    'post_title'   => $en_title,
    'post_content' => $en_content,     // leer für Self-Render
    'post_type'    => 'page',
    // … weitere Felder
] );
$en_id = $wpdb->insert_id;

// 2. wp_postmeta (kopieren mit Overrides)
foreach ( $de_postmeta as $key => $value ) {
    if ( in_array( $key, ['_wpml_word_count', '_edit_lock'], true ) ) continue;
    update_post_meta( $en_id, $key, $overrides[$key] ?? $value );
}

// 3. wp_icl_translations (gleiche trid, language_code='en')
$wpdb->insert( "{$wpdb->prefix}icl_translations", [
    'element_type'         => 'post_page',
    'element_id'           => $en_id,
    'trid'                 => $de_trid,    // identisch
    'language_code'        => 'en',
    'source_language_code' => 'de',
] );
```

**Sicherheits-Pflicht:**
- DB-Backup vor Insert: `mysqldump wp_posts wp_postmeta wp_icl_translations`
  in `<projekt>/_backups/<sprint>/`
- Dry-Run-Modus mit `--commit`-Gate (Skript zeigt erst PLAN)
- Idempotenz-Test (Re-Run = alle Pages „EXISTS")

**WP-CLI-Falle:** wp-cli 2.12.0 ist mit PHP 8.4 broken
(Deprecation-Spam, STDOUT/STDERR-Mix). Direct-MySQL-Socket via
Local-by-Flywheel Lightning-Services (`/Applications/Local.app/.../mysql-8.0.35+4/bin/.../mysql`)
ist der robuste Weg.

**Lokales Routing-Caveat:** `?lang=en` kann lokal durch AIOSEO-Canonical
zu DE redirecten, während Live korrekt antwortet. Browser-Smoke-Test bei
Routing-Bug entweder via Cookie-Switch oder nach Live-Deploy.

**Vorlage:** `~/Cortex/projects/Cortex-Web/sites/praxis-webseite/tools/s65-en-cluster-praxisgemeinschaft.php`
**Pattern-Datei:** `Nexus/_memory/patterns/wpml-bridge-cluster-import.md` (S65, 2026-05-02).

---

## 13c. Theme-AJAX — `wp_ajax_*` und `wp_localize_script`

Forms im Theme, die per JavaScript an WordPress submitten (z. B. das
Termin-Anfrage-Modal aus S62), nutzen WordPress' eigenen AJAX-Endpoint
`admin-ajax.php`. **Kein eigener REST-Endpoint, kein externer Service.**

**Schritt 1 — Handler im Theme registrieren:**

```php
add_action( 'wp_ajax_pxz_termin_submit',        'pxz_termin_handle_submit' );
add_action( 'wp_ajax_nopriv_pxz_termin_submit', 'pxz_termin_handle_submit' );

function pxz_termin_handle_submit() {
    // 1. Nonce-Check (CSRF-Schutz)
    if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'pxz_termin_submit' ) ) {
        wp_send_json_error( [ 'message' => 'Token expired' ], 400 );
    }
    // 2. Honeypot (Bot-Schutz)
    if ( ! empty( $_POST['company_url'] ) ) {
        wp_send_json_success( [ 'message' => 'ok' ] ); // silent ack
    }
    // 3. Validation, Mail-Versand …
    wp_send_json_success( [ 'message' => 'OK' ] );
}
```

> [!warning] Beide Hooks pflichtig: `wp_ajax_<action>` für eingeloggte
> Nutzer, `wp_ajax_nopriv_<action>` für Besucher ohne Login. Wer den
> nopriv-Hook vergisst, bekommt 0-Byte-Antwort für Patienten und merkt
> es nur im Praxis-Test.

**Schritt 2 — JS bekommt die AJAX-URL via `wp_localize_script`:**

```php
add_action( 'wp_enqueue_scripts', function() {
    if ( ! wp_script_is( 'pxz-termin', 'enqueued' ) ) return;
    wp_localize_script( 'pxz-termin', 'pxzTermin', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
    ] );
}, 50 );
```

**Schritt 3 — JS submittet:**

```javascript
fetch( pxzTermin.ajaxUrl, {
    method: 'POST',
    body: new FormData( formElement ),
} ).then( r => r.json() );
```

**Sicherheits-Trio:**
- **Nonce** — gegen Cross-Site-Request-Forgery (CSRF). `wp_create_nonce()`
  beim Render, `wp_verify_nonce()` im Handler. 24 h gültig.
- **Honeypot** — versteckt-positioniertes Input-Feld. Echte Nutzer füllen
  es nie aus, Bots schon. Handler antwortet bei Befüllung mit
  silent-success — Bot denkt, alles ok, Praxis-Mailbox bleibt leer.
- **Rate-Limit / Sanitize** — `sanitize_text_field()`, `is_email()`,
  `wp_unslash()` vor jeder Verarbeitung; `wp_kses_post()` bei HTML-
  Ausgabe.

**Pattern-Datei:** `Nexus/_memory/patterns/wp-modal-mail-cta-individualized.md`
(S62) — vollständiges Modal-CTA-Pattern mit IGeL-Klausel, GKV/PKV-
Logik und Bestätigungs-Mail.

---

## 14. Lern-Reihenfolge

1. **Diese Seite** — die Konzepte
2. [[Webentwicklung Grundlagen]] — Web-Stack-Hintergrund
3. [[LERNPFAD]] — strukturierter Pfad durch die 22 Praxis-Module
4. [[Webdesign Grundlagen]] — generische Webdesign-Module (12)
5. [[Terminal/02-git|Terminal 02 — Git]] — für Theme-Versionierung

---

## Verwandte Notizen

- [[_MOC Tutorials]] — Dach-MOC aller Tutorials
- [[_Basiswissen Schnelleinstieg]] — Pfad „Web-Programmierung von 0 auf 1"
- [[LERNPFAD]] — Lernpfad für diese Domäne
- [[Webentwicklung Grundlagen]] — Dach-Verteiler
- [[Webdesign Grundlagen]] — generische CSS/Token/Type-Scale-Module
- [[praxis-webseite]] — Projekt-Notiz
- [[Cortex-Web]] — Common-Trunk-Dachprojekt
- [[Sicherheit & Datenschutz Grundlagen]] — DSGVO-relevant für Patientendaten
