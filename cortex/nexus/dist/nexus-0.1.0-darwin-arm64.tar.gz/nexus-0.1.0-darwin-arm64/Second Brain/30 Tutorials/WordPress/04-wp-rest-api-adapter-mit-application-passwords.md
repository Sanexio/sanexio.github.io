# 06 — WordPress-REST-API-Adapter mit Application Passwords

> **Wofür:** Ein externes Programm (Skript, Build-Pipeline, mobile App) soll
> Inhalte in WordPress anlegen oder ändern, **ohne** Zugangsdaten des normalen
> Admin-Logins zu verwenden und **ohne** durch die Klick-Oberfläche des WP-Admin
> gehen zu müssen.
>
> **Praxis-Bezug:** Cortex-Web Phase 1 (2026-04-18): Das Skript
> `tools/sync-wp.sh` liest eine YAML-Datei aus dem Trunk und erstellt daraus
> eine WordPress-Page auf der lokalen `westend-hausarzt.com`-Entwicklungsseite.
> Die Arbeitsweise ist stellvertretend für jede Pipeline, die aus einer
> Content-Quelle heraus WP befüllt.

---

## Warum überhaupt ein Zweit-Schlüssel?

Bis WordPress 5.5 konnten Programme sich einfach mit **demselben** Passwort
anmelden, das Sie auch im Login-Formular eingeben. Das ging über einen
HTTP-Header namens `Authorization: Basic ...`. Ab WordPress 5.6 blockiert WP
das aus Sicherheitsgründen: Ein Skript, das mit Ihrem echten Login-Passwort
kompromittiert wird, würde sonst den kompletten Admin-Zugang verlieren lassen.

Seitdem gilt:

- **Login-Passwort** = für den Menschen am Browser
- **Application Password** = für Programme, pro Zweck ein eigenes, einzeln
  widerrufbar, wird niemals ins Login-Formular getippt

Beide Passwörter gehören zu demselben WP-Benutzer. Widerrufen Sie später das
Application Password, bleibt Ihr Login-Passwort unverändert. Das ist die
ganze Idee: **Schlüssel-Trennung pro Einsatzzweck**.

---

## Anatomie eines REST-API-Aufrufs

Die WordPress REST API ist eine Schnittstelle, die unter der URL
`https://<ihre-site>/wp-json/wp/v2/...` erreichbar ist. Jede Ressource
(Seiten, Beiträge, Benutzer, Medien …) hat dort einen eigenen Pfad:

| Pfad | Zweck |
|------|-------|
| `/wp-json/wp/v2/pages` | Seiten (Pages) |
| `/wp-json/wp/v2/posts` | Beiträge (Posts) |
| `/wp-json/wp/v2/users/me` | der aktuell angemeldete Benutzer |
| `/wp-json/wp/v2/media` | hochgeladene Mediendateien |

Ein Adapter-Programm macht drei Arten von Aufrufen:

- **GET** — Lesezugriff. Beispiel: „Gibt es eine Seite mit dem Slug
  `basic-check`?" → `GET /wp/v2/pages?slug=basic-check`.
- **POST** — etwas Neues anlegen. Beispiel: „Lege eine neue Seite an."
- **PUT** — etwas Bestehendes ändern. Beispiel: „Aktualisiere Seite 9668."

Der `Authorization`-Header wird bei jedem dieser Aufrufe mitgeschickt. Er ist
die Eintrittskarte. Fehlt er oder ist er ungültig, antwortet WP mit
`401 rest_not_logged_in`.

---

## Application Password anlegen — Schritt für Schritt

1. Im WordPress-Admin einloggen (normaler Benutzername + normales
   Login-Passwort)
2. Links in der Seitenleiste **Benutzer → Profil** oder oben rechts auf den
   eigenen Namen → **Profil bearbeiten**
3. Auf der Profilseite ganz nach unten scrollen, bis der Abschnitt
   **„Anwendungspasswörter"** (engl. „Application Passwords") erscheint
4. Textfeld „Neuer Name des Anwendungspassworts" → z. B. `cortex-web-adapter`
   eintippen. Der Name ist nur ein Label, damit Sie später wissen, welches
   Passwort zu welchem Programm gehört
5. Button **„Neues Anwendungspasswort hinzufügen"** klicken
6. In einem **gelb hinterlegten Kasten** erscheint jetzt ein 24-Zeichen-Passwort
   in sechs Blöcken, z. B. `ABcd 1234 eFGh 5678 ijKL 9012`
7. **Sofort kopieren.** Das Passwort wird nur dieses eine Mal angezeigt —
   danach ist es in WP nur noch als Hash gespeichert. Haben Sie es verloren,
   müssen Sie den Eintrag widerrufen und ein neues erzeugen

Dieses Passwort enthält **nur Buchstaben und Ziffern** (Buchstaben gemischt,
keine Sonderzeichen wie `%`, `!`, `(`). Das ist der Code von
`wp_generate_password( 24, false )`. Wenn Sie ein Passwort sehen, das
Sonderzeichen enthält, stammt es nicht aus dieser Funktion.

---

## Das Passwort in den Adapter einbringen

Im Cortex-Web-Repo liegt eine Datei `.env.local.template`. Sie enthält die
„Form" der Zugangsdaten, aber keine Werte:

```
WP_REST_BASE=http://...site.local/wp-json
WP_USER=
WP_APP_PASSWORD=
```

Kopie anlegen:

```bash
cp .env.local.template .env.local
```

Werte eintragen. Das App-Password mit doppelten Anführungszeichen umschließen,
damit die Leerzeichen erhalten bleiben:

```
WP_USER=sstracke
WP_APP_PASSWORD="ABcd 1234 eFGh 5678 ijKL 9012"
```

Die Datei `.env.local` ist in `.gitignore` ausgeschlossen — sie wandert
**niemals** ins Repo. Das Template bleibt im Repo, damit man sieht, was
benötigt wird.

Smoke-Test:

```bash
cd Cortex-Web
set -a; . ./.env.local; set +a
curl -s -u "$WP_USER:$WP_APP_PASSWORD" "$WP_REST_BASE/wp/v2/users/me"
```

Erwartete Antwort: JSON mit `id`, `name`, `slug`. Bei `401 rest_not_logged_in`
siehe „Häufige Fehler" weiter unten.

---

## Idempotenz — warum der Adapter „zweimal laufen darf"

Ein typischer Content-Pipeline-Fehler: Beim zweiten Lauf entstehen Duplikate.
Ein gut gebauter Adapter beweist durch seine Architektur, dass das nicht
passieren kann.

Im Cortex-Web-Adapter ist das Muster:

```
1.  GET /wp/v2/pages?slug=basic-check
        → []          (keine existiert)  →  POST /pages (erzeugt neu)
        → [{ id: 9668 }]  (eine existiert) →  PUT /pages/9668 (aktualisiert)
        → mehr als eine   →  ABBRUCH (mehrdeutig, nie automatisch raten)
```

Der **Slug** ist der stabile Identifikator. Die Slug-Quelle ist im Trunk das
Feld `id` in der YAML-Datei. Ändert sich `id` nicht, bleibt die Page-ID
stabil. Zweiter, dritter, hundertster Lauf ändern die gleiche Page.

---

## Was Content-Felder im POST/PUT-Payload bedeuten

```json
{
  "slug":   "basic-check",
  "title":  "Laborcheck Basis — Informationen",
  "content": "<!-- wp:paragraph --><p>…</p>…",
  "status": "publish",
  "meta":   { "_cortex_web_source": "trunk/…/basic-check.yaml" }
}
```

- **`slug`** — Teil der URL (`/basic-check/`)
- **`title`** — Seitentitel (Browser-Tab, H1-Fallback)
- **`content`** — der Seiteninhalt. WordPress erwartet hier **Gutenberg-HTML**,
  also HTML mit `<!-- wp:… -->`-Kommentaren, die den Block-Typ ankündigen.
  Das ist wichtig: Wenn man reines HTML ohne diese Kommentare schickt, landet
  alles in einem einzigen „HTML"-Block und lässt sich im Editor schlecht
  weiterbearbeiten
- **`status`** — `publish`, `draft`, `pending` …
- **`meta`** — benutzerdefinierte Metadaten. `_cortex_web_source` dient später
  zur Rückverfolgung: Welche Trunk-Datei hat diese Page erzeugt?

---

## Häufige Fehler und ihre Ursachen

### `401 rest_not_logged_in` trotz korrektem Passwort

Wahrscheinlich eine **der drei Layer-Probleme** beim Zusammenspiel
nginx ↔ PHP ↔ WordPress:

1. **nginx reicht den `Authorization`-Header nicht an PHP weiter.** Apache
   macht das automatisch, nginx nicht. Man erkennt es daran, dass ein
   Probe-Script `$_SERVER['HTTP_AUTHORIZATION']` als leer ausgibt, obwohl
   `curl` den Header sendet
2. **PHP setzt `$_SERVER['PHP_AUTH_USER']` und `$_SERVER['PHP_AUTH_PW']` nicht
   automatisch** — das macht nur Apache's `mod_auth_basic`. WordPress' Auth
   liest aber genau diese Variablen, also müssen sie befüllt werden
3. **WordPress verweigert Application Passwords auf nicht-HTTPS** im Standard.
   Auf einer lokalen Dev-Site (`http://site.local`) muss man den internen
   Filter `wp_is_application_passwords_available` auf `true` zwingen

Für das Cortex-Web-Repo ist die Lösung dokumentiert unter
`Cortex-Web/tools/local-wp-setup/README.md` — mu-plugin plus eine
nginx-Zeile. Dieses Setup ist nur für **lokale Entwicklung**, auf einer
echten Website mit HTTPS ist keiner dieser Eingriffe nötig.

### `incorrect_password` bei korrekt kopiertem App-Password

Meist Copy-Paste-Verlust: ein Zeichen fehlt, ein Block ist versehentlich
doppelt. WP zeigt das Passwort nur einmal; fehlerhafte Kopien sind nicht
reparierbar. Das bestehende App-Password im WP-Admin widerrufen, neues
anlegen, neu kopieren.

### `ambiguous slug — N pages match`

Der Adapter hat mehrere Pages mit demselben Slug gefunden. Das passiert, wenn
Sie die Page früher manuell im WP-Admin angelegt UND der Adapter später noch
einmal unter demselben Slug laufen ließ. Im WP-Admin die doppelte(n) Seite(n)
löschen oder umbenennen, dann Adapter erneut ausführen.

---

## Sicherheits-Regeln

- **`.env.local` niemals committen.** `.gitignore` mit `.env.*`-Eintrag ist
  Pflicht, ein einziger Commit-Leak ist über `git log` für immer sichtbar
- **Keine App-Passwords im Chat, in Slack, im E-Mail.** Sie landen sonst in
  Backups, Screenshots, Logs. Kurze Übermittlung ist nötig, aber direkt
  danach widerrufen
- **Application Passwords auf Produktion nur mit HTTPS.** Basic-Auth über
  unverschlüsseltes HTTP ist gegen jedes moderne Sicherheitsverständnis
- **Password-Masking in Log-Output.** Der REST-Client in Cortex-Web ersetzt
  jedes Vorkommen des Passworts mit `***`, bevor Fehler-Texte geloggt werden
- **Ein App-Password pro Verwendungszweck.** Nicht dasselbe für Cortex-Web,
  iOS-App und CI-Pipeline — pro Programm ein eigenes, dann kann man bei
  Verdacht einzeln widerrufen, ohne die anderen zu stören

---

## Was dieses Tutorial absichtlich nicht abdeckt

- JWT-Auth, OAuth, Cookie-Auth (für komplexere Szenarien)
- REST-API-Erweiterung mit Custom Post Types oder Custom Fields
- Shopify's REST-Adapter (folgt in Phase 2 mit eigenem Tutorial)
- Medien-Upload per REST (folgt in Phase 2)

---

## Referenz

- Offizielle WP-REST-API-Doku: <https://developer.wordpress.org/rest-api/>
- Application-Passwords-Spezifikation:
  <https://make.wordpress.org/core/2020/11/05/application-passwords-integration-guide/>
- Cortex-Web Phase-1-Spec:
  `projects/Cortex-Web/specs/phase-1/POC_WP_ADAPTER.md`
- Cortex-Web Local-Setup:
  `projects/Cortex-Web/tools/local-wp-setup/README.md`
- Pattern-Dokumentation:
  `Nexus/_memory/patterns/local-wp-rest-auth-bootstrap.md`
