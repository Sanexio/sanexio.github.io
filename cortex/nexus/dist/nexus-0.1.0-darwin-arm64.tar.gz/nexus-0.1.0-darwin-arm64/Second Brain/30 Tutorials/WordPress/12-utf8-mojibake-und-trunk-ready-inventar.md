# 16 — UTF-8-Mojibake-Fix und Trunk-ready Page-Inventar

> **Kontext:** Aus Praxis-Sprint 2 / S2.3-D Phase 1 (2026-04-20 Session 15).
> Zwei zusammengehörige Themen, weil sie beim Vorbereitungs-Pass eines
> Website-Content-Umzugs immer zusammen auftreten.
>
> **Pattern-Bezüge:**
> `Nexus/_memory/patterns/wp-mojibake-mb-convert-fix.md` ·
> `Nexus/_memory/patterns/trunk-ready-page-inventory.md` ·
> `Nexus/_memory/patterns/mysql-utf8mb4-binary-rejection-proof.md`

---

## Teil A — UTF-8-Mojibake

### A.1 Was ist Mojibake?

**Mojibake** (japanisch 文字化け, „Zeichensalat") bezeichnet die sichtbare
Verstümmelung von Text, wenn Zeichenketten unterwegs zwischen zwei Systemen
mit falscher Zeichenkodierung übersetzt wurden. Typische Symptome auf einer
WP-Site, die aus einer älteren Quelle importiert wurde:

| Was sichtbar im Text steht | Was es eigentlich sein sollte |
|---|---|
| `â€ž` | `„` (Anführungszeichen unten) |
| `â€"` | `—` (em-dash) oder `"` (Anführungszeichen oben) |
| `Ã¤`, `Ã¶`, `Ã¼`, `ÃŸ` | `ä`, `ö`, `ü`, `ß` |
| `Â `, `Â©` | NBSP, `©` |

### A.2 Wie entsteht es?

Ein typischer WordPress-Import aus einer älteren Quelle macht:

1. Quell-DB hat einen Text **korrekt** als UTF-8 kodiert. Beispiel: `„` →
   UTF-8-Bytes `E2 80 9E`.
2. Irgendein Zwischen-Tool (CSV-Import, WP-REST-Endpoint mit falschem
   `charset`-Header, phpMyAdmin mit latin1-Default) liest diese Bytes
   **als Windows-1252 (cp1252)** ein. Ergebnis: drei Zeichen `â€ž`.
3. Das gleiche Tool schreibt die drei Zeichen **wieder als UTF-8** zurück:
   - `â` (U+00E2) → `C3 A2`
   - `€` (U+20AC) → `E2 82 AC`
   - `ž` (U+017E) → `C5 BE`
4. In der neuen utf8mb4-DB landen 7 Bytes: `C3 A2 E2 82 AC C5 BE`.
5. Browser rendert diese 7 Bytes als `â€ž` — Mojibake entsteht.

Das Muster heißt **„double-encoded UTF-8"**.

### A.3 Warum statische SQL-REPLACE-Ketten fragil sind

Naheliegender erster Versuch:

```sql
UPDATE wp_posts SET post_content = REPLACE(post_content, 'â€ž', '„');
UPDATE wp_posts SET post_content = REPLACE(post_content, 'â€"', '—');
-- ... 15 weitere Regeln ...
```

**Problem:** Die Byte-Sequenz des needle-Strings hängt von der Shell
(UTF-8 vs. cp1252) und vom Double-Encode-Pfad (cp1252 vs. ISO-8859-1 als
Zwischenstufe) ab. Ein im UTF-8-Terminal getippter needle `â€"` (em-dash
U+2014) trifft nur **einen** der beiden Pfade — der ISO-8859-1-Pfad (bei dem
em-dash als `0x97` interpretiert wird und zu `C2 97` re-encoded) bleibt
ungemacht.

Empirisch in Session 15: Ein Pre-Count mit 15 Shell-typed needle-Varianten
fand **nur 1/15 Mustern** (`â€ž` = 31 Hits), aber 165 Pages hatten noch
`Â`/`Ã`/`â€`-Byte-Spuren. Statischer REPLACE hätte 14 Varianten liegen lassen.

### A.4 Die robuste Lösung: `mb_convert_encoding`-Paar

Der **kanonische Fix** (identisch zu Python's `ftfy`-Bibliothek):

```php
function fix_utf8_double_encode(string $s): ?string {
    // Step 1: Interpret current UTF-8 chars as Windows-1252 bytes
    //         (rolls back the second encoding step).
    $tmp = @mb_convert_encoding($s, 'Windows-1252', 'UTF-8');
    if ($tmp === false || $tmp === null) return null;
    // Step 2: Validate result as UTF-8.
    $fixed = @mb_convert_encoding($tmp, 'UTF-8', 'UTF-8');
    if ($fixed === false || $fixed === null) return null;
    if (!mb_check_encoding($fixed, 'UTF-8')) return null;
    return $fixed;
}
```

**Warum das funktioniert:** Schritt 1 macht die falsch interpretierte
cp1252-Sicht rückgängig — er liefert die ursprüngliche UTF-8-Byte-Sequenz.
Schritt 2 ist nur eine Validity-Pass.

**Aber Vorsicht:** Diese Funktion verformt auch legitime UTF-8-Texte, die
gar kein Mojibake haben! Deshalb immer erst **prüfen**, ob überhaupt Mojibake
vorliegt:

```php
function has_mojibake(string $s): bool {
    if (strpos($s, "\xC3\xA2\xE2\x82\xAC") !== false) return true;     // â€
    if (preg_match('/\xC3\x83[\xA0-\xBF\x80-\x9F]/', $s)) return true; // Ã + Umlaut
    if (preg_match('/\xC3\x82[\x80-\xBF]/', $s)) return true;          // Â + punct
    if (strpos($s, "\xC3\xA2\xE2\x80") !== false) return true;         // lone â€
    return false;
}
```

Die Detection-Funktion ist **binary-safe** (arbeitet auf Byte-Ebene), egal
wie das Terminal oder PHP-Source-File kodiert ist.

### A.5 Safety-Gitter pro Page

```php
if (!has_mojibake($orig)) continue;              // nichts zu tun
$fixed = fix_utf8_double_encode($orig);
if ($fixed === null) { log_residue($id); continue; }   // Invalid UTF-8
if (has_mojibake($fixed)) {                      // Fix hat Marker nicht entfernt
    // Marker-Score-Diff: hat's verbessert oder verschlechtert?
    $score_orig  = count_markers($orig);
    $score_fixed = count_markers($fixed);
    if ($score_fixed >= $score_orig) {
        log_residue($id); continue;              // nicht akzeptieren
    }
}
if ($fixed === $orig) continue;                  // spare UPDATE
// Commit fix:
$stmt->bind_param('si', $fixed, $id);
$stmt->execute();
```

### A.6 Pflicht-Evidenz

Eine Mojibake-Fix-Session braucht **vier Evidenz-Artefakte**:

1. **Pre-Snapshot:** `mysqldump --single-transaction wp_posts ... | gzip > pre.sql.gz` — Rollback-Quelle.
2. **Pre-Count:** Marker-Zähler pro Muster + Page-Count-Snapshot.
3. **Post-Count / Idempotenz-Beweis:** Zweiter Lauf des Fix-Skripts → muss
   `had_mojibake: 0` liefern.
4. **Self-Check-MD** mit AK-Tabelle (Idempotenz, 0 Residuen, Page-Count
   unverändert, UTF-8-Validität).

### A.7 Sekundär-Beweis: MySQL utf8mb4-Rejection

Spannend: Wenn man nach dem Fix nach Mojibake-Bytes suchen will:

```sql
SELECT COUNT(*) FROM wp_posts
WHERE INSTR(post_content, UNHEX('C383A4')) > 0;
```

liefert auf MySQL 8 den Fehler:

```
ERROR 3854: Cannot convert string '\xC3\x83\xA4' from binary to utf8mb4
```

**Das ist kein Bug — das ist der Beweis.** `C3 83 A4` ist keine valide
UTF-8-Sequenz. MySQL würde solche Bytes gar nicht in eine utf8mb4-Spalte
lassen. Der Fehler belegt: Die Spalte ist per Definition frei von dieser
Byte-Sequenz.

Dieser indirekte Residuen-Beweis ist in
`Nexus/_memory/patterns/mysql-utf8mb4-binary-rejection-proof.md`
eigenständig dokumentiert.

---

## Teil B — Trunk-ready Page-Inventar

### B.1 Warum ein Inventar braucht mehr als MD-Tabellen

In einem Dach-Projekt wie **Cortex-Web** (gemeinsamer Trunk für mehrere
Plattformen — Praxis-WP + Juvantis-Shopify) muss ein Content-Inventar
**zwei zusätzliche Fragen** pro Page beantworten:

1. **Ist diese Page ein Trunk-Kandidat?** (CMS-agnostische zentrale Quelle)
2. **Hat sie Cross-Site-Potenzial?** (z. B. Praxis-Check-Up ↔ Juvantis-Body-Check)

Reine MD-Inventare lösen das nicht — sie sind nicht maschinenlesbar, und
späte Bridge-Aktivierung braucht dann einen zweiten Scan.

### B.2 Die 15 Pflicht-Spalten

| # | Spalte | Zweck |
|:-:|---|---|
| 1–5 | `id`, `slug`, `title`, `status`, `parent_id` | Identität + Hierarchie |
| 6 | `template` | Page-Template (oder 'default') |
| 7 | `wpml_lang` | Sprache (de/en/fr/es/-) |
| 8 | `content_length` | CHAR_LENGTH(post_content) |
| 9–10 | `image_count`, `image_source_hint` | Bilder pro Page + Quelle (wp-upload / ext-url / juvantis-shopify / none / mixed) |
| 11 | `mojibake_hits_pre` | Falls Session Mojibake fixte |
| 12–13 | `cluster`, `priority` | Themen-Cluster + P0/P1/P2 |
| 14 | `trunk_candidate` | yes / no / maybe |
| 15 | `cross_site_potential` | Juvantis-Slug-Kandidat oder 'no' |

### B.3 Cluster-Regeln (regel-basiert, nicht manuell)

Cluster werden per **Keyword-Regex auf Slug + Titel** zugeordnet. Beispiel
Praxis (Innere Medizin):

| Cluster | Keyword/Regex | Prio |
|---|---|:-:|
| `kern` | home, praxis, team, kontakt, karriere, impressum, datenschutz | P0 |
| `checkups` | check-?up, vorsorge, basic-check, executive | P0 |
| `aerzte` | ^dr-, ^arzt-, ^profil- | P1 |
| `fachrichtung` | innere, hno, neurologie, psychologie, gyn… | P1 |
| `diagnostik` | labor, sonographie, ekg, mrt, ct, gastroskopie | P1 |
| `services` | behandlung, therapie, beratung, impf, reise | P1 |
| `i18n-dublette` | `wpml_lang != 'de'` ODER slug endet `-en/-fr/-es/-2/-3` | P2 |
| `legacy` | Rest | P2 |

### B.4 Trunk-Candidate-Zuordnung

- `yes`: Cluster ∈ {`checkups`, `services`} ODER `cross_site_potential != 'no'`
- `maybe`: Cluster ∈ {`diagnostik`, `kern`}
- `no`: Cluster ∈ {`legacy`, `i18n-dublette`}

### B.5 Die i18n-Multiplikator-Erkenntnis

Schlüssel-Finding aus S2.3-D Phase 1:

- Rohzahl Pages: **189**
- Davon i18n-Dubletten: **134 (71 %)** — EN + FR + ES Kopien der deutschen Seiten
- Deutsche kuratur-relevante Pages: **55**

Ohne diese Aufschlüsselung wäre die Sprint-Dauer-Schätzung massiv verzerrt.
**Erste Tat im Inventar-Generator: i18n-Dubletten markieren, dann Scope-Plan
machen.**

### B.6 Was das Inventar später ermöglicht

1. **Batch-Sizing für Content-Kuratur-Sessions** — CSV filtern nach
   `cluster + priority + status == 'publish'`, dann 3–8 Pages pro Session.
2. **YAML-Trunk-Generator** — alle `trunk_candidate=yes` Zeilen werden
   per Skript in `trunk/content/*.yaml` migriert, wenn Bridge aktiviert
   wird.
3. **Phase-2b Medien-Pipeline** — alle Zeilen mit `image_count > 0` + `image_source_hint != 'wp-upload'` sind Kandidaten für Medien-Trunk-Migration (z. B. Bilder
   von sanexio.eu-CDN ins Praxis-Medien-Trunk holen).
4. **Menü-Restrukturierung (S2.4)** — Cluster-Tabelle ist die Grundlage für
   die neue Top-Level-Nav.

---

## Teil C — Kombinierter Workflow (1 Session, 2 Artefakte)

Die beiden Themen gehören zusammen in einen **Vorbereitungs-Pass**, bevor
echter Content-Review beginnt:

```
T2: mysqldump Pre-Snapshot                           (Rollback-Safety)
T3: Pre-Count Mojibake                               (Baseline)
T4: mojibake-fix.php                                 (Artefakt 1)
T5: 2 Läufe (Idempotenz)
T6: Residuen-Check (binary-safe + utf8mb4-rejection) (Sauberkeit)
T7: Post-Count                                       (Evidenz)
T8: inventory-generator.php                          (Artefakt 2)
T9: CSV + MD erzeugen
T10: Self-Check (AK-Tabelle)
T11: Verify-Pipelines (verify.sh, smoke-http, validate)
T12: Commit B
```

**Wichtig:** Kein Echt-Content-Edit in dieser Session. Das ist reine
Vorbereitung. Wert entsteht in den Folge-Sessions, die mit sauberem Content
und strukturiertem Inventar starten.

---

## Teil D — Anti-Patterns (zum Lernen)

### ❌ Shell-LIKE als Mojibake-Audit

```sql
SELECT COUNT(*) FROM wp_posts WHERE post_content LIKE '%Ã¤%';
```

Shell-typed `Ã¤` ist UTF-8-Bytes `C3 83 C2 A4`. DB hat Mojibake als `C3 83 A4`
(3 Bytes). LIKE matcht nicht. **Nutze HEX-Literal oder PHP-Binary-Detection.**

### ❌ Statische REPLACE-Kette

Trifft nur eine Double-Encode-Variante. Lässt Residuen. Verwende
`mb_convert_encoding`-Paar.

### ❌ Blind `mb_convert_encoding` auf allen Pages

Ohne Mojibake-Detection werden legitime UTF-8-Texte verformt. Immer erst
`has_mojibake()` prüfen.

### ❌ Inventar ohne Trunk-Felder

Zweiter Scan nötig, wenn Bridge aktiviert wird. Kostet 0 jetzt, aber 1
Session später.

### ❌ Draft/Private Pages im Inventar weggelassen

Verwaiste Test-Pages bleiben unsichtbar; keine Gesamt-Scope-Sicht.

---

## Siehe auch

- Pattern `wp-mojibake-mb-convert-fix.md` — Code-Template + AK-Liste
- Pattern `trunk-ready-page-inventory.md` — CSV-Schema + Generator-Skeleton
- Pattern `mysql-utf8mb4-binary-rejection-proof.md` — Evidenz-Nutzung
- Tutorial 10 `10-seiten-inventar-website-relaunch.md` — Basis-Inventar (S2.1)
- Tutorial 14 `14-wp-plugin-sicher-entfernen.md` — ähnliche Evidenz-Disziplin
- S2.3-D Spec `Cortex-Web/sites/praxis-webseite/specs/sprint-2/S2.3-D_content-curation.md`
- S2.3-D Self-Check `… evidence/2026-04-20_s2.3-d_self-check.md`
