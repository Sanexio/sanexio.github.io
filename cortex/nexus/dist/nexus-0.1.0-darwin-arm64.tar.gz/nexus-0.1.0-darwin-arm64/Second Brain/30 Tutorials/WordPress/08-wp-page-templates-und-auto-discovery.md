# 11 — WordPress Page-Templates & Auto-Discovery

> **Quelle:** Praxis-Webseite Sprint 2 / S2.2 (2026-04-19) — 8 Skelett-Templates
> auf einmal angelegt; eine versteckte WP-Falle gefangen.
>
> **Voraussetzung:** Tutorial 02 (Git-Bootstrap + Page-Registry), Tutorial 09
> (4-Schichten-Design-Tokens).

---

## Worum es geht

WordPress kennt zwei Arten von „Templates":

| Art | Wofür | Wie WP es findet |
|---|---|---|
| **Page-Template** | Eine WP-Page nutzt ein bestimmtes Layout (Standard, Kontakt, Arzt-Profil …) | Auto-Discovery + Filter-Hook |
| **Hierarchie-Template** | WP wählt automatisch je nach Anfrage-Typ (Single Post → `single.php`, 404 → `404.php`, Suche → `search.php` …) | WP-Hierarchie-Algorithmus, fest verdrahtet |

Wenn Sie eine neue Praxis-Seite anlegen (z.B. „Innere Medizin"), wählen Sie im
WP-Admin **welches Page-Template** sie nutzen soll — wenn es passende
gibt. Sonst nimmt WP das Default `page.php`.

---

## So registrieren wir Page-Templates

### Variante 1 — Header-Comment (am sichersten)

Am Anfang jeder PHP-Template-Datei steht ein Block-Comment, der WP sagt
„diese Datei ist ein Page-Template":

```php
<?php
/**
 * Template Name: Standard (Textseite)
 * Generic text page template for Praxis, Team, Datenschutz, Impressum.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();
?>
<div class="pxz-standard">
  <!-- Inhalt -->
</div>
<?php get_footer(); ?>
```

Die Zeile `* Template Name: Standard (Textseite)` ist der **Trigger**.
WP scannt jede `.php`-Datei im Theme-Root danach und nimmt den Reststring als
Display-Namen für den WP-Admin-Dropdown.

### Variante 2 — Filter-Hook (ergänzend in `functions.php`)

```php
add_filter( 'theme_page_templates', function( $templates ) {
    $templates['template-standard.php'] = 'Standard (Textseite)';
    $templates['template-arzt.php']     = 'Arzt (Einzel-Profil)';
    return $templates;
} );
```

Vorteil: Display-Namen liegen alle an einer Stelle und sind einfacher zu
pflegen. Nachteil: redundant mit Variante 1.

In unserem Praxis-Theme nutzen wir **beide** zusammen — Header-Comment für
Auto-Discovery, Filter für sauberen Display-Namen-Index.

---

## Die Auto-Discovery-Falle (PXZ-E-009)

In Sprint 2 / S2.2 ist mir folgendes passiert: Nach Anlage von 8 Templates
zeigte das WP-Admin-Dropdown **zwei Phantom-Einträge**:

```
Standard (Textseite)              ✅ erwartet
Sprechstunden                     ✅ erwartet
Kontakt                           ✅ erwartet
Fachrichtungen-Übersicht          ✅ erwartet
Fachrichtung (Einzel)             ✅ erwartet
Ärzte-Übersicht                   ✅ erwartet
Arzt (Einzel-Profil)              ✅ erwartet
" header).                        ❌ Phantom — kommt aus 404.php?!
"-Header automatisch.             ❌ Phantom — kommt aus functions.php?!
```

### Was passiert ist

WordPress' Auto-Discovery scannt **wirklich jede `.php`-Datei** im Theme via
Regex auf den literalen String `Template Name:` — egal in welchem Kontext.
Mein Header-Comment in `404.php` lautete:

```php
/**
 * 404 Fallback Template
 * NOT a Page Template (no "Template Name:" header).   ← TRIGGER!
 */
```

Auch `functions.php` hatte einen erläuternden Code-Comment:
```php
// Karriere registriert sich via "Template Name:"-Header automatisch.   ← TRIGGER!
```

WP las jeweils alles nach dem Doppelpunkt bis Zeilenende als „Display-Name" —
das ergab `" header).` und `"-Header automatisch.`.

### Der Fix

**Niemals** den literalen String `Template Name:` (mit Doppelpunkt) in
Code-Comments schreiben. Sichere Form:

| ❌ Falsch | ✅ Richtig |
|---|---|
| `// "Template Name:"-Header automatisch` | `// Template-Name-Header automatisch` |
| `* (no "Template Name:" header)` | `* (no Template-Name header)` |

Bindestrich statt Doppelpunkt — dann matcht der WP-Regex nicht mehr.

### Allgemeine Regel

Diese Falle existiert für **alle WP-Header-Trigger**:
- `Template Name:` — Page-Templates
- `Plugin Name:` — Plugin-Header
- `Theme Name:` — Theme-Header
- `Block Name:` — Block-Plugin
- `Description:`, `Version:`, `Author:` — Meta-Felder

Wenn ein String im Code-Comment auftauchen soll, der gleichzeitig ein
WP-Header-Feld definiert: **Doppelpunkt vermeiden.** Bindestrich-Variante
schreiben.

---

## Verifikations-Workflow (statt blindem Vertrauen)

Nach jeder Theme-Änderung läuft eine WP-CLI-Probe, die alle vom Theme
registrierten Page-Templates auflistet:

```bash
PHP=".../php-8.2.29+0/bin/darwin-arm64/bin/php"
PHAR=".../wp-cli/wp-cli.phar"
SITE="/Users/.../app/public"
SOCK="/Users/.../mysqld.sock"

"$PHP" -d mysqli.default_socket="$SOCK" "$PHAR" --path="$SITE" \
  eval 'print_r( wp_get_theme()->get_page_templates() );'
```

Output sollte **exakt** die intendierten Templates enthalten — keine
Phantome wie `404.php` oder `functions.php`.

**Warum das wichtig ist:** Wenn ein Phantom-Template im WP-Admin-Dropdown
erscheint und Dr. Stracke (oder ein Mitarbeiter) klickt es versehentlich an,
würde die Page entweder leer rendern oder PHP-Errors werfen — schwer zu
debuggen, peinlich für die Praxis.

---

## Sonderfall: `404.php`

`404.php` ist **kein** Page-Template, sondern ein **Hierarchie-Template**.
WP liefert es automatisch, wenn die angefragte URL keine bekannte Page/Post/etc.
ist (`is_404()`-Bedingung).

Konsequenz:
- **Kein** `Template Name:`-Header in `404.php`
- **Kein** `theme_page_templates`-Eintrag
- **Kein** `is_page_template('404.php')` im Enqueue — stattdessen `is_404()`:

```php
if ( is_404() ) {
    wp_enqueue_style( 'pxz-404', PXZ_URI . '/assets/css/404.css', [ 'praxiszentrum' ], PXZ_VERSION );
}
```

---

## Die „Skelett-Sprint"-Strategie

In Sprint 2 / S2.2 haben wir **8 Templates auf einmal** angelegt — als
Skelette ohne Echt-Content. Warum?

### Vorteile gegenüber „eines nach dem anderen"

1. **Funktions-Wahl im WP-Admin** — sobald die Skelette da sind, kann jede
   neue Page das richtige Template wählen, auch wenn der Inhalt noch leer ist.
2. **Token-Disziplin** — wenn alle Skelette gleichzeitig die Token-Quelle
   (`tokens.css` v2) referenzieren, werden Inkonsistenzen sofort sichtbar.
3. **Ein Cache-Buster-Bump** statt acht — `PXZ_VERSION` 2.7.6 → 2.7.7 deckt
   alle 8 Templates auf einmal ab.
4. **Verify-grün-Erhalt** wird in einem Schritt geprüft — Home + Karriere
   bleiben unangetastet, alles andere ist additiv.

### Was Skelett bedeutet

```php
<section class="pxz-fachrichtung-services">
  <div class="pxz-fachrichtung-services-inner">
    <h2 class="pxz-fachrichtung-services-title">&nbsp;</h2>
    <!-- Liste folgt in S2.3 -->
  </div>
</section>
```

`<h2>` enthält ein nichtbrechendes Leerzeichen statt einem echten Titel —
damit WP rendert die Sektion (sieht „leer" aus), aber die HTML-Struktur und
die Klassen sind schon da. Sprint 2 / S2.3 füllt dann den echten Text.

### Was Skelett **nicht** bedeutet

- Kein Echt-Content (das ist ein eigener Sprint = S2.3)
- Keine Echt-Werte im CSS (Klassen sind nur deklariert mit `/* TODO S2.3 */`)
- Keine generischen Komponenten (das wäre ein Component-Refactor-Sprint = S2.0b)

Die strikte Trennung verhindert „Mega-Sprints" und macht jede Phase einzeln
prüfbar.

---

## Pre-Flight-Empfehlung für künftige Theme-Sessions

Bevor Sie eine Theme-Session abschließen, lassen Sie folgende drei Checks laufen:

```bash
# 1. PHP-Syntax aller geänderten Templates
for f in template-*.php functions.php 404.php; do
  "$PHP" -l "$f" 2>&1 | head -1
done

# 2. WP-CLI-Probe: keine Phantom-Templates?
"$PHP" "$PHAR" --path="$SITE" eval 'print_r( wp_get_theme()->get_page_templates() );'

# 3. verify.sh-Probe: Live-Pages unverändert grün?
cd ~/Cortex/projects/Cortex-Web/sites/praxis-webseite && bash tools/verify.sh
```

Wenn alle drei grün sind: Commit + Session beenden.

---

## Verwandte Tutorials

- **02 — Git-Bootstrap & Page-Registry** — wie das Theme-Repo + Pre-Flight aufgesetzt sind
- **05 — Design-Tokens & Cascade** — wie CSS-Werte via Tokens fließen
- **09 — 4-Schichten-Design-Tokens** — wie die Token-Hierarchie organisiert ist
- **10 — Seiten-Inventar für Website-Relaunch** — Vorgänger-Sprint zu S2.2 (Inventar liefert die Template-Liste)

---

## Verwandtes Pattern (für Claude)

`Nexus/_memory/patterns/wp-skeleton-templates-bundle.md` — die Pattern-Form
dieses Tutorials, projekt-übergreifend wiederverwendbar.

---

*Tutorial angelegt 2026-04-19 (Session 10) aus den Lessons der S2.2-Umsetzung.
Wenn Sie auf eine ähnliche Falle stoßen, ergänzen Sie hier — das Tutorial wächst
mit den realen Problemen.*
