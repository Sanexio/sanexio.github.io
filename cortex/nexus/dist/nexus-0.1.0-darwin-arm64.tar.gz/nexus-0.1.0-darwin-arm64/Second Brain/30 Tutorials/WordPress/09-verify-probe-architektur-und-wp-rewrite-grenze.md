# 13 — Verify-Probe-Architektur & WordPress-Rewrite-Rule-Grenze

> **Ziel:** Verstehen, wie eine belastbare Verify-Pipeline für eine Komponenten-Bibliothek aussieht — und welche Grenze WordPress einem dabei setzt, wenn man direkt in die Datenbank schreibt. Dieses Tutorial ist aus S2.0e (Session 12, 2026-04-19) entstanden, wo ein ursprünglich geplanter Test-Ansatz während der Umsetzung scheiterte und ein architektonisch sauberer Pivot notwendig wurde.

## 1. Das Ausgangsproblem

In Sprint 2 / S2.0b wurde eine **Komponenten-Bibliothek** (`assets/css/components.css`) als Schicht 3 des Design-Systems eingezogen (siehe Tutorial 12). Diese Bibliothek enthält 8+ generische CSS-Regeln (`.pxz-container`, `.pxz-btn`, `.pxz-eyebrow`, Typografie-Klassen, Hero-Basis), die auf jeder Page des Themes verwendet werden sollen.

**Die Frage der Verify-Pipeline:** *Wie stellen wir sicher, dass diese Komponenten-Bibliothek nicht still bricht?*

Es gibt zwei Dimensionen, auf denen etwas brechen kann:

1. **Code-Seite:** Jemand bearbeitet `components.css` und ändert aus Versehen einen Wert (z. B. `border-radius: 9999px` → `border-radius: 12px`). Die Regel steht immer noch da, aber falsch.
2. **Integrations-Seite:** Jemand bearbeitet `functions.php` und vergisst das `wp_enqueue_style('pxz-components', ...)`. Die Datei ist korrekt, wird aber nicht geladen.

Eine gute Verify-Probe muss **beide Dimensionen testen**, und — wichtig — sie muss für eine Person, die das Probe-Ergebnis liest, klar machen, **welche Dimension rot ist**.

## 2. Ein-Stufen-Probe: DOM-Rendering (was wir ursprünglich wollten)

Die intuitivste Lösung: Eine Probe-Page im WordPress anlegen, die alle Komponenten-Klassen verwendet, und per Headless-Chrome (Puppeteer) `getComputedStyle()` auf die Elemente anwenden.

```js
await page.goto('https://local.test/s2-0b-probe/');
const borderRadius = await page.evaluate(() =>
  getComputedStyle(document.querySelector('.pxz-btn')).borderRadius
);
console.assert(borderRadius === '9999px');
```

Das testet „echtes Rendering" — also beide Dimensionen gleichzeitig. Klingt gut?

**Klingt gut, ist aber aus zwei Gründen schlecht:**

1. **Fehler-Lokalisierung wird unscharf.** Wenn die Probe rot wird, sagt sie: *„border-radius ist 0px statt 9999px"*. Aber warum? Ist die Regel in `components.css` falsch? Oder ist `components.css` gar nicht geladen? Man muss es einzeln nachprüfen.
2. **Es hängt an einer gerenderten Page**, mit allen WordPress-Problemen, die damit zusammenhängen.

## 3. Die WordPress-Falle: Rewrite-Rules bei direkt-SQL-Pages

Hier kam der **technische Schock**. Für eine Probe-Page gibt es zwei Wege, sie anzulegen:

- **Weg A — Über WP-Admin** oder `wp post create` (wp-cli). WordPress läuft dabei seinen kompletten Hook-Stack durch: `save_post`, `wp_insert_post`, `flush_rewrite_rules` und Plugin-Filter. Die Page ist danach korrekt in den URL-Rewrite-Rules eingetragen, und `/s2-0b-probe/` liefert den gerenderten Page-Content.
- **Weg B — Direkt per SQL-INSERT** (weil `wp-cli` auf Local-by-Flywheel am DB-Socket scheitert, siehe Tutorial 12 + Pattern `local-wp-mysql-socket.md`). Page ist in `wp_posts` drin, aber: **Die Rewrite-Rules werden nicht aktualisiert.**

Symptome bei Weg B:
```
$ curl -I https://local.test/s2-0b-probe/
HTTP/2 404 Not Found
```

Der „naheliegende" Fix ist `DELETE FROM wp_options WHERE option_name='rewrite_rules'` — das zwingt WordPress beim nächsten Request, die Rules neu zu generieren. Tatsächlich: WordPress generiert sie. Aber der neue Slug erscheint **nicht zuverlässig** in den generierten Rules.

Der Grund liegt in Plugins, die eigene URL-Handler registrieren (Santapress, WPML, Polylang, Yoast Premium-Redirects). Diese Plugins haken sich in `rewrite_rules_array` oder `page_rewrite_rules` ein und können die Rewrite-Logik übersteuern, ohne dass man es merkt.

Alternative Lösungen, die **auch nicht funktionieren**:

- `php -r "require 'wp-load.php'; flush_rewrite_rules();"` — scheitert auf Local-by-Flywheel am DB-Socket (gleicher Grund wie wp-cli).
- PATHINFO-URLs wie `/index.php/s2-0b-probe/` → 301-Redirect auf `/s2-0b-probe/` → 404.
- `?pagename=s2-0b-probe` → 301 → 404.

**Konsequenz als Grundregel:** **Direkt-SQL-INSERT auf `wp_posts` ist nur für Backend-Objekte zuverlässig** (Meta, Options, Transient-Cache). **Für Frontend-Pages mit Slug-URL braucht es den WordPress-Hook-Stack.**

## 4. Der Pivot: Zwei-Stufen-Bash-Probe

Statt gegen WordPress zu kämpfen, haben wir die Probe-Architektur umgedreht. Die neue `component_probe()` in `tools/verify.sh` testet **die zwei Dimensionen getrennt**:

### Stufe A — Code-Korrektheit (`grep` auf die CSS-Datei)

Direkt auf `assets/css/components.css` mit einem Array von (Beschreibung|Start-Regex|Inhalt-Regex|Kontext-Zeilen)-Tupeln:

```bash
assertions=(
  "pxz-container max-width:1280px|^\.pxz-container[[:space:]]*\{|max-width:[[:space:]]*1280px|1"
  "pxz-btn border-radius:9999px|^\.pxz-btn[[:space:]]*\{|border-radius:[[:space:]]*9999px|12"
  # …
)
for a in "${assertions[@]}"; do
  IFS='|' read -r desc head content ctx <<< "$a"
  if grep -E "$head" -A "$ctx" "$css_file" | grep -qE "$content"; then
    echo "  ✓ $desc"
  fi
done
```

**Das Multi-Line-Problem:** CSS-Regeln sind oft über mehrere Zeilen verteilt. `.pxz-btn { ... border-radius: 9999px }` beginnt auf einer Zeile, der Wert folgt 4 Zeilen später.

Reines `grep -E '.pxz-btn.*border-radius.*9999px'` matcht nur single-line. Die Lösung: **Zweistufiges grep**:

1. Das erste `grep` findet den Selektor-Kopf (`^\.pxz-btn\s*{`) und gibt **N Folgezeilen** mit aus (`-A <ctx>`).
2. Das zweite `grep` sucht im Ergebnis nach dem Inhalts-Regex (`border-radius:\s*9999px`).

Der `ctx`-Wert muss groß genug sein, um den Regel-Body zu umfassen — typisch 1 für kleine Regeln, 12 für Button-Blöcke.

### Stufe B — Integrations-Korrektheit (`curl` auf HTML)

Ein simpler `curl`-Aufruf auf die Homepage holt das gerenderte HTML, dann `grep` auf den `<link>`-Tag:

```bash
home_html=$(curl -sk "$HOME_URL")
# Enqueue-ID muss im <link>-Tag stehen
echo "$home_html" | grep -qE "id=['\"]pxz-components-css['\"]" && echo "  ✓ Enqueue-ID"
# href mit Version-Query
echo "$home_html" | grep -qE "assets/css/components\.css\?ver=" && echo "  ✓ href"
```

WordPress hängt an die Enqueue-ID aus `wp_enqueue_style('pxz-components', ...)` automatisch `-css` an und schreibt das als `id` in den `<link>`-Tag. Wir müssen nur darauf matchen.

### Warum das architektonisch besser ist

| Ein-Stufen-Probe (DOM) | Zwei-Stufen-Bash-Probe |
|---|---|
| *„border-radius falsch"* | *„Stufe A ✗ pxz-btn border-radius" ODER „Stufe B ✗ href fehlt"* |
| 3 Sekunden (Chrome-Boot) | 300 Millisekunden (grep + curl) |
| Braucht Probe-Page + Auth + Rewrite | Braucht nur CSS-Datei + Home-URL |
| Mensch muss DOM-Dump lesen | Mensch sieht sofort, welche Dimension rot ist |

## 5. Wann welcher Probe-Typ?

Beide Probe-Ansätze haben ihren Platz:

- **Page-Level-Rendering** (Layout, Responsive, Conversion-Flows): weiterhin **DOM-Probe** via Puppeteer + `page-registry`. Testet echtes Rendering-Verhalten auf echten Seiten.
- **Component-Level-Declaration** (*ist die Regel da, wird sie geladen?*): **Bash-Probe**. Testet Code + Integration getrennt, ohne fragile Page-Voraussetzung.

Beide ergänzen sich zu einer **schichtweise Regressions-Sicht**. Im Theme `praxiszentrum` heißen sie `§3 Computed-Style-Probe` (Puppeteer, Home + Karriere) und `§3b Component-Probe` (Bash, `components.css`).

## 6. Lehrsätze (Meta-Ebene)

Das ist nicht nur CSS-Testing, das ist eine **allgemeine Lehre für Test-Architektur**:

- **Trenne Dimensionen.** Wenn zwei unabhängige Fragen beantwortet werden müssen, dann schreibe zwei Tests. Fehler-Lokalisierung ist ein First-Class-Design-Ziel.
- **Kämpfe nicht gegen Plattformen, wenn du sie nicht testen willst.** Die DOM-Probe hätte uns gezwungen, WordPress' Rewrite-Rule-Mechanik zu verstehen, Plugins zu debuggen und einen Auth-Flow zu bauen. Die Bash-Probe umgeht das komplett.
- **Architektur-Pivots sind nicht Niederlagen.** Der ursprüngliche Plan war technisch vernünftig, aber bei Umsetzung zeigte sich eine Plattform-Grenze. Die Neuorientierung auf eine sauberere Trennung war das, was die Architektur robuster gemacht hat.
- **Rollback nach einem Pivot muss den DB-Zustand mit zurücksetzen.** Nach dem Pivot wurde Page 9670 per `UPDATE wp_posts SET post_status='draft', post_content=''` auf den S2.0b-Zustand zurückgerollt. Ohne diesen Rollback wäre die Page als `publish` mit Probe-Markup in der DB geblieben — ein Geist-Zustand zwischen zwei Entscheidungen.

## 7. Wann Dr. Stracke diese Lehre braucht

- Wenn eine Verify-Probe gebaut wird und die Frage „wie testen wir das?" aufkommt → *„Code-Korrektheit und Integrations-Korrektheit getrennt testen."*
- Wenn WordPress-Page-Operationen per direktem SQL gemacht werden sollen → *„Geht nur für Backend-Objekte, nicht für Frontend-Slug-URLs."*
- Wenn ein DOM-Test rot wird → *„Ist es Stufe A oder Stufe B?"* Statt stundenlangem Debuggen.

## 8. Referenzen

- Spec S2.0e: `Cortex-Web/sites/praxis-webseite/specs/sprint-2/S2.0e_verify-hardening.md`
- Self-Check S2.0e: `Cortex-Web/sites/praxis-webseite/specs/sprint-2/evidence/2026-04-19_s2.0e_self-check.md`
- Pattern: `Nexus/_memory/patterns/verify-probe-code-vs-integration.md`
- Pattern-Erweiterung: `Nexus/_memory/patterns/local-wp-mysql-socket.md` §Grenze (Rewrite-Rules)
- Vorläufer: Tutorial 12 (`12-css-spezifitaet-und-komponenten-schichten.md`) — Schicht-3-Einführung
- Tool: `Cortex-Web/sites/praxis-webseite/tools/verify.sh` §1b + §3b

---

*Angelegt 2026-04-19 (Cortex-Web Session 12, praxis-webseite S2.0e).*
