# 24 — Blocksy-Footer komplett überschreiben im Child-Theme

**Kurz:** Blocksy rendert standardmäßig einen minimalen Footer, der sich
nur über den Customizer konfigurieren lässt. Wenn man einen vollständig
eigenen, git-getrackten Footer will (Brand-Block, 4-Spalten-Grid, Legal-Nav,
mehrsprachig), überschreibt man die Blocksy-`footer.php` im Child-Theme —
aber so, dass die Blocksy-Plugin-Hooks erhalten bleiben.

**Gelernt in:** S2.4b Footer-Umbau (Session 25, 2026-04-23), Theme
`praxiszentrum` PXZ 2.7.20.

---

## Was ist das Problem

Blocksy-Customizer-Footer hat drei praktische Nachteile:

1. **Nicht git-trackbar.** Die Config lebt in der DB als Customizer-Option.
   Bei Geräte-Wechsel oder Roll-back verliert man sie.
2. **Sehr eingeschränkt.** Blocksy-Default kennt nur ein `copyright`-Block.
   Widgets wären machbar, sind aber wieder DB-basiert.
3. **Kein Inline-SVG-Logo, keine eigene CSS-Kaskade.** Für Brand-Konsistenz
   muss man komplett am Customizer vorbei.

## Lösungsprinzip in einem Satz

> `footer.php` im Child-Theme existieren lassen → WP findet es zuerst →
> Blocksy-Parent-`footer.php` wird übersprungen → eigener Template-Part
> wird gerendert → Plugin-Hooks bleiben erhalten durch manuelle `do_action`-Calls.

## Schritt für Schritt

### 1. Child-Theme-`footer.php` anlegen

```php
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Blocksy's content-bottom-Hook (Plugins nutzen den, z.B. Cookie-Banner).
if ( function_exists( 'blocksy_after_current_template' ) ) {
    blocksy_after_current_template();
}
do_action( 'blocksy:content:bottom' );
?>
    </main>

<?php
do_action( 'blocksy:content:after' );
do_action( 'blocksy:footer:before' );

// Eigener Footer-Render (statt Blocksy-Default)
get_template_part( 'template-parts/site-footer' );

do_action( 'blocksy:footer:after' );
?>
</div>

<?php wp_footer(); ?>
</body>
</html>
```

**Wichtig:** Das schließende `</main>` und das äußere `</div>` mirroren
die Blocksy-Parent-Struktur, damit der DOM-Baum intakt bleibt. Wenn du
den Parent nicht 1:1 abbildest, kollabieren Layouts.

### 2. Eigenen Render in `template-parts/site-footer.php`

```php
<?php if ( ! defined( 'ABSPATH' ) ) exit;

$data = pxz_footer_data_for_lang(); // SSoT, siehe Tutorial 18
?>
<footer class="pxz-footer" role="contentinfo">
  <div class="pxz-footer-inner">
    <!-- Brand / Spalten / Bottom-Bar nach eigenem Geschmack -->
  </div>
</footer>
```

### 3. CSS-Guard als Defence-in-Depth

Falls ein Plugin trotzdem einen `ct-footer` ins DOM setzt:

```css
#footer.ct-footer,
.wpml-ls-statics-footer { display: none !important; }
```

### 4. Verifikation

```bash
curl -sSk https://<site>/praxis/ > /tmp/page.html
grep -c 'class="pxz-footer"' /tmp/page.html   # soll 1 sein
grep -c 'class="ct-footer"'  /tmp/page.html   # soll 0 sein
```

## Warum NICHT `remove_action`

Blocksy ruft seine Footer-Ausgabe nicht über einen benannten Action-Hook
auf, sondern direkt in `blocksy_output_footer()` innerhalb der
Parent-`footer.php`. Ein `remove_action()` greift daher nicht.

Der einzige saubere Weg ist der Template-Override.

## Hook-Verhalten — warum Pass-Through wichtig ist

Wenn du nur `</main>` + eigener Footer + `wp_footer()` schreibst, ohne
die Blocksy-Actions zu feuern, funktionieren **diese Plugins nicht mehr**:
- Cookie-Banner (viele docken an `blocksy:content:after` an)
- Tracking-Pixel (manche nutzen `blocksy:footer:before`)
- A/B-Test-Frameworks

Daher: alle vier `do_action()`-Calls unverändert übernehmen, nur
`blocksy_output_footer()` auslassen.

## Folge-Arbeit

- `inc/footer-data.php` mit Tagline, Claim, Col-Labels, Legal-Nav,
  Copyright 4-sprachig — siehe Tutorial 18 (SSoT-Muster).
- `assets/css/footer.css` tokens-only — siehe DESIGN_GUIDELINES §2
  (Schicht-2-Tokens).
- In `functions.php` enqueuen: `wp_enqueue_style( 'pxz-footer', … )` auf
  **jeder** Seite (nicht template-gated).

## Verwandte Tutorials

- 23 — Template-Parts mit `is_page`-Guard (für partials)
- 20 — Navigation-Restrukturierung (dieselbe Override-Idee für Header)
- 18 — Single Source of Truth für Stammdaten (für footer-data.php)

---

*Autor: Claude (Session 25). Theme PXZ 2.7.20.*
