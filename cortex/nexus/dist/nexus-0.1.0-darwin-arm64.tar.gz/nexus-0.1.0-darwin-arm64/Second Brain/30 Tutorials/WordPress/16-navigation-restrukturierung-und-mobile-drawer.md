# Tutorial 20 — Navigation-Restrukturierung und Mobile-Drawer in WordPress

Jede Website hat ein Menü. Die meisten Menüs sind schlecht. Dieses Tutorial
erklärt, warum — und wie man es richtig macht, auf eine Art, die auch in
ein Jahr noch verständlich ist.

> **Kontext:** geschrieben nach Sprint 2 / S2.4 (praxis-webseite,
> 2026-04-22). Das Praxiszentrum-Menü wurde von hart codierten
> Home-Scroll-Ankern auf 7 kuratierte Seiten-Links + Mobile-Burger
> umgestellt. Theme-Version 2.7.15 → 2.7.16.

---

## Teil 1 — Die drei Lagen eines echten Menüs

Ein Menü hat mehr Schichten, als man denkt:

1. **Datenquelle** — wo die Menü-Struktur herkommt
2. **Rendering** — wer das HTML daraus baut
3. **Stil und Verhalten** — wie es aussieht und auf Eingaben reagiert

### Lage 1 — Datenquelle: drei Architektur-Varianten

| Variante | Vorteile | Nachteile | Typischer Einsatz |
|---|---|---|---|
| **WP-Menu-API** (Admin → Darstellung → Menüs) | Dr. Stracke kann Menü im Backend ändern; WPML-Integration automatisch; Plugin-Kompatibilität | Stand ist in der Datenbank, nicht im Git; Änderungen sind nicht reviewbar | Mittelgroße Kundenprojekte, Multi-Redakteur-Sites |
| **PHP-Array in `inc/nav-data.php`** | Git-tracked, deterministisch, 100 % deploy-based | Dr. Stracke muss jeden Eintrag über Deploy ändern lassen | Architektur-Disziplin, kleine Teams, sensible Branding-Kontrolle |
| **`nav.yaml` im Trunk-Repo** | Plattform-agnostisch (WP + Shopify teilen dieselbe Struktur); CW-001-Trunk-Master-Prinzip | Adapter-Pfad + Schema + Validator zu bauen | Cortex-Web-Stil: multiple Sites mit gemeinsamer Struktur |

**Unsere Wahl für S2.4: Variante 2 (PHP-Array).** Grund: Die Struktur ist
eng mit Sprint-Scope verbunden (jeder Cluster fügt Items dazu), Admin-UI-
Pflege würde Entscheidungen aus dem Git-Review herauslösen.

### Datei `inc/nav-data.php` — die drei Helpers

```php
// 1. Die Quelle
function pxz_nav_data() {
    return [
        'de' => [ 'primary' => [
            [ 'label' => 'Praxis', 'href' => '/praxis/' ],
            [ 'label' => 'Check-Ups', 'href' => '/check-ups/', 'children' => [
                [ 'label' => 'Gesundheits-Check-Up', 'href' => '/gesundheits-check-up/' ],
                // …
            ] ],
            // …
        ] ],
        'en' => [ /* same shape */ ],
    ];
}

// 2. Aktiven Sprach-Zweig holen
function pxz_nav_primary() {
    $all  = pxz_nav_data();
    $lang = pxz_current_lang();
    return $all[ $lang ]['primary'] ?? $all['de']['primary'];
}

// 3. Aktive Seite erkennen
function pxz_nav_is_active( $href ) {
    $req = strtok( $_SERVER['REQUEST_URI'] ?? '/', '?' );
    $req = '/' . trim( $req, '/' ) . '/';
    return $req === '/' . trim( $href, '/' ) . '/';
}
```

**Drei Funktionen reichen.** Nicht mehr, nicht weniger. Die Versuchung, das
aufzubohren („cachen, filtern, hook-bar machen") ist immer da — widerstehen.

---

## Teil 2 — Rendering in `template-parts/header-nav.php`

Vor S2.4: eine hart codierte Liste von 5 Fragment-Anchors (`#service`,
`#team`, …). Problem: Auf Non-Home-Pages führen alle Links ins Nichts.

Nach S2.4: eine Render-Funktion, die pro Top-Item entscheidet, ob Submenu
oder flach.

```php
function pxz_render_nav_item( $item, $is_drawer = false ) {
    $has_children = ! empty( $item['children'] );
    $is_active    = pxz_nav_is_active( $item['href'] );
    $has_active_child = false;
    if ( $has_children ) {
        foreach ( $item['children'] as $c ) {
            if ( pxz_nav_is_active( $c['href'] ) ) { $has_active_child = true; break; }
        }
    }

    // li-Klassen
    $li_class = $has_children ? 'has-children' : '';
    if ( $is_active )        $li_class .= ' is-active-item';
    if ( $has_active_child ) $li_class .= ' is-active-parent';

    echo '<li class="' . esc_attr( $li_class ) . '">';
    if ( $has_children && $is_drawer ) {
        // Mobile: <details>-Accordion
        echo '<details' . ( $has_active_child ? ' open' : '' ) . '>';
        echo '<summary>…</summary>';
        echo '<ul class="pxz-nav-sub">…</ul>';
        echo '</details>';
    } elseif ( $has_children ) {
        // Desktop: CSS-Hover-Dropdown
        echo '<a href="…" aria-haspopup="true" aria-expanded="false">…</a>';
        echo '<ul class="pxz-nav-sub" role="menu">…</ul>';
    } else {
        echo '<a href="…">…</a>';
    }
    echo '</li>';
}
```

**Warum `aria-current="page"` und nicht nur CSS-Klasse?** Screen-Reader
kündigen damit „aktuelle Seite" an — Accessibility-Pflicht nach WCAG 2.1.
Eine CSS-Klasse sehen sie nicht.

---

## Teil 3 — Submenu-Hover ohne JavaScript

Das Dropdown auf Desktop ist reines CSS:

```css
.pxz-nav-sub {
  position: absolute;
  top: 100%; left: 50%;
  transform: translateX(-50%) translateY(-4px);
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s, transform 0.15s;
}

.has-children:hover > .pxz-nav-sub,
.has-children:focus-within > .pxz-nav-sub {
  opacity: 1;
  pointer-events: auto;
  transform: translateX(-50%) translateY(0);
}
```

`:focus-within` ist wichtig — sonst kommt man mit der Tastatur (Tab) nicht
ins Submenu rein. Viele Themes vergessen das.

---

## Teil 4 — Mobile-Burger + Off-Canvas-Drawer

Unter 1100 px übernimmt ein Burger-Button, der einen Drawer von rechts
einblendet.

### Das HTML

```html
<button class="pxz-nav-burger" aria-expanded="false" aria-controls="pxz-nav-drawer">
  <span class="bar"></span><span class="bar"></span><span class="bar"></span>
</button>

<aside id="pxz-nav-drawer" role="dialog" aria-modal="true" inert hidden>
  <button class="pxz-nav-drawer-close">✕</button>
  <ul class="pxz-nav-drawer-list">
    <li>
      <details><summary><a>Check-Ups</a></summary>
        <ul class="pxz-nav-sub">
          <li><a>Gesundheits-Check-Up</a></li>
          …
        </ul>
      </details>
    </li>
    …
  </ul>
</aside>

<div class="pxz-nav-drawer-backdrop" hidden></div>
```

**Zwei nicht-offensichtliche Details:**

- `<details>` ist HTML5-Standard. Es erzeugt ein natives Accordion — klappt
  auf und zu **ohne JavaScript**. Wer 2026 noch jQuery-`.toggle()` nutzt,
  hat die letzten 8 Jahre verschlafen.
- `inert` (ein HTML-Attribut) nimmt das Element aus Tab-Reihenfolge und
  Screen-Reader-Flow. Moderner als die alten `aria-hidden` + `tabindex="-1"`
  Tricks. Unterstützt in allen Major-Browsern ab 2023.

### Das JavaScript (~90 Zeilen vanilla)

Nur drei Dinge:

1. **Burger-Click öffnet/schließt** (`is-open`-Klasse + `inert` setzen/entfernen)
2. **ESC / Backdrop-Click schließt**
3. **Focus springt beim Öffnen in den ersten Link, beim Schließen zurück auf Burger**

Das ist alles. Keine Frameworks.

### Scroll-Lock — warum und wie

Wenn der Drawer offen ist, darf der Body nicht scrollen (sonst wirkt die
Seite „zerrissen"):

```css
body.pxz-nav-open { overflow: hidden; }
```

JS fügt `.pxz-nav-open` hinzu / entfernt es. Fertig. Kein `scrollTop`-Dance,
keine iOS-Touch-Override-Hacks.

---

## Teil 5 — Progressive Enhancement: was passiert ohne JS?

- **Mit JS:** Burger klickbar, Drawer animiert, Focus-Lock aktiv, alles schön.
- **Ohne JS:** Burger-Click macht nichts; Drawer bleibt `hidden`. Der
  Nutzer sieht immerhin das Desktop-`.pxz-nav-list`, das unter 1100 px
  `display: none` ist. Also nichts.

**Ist das ein Problem?** In 2026 praktisch nicht. <0.2 % der Besucher
haben JS komplett aus. Wer wirklich 0-JS-Fallback will, macht den Drawer
statisch open auf Mobile (CSS-only Media-Query). Kostet aber ~60 % des
Viewports unterhalb des Headers.

**Unsere Wahl: JS-Enhancement statt JS-Fallback.** Ehrliche Entscheidung:
wir schützen den Haupt-Use-Case, nicht den 0.2%-Edge-Case.

---

## Teil 6 — Der dritte Scope-Schnitt: „Menü wächst mit Content"

Das ist keine technische Lektion, sondern eine Architektur-Regel.

**Direktive:** Sobald ein Inhalts-Cluster fertig migriert ist, muss das
Menü mitwachsen — in derselben oder direkt folgender Session. Sonst sind
Inhalte vorhanden, aber für den Nutzer unauffindbar.

**Was bedeutet das in der Praxis?**

- Cluster `checkups` hat 6 neue Pages (S2.3-checkups, Session 18) →
  Menü bekommt `Check-Ups ▼` mit 5 Kinder-Links (S2.4, Session 19).
- Cluster `aerzte` hat noch keine Pages → `/aerzte/` ist **nicht** im
  Menü. Wenn dieser Cluster in Session 20 oder 21 migriert, kommt
  `/aerzte/` automatisch als Menü-Item dazu (plus Submenu mit den
  einzelnen Ärzte-Profilen, wenn auch die fertig sind).

**Ehrlichkeit ist besser als Struktur-Anspruch.** Ein tot klickender Menü-
Eintrag zerstört Nutzervertrauen in 0.3 Sekunden. Ein fehlender Menü-
Eintrag bleibt unbemerkt.

**Pre-Check-Routine vor Commit:** Curl alle Menü-URLs. Jeder 404 und jeder
301 bekommen eine dokumentierte Entscheidung (Stub / Remove / Umleiten).

---

## Teil 7 — Verifikation (verify.sh + smoke)

Nach dem Menü-Umbau müssen grün sein:

1. **`tools/verify.sh`** — §1 Split-Check, §1b Split-Paar, §2 Reset-Isolation,
   §3 Computed-Styles (54 Props), §3b Component-Probe, §4 Alignment (10/10).
   Alle grün.
2. **`tools/smoke-http.sh`** — 5 Referenz-URLs, alle HTTP 200, kein 5xx.
3. **Nav-URL-Matrix** — jede einzelne Menü-URL separat via `curl -sk -o
   /dev/null -w "%{http_code}"`. Alle 200.
4. **HTML-Assertions** — `grep` auf Home-HTML nach `pxz-nav-list`,
   `pxz-nav-sub`, `pxz-nav-burger`, `pxz-nav-drawer`, `js/nav.js`. Jede
   genau einmal (außer Submenu, das im HTML 2× erscheint: einmal Desktop,
   einmal Drawer).
5. **Active-State-Probe** — `curl /praxis/ | grep 'is-active" aria-current'`
   muss matchen.
6. **Brand-Switch-Probe** — `curl /team/ | grep 'logo-sanexio.svg'` muss
   ≥ 1 liefern.

**Home-Hero unverändert** (visuell) — aber Home-HTML-MD5 ändert sich durch
den Nav-Umbau. Das ist **gewollt** und wird im Self-Check als Risiko R-1
dokumentiert. Nicht jeder MD5-Delta ist ein Bug.

---

## Weiterführende Lektüre

- `Nexus/_memory/patterns/menu-scope-honest-entries.md` — die Entscheidungsregel
- `Nexus/_memory/patterns/wp-nav-progressive-enhancement.md` — die Drawer-Architektur
- `Nexus/_memory/patterns/nav-active-state-url-match.md` — Active-Detection-Helper
- Tutorial 15 (`15-seo-und-header-branding-im-theme.md`) — S2.3-B-Vorgeschichte
  (Unified Site-Header, Brand-Switch)

---

*Stand: 2026-04-22. Update bei S2.4b (Footer) geplant.*
