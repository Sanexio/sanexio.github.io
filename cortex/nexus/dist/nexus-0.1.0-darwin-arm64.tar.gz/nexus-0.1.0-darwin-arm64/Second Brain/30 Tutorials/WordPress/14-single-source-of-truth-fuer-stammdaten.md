# Tutorial 18 — Single-Source-of-Truth für Stammdaten in WordPress-Themes

**Kontext:** praxis-webseite S2.3-kern, Session 17 (2026-04-21)
**Zielgruppe:** Dr. Stracke (Webentwicklungs-Lernpfad)
**Vorausgesetzte Tutorials:** 02 (Git-Bootstrap), 09 (4-Schichten Design-Tokens), 11 (Page-Templates)
**Verwandte Patterns:** `practice-data-ssot.md`, `md5-null-delta-version-normalization.md`, `wp-page-insert-settings-api.md`

---

## Was ist das Problem?

Eine Arztpraxis-Website zeigt an mehreren Stellen dieselben Stammdaten:
- auf der Homepage (Standorte-Sektion)
- auf der Kontakt-Seite (vollständiger Adress-Block)
- auf der Sprechstunden-Seite (Öffnungszeiten-Tabelle)
- im Footer (Notfall-Nummer)

Wenn die Telefonnummer sich ändert, muss man an **drei Stellen** suchen und ändern. Irgendeine Stelle wird vergessen — und die Homepage zeigt dann eine andere Nummer als die Kontaktseite. Patienten rufen bei der falschen Nummer an, Vertrauen leidet.

Lösung: **Eine Datei ist die Wahrheit.** Alle Templates lesen von dort.

---

## Schritt 1: Die Stammdaten-Datei anlegen

Im Theme-Ordner eine Datei `inc/practice-data.php`:

```php
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PXZ_DOCTOLIB_URL', 'https://www.doctolib.de/…' );

function pxz_practice_data() {
    return [
        'de' => [
            'loc_main_title'   => 'Grüneburgweg 12',
            'loc_main_address' => '60322 Frankfurt Westend',
            'loc_hours' => [
                [ 'day' => 'Mo · Di · Do', 'time' => '07:00 – 17:00' ],
                [ 'day' => 'Mi · Fr',      'time' => '08:00 – 15:00' ],
            ],
            // … weitere Felder
        ],
        'en' => [ /* … */ ],
        'fr' => [ /* … */ ],
        'es' => [ /* … */ ],
    ];
}

function pxz_practice_data_for_lang( $lang = null ) {
    if ( $lang === null && function_exists( 'pxz_current_lang' ) ) {
        $lang = pxz_current_lang();
    }
    $all = pxz_practice_data();
    return $all[ $lang ] ?? $all['de'];
}
```

**Warum `function` statt `define`?** Weil eine Funktion je Sprache ein anderes Array liefern kann — ein `define` geht nicht Sprach-abhängig.

**Warum 4 Sprachen fest drin?** Weil die Praxis mehrsprachig arbeitet (de/en/fr/es); das WPML-Plugin stellt `pxz_current_lang()` bereit.

---

## Schritt 2: In `functions.php` einbinden

```php
// vor homepage-data.php — die liest practice-data
require_once PXZ_PATH . '/inc/practice-data.php';
require_once PXZ_PATH . '/inc/homepage-data.php';
```

Reihenfolge wichtig: erst practice-data laden, dann homepage-data. Sonst hat homepage-data keine Zugriff.

---

## Schritt 3: Konsumenten anpassen

### Homepage-Data (merge am Funktionsende)

Bisher waren die `loc_*`-Felder in `homepage-data.php` hartcodiert. Jetzt werden sie am Funktionsende reingemergt:

```php
function pxz_homepage_content() {
    $homepage = [ 'de' => [ /* home-spezifisch, ohne loc_*-Stammdaten */ ], /* … */ ];

    if ( function_exists( 'pxz_practice_data' ) ) {
        $practice = pxz_practice_data();
        foreach ( $homepage as $lang => &$data ) {
            if ( isset( $practice[ $lang ] ) ) {
                $data = array_merge( $data, $practice[ $lang ] );
            }
        }
        unset( $data );
    }
    return $homepage;
}
```

`array_merge` fügt die practice-data-Felder zu jedem Sprachblock hinzu. Das gerenderte Array hat dieselben Keys und Werte wie vorher — **Home bleibt pixelgleich**.

### Kontakt- und Sprechstundenseite

Diese Templates lesen direkt aus `pxz_practice_data_for_lang()`:

```php
// am Anfang von template-kontakt.php
$p = pxz_practice_data_for_lang();

// im Markup
<address><?php echo esc_html( $p['loc_main_address'] ); ?></address>
```

---

## Schritt 4: Beweis, dass der Home-Refactor pixelgleich ist

Das ist das kritische Kriterium: die Homepage darf sich **nicht** ändern. Nachweis-Methode:

```bash
# Vor dem Refactor
curl -sk https://praxis.local/ > home-pre.html

# … Refactor durchführen, PXZ_VERSION bumpen, Commit …

# Nach dem Refactor
curl -sk https://praxis.local/ > home-post.html

# MD5-Vergleich mit Normalisierung der Cache-Buster
PRE=$(sed -E 's/\?(ver|v)=[0-9.]+//g' home-pre.html | md5 -q)
POST=$(sed -E 's/\?(ver|v)=[0-9.]+//g' home-post.html | md5 -q)
[ "$PRE" = "$POST" ] && echo "✅ Null-Delta"
```

**Warum die Normalisierung?** Weil beim Version-Bump alle Asset-URLs sich um `?ver=2.7.14` statt `?ver=2.7.13` ändern. Das ist erwartet und semantisch egal — es gehört rausgefiltert.

Details siehe Pattern `md5-null-delta-version-normalization.md`.

---

## Schritt 5: Die neue Sprechstunden-Seite in die DB einfügen

Wenn im Cluster-Kern eine komplett **neue** Seite entsteht (hier: `/sprechstunden/`), muss sie in `wp_posts` angelegt werden:

```bash
MYSQL="/Applications/Local.app/.../bin/mysql"
DBSOCK="/Users/.../mysqld.sock"

"$MYSQL" --socket="$DBSOCK" -u root -proot -D local --init-command="SET sql_mode='';" << SQL
INSERT INTO wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, menu_order, post_type, post_mime_type, comment_count)
VALUES (1, NOW(), NOW(), '', 'Sprechzeiten & Termin', '', 'publish', 'closed', 'closed', '', 'sprechstunden', '', '', NOW(), NOW(), '', 0, 0, 'page', '', 0);
SET @nid = LAST_INSERT_ID();
INSERT INTO wp_postmeta (post_id, meta_key, meta_value) VALUES (@nid, '_wp_page_template', 'template-sprechstunden.php');
INSERT INTO wp_icl_translations (element_type, element_id, trid, language_code, source_language_code) VALUES ('post_page', @nid, (SELECT COALESCE(MAX(trid),0)+1 FROM wp_icl_translations AS t), 'de', NULL);
DELETE FROM wp_options WHERE option_name='rewrite_rules';
SQL
```

**Zwei nicht-offensichtliche Stolpersteine:**
1. `SET sql_mode=''` — sonst meckert MySQL 8 wegen fehlender `post_excerpt`-Defaults.
2. `wp_icl_translations`-Eintrag — sonst liefert WordPress mit WPML-Plugin auch bei `post_status=publish` einen 404. Die Page existiert, aber WPML filtert sie aus, weil sie keine Sprachzuordnung hat.

---

## Schritt 6: Editierbarer „Aktuelles"-Block für Dr. Stracke

Für den Fall, dass man z. B. einen Ferien-Hinweis direkt auf der Sprechstunden-Seite anzeigen will — ohne an den Code zu müssen:

```php
// in functions.php
add_action( 'admin_init', function() {
    register_setting( 'general', 'pxz_sprechstunden_aktuelles', [
        'type'              => 'string',
        'sanitize_callback' => 'wp_kses_post',
        'default'           => '',
    ] );
    add_settings_section(
        'pxz_sprechstunden_section',
        'Praxiszentrum — Sprechstunden',
        function() { echo '<p>Redaktioneller Inhalt (z. B. Feiertags-Schließzeiten). Leer = Block wird nicht angezeigt.</p>'; },
        'general'
    );
    add_settings_field(
        'pxz_sprechstunden_aktuelles',
        'Aktuelles aus der Praxis',
        function() {
            $val = get_option( 'pxz_sprechstunden_aktuelles', '' );
            echo '<textarea name="pxz_sprechstunden_aktuelles" rows="6" cols="70" class="large-text code">' . esc_textarea( $val ) . '</textarea>';
        },
        'general',
        'pxz_sprechstunden_section'
    );
} );
```

Im Template:
```php
$aktuelles = trim( (string) get_option( 'pxz_sprechstunden_aktuelles', '' ) );
if ( $aktuelles !== '' ) : ?>
    <section class="pxz-sprechstunden-aktuelles">
        <?php echo wp_kses_post( wpautop( $aktuelles ) ); ?>
    </section>
<?php endif;
```

Dr. Stracke findet das dann unter **wp-admin → Einstellungen → Allgemein** ganz unten. Kein ACF, kein eigenes Admin-Menü. Leer lassen = Block verschwindet.

---

## Was haben wir damit gewonnen?

1. **Eine Datei für Stammdaten.** Wenn die Telefonnummer sich ändert, nur `practice-data.php` anpassen — Home + Kontakt + Sprechstunden ziehen sich automatisch.
2. **Mehrsprachig von Anfang an.** Die Struktur hält 4 Sprachen bereits vor; Sprint 3 WPML muss nur noch die Sprachumschaltung anziehen.
3. **Beweisbarer pixelgleicher Refactor.** MD5-Null-Delta zeigt: nichts Sichtbares hat sich verändert.
4. **Editierbarkeit für Dr. Stracke ohne Code-Abhängigkeit.** Ferien-Hinweise, Notfallhinweis, neue Ärztin — alles direkt im WP-Admin pflegbar.

---

## Anti-Patterns (was man vermeiden soll)

- **ACF-Field-Group** nur für Stammdaten — overkill + zusätzliche Plugin-Abhängigkeit.
- **Stammdaten als `define`-Konstanten** — geht nur bei einer Sprache.
- **`include` statt `require_once`** — bei 2. Include zerschießt sich die Funktion-Definition.
- **Byte-MD5 ohne Normalisierung** beim Refactor-Beweis → falscher Alarm bei Version-Bump.

---

## Zusammenfassung

Single-Source-of-Truth + Merge-Pattern ist ein sauberes Idiom für multilingualen Theme-Code. Es ist lesbarer, wartbarer und macht Refactoring ohne Risiko möglich — weil man den MD5-Beweis hat, dass sich nichts verändert hat.

Der nächste Schritt in unserem Lernpfad: wie macht man Tabellen und Tabellen-artige Daten (Ärzte-Liste, Sprechzeiten pro Arzt) genauso sauber verfügbar?
