---
type: lernpfad
category: wordpress
aliases: [Lernpfad WordPress, WordPress-Lernpfad]
tags: [lernpfad, wordpress, index]
---

# Lernpfad — WordPress (Praxis-Lessons)

> Praxis-Lessons aus dem Praxis-Webseiten-Sprint (Cortex-Web /
> praxis-webseite). WordPress-Spezifika: Theme, REST-API, Templates,
> Bridge-Pages, Verify-Probes, Render-Quellen.
>
> Reorganisation 2026-05-05 (Sprint F2): 21 Module aus Webdesign-Domäne
> hierher verschoben + 2 bestehende Module = 22 Module.
> Generische Webdesign-Konzepte (Tokens, Type-Scale, Cascade) bleiben in
> [[Webdesign Grundlagen|Webdesign]].

---

## Block 1 — Lifecycle & Cleanup

| # | Tutorial | Lernziel |
|---:|---|---|
| 01 | [[01-db-cleanup-fallstricke]] | DB-Cleanup-Fallstricke (Hard-Delete vs. Trash, Backup-Pflicht) |
| 02 | [[02-manueller-deploy-host-server]] | Manueller Deploy auf Host-Server (FTPS, cPanel-Constraints) |

---

## Block 2 — Setup & Versionskontrolle

| # | Tutorial | Lernziel |
|---:|---|---|
| 03 | [[03-git-bootstrap-und-page-registry]] | Git-Workflow für WP-Projekte aufsetzen, Page-Registry |
| 06 | [[06-cross-repo-subsumption-mit-git-subtree]] | Mehrere Repos unter einem Common Trunk via `git subtree` |

---

## Block 3 — Content-Migration & Inhalt

| # | Tutorial | Lernziel |
|---:|---|---|
| 07 | [[07-seiten-inventar-website-relaunch]] | Vollständiges Seiten-Inventar als erste Pflichtarbeit beim Relaunch |
| 12 | [[12-utf8-mojibake-und-trunk-ready-inventar]] | Zeichensatz-Probleme erkennen, Mojibake reparieren |
| 13 | [[13-content-archive-md5-contract]] | Content-Migration mit MD5-Verträgen — keine stille Inhaltsdrift |
| 14 | [[14-single-source-of-truth-fuer-stammdaten]] | Stammdaten (Adressen, Sprechzeiten, Ärzte) zentral halten |

---

## Block 4 — REST-API & Adapter

| # | Tutorial | Lernziel |
|---:|---|---|
| 04 | [[04-wp-rest-api-adapter-mit-application-passwords]] | Inhalte programmatisch via WP-REST-API holen, App-Passwords |

---

## Block 5 — Theme: Templates & Auto-Discovery

| # | Tutorial | Lernziel |
|---:|---|---|
| 08 | [[08-wp-page-templates-und-auto-discovery]] | Eigene Seitentypen im Theme definieren, Auto-Discovery |
| 19 | [[19-template-parts-mit-is-page-guard]] | Template-Teile, gezielt nur auf bestimmten Seiten ausspielen |
| 11 | [[11-seo-und-header-branding-im-theme]] | SEO-Grundlagen, Title/Description, Header-Branding im Theme |
| 20 | [[20-blocksy-footer-override]] | Blocksy-Theme-Footer überschreiben (Praxis-Anwendung) |

---

## Block 6 — Render-Quellen & Theme-First

| # | Tutorial | Lernziel |
|---:|---|---|
| 21 | [[21-theme-render-source-vor-db-schreiben]] | Theme-Render-Source vor DB-Schreiben (Source-of-Truth-Hierarchie) |
| 15 | [[15-bridge-pages-trunk-rendered]] | Bridge-Pages aus dem Common Trunk rendern |
| 22 | [[22-detail-page-mirror-shopify-zu-wp]] | Detail-Pages aus Shopify-Trunk auf WP spiegeln |

---

## Block 7 — Navigation & URL-Struktur

| # | Tutorial | Lernziel |
|---:|---|---|
| 16 | [[16-navigation-restrukturierung-und-mobile-drawer]] | Menü-Architektur, mobile Drawer-Komponente |
| 17 | [[17-detail-pages-mit-cross-navigation]] | Detailseiten mit seitenübergreifender Navigation, Breadcrumbs |
| 18 | [[18-wp-nested-pages-und-old-slug-redirects]] | Seitenhierarchien, alte URLs sauber umleiten |

---

## Block 8 — Verify, Tests, Plugin-Lifecycle

| # | Tutorial | Lernziel |
|---:|---|---|
| 05 | [[05-review-pipeline-und-local-wp-tests]] | Review-Pipeline für sichere CSS-Änderungen, Local-WP-Tests |
| 09 | [[09-verify-probe-architektur-und-wp-rewrite-grenze]] | Verify-Probes mit Puppeteer, Grenzen von WP-Rewrite |
| 10 | [[10-wp-plugin-sicher-entfernen]] | Plugin sicher entfernen ohne Bestand zu verlieren |

---

## Verwandte Notizen

- [[WordPress Grundlagen]] — Domänen-Landing
- [[Webdesign Grundlagen|Webdesign]] — generische CSS/Token-Module
- [[_MOC Tutorials]] — Tutorial-Index
- [[Praxis-Webseite]] — Projekt, aus dem die meisten Lessons stammen

*Aufgesetzt 2026-05-05 (Sprint F2): 21 Module aus Webdesign zugewandert + 2 bestehende = 22.*
