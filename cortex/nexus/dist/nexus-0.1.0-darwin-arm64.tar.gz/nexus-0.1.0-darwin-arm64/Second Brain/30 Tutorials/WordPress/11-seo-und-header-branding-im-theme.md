# 15 · SEO-Metadaten und Header-Branding im Theme selbst

> **Warum lesenswert:** Nach diesem Kapitel können Sie nachvollziehen, warum
> SEO-Plugins (All In One SEO, Yoast, RankMath) ihre Stärke haben, wann das
> Theme die Kontrolle übernehmen sollte, und wie ein Multi-Brand-Header (ein
> Logo pro URL-Kontext) technisch sauber gelöst wird — ohne das Plugin zu
> deaktivieren oder das Parent-Theme zu ersetzen.
>
> Stand: 2026-04-19 (Sprint-2 / S2.3-B).

---

## Warum überhaupt SEO im Theme?

Standard-Weg für SEO-Metadaten (Title-Tag, Meta-Description, Open Graph,
Schema.org-JSON-LD) ist ein Plugin. Das ist praktisch, weil:

- UI im Admin zum Bearbeiten pro Seite
- Import/Export
- SERP-Preview
- Integrations mit Analytics

**Der Haken:** Das Plugin ist eine zusätzliche Abhängigkeit. Updates können
die Ausgabe verändern, einzelne Seiten sind schwer zu überschreiben
(AIOSEO hookt z.B. mit Priorität `99999`), und die Wahrheit über die
SEO-Ausgabe lebt nicht im Git-Repo, sondern in der WP-DB.

Für Seiten, bei denen **du exakt bestimmen willst, was im `<head>` steht**
— z.B. Produkt-Seiten mit Schema.org-MedicalClinic — ist eine theme-eigene
SEO-Schicht sauberer. Der Rest der Site kann weiter vom Plugin verwaltet
werden.

---

## Die Architektur: zwei kleine Dateien

```
inc/
├── seo-data.php   ← Daten pro Seite (title, description, canonical, JSON-LD)
└── seo-meta.php   ← Renderer im wp_head + Plugin-Overrides
```

### `inc/seo-data.php` — pro Seite ein Eintrag

```php
function pxz_seo_data_for_current() {
    if ( is_404() )            return pxz_seo_data_404();
    if ( is_page( 'praxis' ) ) return pxz_seo_data_praxis();
    if ( is_page( 'team' ) )   return pxz_seo_data_team();
    return null; // kein Override → Plugin/Theme-Default
}

function pxz_seo_data_praxis() {
    return [
        'title'       => 'Internist Frankfurt Westend – Praxiszentrum Dr. Stracke …',
        'description' => 'Internistische Schwerpunktpraxis …',
        'canonical'   => 'https://westend-hausarzt.com/praxis/',
        'robots'      => 'index, follow',
        'og_type'     => 'website',
        'jsonld'      => [
            '@context' => 'https://schema.org',
            '@type'    => 'MedicalClinic',
            'name'     => 'Praxiszentrum Dr. Stracke und Kollegen',
            // … address, specialty, openingHours etc.
        ],
    ];
}
```

Rückgabewert `null` ist die elegante Ausstiegsluke: auf Seiten ohne eigenen
Eintrag läuft das SEO-Plugin normal weiter.

### `inc/seo-meta.php` — Renderer + zwei Overrides

```php
function pxz_seo_render() {
    $data = pxz_seo_data_for_current();
    if ( ! $data ) return;

    printf( '<meta name="description" content="%s">' . "\n",
            esc_attr( $data['description'] ) );
    printf( '<link rel="canonical" href="%s">' . "\n",
            esc_url( $data['canonical'] ) );
    printf( '<meta property="og:title" content="%s">' . "\n",
            esc_attr( $data['title'] ) );

    if ( is_array( $data['jsonld'] ) ) {
        echo '<script type="application/ld+json">' . "\n";
        echo wp_json_encode( $data['jsonld'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
        echo "\n</script>\n";
    }
}
add_action( 'wp_head', 'pxz_seo_render', 1 );
```

---

## Der schwierige Teil: AIOSEO überstimmen

AIOSEO rendert auf **zwei** Hooks gleichzeitig. Ein höher-priorisierter
Filter reicht **nicht**, weil AIOSEO seinen Title-Output `from scratch`
berechnet und das `$title`-Input ignoriert.

### Kampfplatz 1 — Head-Meta

```php
add_action( 'wp_head', function() {
    $data = pxz_seo_data_for_current();
    if ( ! $data ) return;
    if ( function_exists( 'aioseo' ) && isset( aioseo()->head ) ) {
        remove_action( 'wp_head', [ aioseo()->head, 'wpHead' ], 1 );
    }
}, 0 );  // MUSS Priorität 0 sein — vor AIOSEO (Priorität 1)
```

### Kampfplatz 2 — Title-Tag

```php
// Unser Filter mit maximaler Priorität
add_filter( 'pre_get_document_title', function( $title ) {
    $data = pxz_seo_data_for_current();
    return ( $data && ! empty( $data['title'] ) ) ? $data['title'] : $title;
}, PHP_INT_MAX );

// AIOSEO's getTitle explizit entfernen (kritisch!)
add_action( 'wp', function() {
    $data = pxz_seo_data_for_current();
    if ( ! $data ) return;
    if ( function_exists( 'aioseo' ) && isset( aioseo()->head ) ) {
        remove_filter( 'pre_get_document_title',
                       [ aioseo()->head, 'getTitle' ], 99999 );
    }
}, 1 );
```

### Plugin-Methoden-Namen sind Version-spezifisch

AIOSEO 4.9.x nutzt `wpHead` und `getTitle` — andere Versionen können
anders heißen. Wenn ein Override nicht greift, auflisten:

```php
global $wp_filter;
foreach ( $wp_filter['pre_get_document_title']->callbacks as $prio => $cbs ) {
    foreach ( $cbs as $name => $cb ) {
        $fn = $cb['function'];
        $label = is_array( $fn )
            ? get_class( $fn[0] ) . '::' . $fn[1]
            : ( is_string( $fn ) ? $fn : 'closure' );
        echo "prio $prio: $label\n";
    }
}
```

---

## Header-Branding: ein Logo pro URL

Zweiter Teil dieses Kapitels: Was tun, wenn die Praxis-Seite
"Praxiszentrum Dr. Stracke" heißt, die Team-Seite aber "Praxisgemeinschaft
Sanexio" — also ein anderes Logo zeigen soll?

### Schritt 1: Header in ein Template-Part extrahieren

Wenn die Nav nur in `template-homepage.php` hardcodiert ist, sieht jede
andere Seite den Blocksy-Default-Header (mit stale `blogname`). Fix:

```php
// template-parts/header-nav.php
$uri = $_SERVER['REQUEST_URI'] ?? '';
$is_sanexio = (bool) preg_match( '#^/team/?(\?|$)#', $uri );
?>
<header class="pxz-nav <?php echo $is_sanexio ? 'pxz-nav-sanexio' : 'pxz-nav-praxis'; ?>">
  <?php if ( $is_sanexio ) : ?>
    <a class="pxz-nav-logo-sanexio">
      <img src=".../assets/logo-sanexio.svg" alt="Praxisgemeinschaft Sanexio">
    </a>
  <?php else : ?>
    <a class="pxz-nav-logo-praxis">
      <img src=".../assets/logo.svg" alt="Praxiszentrum …">
      <span class="pxz-nav-logo-text">
        <span class="top">Praxiszentrum</span>
        <span class="sub">Dr. Stracke & Kollegen</span>
      </span>
    </a>
  <?php endif; ?>
</header>
```

Dann in jedem Page-Template nach `get_header()`:

```php
get_template_part( 'template-parts/header-nav' );
```

### Schritt 2: Parent-Theme-Default-Header ausblenden

Neue Datei `assets/css/nav.css`, **unconditional** enqueued:

```css
/* Parent-Theme-Default (Blocksy) site-weit ausblenden */
#header.ct-header { display: none !important; }

/* .pxz-nav-Regeln hier — gelten auf jeder Seite */
.pxz-nav { position: sticky; top: 0; … }
.pxz-nav-logo-praxis img {
    width: 151px !important; height: 151px !important;
}
.pxz-nav-logo-sanexio img {
    width: 240px !important; height: auto !important;
    aspect-ratio: 800 / 270;
}
```

Warum `!important`? Weil das Parent-Theme typisch `img { max-width: 100% }`
setzt — das würde das Logo zerquetschen. Die `!important`-Regeln schlagen
das Parent-Reset.

### Schritt 3: URL-basierter `blogname`-Filter (optional)

Wenn das Parent-Theme den Site-Title textuell rendert, ebenfalls
URL-abhängig überschreiben:

```php
add_filter( 'pre_option_blogname', function( $pre ) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    if ( preg_match( '#^/team/?(\?|$)#', $uri ) ) {
        return 'Praxisgemeinschaft Sanexio';
    }
    return $pre;
});
```

**Warum URL-basiert, nicht `is_page()`?** Weil dieser Filter in der
Bootstrap-Phase gefeuert wird — vor `WP_Query::parse_query()`.
`is_page()` ist dann noch nicht zuverlässig.

---

## Verify-Check für SEO-Output

Bash-Script mit `curl` + `grep` pro Seite:

```bash
assert_grep() {
    local body; body="$(curl -sk "$1")"
    if printf '%s' "$body" | grep -qE "$2"; then
        echo "✓ $3"
    else
        echo "✗ $3"
    fi
}
assert_grep "$URL/praxis/" "<title>Internist Frankfurt Westend" "title tag"
assert_grep "$URL/praxis/" "@type.*MedicalClinic" "JSON-LD type"
```

**Achtung SIGPIPE-Falle:** `set -o pipefail` + `grep -q` + `curl` zusammen
erzeugen false-negatives bei großen Outputs. Entweder `pipefail` weglassen
oder — wie oben gezeigt — den curl-Output erst in eine Variable
buffern, dann per `printf` ins Grep leiten.

---

## Zusammenfassung

| Problem | Lösung |
|---|---|
| SEO pro Page exakt kontrollieren | `inc/seo-data.php` + `inc/seo-meta.php` |
| Plugin-Title überschreiben | `pre_get_document_title` (PHP_INT_MAX) **und** Plugin-Hook per `remove_filter` entfernen |
| Plugin-Head-Meta überschreiben | `wp_head` Priorität 0 → `remove_action` auf Plugin-`wpHead` |
| Header auf allen Seiten einheitlich | Nav in `template-parts/header-nav.php` extrahieren + `get_template_part` in jeder Template |
| Parent-Theme-Header ausblenden | `#header.ct-header { display: none !important }` in unconditional-enqueued CSS |
| Logo pro URL wechseln | URL-Regex-Check + zwei Logo-Varianten in `assets/` |
| `blogname` pro URL wechseln | `pre_option_blogname`-Filter (URL-basiert, nicht `is_page()`) |

---

## Referenz-Patterns

- `Nexus/_memory/patterns/wp-plugin-head-override.md`
- `Nexus/_memory/patterns/wp-unified-site-header.md`
- `Nexus/_memory/patterns/wpml-translations-direct-sql.md`
- `Nexus/_memory/patterns/bash-sigpipe-grep-trap.md`

## Referenz-Spec

- `Cortex-Web/sites/praxis-webseite/specs/sprint-2/S2.3-B_praxis-team-404.md`

---

*Tutorial angelegt 2026-04-19 Session 14 (Praxis-Sprint-2 / S2.3-B). Aus
vier Lessons Learned: SEO-Schicht theme-eigen, AIOSEO-Override mit
richtiger Priorität **und** Unhook, Nav-Extraktion in Template-Part,
URL-basiertes Multi-Brand-Setup.*
