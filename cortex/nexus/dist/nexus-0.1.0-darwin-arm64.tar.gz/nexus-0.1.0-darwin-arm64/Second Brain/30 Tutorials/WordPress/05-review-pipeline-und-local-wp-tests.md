# 07 — Review-Pipeline und automatisierte Local-WP-Tests

> Entstanden 2026-04-19 aus Cortex-Web Phase 3 (`Commit 98d1f67`).
> Zielgruppe: Dr. Stracke. Erklärt, **warum** wir für Cortex-Web eine eigene
> Review-Pipeline brauchten, **was** sie prüft, und **welche Stolperfallen**
> bei automatisierten Tests gegen Local-by-Flywheel (Local-WP) auftreten.

---

## Worum geht es?

Beim Cortex-Web-Projekt rendert **eine einzige YAML-Datei** (der „Trunk") auf
zwei unterschiedliche Webseiten: die **Praxis-Seite** (WordPress, HWG-konform
ohne Preis) und die **Juvantis-Seite** (Shopify, mit Preis und Kauf-CTA).

Die Frage vor Phase 4 war: **Funktioniert das überhaupt zuverlässig?** Unit-Tests
beantworten das nicht — sie prüfen einzelne Bausteine, nicht das Zusammenspiel
von YAML → Adapter → REST-API → Plattform. Deshalb haben wir eine
**Review-Pipeline** gebaut.

---

## Was ist eine Review-Pipeline?

Ein Shell-Befehl (`bash tools/review.sh`), der nacheinander **alle relevanten
Dimensionen** prüft und ein strukturiertes Evidenz-Paket schreibt:

| Dimension | Was wird geprüft? | Analogie aus der Praxis |
|---|---|---|
| Content-Parität | Steht alles aus dem Trunk auch wirklich auf beiden Seiten? | „Ist jedes Diagnose-Code-Feld im Befund angekommen?" |
| HWG-Compliance | Kein Preis-Wort / Kauf-Button auf der Praxis-Seite | „Kein ‚Werbungsverstoß' im Arztbrief" |
| Commerce-Check | Shopify hat Preis, SKU, Varianten | „Rechnung hat Betrag, Leistungsziffer" |
| Idempotenz | 2. Lauf ändert nichts, erzeugt keine Dubletten | „Befund zweimal verschickt → Patient bekommt ihn nur einmal" |
| Trunk-Master-Roundtrip | Wenn jemand im Shopify-Admin ‚Preis auf 200' setzt, überschreibt der nächste Trunk-Lauf das wieder | „Wahrheit liegt in der Akte, nicht im Kopf" |
| Visueller Vergleich | Screenshots beider Seiten nebeneinander | „Bildgebender Befund, um das Ergebnis zu sehen" |

Jede Dimension schreibt ihr eigenes JSON-Report (`specs/phase-3/evidence/*.json`).
Am Ende aggregiert ein `summary.json` alle AKs („Akzeptanzkriterien"). Entweder
alles grün (Go) oder Stopp (No-Go) — keine Grauzone.

---

## Warum eine neue Disziplin?

Dr. Stracke kennt aus der Medizin den Unterschied:

- **Anamnese + Untersuchung = Unit-Test** (prüft einzelne Befunde)
- **Konsil / Zweitmeinung = Integration-Test** (bringt mehrere Quellen zusammen)
- **Review-Pipeline = Fallvorstellung** (das Gesamtbild wird strukturiert
  durchgegangen, mit Evidenz, nicht mit Bauchgefühl)

Wenn eine Architektur-Entscheidung auf dem Spiel steht („trägt der Ansatz?"),
reicht Bauchgefühl nicht. Eine Review-Pipeline liefert die Entscheidungsgrundlage
**reproduzierbar** — derselbe Befehl liefert morgen dieselbe Evidenz.

---

## Stolperfalle 1 — Local-WP läuft auf HTTPS mit selbstsigniertem Zertifikat

**Symptom:** Puppeteer (der automatisierte Browser-Agent) bricht mit
`net::ERR_CERT_AUTHORITY_INVALID`, wenn er eine Local-WP-Seite öffnen soll.

**Ursache:** Local-by-Flywheel startet jede Dev-Seite unter
`https://<sitename>.local/`. Das Zertifikat ist **selbst ausgestellt** — in der
echten Welt würde ein Browser davor warnen, weil es keine vertrauenswürdige
Zertifizierungsstelle gibt. Puppeteer macht dasselbe, per Default.

**Lösung:** beim Puppeteer-Start explizit sagen, dass Selbstzerts OK sind:

```js
import puppeteer from "puppeteer-core";

const browser = await puppeteer.launch({
  executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  headless: "new",
  acceptInsecureCerts: true,                       // ← erlaubt selbstsignierte Zerts
  args: ["--no-sandbox", "--ignore-certificate-errors"]  // ← Redundanz auf Chrome-Ebene
});
```

**Warum beide Optionen?** Puppeteer-Versionen und Chrome-Versionen driften. Beide
gleichzeitig zu setzen kostet nichts und ist robust gegen Versions-Updates.

**Analogie:** Es ist wie ein Ausweis, den jemand sich selbst gebastelt hat —
offiziell wertlos, aber in der Dev-Umgebung akzeptieren wir den, weil wir wissen,
dass es unser eigener ist.

---

## Stolperfalle 2 — Shell-Scripts mischen Logs und JSON in stdout

**Symptom:** Ein Test-Skript ruft `bash tools/sync-wp.sh` auf, erwartet JSON
zurück, bekommt aber `null`. Der Sync-Lauf selbst war erfolgreich (Exit 0).

**Ursache:** Das Shell-Script druckt **Fortschritt** (`sync-wp: [1/3] validate`),
dann das JSON-Summary des Adapters, **danach** noch `sync-wp: OK`. Wenn man
versucht, das JSON per Regex mit „letzter Block am Ende" zu holen, findet man
nichts — weil das JSON nicht am Ende steht.

**Lösung:** **zeilenbasiert** die letzte schließende `}`-Zeile suchen, rückwärts
zur passenden `{`-Zeile scannen, und JSON.parse() versuchen. Funktioniert bei
jedem pretty-printed JSON (`JSON.stringify(x, null, 2)`), egal welcher Text davor
oder danach steht.

```js
function extractAdapterSummary(stdout) {
  const lines = stdout.split("\n");
  for (let end = lines.length - 1; end >= 0; end--) {
    if (lines[end].trimEnd() === "}") {
      for (let start = end; start >= 0; start--) {
        if (lines[start].trim() === "{") {
          const candidate = lines.slice(start, end + 1).join("\n");
          try { return JSON.parse(candidate); } catch { break; }
        }
      }
    }
  }
  return null;
}
```

**Analogie:** Wie beim Durchblättern einer Patientenakte — man sucht das letzte
Laborblatt, nicht das erste Blatt ganz unten. „Von hinten nach vorne" ist die
robustere Strategie, wenn die Akte noch weiter gewachsen ist als erwartet.

---

## Stolperfalle 3 — Trunk-Master-Test braucht Safety-Net

**Symptom:** Man testet, ob der Adapter Admin-Edits zurücksetzt. Testlauf bricht
in der Mitte ab. Das Produkt im Shopify-Store bleibt auf `status=active` stehen —
und ist jetzt auf einmal **öffentlich**.

**Lösung:** `try { … } finally { forceReset() }`. Egal wie der Test endet,
der `finally`-Block setzt den Zustand zurück auf „Trunk-Wahrheit". Pflicht bei
jedem Test, der Plattform-State mutiert.

**Analogie:** Wie bei einer diagnostischen Punktion: vorher weiß man, wie der
Patient versorgt wird, falls der Eingriff abbricht. Nie eine riskante Aktion
starten, ohne den Exit-Plan bereit zu haben.

---

## Was hat Dr. Stracke davon?

Für zukünftige Projekte (Juvantis-Web, doc-workflow, Amtsanfragen) gilt dieselbe
Frage: „Funktioniert unser Ansatz, bevor wir groß ausrollen?" Die Review-Pipeline
ist das Werkzeug dafür. Sie kostet einmal Einrichten (eine halbe Session),
verhindert aber Monate Ärger, wenn ein Ansatz sich nachträglich als untragbar
erweist.

**Wiederverwendbares Muster:** `Nexus/_memory/patterns/cross-platform-review-pipeline.md`.
Claude zieht das automatisch heran, wenn wieder mal ein Common-Trunk-Setup mit
mehreren Zielen gebaut wird.

---

## Referenz-Implementierung

```
projects/Cortex-Web/
├── tools/
│   ├── review.sh                    ← Bash-Wrapper
│   └── review/                      ← 6 Module + Orchestrator
└── specs/phase-3/
    ├── REVIEW.md                    ← Spec (Architekten-Modus Phase 2)
    └── evidence/
        ├── 2026-04-19_self-check.md ← Ergebnis (12/12)
        ├── *.json                   ← Maschinen-lesbare Berichte
        ├── *.png                    ← Screenshots
        └── side-by-side.html        ← lokal im Browser öffnen
```

Zum Anschauen: im Finder zu `specs/phase-3/evidence/` navigieren, `side-by-side.html`
doppelklicken. Browser zeigt WP-Seite links, Shopify-Rendering rechts.
