# Tutorial 21 — Detail-Pages mit Cross-Navigation: kein Profil steht allein

**Stand:** 2026-04-22 · Sprint 2 / S2.3-aerzte-services · PXZ_VERSION 2.7.17
**Vorgänger:** Tutorial 18 (SSoT für Stammdaten) · Tutorial 20 (Navigation)

---

## Was ist hier neu?

Diese Lektion löst zwei Probleme, die in jeder Webseite mit „Personen, Produkten,
Standorten" auftauchen:

1. **Stub-Pages ehrlich gestalten** — wenn ein Detail-Profil noch keinen
   ausführlichen Inhalt hat (z. B. „Vorstellung folgt"), wie macht man die
   Page trotzdem nutzbar?
2. **Sackgassen-Vermeidung** — wie surface ich auf jeder Detail-Page alle
   Geschwister, ohne Drift, ohne Wartungsschmerz?

Konkretes Beispiel aus S2.3-aerzte-services:
- 8 Ärzte in der Praxisgemeinschaft Sanexio
- Dr. Stracke hat ein ausführliches Profil aus dem WP-Archive (Werdegang, MBA, Studium)
- 7 weitere haben aktuell nur Initialen-Avatar + Name + Rolle (Stub)
- **Trotzdem müssen ALLE 8 jederzeit klickbar erreichbar sein** (Auftraggeber-Wunsch)

---

## Lehrsatz 1 — Detail-Page-Daten kommen aus einer SSoT, nicht aus DB-Feldern

In `inc/team-data.php`:

```php
function pxz_team_doctors() {
    $doctors = [
        [ 'slug'=>'dr-stracke', 'name'=>'Dr. Stracke', 'title'=>'Internist', … ],
        [ 'slug'=>'docteur-saul', 'name'=>'Docteur Saul', … ],
        // …8 total
    ];
    foreach ( $doctors as &$d ) $d['profile_url'] = '/' . $d['slug'] . '/';
    return $doctors;
}
```

Die einzige Wahrheit. Ein neuer Arzt = ein Array-Eintrag.

**Warum nicht Custom Post Type oder ACF-Feldgruppe?** Weil das Team eine
geschlossene Menge mit niedriger Änderungsrate ist (8 Ärzte, alle paar Monate
einer mehr/weniger). PHP-Array ist git-trackbar, code-review-pflichtig und
schnell zu lesen. CPT/ACF wären Overhead für 8 Datensätze.

Die WP-Page (DB) trägt nur drei Dinge:
- den **Slug** (für die URL und für `get_post()->post_name` im Template)
- den **Title** (für `<title>` und Crumbs)
- optional **`post_content`** für ausführlichen Vita-Block (Stracke ja, andere leer)

Alles andere — Bild, Sprachen, Rolle, Schwerpunkt — kommt aus `pxz_team_doctors()`.

---

## Lehrsatz 2 — Stub-Pages sind keine Karteileichen, wenn sie ehrlich sind

Schlechte Stub-Page:
```html
<h1>Dr. Müller</h1>
<p>Lorem ipsum dolor sit amet…</p>
```
→ wirkt wie ein Bug, kein Vertrauen.

Ehrliche Stub-Page (S2.3-aerzte-services Pattern):
```html
<section class="pxz-arzt-hero">
  <span class="initials">FM</span>
  <h1>Dr. Fabian Müller</h1>
  <p>Facharzt für Innere Medizin</p>
  <ul class="langs"><li>DE</li><li>EN</li></ul>
</section>
<section class="pxz-arzt-vita">
  <h2>Über Dr. Fabian Müller</h2>
  <p>Schwerpunkt Innere Medizin.</p>
  <p class="callout">Eine ausführliche Vorstellung mit Werdegang,
    Schwerpunkten und persönlichem Profil folgt in Kürze. Termine
    sind selbstverständlich bereits jetzt buchbar.</p>
</section>
<section class="pxz-arzt-others"><!-- 7 Cards der Kollegen --></section>
<section class="pxz-arzt-cta"><!-- Termin-Buttons --></section>
```

Stub-Pages dürfen kürzer sein als Voll-Pages, müssen aber:
- echtes Hero (Avatar, Name, Rolle, Sprachen) zeigen
- ehrlich kommunizieren („Vorstellung folgt")
- alle Cross-Navigations-Möglichkeiten haben (Other-Doctors-Sektion + CTA)
- echte SEO-Meta liefern (`<title>`, `description`, schema.org/Person)

Dann ist die Page **funktional vollständig**, auch wenn der Long-Content fehlt.

---

## Lehrsatz 3 — Cross-Navigation als Helper-Funktion, nicht als Template-Code

Schlecht (Code in jeder Detail-Page-Template-Datei):
```php
foreach ( $all_doctors as $d ) {
  if ( $d['slug'] === $current_slug ) continue;
  echo '<a href="…">…</a>';
}
```
→ 8× kopiert auf 8 Templates? Drift-Garantie.

Gut (Helper):
```php
// inc/team-data.php
function pxz_render_other_doctors( $exclude_slug ) {
    $others = array_filter( pxz_team_doctors(), fn($d) => $d['slug'] !== $exclude_slug );
    // Returns finished HTML
}

// template-arzt.php
echo pxz_render_other_doctors( get_post()->post_name );
```

Eine Funktion, eine Stelle, jede Detail-Page bekommt das Update.

---

## Lehrsatz 4 — Brand-Switch über Helper, nicht über hartcodierte Regex

Vor S2.3-aerzte-services war der Sanexio-Brand-Switch im Header so:

```php
// header-nav.php — alte Regex, fest verdrahtet
$is_sanexio = (bool) preg_match( '#^/team/?(\?|$)#', $uri );
```

Jetzt soll der Switch auch auf 8 Arzt-Slugs greifen. Naive Lösung wäre:

```php
$is_sanexio = (bool) preg_match( '#^/(team|dr-stracke|docteur-saul|dr-barcsay|dr-seelig|dr-jawich|dr-shahin|dr-landeberg|dr-arbitmann)/?(\?|$)#', $uri );
```

→ Wenn ein neuer Arzt ins Team kommt, vergisst man die Regex zu erweitern.

Pattern-Lösung:

```php
// inc/team-data.php
function pxz_is_sanexio_uri( $uri ) {
    if ( preg_match( '#^/team/?(\?|$)#', $uri ) ) return true;
    foreach ( pxz_doctor_slugs() as $slug ) {
        if ( preg_match( '#^/' . preg_quote( $slug, '#' ) . '/?(\?|$)#', $uri ) ) return true;
    }
    return false;
}

// header-nav.php
$is_sanexio = pxz_is_sanexio_uri( $uri );
```

Helper liest die Slugs aus der SSoT. Ein neuer Arzt → Brand-Switch wirkt
automatisch, ohne dass irgendjemand am Header denken müsste.

**Wichtig:** Der Helper muss VOR dem `pre_option_blogname`-Filter geladen sein.
Daher in `functions.php` früh:

```php
require_once PXZ_PATH . '/inc/team-data.php';
add_filter( 'pre_option_blogname', function( $pre ) {
    if ( pxz_is_sanexio_uri( $_SERVER['REQUEST_URI'] ) ) return 'Sanexio';
    return $pre;
} );
```

`function_exists()`-Guard im Filter ist Sicherheitsnetz, kein Ersatz für
korrekte Lade-Reihenfolge.

---

## Lehrsatz 5 — `grep -c` zählt Zeilen, nicht Vorkommen

WordPress rendert oft alles in eine einzige HTML-Zeile (besonders mit
Komprimierung). Bei der Verifikation:

```bash
# FALSCH — zählt Zeilen mit Treffern, nicht Treffer
curl /dr-stracke/ | grep -c 'pxz-arzt-others-card'
# Output: 1   (alles auf einer Zeile)

# RICHTIG — zählt einzelne Vorkommen
curl /dr-stracke/ | grep -oE 'pxz-arzt-others-card' | wc -l
# Output: 7   (7 Other-Doctors-Cards)
```

Diese Lektion wurde live bei der AK-3-Verifikation entdeckt — die Self-Check-Tabelle hatte zunächst „1× others-card" stehen, was falsch wirkte. Erst der Wechsel auf `grep -oE … | wc -l` zeigte das korrekte Bild.

---

## Praktischer Workflow zum Nachbauen

### 1. Daten-SSoT anlegen
```php
// inc/{entity}-data.php
function pxz_{entities}() { return [ /* array */ ]; }
function pxz_{entity}_slugs() { /* derived */ }
function pxz_{entity}_by_slug( $slug ) { /* lookup */ }
function pxz_render_other_{entities}( $exclude ) { /* HTML */ }
```

### 2. Detail-Template produktiv machen
```php
// template-{entity}.php
$current = get_post()->post_name;
$data    = pxz_{entity}_by_slug( $current );
// Hero with $data['name'], $data['title']
// Optional: the_content() for curated long-form, fallback to placeholder
echo pxz_render_other_{entities}( $current );
// CTA section
```

### 3. Migration für DB-Pages
```php
// tools/migrations/YYYY-MM-DD_{name}.php
foreach ( $entities_to_create as [ $slug, $title ] ) {
    ensure_page( $mysqli, $slug, $title, '', 'template-{entity}.php' );
    upsert_wpml_de( $mysqli, $id );
}
```

### 4. Verifikation
```bash
for slug in $SLUGS; do
  curl -sk "$URL/$slug/" -o /dev/null -w "%{http_code}\n"
  test_count=$(curl -sk "$URL/$slug/" | grep -oE 'class="other-card"' | wc -l)
  expected=$((${#SLUGS[@]} - 1))
  [ "$test_count" = "$expected" ] && echo "OK" || echo "FAIL"
done
```

---

## Was Du nicht tun solltest

- **Stubs nicht algorithmisch füllen** („Lorem ipsum") — wirkt unprofessionell
- **Cross-Link-Sektion nicht weglassen, weil „nur 3 Items"** — auch bei wenigen Geschwistern verbessert die Sektion das Mental-Model
- **Stub und Voll-Page nicht in unterschiedliche Templates trennen** — gleiches Template, anderer Inhalt; sonst Layout-Drift
- **SSoT nicht in DB verlagern „weil flexibler"** — bei <20 Datensätzen ist PHP-Array besser (Code-Review, Git-Diff, kein Settings-API-UI nötig)

---

## Verbundene Patterns (Nexus/_memory/patterns/)

- `entity-roster-ssot.md` — Single-Source-of-Truth für Entitäts-Listen
- `cross-link-no-isolation-pattern.md` — UX-Pattern „kein Detail steht allein"
- `practice-data-ssot.md` — gleiche Idee für Stammdaten (Adressen)
- `wp-cross-brand-cta-registry.md` — Cross-LINKS zwischen Marken (verwandt)

---

*Tutorial-Geburt: S2.3-aerzte-services — 8 Arzt-Profile, davon 7 als ehrliche Stubs, alle wählbar.*
