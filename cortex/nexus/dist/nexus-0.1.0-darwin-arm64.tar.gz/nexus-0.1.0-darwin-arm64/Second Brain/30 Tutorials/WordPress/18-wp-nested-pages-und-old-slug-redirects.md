# 22 — Nested-Pages, Old-Slug-Redirects und rechtlich gegatete Migrationen

> Kontext: Praxis-Webseite Sprint 2, Session 21 (2026-04-22), S2.3-diagnostik.
> Das Tutorial beschreibt drei zusammenhängende Techniken, die beim Aufbau
> des Diagnostik-Clusters nötig waren — und die bei jeder zukünftigen
> Content-Umstellung mit Slug-Änderungen wieder relevant werden.

---

## Worum es geht

Beim Umzug eines bestehenden WordPress-Inhalts auf eine neue Slug-Struktur fallen drei Probleme gleichzeitig an:

1. **Hierarchie aufbauen** — aus einer flachen Slug-Liste (`/ultraschall-der-beingefaesse/`) eine echte Baumstruktur machen (`/sonographie/beingefaesse/`).
2. **Alte URLs am Leben halten** — Backlinks und Lesezeichen sollen per 301 auf den neuen Slug zeigen, sonst verliert Google Trust.
3. **Rechtlich unsicheren Content nicht aus Versehen live schalten** — Patientenbilder, Zitate, Externa brauchen separate Freigabe, aber die Migration soll trotzdem weitergehen können.

Dieses Tutorial zeigt die drei Mechanismen und wie sie ineinandergreifen.

---

## Teil 1 — Nested Pages über `post_parent`

WordPress kann aus einer flachen Page-Struktur automatisch Nested-URLs bauen, **wenn man `post_parent` setzt**. Der Permalink wird dann aus der Kette `/parent-slug/child-slug/` generiert.

### Die Migration

```php
// 1. Parent-Page anlegen (oder bestehende umwidmen)
mxq( $mysqli,
    "UPDATE wp_posts SET post_name=? WHERE ID=?",
    'si', 'sonographie', 277 );

// 2. Kinder unter den neuen Parent hängen
mxq( $mysqli,
    "UPDATE wp_posts SET post_name=?, post_parent=? WHERE ID=?",
    'sii', 'schilddruese', 277, 357 );
```

Nach diesen zwei Statements:

- `/sonographie/` → rendert Page 277
- `/sonographie/schilddruese/` → rendert Page 357

Aber erst nach Schritt 2 des Tutorials ↓

### Warum das ohne Flush nicht funktioniert

WordPress speichert die komplette Permalink-Struktur als serialisiertes Array in `wp_options.rewrite_rules`. Dieses wird **nur neu berechnet**, wenn man es explizit löscht oder `flush_rewrite_rules()` aufruft. Ohne Flush matched `/sonographie/schilddruese/` keine bestehende Rule → WP liefert 404.

**Der minimale Fix (ohne WP-Context):**

```sql
DELETE FROM wp_options WHERE option_name = 'rewrite_rules';
```

Das genügt. WP generiert die Rules beim nächsten Frontend-Request neu (Cold-Start-Penalty ≈ 100 ms beim ersten Hit).

### Was man NICHT tun sollte

- ❌ Die Page-Hierarchie per Admin-UI klicken, wenn man sowieso ein Migrations-Script hat — das Admin-Save triggert zwar den Flush, aber nicht reproduzierbar und nicht unter Versionskontrolle.
- ❌ `.htaccess` händisch editieren — WP überschreibt das beim nächsten Permalink-Save.
- ❌ Rewrite-Rules als Plugin einbauen — für ein internes Hierarchie-Update overengineered.

---

## Teil 2 — `_wp_old_slug` Redirects (und warum sie für Pages unzuverlässig sind)

Wenn man `post_name` ändert, merkt sich WordPress automatisch den alten Slug als `_wp_old_slug` in `wp_postmeta`. Der Core-Hook `wp_old_slug_redirect` soll dann bei Anfragen an den alten Slug eine 301-Weiterleitung erzeugen.

**Für `post_type=post` funktioniert das zuverlässig.**

**Für `post_type=page`** ist es in vielen Setups buggy — besonders in Kombination mit WPML, Nested-Hierarchien oder Custom-Permalink-Strukturen. In unserem Setup lieferten 4 von 5 Page-Slug-Redirects HTTP 404 statt 301.

### Der Theme-Helper als Fallback

Einfacher, deterministischer, priority 5 im `template_redirect`-Hook:

```php
add_action( 'template_redirect', 'pxz_old_slug_fallback_redirect', 5 );
function pxz_old_slug_fallback_redirect() {
    if ( ! is_404() ) return;

    $uri = trim( strtok( $_SERVER['REQUEST_URI'], '?' ), '/' );
    if ( ! $uri ) return;

    $parts    = explode( '/', $uri );
    $old_slug = end( $parts );

    global $wpdb;
    $post_id = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT pm.post_id FROM {$wpdb->postmeta} pm
           INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
         WHERE pm.meta_key = '_wp_old_slug'
           AND pm.meta_value = %s
           AND p.post_type = 'page'
           AND p.post_status = 'publish'
         LIMIT 1",
        $old_slug
    ) );
    if ( ! $post_id ) return;

    $link = get_permalink( $post_id );
    if ( ! $link || $link === home_url( $_SERVER['REQUEST_URI'] ) ) return;

    wp_safe_redirect( $link, 301 );
    exit;
}
```

### Warum der `post_status='publish'`-Filter wichtig ist

Ohne diesen Filter würde der Helper auch für Draft-Seiten weiterleiten. Das führt zu `?page_id=X` als Redirect-Ziel (WP kann für Drafts keinen Pretty-Permalink generieren) — und dann wieder 404 für Besucher (Draft-Seiten sind öffentlich nicht erreichbar). Ergebnis: 301 → 404, schlechter als ein simpler 404.

Der Filter „nur weiterleiten wenn Ziel publish" sorgt dafür, dass:

- Alte Slugs, deren Nachfolger publish ist → sauberer 301.
- Alte Slugs, deren Nachfolger draft ist → bleiben 404 (korrekt — das Ziel ist noch nicht bereit).
- Sobald der Nachfolger auf publish gesetzt wird, greift der Redirect automatisch.

### Migration-Schritt: Meta pflegen

Wenn das Migrations-Script den Slug ändert, setzt es zusätzlich `_wp_old_slug`:

```php
function set_old_slug( $mysqli, $apply, $post_id, $old_slug ) {
    $existing = fetch_row( $mysqli,
        "SELECT meta_id FROM wp_postmeta
         WHERE post_id=? AND meta_key='_wp_old_slug' AND meta_value=?
         LIMIT 1",
        'is', $post_id, $old_slug );
    if ( $existing ) return; // idempotent
    mxq( $mysqli,
        "INSERT INTO wp_postmeta (post_id, meta_key, meta_value)
         VALUES (?, '_wp_old_slug', ?)",
        'is', $post_id, $old_slug );
}
```

---

## Teil 3 — Der Draft-Gate für rechtlich offenen Content

**Situation:** Eine der migrierten Seiten enthält medizinische Befundbilder. Die Einwilligung der dargestellten Patienten müsste Dr. Stracke zuerst juristisch klären — das dauert. Die Migration soll aber nicht blockiert werden.

### Die Strategie

1. Die Seite **wird migriert** — Slug, Parent, Content, `_wp_old_slug`, alles wie bei den anderen Pages.
2. Aber `post_status=draft` statt `publish`.
3. Das Migrations-Script kennt eine Environment-Variable, die das Verhalten steuert:

```bash
# Variante 1: Alles bis auf die sensitive Seite migrieren (Default)
APPLY=1 php migrate.php

# Variante 2: Sensitive Seite als draft migrieren
APPLY=1 INCLUDE_SENSITIVE_CONTENT=draft php migrate.php

# Variante 3: Sensitive Seite sofort publish (wenn Klärung fertig ist)
APPLY=1 INCLUDE_SENSITIVE_CONTENT=1 php migrate.php
```

### Wichtig: `getenv` normalisieren

PHP's `getenv()` gibt `false` zurück, wenn die Variable nicht gesetzt ist — **nicht** `''`. Bei Strict-Comparison fehlerhaft:

```php
// ❌ Falsch
if ( getenv('FLAG') === '' ) { /* default-pfad */ }
// getenv() liefert false, false !== '' → falsche Abzweigung

// ✅ Richtig
$raw  = getenv( 'FLAG' );
$flag = ( $raw === false ) ? '' : (string) $raw;
if ( $flag === '' ) { /* default-pfad */ }
```

In Session 21 hätte dieser Bug ohne Fix zum Publish der sensitiven Seite geführt, obwohl die Environment-Variable nie gesetzt war. Darum: IMMER direkt nach `getenv()` normalisieren.

### Frontend-Filter gegen tote Links

Wenn ein Hub (z. B. `/sonographie/`) auf die sensitive Seite verlinkt, würde der Link bei `status=draft` auf 404 zeigen. Lösung: Der Hub filtert aus der Daten-SSoT die Drafts heraus:

```php
function pxz_hub_children() {
    $items = [ /* Array aller möglichen Kinder */ ];
    return array_values( array_filter( $items, function( $i ) {
        $page = get_page_by_path( 'parent/' . $i['slug'] );
        // Keep if: Page existiert nicht (Bootstrap) ODER ist publish
        return ! $page || $page->post_status === 'publish';
    } ) );
}
```

Ergebnis:
- Die Card erscheint **nicht**, solange die Seite Draft ist.
- Sobald der Client freischaltet (`UPDATE wp_posts SET post_status='publish' WHERE ID=X`), erscheint die Card automatisch, ohne Theme-Änderung.

---

## Alles zusammen — die Reihenfolge im Migrations-Script

```
1. Parent-Page umbenennen:          UPDATE 277 SET post_name='sonographie'
2. Kinder unter Parent einhängen:    UPDATE 357 SET post_name='schilddruese', post_parent=277
3. _wp_old_slug pflegen:             INSERT wp_postmeta '_wp_old_slug' = 'ultraschall-der-beingefaesse'
4. Sensitive Content als draft:       UPDATE 4206 SET post_status='draft', …
5. Rewrite-Rules flushen:             DELETE FROM wp_options WHERE option_name='rewrite_rules'
6. Warm-Up-Request:                   curl -sk $SITE/ (damit WP die Rules regeneriert)
```

Alle Schritte sind idempotent: Bei einem zweiten Lauf prüft das Script den Zustand und schreibt nur, wo sich etwas ändert.

---

## Verify-Checkliste

Nach der Migration mit curl prüfen:

```bash
SITE="https://example.local"

# 1. Neue URLs funktionieren
curl -sk -o /dev/null -w "%{http_code}" "$SITE/sonographie/schilddruese/"
# expect: 200

# 2. Alte URLs redirecten
curl -sk -o /dev/null -w "%{http_code} %{redirect_url}" "$SITE/schilddruesen-sonographie/"
# expect: 301 https://…/sonographie/schilddruese/

# 3. Draft-Page ist nicht öffentlich
curl -sk -o /dev/null -w "%{http_code}" "$SITE/sonographie/atlas/"
# expect: 404 (weil atlas status=draft)

# 4. Idempotenz
APPLY=1 php migrate.php   # zweiter Lauf
# expect: created=0 updated=0 drafted=0 skipped=N
```

---

## Was man mitnimmt

- **Nested Pages** sind in WP eingebaut, aber Rewrite-Rules müssen nach `post_parent`-Änderung geflusht werden (SQL-DELETE reicht).
- **`_wp_old_slug`** ist der richtige Mechanismus für 301-Redirects, aber der WP-Core-Handler für Pages ist unzuverlässig — ein 20-Zeilen-Theme-Fallback rettet das.
- **Draft-Gates** sind die saubere Lösung für rechtlich unsicheren Content — kombiniert mit einem Frontend-Filter entstehen keine toten Links.
- **`getenv()`-Fallen**: Normalisierung direkt nach dem Aufruf, niemals Strict-Comparison gegen `''` ohne vorher das `false` wegzumappen.

Zugehörige Patterns im Nexus:

- `Nexus/_memory/patterns/wp-nested-pages-rewrite-flush.md`
- `Nexus/_memory/patterns/wp-old-slug-redirect-reliability.md`
- `Nexus/_memory/patterns/dsgvo-draft-gate-pattern.md`
- `Nexus/_memory/patterns/php-getenv-normalization.md`
- `Nexus/_memory/patterns/nav-match-prefix-active-state.md` (Nav-Active-State bei Nested-URIs)
