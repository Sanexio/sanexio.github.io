# 28 — Detail-Pages von Shopify nach WordPress spiegeln

> **Kontext:** Du hast eine Shopify-Storefront (z. B. sanexio.eu) mit
> Produkt-Pages und willst die Inhalte (Bild + Beschreibung) auf eine
> WordPress-Site (z. B. westend-hausarzt.com) übertragen — als „Spiegel",
> aber mit Sie-Form, ohne Preise und mit Termin-CTA statt Warenkorb.
>
> **Erstmals durchgespielt:** S50 (2026-04-28), 23 von 25 Praxis-Detail-Pages.

---

## Glossar

- **Storefront-Passwort** — Ein Shopify-Feature, das die ganze Storefront
  mit einem Passwort sperrt (Coming-Soon-Modus). Ohne Auth-Cookie sieht
  jeder externe Crawler nur die „We'll be back shortly"-Seite.
- **og:image** — Open-Graph-Metadatum im HTML-Head; jede Shopify-Produkt-
  Page füllt das automatisch mit dem **Featured Image**.
- **Trunk** — Die zentrale Inhalts-Quelle in Cortex-Web (`trunk/content/...`)
  als YAML. Builder rendert daraus PHP-Dateien fürs WP-Theme.
- **Builder** — Skript `adapters/wordpress/build-page-hub.mjs`, das die
  YAMLs in PHP-Datenfiles wandelt.
- **Renderer** — `template-parts/page-hub-renderer.php`, rendert die
  PHP-Datenfiles als HTML.
- **HWG** — Heilmittelwerbegesetz; verbietet Heilversprechen, Vergleiche
  und Preise in der ärztlichen Praxis-Werbung.

---

## Schritt 1 — Storefront-Auth

```bash
curl -sL -c sanexio-cookies.txt -b sanexio-cookies.txt \
  -e "https://sanexio.eu/" \
  -X POST "https://sanexio.eu/password" \
  -d "form_type=storefront_password&utf8=%E2%9C%93&password=DEINPASSWORT" \
  -o /dev/null
```

Was passiert:
- `-c` schreibt das Cookie in die Datei
- `-b` schickt das Cookie auch wieder mit (bidirektional)
- `-e` setzt den Referer auf die Storefront-Hauptseite
- `-X POST` mit den Form-Daten meldet sich am Storefront-Schloss an

**Verifikation:** Folge-GET auf eine Produkt-Page muss > 100 KB Body
liefern und `og:image:secure_url` im HTML enthalten. Wenn nicht: Cookie
ist nicht gesetzt.

## Schritt 2 — Produkt-Pages batch-fetchen

```python
for praxis_slug, sanexio_slug in mapping.items():
    subprocess.run(['curl', '-sL', '-b', 'sanexio-cookies.txt',
                    '-o', f'{praxis_slug}.html',
                    f'https://sanexio.eu/products/{sanexio_slug}'])
```

## Schritt 3 — Hero-Bild + Description extrahieren

**Bild aus `og:image:secure_url`** (NIE das erste `<img>` — das ist das
Logo):

```python
img = re.search(
  r'<meta property="og:image:secure_url" content="(https?://[^"?]+\.(?:jpg|png))',
  html
)
hero_url = img.group(1) + '?width=1600'  # 1600px-Variante via Shopify-CDN
```

**Description aus `class="product__description rte"`:**

```python
start = h.find('class="product__description rte')
# walk back to enclosing <div>, walk forward depth-tracking until matching </div>
# strip <style>, <script>, class/style/id attributes, <div>-Tags
```

Übrig bleiben semantische HTML-Tags (`<p>`, `<h2>`, `<ul>`, `<li>`,
`<strong>`) — direkt verwendbar als `body_html`.

## Schritt 4 — Sie-Form + HWG-Filter (manuell pro Page)

Sanexio-Texte sind im **Du**-Stil mit Werbe-Sprache. Pro Page durch:

| Sanexio | Praxis |
|---|---|
| „Du" / „Dein" / „Dich" | „Sie" / „Ihr" / „sich" (Verb-Konjugation passt sich an) |
| „Wir bringen Dein Herz auf Hochtouren" | „Belastungs-EKG prüft die Belastungsfähigkeit Ihres Herzens" |
| „Befundbericht aus Deiner Gesundheitsakte" | „persönlicher Befundbericht" (Sanexio-Funktion entfällt) |
| „Bei Gefahr von Krebs entfernen wir die Knoten" | „Bei Verdacht auf bösartige Veränderungen wird das weitere Vorgehen besprochen" |
| Vergleiche („genauer als im Labor") | sachliche Beschreibung, kein Vergleich |
| „Plakette für Dein aktuelles Gesundheitslevel" | „strukturierte Bestandsaufnahme Ihres Gesundheitszustandes" |

## Schritt 5 — Bild ins WP-Upload-Verzeichnis kopieren

```bash
cp _media-source/shopify-mirror/detail/<slug>/hero.jpg \
   "/Users/.../wp-content/uploads/2026/04/sanexio-imports/<slug>-hero.jpg"
```

## Schritt 6 — Trunk-YAML aktualisieren

```yaml
sections:
  - type: hero
    eyebrow: { de: "..." }
    heading: { de: "..." }
    lead: { de: "Kurze Beschreibung in einem Satz." }
    image: shopify-mirror://detail/<slug>-hero.jpg

  - type: body
    body_html:
      de: |
        <p>Sie-Form-konvertierter HWG-bereinigter Text aus Sanexio.</p>
        <h2>Wie wird die Untersuchung durchgeführt?</h2>
        <p>...</p>

  - type: cta-banner
    heading: { de: "Termin für die ...?" }
    cta_label: { de: "Termin vereinbaren" }
    cta_url: /service/terminanfrage/    # später Doctolib-Direktlink
```

## Schritt 7 — Build + Verify

```bash
cd ~/Cortex/projects/Cortex-Web
bun adapters/wordpress/build-page-hub.mjs

# HTTP-Sweep
for url in /sonographie/ /sonographie/schilddruese/ ...; do
  curl -sk -o /dev/null -w "%{http_code} $url\n" \
    "https://gpmedicalcenter.../$url"
done
```

Erwartung: 200 für jede Page, `pxz-hub-product-hero` und
`pxz-hub-overview-card` im Body.

---

## Was du dadurch gelernt hast

1. Cookie-basiertes Scraping für Shopify-Storefronts mit Passwort
2. `og:image` als zuverlässige Quelle für Produkt-Bilder
3. Description-Block-Extraktion mit Depth-tracking-`<div>`-Walk
4. Sie-Form-Konversion + HWG-Filter als verbindlicher Praxis-Schritt
5. Trunk-YAML als zentrale Wahrheit, Theme nur als Renderer

---

## Verbundene Patterns

- `Nexus/_memory/patterns/storefront-auth-mirror.md` — Auth-Cookie + og:image
- `Nexus/_memory/patterns/auto-related-page-grid.md` — Übersichts-Block
- `Nexus/_memory/patterns/single-source-ui-region.md` (S38) — keine Doppel-Render-Quellen
- `Nexus/_memory/patterns/theme-rendering-source-check.md` (S42) — Theme-Render-Quelle vor DB-Aktion prüfen

---

## Spec-Referenz

`projects/Cortex-Web/sites/praxis-webseite/specs/sprint-2/S50_sanexio-detail-page-mirror.md`
