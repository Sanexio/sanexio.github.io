# Netzwerk & Sysadmin: Grundlagen

> **Hinweis:** Diese Lektion ist die Kurzübersicht. Für die ausführlichen,
> modular aufgebauten Tutorials mit Praxisübungen siehe die Module 02-08
> in diesem Ordner. Das vollständige Homelab-Handbuch mit deiner Infrastruktur
> findest du in `homelab-handbuch.md`.

## Was lernst du hier?

Netzwerke sind überall — zwischen deinem Mac, dem Drucker, dem Homelab, dem iPhone, der Cloud. Diese Lektion erklärt, wie Daten von A nach B kommen:

- IP-Adressen (wie Postleitzahlen für Computer)
- DNS (wie die Adressbuch-App für Websites)
- Ports (wie Fenster auf einem Haus — jedes macht etwas anderes)
- SSH (sichere Verbindung zu anderen Computern)
- Grundlegende Netzwerk-Diagnostik

**Für dich relevant:**
- Dein Homelab (Proxmox, VMs) sind übers Netzwerk verbunden
- Juvantis braucht Internet für HealthKit-Sync und Cloud-Daten
- Gelegentliche Netzwerk-Fehler solltest du selbst diagnostizieren können

---

## IP-Adressen: Die Postleitzahl deines Computers

Jedes Gerät im Netzwerk hat eine IP-Adresse — das ist wie seine Postleitzahl + Hausnummer.

### IPv4 (die Standard-Version)

Format: `XXX.XXX.XXX.XXX` (vier Zahlen, je 0-255)

**Beispiele:**
- `192.168.1.1` = dein Netzwerk-Router
- `192.168.1.5` = dein Mac
- `192.168.1.20` = dein Homelab-Server
- `8.8.8.8` = Google's öffentlicher DNS (im Internet)
- `127.0.0.1` = "Localhost" (dein Computer selbst)

**Lokale vs. öffentliche Adressen:**
- `192.168.x.x` = Lokal (nur dein Heimnetzwerk)
- `10.0.0.x` = Lokal (alternative Range)
- `172.16.x.x - 172.31.x.x` = Lokal (private range)
- Alles andere = Öffentlich (im Internet erreichbar)

---

### IPv6 (der neue Standard)

Format: `xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx` (Hexadezimal, mit Kürzungen)

**Beispiel:**
- `2001:0db8:85a3:0000:0000:8a2e:0370:7334` (lang)
- `2001:db8:85a3::8a2e:370:7334` (gekürzt)

IPv6 hat *viel* mehr Adressen. Wichtig für die Zukunft, aber IPv4 ist immer noch Standard.

---

## Subnets: Wie teilt man ein Netzwerk auf?

Ein Subnet ist ein Teil eines Netzwerks.

**Beispiel Heimnetzwerk:**
```
Router: 192.168.1.1
Dein Mac: 192.168.1.5
Homelab: 192.168.1.20
Drucker: 192.168.1.50
```

Alle haben `192.168.1.x` — sie sind im gleichen Subnet.

**Subnet-Maske:**
Die "Maske" sagt: "Diese Teile sind gleich, der Rest ist unterschiedlich."

- `255.255.255.0` = alle `192.168.1.x` sind im gleichen Netz
- `255.255.0.0` = alle `192.168.x.x` sind im gleichen Netz

**Oder in CIDR-Notation:**
- `192.168.1.0/24` = "24 Bits sind gleich, 8 sind unterschiedlich"
- `192.168.0.0/16` = "16 Bits sind gleich, 16 sind unterschiedlich"

---

## DHCP: Automatische IP-Vergabe

Statt jedem Gerät eine IP manuell zuzuweisen, gibt der Router (DHCP-Server) automatisch IPs aus.

**Wie das funktioniert:**
```
1. Dein Mac bootet auf
2. Dein Mac sagt zum Router: "Gib mir eine IP!"
3. Router sagt: "OK, nimm 192.168.1.5"
4. Dein Mac bekommt auch: Netzwerk-Maske, Gateway, DNS
5. Dein Mac hat Internet!
```

**DHCP-Lease:** Die IP ist "gemietet" für eine Weile (z.B. 24 Stunden). Dann muss sie erneuert werden.

---

## NAT: Wie dein Heimnetzwerk ins Internet kommt

NAT = Network Address Translation. Es "übersetzt" zwischen deinem lokalen Netzwerk und dem Internet.

```
┌─────────────────────────────────┐
│ Dein Heimnetzwerk (lokal)       │
│ 192.168.1.0/24                  │
│ ├─ Mac: 192.168.1.5             │
│ ├─ Homelab: 192.168.1.20        │
│ └─ iPhone: 192.168.1.30 (WiFi)  │
└────────────┬────────────────────┘
             │ NAT
             ↓
┌─────────────────────────────────┐
│ Internet (öffentlich)            │
│ Alles scheint von einer IP      │
│ z.B. 203.0.113.42 zu kommen     │
└─────────────────────────────────┘
```

**Was das bedeutet:**
- Dein Router übernimmt die "Kommunikation nach draußen"
- Von außen sehen alle Geräte wie ein Gerät aus
- Das macht dein Netzwerk sicherer (versteckt interne IPs)

---

## DNS: Das "Telefonbuch" des Internets

DNS übersetzt Namen in IP-Adressen.

```
Du gibst ein:          DNS antwortet:
google.com       →     142.251.41.206
github.com       →     140.82.113.3
sanexio.de       →     93.110.236.123
```

**Ohne DNS müsstest du Nummern wie 142.251.41.206 merken!**

### DNS-Lookup: Wie funktioniert das?

```
Dein Browser
    ↓ "Was ist google.com?"
Dein Router (DNS-Forwarder)
    ↓ "Ich frag bei Google nach"
8.8.8.8 (Google's DNS)
    ↓ "Das ist 142.251.41.206"
Zurück zu dir
    ↓
Dein Browser verbindet sich zu 142.251.41.206
```

### DNS testen: `dig` oder `nslookup`

```bash
nslookup google.com
```

```
Non-authoritative answer:
Name:   google.com
Address: 142.251.41.206
```

---

## Ports: Welche "Tür" des Computers?

Ein Computer hat 65536 Ports (Nummern 0-65535). Jeder Service hört auf einem bestimmten Port:

| Port | Service | Beispiel |
|------|---------|----------|
| 80 | HTTP (Web) | `http://example.com:80` |
| 443 | HTTPS (sicheres Web) | `https://example.com:443` |
| 22 | SSH (Fernzugriff) | `ssh user@example.com` |
| 3306 | MySQL (Datenbank) | `mysql://localhost:3306` |
| 5432 | PostgreSQL (Datenbank) | `psql://localhost:5432` |
| 3000 | Entwicklungs-Server | `npm run dev` (Port 3000) |
| 8080 | Alternative HTTP | `localhost:8080` |

**Wichtig:**
- Ports 0-1023 sind "privilegiert" (nur Admin darf sie nutzen)
- Ports 1024+ sind "unprivilegiert" (jeder darf sie nutzen)
- Ein Server kann auf mehreren Ports gleichzeitig lauschen

### Port testen: `telnet` oder `netstat`

```bash
telnet localhost 3000
```

Versucht, sich zu Port 3000 zu verbinden. Wenn erfolgreich, läuft dort ein Server.

```bash
netstat -an | grep LISTEN
```

Zeigt alle offenen Ports auf deinem Computer:

```
tcp4       0      0 127.0.0.1.3000         *.*                    LISTEN
tcp4       0      0 127.0.0.1.5432         *.*                    LISTEN
```

---

## Firewalls: Die Türklingel deines Netzwerks

Eine Firewall blockiert unerwünschte Verbindungen:

```
┌──────────────┐
│ Außen        │ ← Hacker, Spam-Bots
└──────┬───────┘
       │ Firewall (blockiert!)
       ↓
┌──────────────┐
│ Dein Netzwerk│
└──────────────┘
```

**Auf macOS:**
System Preferences → Security & Privacy → Firewall

**Auf dem Router:**
Jeder Router hat eine eingebaute Firewall.

---

## SSH: Sicher auf andere Computer zugreifen

SSH ist wie eine Fernbedienung für einen anderen Computer — sicher verschlüsselt.

### SSH-Verbindung

```bash
ssh user@192.168.1.20
```

Das verbindet dich zum Homelab-Server als Benutzer `user`:

```
user@homelab:~$
```

Du bist jetzt auf dem entfernten Computer!

**Mit Port (falls nicht Standard 22):**
```bash
ssh -p 2222 user@192.168.1.20
```

---

### SSH-Schlüssel: Sicherer als Passwort

Statt Passwort einzutippen, nutzt du ein Schlüsselpaar:

**Schlüssel generieren:**
```bash
ssh-keygen -t rsa -b 4096
```

Das erstellt:
- `~/.ssh/id_rsa` (privater Schlüssel — GEHEIM!)
- `~/.ssh/id_rsa.pub` (öffentlicher Schlüssel — in die Welt)

**Öffentlichen Schlüssel auf den Server kopieren:**
```bash
ssh-copy-id -i ~/.ssh/id_rsa.pub user@192.168.1.20
```

oder manuell:
```bash
cat ~/.ssh/id_rsa.pub
```

Kopiere das, dann auf dem Server:
```bash
echo "PASTE_PUBLIC_KEY_HERE" >> ~/.ssh/authorized_keys
```

**Jetzt kannst du dich ohne Passwort anmelden:**
```bash
ssh user@192.168.1.20
```

---

### SSH Config: Aliases für häufige Verbindungen

Erstelle `~/.ssh/config`:

```
Host homelab
    HostName 192.168.1.20
    User admin
    Port 22
    IdentityFile ~/.ssh/id_rsa

Host grafana
    HostName 192.168.1.30
    User root
    Port 2222
```

Jetzt kannst du einfach schreiben:
```bash
ssh homelab
```

Statt:
```bash
ssh -p 22 admin@192.168.1.20
```

---

## Netzwerk-Diagnostik: Wenn etwas nicht funktioniert

### `ping`: Ist der Server erreichbar?

```bash
ping 8.8.8.8
```

Sendet "Hallo"-Pakete an Google's DNS:

```
PING 8.8.8.8 (8.8.8.8): 56 data bytes
64 bytes from 8.8.8.8: icmp_seq=0 ttl=119 time=25.3ms
64 bytes from 8.8.8.8: icmp_seq=1 ttl=119 time=22.1ms
```

**Wenn du keine Antwort bekommst:**
- Internet ist weg
- Firewall blockiert ICMP
- Server ist aus
- DNS funktioniert nicht

---

### `traceroute`: Der Weg zu einem Server

```bash
traceroute google.com
```

Zeigt, durch welche Computer (Hops) das Signal zu Google geht:

```
traceroute to google.com (142.251.41.206), 64 hops max
 1  192.168.1.1 (dein Router)     1.234 ms
 2  10.x.x.x (ISP Gateway)        5.123 ms
 3  core-router.isp.de            12.456 ms
 4  142.251.41.206 (Google)       25.123 ms
```

Wenn es stecken bleibt, ist einer der Hops offline oder blockiert.

---

### `nslookup` oder `dig`: DNS testen

```bash
nslookup google.com
```

Zeigt die IP-Adresse von google.com. Wenn das nicht geht, ist DNS kaputt.

---

### `ifconfig` oder `ip`: Deine Netzwerk-Konfiguration

```bash
ifconfig
```

Zeigt alle Netzwerk-Interfaces:

```
en0: flags=... inet 192.168.1.5 netmask 0xffffff00 ...
en1: flags=... inet 192.168.0.50 netmask 0xffffff00 ...
lo0: flags=... inet 127.0.0.1 netmask 0xff000000 ...
```

- `en0` = Ethernet oder WiFi (mit IP `192.168.1.5`)
- `lo0` = Localhost (`127.0.0.1`)

---

## Zusammenfassung: Netzwerk-Checkliste bei Problemen

```
Ist das Internet weg?
  → Ping 8.8.8.8
     → Ja: Router neu starten oder ISP kontaktieren
     → Nein: DNS-Problem?

Kann ich einen spezifischen Server nicht erreichen?
  → Ping 192.168.1.20
     → Ja: Server läuft, aber Port zu?
     → Nein: Firewall blockiert? Server aus?

Welche Port sind offen?
  → netstat -an | grep LISTEN

Wie verbinde ich mich zum Homelab?
  → ssh homelab (mit ~/.ssh/config)
     oder: ssh admin@192.168.1.20

DNS funktioniert nicht?
  → nslookup google.com
     → Fehler: Änder DNS (z.B. auf 8.8.8.8)
```

---

## Nächste Schritte

1. **Erkunde dein Netzwerk:**
   ```bash
   ifconfig                    # Deine IP
   ping 192.168.1.1           # Router
   ping 8.8.8.8               # Google
   ```

2. **Richter SSH ein:**
   ```bash
   ssh-keygen -t rsa -b 4096
   ssh-copy-id user@homelab
   ```

3. **Erstelle ~/.ssh/config** für deine Hosts

4. **Lerne dein Homelab kennen:**
   ```bash
   ssh homelab
   ifconfig                    # Von dort aus
   ```

5. **Tiefer gehen:** `man ssh`, `man ssh-config`, `man nslookup`

---

## Vertiefte Module (ausführlich, mit Praxisübungen)

Diese Module stammen aus dem Homelab-Projekt und gehen viel tiefer:

| Datei | Thema | Dauer |
|-------|-------|-------|
| `02-was-ist-ein-netzwerk.md` | Was ist ein Netzwerk? (Grundbegriffe) | 15 Min |
| `03-ip-adressen.md` | IP-Adressen verstehen (IPv4, Subnets) | 20 Min |
| `04-router-switch-gateway.md` | Router, Switch und Gateway | 25 Min |
| `05-dhcp.md` | DHCP — Automatische IP-Vergabe | 20 Min |
| `06-dns.md` | DNS — Namensauflösung | 20 Min |
| `07-netzwerkscan.md` | Netzwerkscan durchführen (nmap) | 30 Min |
| `08-cgnat.md` | CGNAT verstehen (Carrier-Grade NAT) | 15 Min |

## Referenz-Dokumente

| Datei | Inhalt |
|-------|--------|
| `homelab-handbuch.md` | Vollständiges Admin-Handbuch mit Hardware-Inventar und Topologie |
| `01_netzwerk_analyse.sh` | Netzwerk-Analyse-Skript (Bash) |

---

**Tipp:** Die besten Netzwerk-Fehler passieren morgens. Wenn Internet weg ist, bleib ruhig und geh die Checkliste durch. 90% der Zeit ist der Router aus.
