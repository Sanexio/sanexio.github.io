# Modul 07: CGNAT verstehen

**Dauer**: 15 Minuten  
**Schwierigkeit**: ⭐⭐ Mittel  
**Voraussetzungen**: Modul 02, Modul 03  
**Version**: 0.3

---

## 📚 Theorie

### Was ist CGNAT?

**CGNAT** steht für **Carrier-Grade NAT** (Carrier-Grade Network Address Translation).

**Einfach erklärt**: CGNAT ist wie ein **großes Postamt**, das alle Briefe sammelt und weiterleitet. Dein Internetanbieter (Vodafone) verwendet CGNAT, um mehrere Kunden über eine einzige öffentliche IP-Adresse zu verbinden.

**Problem**: Du bekommst **keine eigene öffentliche IPv4-Adresse** mehr direkt zugewiesen.

### Warum gibt es CGNAT?

**Hintergrund**: IPv4-Adressen gehen zur Neige!

- Es gibt nur etwa 4,3 Milliarden IPv4-Adressen weltweit
- Es gibt aber viel mehr Geräte, die ins Internet wollen
- Lösung: Mehrere Kunden teilen sich eine öffentliche IP-Adresse

**CGNAT**: Internetanbieter verwenden NAT auf ihrer Seite, um mehrere Kunden über eine IP zu verbinden.

### Was bedeutet das für dich?

**Ohne CGNAT** (normale Situation):
- Du bekommst eine öffentliche IPv4-Adresse
- Portfreigaben funktionieren direkt
- Du kannst von außen auf dein Netzwerk zugreifen

**Mit CGNAT** (deine Situation):
- ⚠️ Keine öffentliche IPv4-Adresse direkt zugewiesen
- ⚠️ IPv4-Portfreigaben funktionieren **nicht** von außen
- ✅ IPv6 ist verfügbar (moderne Lösung)
- ✅ MyFRITZ! DynDNS funktioniert (Workaround)

### Warum ist das ein Problem?

**Portfreigaben**: Wenn du von außen auf einen Server in deinem Netzwerk zugreifen möchtest, musst du eine Portfreigabe einrichten. Mit CGNAT funktioniert das nicht direkt über IPv4.

**Beispiel**: Du möchtest von unterwegs auf Cluster-Mini-01 zugreifen.
- **Ohne CGNAT**: Portfreigabe funktioniert, du kannst direkt zugreifen
- **Mit CGNAT**: Portfreigabe funktioniert nicht, du brauchst eine Alternative

### Erweiterte NAT- und CGNAT-Konzepte

**NAT (Network Address Translation)**: Übersetzt private IP-Adressen in öffentliche IP-Adressen. Ermöglicht mehreren Geräten, eine öffentliche IP zu teilen.

**NAT-Types**:
- **Static NAT (1:1 NAT)**: Feste Zuordnung einer privaten zu einer öffentlichen IP
- **Dynamic NAT**: Dynamische Zuordnung aus einem Pool öffentlicher IPs
- **PAT (Port Address Translation) / NAPT**: Mehrere private IPs teilen sich eine öffentliche IP über verschiedene Ports
- **CGNAT (Carrier-Grade NAT)**: NAT auf ISP-Ebene - mehrere Kunden teilen sich eine öffentliche IP

**NAT-Table**: Tabelle im Router, die aktive NAT-Verbindungen speichert. Enthält Mapping zwischen privater IP:Port und öffentlicher IP:Port.

**NAT-Session**: Eine aktive Verbindung durch NAT. Wird automatisch entfernt, wenn die Verbindung beendet wird.

**NAT-Timeouts**: Zeit, nach der inaktive NAT-Sessions entfernt werden. Variiert je nach Protokoll (TCP, UDP, ICMP).

**Hairpinning / NAT-Loopback**: Zugriff auf einen internen Service über die öffentliche IP von innerhalb des Netzwerks. Nicht alle Router unterstützen dies.

**Port-Forwarding / Port-Mapping**: Weiterleitung eines bestimmten Ports von der öffentlichen IP zu einer privaten IP. Beispiel: Port 8080 → 192.168.178.29:8080.

**DMZ (Demilitarized Zone)**: Ein Gerät, das direkt dem Internet ausgesetzt ist (alle Ports weitergeleitet). Weniger sicher, aber einfacher.

**UPnP (Universal Plug and Play)**: Automatisches Port-Forwarding durch Anwendungen. Sicherheitsrisiko, da Anwendungen Ports öffnen können.

**IPv4-Adress-Erschöpfung**: Das Problem, dass IPv4-Adressen zur Neige gehen. Nur etwa 4,3 Milliarden IPv4-Adressen verfügbar.

**IPv6**: Lösung für IPv4-Erschöpfung. 128-Bit-Adressen ermöglichen 3.4×10^38 Adressen. Keine NAT erforderlich.

**Dual-Stack**: Unterstützung von IPv4 und IPv6 gleichzeitig. Deine FRITZ!Box unterstützt Dual-Stack.

**IPv6-Adress-Typen**:
- **Global Unicast**: Öffentliche IPv6-Adresse (ähnlich öffentlicher IPv4)
- **Link-Local**: Lokale Adresse für direkte Verbindungen (fe80::/10)
- **Unique Local**: Private IPv6-Adresse (fc00::/7)
- **Multicast**: Gruppen-Adressen (ff00::/8)

**IPv6-Stateless Address Autoconfiguration (SLAAC)**: Automatische IPv6-Adressvergabe ohne DHCP. Verwendet Router Advertisements (RA).

**Router Advertisement (RA)**: IPv6-Nachricht vom Router, die Netzwerk-Informationen bereitstellt (Präfix, Gateway, DNS).

**DynDNS (Dynamic DNS)**: Automatische Aktualisierung eines DNS-Namens, wenn sich die IP-Adresse ändert. MyFRITZ! verwendet DynDNS.

**DynDNS-Provider**: Services wie No-IP, DuckDNS, oder MyFRITZ!, die DynDNS bereitstellen.

**DDNS-Update-Protokoll**: Protokoll für DNS-Updates (z.B. RFC 2136 für DNS Updates über DNS, oder HTTP-basierte APIs).

**Teredo**: IPv6-Tunneling über IPv4-NAT. Ermöglicht IPv6-Verbindungen auch hinter NAT.

**6to4**: Automatisches IPv6-Tunneling über IPv4. Verwendet öffentliche IPv4-Adresse.

**ISATAP (Intra-Site Automatic Tunnel Addressing Protocol)**: IPv6-Tunneling innerhalb eines IPv4-Netzwerks.

**NAT64**: Übersetzung von IPv6 zu IPv4. Ermöglicht IPv6-only-Geräten, IPv4-Services zu erreichen.

**DNS64**: Erstellt IPv6-Adressen für IPv4-only-Services. Arbeitet mit NAT64 zusammen.

**CGNAT-Architektur**: 
- **LSN (Large Scale NAT)**: NAT auf ISP-Ebene
- **CGNAT-Geräte**: Spezialisierte Router für Carrier-Grade NAT
- **Port-Blocks**: Zuweisung von Port-Bereichen an Kunden

**Port-Block-Size**: Anzahl von Ports, die einem CGNAT-Kunden zugewiesen werden. Typisch: 256-4096 Ports.

**CGNAT-Logging**: ISP muss NAT-Logs führen für rechtliche Compliance. Erfordert große Datenbanken.

**CGNAT-Performance**: Kann Performance-Probleme verursachen durch:
- Port-Exhaustion (alle Ports belegt)
- NAT-Table-Überlauf
- Zusätzliche Latenz

**IPv6-Transition-Mechanismen**: Technologien für Übergang von IPv4 zu IPv6:
- Dual-Stack
- Tunneling (6to4, Teredo, ISATAP)
- Translation (NAT64, DNS64)

**IPv6-Privacy-Extensions**: Zufällige IPv6-Adressen für bessere Privatsphäre. Ändern sich regelmäßig.

**IPv6-Stateless-DHCP**: DHCPv6 ohne Adressvergabe (nur Konfiguration wie DNS).

**Stateful-DHCPv6**: DHCPv6 mit Adressvergabe (ähnlich DHCPv4).

---

## 🎯 Ziel dieses Moduls

Nach diesem Modul verstehst du:
- ✅ Was CGNAT ist und warum es existiert
- ✅ Warum CGNAT ein Problem für Portfreigaben ist
- ✅ Verfügbare Lösungen kennen (IPv6, MyFRITZ!, VPN)
- ✅ CGNAT-Problem erkennen können
- ✅ NAT-Types verstehen (Static, Dynamic, PAT, CGNAT)
- ✅ NAT-Table, NAT-Sessions, NAT-Timeouts kennen
- ✅ Port-Forwarding, DMZ, UPnP verstehen
- ✅ IPv6-Adress-Typen und SLAAC kennen
- ✅ IPv6-Transition-Mechanismen verstehen (Dual-Stack, Tunneling, Translation)
- ✅ DynDNS, Router Advertisements, NAT64/DNS64 kennen

---

## 📋 Schritt-für-Schritt

### Schritt 1: CGNAT-Problem erkennen

**Was machen wir?**  
Wir prüfen, ob CGNAT aktiv ist.

**FRITZ!Box Oberfläche**:

1. Öffne die FRITZ!Box Oberfläche: `http://192.168.178.1`

2. Gehe zu **"Internet"** → **"Freigaben"** → **"FRITZ!Box-Dienste"**

**Erwartetes Ergebnis**:  
Du siehst eine Warnmeldung:
```
⚠️ Die vom Internetanbieter zugewiesene IPv4-Adresse ist keine 
öffentlich erreichbare IP-Adresse. Freigaben auf IPv4-Dienste der 
FRITZ!Box und auf Ihr IPv4-Heimnetz werden daher voraussichtlich 
nicht funktionieren.
```

**Das bedeutet**:
- ✅ CGNAT ist aktiv
- ⚠️ IPv4-Portfreigaben funktionieren nicht
- ✅ Du brauchst eine Alternative

---

### Schritt 2: IPv6-Verfügbarkeit prüfen

**Was machen wir?**  
Wir prüfen, ob IPv6 verfügbar ist (Lösung für CGNAT).

**FRITZ!Box Oberfläche**:

1. Gehe zu **"Internet"** → **"Zugangsdaten"** → **"IPv6"**

2. Prüfe IPv6-Konfiguration

**Erwartetes Ergebnis**:  
Du siehst:
- ✅ IPv6 ist aktiviert
- **IPv6-Adresse**: `2a00:1f:3204:0000::1`

**Das bedeutet**:
- ✅ IPv6 ist verfügbar!
- ✅ Du kannst IPv6 für externen Zugriff verwenden
- ✅ Keine CGNAT-Probleme mit IPv6

**IPv6-Format**:  
IPv6-Adressen sehen anders aus als IPv4:
- IPv4: `192.168.178.1` (4 Zahlen)
- IPv6: `2a00:1f:3204:0000::1` (Hexadezimal, Doppelpunkt-getrennt)

---

### Schritt 3: MyFRITZ! DynDNS prüfen

**Was machen wir?**  
Wir prüfen, ob MyFRITZ! DynDNS aktiviert ist (Alternative Lösung).

**FRITZ!Box Oberfläche**:

1. Gehe zu **"Internet"** → **"Freigaben"** → **"FRITZ!Box-Dienste"**

2. Prüfe **"Internetzugriff auf die FRITZ!Box über HTTPS aktiv"**

**Erwartetes Ergebnis**:  
Du siehst:
- ✅ Internetzugriff aktiviert
- **TCP-Port für HTTPS**: `47924`
- **Internet-Adressen**:
  - `https://475cdg2rogmn8yah.myfritz.net:47924`
  - `https://[2a00:1f:3204:0000::1]:47924`
  - `https://192.0.0.2:47924`

**Das bedeutet**:
- ✅ MyFRITZ! DynDNS ist aktiviert
- ✅ Du kannst über `myfritz.net` auf deine FRITZ!Box zugreifen
- ✅ IPv6-Zugriff ist auch möglich

---

### Schritt 4: Lösungen verstehen

**Was machen wir?**  
Wir verstehen die verfügbaren Lösungen für das CGNAT-Problem.

**Lösung 1: IPv6** ✅ (Empfohlen)

**Vorteile**:
- ✅ Direkter Zugriff ohne NAT-Probleme
- ✅ Moderne Lösung
- ✅ Keine zusätzlichen Kosten
- ✅ Bereits verfügbar

**Nachteile**:
- ⚠️ Client muss IPv6 unterstützen
- ⚠️ Nicht alle Netzwerke haben IPv6

**Verwendung**: Portfreigaben über IPv6 konfigurieren

---

**Lösung 2: MyFRITZ! DynDNS** ✅ (Aktiv)

**Vorteile**:
- ✅ Bereits aktiviert
- ✅ Funktioniert auch mit CGNAT
- ✅ Einfach zu verwenden

**Nachteile**:
- ⚠️ Nur für FRITZ!Box-Zugriff
- ⚠️ Nicht für direkten Server-Zugriff

**Verwendung**: Zugriff auf FRITZ!Box von außen

---

**Lösung 3: VPN** ⚪ (Geplant für Phase 8)

**Vorteile**:
- ✅ Sicherer Zugriff
- ✅ Funktioniert mit CGNAT
- ✅ Zugriff auf alle Geräte im Netzwerk

**Nachteile**:
- ⚠️ Muss erst eingerichtet werden
- ⚠️ Etwas komplexer

**Verwendung**: Sichere Verbindung ins Netzwerk von außen

---

**Lösung 4: Öffentliches IPv4-Subnetz** ⚪ (Möglich)

**Vorgehen**: Beim ISP (Vodafone) anfragen

**Vorteile**:
- ✅ Direkte IPv4-Portfreigaben möglich
- ✅ Kompatibel mit allen Geräten

**Nachteile**:
- ⚠️ Möglicherweise kostenpflichtig
- ⚠️ Nicht immer verfügbar

---

### Schritt 5: CGNAT-Problem zusammenfassen

**Was machen wir?**  
Wir fassen das CGNAT-Problem und die Lösungen zusammen.

**Das Problem**:
- ⚠️ Keine öffentliche IPv4-Adresse direkt zugewiesen
- ⚠️ IPv4-Portfreigaben funktionieren nicht von außen
- ⚠️ Direkter Zugriff auf Server über IPv4 nicht möglich

**Die Lösungen**:
1. ✅ **IPv6**: Direkter Zugriff über IPv6 (bereits verfügbar)
2. ✅ **MyFRITZ!**: Zugriff auf FRITZ!Box (bereits aktiviert)
3. ⚪ **VPN**: Sichere Verbindung (geplant für Phase 8)
4. ⚪ **Öffentliches IPv4-Subnetz**: Beim ISP anfragen

**Empfehlung**: Verwende IPv6 für externen Zugriff (modernste Lösung)

---

## 💻 Befehle

### IPv6-Adresse anzeigen

```bash
# macOS
ifconfig | grep "inet6 " | grep -v "::1"

# Linux
ip -6 addr show
```

### IPv6-Verbindung testen

```bash
# IPv6-Verbindung testen
ping6 2a00:1f:3204:0000::1

# Oder
ping6 -c 4 2a00:1f:3204:0000::1
```

### Öffentliche IP-Adresse prüfen

```bash
# Öffentliche IPv4-Adresse (zeigt CGNAT-Adresse)
curl ifconfig.me

# Oder
curl ipv4.icanhazip.com
```

---

## ✅ Erwartetes Ergebnis

Nach diesem Modul solltest du:

1. ✅ Verstehen, was CGNAT ist und warum es existiert
2. ✅ Das CGNAT-Problem erkennen können
3. ✅ Verfügbare Lösungen kennen (IPv6, MyFRITZ!, VPN)
4. ✅ IPv6-Verfügbarkeit prüfen können
5. ✅ MyFRITZ! DynDNS verstehen

---

## ⚠️ Mögliche Fehlerquellen

### Problem: Ich verstehe CGNAT nicht

**Lösung**:
- Denke an ein Postamt: Mehrere Häuser teilen sich eine Postleitzahl
- CGNAT ist ähnlich: Mehrere Kunden teilen sich eine öffentliche IP
- Das Problem: Von außen weiß niemand, welches "Haus" (Netzwerk) gemeint ist

### Problem: Portfreigaben funktionieren nicht

**Lösung**:
- Das ist normal mit CGNAT!
- Verwende IPv6 statt IPv4
- Oder verwende VPN (später)
- Oder frage beim ISP nach öffentlichem IPv4-Subnetz

### Problem: IPv6 funktioniert nicht

**Lösung**:
- Prüfe IPv6-Konfiguration in FRITZ!Box
- Prüfe, ob dein Client IPv6 unterstützt
- Prüfe Internetverbindung
- Verwende MyFRITZ! als Alternative

---

## 📝 Zusammenfassung

**Was hast du gelernt?**

1. **CGNAT**: Carrier-Grade NAT - mehrere Kunden teilen sich eine öffentliche IP
2. **Problem**: Keine direkte öffentliche IPv4-Adresse → Portfreigaben funktionieren nicht
3. **Lösungen**: IPv6, MyFRITZ!, VPN, öffentliches IPv4-Subnetz
4. **IPv6**: Moderne Lösung, bereits verfügbar
5. **MyFRITZ!**: Workaround für FRITZ!Box-Zugriff

**Wichtige Begriffe**:
- **CGNAT**: Carrier-Grade NAT - NAT auf ISP-Ebene
- **NAT**: Network Address Translation - Übersetzung privater in öffentliche IPs
- **Static NAT**: Feste 1:1 IP-Zuordnung
- **Dynamic NAT**: Dynamische IP-Zuordnung aus Pool
- **PAT/NAPT**: Port Address Translation - mehrere IPs über Ports
- **NAT-Table**: Tabelle mit aktiven NAT-Verbindungen
- **NAT-Session**: Aktive Verbindung durch NAT
- **NAT-Timeouts**: Zeit für Entfernung inaktiver Sessions
- **Hairpinning/NAT-Loopback**: Interner Zugriff über öffentliche IP
- **Port-Forwarding**: Weiterleitung eines Ports zu privater IP
- **Port-Mapping**: Synonym für Port-Forwarding
- **DMZ**: Demilitarized Zone - Gerät mit allen Ports weitergeleitet
- **UPnP**: Universal Plug and Play - automatisches Port-Forwarding
- **IPv4-Adress-Erschöpfung**: Problem der begrenzten IPv4-Adressen
- **IPv6**: Internet Protocol Version 6 - Lösung für Adress-Erschöpfung
- **Dual-Stack**: Unterstützung von IPv4 und IPv6 gleichzeitig
- **Global Unicast**: Öffentliche IPv6-Adresse
- **Link-Local**: Lokale IPv6-Adresse (fe80::/10)
- **Unique Local**: Private IPv6-Adresse (fc00::/7)
- **SLAAC**: Stateless Address Autoconfiguration - automatische IPv6-Adressvergabe
- **Router Advertisement (RA)**: IPv6-Nachricht mit Netzwerk-Informationen
- **DynDNS**: Dynamic DNS - automatische IP-Updates
- **DynDNS-Provider**: Services für DynDNS (No-IP, DuckDNS, MyFRITZ!)
- **DDNS-Update-Protokoll**: Protokoll für DNS-Updates
- **Teredo**: IPv6-Tunneling über IPv4-NAT
- **6to4**: Automatisches IPv6-Tunneling über IPv4
- **ISATAP**: IPv6-Tunneling innerhalb IPv4-Netzwerk
- **NAT64**: Übersetzung von IPv6 zu IPv4
- **DNS64**: Erstellt IPv6-Adressen für IPv4-Services
- **LSN**: Large Scale NAT - NAT auf ISP-Ebene
- **Port-Block-Size**: Anzahl Ports pro CGNAT-Kunde
- **CGNAT-Logging**: NAT-Logs für Compliance
- **IPv6-Privacy-Extensions**: Zufällige IPv6-Adressen für Privatsphäre
- **Stateless-DHCPv6**: DHCPv6 ohne Adressvergabe
- **Stateful-DHCPv6**: DHCPv6 mit Adressvergabe
- **Portfreigabe**: Öffnet einen Port für externen Zugriff

**Deine Situation**:
- ⚠️ **CGNAT aktiv**: Keine direkte öffentliche IPv4-Adresse
- ✅ **IPv6 verfügbar**: `2a00:1f:3204:0000::1`
- ✅ **MyFRITZ! aktiv**: `475cdg2rogmn8yah.myfritz.net:47924`
- ⚪ **VPN geplant**: Phase 8

---

## 🔗 Verweise

**Handbuch-Kapitel**:
- Kapitel 2.2: Router (CGNAT-Hinweis)
- Kapitel 5.4: NAT und Port Forwarding
- Kapitel 6: Netzwerkzugriff von außen

**Nächstes Modul**:  
➡️ Phase 2 beginnt mit Modul 08 (Hardware inventarisieren)

---

## 🎓 Selbstprüfung

Beantworte diese Fragen für dich selbst:

- [ ] Kann ich erklären, was CGNAT ist?
- [ ] Verstehe ich, warum CGNAT ein Problem ist?
- [ ] Weiß ich, welche Lösungen verfügbar sind?
- [ ] Kann ich IPv6-Verfügbarkeit prüfen?
- [ ] Verstehe ich MyFRITZ! DynDNS?

**Wenn du alle Fragen mit "Ja" beantworten kannst, hast du Phase 1 abgeschlossen!** 🎉

**Herzlichen Glückwunsch! Du hast die Netzwerk-Grundlagen gemeistert!** 🚀

---

**Ende Modul 07 - Ende Phase 1**
