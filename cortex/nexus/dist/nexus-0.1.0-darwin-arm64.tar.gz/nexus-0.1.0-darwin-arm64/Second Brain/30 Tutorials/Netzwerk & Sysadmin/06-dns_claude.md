# DNS — Claude-Workflow

**Einsatzbereich:** Automatische DNS-Tests, Hostname-Mapping, Resolver-Diagnose

**Wann ist dieser Workflow sinnvoll?**
- Du möchtest regelmäßig testen, ob DNS funktioniert
- Du brauchst ein Skript, das Auflösungen aller Hostnamen testet
- Du möchtest DNS-Fehler automatisch erkennen
- Du möchtest Audit-Logs von DNS-Anfragen erstellen
- Du brauchst DNS-Caching-Statistiken

---

## Szenario

Dr. Stracke merkt manchmal, dass der Browser langsam lädt. Er möchte wissen, ob DNS-Auflösung funktioniert und wie lange sie dauert. Claude erstellt automatische Tests, um DNS-Performance zu messen.

---

## Workflow-Schritte

### 1. DNS-Auflösungs-Test-Skript (Python/Bash)

Claude erstellt ein Skript, das:
- Alle Cluster Node Hostnamen auflöst
- Internet-Domains testet (google.com, github.com)
- Auflösungszeit misst
- Fehler erkennt und meldet

**Aufruf:**
```bash
python3 scripts/dns_test.py --all
```

**Ergebnis:**
```
DNS-Auflösungs-Tests (2026-04-03 10:30 UTC)
===========================================

Lokale Hostnamen:
✅ Cluster-Mini-01.fritz.box      → 192.168.178.29     (2 ms)
✅ Cluster-Mini-02.fritz.box      → 192.168.178.30     (2 ms)
✅ Cluster-Mini-03.fritz.box      → 192.168.178.31     (2 ms)
✅ Cluster-Mini-04.fritz.box      → 192.168.178.32     (2 ms)
✅ ES216G.fritz.box               → 192.168.178.96     (3 ms)

Internet-Domains:
✅ google.com                     → 142.250.185.14    (25 ms)
✅ github.com                     → 140.82.113.3      (45 ms)
❌ invalid-domain-xyz.com         → FAILED             (timeout)

DNS-Server: 192.168.178.1 (FRITZ!Box)
Durchschnittliche Auflösungszeit: 15 ms
```

### 2. DNS-Cache-Monitor

Claude erstellt Skripte für:
- Abfrage des lokalen DNS-Caches
- Cache-Hit-Rate-Berechnung
- Erkennung von böswilligen Domains

**Aufruf:**
```bash
python3 scripts/dns_cache_stats.py
```

**Ergebnis:**
```
DNS-Cache-Statistiken
=====================
Total Anfragen (24h): 2,548
Cache Hits: 1,890 (74%)
Cache Misses: 658 (26%)
Durchschnittliche TTL: 3,600 Sekunden (1 Stunde)

Häufigste Domains:
1. google.com (456 Anfragen)
2. github.com (234 Anfragen)
3. stackoverflow.com (178 Anfragen)
```

### 3. DNS-Fehlerdiagnose

Claude erstellt automatisch:
- Logs von DNS-Anfragen
- Fehlerberichts
- Empfehlungen bei Problemen

**Beispiel:**
```
⚠️ DNS-Fehler erkannt!
DNS-Anfrage zu "problematic-domain.com" fehlgeschlagen.
→ Wahrscheinlich: Domain existiert nicht oder ist offline
→ Empfehlung: Domain-Name überprüfen
```

### 4. Resolver-Diagnose

Claude erstellt ein Skript, das:
- Prüft, welcher DNS-Server verwendet wird
- Testet die Responsetime des Servers
- Prüft DNS-Konfiguration auf Fehler

**Aufruf:**
```bash
python3 scripts/dns_resolver_check.py
```

**Ergebnis:**
```
DNS-Resolver-Konfiguration
===========================
Primary DNS: 192.168.178.1 (FRITZ!Box)
Secondary DNS: (none - konfiguriert)

DNS-Server-Responsetime:
192.168.178.1 → 1-2 ms (lokal, sehr schnell) ✅
8.8.8.8 (Google) → 8-12 ms (Fallback) ✅

Empfehlung: Alles in Ordnung
```

---

## Wichtige Befehle für Automation

```bash
# DNS-Auflösung testen (nslookup)
nslookup Cluster-Mini-01.fritz.box

# Detaillierte DNS-Abfrage (dig)
dig Cluster-Mini-01.fritz.box

# einfache Auflösung (host)
host google.com

# Lokale DNS-Konfiguration (macOS)
scutil --dns

# DNS-Cache leeren (macOS)
sudo dscacheutil -flushcache

# DNS-Server prüfen (Linux)
cat /etc/resolv.conf
```

---

## Wann nutzt man diesen Workflow?

✅ **Nutze Claude-Automation:**
- Regelmäßige DNS-Tests (täglich)
- Performance-Monitoring
- Fehlerdetection
- Cache-Statistiken
- Historische Daten

❌ **Nutze stattdessen manuelle Commands (Modul 06-dns_manuell.md):**
- Ad-hoc Tests
- Einmalige Diagnose
- Manuelle Auflösungsprüfung
- Troubleshooting einzelner Domains

---

## Typisches Workflow-Beispiel

**Szenario:** Dr. Stracke fragt "Warum lädt die Seite so langsam?"

**Mit Claude-Automation:**
1. Claude führt DNS-Test aus
2. Zeigt Ergebnis:
   - DNS-Auflösung: 2 ms ✅ (sehr schnell)
   - Seiten-Ladezeit: 8 Sekunden ❌ (Problem nicht bei DNS)
3. Empfehlung: Problem liegt wahrscheinlich bei der Website oder Internet-Verbindung

---

## Beste Praktiken

1. **DNS Tests täglich:** Um 10:00 UTC
2. **Fehler-Alerts:** Nur bei kritischen Problemen
3. **Cache-Statistiken:** Wöchentlich analysi
4. **Reports:** Monatlich für Performance-Vergleiche
5. **Timeout erhöhen:** Für langsame Netzwerke

---

**Nächster Schritt:** Siehe Modul 06-dns_manuell.md für manuelle DNS-Tests und Troubleshooting.
