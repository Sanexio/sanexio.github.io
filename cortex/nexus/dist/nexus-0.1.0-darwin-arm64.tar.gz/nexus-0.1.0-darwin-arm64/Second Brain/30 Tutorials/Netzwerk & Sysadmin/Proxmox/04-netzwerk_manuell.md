# Proxmox 04 — Manueller Workflow

> Schritt-für-Schritt im Web-Interface und Terminal.

---

## Übung 1: Netzwerk-Konfiguration anzeigen

Im Web-Interface:
1. Node → **Network** Tab
2. Du siehst alle konfigurierten Interfaces und Bridges

Per Terminal:
```bash
# Aktuelle Netzwerk-Konfiguration
cat /etc/network/interfaces

# Aktive Netzwerk-Interfaces
ip addr show

# Bridge-Informationen
brctl show

# Routing-Tabelle
ip route
```

## Übung 2: Isoliertes Test-Netzwerk erstellen

Wir erstellen eine Bridge OHNE physischen Port — ein rein virtuelles Netzwerk:

1. Node → Network → **Create** → **Linux Bridge**
2. Name: `vmbr1`
3. IPv4/CIDR: `10.99.99.1/24`
4. Bridge ports: *leer lassen*
5. Comment: `Isoliertes Test-Netzwerk`
6. **Create** → **Apply Configuration**

Jetzt können Test-VMs an `vmbr1` gehängt werden. Sie können untereinander
kommunizieren, aber NICHT ins Internet oder ins Praxis-Netzwerk.

Per Terminal:
```bash
# In /etc/network/interfaces hinzufügen:
cat >> /etc/network/interfaces << 'EOF'

auto vmbr1
iface vmbr1 inet static
    address 10.99.99.1/24
    bridge-ports none
    bridge-stp off
    bridge-fd 0
    # Isoliertes Test-Netzwerk
EOF

# Netzwerk neu laden
ifreload -a
```

## Übung 3: VM ins Test-Netzwerk hängen

1. Test-Container (z.B. CT 200) → **Network** Tab
2. Bestehendes Interface editieren ODER neues hinzufügen:
   - Bridge: `vmbr1`
   - IPv4: `10.99.99.10/24`
   - Gateway: `10.99.99.1`
3. Container neustarten

Prüfen:
```bash
# Im Container:
ip addr show
ping 10.99.99.1    # Gateway erreichbar?
ping google.com     # Internet NICHT erreichbar (gewollt!)
```

## Netzwerk-Diagnose-Befehle

```bash
# Vom Proxmox-Host:

# Welche VMs hängen an welcher Bridge?
brctl show

# Netzwerk-Traffic beobachten
tcpdump -i vmbr0 -n -c 20

# DNS testen
dig google.com @192.168.10.1

# Verbindung zu einer VM testen
ping 192.168.10.100

# Ports scannen (von Proxmox zu einer VM)
nmap -sT 192.168.10.100
```

---

## Nächste Schritte

→ **05-sicherheit.md** — Server absichern
