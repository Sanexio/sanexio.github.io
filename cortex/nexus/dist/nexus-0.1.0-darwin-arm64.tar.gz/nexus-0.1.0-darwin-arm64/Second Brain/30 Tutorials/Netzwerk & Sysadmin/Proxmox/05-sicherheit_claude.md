# Proxmox 05 — Claude-Workflow

> Was Claude für dich automatisiert machen kann.

---

## Sicherheits-Audit vorbereiten

```
"Claude, erstelle eine Sicherheits-Checkliste für unseren Proxmox-Server
und prüfe, ob wir DSGVO-konform aufgestellt sind."

→ Claude erstellt eine detaillierte Checkliste mit:
  - Technische Maßnahmen (Verschlüsselung, Backup, Firewall)
  - Organisatorische Maßnahmen (Zugriffsprotokoll, Verantwortlichkeiten)
  - DSGVO-spezifische Anforderungen für Arztpraxen
```

## SSH-Konfiguration generieren

```
"Claude, erstelle mir eine gehärtete SSH-Konfiguration für Proxmox."

→ Claude generiert eine vollständige sshd_config mit
  Best-Practice-Einstellungen und erklärt jede Zeile.
```

## Firewall-Regeln prüfen

```
"Claude, hier sind unsere aktuellen Firewall-Regeln: [Regeln einfügen].
Gibt es Sicherheitslücken?"

→ Claude analysiert die Regeln und schlägt Verbesserungen vor.
```

## Einschränkungen

- Sicherheitsänderungen IMMER erst planen, dann testen, dann live schalten
- Bei SSH-Änderungen: Parallele Session offenhalten als Rettungsanker
- Im Zweifel: IPMI/BMC-Zugang vorher testen
