---
type: tutorial
aliases: [Proxmox, Virtualisierung, VMs, Container, Hypervisor, Homelab]
tags:
  - tutorial
  - proxmox
  - virtualisierung
  - homelab
source: Second Brain/30 Tutorials/Proxmox/
legacy_path: _tutorials/proxmox/ (Symlink)
---

# Proxmox VE — Tutorial-Übersicht

> Quellpfad: `Second Brain/30 Tutorials/Proxmox/` (Single Source of Truth)
> Legacy-Pfad: `_tutorials/proxmox/` → Symlink

Proxmox Virtual Environment (PVE) ist ein Open-Source-Hypervisor, der es dir ermöglicht, auf EINER Hardware mehrere virtuelle Maschinen (VMs) und Container gleichzeitig zu betreiben.

---

## Warum Proxmox?

In deiner Praxis laufen verschiedene Dienste, die voneinander getrennt sein sollen:
- **Domain Controller (DC):** Verwaltet Benutzerkonten, Login, Berechtigungen
- **File Server:** Speichert Patientenakten und Dokumente
- **Application Server:** Praxissoftware, Medizintechnik-Anbindung

Ohne Virtualisierung bräuchtest du für jeden Dienst einen eigenen Server — teuer, laut, stromfressend. Mit Proxmox laufen alle auf EINER Hardware, aber sauber getrennt.

---

## Module

### 01 — Grundlagen
**Verstehen, was Proxmox ist und wie es funktioniert.**

Lerninhalte:
- **Hypervisor:** Software, die VMs auf Hardware hostet
- **Typ-1 vs. Typ-2:** Proxmox läuft DIREKT auf Hardware (schneller!)
  - Typ-2: Hardware → OS (Windows/macOS) → VirtualBox → VMs
  - Typ-1: Hardware → Proxmox → VMs + Container (direkt!)
- **VMs vs. Container:** Der Unterschied und wann du was nutzt
- **Architektur:** Wie Proxmox intern funktioniert

**Module:**
- Theorie: `01-grundlagen.md`
- Claude-Workflow: `01-grundlagen_claude.md`
- Manuell: `01-grundlagen_manuell.md`

---

### 02 — VMs und Container
**Erstellen und verwalten virtueller Systeme.**

Lerninhalte:
- **VM (Virtual Machine):** Vollständiges Betriebssystem (Windows, Linux)
  - Mehr Ressourcen
  - Komplette Isolation
  - Längere Boot-Zeit
- **Container (LXC):** Leichtgewicht OS ohne Kernel
  - Schneller
  - Weniger Ressourcen
  - Bessere Performance
- **Wann welches?** Entscheidungshilfen
- **Erstellen, Starten, Stoppen, Löschen**

**Module:**
- Theorie: `02-vms-und-container.md`

---

### 03 — Storage und Backup
**Speicherplatz verwalten und Daten sichern.**

Lerninhalte:
- **Local Storage:** Proxmox-Festplatte
- **NFS:** Network File System (zentraler Speicher)
- **iSCSI:** Block-Storage übers Netzwerk
- **Backup-Strategien:**
  - Snapshots (schnelle Zwischenstand)
  - Incremental Backups (nur Änderungen)
  - Retention Policies (wie lange speichern?)
  - Offsite Backups (kopiert zur Cloud/externem Server)
- **Disaster Recovery:** Wiederherstellen nach Notfall

**Module:**
- Theorie: `03-storage-und-backup.md`
- Claude-Workflow: `03-storage-und-backup_claude.md`
- Manuell: `03-storage-und-backup_manuell.md`

---

### 04 — Netzwerk
**Deine VMs ins Netzwerk bringen.**

Lerninhalte:
- **Virtuelle Netzwerk-Geräte:** Bridges, vlan-aware Switches
- **Linux Bridges:** `vmbr0`, `vmbr1` (wie physische Switch-Ports)
- **VLAN:** Mehrere logische Netze auf einer Hardware
  - VLAN 10: Domain Controller
  - VLAN 20: File Server
  - VLAN 30: Praxis-Software
- **Firewall-Regeln:** Wer darf mit wem sprechen?
- **DNS in VMs:** Auflösung der lokalen Domain
- **Troubleshooting:** Netzwerk-Fehler finden

**Module:**
- Theorie: `04-netzwerk.md`
- Claude-Workflow: `04-netzwerk_claude.md`

---

### 05 — Sicherheit
**Deine VMs und Daten schützen.**

Lerninhalte:
- **Firewall im Proxmox:** IN/OUT/FORWARD Regeln
- **VM-Isolation:** Wer kann mit wem kommunizieren?
- **Zugriffskontrolle:** Wer darf Proxmox administrieren?
- **Verschlüsselung:** Von Speicher bis Backup
- **SSL/TLS:** Sichere Verbindungen
- **Regelmäßige Updates:** Security Patches
- **Sicherheits-Checkliste:** Vor produktiver Nutzung

**Module:**
- Theorie: `05-sicherheit.md`
- Claude-Workflow: `05-sicherheit_claude.md`
- Manuell: `05-sicherheit_manuell.md`

---

### 06 — Monitoring und Wartung
**Überwachen, dass alles läuft, und planmäßig warten.**

Lerninhalte:
- **Proxmox Dashboard:** CPU, RAM, Storage im Überblick
- **Performance-Metriken:** Was ist normal?
- **Alerting:** Benachrichtigungen bei Problemen
- **Logs:** Fehler finden im `/var/log/`
- **Regelmäßige Wartung:**
  - Kernel Updates
  - Sicherheits-Patches
  - Storage-Checks
  - Backup-Verifizierung
- **Capacity Planning:** Wann brauchst du mehr Hardware?

**Module:**
- Theorie: `06-monitoring-und-wartung.md`
- Claude-Workflow: `06-monitoring-und-wartung_claude.md`

---

## Bonus: Praxis-Konfiguration

**Datei:** `praxis-konfiguration.md`

Dein komplettes Setup für die ärztliche Praxis:
- **DC (Domain Controller):** Windows Server mit Active Directory
- **File Server:** Linux mit NFS-Export für Patientenakten
- **Application Server:** Praxissoftware
- **Backup Server:** Zentrale Backup-VM
- **Monitoring:** Prometheus + Grafana im Container
- **Netzwerk-Topologie:** VLANs und Firewall-Konfiguration
- **Checklisten:** Monatliche Wartung, Disaster Recovery, Sicherheit

---

## Lern-Reihenfolge

1. **01 — Grundlagen** (Basis-Konzepte)
2. **02 — VMs und Container** (Praktische Verwaltung)
3. **03 — Storage und Backup** (Datensicherheit — WICHTIG!)
4. **04 — Netzwerk** (VMs verbinden)
5. **05 — Sicherheit** (Schützen vor Angriffen)
6. **06 — Monitoring** (Alles läuft rund)
7. **Praxis-Konfiguration** (Deine konkrete Aufgabe)


<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

- [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/01-grundlagen|01-grundlagen]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/01-grundlagen_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/01-grundlagen_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/02-vms-und-container|02-vms-und-container]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/02-vms-und-container_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/02-vms-und-container_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/03-storage-und-backup|03-storage-und-backup]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/03-storage-und-backup_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/03-storage-und-backup_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/04-netzwerk|04-netzwerk]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/04-netzwerk_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/04-netzwerk_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/05-sicherheit|05-sicherheit]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/05-sicherheit_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/05-sicherheit_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/06-monitoring-und-wartung|06-monitoring-und-wartung]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/06-monitoring-und-wartung_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/06-monitoring-und-wartung_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/Proxmox/praxis-konfiguration|praxis-konfiguration]]

<!-- /auto-moc-links -->