# Proxmox Tutorial 01 — Grundlagen

> **Voraussetzungen:** Terminal-Grundlagen (`_tutorials/terminal-befehle/01-grundlagen.md`)
> **Ziel:** Verstehen, was Proxmox ist, warum man es braucht und wie Virtualisierung funktioniert.

---

## Was ist Proxmox VE?

Proxmox Virtual Environment (PVE) ist ein Open-Source-Hypervisor — eine Software,
die auf einem physischen Server läuft und es ermöglicht, darauf mehrere virtuelle
Maschinen (VMs) und Container gleichzeitig zu betreiben.

Stell dir vor, du hast einen sehr leistungsfähigen Computer. Statt darauf nur
EIN Betriebssystem laufen zu lassen, teilst du die Hardware auf und lässt
MEHRERE unabhängige Systeme parallel laufen — jedes denkt, es hätte seinen
eigenen Computer.

### Warum Proxmox in der Praxis?

In der Praxis laufen verschiedene Dienste, die voneinander getrennt sein sollen:

- **Domain Controller (DC):** Verwaltet Benutzerkonten, Login, Berechtigungen
- **File Server:** Speichert Patientenakten, Dokumente, Netzlaufwerke
- **Application Server:** Praxissoftware, Medizintechnik-Anbindung

Ohne Virtualisierung bräuchte man für jeden Dienst einen eigenen physischen
Server — teuer, laut, stromfressend. Mit Proxmox laufen alle auf EINER
Hardware, aber sauber getrennt.

## Typ-1 vs. Typ-2 Hypervisor

Es gibt zwei Arten von Virtualisierung:

**Typ-2 (z.B. VirtualBox, Parallels):** Läuft AUF einem normalen Betriebssystem.
Du installierst macOS oder Windows, und darin dann VirtualBox. Performance ist
eingeschränkt, weil alles durch das Host-OS durch muss.

**Typ-1 (z.B. Proxmox, VMware ESXi):** Läuft DIREKT auf der Hardware, ohne
dazwischenliegendes Betriebssystem. Proxmox ist ein Typ-1-Hypervisor — es IST
quasi das Betriebssystem. Deshalb ist es schneller und stabiler.

```
Typ-2:  Hardware → Windows/macOS → VirtualBox → VMs
Typ-1:  Hardware → Proxmox VE → VMs + Container (direkt!)
```

## VMs vs. Container

Proxmox kann beides — und der Unterschied ist wichtig:

### Virtuelle Maschinen (KVM/QEMU)
- Simulieren einen **kompletten Computer** mit eigener virtueller Hardware
- Jede VM hat ihren eigenen Kernel (Betriebssystem-Kern)
- Können JEDES Betriebssystem laufen (Windows, Linux, BSD, etc.)
- Brauchen mehr Ressourcen (RAM, CPU, Speicher)
- **Einsatz:** Windows-Server (DC, File Server), spezielle Software

### Container (LXC)
- Teilen sich den **Linux-Kernel** des Hosts
- Viel leichtgewichtiger (starten in Sekunden statt Minuten)
- Können NUR Linux laufen
- Brauchen weniger Ressourcen
- **Einsatz:** Webserver, DNS, Pi-Hole, Monitoring-Tools

**Faustregel:** Windows oder spezielle Hardware-Anforderungen → VM.
Linux-Dienst, der einfach laufen soll → Container.

## Die Hardware des Praxis-Servers

Der Proxmox-Host in der Praxis ist kein normaler PC, sondern ein professioneller
Server mit Enterprise-Komponenten:

- **CPU:** AMD Epyc 9135 — Server-Prozessor mit vielen Kernen
- **RAM:** 256 GB DDR5 ECC — ECC erkennt und korrigiert Speicherfehler automatisch
- **SSDs:** NVMe (schnell, für VMs) + SATA HDDs (groß, für Archiv/Backup)
- **GPU:** RTX 5060 Ti — für KI-Aufgaben oder GPU-Passthrough
- **Netzwerk:** 10/25 Gbit — deutlich schneller als normales 1-Gbit-Ethernet

### Storage-Pools

Proxmox organisiert Speicher in "Pools":

| Pool | Typ | Größe | Zweck |
|------|-----|-------|-------|
| rpool | 2× NVMe SSD (Mirror) | 960 GB | Proxmox-System, VM-Disks (schnell) |
| SSDPool1 | 2× U.2 NVMe (Mirror) | 7,68 TB | Große VMs, Datenbanken |
| HDDPool1 | 4× SATA HDD | 8 TB × 4 | Backups, Archiv, selten genutzte Daten |

**Mirror** bedeutet: Jede Daten wird auf BEIDEN Platten gleichzeitig gespeichert.
Fällt eine aus, läuft alles weiter.

## Das Web-Interface

Proxmox wird über ein Web-Interface gesteuert — kein Monitor am Server nötig.
Du öffnest einfach einen Browser und gehst zu:

```
https://<IP-des-Servers>:8006
```

Von dort aus kannst du:
- VMs und Container erstellen, starten, stoppen
- Ressourcen zuweisen (CPU, RAM, Disk)
- Netzwerke konfigurieren
- Backups erstellen und wiederherstellen
- Den Server überwachen (CPU-Auslastung, RAM, Netzwerk)

## Wichtige Begriffe

| Begriff | Bedeutung |
|---------|-----------|
| **Node** | Ein physischer Proxmox-Server |
| **VM** | Virtuelle Maschine (komplett isoliert, eigener Kernel) |
| **CT / LXC** | Container (teilt Host-Kernel, leichtgewichtig) |
| **Storage Pool** | Logische Zusammenfassung von Festplatten |
| **Bridge** | Virtuelle Netzwerk-Brücke (verbindet VMs mit dem Netzwerk) |
| **VLAN** | Virtuelles Netzwerk-Segment (Trennung ohne extra Kabel) |
| **Snapshot** | Momentaufnahme einer VM (zum schnellen Zurückrollen) |
| **Cluster** | Mehrere Proxmox-Nodes, die zusammenarbeiten |
| **HA** | High Availability — VMs starten automatisch auf anderem Node bei Ausfall |
| **IPMI/BMC** | Remote-Zugriff auf Server-Hardware (auch wenn Proxmox nicht läuft) |

---

## Nächste Schritte

- **02-vms-und-container.md** — VMs und Container erstellen und verwalten
- **03-storage-und-backup.md** — Storage-Pools und Backup-Strategien
- **04-netzwerk.md** — Netzwerk-Bridges, VLANs, Firewall
