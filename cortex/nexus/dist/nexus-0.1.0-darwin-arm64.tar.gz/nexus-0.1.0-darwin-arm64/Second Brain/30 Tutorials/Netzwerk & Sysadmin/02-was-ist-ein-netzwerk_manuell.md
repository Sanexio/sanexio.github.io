# Was ist ein Netzwerk — Manueller Workflow

**Einsatzbereich:** Web-UI-basierte Navigation, erste Orientierung, einmalige Setup-Aufgaben

**Wann ist dieser Workflow sinnvoll?**
- Du möchtest dich zum ersten Mal im Omada Controller orientieren
- Du möchtest den Switch manuell zu Omada hinzufügen (Adoption)
- Du brauchst eine visuelle Übersicht über dein Netzwerk
- Du möchtest VLAN-Einstellungen über die Web-UI vornehmen
- Du hast eine neue Hardware (neuer Access Point) und möchtest sie hinzufügen

---

## Szenario

Dr. Stracke möchte seinen neuen TP-Link ES216G Switch über den Omada Cloud Controller verwalten. Er braucht Schritt-für-Schritt-Anleitung durch die Web-UI.

---

## Workflow-Schritte

### Schritt 1: Omada Cloud Controller öffnen

1. Öffne den Browser
2. Navigiere zu: **https://euw1-omada-cloud.tplinkcloud.com**
3. Melde dich mit deinen Omada-Zugangsdaten an
4. Du siehst das Dashboard mit Übersicht der Geräte

**Erwarteter Anblick:**
- Switches: 0 (dein ES216G ist noch nicht hinzugefügt)
- Access Points: 3 (deine 3x EAP653 sind bereits verbunden)
- Clients: 18 Endgeräte

### Schritt 2: Verfügbare Geräte anzeigen

1. Im Menü links: Gehe zu **"Devices"** oder **"Geräte"**
2. Klicke auf den Tab **"Pending"** oder **"Ausstehend"**
3. Du solltest deinen ES216G Switch sehen:
   - **Modell**: TP-Link ES216G
   - **MAC-Adresse**: 78-20-51-96-96-EB
   - **IP-Adresse**: 192.168.178.96
   - **Status**: Pending (wartet auf Adoption)

### Schritt 3: Switch adoptieren (automatisch)

1. Klicke auf deinen ES216G Switch
2. Klicke auf die Schaltfläche **"Adopt"** oder **"Adoptieren"**
3. Warte 2-3 Minuten, während der Switch adoptiert wird
4. Status ändert sich von "Pending" zu "Online"

**Was passiert dabei:**
- Der Switch wird mit dem Omada Controller verbunden
- Der Controller speichert die Konfiguration
- Der Switch wird von jetzt an zentral verwaltet

### Schritt 4: Switch konfigurieren

Nach erfolgreicher Adoption:

1. Gehe zu **"Devices"** → **"Switches"**
2. Klicke auf deinen **ES216G**
3. Du siehst verschiedene Konfigurationsoptionen:
   - **Port-Einstellungen** (aktivieren/deaktivieren)
   - **VLANs** (virtuelle Netzwerke)
   - **QoS** (Priorisierung)
   - **Port-Mirroring** (Verkehrsüberwachung)

**Wichtig:** Für den Anfang keine Änderungen vornehmen - nur die Standardkonfiguration verwenden.

### Schritt 5: Dashboard-Übersicht

Nach erfolgreicher Adoption siehst du im Dashboard:

1. **Switches**: 1 (statt 0)
2. **Access Points**: 3 (unverändert)
3. **Clients**: Alle verbundenen Geräte
4. **Port-Status**: Überblick über alle Ports

**Grüne Pfeile** = Geräte verbunden
**Grauer Punkt** = Port ist leer

---

## Manuelles Troubleshooting

### Problem: Switch erscheint nicht in "Pending"

**Lösungsschritte:**
1. Prüfe, ob der Switch eingeschaltet ist (LED blinkt)
2. Prüfe die Netzwerkverbindung: `ping 192.168.178.96`
3. Öffne den Browser und gehe zu: `http://192.168.178.96`
4. Melde dich an (Username: `admin`, Passwort: `admin`)
5. Gehe zu **"Management"** → **"Omada Controller Settings"**
6. Stelle sicher, dass der Controller aktiviert ist

### Problem: Adoption schlägt fehl

**Lösungsschritte:**
1. Prüfe Internetverbindung
2. Warte länger (bis zu 5 Minuten)
3. Aktualisiere die Seite (F5)
4. Prüfe die Firewall-Einstellungen (Ports 29810-29814)
5. Versuche erneut zu adoptieren

### Problem: Switch ist offline nach Adoption

**Lösungsschritte:**
1. Prüfe Stromversorgung
2. Prüfe Netzwerkkabel
3. Neustarten: Router neu starten (30 Sekunden warten)
4. Erneut adoptieren

---

## Wichtige Netzwerk-Informationen im Dashboard

**Zu merken:**
- **Router (FRITZ!Box):** 192.168.178.1 - zentral, verwaltet Internet
- **Switch (ES216G):** 192.168.178.96 - verteilt Kabel-Verbindungen
- **Cluster Nodes:** .29-.32 - deine Render Nodes
- **Access Points:** .40, .61, .62 - deine WiFi-Access-Points

**Unterschiede:**
- **Router**: Verbindet dein Netzwerk mit dem Internet
- **Switch**: Verbindet nur Geräte untereinander (kein Internet-Zugriff)
- **Access Points**: Ermöglichen WiFi-Zugriff auf das Netzwerk

---

## Wann nutzt man diesen Workflow?

✅ **Nutze manuelle Web-UI:**
- Erste Orientierung im Dashboard
- Switch-Adoption durchführen
- Visuelle Geräte-Verwaltung
- Einmalige Konfigurationsschritte
- Troubleshooting via Web-Interface

❌ **Nutze stattdessen Claude-Automation (Modul 02-was-ist-ein-netzwerk_claude.md):**
- Regelmäßige Netzwerk-Scans
- Automatische Reports
- Geräte-Tracking
- Historische Daten
- Geplante Backups

---

## Praktischer Tipp

Nach erfolgreicher Adoption hast du folgende Optionen:

1. **Passwort ändern** (empfohlen): Switch-Login sichern
2. **Firmware aktualisieren**: Switch auf neueste Version
3. **Monitoring aktivieren**: Überwachung im Omada Dashboard
4. **Port-Verwaltung**: Später einzelne Ports konfigurieren

Für den Anfang: Einfach die Standard-Konfiguration beibehalten und den Switch überwachen.

---

**Nächster Schritt:** Siehe Modul 03-ip-adressen.md für IP-Adressierung im Detail.
