---
title: "Netzwerk & Sysadmin / 11 — VPN-Grundlagen + dein Cortex-Setting"
created: 2026-05-10
domain: netzwerk-sysadmin
status: live
tags: [tutorial, vpn, wireguard, tailscale, mesh, mac, ipad, cortex, setting]
related:
  - "09-cortex-mesh-tailscale.md"
  - "10-remote-zugriff-local-dev.md"
  - "../Cortex & Nexus/10-ipad-remote-desktop.md"
---

# 11 — VPN-Grundlagen und dein Cortex-Setting

> **Was du nach diesem Tutorial verstehst:**
> – was ein VPN technisch ist, welche Bauformen es gibt und wofür man sie nutzt
> – warum **Tailscale** in deinem Setting die richtige Wahl ist und wo seine Grenzen liegen
> – wie dein konkretes Tailnet aufgebaut ist (Live-Snapshot 2026-05-10)
> – welche Befehle du im Alltag wirklich brauchst und was du im Notfall tust
> – was Tier-3-Risiken sind (Apple-ID, Patientendaten)
>
> **Lesezeit:** 25–30 Minuten · **Voraussetzungen:** Modul 02 (Netzwerk-Grundlagen),
> Modul 03 (IP-Adressen), Modul 08 (CGNAT) sind hilfreich, aber nicht zwingend.
>
> Dieses Tutorial ist die **Theorie** zu Modul 09 (`09-cortex-mesh-tailscale.md`,
> dort steht das Setup-Cookbook) und zum praktischen Alltag in
> `Cortex & Nexus / 10-ipad-remote-desktop.md`.

---

## Teil 1 — VPN als Konzept

### §1.1 Was ist ein VPN überhaupt?

**VPN = Virtual Private Network.** Ein verschlüsselter Tunnel, der zwei oder
mehr Geräte so verbindet, als hingen sie am selben Switch — über das öffentliche
Internet hinweg. „Virtuell privat" heißt: das Internet sieht nur den Tunnel,
nicht den Inhalt; deine Geräte verhalten sich, als wären sie im selben LAN.

Drei Dinge leistet ein VPN technisch:

1. **Vertraulichkeit** — der Inhalt ist verschlüsselt, niemand zwischen den
   Endpunkten kann mitlesen (auch nicht dein ISP, der WLAN-Hotspot im Café,
   die Mobilfunk-Antenne).
2. **Authentifizierung** — beide Seiten beweisen einander kryptographisch,
   wer sie sind. Ohne korrekten Schlüssel kommt keiner rein.
3. **Erreichbarkeit** — Geräte hinter NAT, dynamischen IPs oder
   Carrier-Grade-NAT (siehe Modul 08) sind plötzlich von überall erreichbar,
   weil der Tunnel-Endpunkt sie als „im selben virtuellen Netz" anbietet.

Was VPN **nicht** leistet (verbreitete Missverständnisse):

| Missverständnis | Realität |
|---|---|
| „Ein VPN macht mich anonym im Internet" | Falsch. Es verschiebt nur das Vertrauen vom ISP zum VPN-Anbieter. Anonymität braucht Tor o.ä. |
| „Ich kann damit GeoBlocking umgehen" | Bedingt. Streaming-Dienste blocken die meisten kommerziellen VPN-Range-IPs gezielt. |
| „Ein VPN schützt mich vor Phishing/Malware" | Nein. Ein VPN ist ein Transport-Tunnel, kein Inhalts-Filter. |
| „Mit VPN ist mein Heim-Netz im Internet sichtbar" | Im Gegenteil — ein VPN ersetzt Port-Freigaben am Router, das Heim-Netz bleibt nach außen geschlossen. |

### §1.2 Klassische Bauformen

```
Site-to-Site                    Remote-Access                   Mesh
(Standort ↔ Standort)            (Mitarbeiter ↔ Firma)            (jeder ↔ jeder)

   Praxis-Netz                    Mitarbeiter-Laptop              Mac1 ─── Mac2
       │                                │                          │  ╲   ╱  │
   [VPN-GW]──Internet──[VPN-GW]      Internet                       │   ╳    │
       │                                │                          │  ╱   ╲  │
   Sanexio-Netz                     [VPN-GW]                      Mac3 ─── iPad
                                       │
                                   Firmen-Netz
```

| Modell | Wer redet mit wem? | Beispiel |
|---|---|---|
| **Site-to-Site** | Zwei feste Standorte über VPN-Gateways | Praxis-Server ↔ Sanexio-Buchhaltung |
| **Remote-Access** | Einzelne Clients dialen ins Firmen-Netz ein | Klassisches OpenVPN/IPsec von Cisco, FortiGate etc. |
| **Mesh** | Jedes Gerät hat zu jedem anderen einen Tunnel | Tailscale, ZeroTier, Nebula |

**Dein Setting ist Mesh** — jeder Mac kann jeden anderen Mac und das iPad direkt
erreichen, ohne ein zentrales Gateway. Das ist die moderne Bauform und
operationell unkomplizierter, weil kein Gateway als Single Point of Failure
existiert.

### §1.3 Wichtige VPN-Protokolle

| Protokoll | Status | Pro | Contra |
|---|---|---|---|
| **WireGuard** | modern, ~2018, Linux-Kernel-Modul | minimal (nur ~4 kLOC), schnell, einfache Config | UDP-only, keine Built-in-Authentication-Federation |
| **OpenVPN** | etabliert, ~2002 | sehr ausgereift, TLS-basiert, jahrzehntelang auditiert | komplexe Config, langsamer als WireGuard |
| **IPsec** | RFC seit 1995 | OS-Standard, Site-to-Site-Klassiker | steif, hakelige NAT-Traversierung, bürokratische Config |
| **L2TP/PPTP** | obsolet | – | unsicher, nicht mehr nutzen |
| **WireGuard via Tailscale** | Mesh-Wrapper über WireGuard | siehe Tailscale unten | Ökosystem-Lock-in (siehe §3.5) |

WireGuard hat sich seit ~2020 als De-facto-Standard etabliert, weil:
- Es ist im Linux-Kernel, also ohne User-Space-Daemon nutzbar.
- Die Codebasis ist ein Bruchteil von OpenVPN — kleinere Angriffsfläche.
- Die Performance ist nahe an Wire-Speed (≥1 Gbit/s problemlos).
- Es nutzt moderne Krypto (Curve25519, ChaCha20, Poly1305, BLAKE2s) —
  alles als sicher geltende Algorithmen ohne bekannte Schwächen.

WireGuards Schwäche ist die **operative Komplexität** im Mesh-Fall: Bei N
Geräten brauchst du N×(N−1) Tunnel-Configs, jede mit eigenen Keys. Genau
diese Lücke schließt Tailscale.

---

## Teil 2 — Tailscale als VPN-Implementierung

### §2.1 Was Tailscale eigentlich ist

Tailscale ist **WireGuard plus Control-Plane**. Der eigentliche Datenverkehr
läuft direkt zwischen deinen Geräten via WireGuard — verschlüsselt mit Keys,
die nur deine Geräte kennen. Tailscale-die-Firma sieht den Inhalt **nicht**.

Was Tailscale beisteuert ist die Verwaltung drumherum:

```
        ┌──────────────────┐
        │  Tailscale Cloud │   ← Coordination-Server (sieht: wer ist im Tailnet,
        │  (Coord.-Server) │     welche Public-Keys, welche IPs, ACLs)
        └────────┬─────────┘     SIEHT NICHT: deinen Traffic
                 │
       Apple-ID-Auth (oder Google, GitHub, MS, OIDC)
                 │
   ┌─────────────┼─────────────┬───────────────┐
   │             │             │               │
[ Mac1 ]    [ Mac2 ]      [ iPad ]        [ iPhone ]
   ↑             ↑             ↑               ↑
   └── direkter WireGuard-Tunnel zwischen je 2 Peers ──┘
       (NUR im Notfall über DERP-Relay umgeleitet)
```

**Komponenten:**

- **Coordination-Server** — ein zentrales Verzeichnis, das jedem Gerät sagt:
  „Hier sind die Public-Keys und IPs der anderen Geräte in deinem Tailnet."
  Selbst gehosteter Open-Source-Klon: **Headscale**.
- **DERP-Relays** — Notfall-Relays, falls zwei Peers keine direkte Verbindung
  aufbauen können (z. B. beide hinter symmetrischem NAT). Dein Traffic ist
  auch über DERP Ende-zu-Ende verschlüsselt — Tailscale relayed nur Pakete,
  kann sie nicht lesen.
- **MagicDNS** — automatische DNS-Auflösung deiner Geräte-Namen
  (`cluster-mini-02.piranha-marlin.ts.net` statt `100.127.125.48`).
- **ACLs** (Access Control Lists) — JSON-Policy auf der Tailnet-Ebene, die
  bestimmt, welches Gerät welches andere erreichen darf. Default: alle dürfen
  alles. Optional einschränkbar.
- **Identity Provider** — Tailscale verlangt Login per OIDC: Google, GitHub,
  Microsoft, Apple-ID, eigene OIDC-Quelle. Kein eigenes Passwort.

### §2.2 Was du dafür bezahlst (oder eben nicht)

Tailscale-Free ist kostenlos für **bis zu 100 Geräte** und 3 User. Du bist
in dieser Klasse — also Null-Kosten dauerhaft. Bezahlpläne brauchst du erst
bei Team-Setups oder Funktionen wie SAML-SSO, Audit-Logs, Tailnet-Lock.

### §2.3 Tailscale-Konkurrenz

| Produkt | Kurzbewertung |
|---|---|
| **ZeroTier** | älter, eigenes Protokoll (nicht WireGuard), seit 2014. Funktional ähnlich, aber weniger nahtlos auf Apple-Geräten. |
| **Nebula** (Slack-Open-Source) | self-hosted only, mehr Bastelei, dafür kein Vendor-Lock-in. |
| **Headscale** | Open-Source-Klon des Tailscale-Coordination-Servers; man läuft Tailscale-Clients gegen einen eigenen Server. Höchste Souveränität, dafür mehr Wartung. |
| **WireGuard pur** | Maximale Kontrolle, maximaler Konfig-Aufwand. Nur sinnvoll bei wenigen statischen Endpunkten. |

Tailscale ist die richtige Wahl für dein Setting, weil du Apple-zentriert bist,
keine Zeit für Headscale-Wartung hast und die Free-Quote nicht überschreitest.

---

## Teil 3 — Dein konkretes Cortex-Setting (Live-Stand 2026-05-10)

### §3.1 Tailnet-Identität

| Feld | Wert |
|---|---|
| **Tailnet-Name** | `7vwcqsnty6@privaterelay.appleid.com` |
| **Identity-Provider** | Apple-ID (mit Hide-My-Email-Relay-Adresse) |
| **MagicDNS-Suffix** | `piranha-marlin.ts.net` |
| **Plan** | Free (Personal-Plan; Tailnet-Suffix wurde von Tailscale per Random-Wortpaar vergeben — der Wunschname „cortex" war auf dem Free-Plan nicht buchbar) |
| **Tier** | privat, einzelner User (du) |
| **Admin-Konsole** | <https://login.tailscale.com/admin/machines> |

> **Wichtig zur Apple-ID:** Du loggst dich bei Tailscale via „Sign in with Apple"
> ein, dabei wird eine Apple-ID-Relay-Adresse generiert (die `7vwcqsnty6@…`-Adresse).
> Das ist eine Wegwerf-E-Mail, die intern auf deine echte Apple-ID zeigt. Konsequenz:
> deine Apple-ID ist der **Master-Key** zu deinem Tailnet. Verlust der Apple-ID
> = vollständiger Verlust des Tailnets (siehe §6 Sicherheit).

### §3.2 Geräte im Mesh — Live-Snapshot 2026-05-10

| Tailscale-IP | Hostname | Gerät | OS | Status |
|---|---|---|---|---|
| `100.127.125.48` | `cluster-mini-02` | Mac mini M2 (Home) | macOS 15.5 | online (Self) |
| `100.119.241.21` | `praxis-studio` | Mac Studio (Praxis Zi2) | macOS 15.7.4 | online, relay=nue |
| `100.115.230.94` | `macbookpro-intel` | MacBook Pro Intel (Praxis-Mobil-alt) | macOS 15.7.4 | offline, IP-Konflikt mit M5 — siehe §7.1 |
| `100.95.255.46` | `SSMD-MacBookPro M5` | MacBook Pro M5 Pro | macOS 26.4 | offline (Akku-Modus, schläft) |
| `100.105.151.95` | `localhost` | iPad (iOS) | iOS | online, direct |

> Vollregistrierung mit physischen Adressen, Brew-Prefix, SSH-User etc. liegt in
> `Nexus/.config/devices.json`.

### §3.3 Welche Services laufen über das Tailnet?

Auf `cluster-mini-02` (deinem Home-Mac, von dem du gerade liest):

| Service | Port | Zweck | Erreichbar |
|---|---|---|---|
| macOS Bildschirmfreigabe (VNC) | 5900 | iPad → Mac per Jump Desktop | von allen Tailnet-Mitgliedern |
| Apple Remote Desktop | 3283 | für ARD-Clients (nicht aktiv genutzt) | von allen Tailnet-Mitgliedern |
| SSH | 22 | Terminal-Zugriff von anderen Macs | von allen Tailnet-Mitgliedern |
| nginx (lokales Praxis-Webseiten-Staging) | 80 / 443 | WP-Entwicklungs-Site | von allen Tailnet-Mitgliedern |
| Local-by-Flywheel-Stacks | 10003 / 10004 | nginx + MariaDB der Dev-Site | nur localhost (siehe Modul 10 für Tunnel-Tricks) |
| mailpit | 10000 / 10001 | lokale E-Mail-Capture | nur localhost |
| AirPlay (ControlCenter) | 5000 / 7000 | Apple-Continuity | LAN + Tailnet |
| rapportd | 49152 | Apple-Continuity-Pairing | LAN + Tailnet |

**Faustregel:** Alles, was auf `0.0.0.0`/`*` lauscht, ist tailnet-weit
erreichbar. Was auf `127.0.0.1`/`[::1]` bindet, ist nur lokal — für solche
Services gibt es Modul 10 (`/etc/hosts`-Trick, SSH-Tunnel, Tailscale Serve).

### §3.4 Welche Apple-Geräte können was?

| Von | Auf | Wie |
|---|---|---|
| iPad / iPhone (Tailscale-iOS-App) | Mac (VNC, SSH, HTTP) | Jump Desktop, Termius, Safari mit Tailscale-IP/MagicDNS |
| Mac → Mac | SSH, VNC, Files (smb://) | über `ssh praxis`, `ssh studio` (siehe `~/.ssh/config`) |
| Mac → iPad/iPhone | nichts direkt | iOS-Tailscale ist Client-only, kein SSH-Server |
| Externe (Bekannte) | nichts | Tailnet ist privat. Sharing per Tailscale-Sharing-Link einzeln möglich |

### §3.5 Lock-in-Realität

Tailscale-Free hat zwei harte Lock-ins:

1. **Apple-ID** — dein Identity-Provider ist Apple. Wechsel zu einem anderen
   IdP geht nur, indem du das Tailnet **neu aufbaust** (jedes Gerät neu
   anmelden, Tailnet-Owner-Wechsel ist auf Free-Plan nicht supportet).
2. **Tailscale-Coordination-Server** — die Cloud-Komponente kommt von
   Tailscale Inc. Wenn die Firma morgen abdreht, läuft dein Mesh weiter, bis
   das erste Gerät rebootet — dann braucht es einen Coordination-Server, und
   der ist weg. Migrationspfad: Headscale aufsetzen, Clients mit
   `--login-server`-Flag umlenken.

In der Praxis: Tailscale-Inc. ist seit 2019 stabil aufgestellt, von Heroku-
und Google-Veteranen gegründet, profitabel. Ein Headscale-Migrationspfad
existiert dokumentiert. Lock-in ist real, aber nicht akut.

---

## Teil 4 — Was du im Alltag wirklich brauchst

### §4.1 Zehn Befehle, die reichen

Auf jedem Mac im Mesh:

```bash
# Status — wer ist online, wer relay, wer direct
tailscale status

# Eigene Tailscale-IP
tailscale ip -4

# Health-Check (Direct-Connections, DERP-Latenzen, Portmapping)
tailscale netcheck

# Anpingen eines anderen Tailnet-Mitglieds (nicht ICMP — Tailscale-Layer)
tailscale ping praxis-studio

# Manuelles Re-Auth nach OS-Update / Apple-ID-Wechsel
sudo tailscale up --force-reauth

# Tailnet verlassen (z.B. vor Verkauf eines Geräts)
sudo tailscale logout

# Datei senden (nutzt internen Tailscale-Drop)
tailscale file cp foo.txt praxis:

# Service exposen — nur intern, Tailscale Serve
tailscale serve --bg --https=443 http://localhost:8080

# Service exposen — öffentlich (Tailscale Funnel, braucht DNS-Aktivierung)
tailscale funnel --bg 8080

# Admin-Konsole im Browser
open https://login.tailscale.com/admin/machines
```

Auf dem iPad oder iPhone gibt es kein Terminal — alles passiert in der
Tailscale-iOS-App. Wichtigster Schalter dort: **„Use Tailscale DNS"** muss
**an** sein, sonst funktioniert MagicDNS nicht.

### §4.2 Neues Gerät hinzufügen — Kurzfassung

1. Tailscale-Client auf dem Gerät installieren
   - macOS: `brew install --cask tailscale-app` oder Mac-App-Store
   - iOS: App Store → „Tailscale"
   - Windows/Linux: <https://tailscale.com/download>
2. Mit Apple-ID einloggen (immer dieselbe wie für dein Tailnet)
3. Auf dem ersten Mac: `tailscale up --hostname=<gewünschter-name> --ssh --accept-routes`
   (nur einmal nötig, danach merkt sich der Daemon das)
4. In der Admin-Konsole prüfen: <https://login.tailscale.com/admin/machines> →
   das neue Gerät erscheint binnen Sekunden.
5. Optional: alte Geräte mit gleicher IP entfernen (siehe §7.1).

Volle Setup-Schritte für die Cortex-Macs siehe **Modul 09** dieser Domain.

### §4.3 Was du **nicht** musst

- **Keine Port-Freigabe in der FritzBox.** Tailscale baut den Tunnel selbst
  auf, dein Heim-Router ist außen vor. (Falls UPnP an ist, nutzt Tailscale
  ihn opportunistisch für bessere Direct-Connections — aber Pflicht ist es
  nicht.)
- **Keine statische öffentliche IP nötig.** Dein Provider (Deutsche
  Glasfaser, GoDaddy bei der Praxis) darf dir täglich eine neue
  IPv4 geben — Tailscale findet das raus.
- **Keine eigene Domain.** MagicDNS gibt dir `*.piranha-marlin.ts.net`
  kostenlos. Eigene Domain wäre nur für Tailscale Funnel sinnvoll.

---

## Teil 5 — Was Tailscale **nicht** ersetzt

Tailscale ist ein **Transport-Layer** — es baut den Tunnel und liefert
TCP/UDP-Pakete von A nach B. Was über den Tunnel läuft, ist Sache der
Anwendungen:

| Anforderung | Tailscale macht | Du brauchst zusätzlich |
|---|---|---|
| Mac-Bildschirm vom iPad bedienen | Tunnel zu Port 5900 | macOS Bildschirmfreigabe (eingebaut) + Jump Desktop (iPad) |
| Datei-Sync zwischen Macs | nichts spezifisch | iCloud, Syncthing, rsync |
| Cluster-Dateifreigabe (SMB) | Tunnel zu Port 445 | macOS „Datei-Freigabe" |
| Gemeinsame Datenbank | Tunnel zu Port 5432/3306 | PostgreSQL/MySQL mit `bind-address=0.0.0.0` |
| WordPress-Dev-Site teilen | siehe Modul 10 | `/etc/hosts`-Eintrag oder SSH-Tunnel |
| Video-Streaming | Tunnel | Jellyfin, Plex |

---

## Teil 6 — Sicherheit und Tier-3-Risiken

### §6.1 Was Tailscale dir gibt

- **Ende-zu-Ende-Verschlüsselung** zwischen Peers via WireGuard (Curve25519,
  ChaCha20-Poly1305). Tailscale-die-Firma kann den Inhalt nicht entschlüsseln,
  auch nicht über DERP-Relays (DERP relayed nur verschlüsselte Pakete).
- **Authentifizierung pro Gerät.** Jedes Gerät hat einen eigenen Public/Private-Key.
  Verloren gegangenes Gerät → in der Admin-Konsole die Maschine löschen, fertig.
- **Default-Deny von außen.** Geräte, die nicht im Tailnet sind, sehen deine
  Macs nicht. Kein offener Port ins Internet, keine Brute-Force-Versuche
  in den SSH-Logs.

### §6.2 Was Tailscale dir **nicht** gibt

- **Patientendaten**: VPN-Tunnel ≠ DSGVO-Compliance. Wenn du
  patientenbezogene Daten zwischen deinen Macs überträgst, musst du
  separat sicherstellen, dass die Anwendungs-Schicht (E-Mail, Datei-Format,
  Backup-Ziel) DSGVO-konform ist.
- **Schutz bei kompromittiertem Gerät**: Wenn ein Mac geknackt wird, hat
  der Angreifer von dort aus Tailnet-Zugang zu allen anderen. Mitigation:
  Tailnet-ACLs einschränken, Geräte-Pin/Touch-ID konsequent.
- **Kein Audit-Log auf Free-Plan**: Wer wann auf welchen Mac zugegriffen hat,
  loggt Tailscale nicht. Kommt erst mit Personal-Pro-Plan oder eigenem
  Headscale + Logging.

### §6.3 Tier-3-Risiken im Cortex-Kontext

In Cortex-Sprache: drei Operationen sind **Tier-3** (Stop + User-Freigabe):

1. **Apple-ID-Verlust = Tailnet-Verlust.** Wenn die Apple-ID
   `7vwcqsnty6@privaterelay.appleid.com` (über die echte Apple-ID dahinter)
   verloren geht, ist das Tailnet weg. Mitigation: Apple-ID 2FA + Recovery-Key
   sicher hinterlegen, Recovery-Key NICHT in Cortex-Memory committen.
2. **Tailnet-Owner-Wechsel** (z. B. bei Praxis-Verkauf). Auf Free-Plan nicht
   supportet — du musst das Tailnet neu aufbauen, alle Geräte neu anmelden.
3. **Sharing an Externe.** Tailscale erlaubt Geräte-Sharing per Link an andere
   Tailnet-User (z. B. Steuerberater, Sanexio-Mitarbeiter). Das ist Tier-3
   §3 (externer Empfänger): bevor du teilst, klar machen, was die andere
   Seite sehen kann.

---

## Teil 7 — Troubleshooting aus dem Cortex-Alltag

### §7.1 IP-Konflikt M5 ↔ Intel-MBP (live aktuell)

**Symptom:** `tailscale status` zeigt `100.115.230.94` mal als `macbookpro-intel`,
mal als `SSMD-MacBookPro M5`. SSH zur IP geht mal, dann wieder nicht.

**Ursache:** Beim Migrationsassistenten 2026-05-06 hat der M5 den NodeKey vom
Intel-MBP übernommen, beide Macs haben dieselbe Tailscale-Identität benutzt.
Beim Reset 2026-05-09 wurde der M5 frisch aufgenommen (jetzt `100.95.255.46`),
aber wenn der Intel-MBP wieder online geht, übernimmt er kurzzeitig wieder
`100.115.230.94`.

**Fix:** An beiden Macs einmal physisch:

```bash
sudo tailscale up --force-reauth --hostname=<eindeutiger-name> --ssh --accept-routes
```

Das öffnet den Browser zur Re-Auth, und Tailscale weist dem Gerät einen
sauberen NodeKey + eine eindeutige IP zu. **Tier-3** — geht nur am Gerät
selbst, weil Browser-Auth gefordert ist.

### §7.2 MagicDNS löst nicht auf

**Symptom:** `cluster-mini-02.piranha-marlin.ts.net` antwortet nicht, IP geht.

**Fix:**
1. Tailscale-iOS-App / macOS-Tailscale-Settings → Toggle „Use Tailscale DNS"
   muss an sein.
2. macOS: `tailscale set --accept-dns=true`
3. iOS: in der App den Toggle einmal aus + an, oder Tailnet ab+wieder anschalten.

Im aktuellen Setting funktioniert MagicDNS auf dem iPad korrekt; auf
`cluster-mini-02` löst die Bash-`dscacheutil` keine MagicDNS-Hosts auf —
das ist ein bekannter macOS-DNS-Cache-Bug, der iPad-Funktionalität ist
davon nicht betroffen.

### §7.3 Latenz hoch (>200 ms) trotz „direct"

**Symptom:** `tailscale ping` zeigt direkte Verbindung, aber Lag.

**Mögliche Ursachen:**
- WLAN-Roaming (Mac wechselt zwischen 2.4 GHz und 5 GHz) — nichts mit
  Tailscale zu tun.
- Carrier-Mobilfunk-Routing über entfernte Knoten — der DERP-Latenz-Report
  hilft (`tailscale netcheck`).
- Gerät hängt im Standby — `caffeinate -i` für Dauerläufer.

### §7.4 Connection failed nach OS-Update

**Symptom:** Nach iOS-/macOS-Update läuft Tailscale nicht mehr.

**Fix:** App komplett neustarten, ggf. einmal aus dem Tailnet aus- und
wieder einloggen. Bei macOS gelegentlich:
`sudo launchctl kickstart -k system/com.tailscale.tailscaled`.

---

## Teil 8 — Checkliste für deinen Alltag

| Frage | Antwort | Quelle |
|---|---|---|
| Wo sehe ich, welche Geräte gerade online sind? | `tailscale status` oder Admin-Konsole | §4.1 |
| Wie verbinde ich mein iPad zum Mac-Bildschirm? | Jump Desktop, manuelle VNC-Konfig auf `100.127.125.48:5900` | `Cortex & Nexus / 10` |
| Wie hole ich von unterwegs einen Datei vom Home-Mac? | `tailscale file cp` oder via SSH `scp cluster-mini-02:foo .` | §4.1 |
| Wie nehme ich ein neues Gerät auf? | Tailscale-Client + Apple-ID-Login + `tailscale up` | §4.2, Modul 09 |
| Wie sehe ich, ob ein Mac schläft? | `tailscale status` → Status-Spalte | §3.2 |
| Was passiert, wenn mein Internet ausfällt? | Mesh ist tot, alles im LAN funktioniert weiter | §1.1 |
| Was passiert bei Apple-ID-Verlust? | Tailnet weg, neu aufbauen | §6.3 |
| Wo finde ich Setup-Schritte für ein neues Gerät? | Modul 09 dieser Domain | – |

---

## Teil 9 — Referenzen

- **Modul 09** — `09-cortex-mesh-tailscale.md` — Setup-Cookbook der drei Macs
- **Modul 10** — `10-remote-zugriff-local-dev.md` — Remote auf lokale WP-Dev-Site
- **Cortex & Nexus / 10** — `Cortex & Nexus/10-ipad-remote-desktop.md` — iPad → Mac
- **Geräte-Registry** — `Nexus/.config/devices.json` — Quelle der Wahrheit für IPs/Roles
- **Tailscale-Doku** — <https://tailscale.com/kb>
- **WireGuard-Whitepaper** — <https://www.wireguard.com/papers/wireguard.pdf>
- **Headscale (Open-Source-Coord-Server)** — <https://github.com/juanfont/headscale>

---

*Stand 2026-05-10 — Live-Snapshot des Tailnets unter `7vwcqsnty6@privaterelay.appleid.com`.
Bei Veränderungen am Mesh dieses Tutorial mitziehen (insbesondere §3.2 Devices-Tabelle).*
