#!/bin/bash

# Netzwerkanalyse-Skript für Homelab Cluster
# Version: 0.1
# Datum: 2026-03-08
# Zweck: Vollständige Analyse des bestehenden Heimnetzwerks

set -e

echo "=========================================="
echo "NETZWERKANALYSE - HOMELAB CLUSTER"
echo "Version 0.1"
echo "=========================================="
echo ""

# Farben für Ausgabe
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Prüfe ob nmap installiert ist
if ! command -v nmap &> /dev/null; then
    echo -e "${YELLOW}Warnung: nmap ist nicht installiert.${NC}"
    echo "Installation auf macOS: brew install nmap"
    echo ""
fi

# Prüfe ob arp-scan installiert ist
if ! command -v arp-scan &> /dev/null; then
    echo -e "${YELLOW}Hinweis: arp-scan ist nicht installiert (optional).${NC}"
    echo "Installation auf macOS: brew install arp-scan"
    echo ""
fi

# Netzwerk-Interface ermitteln
echo -e "${BLUE}[1/6] Netzwerk-Interface ermitteln${NC}"
echo "----------------------------------------"
INTERFACE=$(route get default | grep interface | awk '{print $2}')
echo "Standard-Interface: $INTERFACE"
echo ""

# Aktuelle IP-Konfiguration
echo -e "${BLUE}[2/6] Aktuelle IP-Konfiguration${NC}"
echo "----------------------------------------"
ifconfig $INTERFACE | grep -E "inet |netmask |broadcast " || ipconfig getifaddr $INTERFACE
echo ""

# Gateway ermitteln
echo -e "${BLUE}[3/6] Gateway ermitteln${NC}"
echo "----------------------------------------"
GATEWAY=$(route -n get default | grep gateway | awk '{print $2}')
echo "Gateway: $GATEWAY"
echo ""

# Subnetz ermitteln
echo -e "${BLUE}[4/6] Subnetz ermitteln${NC}"
echo "----------------------------------------"
SUBNET=$(ipconfig getoption $INTERFACE subnet_mask 2>/dev/null || echo "255.255.255.0")
NETWORK=$(ipconfig getoption $INTERFACE router 2>/dev/null | sed 's/\.[0-9]*$/\.0/')
echo "Subnetz: $NETWORK/24 (angenommen)"
echo ""

# DNS-Server ermitteln
echo -e "${BLUE}[5/6] DNS-Server ermitteln${NC}"
echo "----------------------------------------"
scutil --dns | grep "nameserver\[0\]" | head -2
echo ""

# Netzwerkscan durchführen
echo -e "${BLUE}[6/6] Netzwerkscan durchführen${NC}"
echo "----------------------------------------"
echo "Dies kann einige Minuten dauern..."
echo ""

if command -v nmap &> /dev/null; then
    echo "Scanning 192.168.178.0/24..."
    echo ""
    nmap -sn 192.168.178.0/24 | grep -E "Nmap scan report|MAC Address" | head -40
    echo ""
    echo -e "${GREEN}Detaillierter Scan des Gateways:${NC}"
    nmap -A $GATEWAY
else
    echo -e "${YELLOW}nmap nicht verfügbar. Verwende ping-Scan...${NC}"
    for i in {1..254}; do
        ping -c 1 -W 1000 192.168.178.$i > /dev/null 2>&1 && echo "192.168.178.$i ist erreichbar" || true
    done
fi

echo ""
echo "=========================================="
echo -e "${GREEN}Netzwerkanalyse abgeschlossen${NC}"
echo "=========================================="
echo ""
echo "Nächste Schritte:"
echo "1. Ergebnisse dokumentieren"
echo "2. Unbekannte Geräte identifizieren"
echo "3. Hardware-Spezifikationen erfassen"
echo "4. DHCP-Bereich in FRITZ!Box prüfen"
