# Schichtenmodell und Webhosting — Tutorial

> **Stand:** 2026-05-04
> **Anlass:** Sprint-1 Praxis-Webseite (`westend-hausarzt.de`/`.com`) auf
> Domainfactory-Hosting — Tag, an dem ein Apache-Bug uns gestoppt hat.
> Aus dieser Stolperstelle entstand dieses Tutorial.
> **Zielgruppe:** Dr. Stracke — Arzt, kein IT-Experte. Erklärungen
> mit medizinischen Analogien wo möglich.

---

## Inhalt

1. [Warum Schichtenmodell?](#warum-schichtenmodell)
2. [Die OSI-7-Schichten — Übersicht](#die-osi-7-schichten--übersicht)
3. [Schicht 1+2 — Wie das Internet zur Praxis kommt](#schicht-12--wie-das-internet-zur-praxis-kommt)
4. [Schicht 3 — IP-Adressen, DNS, Domain-Auflösung](#schicht-3--ip-adressen-dns-domain-auflösung)
5. [Schicht 4 — TCP, UDP, Ports](#schicht-4--tcp-udp-ports)
6. [Schicht 5+6 — Verschlüsselung, TLS, SSL](#schicht-56--verschlüsselung-tls-ssl)
7. [Schicht 7 — HTTP/HTTPS, FTP, SFTP, FTPS](#schicht-7--http-ftp-sftp-ftps)
8. [Webserver Apache und seine Welt](#webserver-apache-und-seine-welt)
9. [Domains, Subdomains, Add-on-Domains](#domains-subdomains-add-on-domains)
10. [cPanel und das Verhältnis zum DF-Kundencenter](#cpanel-und-das-verhältnis-zum-df-kundencenter)
11. [Der WordPress-Stack](#der-wordpress-stack)
12. [Diagnose-Werkzeuge auf der Kommandozeile](#diagnose-werkzeuge-auf-der-kommandozeile)
13. [Praxis-Fall 2026-05-04 — Schritt für Schritt](#praxis-fall-2026-05-04--schritt-für-schritt)
14. [Sicherheits-Konzepte](#sicherheits-konzepte)

---

## Warum Schichtenmodell?

Sie kennen das Prinzip aus der Medizin: ein Patient ist nicht **eine** Sache,
sondern Schichten — Genom, Zellen, Gewebe, Organe, Systeme, Verhalten.
Wenn etwas schief geht, fragen Sie sich: **auf welcher Ebene?** Ein Husten
kann von der Schleimhaut kommen (Bronchitis), vom Herzen (Linksherzinsuffizienz),
oder von einem Medikament (ACE-Hemmer). Erst die Schichten-Diagnose führt
zum richtigen Eingriff.

Ein Computer-Netzwerk funktioniert exakt so. Wenn eine Webseite nicht
erreichbar ist, kann das auf **sieben unterschiedlichen Ebenen** liegen.
Wer nicht weiß, auf welcher Schicht sein Problem sitzt, probiert blind alles —
genau das ist uns heute mit der `westend-hausarzt.de` passiert.

Das **OSI-Schichtenmodell** (Open Systems Interconnection, 1984 standardisiert)
zerlegt jede Netzwerk-Kommunikation in 7 Schichten. Jede Schicht hat eine
klare Aufgabe und kommuniziert nur mit der direkt darüber- und darunterliegenden.
Das ist Anatomie für Netzwerke.

In der Praxis (vor allem im Internet) wird das vereinfachte
**TCP/IP-Modell mit 4 Schichten** verwendet. Es ist OSI-Schichten 1+2, 3, 4
und 5+6+7 zusammengefasst. Beide Modelle beschreiben dasselbe — OSI ist
didaktischer, TCP/IP ist praxisnäher.

---

## Die OSI-7-Schichten — Übersicht

| # | Name | Was sie tut | Beispiele |
|---|---|---|---|
| **7** | Anwendung | Was Ihr Programm sieht | HTTP, HTTPS, FTP, SFTP, SMTP, DNS |
| **6** | Darstellung | Datenformate, Verschlüsselung | TLS, Zeichensätze (UTF-8) |
| **5** | Sitzung | Verbindungs-Lebenszyklus | TLS-Handshake, FTP-Sessions |
| **4** | Transport | Pakete von A nach B, Ports | TCP, UDP |
| **3** | Vermittlung | IP-Adressen, Wegfindung | IP, Routing, DNS-Auflösung |
| **2** | Sicherung | Datenübertragung am Kabel | Ethernet, WLAN-Frames |
| **1** | Bitübertragung | Elektrische Signale | Kupferkabel, Glasfaser, Funk |

**Merksatz** für die Reihenfolge von oben nach unten:
**A**lle **D**eutschen **S**chweine **T**rinken **V**iel **S**chöne**B**ier
(Anwendung — Darstellung — Sitzung — Transport — Vermittlung — Sicherung — Bitübertragung)

In den folgenden Kapiteln gehe ich Schicht für Schicht durch und zeige,
**wo unsere heutigen Probleme tatsächlich saßen**.

---

## Schicht 1+2 — Wie das Internet zur Praxis kommt

**Schicht 1 (Bitübertragung):** Hier fließen tatsächlich Strom oder Lichtimpulse
durch ein Kabel. Wenn das Kabel rausgezogen wird, gibt es keine Schicht-7-Anwendung,
egal wie sauber Apache konfiguriert ist.

**Schicht 2 (Sicherung):** Sorgt dafür, dass die Bits am direkten Nachbarn
ankommen. Auf dieser Schicht hat jedes Gerät eine **MAC-Adresse**
(z.B. `aa:bb:cc:11:22:33`), eine ab Werk eingebrannte Hardware-Adresse.

**Bedeutung für Sie:** Schichten 1 und 2 funktionieren, sobald Ihr Mac
WLAN/Ethernet hat. Diese Schichten waren heute **nicht** das Problem — wir
haben mit dem Server gesprochen, also liefen die unteren Schichten.

---

## Schicht 3 — IP-Adressen, DNS, Domain-Auflösung

### IP-Adressen

Jedes Gerät im Internet hat eine **IP-Adresse** (Internet Protocol).
Zwei Versionen:

- **IPv4** wie `92.204.31.125` — vier Zahlen 0–255 mit Punkten getrennt.
  4,3 Milliarden mögliche Adressen, mittlerweile knapp.
- **IPv6** wie `2a02:1234:5678::1` — länger, hexadezimal, praktisch unendlich
  viele Adressen.

Eine IP-Adresse identifiziert **einen Server** im Internet eindeutig.

### DNS — das Telefonbuch des Internets

Niemand merkt sich `92.204.31.125`. Wir tippen `westend-hausarzt.de`. Die
Übersetzung erledigt **DNS** (Domain Name System).

**So läuft eine DNS-Auflösung**, wenn Sie `westend-hausarzt.de` im Browser eingeben:

1. Ihr Mac fragt einen **DNS-Resolver** (meist der Ihres Internet-Providers
   oder Google `8.8.8.8` oder Cloudflare `1.1.1.1`).
2. Der Resolver fragt eine Kette von Servern ab:
   - **Root-Server:** „wer kennt `.de`?"
   - **TLD-Server für `.de`:** „wer kennt `westend-hausarzt.de`?"
   - **Authoritative Server (bei DF):** „IP ist `92.204.31.125`."
3. Antwort kommt zurück, Ihr Mac speichert sie kurz im Cache und verbindet
   sich.

**Heute relevant:** Als wir testeten, ob die Domain antwortet, haben wir
beobachtet:

```
westend-hausarzt.de → 92.204.31.125
sxb1plmcpnl510251.prod.sxb1.secureserver.net → 92.205.249.252
```

Zwei verschiedene IPs. Das war das erste Indiz, dass Ihre Domain auf einem
GoDaddy/secureserver-Server liegt — selbst wenn Ihr Vertrag bei
Domainfactory ist.

### Domain-Hierarchie

Eine Domain liest man **von rechts nach links** wie eine Postanschrift:

```
westend-hausarzt.de
└─────────────┘ └──┘
   Domain      TLD
```

- **TLD** (Top-Level Domain): `.de`, `.com`, `.org`. Verwaltet von zentralen
  Stellen (DENIC für `.de`, Verisign für `.com`).
- **Domain:** der Teil, den Sie kaufen (`westend-hausarzt`).
- **Subdomain:** alles links von der Domain (`www.`, `staging.`, `mail.`).

Beispiel mit Subdomain:

```
staging.westend-hausarzt.com
└─────┘ └─────────────┘ └──┘
Subdom.    Domain      TLD
```

Subdomains kann der Domain-Inhaber **selbst** beliebig anlegen, ohne erneut
zu kaufen.

---

## Schicht 4 — TCP, UDP, Ports

Auf Schicht 3 haben wir die IP-Adresse. Aber auf einem Server laufen viele
Dienste gleichzeitig (Webserver, E-Mail-Server, Datenbank-Server). Welcher
Dienst ist gemeint?

Dafür gibt es **Ports** — Zahlen 0 bis 65535. Jeder Dienst lauscht auf einem
festen Port.

| Port | Protokoll | Wofür |
|---|---|---|
| 21 | FTP / FTPS | Dateien hochladen/herunterladen |
| 22 | SSH / SFTP | Verschlüsselter Shell-Zugriff + sicheres FTP |
| 25 | SMTP | E-Mail senden (zwischen Servern) |
| 53 | DNS | Namens-Auflösung |
| 80 | HTTP | Webseite (unverschlüsselt) |
| 110 | POP3 | E-Mail abholen (alt) |
| 143 | IMAP | E-Mail abholen (modern, unverschlüsselt) |
| 443 | HTTPS | Webseite (verschlüsselt) |
| 465 | SMTPS | E-Mail senden (verschlüsselt) |
| 587 | SMTP Submission | E-Mail senden (verschlüsselt, modern) |
| 993 | IMAPS | E-Mail abholen (verschlüsselt) |
| 3306 | MySQL | Datenbank-Zugriff |

Zwei Transport-Protokolle teilen sich diese Ports:

- **TCP** (Transmission Control Protocol) — zuverlässig, verbindungsorientiert,
  bestätigt jedes Paket. Wie ein Einschreiben mit Empfangsbestätigung.
  Wird von HTTP, FTP, SMTP genutzt.
- **UDP** (User Datagram Protocol) — schnell, ohne Bestätigung. Wie eine
  Postkarte. Wird von DNS, Online-Spielen, Video-Streaming genutzt.

**Heute relevant:** Beim FTP-Test haben wir Port 21 geprüft — er war offen
(„TCP-OK"). Damit wussten wir: ein FTP-Server lauscht. Was er **inhaltlich**
sagte, war eine Schicht-7-Frage (siehe unten).

---

## Schicht 5+6 — Verschlüsselung, TLS, SSL

### Wozu Verschlüsselung

Wenn Sie auf Schicht 7 ein Passwort oder Patientendaten verschicken, durchquert
das Paket viele Router auf Schicht 3. Jeder Router könnte mitlesen, wenn
die Daten unverschlüsselt sind.

Lösung: Auf Schicht 5/6 wird ein **verschlüsselter Tunnel** zwischen Ihrem
Browser und dem Server aufgebaut, **bevor** Schicht-7-Daten fließen.

### TLS (Transport Layer Security)

**TLS** ist der Nachfolger von **SSL** (heute beide oft synonym genannt,
„SSL-Zertifikat" meint meist TLS). Was beim Verbindungsaufbau passiert
(extrem vereinfacht):

1. Browser: „Hallo, ich bin Browser, kann TLS 1.3."
2. Server: „Hallo, hier ist mein **Zertifikat**, signiert von Let's Encrypt."
3. Browser prüft: „Ist Let's Encrypt vertrauenswürdig? Ja. Stimmt das
   Zertifikat mit `westend-hausarzt.com` überein? Ja. → Verbindung sicher."
4. Browser und Server **handeln einen Sitzungsschlüssel aus** (komplexes
   Mathematik-Verfahren, Stichwort Diffie-Hellman).
5. Ab jetzt fließen alle Daten **symmetrisch verschlüsselt** durch den Tunnel.

### Zertifikate kurz

Ein Zertifikat ist eine **digital signierte Aussage** einer
**Zertifizierungsstelle (CA)** — sie sagt: „Ich bestätige, dass der Server,
der dieses Zertifikat zeigt, wirklich `westend-hausarzt.com` ist."

Wichtigste CAs:
- **Let's Encrypt** — kostenlos, 90 Tage gültig, automatisierter Renew.
  Standard bei modernen Hostern (auch DF/cPanel).
- **DigiCert, Sectigo, GlobalSign** — kostenpflichtig, oft mit
  Extended Validation (Browser zeigte früher den Firmennamen in Grün).

**Heute relevant:** Die Live-Site `westend-hausarzt.com` hat ein Let's-Encrypt-
Zertifikat, das DF/cPanel automatisch erneuert. Bei der neu angelegten
Subdomain `staging.westend-hausarzt.com` wäre das Zertifikat ebenfalls
automatisch ausgestellt worden — wenn der Apache-Bug nicht zugeschlagen hätte.

---

## Schicht 7 — HTTP, FTP, SFTP, FTPS

Auf der obersten Schicht laufen die **Anwendungs-Protokolle**. Hier
„sprechen" Programme miteinander in fest definierten Sprachen.

### HTTP / HTTPS

**HTTP** (HyperText Transfer Protocol) ist die Sprache des Webs. Der Browser
sendet eine **Anfrage**, der Server eine **Antwort**.

Beispiel-Anfrage (was der Browser dem Server schickt):

```
GET /eye-check/ HTTP/1.1
Host: westend-hausarzt.com
User-Agent: Mozilla/5.0 (Macintosh; …) Safari/605.1.15
Accept-Language: de
```

Beispiel-Antwort (was der Server zurückschickt):

```
HTTP/2 200 OK
Content-Type: text/html; charset=UTF-8
Content-Length: 94159
Server: Apache

<!DOCTYPE html>
<html>…</html>
```

Die **Statuszeile** ganz oben (`HTTP/2 200`) ist die wichtigste Information.

### HTTP-Status-Codes — kurz erklärt

| Bereich | Bedeutung | Beispiele |
|---|---|---|
| **2xx** Erfolg | Alles gut | **200** OK · **201** Created · **204** No Content |
| **3xx** Weiterleitung | Geh woanders hin | **301** Permanent · **302** Temporär · **304** Not Modified |
| **4xx** Du hast falsch gefragt | Client-Fehler | **400** Bad Request · **401** Unauthorized · **403** Forbidden · **404** Not Found |
| **5xx** Ich kann nicht | Server-Fehler | **500** Internal Server Error · **502** Bad Gateway · **503** Service Unavailable |

**Heute relevant — die Codes, die uns begegnet sind:**

- **200** auf `westend-hausarzt.com/` → Live-Site läuft
- **301** auf `westend-hausarzt.de/` (vor unserem Eingriff) → Weiterleitung auf `.com`
- **403** Forbidden auf `westend-arzt.de/` → globale Block-Regel verbietet Zugriff
- **404** Not Found auf `juvantis.de/` → keine Standard-Seite vorhanden
- **500** Internal Server Error auf `staging.westend-hausarzt.com/` → Apache hat ein Konfigurations-Problem

**Faustregel zur Diagnose:**
- 4xx = **Sie/der Browser** hat falsch gefragt
- 5xx = **Der Server** hat ein internes Problem

### Redirects (301, 302, 307, 308)

Eine **Weiterleitung** ist eine Antwort, die sagt: „Geh stattdessen dorthin."
Der Browser folgt automatisch.

| Code | Bedeutung | Wann |
|---|---|---|
| **301** Permanent | „Diese URL ist umgezogen, für immer." | Domain-Wechsel, neuer Slug. Suchmaschinen aktualisieren ihre Indexe. |
| **302** Found | „Schau temporär dort." | Wartungsumleitung, A/B-Tests. Suchmaschinen aktualisieren NICHT. |
| **307/308** | Modernere Varianten von 302/301 | Selten manuell genutzt. |

**Heute relevant:** `westend-hausarzt.de → westend-hausarzt.com` war eine
**301** — implementiert in der cPanel-„Umleitungen"-Tabelle. Wir haben sie
gelöscht, um Platz für eine eigene Webseite zu schaffen.

### FTP-Familie (drei Protokolle, leicht zu verwechseln)

| Name | Voll | Port | Verschlüsselt | Wie |
|---|---|---|---|---|
| **FTP** | File Transfer Protocol | 21 | ❌ | Klartext, Passwort sichtbar im Klartext |
| **FTPS** | FTP über TLS | 21 (Daten oft 990 oder dynamisch) | ✅ | FTP-Befehle, aber durch TLS verschlüsselt. „Explicit FTPS" startet auf 21 unverschlüsselt und schaltet dann um. |
| **SFTP** | SSH File Transfer Protocol | 22 | ✅ | Komplett anderes Protokoll, basiert auf SSH. |

**Wichtig:** FTPS und SFTP sind **nicht dasselbe** und **nicht** miteinander
kompatibel. Werkzeuge wie `lftp` können beide. `sftp` (Kommandozeile) kann
nur SFTP.

**Heute relevant:** Die Cyberduck-Bookmark `Secure e88c2b3jxfrg.duck` zeigte
SFTP/22. Sub-Sub-User-Konten bei GoDaddy haben aber **keinen SSH-Zugang**,
also kein SFTP. Wir mussten auf **FTPS Port 21** ausweichen — das funktionierte.

### Cyberduck

**Cyberduck** ist ein freier macOS-Datei-Transfer-Client. Er kann FTP, FTPS,
SFTP, WebDAV, S3, Google Drive und vieles mehr. `.duck`-Dateien sind seine
**Bookmarks** — XML-Plists mit Hostname, Port, Protokoll, Username
(**ohne** Passwort, das liegt im macOS-Keychain).

**Praktisch bedeutet:** Wenn jemand Ihnen eine `.duck`-Datei schickt, sehen
Sie sofort die Verbindungsdaten — **ohne** das Passwort dabei zu haben.

---

## Webserver Apache und seine Welt

### Was ein Webserver tut

Ein **Webserver** (z.B. Apache, Nginx, LiteSpeed, IIS) ist ein Programm, das
auf Port 80/443 lauscht. Wenn eine HTTP-Anfrage kommt, sucht er die
gewünschte Datei auf der Festplatte und schickt sie zurück. Bei dynamischen
Anwendungen (z.B. WordPress) leitet er die Anfrage an PHP weiter, das die
Datenbank befragt und HTML produziert.

**Apache HTTPD** ist der älteste und am weitesten verbreitete Webserver
(seit 1995). Konfigurations-Datei-basiert, sehr modular, sehr verbreitet im
Shared-Hosting.

### Virtuelle Hosts (vhost)

Ein einzelner Apache-Prozess kann **viele Webseiten gleichzeitig** ausliefern.
Dazu konfiguriert man **virtuelle Hosts** — eine vhost-Konfiguration pro
Domain.

Beispiel-vhost (vereinfacht):

```apache
<VirtualHost *:443>
    ServerName westend-hausarzt.com
    ServerAlias www.westend-hausarzt.com
    DocumentRoot /home/e88c2b3jxfrg/praxis2021
    SSLCertificateFile /etc/letsencrypt/live/.../cert.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/.../privkey.pem
</VirtualHost>

<VirtualHost *:443>
    ServerName staging.westend-hausarzt.com
    DocumentRoot /home/e88c2b3jxfrg/public_html/staging.westend-hausarzt.com
    …
</VirtualHost>
```

Apache schaut beim eingehenden HTTPS-Request auf den **Host-Header** (siehe
HTTP-Anfrage oben) und entscheidet, welcher vhost zuständig ist.

**Heute relevant:** Bei der neu angelegten Subdomain wurde der vhost zwar
in der cPanel-Datenbank eingetragen, aber Apaches generierte
Konfigurationsdatei produzierte **HTTP 500** — entweder weil der vhost
selbst kaputt geschrieben wurde, oder weil eine **globale `.htaccess`-Regel**
in den vhost zog und dort ein Problem auslöste.

### `.htaccess` — Apache lokal überstimmen

Eine `.htaccess` ist eine **Konfigurationsdatei pro Verzeichnis**. Sie kann
viele Apache-Direktiven enthalten:

```apache
RewriteEngine On
RewriteRule ^old-page/?$ /new-page [R=301,L]
ErrorDocument 404 /not-found.html
DirectoryIndex index.html index.php
Options -Indexes
```

Apache-Admins können `AllowOverride` setzen, um zu steuern, **welche**
Direktiven in einer `.htaccess` erlaubt sind. Wenn `AllowOverride None`,
werden `.htaccess`-Dateien komplett ignoriert.

**Heute relevant:** Wir haben versucht, die globale Block-Regel (die alle
URLs mit Punkt im Pfad blockt) mit einer eigenen `.htaccess` zu überschreiben.
Hat nicht funktioniert. Mögliche Gründe:
- Globale Regel ist auf Server-Ebene gesetzt, nicht in `.htaccess` (dann
  hilft keine lokale Datei).
- Oder: `AllowOverride` auf dem Server lässt die nötige Direktive nicht zu.

### `mod_rewrite` — URLs umschreiben

Apache-Modul, das URLs **on the fly** umschreiben kann. Beispiel: WordPress
braucht das, um aus `/eye-check/` intern `/index.php?p=42` zu machen.

Beispielregel:

```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
```

**Lesart:** „Wenn die angefragte Datei nicht existiert UND kein Verzeichnis
ist, dann leite intern auf `/index.php` um."

Genau das ist die WordPress-Standard-Regel.

---

## Domains, Subdomains, Add-on-Domains

Bei Shared-Hosting (cPanel) gibt es drei Domain-Konzepte, die leicht zu
verwechseln sind:

| Typ | Beispiel | Document-Root | Eigenes Webspace? |
|---|---|---|---|
| **Hauptdomain** | `westend-hausarzt.com` | `/home/.../public_html` (Standard) | Ja, das Hauptverzeichnis |
| **Subdomain** | `staging.westend-hausarzt.com` | beliebig (oft `/home/.../public_html/staging`) | Eigener Ordner unter dem Account |
| **Add-on-Domain** | `westend-hausarzt.de` (eine zweite, eigenständige Domain auf demselben Account) | beliebig | Ja, eigener Ordner |
| **Domain-Alias / Parked** | `westendhausarzt.de` | identisch mit Hauptdomain | Nein, zeigt einfach denselben Inhalt |

**Add-on vs. Subdomain technisch:**
- Beides erzeugt einen Apache-vhost.
- Subdomains hängen am DNS der Hauptdomain (kein separater Domain-Kauf nötig).
- Add-on-Domains sind eigenständig registrierte Domains, die zusätzlich auf
  diesem Account gehostet werden. Sie brauchen eigene DNS-Einträge.

**Heute relevant:** Wir haben **beide** Wege probiert:
1. Add-on-Domain (`westend-hausarzt.de`) — Document-Root umgebogen → Apache 500.
2. Subdomain (`staging.westend-hausarzt.com`) — neu angelegt → Apache 500.

Beide Wege haben dasselbe Symptom geworfen, was darauf hindeutet, dass das
Problem **nicht** am Domain-Typ liegt, sondern systemisch (globale
Block-Regel oder vhost-Generierungs-Bug).

---

## cPanel und das Verhältnis zum DF-Kundencenter

Sie haben heute zwei Verwaltungs-Oberflächen erlebt — beide gehören zu
demselben Hosting-Vertrag, machen aber unterschiedliche Dinge:

### DF-Kundencenter (`admin.df.eu`)

Die **kaufmännische Oberfläche** Ihres Vertrags.
- Vertragsdetails, Rechnungen, SEPA-Mandate
- Domain-Buchungen (Neukauf, Verlängerung, Transfer)
- Account-Stammdaten
- Support-Tickets

**Faustregel:** Was mit Geld zu tun hat, läuft im DF-Kundencenter.

### cPanel (auf `secureserver.net`-Subdomain)

Die **technische Oberfläche** Ihres Webspaces.
- FTP-Konten, MySQL-Datenbanken, E-Mail-Konten
- Domain-Konfiguration auf dem Webserver (Document-Roots, Subdomains, Aliase)
- Datei-Manager
- Cron-Jobs, Backups, Statistiken
- SSL-Zertifikate, DNS-Zonen

**Faustregel:** Was mit Server-Konfiguration zu tun hat, läuft im cPanel.

### Wieso `secureserver.net`?

Domainfactory wurde 2020 von **GoDaddy** übernommen. GoDaddys eigene
Hosting-Plattform läuft auf Servern mit dem internen Hostnamen
`*.secureserver.net`. Wenn Sie sich im DF-Kundencenter auf cPanel klicken,
werden Sie technisch auf einen GoDaddy-Server weitergeleitet, der das
cPanel-Tooling bereitstellt. Vertraglich bleibt es DF, technisch ist es GoDaddy.

**Heute relevant:** Diese Trennung hat uns am Anfang Zeit gekostet — der
Sprint-1-Plan ging davon aus, dass FTP-Zugänge im DF-Kundencenter zu finden
sind. Sind sie aber nicht. Sie sind **im cPanel**. Klare Lehre:
*Server-Tooling immer im cPanel suchen.*

---

## Der WordPress-Stack

Eine moderne WordPress-Webseite besteht aus **vier Komponenten**, die
zusammenspielen:

```
   ┌────────────────────────┐
   │       Browser          │   ← Schicht 7
   └───────────┬────────────┘
               │ HTTPS (Schicht 7)
   ┌───────────▼────────────┐
   │       Apache           │   ← Schicht 7 (Webserver)
   │       (Port 443)       │
   └───────────┬────────────┘
               │
   ┌───────────▼────────────┐
   │         PHP            │   ← interpretiert .php-Dateien
   │  (WordPress-Code)      │
   └───────────┬────────────┘
               │ MySQL-Protokoll (Port 3306)
   ┌───────────▼────────────┐
   │       MySQL            │   ← Datenbank
   │  (Posts, Settings)     │
   └────────────────────────┘
```

- **Apache** empfängt die HTTPS-Anfrage und entscheidet: HTML-Datei direkt
  ausliefern oder PHP-Datei interpretieren lassen.
- **PHP** liest die `.php`-Datei (z.B. WordPress-Core), führt den Code aus,
  fragt die Datenbank an und produziert HTML.
- **MySQL** speichert Inhalte (Posts, Pages), Einstellungen, Benutzer.
- **Browser** bekommt das fertige HTML zurück.

### Wichtige WordPress-Dateien

| Datei | Inhalt |
|---|---|
| `wp-config.php` | Datenbank-Zugang, Sicherheits-Schlüssel — **streng vertraulich!** |
| `wp-content/themes/` | Layout-Dateien |
| `wp-content/plugins/` | Erweiterungen |
| `wp-content/uploads/` | Hochgeladene Bilder |
| `.htaccess` | Apache-Regeln (Pretty URLs, Security) |

### WPML — Multi-Language

Plugin, das WordPress mehrsprachig macht. Jeder Post hat Versionen pro
Sprache, die über `?lang=` oder Subverzeichnis (`/en/`) erreichbar sind.

Heute haben wir gesehen, dass die Live-Site WPML 4.9.2 mit Stringtranslation,
Media-Translation, Import-Plugin nutzt. Mit dem geplanten Theme-Wechsel
muss WPML **mit umgezogen** werden — die DB-Einträge (Sprach-Zuordnungen)
sind wertvoll.

---

## Diagnose-Werkzeuge auf der Kommandozeile

Wenn etwas nicht funktioniert, sind diese Werkzeuge Ihre Stethoskope.
Alle laufen im Mac-Terminal.

### `ping` — antwortet der Server überhaupt?

```bash
ping westend-hausarzt.com
```

Schickt kleine Pakete und misst die Antwortzeit. Wenn keine Antwort kommt,
ist Schicht 1–3 unterbrochen.

### `dig` / `nslookup` — DNS prüfen

```bash
dig westend-hausarzt.de A
```

Zeigt, welche IP-Adresse für die Domain hinterlegt ist. Hilfreich, um zu
sehen, ob ein DNS-Eintrag stimmt oder gerade gewechselt wurde.

### `curl` — HTTP-Anfragen senden

```bash
curl -I https://westend-hausarzt.com/
```

`-I` zeigt nur die HTTP-Header (Statuscode + Metadaten), keinen Inhalt.
Perfekt, um zu sehen: 200? 301? 500?

```bash
curl -L https://westend-arzt.de/
```

`-L` folgt Redirects automatisch.

### `nc` (netcat) — ist ein Port offen?

```bash
nc -vz westend-hausarzt.de 443
```

Sagt: „Verbindung erfolgreich" oder „Verbindung verweigert". Schicht-4-Test.

### `lftp` / `sftp` — Datei-Transfer

```bash
sftp benutzer@server.example
lftp -u user,pass ftps://server.example
```

Interaktive FTP/SFTP-Sessions auf der Kommandozeile.

### Schichten-Diagnose-Reihenfolge

Wenn eine Webseite nicht erreichbar ist, gehe ich (und Sie ab heute) so vor:

1. `ping` → kommt Antwort? (Schicht 1–3)
2. `dig` → stimmt die DNS-IP? (Schicht 3)
3. `nc -vz host 443` → ist Port 443 offen? (Schicht 4)
4. `curl -I https://host/` → was sagt der Webserver? (Schicht 7)
5. Statuscode interpretieren — 4xx vs. 5xx → wo der Hund begraben liegt.

---

## Praxis-Fall 2026-05-04 — Schritt für Schritt

Jetzt durchdeklinieren wir den heutigen Fall mit dem Schichtenmodell als
Brille. So sehen Sie genau, **wo welche Aktion welche Schicht betraf**.

### Phase 0 — Ausgangslage

| Was | Wo | Schicht |
|---|---|---|
| `westend-hausarzt.com` lieferte 200 OK (Live-Praxis-Webseite) | praxis2021/ Ordner | 7 (HTTP) |
| `westend-hausarzt.de` lieferte 301 → `.com` | cPanel-Umleitung | 7 (HTTP) |
| Alle anderen Westend-Varianten ebenfalls 301 | cPanel-Umleitungen | 7 |

### Phase 1 — FTP-Zugang klären

Wir suchten den FTP-Server-Hostnamen. Cyberduck-Bookmark zeigte
`ftp.df-393047.dummy` — keine echte DNS-Adresse (Schicht 3 würde fehlschlagen).
Test:

```
TCP-Connect zu westend-hausarzt.de:21 → OK
TCP-Connect zu sxb1plmcpnl510251...secureserver.net:21 → OK
```

Beide antworteten auf Schicht 4. Damit wussten wir: der echte FTP-Hostname
ist `westend-hausarzt.de`.

### Phase 2 — User + Protokoll

Erster Login-Versuch mit User `e88c2b3jxfrg` über SFTP/22 → fehlgeschlagen.
Hypothese: Sub-User haben keinen SSH-Zugang. Test mit User `393047-ftp`
über FTPS/21 → **funktionierte**.

**Schichten-Interpretation:**
- Schicht 4 (Port) hat geklappt — Port 21 war offen.
- Schicht 5/6 (TLS) hat geklappt — `ssl-force true` hat funktioniert.
- Schicht 7 (FTP-Login) hat erst nach User-Wechsel funktioniert.

### Phase 3 — Webspace-Struktur entdeckt

Per FTP haben wir gelistet:

```
/home/e88c2b3jxfrg/
├── praxis2021/          ← LIVE westend-hausarzt.com
├── public_html/          ← leer (cgi-bin nur)
├── redirects/            ← Stub-Dokumentenstämme der 301-Domains
├── Juvantis/, Medzpoint/, …
└── …
```

WordPress lebt in `praxis2021/`, nicht im Standard-`public_html/`. Das ist
eine cPanel-Konfigurations-Eigenheit auf Ebene **vhost** — nichts mit den
Schichten 1–6 zu tun.

### Phase 4 — Versuch 1: `westend-hausarzt.de`

Plan: Weiterleitung löschen + Document-Root von `redirects/...` auf eigenen
Ordner umbiegen + WordPress hochladen.

Was passiert ist:

| Schritt | Schicht | Resultat |
|---|---|---|
| 301-Umleitung im cPanel gelöscht | 7 (Apache-Konfig) | ✅ Domain antwortete dann mit 403 |
| Document-Root umgebogen | 7 (vhost) | ❌ Domain antwortete plötzlich mit 500 |

Der Wechsel von 403 zu 500 zeigte: durch das vhost-Update wurde **etwas
zerschossen**. Apache versuchte ein Error-Document zu rendern und scheiterte.

### Phase 5 — Versuch 2: Subdomain `staging.westend-hausarzt.com`

Identisches Symptom — frisch angelegte Subdomain → 500. Damit war klar:
**das Problem ist nicht domain-spezifisch**, sondern triggert bei **jeder**
neu erstellten/geänderten vhost-Konfiguration auf diesem Account.

### Phase 6 — Versuch 3: `westend-arzt.de`

Bewusst KEIN Document-Root-Switch, nur Umleitung gelöscht. Resultat: 403
(stabil). Eigene `.htaccess` mit `RewriteEngine on` + Override-Rules
hochgeladen. Resultat: weiterhin 403.

**Diagnose-Erkenntnis:** Die globale 403-Regel
`^/(?!\.well-known/)(.*)?\.+` ist auf einer Ebene gesetzt, die unsere
lokale `.htaccess` nicht überschreiben darf — wahrscheinlich
`AllowOverride None` für die nötige Direktive, oder die Regel ist
gar nicht in `.htaccess`, sondern im server-globalen Apache-Config.

### Phase 7 — Schluss

Wir konnten den Server-seitigen Block aus FTP-Sicht nicht umgehen.
Ticket an DF-Support gestellt.

### Lehren aus dem Fall

1. **Schichten-Diagnose von unten nach oben.** Wir hätten in Phase 4 sofort
   prüfen können, ob andere unbearbeitete Domains 403 zeigen — dann wäre
   die globale Regel früher als Verdacht aufgekommen.
2. **Eine `.htaccess` ist nicht allmächtig.** Sie kann nur, was der Server
   ihr erlaubt. Bei Shared-Hosting ist `AllowOverride` oft restriktiv.
3. **cPanel ist nicht Apache.** Die cPanel-Oberfläche zeigt eine Abstraktion;
   die echte Wahrheit liegt in den Apache-Logs, an die wir als FTP-User
   nicht herankommen.
4. **Bei Hoster-Bugs: Support, nicht Heroismus.** 30 Minuten erfolglose
   Eigentherapie sind teurer als ein Ticket.

---

## Sicherheits-Konzepte

### Permissions (Unix-Dateirechte)

Jede Datei und jeder Ordner hat **drei Rechte-Gruppen**:

```
-rw-r--r-- 1 user group 848 Mai 4 21:05 index.html
 ↑ ↑↑↑ ↑↑↑ ↑↑↑
 │ │   │   └─ andere (alle Welt) — read only
 │ │   └─ Gruppe                  — read only
 │ └─ Eigentümer                  — read + write
 └─ Datei-Typ (- = Datei, d = Verzeichnis, l = Symlink)
```

In oktaler Schreibweise: `644` für Dateien, `755` für Verzeichnisse.

| Octal | Symbolisch | Bedeutung |
|---|---|---|
| 4 | r-- | Lesen |
| 2 | -w- | Schreiben |
| 1 | --x | Ausführen / Verzeichnis betreten |
| 7 | rwx | Alles |
| 6 | rw- | Lesen + Schreiben |
| 5 | r-x | Lesen + Ausführen |

**Standard für Web-Dateien:**
- Verzeichnisse: 755 (alle lesen, nur Eigentümer schreiben)
- Dateien: 644 (alle lesen, nur Eigentümer schreiben)
- Niemals: 777 (alle dürfen alles → Sicherheitsalbtraum)

### Basic-Auth

Eine Apache-Funktion, die ein **Browser-Login-Fenster** vor eine Webseite
setzt. Konfiguriert via `.htaccess` + `.htpasswd`-Datei mit verschlüsselten
Passwörtern.

```apache
AuthType Basic
AuthName "Staging — bitte einloggen"
AuthUserFile /home/user/.htpasswd
Require valid-user
```

**Vorteil:** Funktioniert sofort, kein Plugin nötig. Schützt Staging-Sites
zuverlässig vor zufälligen Besuchern.
**Nachteil:** Das Passwort wird bei jedem Request mitgesendet (verschlüsselt
durch HTTPS), aber leicht zu vergessen für ehrlichen Zugang.

### `robots.txt` und `noindex`

| Methode | Wirkung |
|---|---|
| `robots.txt` mit `Disallow: /` | Bittet Suchmaschinen, nichts zu crawlen — **freiwilliger** Standard |
| `<meta name="robots" content="noindex,nofollow">` | Bittet Suchmaschinen, die Seite nicht in den Index aufzunehmen |
| Basic-Auth davor | **Erzwingt** den Schutz, weil Crawler nicht hinter den Login kommen |

**Empfehlung für Staging:** alle drei kombiniert.

### Secrets-Handling — Wichtige Regel

Aus dem heutigen Verlauf: **niemals Admin-Passwörter in Konfigurationsdateien
abspeichern**, die in einem Repository landen könnten. Stattdessen:
- App-Passwords (für Tools/Scripts) — pro Anwendungsfall ein eigenes,
  jederzeit widerrufbar
- Zugänge in `.env*`-Dateien, die durch `.gitignore` ausgeschlossen sind
- Bei Sonderzeichen: Werte in **einfache Anführungszeichen** setzen,
  damit Bash sie korrekt liest

---

## Glossar — die wichtigsten Begriffe in einer Tabelle

| Begriff | In einem Satz |
|---|---|
| **Apache** | Webserver-Programm, das Webseiten ausliefert. |
| **Add-on-Domain** | Eine zusätzliche, eigenständig registrierte Domain, die auf demselben Hosting-Account liegt. |
| **Basic-Auth** | Browser-Login-Fenster vor einer Webseite (Apache-Feature). |
| **cPanel** | Web-Oberfläche zur Verwaltung von Shared-Hosting (Domains, FTP, DB, E-Mail). |
| **DNS** | „Telefonbuch des Internets" — übersetzt Domainnamen in IP-Adressen. |
| **Document-Root** | Der Verzeichnis-Pfad auf dem Server, in dem die Dateien einer Domain liegen. |
| **Domainfactory (DF)** | Hosting-Anbieter, seit 2020 zu GoDaddy. Vertragsoberfläche `admin.df.eu`. |
| **FTP / FTPS / SFTP** | Drei Dateiübertragungs-Protokolle. FTP unverschlüsselt, FTPS = FTP + TLS, SFTP = über SSH. |
| **HTTP / HTTPS** | Web-Protokoll. HTTP unverschlüsselt (Port 80), HTTPS verschlüsselt (Port 443). |
| **`.htaccess`** | Apache-Konfigurations-Datei pro Verzeichnis. Kann Regeln für URL-Rewriting, Zugriffsschutz etc. enthalten. |
| **IP-Adresse** | Eindeutige Server-Adresse im Internet (z.B. `92.204.31.125`). |
| **Let's Encrypt** | Kostenlose SSL/TLS-Zertifikate. Standard auf modernen Hostern. |
| **Port** | Nummer 0-65535, identifiziert einen Dienst auf einem Server. |
| **Permissions / chmod** | Unix-Dateirechte (lesen/schreiben/ausführen × Eigentümer/Gruppe/andere). |
| **Redirect 301** | Permanente HTTP-Weiterleitung. Sucht-Index folgt mit. |
| **Subdomain** | Etwas vor der Hauptdomain (z.B. `staging.example.com`). Kein neuer Domain-Kauf nötig. |
| **TLS / SSL** | Verschlüsselungs-Protokolle für sichere Verbindungen. TLS ist der Nachfolger von SSL. |
| **TCP / UDP** | Transport-Protokolle. TCP zuverlässig, UDP schnell. |
| **vhost** | „Virtual Host" — Apache-Konfiguration für eine Domain. |
| **WPML** | WordPress-Plugin für Multi-Language-Sites. |
| **WordPress** | Content-Management-System auf PHP+MySQL-Basis. |

---

*Anlage:* Eine eigene Datei `EXIT-SOLUTION-HOSTING.md` enthält den
Plan B/C/D, falls der DF-Support zu lange braucht.

*Cross-References:*
- `09-cortex-mesh-tailscale.md` — wie Tailscale ein eigenes „Schicht-3-Internet"
  zwischen Ihren Geräten baut
- `10-remote-zugriff-local-dev.md` — wie Sie Ihre lokale WordPress-Installation
  öffentlich erreichbar machen können (relevant für die Exit-Solution)
