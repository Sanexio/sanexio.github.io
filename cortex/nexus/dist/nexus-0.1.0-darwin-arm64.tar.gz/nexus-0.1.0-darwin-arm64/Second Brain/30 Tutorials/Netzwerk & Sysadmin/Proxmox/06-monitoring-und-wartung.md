# Proxmox Tutorial 06 — Monitoring und Wartung

> **Voraussetzungen:** 01 bis 05
> **Ziel:** Server überwachen, Probleme frühzeitig erkennen, regelmäßige Wartung.

---

## Warum Monitoring?

Ein Server, der nicht überwacht wird, fällt erst auf, wenn er ausfällt.
Monitoring erkennt Probleme **bevor** sie kritisch werden:

- Festplatte voll → Backup schlägt fehl → Datenverlust
- RAM-Auslastung steigt → VMs werden langsam → Praxis-Software hängt
- CPU-Temperatur zu hoch → Thermal Throttling → Performance-Einbruch
- Netzwerk-Fehler → Pakete gehen verloren → Verbindungsabbrüche

## Eingebautes Proxmox-Monitoring

### Dashboard (Web-Interface)

Das einfachste Monitoring: Klicke auf den Node oder eine VM und schaue dir
den **Summary** Tab an. Dort siehst du:

- CPU-Auslastung (%)
- RAM-Belegung (GB / %)
- Storage-Belegung
- Netzwerk-Traffic
- Uptime (wie lange läuft der Server schon)

### Wichtige Kennzahlen und Schwellenwerte

| Kennzahl | Normal | Warnung | Kritisch |
|----------|--------|---------|----------|
| CPU-Auslastung | < 60% | 60-80% | > 80% dauerhaft |
| RAM-Belegung | < 70% | 70-85% | > 85% |
| Storage-Belegung | < 70% | 70-85% | > 85% (bei ZFS: > 80%) |
| CPU-Temperatur | < 70°C | 70-80°C | > 80°C |
| Netzwerk-Fehler | 0 | > 0 | Steigend |

## Erweiteres Monitoring mit Grafana

Für professionelles Monitoring kann man Grafana + Prometheus einrichten —
das gleiche System, das auch für das SmartQ-Dashboard der Praxis genutzt wird.

### Architektur

```
Proxmox-Node → Prometheus Exporter → Prometheus → Grafana
                (sammelt Metriken)    (speichert)  (visualisiert)
```

Der Prometheus-Exporter für Proxmox heißt `pve-exporter` und liefert:
- VM/CT-Status und Ressourcen
- Node-Metriken (CPU, RAM, Disk, Netzwerk)
- Storage-Pool-Belegung
- Cluster-Status

## E-Mail-Benachrichtigungen

Proxmox kann E-Mails senden bei:
- Backup-Fehlern
- ZFS-Scrub-Ergebnissen
- Hardware-Fehlern (SMART)

### Einrichten:

1. **Datacenter** → **Options** → **Email from address**: `proxmox@praxis-stracke.de`
2. **Node** → **Options** → Postfix-Konfiguration (oder externen SMTP nutzen)

```bash
# Postfix als Relay konfigurieren (für Gmail/Office365):
apt install libsasl2-modules -y

# /etc/postfix/main.cf anpassen:
relayhost = [smtp.office365.com]:587
smtp_sasl_auth_enable = yes
smtp_sasl_password_maps = hash:/etc/postfix/sasl_passwd
smtp_sasl_security_options = noanonymous
smtp_tls_security_level = encrypt
```

## Regelmäßige Wartung

### Tägliche Prüfungen (automatisiert)

- Backup-Jobs erfolgreich? (E-Mail-Benachrichtigung)
- Alle VMs/CTs laufen? (Proxmox-Dashboard)

### Wöchentliche Prüfungen

- Storage-Belegung prüfen
- Log-Dateien auf Fehler durchsehen
- ZFS-Pool-Status checken

### Monatliche Wartung

```bash
# 1. System-Updates (nach Snapshot!)
apt update && apt dist-upgrade -y

# 2. ZFS Scrub manuell anstoßen (falls nicht automatisch)
zpool scrub rpool
zpool scrub SSDPool1

# 3. Alte Backups aufräumen (Retention prüfen)
# Web-Interface: Storage → Backups → Aufräumen

# 4. Log-Rotation prüfen
journalctl --disk-usage
journalctl --vacuum-time=30d   # Logs älter als 30 Tage löschen

# 5. SMART-Status der Festplatten
smartctl -a /dev/sda | grep -E "Reallocated|Current_Pending|Offline_Uncorrectable"
# → Werte > 0 = Festplatte könnte bald ausfallen!
```

### Jährliche Wartung

- Hardware-Check (Staub, Lüfter, Kabel)
- USV-Test (Unterbrechungsfreie Stromversorgung)
- Disaster-Recovery-Test (Backup auf neuer Hardware wiederherstellen)
- Passwort-Rotation
- Zertifikate erneuern

## Wichtige Log-Dateien

```bash
# Proxmox-System-Logs
journalctl -u pvedaemon --since "1 hour ago"
journalctl -u pveproxy --since "1 hour ago"

# Backup-Logs
ls /var/log/vzdump/

# ZFS-Events
zpool events | tail -20

# Hardware-Fehler (IPMI)
ipmitool sel list

# Kernel-Meldungen (Hardware-Fehler, OOM, etc.)
dmesg | tail -50
```

---

## Nächste Schritte

- Für die Praxis-Konfiguration: `praxis-konfiguration.md` (Referenzdatei)
