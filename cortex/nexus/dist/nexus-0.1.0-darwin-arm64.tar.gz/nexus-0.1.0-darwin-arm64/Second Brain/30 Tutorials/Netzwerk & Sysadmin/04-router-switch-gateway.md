# Modul 03: Router, Switch und Gateway

**Dauer**: 25 Minuten  
**Schwierigkeit**: ⭐⭐ Mittel  
**Voraussetzungen**: Modul 01, Modul 02  
**Version**: 0.3

---

## 📚 Theorie

### Was ist ein Router?

Ein **Router** ist wie ein **Postamt**: Er leitet Datenpakete zwischen verschiedenen Netzwerken weiter.

**Funktionen eines Routers**:
1. **Internet-Gateway**: Verbindet dein lokales Netzwerk mit dem Internet
2. **DHCP-Server**: Vergibt automatisch IP-Adressen
3. **DNS-Server**: Löst Domain-Namen auf
4. **Firewall**: Schützt dein Netzwerk vor Angriffen
5. **NAT**: Übersetzt private IPs in öffentliche IPs

**Dein Router**: FRITZ!Box 7530 AX (192.168.178.1)

### Was ist ein Switch?

Ein **Switch** ist wie ein **Verteiler**: Er verbindet mehrere Geräte im **gleichen Netzwerk** miteinander.

**Unterschied Router vs. Switch**:
- **Router**: Verbindet **verschiedene Netzwerke** (z.B. LAN ↔ Internet)
- **Switch**: Verbindet **Geräte im gleichen Netzwerk** (z.B. mehrere Computer)

**Dein Switch**: TP-Link ES216G (192.168.178.96)
- 16 Ports
- Managed Switch (kann konfiguriert werden)

### Was ist ein Gateway?

Ein **Gateway** ist der **Ausgangspunkt** aus deinem Netzwerk heraus.

**Einfach erklärt**: Wenn ein Gerät im Netzwerk ins Internet möchte, sendet es die Daten an den **Gateway** (deinen Router), der sie dann weiterleitet.

**Dein Gateway**: `192.168.178.1` (FRITZ!Box)

**Warum wichtig?** Alle Geräte müssen wissen, wohin sie Daten senden sollen, die nicht für das lokale Netzwerk bestimmt sind.

### Erweiterte Router- und Switch-Konzepte

**Routing-Tabelle**: Eine Tabelle im Router, die bestimmt, wohin Datenpakete weitergeleitet werden. Enthält Netzwerke und die zugehörigen nächsten Hops (Next Hop).

**Default Route**: Die Standard-Route für alle Pakete, deren Ziel nicht in der Routing-Tabelle steht. Meist der Gateway zum Internet (0.0.0.0/0 → Gateway).

**Next Hop**: Das nächste Gerät auf dem Weg zum Ziel. In lokalen Netzwerken ist das meist der Gateway-Router.

**Static Routing**: Manuell konfigurierte Routen in der Routing-Tabelle. Für einfache Netzwerke ausreichend.

**Dynamic Routing**: Automatisches Lernen von Routen durch Routing-Protokolle wie OSPF, BGP, RIP. Für komplexe Netzwerke.

**ARP (Address Resolution Protocol)**: Übersetzt IP-Adressen (Layer 3) in MAC-Adressen (Layer 2). Wenn ein Gerät die MAC-Adresse eines anderen Geräts im gleichen Netzwerk benötigt, sendet es eine ARP-Anfrage.

**ARP-Tabelle**: Speichert die Zuordnung zwischen IP- und MAC-Adressen. Kann mit `arp -a` angezeigt werden.

**MAC-Learning**: Switches lernen automatisch, welche MAC-Adressen an welchen Ports sind, indem sie die Quell-MAC-Adressen von eingehenden Frames analysieren.

**MAC-Adress-Tabelle**: Eine Tabelle im Switch, die MAC-Adressen Ports zuordnet. Ermöglicht effizientes Forwarding von Frames.

**Broadcast-Sturm**: Ein Zustand, in dem Broadcast-Nachrichten sich selbst verstärken und das Netzwerk überlasten. Moderne Switches verhindern dies durch Spanning Tree Protocol.

**Spanning Tree Protocol (STP)**: Verhindert Loops in Netzwerken mit mehreren Switches. Deaktiviert redundante Verbindungen automatisch.

**VLAN (Virtual LAN)**: Logische Aufteilung eines physischen Netzwerks in mehrere virtuelle Netzwerke. Geräte in verschiedenen VLANs können nicht direkt kommunizieren.

**Trunking**: Verbindung zwischen Switches, die mehrere VLANs transportiert. Verwendet VLAN-Tagging (802.1Q).

**VLAN-Tagging**: Hinzufügen einer VLAN-ID zu Ethernet-Frames (802.1Q Header). Ermöglicht Trunking.

**Access Port**: Ein Switch-Port, der nur einem VLAN zugeordnet ist. Geräte sind direkt mit diesem VLAN verbunden.

**Trunk Port**: Ein Switch-Port, der mehrere VLANs transportiert (getagged).

**Layer 2 Switch**: Arbeitet auf OSI Layer 2 (Data Link), verwendet MAC-Adressen für Forwarding. Dein TP-Link ES216G ist ein Layer 2 Switch.

**Layer 3 Switch**: Kombiniert Switch- und Router-Funktionalität. Kann Routing auf Layer 3 durchführen, aber auch Switching auf Layer 2.

**Managed Switch**: Ein Switch, der konfiguriert werden kann (VLANs, STP, etc.). Dein TP-Link ES216G ist ein Managed Switch.

**Unmanaged Switch**: Ein Switch ohne Konfigurationsmöglichkeiten. Funktioniert Plug-and-Play.

**Port Mirroring**: Kopiert den Traffic von einem Port auf einen anderen Port. Wird für Monitoring verwendet.

**QoS (Quality of Service)**: Priorisierung von Netzwerk-Traffic. Wichtige Pakete (z.B. VoIP) erhalten Vorrang.

**Jumbo Frames**: Ethernet-Frames größer als 1500 Bytes (Standard MTU). Erfordert Unterstützung von allen Geräten.

**MTU (Maximum Transmission Unit)**: Maximale Größe eines Datenpakets, das ohne Fragmentierung übertragen werden kann. Standard: 1500 Bytes für Ethernet.

**Fragmentation**: Aufteilen großer Pakete in kleinere Pakete, wenn die MTU überschritten wird.

**ICMP (Internet Control Message Protocol)**: Protokoll für Fehlermeldungen und Diagnose. `ping` verwendet ICMP Echo Request/Reply.

**TTL (Time To Live)**: Ein Feld im IP-Header, das verhindert, dass Pakete endlos im Netzwerk zirkulieren. Wird bei jedem Hop dekrementiert.

**Hop Count**: Anzahl der Router, die ein Paket durchquert. Teil des TTL-Mechanismus.

**Firewall-Regeln**: Regeln, die bestimmen, welche Pakete durchgelassen oder blockiert werden. Deine FRITZ!Box hat eine integrierte Firewall.

**ACL (Access Control List)**: Liste von Regeln für Zugriffskontrolle. Bestimmt, welche Traffic erlaubt oder blockiert wird.

**Stateful Firewall**: Merkt sich Verbindungszustände. Erlaubt Antwortpakete automatisch, wenn eine Verbindung initiiert wurde.

**Stateless Firewall**: Prüft jedes Paket einzeln ohne Kontext. Weniger intelligent, aber einfacher.

**NAT-Types**:
- **Static NAT**: Feste Zuordnung einer privaten zu einer öffentlichen IP
- **Dynamic NAT**: Dynamische Zuordnung aus einem Pool öffentlicher IPs
- **PAT (Port Address Translation)**: Mehrere private IPs teilen sich eine öffentliche IP über verschiedene Ports (auch NAPT genannt)

---

## 🎯 Ziel dieses Moduls

Nach diesem Modul verstehst du:
- ✅ Unterschied zwischen Router und Switch
- ✅ Was ein Gateway ist und warum es wichtig ist
- ✅ Funktionen deines Routers kennen
- ✅ Deine Netzwerk-Infrastruktur verstehen
- ✅ Routing-Tabellen, Default Route, Next Hop verstehen
- ✅ ARP und MAC-Learning kennen
- ✅ VLAN, Trunking, Tagging verstehen
- ✅ Layer 2 vs. Layer 3 Switches unterscheiden
- ✅ MTU, Fragmentation, ICMP kennen
- ✅ Firewall-Konzepte (Stateful, Stateless, ACL) verstehen
- ✅ NAT-Types kennen

---

## 📋 Schritt-für-Schritt

### Schritt 1: Router-Funktionen verstehen

**Was machen wir?**  
Wir schauen uns die Funktionen deiner FRITZ!Box an.

**Router-Funktionen deiner FRITZ!Box**:

1. **Internet-Gateway**:
   - Verbindet dein Netzwerk (192.168.178.0/24) mit dem Internet
   - IP: 192.168.178.1

2. **DHCP-Server**:
   - Vergibt automatisch IP-Adressen
   - Bereich: 192.168.178.40 - 200
   - Lease-Zeit: 10 Tage

3. **DNS-Server**:
   - Löst Domain-Namen auf (z.B. google.com → IP-Adresse)
   - Weiterleitung an ISP-DNS-Server
   - Lokale Domain: `.fritz.box`

4. **Firewall**:
   - Blockiert unerwünschte Verbindungen von außen
   - Standard: Alle eingehenden Verbindungen blockiert

5. **NAT (Network Address Translation)**:
   - Übersetzt private IPs (192.168.178.x) in öffentliche IP
   - Ermöglicht Internet-Zugriff für alle Geräte

---

### Schritt 2: Router-Konfiguration prüfen

**Was machen wir?**  
Wir schauen uns die Router-Konfiguration an.

1. Öffne die FRITZ!Box Oberfläche: `http://192.168.178.1`

2. Gehe zu **"Internet"** → **"Zugangsdaten"**

3. Prüfe die **DNS-Server**:
   - Vom Internetanbieter zugewiesen (automatisch)
   - Weiterleitung über FRITZ!Box

4. Gehe zu **"Heimnetz"** → **"Netzwerk"**

5. Prüfe die **DHCP-Einstellungen**:
   - DHCP-Bereich: 192.168.178.40 - 200
   - Lease-Zeit: 10 Tage

**Erwartetes Ergebnis**:  
Du siehst die Konfiguration deines Routers und verstehst, welche Funktionen aktiv sind.

---

### Schritt 3: Gateway prüfen

**Was machen wir?**  
Wir prüfen, ob dein Computer den Gateway kennt.

**macOS**:

1. Öffne das Terminal

2. Gib diesen Befehl ein:
```bash
netstat -rn | grep default
```

**Erwartetes Ergebnis**:  
Du siehst eine Zeile wie:
```
default            192.168.178.1        UGSc           en7
```

**Das bedeutet**:
- **default**: Standard-Route (für alle Ziele außerhalb des lokalen Netzwerks)
- **192.168.178.1**: Gateway-Adresse (dein Router)
- **UGSc**: Flags (U=up, G=gateway, Sc=static)
- **en7**: Netzwerk-Interface

**Alternative (einfacher)**:
```bash
route get default | grep gateway
```

---

### Schritt 4: Switch identifizieren

**Was machen wir?**  
Wir identifizieren deinen Switch im Netzwerk.

**Dein Switch**: TP-Link ES216G

**Eigenschaften**:
- **IP-Adresse**: 192.168.178.96
- **Typ**: Managed Switch (kann konfiguriert werden)
- **Ports**: 16 Ports
- **Funktion**: Verbindet Geräte per Kabel

**Was macht der Switch?**
- Verbindet mehrere Geräte per Kabel
- Leitet Daten zwischen verbundenen Geräten weiter
- Arbeitet auf Layer 2 (MAC-Adressen)

**Vergleich**:
- **Router**: Entscheidet, wohin Daten gehen (verschiedene Netzwerke)
- **Switch**: Verteilt Daten im gleichen Netzwerk

---

### Schritt 5: Netzwerk-Fluss verstehen

**Was machen wir?**  
Wir verstehen, wie Daten durch dein Netzwerk fließen.

**Beispiel: Cluster-Mini-01 möchte auf google.com zugreifen**

1. **Cluster-Mini-01** (192.168.178.29) möchte google.com aufrufen
2. Fragt **DNS-Server** (192.168.178.1): "Was ist die IP von google.com?"
3. Erhält Antwort: "142.250.185.14"
4. Sendet Datenpaket an **Gateway** (192.168.178.1)
5. **Router** (Gateway) leitet Paket ins **Internet** weiter
6. Antwort kommt zurück über **Router**
7. **Router** leitet Antwort an **Cluster-Mini-01** weiter

**Lokale Kommunikation** (z.B. Cluster-Mini-01 → Cluster-Mini-02):
- Geht direkt über den **Switch**
- Braucht keinen Router
- Schneller, da lokal

---

## 💻 Befehle

### Gateway anzeigen

```bash
# macOS/Linux
netstat -rn | grep default

# Oder einfacher
route get default | grep gateway

# Linux
ip route | grep default
```

### Router erreichen (Ping)

```bash
# Prüfe, ob Router erreichbar ist
ping 192.168.178.1

# Nur 4 Pakete senden
ping -c 4 192.168.178.1
```

### Routing-Tabelle anzeigen

```bash
# macOS/Linux
netstat -rn

# Linux
ip route show
```

---

## ✅ Erwartetes Ergebnis

Nach diesem Modul solltest du:

1. ✅ Den Unterschied zwischen Router und Switch verstehen
2. ✅ Wissen, was ein Gateway ist
3. ✅ Die Funktionen deines Routers kennen
4. ✅ Den Gateway deines Computers finden können
5. ✅ Verstehen, wie Daten durch dein Netzwerk fließen

---

## ⚠️ Mögliche Fehlerquellen

### Problem: Gateway-Befehl zeigt nichts

**Lösung**:
- Prüfe, ob du mit dem Netzwerk verbunden bist
- Versuche: `ping 192.168.178.1`
- Falls das nicht funktioniert, prüfe deine Netzwerkverbindung

### Problem: Ich verstehe den Unterschied nicht

**Lösung**:
- **Router**: Verbindet verschiedene Netzwerke (wie ein Postamt zwischen Städten)
- **Switch**: Verbindet Geräte im gleichen Netzwerk (wie ein Verteiler in einem Gebäude)
- **Gateway**: Der Ausgangspunkt aus deinem Netzwerk (wie die Haustür)

### Problem: Router nicht erreichbar

**Lösung**:
- Prüfe die Netzwerkverbindung
- Prüfe, ob Router eingeschaltet ist
- Prüfe die IP-Adresse (sollte 192.168.178.1 sein)

---

## 📝 Zusammenfassung

**Was hast du gelernt?**

1. **Router**: Verbindet verschiedene Netzwerke, leitet Datenpakete weiter
2. **Switch**: Verbindet Geräte im gleichen Netzwerk
3. **Gateway**: Ausgangspunkt aus dem Netzwerk (meist der Router)
4. **Router-Funktionen**: Gateway, DHCP, DNS, Firewall, NAT

**Wichtige Begriffe**:
- **Router**: Verbindet Netzwerke, leitet Datenpakete weiter (Layer 3)
- **Switch**: Verbindet Geräte im gleichen Netzwerk (Layer 2)
- **Gateway**: Ausgangspunkt aus dem Netzwerk (Default Route)
- **Routing-Tabelle**: Bestimmt, wohin Pakete weitergeleitet werden
- **Default Route**: Standard-Route für unbekannte Ziele (0.0.0.0/0)
- **Next Hop**: Nächstes Gerät auf dem Weg zum Ziel
- **Static Routing**: Manuell konfigurierte Routen
- **Dynamic Routing**: Automatisches Lernen durch Routing-Protokolle (OSPF, BGP, RIP)
- **ARP**: Address Resolution Protocol - IP zu MAC-Adresse
- **ARP-Tabelle**: Zuordnung IP → MAC-Adresse
- **MAC-Learning**: Switches lernen MAC-Adressen automatisch
- **MAC-Adress-Tabelle**: Zuordnung MAC-Adresse → Port im Switch
- **Broadcast-Sturm**: Überlastung durch sich verstärkende Broadcasts
- **STP**: Spanning Tree Protocol - verhindert Loops
- **VLAN**: Virtual LAN - logische Netzwerk-Aufteilung
- **Trunking**: Verbindung zwischen Switches für mehrere VLANs
- **VLAN-Tagging**: 802.1Q Header für VLAN-Information
- **Access Port**: Port für ein VLAN
- **Trunk Port**: Port für mehrere VLANs (getagged)
- **Layer 2 Switch**: Switch auf OSI Layer 2 (MAC-Adressen)
- **Layer 3 Switch**: Switch mit Routing-Funktionalität (Layer 3)
- **Managed Switch**: Konfigurierbarer Switch (VLANs, STP)
- **Unmanaged Switch**: Plug-and-Play Switch ohne Konfiguration
- **Port Mirroring**: Kopieren von Traffic für Monitoring
- **QoS**: Quality of Service - Traffic-Priorisierung
- **Jumbo Frames**: Frames größer als 1500 Bytes
- **MTU**: Maximum Transmission Unit - max. Paketgröße (Standard: 1500 Bytes)
- **Fragmentation**: Aufteilen großer Pakete
- **ICMP**: Internet Control Message Protocol - Fehlermeldungen, ping
- **TTL**: Time To Live - verhindert endlose Paket-Zirkulation
- **Hop Count**: Anzahl Router-Hops
- **Firewall-Regeln**: Regeln für Paket-Filterung
- **ACL**: Access Control List - Zugriffskontroll-Liste
- **Stateful Firewall**: Merkt sich Verbindungszustände
- **Stateless Firewall**: Prüft jedes Paket einzeln
- **Static NAT**: Feste IP-Zuordnung
- **Dynamic NAT**: Dynamische IP-Zuordnung
- **PAT/NAPT**: Port Address Translation - mehrere IPs über Ports
- **DHCP**: Automatische IP-Vergabe durch Router
- **DNS**: Namensauflösung durch Router
- **NAT**: Network Address Translation - Übersetzung privater IPs

**Deine Infrastruktur**:
- **Router**: FRITZ!Box 7530 AX (192.168.178.1)
- **Switch**: TP-Link ES216G (192.168.178.96)
- **Gateway**: 192.168.178.1 (FRITZ!Box)

---

## 🔗 Verweise

**Handbuch-Kapitel**:
- Kapitel 2.2: Router
- Kapitel 4.3: Netzwerkhardware
- Kapitel 5: Netzwerk Grundlagen

**Nächstes Modul**:  
➡️ [Modul 04: DHCP - Automatische IP-Vergabe](../TUTORIAL.md#modul-04-dhcp-automatische-ip-vergabe)

---

## 🎓 Selbstprüfung

Beantworte diese Fragen für dich selbst:

- [ ] Kann ich den Unterschied zwischen Router und Switch erklären?
- [ ] Weiß ich, was ein Gateway ist?
- [ ] Kann ich meinen Gateway finden?
- [ ] Verstehe ich die Funktionen meines Routers?
- [ ] Kann ich erklären, wie Daten durch mein Netzwerk fließen?

**Wenn du alle Fragen mit "Ja" beantworten kannst, bist du bereit für Modul 04!** 🎉

---

**Ende Modul 03**
