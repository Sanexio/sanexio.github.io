# Modul 04: DHCP - Automatische IP-Vergabe

**Dauer**: 20 Minuten  
**Schwierigkeit**: ⭐⭐ Mittel  
**Voraussetzungen**: Modul 02, Modul 03  
**Version**: 0.3

---

## 📚 Theorie

### Was ist DHCP?

**DHCP** steht für **Dynamic Host Configuration Protocol** (Dynamisches Host-Konfigurationsprotokoll).

**Einfach erklärt**: DHCP ist wie ein **automatischer Adressvergabe-Service**. Wenn ein neues Gerät ins Netzwerk kommt, bekommt es automatisch eine IP-Adresse zugewiesen - du musst nichts manuell konfigurieren!

**Ohne DHCP**: Du müsstest jedem Gerät manuell eine IP-Adresse geben.  
**Mit DHCP**: Das Gerät bekommt automatisch eine IP-Adresse.

### Wie funktioniert DHCP?

**Der DHCP-Prozess** (vereinfacht):

1. **Gerät kommt ins Netzwerk** (z.B. neues Smartphone)
2. **Gerät fragt**: "Gibt es einen DHCP-Server? Ich brauche eine IP-Adresse!"
3. **DHCP-Server antwortet**: "Ja! Hier ist deine IP: 192.168.178.45"
4. **Gerät verwendet die IP** für eine bestimmte Zeit (Lease-Zeit)
5. **Nach Ablauf**: Gerät fragt erneut oder bekommt die gleiche IP verlängert

**Dein DHCP-Server**: FRITZ!Box 7530 AX (192.168.178.1)

### DHCP-Bereich

Der **DHCP-Bereich** definiert, welche IP-Adressen automatisch vergeben werden können.

**Dein DHCP-Bereich**: `192.168.178.40 - 192.168.178.200`

**Das bedeutet**:
- Geräte erhalten IPs zwischen `.40` und `.200`
- `.1` ist der Router (Gateway)
- `.29 - .32` sind deine Cluster Nodes (statische IPs)
- `.2 - .39` und `.201 - .254` sind für statische IPs reserviert

### Statische IPs vs. DHCP

**DHCP (dynamisch)**:
- IP-Adresse wird automatisch vergeben
- Kann sich ändern (nach Lease-Zeit)
- Einfach zu verwalten
- Für normale Geräte (Smartphones, Tablets, etc.)

**Statische IP**:
- IP-Adresse ist fest zugewiesen
- Ändert sich nie
- Muss manuell konfiguriert werden
- Für Server, Cluster Nodes, wichtige Geräte

**Deine Cluster Nodes**: Haben statische IPs (.29-.32), damit sie immer die gleiche Adresse haben.

### Erweiterte DHCP-Konzepte

**DHCP-Discover**: Die erste Nachricht eines Clients, der eine IP-Adresse sucht. Wird als Broadcast gesendet, da der Client noch keine IP hat.

**DHCP-Offer**: Antwort des DHCP-Servers mit einem IP-Angebot. Enthält IP-Adresse, Subnetzmaske, Gateway, DNS-Server, Lease-Zeit.

**DHCP-Request**: Bestätigung des Clients, dass er das Angebot annimmt. Wird ebenfalls als Broadcast gesendet.

**DHCP-ACK (Acknowledgment)**: Finale Bestätigung des Servers. Der Client kann jetzt die IP-Adresse verwenden.

**DHCP-NAK (Negative Acknowledgment)**: Ablehnung, wenn die angeforderte IP nicht mehr verfügbar ist.

**DHCP-Release**: Client gibt seine IP-Adresse frei, wenn er das Netzwerk verlässt.

**DHCP-Renew**: Erneuerung der Lease-Zeit. Wird automatisch nach 50% der Lease-Zeit gesendet.

**DHCP-Rebind**: Wenn Renew fehlschlägt, versucht der Client einen anderen DHCP-Server zu kontaktieren.

**DHCP-Relay Agent**: Ein Gerät (meist Router), das DHCP-Nachrichten zwischen Clients und Servern weiterleitet, wenn sie in verschiedenen Subnetzen sind.

**DHCP-Snooping**: Sicherheitsfeature in Switches, das nur autorisierte DHCP-Server zulässt. Verhindert Rogue DHCP Server Angriffe.

**Option 82 (DHCP Relay Agent Information)**: Fügt Informationen über den Relay Agent hinzu (z.B. Switch-Port, VLAN).

**DHCP-Optionen**: Zusätzliche Konfigurationsparameter, die der Server an den Client sendet:
- **Option 1**: Subnetzmaske
- **Option 3**: Gateway (Router)
- **Option 6**: DNS-Server
- **Option 15**: Domain-Name
- **Option 51**: Lease-Zeit
- **Option 66**: TFTP-Server (für PXE-Boot)
- **Option 67**: Boot-Dateiname (für PXE-Boot)

**DHCP-Reservation**: Feste Zuordnung einer IP-Adresse zu einer MAC-Adresse. Kombiniert Vorteile von DHCP (zentrale Verwaltung) und statischer IP (feste Adresse).

**Scope**: Ein IP-Adressbereich, den ein DHCP-Server verwaltet. Dein DHCP-Scope ist `192.168.178.40 - 200`.

**Exclusion Range**: IP-Adressen innerhalb des Scopes, die nicht vergeben werden sollen. Beispiel: `.29-.32` für Cluster Nodes.

**Superscope**: Kombination mehrerer Scopes zu einem logischen Scope. Wird für mehrere Subnetze verwendet.

**DHCP-Failover**: Zwei DHCP-Server teilen sich einen Scope für Hochverfügbarkeit. Wenn einer ausfällt, übernimmt der andere.

**PXE (Preboot Execution Environment)**: Netzwerk-Boot über DHCP. Option 66 und 67 werden verwendet, um Boot-Server und Boot-Datei anzugeben.

**BOOTP**: Vorgänger von DHCP. DHCP ist abwärtskompatibel zu BOOTP.

**UDP-Ports**: DHCP verwendet UDP Port 67 (Server) und Port 68 (Client).

**Broadcast vs. Unicast**: DHCP-Nachrichten werden als Broadcast gesendet, da der Client noch keine IP hat. Nach der Lease-Vergabe können Renew-Nachrichten als Unicast gesendet werden.

**T1 (Renewal Time)**: Zeitpunkt, zu dem der Client versucht, seine Lease zu erneuern (50% der Lease-Zeit). Bei 10 Tagen Lease = nach 5 Tagen.

**T2 (Rebinding Time)**: Zeitpunkt, zu dem der Client versucht, einen anderen Server zu kontaktieren (87.5% der Lease-Zeit). Bei 10 Tagen Lease = nach 8.75 Tagen.

**Lease Database**: Datenbank des DHCP-Servers mit allen vergebenen IPs, MAC-Adressen, Lease-Zeiten.

**Conflict Detection**: Prüfung, ob eine IP-Adresse bereits verwendet wird, bevor sie vergeben wird. Sendet ICMP-Ping oder ARP-Request.

**Rogue DHCP Server**: Unautorisierter DHCP-Server im Netzwerk. Kann falsche Konfigurationen verteilen. Wird durch DHCP-Snooping verhindert.

---

## 🎯 Ziel dieses Moduls

Nach diesem Modul verstehst du:
- ✅ Was DHCP ist und wie es funktioniert
- ✅ Den DHCP-Bereich deines Routers kennen
- ✅ Unterschied zwischen DHCP und statischen IPs verstehen
- ✅ DHCP-Lease-Zeit verstehen
- ✅ DHCP-Konfiguration prüfen können
- ✅ DHCP-Nachrichten-Typen kennen (Discover, Offer, Request, ACK, NAK, Release, Renew, Rebind)
- ✅ DHCP-Relay Agent und DHCP-Snooping verstehen
- ✅ DHCP-Optionen kennen (Option 1, 3, 6, 15, 51, etc.)
- ✅ DHCP-Reservation, Scope, Exclusion Range verstehen
- ✅ T1/T2 Timer und Lease-Database kennen

---

## 📋 Schritt-für-Schritt

### Schritt 1: DHCP-Konfiguration prüfen

**Was machen wir?**  
Wir schauen uns die DHCP-Konfiguration deiner FRITZ!Box an.

1. Öffne die FRITZ!Box Oberfläche: `http://192.168.178.1`

2. Gehe zu **"Heimnetz"** → **"Netzwerk"** → **"Netzwerkeinstellungen"**

3. Suche nach **"DHCP-Server"**

**Erwartetes Ergebnis**:  
Du siehst:
- ✅ DHCP-Server aktiviert
- **DHCP-Bereich "von"**: `192.168.178.40`
- **DHCP-Bereich "bis"**: `192.168.178.200`
- **Gültigkeit**: `10 Tage`

**Das bedeutet**:
- Geräte erhalten IPs zwischen `.40` und `.200`
- Die IP-Adresse ist 10 Tage gültig
- Nach 10 Tagen wird die IP erneuert oder neu vergeben

---

### Schritt 2: DHCP-Bereich verstehen

**Was machen wir?**  
Wir analysieren, welche IPs für was verwendet werden.

**IP-Verteilung in deinem Netzwerk**:

| Bereich | Verwendung | Beispiel |
|---------|------------|----------|
| `.1` | Gateway (Router) | 192.168.178.1 |
| `.2 - .28` | Reserviert für statische IPs | Verfügbar |
| `.29 - .32` | **Cluster Nodes (statisch)** | 192.168.178.29 |
| `.33 - .39` | Reserviert für statische IPs | Verfügbar |
| **`.40 - .200`** | **DHCP-Bereich** | Automatisch vergeben |
| `.201 - .254` | Reserviert für statische IPs | Verfügbar |

**Warum diese Aufteilung?**
- Cluster Nodes haben statische IPs außerhalb des DHCP-Bereichs
- DHCP-Bereich ist groß genug für viele Geräte (161 IPs)
- Reservierte Bereiche für zukünftige Server

---

### Schritt 3: DHCP-Lease prüfen

**Was machen wir?**  
Wir schauen uns an, welche Geräte aktuell IP-Adressen vom DHCP-Server haben.

1. In der FRITZ!Box Oberfläche: **"Heimnetz"** → **"Netzwerk"**

2. Suche nach **"Verbundene Geräte"** oder **"Netzwerkgeräte"**

**Erwartetes Ergebnis**:  
Du siehst eine Liste aller Geräte mit:
- Gerätename
- IP-Adresse
- MAC-Adresse
- Verbindungsart (Kabel/WLAN)

**Beobachtung**:  
- Geräte mit IPs zwischen `.40` und `.200` haben diese vom DHCP-Server erhalten
- Cluster Nodes (.29-.32) haben statische IPs

---

### Schritt 4: Lease-Zeit verstehen

**Was machen wir?**  
Wir verstehen, was die Lease-Zeit bedeutet.

**Deine Lease-Zeit**: 10 Tage

**Was bedeutet das?**

1. **Gerät bekommt IP**: z.B. 192.168.178.45
2. **IP ist 10 Tage gültig**: Gerät kann diese IP 10 Tage lang verwenden
3. **Nach 5 Tagen**: Gerät fragt automatisch nach Verlängerung
4. **Nach 10 Tagen**: IP wird erneuert oder neu vergeben

**Warum Lease-Zeit?**
- Verhindert, dass IP-Adressen "verloren gehen"
- Ermöglicht Neuverteilung, wenn Geräte das Netzwerk verlassen
- Flexibilität bei Netzwerkänderungen

---

### Schritt 5: Statische IPs verstehen

**Was machen wir?**  
Wir verstehen, warum deine Cluster Nodes statische IPs haben.

**Deine Cluster Nodes**:
- Cluster-Mini-01: 192.168.178.29 (statisch)
- Cluster-Mini-02: 192.168.178.30 (statisch)
- Cluster-Mini-03: 192.168.178.31 (statisch)
- Cluster-Mini-04: 192.168.178.32 (statisch)

**Warum statische IPs?**

1. **Immer erreichbar**: Die IP-Adresse ändert sich nie
2. **Einfache Konfiguration**: Andere Geräte können die IP-Adresse kennen
3. **Server-Funktion**: Cluster Nodes sind Server, brauchen feste Adressen
4. **Render Farm**: Die Render Farm muss wissen, wo die Nodes sind

**Vergleich**:
- **Smartphone mit DHCP**: IP kann sich ändern, ist aber egal
- **Server mit statischer IP**: IP muss immer gleich sein, damit andere Geräte darauf zugreifen können

---

## 💻 Befehle

### DHCP-Informationen anzeigen (macOS)

```bash
# DHCP-Lease-Informationen anzeigen
ipconfig getpacket en0

# Oder für alle Interfaces
for iface in $(networksetup -listallnetworkservices | tail -n +2); do
    echo "=== $iface ==="
    ipconfig getpacket "$iface" 2>/dev/null | grep -E "domain_name_server|router|subnet_mask|ip_address"
done
```

### Aktuelle IP-Adresse anzeigen

```bash
# macOS
ipconfig getifaddr en0

# Linux
hostname -I
```

### DHCP erneuern (macOS)

```bash
# DHCP-Lease erneuern
sudo ipconfig set en0 DHCP

# Oder
sudo dhclient en0
```

---

## ✅ Erwartetes Ergebnis

Nach diesem Modul solltest du:

1. ✅ Verstehen, was DHCP ist und wie es funktioniert
2. ✅ Den DHCP-Bereich deines Routers kennen (40-200)
3. ✅ Die Lease-Zeit verstehen (10 Tage)
4. ✅ Den Unterschied zwischen DHCP und statischen IPs verstehen
5. ✅ Wissen, warum Cluster Nodes statische IPs haben

---

## ⚠️ Mögliche Fehlerquellen

### Problem: Gerät bekommt keine IP-Adresse

**Lösung**:
- Prüfe, ob DHCP-Server aktiviert ist
- Prüfe, ob DHCP-Bereich noch IPs frei hat
- Prüfe Netzwerkverbindung
- Versuche DHCP-Lease zu erneuern

### Problem: IP-Adresse ändert sich ständig

**Lösung**:
- Das ist normal bei DHCP!
- Wenn du eine feste IP brauchst, verwende statische IP
- Oder konfiguriere IP-Reservierung im Router

### Problem: Ich verstehe den DHCP-Bereich nicht

**Lösung**:
- Denke an einen Parkplatz: Der DHCP-Bereich ist der Bereich, aus dem automatisch Parkplätze vergeben werden
- Außerhalb dieses Bereichs sind Parkplätze reserviert (statische IPs)
- Der Router (.1) ist der Eingang (kein Parkplatz)

---

## 📝 Zusammenfassung

**Was hast du gelernt?**

1. **DHCP**: Automatische IP-Adressvergabe
2. **DHCP-Server**: Vergibt IP-Adressen automatisch
3. **DHCP-Bereich**: Bereich der automatisch vergebenen IPs (40-200)
4. **Lease-Zeit**: Wie lange eine IP gültig ist (10 Tage)
5. **Statische IP**: Feste IP-Adresse (für Server wichtig)

**Wichtige Begriffe**:
- **DHCP**: Dynamic Host Configuration Protocol
- **DHCP-Server**: Vergibt automatisch IP-Adressen
- **DHCP-Client**: Gerät, das eine IP-Adresse anfordert
- **DHCP-Discover**: Broadcast-Nachricht des Clients zur IP-Suche
- **DHCP-Offer**: IP-Angebot des Servers
- **DHCP-Request**: Bestätigung des Clients
- **DHCP-ACK**: Finale Bestätigung des Servers
- **DHCP-NAK**: Ablehnung des Servers
- **DHCP-Release**: Client gibt IP frei
- **DHCP-Renew**: Erneuerung der Lease-Zeit
- **DHCP-Rebind**: Versuch, anderen Server zu kontaktieren
- **DHCP-Relay Agent**: Weiterleitung zwischen Subnetzen
- **DHCP-Snooping**: Sicherheitsfeature gegen Rogue DHCP Server
- **Option 82**: DHCP Relay Agent Information
- **DHCP-Optionen**: Zusätzliche Konfigurationsparameter (Option 1, 3, 6, 15, 51, 66, 67)
- **DHCP-Reservation**: Feste IP-Zuordnung zu MAC-Adresse
- **Scope**: IP-Adressbereich des DHCP-Servers
- **Exclusion Range**: Ausgeschlossene IPs innerhalb des Scopes
- **Superscope**: Kombination mehrerer Scopes
- **DHCP-Failover**: Hochverfügbarkeit mit zwei Servern
- **PXE**: Preboot Execution Environment - Netzwerk-Boot
- **BOOTP**: Vorgänger von DHCP
- **UDP-Ports**: Port 67 (Server), Port 68 (Client)
- **T1 (Renewal Time)**: 50% der Lease-Zeit - Erneuerungsversuch
- **T2 (Rebinding Time)**: 87.5% der Lease-Zeit - Anderer Server
- **Lease Database**: Datenbank mit vergebenen IPs
- **Conflict Detection**: Prüfung auf bereits verwendete IPs
- **Rogue DHCP Server**: Unautorisierter DHCP-Server
- **DHCP-Bereich**: Bereich der automatisch vergebenen IPs
- **Lease-Zeit**: Gültigkeitsdauer einer IP-Adresse
- **Statische IP**: Feste, nicht änderbare IP-Adresse

**Deine DHCP-Konfiguration**:
- **DHCP-Server**: FRITZ!Box 7530 AX (192.168.178.1)
- **DHCP-Bereich**: 192.168.178.40 - 200
- **Lease-Zeit**: 10 Tage
- **Statische IPs**: Cluster Nodes (.29-.32)

---

## 🔗 Verweise

**Handbuch-Kapitel**:
- Kapitel 2.3: Lokales Netzwerk
- Kapitel 5.2: DHCP-Konfiguration

**Nächstes Modul**:  
➡️ [Modul 05: DNS - Namensauflösung](../TUTORIAL.md#modul-05-dns-namensauflösung)

---

## 🎓 Selbstprüfung

Beantworte diese Fragen für dich selbst:

- [ ] Kann ich erklären, was DHCP ist?
- [ ] Weiß ich, welcher DHCP-Bereich konfiguriert ist?
- [ ] Verstehe ich, was die Lease-Zeit bedeutet?
- [ ] Kann ich den Unterschied zwischen DHCP und statischen IPs erklären?
- [ ] Weiß ich, warum Cluster Nodes statische IPs haben?

**Wenn du alle Fragen mit "Ja" beantworten kannst, bist du bereit für Modul 05!** 🎉

---

**Ende Modul 04**
