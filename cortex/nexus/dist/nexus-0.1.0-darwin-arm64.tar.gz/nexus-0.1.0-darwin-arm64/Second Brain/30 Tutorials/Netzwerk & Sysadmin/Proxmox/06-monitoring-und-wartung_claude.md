# Proxmox 06 — Claude-Workflow

> Was Claude für dich automatisiert machen kann.

---

## Wartungsplan erstellen

```
"Claude, erstelle einen Wartungsplan für unseren Proxmox-Server —
was muss täglich, wöchentlich, monatlich und jährlich gemacht werden?"

→ Claude erstellt einen vollständigen Wartungskalender
  mit konkreten Schritten und Zeitaufwand.
```

## Log-Analyse

```
"Claude, hier sind die Logs vom Proxmox-Server: [Logs einfügen].
Gibt es Auffälligkeiten?"

→ Claude analysiert Logs auf Fehler, Warnungen und Muster,
  und empfiehlt Maßnahmen.
```

## Monitoring-Dashboard einrichten

```
"Claude, richte mir ein Grafana-Dashboard für Proxmox-Monitoring ein."

→ Claude erstellt Prometheus-Konfiguration und Grafana-Dashboard-JSON
  mit den wichtigsten Metriken (CPU, RAM, Disk, Netzwerk, VM-Status).
  Kann über den bestehenden Grafana-Server laufen.
```

## Capacity Planning

```
"Claude, unsere VMs nutzen aktuell X GB RAM und Y TB Storage.
Wie lange reicht die Hardware noch?"

→ Claude analysiert Wachstumstrends und empfiehlt,
  wann Upgrades nötig werden.
```
