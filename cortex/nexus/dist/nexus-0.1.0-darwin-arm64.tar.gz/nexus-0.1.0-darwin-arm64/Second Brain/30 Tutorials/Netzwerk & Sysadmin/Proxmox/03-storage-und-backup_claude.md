# Proxmox 03 — Claude-Workflow

> Was Claude für dich automatisiert machen kann.

---

## Backup-Status überprüfen

```
"Claude, wann war das letzte Backup meiner VMs?"
→ Claude fragt nach Zugang zum Proxmox (SSH/API) oder
  du kopierst die Backup-Liste aus dem Web-Interface ein.
  Claude prüft, ob alle VMs aktuell gesichert sind.
```

## Storage-Berechnung

```
"Claude, wie viel Speicher brauche ich für 7 tägliche und
4 wöchentliche Backups von 5 VMs mit je 64 GB?"

→ Claude rechnet:
  - Worst Case (ohne Kompression): 5 × 64 GB × 11 = 3.520 GB
  - Mit zstd-Kompression (~40%): ~2.100 GB
  - Empfehlung: 4 TB HDDPool1 reicht, 8 TB ist komfortabel
```

## Backup-Plan generieren

```
"Claude, erstelle einen Backup-Plan nach der 3-2-1-Regel
für unsere Praxis-Server."

→ Claude erstellt einen vollständigen Plan:
  - Welche VMs wie oft gesichert werden
  - Retention-Zeiten
  - Offsite-Backup-Strategie
  - Wiederherstellungs-Test-Schedule
```
