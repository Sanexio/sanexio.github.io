# Proxmox Tutorial 05 — Sicherheit

> **Voraussetzungen:** 01 bis 04
> **Ziel:** Server absichern — Updates, Zugriffsschutz, Hardening.

---

## Warum Sicherheit wichtig ist

Ein Server in einer Arztpraxis enthält besonders schützenswerte Daten
(Patientenakten, Befunde, Abrechnungen). Die DSGVO und das BDSG verlangen
angemessene technische und organisatorische Maßnahmen. Außerdem: Ransomware-Angriffe
auf Arztpraxen nehmen zu.

## Updates — Erste Priorität

### Proxmox-Updates

Proxmox basiert auf Debian Linux. Updates schließen Sicherheitslücken:

```bash
# Paketlisten aktualisieren
apt update

# Verfügbare Updates anzeigen
apt list --upgradable

# Updates installieren
apt dist-upgrade -y

# Nach Kernel-Updates: Neustart nötig
reboot
```

**Empfehlung:** Updates mindestens monatlich, Sicherheits-Updates sofort.

### VM-Updates

Jede VM braucht eigene Updates:
- **Windows Server:** Windows Update (automatisch oder manuell per WSUS)
- **Linux-Container:** `apt update && apt upgrade -y`

**Tipp:** Vor jedem Update einen **Snapshot** machen — so kannst du zurückrollen,
falls etwas nicht funktioniert.

## Zugriffsschutz

### SSH absichern

```bash
# SSH-Config bearbeiten
nano /etc/ssh/sshd_config

# Empfohlene Einstellungen:
PermitRootLogin prohibit-password  # Root nur mit SSH-Key, nicht mit Passwort
PasswordAuthentication no          # Nur SSH-Keys, keine Passwörter
Port 22                            # Standard-Port (oder ändern für Extra-Sicherheit)
MaxAuthTries 3                     # Max. 3 Fehlversuche

# SSH neu starten
systemctl restart sshd
```

**Wichtig:** BEVOR du Passwort-Login deaktivierst, stelle sicher, dass dein
SSH-Key funktioniert! Sonst sperrst du dich aus.

### SSH-Key einrichten (vom Mac)

```bash
# Auf dem Mac:
ssh-keygen -t ed25519 -C "dr.stracke@praxis"

# Key auf den Server kopieren
ssh-copy-id root@192.168.10.31

# Testen (sollte OHNE Passwort funktionieren)
ssh root@192.168.10.31
```

### Fail2Ban — Brute-Force-Schutz

Fail2Ban sperrt IP-Adressen automatisch, wenn zu viele fehlgeschlagene
Login-Versuche kommen:

```bash
# Installieren
apt install fail2ban -y

# Konfiguration erstellen
cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local

# In jail.local anpassen:
[sshd]
enabled = true
port = ssh
maxretry = 3
bantime = 3600    # 1 Stunde Sperre
```

### Zwei-Faktor-Authentifizierung (2FA)

Proxmox unterstützt 2FA direkt im Web-Interface:

1. User → **TFA** Tab
2. TOTP hinzufügen (mit Authenticator-App auf dem Handy)
3. QR-Code scannen
4. Code eingeben und bestätigen

Ab jetzt brauchst du Passwort UND den Code aus der App.

## Netzwerk-Sicherheit

### Nur nötige Ports öffnen

Der Proxmox-Host sollte nur folgende Ports freigeben:

| Port | Dienst | Zugriff |
|------|--------|---------|
| 8006 | Web-Interface | Nur aus Management-VLAN |
| 22 | SSH | Nur aus Management-VLAN |
| 3128 | Spice Proxy | Nur bei Bedarf |
| 5900-5999 | VNC | Nur bei Bedarf |

Alles andere: **geschlossen**.

### IPMI/BMC absichern

Der IPMI/BMC-Zugang (Remote-Hardware-Management) ist mächtig — er kann den
Server ein/ausschalten, die Konsole anzeigen und BIOS-Einstellungen ändern.

- In ein eigenes VLAN oder Management-Netzwerk legen
- Standardpasswort SOFORT ändern
- Zugriff auf wenige IP-Adressen beschränken

## Verschlüsselung

### ZFS-Verschlüsselung

ZFS kann Datasets verschlüsseln. Sinnvoll für sensitive Daten:

```bash
# Verschlüsseltes Dataset erstellen
zfs create -o encryption=aes-256-gcm -o keylocation=prompt -o keyformat=passphrase rpool/encrypted

# Beim Booten: Passphrase eingeben oder Key-File nutzen
```

### VM-Disk-Verschlüsselung

Windows-VMs können BitLocker nutzen (benötigt TPM-Passthrough oder vTPM).
Linux-VMs können LUKS-Verschlüsselung verwenden.

## Sicherheits-Checkliste

- [ ] Proxmox auf aktuellem Patchlevel
- [ ] SSH nur mit Key-Auth, kein Root-Passwort-Login
- [ ] Fail2Ban aktiv
- [ ] 2FA für Web-Interface aktiviert
- [ ] Firewall-Regeln restriktiv (nur nötige Ports)
- [ ] IPMI/BMC im Management-VLAN isoliert
- [ ] Regelmäßige Backups (getestet!)
- [ ] VMs und Container ebenfalls aktuell
- [ ] Zugangs-Passwörter stark und einzigartig
- [ ] Netzwerk-Segmentierung (VLANs) aktiv

---

## Nächste Schritte

- **06-monitoring-und-wartung.md** — Server überwachen und warten
