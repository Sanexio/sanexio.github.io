# Modul 01: Was ist ein Netzwerk?

**Dauer**: 15 Minuten  
**Schwierigkeit**: ⭐ Einfach  
**Voraussetzungen**: Keine  
**Version**: 0.3

---

## 📚 Theorie

### Was ist ein Netzwerk?

Ein **Netzwerk** ist eine Verbindung zwischen mehreren Computern oder Geräten, die es ihnen ermöglicht, miteinander zu kommunizieren und Daten auszutauschen.

**Einfaches Beispiel**: Stelle dir vor, du hast mehrere Computer zu Hause. Wenn diese Computer miteinander "sprechen" können (z.B. Dateien teilen, Drucker gemeinsam nutzen), dann bilden sie ein **lokales Netzwerk**.

### Warum brauchen wir Netzwerke?

1. **Kommunikation**: Geräte können miteinander kommunizieren
2. **Ressourcen teilen**: Drucker, Dateien, Internetverbindung gemeinsam nutzen
3. **Zentralisierte Verwaltung**: Ein Gerät kann andere verwalten
4. **Zugriff von außen**: Von überall auf deine Geräte zugreifen

### Lokales Netzwerk vs. Internet

**Lokales Netzwerk (LAN - Local Area Network)**:
- Deine Geräte zu Hause
- Schnell und sicher
- Nur für dich zugänglich
- Beispiel: Deine Mac Minis, die miteinander kommunizieren

**Internet (WAN - Wide Area Network)**:
- Weltweites Netzwerk
- Verbindet lokale Netzwerke
- Öffentlich zugänglich
- Beispiel: Zugriff auf Webseiten

### Grundlegende Komponenten

Jedes Netzwerk braucht:

1. **Geräte**: Computer, Smartphones, Drucker, etc.
2. **Verbindungen**: Kabel oder WLAN
3. **Router**: Verbindet dein lokales Netzwerk mit dem Internet
4. **Switch**: Verbindet mehrere Geräte im lokalen Netzwerk

### Netzwerk-Terminologie

**Node (Knoten)**: Ein einzelnes Gerät im Netzwerk (z.B. Computer, Router, Switch). Deine Cluster-Mini-01 bis Cluster-Mini-04 sind jeweils Nodes.

**Host**: Ein Endgerät im Netzwerk, das Daten sendet oder empfängt. **Technisch gesehen**: Jedes Gerät mit einer IP-Adresse ist ein Host. Jeder Computer, jedes Smartphone, jeder Drucker ist ein Host. Der Begriff "Host" beschreibt die **technische Rolle** eines Geräts im Netzwerk (es hat eine IP-Adresse und kann kommunizieren).

**Client**: Ein Gerät, das Dienste von einem Server anfordert. **Funktional gesehen**: Ein Client ist ein Gerät, das **Dienste konsumiert**. Beispiel: Dein iPad ist ein Client, wenn es auf einen Drucker zugreift oder eine Webseite aufruft. Der Begriff "Client" beschreibt die **funktionale Rolle** eines Geräts in einer Client-Server-Beziehung.

**Unterschied Host vs. Client**:
- **Host** = technische Bezeichnung: "Dieses Gerät hat eine IP-Adresse und kann im Netzwerk kommunizieren"
- **Client** = funktionale Bezeichnung: "Dieses Gerät fordert Dienste an"

**Wichtig**: Ein Gerät kann gleichzeitig Host und Client sein! Beispiel:
- Dein Mac Studio ist ein **Host** (hat IP-Adresse 192.168.178.28)
- Gleichzeitig ist es ein **Client**, wenn es auf einen Drucker zugreift
- Und es kann auch ein **Server** sein, wenn es Dateien für andere Geräte bereitstellt

**Zusammenfassung**: 
- **Host** = technische Kategorie (jedes Gerät mit IP)
- **Client** = funktionale Rolle (fordert Dienste an)
- **Server** = funktionale Rolle (stellt Dienste bereit)

**Server**: Ein Gerät, das Dienste für andere Geräte bereitstellt. Deine Cluster Nodes können als Render-Server fungieren. Ein Server ist auch immer ein Host (hat eine IP-Adresse), aber erfüllt die funktionale Rolle des Dienst-Anbieters.

**MAC-Adresse (Media Access Control)**: Eine eindeutige Hardware-Adresse jedes Netzwerk-Interfaces. Format: `AA:BB:CC:DD:EE:FF` (hexadezimal). Jede Netzwerkkarte hat eine fest eingebaute MAC-Adresse.

**Beispiel**: Dein TP-Link ES216G Switch hat die MAC-Adresse `78-20-51-96-96-EB`. Diese Adresse ist fest in der Hardware eingebaut und identifiziert den Switch eindeutig im Netzwerk.

**Ethernet**: Das am häufigsten verwendete Protokoll für kabelgebundene Netzwerke. Dein Switch verwendet Ethernet für die Kommunikation zwischen Geräten.

**WiFi (WLAN)**: Drahtloses Netzwerkprotokoll (IEEE 802.11). Deine Access Points (EAP653) ermöglichen WiFi-Verbindungen.

**TCP/IP**: Das grundlegende Protokoll-Stack für Internet-Kommunikation. TCP (Transmission Control Protocol) sorgt für zuverlässige Datenübertragung, IP (Internet Protocol) für Adressierung und Routing.

**Topologie**: Die physische oder logische Anordnung von Geräten im Netzwerk. Dein Netzwerk verwendet eine **Stern-Topologie** (Star Topology), bei der alle Geräte über einen zentralen Switch verbunden sind.

**Broadcast-Domain**: Ein Bereich, in dem Broadcast-Nachrichten (Nachrichten an alle Geräte) weitergeleitet werden. Dein gesamtes LAN (192.168.178.0/24) ist eine Broadcast-Domain.

**Collision Domain**: Ein Bereich, in dem Datenpakete kollidieren können. 

**Was ist eine Kollision?**
Stell dir vor, zwei Personen sprechen gleichzeitig über ein Telefon - du kannst nichts verstehen. Ähnlich ist es bei Netzwerk-Kollisionen: Wenn zwei Geräte gleichzeitig Datenpakete senden, können diese "zusammenstoßen" und beide Pakete werden unbrauchbar. Die Geräte müssen dann warten und erneut senden.

**Historischer Kontext - Hub vs. Switch:**
- **Hub (veraltet)**: Ein Hub leitet alle Datenpakete an alle Ports weiter. Wenn Gerät A an Gerät B sendet, sehen alle anderen Geräte das Paket auch. Wenn zwei Geräte gleichzeitig senden → **Kollision**! Alle Geräte am Hub teilen sich eine gemeinsame Collision Domain.
- **Switch (modern)**: Ein Switch ist intelligenter. Er lernt, welche Geräte an welchen Ports sind und leitet Pakete nur an den Ziel-Port weiter. Jeder Port hat seine eigene Collision Domain.

**Dein TP-Link ES216G als Beispiel**: 
- 16 Ports, jeder Port = eigene Collision Domain
- MAC-Learning: Der Switch merkt sich, welche MAC-Adressen an welchen Ports sind (z.B. Port 1 → MAC-Adresse 78-20-51-96-96-EB)
- Intelligentes Forwarding: Wenn Cluster-Mini-01 (Port 5) an Cluster-Mini-02 (Port 6) sendet, wird das Paket nur zwischen diesen beiden Ports weitergeleitet, nicht an alle anderen Ports

**Warum haben moderne Switches pro Port eine eigene Collision Domain?**
1. **Direkte Verbindung**: Jeder Port ist direkt mit einem Gerät verbunden (oder einem anderen Switch). Es gibt keine gemeinsame Leitung, die geteilt wird.
2. **Full-Duplex**: Moderne Switches arbeiten im Full-Duplex-Modus. Das bedeutet:
   - Gerät A kann gleichzeitig Daten an Switch senden UND Daten vom Switch empfangen
   - Es gibt separate Sende- und Empfangs-Leitungen
   - Daher können keine Kollisionen auftreten - jedes Gerät hat seine eigene "Spur"

**Beispiel mit deinem Switch:**
- **Mit Hub (alte Technik)**: 5 Computer am Hub → alle 5 teilen sich eine Collision Domain. Wenn Computer 1 und 2 gleichzeitig senden → Kollision!
- **Mit deinem TP-Link ES216G Switch (moderne Technik)**: 
  - 16 Ports verfügbar, jeder Port hat seine eigene Collision Domain
  - Beispiel: 5 Computer am Switch → jeder Computer hat seine eigene Collision Domain
  - Computer 1 (Port 1) kann gleichzeitig mit Computer 2 (Port 2) kommunizieren, ohne dass es zu Kollisionen kommt
  - Alle 16 Ports können gleichzeitig Daten übertragen (Full-Duplex)
  - Der Switch lernt automatisch, welche MAC-Adressen an welchen Ports sind (MAC-Learning)

**Zusammenfassung**: Eine Collision Domain ist der Bereich, in dem Kollisionen auftreten können. Moderne Switches eliminieren Kollisionen praktisch, indem jeder Port seine eigene Collision Domain hat (durch Full-Duplex und intelligentes Forwarding).

**Duplex**: Die Art der Datenübertragung:
- **Half-Duplex**: Daten können nur in eine Richtung gleichzeitig übertragen werden
- **Full-Duplex**: Daten können gleichzeitig in beide Richtungen übertragen werden (moderne Switches)

**Bandbreite**: Die maximale Datenübertragungsrate (z.B. 1 Gbit/s = 1000 Mbit/s). Dein Switch unterstützt Gigabit-Ethernet (1 Gbit/s pro Port).

**Latenz (Latency)**: Die Zeit, die ein Datenpaket benötigt, um von einem Gerät zum anderen zu gelangen. Gemessen in Millisekunden (ms). Lokale Netzwerke haben niedrige Latenz (< 1 ms).

**Throughput**: Die tatsächliche Datenübertragungsrate, die erreicht wird. Kann niedriger sein als die Bandbreite aufgrund von Overhead.

**Ethernet-Frame**: Die Datenstruktur, in der Informationen über Ethernet übertragen werden. Enthält MAC-Adressen, Daten und Fehlerprüfung (CRC).

**OSI-Modell**: Ein 7-Schichten-Modell zur Beschreibung von Netzwerk-Kommunikation:
- **Layer 1 (Physical)**: Kabel, Signale
- **Layer 2 (Data Link)**: Ethernet, MAC-Adressen, Switches
- **Layer 3 (Network)**: IP-Adressen, Routing, Router
- **Layer 4 (Transport)**: TCP, UDP
- **Layer 5-7**: Session, Presentation, Application

Für den Anfang reicht es zu wissen: Switches arbeiten auf Layer 2, Router auf Layer 3.

---

## 🎯 Ziel dieses Moduls

Nach diesem Modul verstehst du:
- ✅ Was ein Netzwerk ist
- ✅ Warum Netzwerke wichtig sind
- ✅ Unterschied zwischen lokalem Netzwerk und Internet
- ✅ Grundlegende Netzwerk-Komponenten
- ✅ Technische Begriffe: Node, Host, Client, Server, MAC-Adresse
- ✅ Netzwerk-Protokolle: Ethernet, WiFi, TCP/IP
- ✅ Netzwerk-Konzepte: Topologie, Broadcast-Domain, Duplex, Bandbreite, Latenz
- ✅ OSI-Modell Grundlagen (Layer 1-3)

---

## 📋 Schritt-für-Schritt

### Schritt 1: Dein eigenes Netzwerk erkennen

**Was machen wir?**  
Wir schauen uns an, welche Geräte bereits in deinem Netzwerk sind.

**Wie machen wir das?**

1. Öffne die **FRITZ!Box Oberfläche**:
   - Gehe im Browser zu: `http://192.168.178.1`
   - Melde dich an (falls nötig)

2. Gehe zu **"Heimnetz"** → **"Netzwerk"**

3. Schaue dir die Liste der verbundenen Geräte an

**Erwartetes Ergebnis**:  
Du siehst eine Liste mit Geräten wie:
- Cluster-Mini-01
- Cluster-Mini-02
- Cluster-Mini-03
- Cluster-Mini-04
- iPad, PS5, Drucker, etc.

**Das sind die Geräte in deinem lokalen Netzwerk!**

---

### Schritt 2: Netzwerk-Typen verstehen

**Was machen wir?**  
Wir identifizieren die verschiedenen Netzwerk-Typen in deinem Setup.

**Lokales Netzwerk (LAN)**:
- Deine Mac Minis
- Dein Mac Studio
- Andere Geräte zu Hause
- **Subnetz**: 192.168.178.0/24

**Internet (WAN)**:
- Verbindung nach außen
- Über Vodafone DSL
- **Router**: FRITZ!Box 7530 AX

**Gastnetzwerk**:
- Getrenntes Netzwerk für Gäste
- **Subnetz**: 192.168.179.0/24

---

### Schritt 3: Netzwerk-Komponenten identifizieren

**Was machen wir?**  
Wir schauen uns die physischen Komponenten deines Netzwerks an.

**Router**: FRITZ!Box 7530 AX
- Verbindet dein lokales Netzwerk mit dem Internet
- IP-Adresse: 192.168.178.1

**Switch**: TP-Link Omada ES216G (16-Port Gigabit Easy Managed Switch)
- **Modell**: ES216G
- **Ports**: 16 Gigabit-Ethernet-Ports (1 Gbit/s pro Port)
- **Typ**: Managed Switch (kann konfiguriert werden)
  - **Was bedeutet "Managed"?** Der Switch kann über eine Web-Oberfläche oder Management-Software konfiguriert werden
  - **Standard-Zugangsdaten**: Username: `admin`, Password: `admin` (sollte bei erstem Zugriff geändert werden!)
  - **Mögliche Konfigurationen**: VLANs, Port-Einstellungen, QoS, Port-Mirroring, etc.
  - **Omada**: Teil des TP-Link Omada-Ökosystems, kann zentral verwaltet werden
- **IP-Adresse**: 192.168.178.96
- **MAC-Adresse**: 78-20-51-96-96-EB (eindeutige Hardware-Adresse, auf dem Gerät aufgedruckt)
- **Seriennummer**: 22570EB000130 UN/1.0 (zur Identifikation und Support)
- **Device Key**: 1736-F122-55A9-8AE3-7000 (für Cloud-Management/Omada-Controller)
- **Funktion**: Verbindet mehrere Geräte per Kabel, leitet Daten intelligent weiter
- **Besonderheit**: Jeder der 16 Ports hat seine eigene Collision Domain (Full-Duplex)

**Access Points**: 3x TP-Link EAP653
- Ermöglichen WLAN-Verbindungen
- Werden vom OC200 Controller verwaltet

---

### Schritt 4: Switch über Omada Controller verwalten

**Was machen wir?**  
Wir verbinden deinen TP-Link ES216G Switch mit dem Omada Cloud Controller, damit er zentral verwaltet werden kann.

**Warum wichtig?**
- **Zentrale Verwaltung**: Alle Omada-Geräte (Switch, Access Points) an einem Ort verwalten
- **Einfache Konfiguration**: VLANs, Port-Einstellungen, QoS über Web-Interface
- **Übersicht**: Alle Geräte und deren Status auf einen Blick sehen
- **Monitoring**: Statistiken und Logs für alle Geräte

**Voraussetzungen**:
- ✅ Switch ist physisch angeschlossen und hat Strom
- ✅ Switch ist im Netzwerk (IP: 192.168.178.96)
- ✅ Omada Cloud Controller ist verfügbar (https://euw1-omada-cloud.tplinkcloud.com)
- ✅ Du hast Zugriff auf den Omada Controller

**Schritt-für-Schritt Anleitung**:

#### 1. Omada Controller öffnen

1. Öffne den **Omada Cloud Controller** im Browser:
   ```
   https://euw1-omada-cloud.tplinkcloud.com/omada/5.14.32.56/index.html
   ```

2. Melde dich an (falls nötig)

3. Gehe zum **Dashboard** - du siehst aktuell:
   - 0 Switches (dein Switch ist noch nicht hinzugefügt)
   - 3 APs (deine Access Points sind bereits verbunden)
   - 18 Endgeräte

#### 2. Switch zum Controller hinzufügen (Adoption)

**Option A: Automatische Adoption (empfohlen)**

1. Im Omada Controller: Gehe zu **"Devices"** oder **"Geräte"** im linken Menü

2. Klicke auf **"Pending"** oder **"Ausstehend"** - hier sollten Geräte erscheinen, die noch nicht adoptiert wurden

3. Suche nach deinem Switch:
   - **Modell**: ES216G
   - **MAC-Adresse**: 78-20-51-96-96-EB
   - **IP-Adresse**: 192.168.178.96

4. Klicke auf **"Adopt"** oder **"Adoptieren"** neben dem Switch

5. Warte, bis der Adoption-Prozess abgeschlossen ist (kann 1-2 Minuten dauern)

**Option B: Manuelle Adoption**

Falls der Switch nicht automatisch erscheint:

1. **Switch direkt aufrufen**:
   - Öffne im Browser: `http://192.168.178.96`
   - Melde dich an mit:
     - Username: `admin`
     - Password: `admin`

2. **Omada Controller aktivieren**:
   - Gehe zu **"Management"** → **"Controller Settings"** oder **"Omada Controller"**
   - Aktiviere **"Enable Omada Controller"**
   - Gib die **Controller-URL** ein:
     ```
     https://euw1-api-omada-controller-connector.tplinkcloud.com
     ```
   - Oder gib die **Omada Controller ID** ein: `2a31fe2b6dba48f20a9f9acd858a2048`
   - Klicke auf **"Apply"** oder **"Übernehmen"**

3. **Zurück zum Omada Controller**:
   - Gehe zurück zum Omada Controller Dashboard
   - Der Switch sollte jetzt unter **"Pending"** erscheinen
   - Klicke auf **"Adopt"**

#### 3. Adoption-Prozess überwachen

Nach dem Klicken auf "Adopt":

1. **Status beobachten**: Der Switch zeigt "Adopting..." oder "Adoptierung läuft..."

2. **Warten**: Der Prozess dauert normalerweise 1-2 Minuten

3. **Erfolg**: Wenn erfolgreich, siehst du:
   - Status: "Online" oder "Online"
   - Der Switch erscheint im Dashboard unter "Switches" (nicht mehr "0 Switches")
   - Du kannst jetzt den Switch konfigurieren

#### 4. Switch konfigurieren

Nach erfolgreicher Adoption:

1. **Im Omada Controller**: Gehe zu **"Devices"** → **"Switches"**

2. **Switch auswählen**: Klicke auf deinen ES216G Switch

3. **Verfügbare Konfigurationen**:
   - **Port-Einstellungen**: Ports aktivieren/deaktivieren, Geschwindigkeit, Duplex
   - **VLANs**: Virtuelle Netzwerke konfigurieren
   - **QoS**: Quality of Service - Priorisierung von Traffic
   - **Port-Mirroring**: Traffic-Monitoring
   - **Link Aggregation**: Mehrere Ports zusammenfassen
   - **STP**: Spanning Tree Protocol für Redundanz

#### 5. Mögliche Probleme und Lösungen

**Problem: Switch erscheint nicht unter "Pending"**

**Lösungen**:
- ✅ Prüfe, ob Switch eingeschaltet ist
- ✅ Prüfe Netzwerkverbindung: `ping 192.168.178.96`
- ✅ Prüfe, ob Switch im gleichen Netzwerk wie der Controller ist
- ✅ Prüfe Firewall-Einstellungen (Ports 29810-29814 müssen offen sein)
- ✅ Versuche, den Switch direkt aufzurufen: `http://192.168.178.96`

**Problem: Adoption schlägt fehl**

**Lösungen**:
- ✅ Prüfe Internetverbindung (Controller ist Cloud-basiert)
- ✅ Prüfe, ob Switch bereits von einem anderen Controller verwaltet wird
- ✅ Setze Switch auf Werkseinstellungen zurück (Reset-Button 10 Sekunden gedrückt halten)
- ✅ Prüfe Firmware-Version (sollte aktuell sein)

**Problem: Switch ist offline nach Adoption**

**Lösungen**:
- ✅ Prüfe Netzwerkverbindung
- ✅ Prüfe, ob Switch Strom hat
- ✅ Prüfe Controller-Verbindung im Switch (unter Management → Controller Settings)
- ✅ Versuche erneute Adoption

**Wichtige Ports für Omada**:
- **Port 29810-29814**: Für Controller-Kommunikation
- **Port 80/443**: Für Web-Interface
- Diese Ports müssen zwischen Switch und Controller erreichbar sein

**Erwartetes Ergebnis**:  
Nach erfolgreicher Adoption siehst du im Omada Controller Dashboard:
- ✅ **1 Switch** (statt 0 Switches)
- ✅ Status: Online
- ✅ Du kannst den Switch konfigurieren und überwachen

---

## 💻 Befehle

**Keine Befehle in diesem Modul** - wir schauen uns nur die Oberfläche an.

---

## ✅ Erwartetes Ergebnis

Nach diesem Modul solltest du:

1. ✅ Verstehen, was ein Netzwerk ist
2. ✅ Deine eigenen Netzwerk-Geräte kennen
3. ✅ Den Unterschied zwischen LAN und Internet verstehen
4. ✅ Die Grundkomponenten deines Netzwerks identifizieren können
5. ✅ Deinen Switch über den Omada Controller verwalten können

---

## ⚠️ Mögliche Fehlerquellen

### Problem: Ich kann die FRITZ!Box nicht erreichen

**Lösung**:
- Prüfe, ob du mit dem Netzwerk verbunden bist
- Versuche: `ping 192.168.178.1`
- Falls das nicht funktioniert, prüfe deine Netzwerkverbindung

### Problem: Ich sehe keine Geräte

**Lösung**:
- Warte einen Moment (Geräte müssen sich anmelden)
- Prüfe, ob Geräte eingeschaltet sind
- Prüfe die Netzwerkverbindung der Geräte

### Problem: Switch erscheint nicht im Omada Controller (0 Switches)

**Lösung**:
- Prüfe, ob Switch eingeschaltet ist und Strom hat
- Prüfe Netzwerkverbindung: `ping 192.168.178.96`
- Versuche Switch direkt aufzurufen: `http://192.168.178.96`
- Prüfe, ob Switch im gleichen Netzwerk wie der Controller ist
- Prüfe Firewall-Einstellungen (Ports 29810-29814 müssen offen sein)
- Versuche manuelle Adoption über Switch-Web-Interface
- Prüfe, ob Switch bereits von einem anderen Controller verwaltet wird
- Setze Switch auf Werkseinstellungen zurück (falls nötig)

### Problem: Adoption schlägt fehl

**Lösung**:
- Prüfe Internetverbindung (Controller ist Cloud-basiert)
- Prüfe Controller-Verbindung im Switch (Management → Controller Settings)
- Warte länger (Adoption kann 2-3 Minuten dauern)
- Prüfe Firmware-Version des Switches
- Versuche erneute Adoption nach Reset

---

## 📝 Zusammenfassung

**Was hast du gelernt?**

1. **Netzwerk**: Verbindung zwischen Geräten zur Kommunikation
2. **LAN**: Lokales Netzwerk (deine Geräte zu Hause)
3. **Internet**: Weltweites Netzwerk (Zugriff nach außen)
4. **Komponenten**: Router, Switch, Access Points
5. **Switch-Verwaltung**: Zentrale Verwaltung über Omada Controller (Adoption, Konfiguration)

**Wichtige Begriffe**:
- **LAN**: Local Area Network (lokales Netzwerk)
- **WAN**: Wide Area Network (Internet)
- **Router**: Verbindet Netzwerke (Layer 3)
- **Switch**: Verbindet Geräte im Netzwerk (Layer 2)
- **Access Point**: Ermöglicht WLAN-Verbindungen
- **Node**: Einzelnes Gerät im Netzwerk
- **Host**: Technische Bezeichnung - Endgerät mit IP-Adresse, das Daten sendet/empfängt (jedes Gerät mit IP ist ein Host)
- **Client**: Funktionale Rolle - Gerät, das Dienste von einem Server anfordert (kann gleichzeitig Host sein)
- **Server**: Funktionale Rolle - Gerät, das Dienste für andere bereitstellt (ist auch immer ein Host)
- **MAC-Adresse**: Hardware-Adresse eines Netzwerk-Interfaces (Layer 2)
- **Ethernet**: Protokoll für kabelgebundene Netzwerke (Layer 2)
- **WiFi/WLAN**: Drahtloses Netzwerkprotokoll (IEEE 802.11)
- **TCP/IP**: Protokoll-Stack für Internet-Kommunikation
- **Topologie**: Anordnung von Geräten im Netzwerk (z.B. Stern-Topologie)
- **Broadcast-Domain**: Bereich für Broadcast-Nachrichten
- **Collision Domain**: Bereich, in dem Datenpakete kollidieren können (bei Hubs: alle Geräte teilen sich eine Domain; bei Switches: jeder Port hat eigene Domain durch Full-Duplex)

- **Duplex**: Half-Duplex (eine Richtung) oder Full-Duplex (beide Richtungen gleichzeitig)
- **Bandbreite**: Maximale Datenübertragungsrate (z.B. 1 Gbit/s)
- **Latenz**: Zeit für Datenpaket-Übertragung (in ms)
- **Throughput**: Tatsächliche erreichte Datenübertragungsrate
- **Ethernet-Frame**: Datenstruktur für Ethernet-Übertragung
- **OSI-Modell**: 7-Schichten-Modell (Layer 1-7)

---

## 🔗 Verweise

**Handbuch-Kapitel**:
- Kapitel 2: Infrastruktur
- Kapitel 3: Netzwerk Topologie

**Nächstes Modul**:  
➡️ [Modul 02: IP-Adressen verstehen](../TUTORIAL.md#modul-02-ip-adressen-verstehen)

---

## 🎓 Selbstprüfung

Beantworte diese Fragen für dich selbst:

- [ ] Kann ich erklären, was ein Netzwerk ist?
- [ ] Verstehe ich den Unterschied zwischen LAN und Internet?
- [ ] Kann ich die Komponenten meines Netzwerks identifizieren?
- [ ] Weiß ich, welche Geräte in meinem Netzwerk sind?
- [ ] Kann ich meinen Switch über den Omada Controller verwalten?

**Wenn du alle Fragen mit "Ja" beantworten kannst, bist du bereit für Modul 02!** 🎉

---

**Ende Modul 01**
