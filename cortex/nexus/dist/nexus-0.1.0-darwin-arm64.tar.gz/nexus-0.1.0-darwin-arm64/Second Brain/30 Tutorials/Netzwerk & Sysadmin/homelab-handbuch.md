# HOMELAB CLUSTER ADMIN HANDBUCH

**Version:** 0.2  
**Datum:** 2026-03-08  
**Status:** Netzwerkanalyse abgeschlossen - Infrastruktur dokumentiert

---

## Inhaltsverzeichnis

1. [Projektübersicht](#1-projektübersicht)
2. [Infrastruktur](#2-infrastruktur)
3. [Netzwerk Topologie](#3-netzwerk-topologie)
4. [Hardware Inventar](#4-hardware-inventar)
5. [Netzwerk Grundlagen](#5-netzwerk-grundlagen)
6. [Versionshistorie](#versionshistorie)

---

## 1. Projektübersicht

### 1.1 Projektziel

Aufbau eines professionellen Homelab-Cluster-Netzwerks zur systematischen Ausbildung als Systemadministrator. Das Projekt kombiniert:

- **Lernsystem**: Praktische Ausbildung in Netzwerk-, Server- und Cluster-Technologien
- **Infrastrukturprojekt**: Produktives Homelab für verschiedene Dienste
- **Dokumentationssystem**: Vollständige, reproduzierbare Dokumentation aller Schritte
- **Experimentierumgebung**: Testumgebung für Cluster-Technologien

### 1.2 Projektphasen

| Phase | Thema | Status |
|-------|-------|--------|
| 1 | Netzwerk Grundlagen | 🟢 Abgeschlossen |
| 2 | Homelab Infrastruktur | ⚪ Geplant |
| 3 | Virtualisierung mit Proxmox | ⚪ Geplant |
| 4 | Container Infrastruktur | ⚪ Geplant |
| 5 | Cluster Systeme | ⚪ Geplant |
| 6 | Blender Render Farm | ⚪ Geplant |
| 7 | Automatisierung | ⚪ Geplant |
| 8 | Remote Zugriff | ⚪ Geplant |
| 9 | Monitoring und Logging | ⚪ Geplant |
| 10 | High Availability | ⚪ Geplant |

### 1.3 Lernziele

Durch dieses Projekt sollen folgende Themen vollständig verstanden werden:

- Netzwerkgrundlagen (IP, Subnetze, Routing, Switching)
- VLAN, DHCP, DNS, NAT, Firewall
- Linux Systemadministration
- Virtualisierung (Proxmox)
- Container Systeme (Docker, Kubernetes)
- Cluster Systeme
- Remote Zugriff (VPN, Zero Trust)
- Monitoring (Prometheus, Grafana)
- Automatisierung (Ansible, Terraform)
- Storage Systeme
- High Availability

### 1.4 Zukünftige Dienste

Das Netzwerk soll später folgende Dienste betreiben:

- Proxmox Server (Virtualisierung)
- n8n Server (Workflow-Automatisierung)
- OpenClaw Server
- Blender Render Farm
- Container Plattform (Docker/Kubernetes)
- Monitoring Systeme
- Automatisierungsdienste
- Cluster-Infrastruktur

---

## 2. Infrastruktur

### 2.1 Internetprovider

| Eigenschaft | Wert |
|-------------|------|
| Provider | Vodafone DSL |
| Download | ~274 Mbit/s |
| Upload | ~45 Mbit/s |
| Verbindungstyp | DSL |

### 2.2 Router

| Eigenschaft | Wert |
|-------------|------|
| Modell | FRITZ!Box 7530 AX |
| Firmware | FRITZ!OS 8.20 |
| IP-Adresse (LAN) | 192.168.178.1 |
| Funktion | Internet-Gateway, Router, DHCP-Server, DNS-Server |
| MyFRITZ! Domain | 475cdg2rogmn8yah.myfritz.net |
| HTTPS-Port (extern) | 47924 |
| IPv6-Adresse | 2a00:1f:3204:0000::1 |
| **WICHTIG**: IPv4 CGNAT | ⚠️ Keine öffentliche IPv4-Adresse (Carrier-Grade NAT) |

### 2.3 Lokales Netzwerk

| Eigenschaft | Wert |
|-------------|------|
| Subnetz | 192.168.178.0/24 |
| Subnetzmaske | 255.255.255.0 |
| Gateway | 192.168.178.1 |
| DHCP-Bereich | 192.168.178.40 - 192.168.178.200 |
| DHCP-Lease-Zeit | 10 Tage |
| DNS-Server | 192.168.178.1 (FRITZ!Box, weiterleitet an ISP-DNS) |
| Lokaler DNS-Server | 192.168.178.1 |

### 2.4 Gastnetzwerk

| Eigenschaft | Wert |
|-------------|------|
| Subnetz | 192.168.179.0/24 |
| Gateway | 192.168.179.1 |
| Subnetzmaske | 255.255.255.0 |
| DHCP-Lease-Zeit | 6 Stunden |
| **Hinweis** | Adressbereich ist von FRITZ!Box festgelegt und nicht änderbar |

---

## 3. Netzwerk Topologie

### 3.1 Aktuelle Topologie (Version 0.2)

```
Internet (Vodafone DSL)
    |
    v
FRITZ!Box 7530 AX (192.168.178.1)
    |   [⚠️ CGNAT: Keine öffentliche IPv4]
    |   [✅ IPv6: 2a00:1f:3204:0000::1]
    |   [✅ MyFRITZ!: 475cdg2rogmn8yah.myfritz.net:47924]
    |
    +-- ES216G Switch (192.168.178.96)
    |   |
    |   +-- Cluster-Mini-01 (192.168.178.29) - M1, 16GB
    |   +-- Cluster-Mini-02 (192.168.178.30) - M2, 8GB
    |   +-- Cluster-Mini-03 (192.168.178.31) - M2, 8GB
    |   +-- Cluster-Mini-04 (192.168.178.32) - M2, 8GB
    |   +-- Mac Studio (IP zu ermitteln)
    |
    +-- OC200 Omada Controller (192.168.178.68)
    |   |
    |   +-- EAP653 Access Point 1 (192.168.178.40)
    |   +-- EAP653 Access Point 2 (192.168.178.61)
    |   +-- EAP653 Access Point 3 (192.168.178.62)
    |
    +-- Client-Geräte (DHCP: 192.168.178.40-200)
    |   |
    |   +-- iPad Pro M5 (192.168.178.41)
    |   +-- iPad 3 (192.168.178.78)
    |   +-- PS5 (192.168.178.55)
    |   +-- HP Drucker (192.168.178.56)
    |   +-- Sonos Geräte (verschiedene IPs)
    |   +-- Weitere IoT-Geräte
    |
    +-- Gastnetzwerk (192.168.179.0/24)
        Gateway: 192.168.179.1
        Lease-Zeit: 6 Stunden
```

### 3.2 Wichtige Erkenntnisse

#### Carrier-Grade NAT (CGNAT)
⚠️ **KRITISCH**: Der Internetanbieter (Vodafone) verwendet Carrier-Grade NAT. Dies bedeutet:
- **Keine öffentliche IPv4-Adresse** direkt zugewiesen
- **Portfreigaben auf IPv4-Basis funktionieren nicht** von außen
- **Lösungen**: IPv6 (verfügbar), VPN, MyFRITZ! DynDNS, oder öffentliches IPv4-Subnetz beim ISP anfragen

#### IPv6 Verfügbarkeit
✅ IPv6 ist verfügbar: `2a00:1f:3204:0000::1`
- Ermöglicht direkten Zugriff von außen über IPv6
- Alternative zu IPv4-Portfreigaben

#### MyFRITZ! DynDNS
✅ MyFRITZ! ist aktiviert:
- Domain: `475cdg2rogmn8yah.myfritz.net`
- HTTPS-Port: `47924`
- Ermöglicht Zugriff auf FRITZ!Box von außen über DynDNS

### 3.3 Netzwerkgeräte-Status (Vollständig)

#### Infrastruktur-Geräte

| Gerät | Typ | IP-Adresse | Hostname | Status | Notizen |
|-------|-----|------------|----------|--------|---------|
| FRITZ!Box 7530 AX | Router | 192.168.178.1 | 192-168-178-1.fritz.box | ✅ Aktiv | Internet-Gateway, DHCP, DNS |
| ES216G | Switch | 192.168.178.96 | ES216G.fritz.box | ✅ Aktiv | TP-Link Managed Switch |
| OC200 | Controller | 192.168.178.68 | OC200-BB800E.fritz.box | ✅ Aktiv | Omada Controller für EAPs |

#### Access Points (Omada)

| Gerät | Typ | IP-Adresse | Hostname | Status | Notizen |
|-------|-----|------------|----------|--------|---------|
| EAP653-1 | Access Point | 192.168.178.40 | EAP653-A8-42-A1-5F-6E-26.fritz.box | ✅ Aktiv | Omada Access Point |
| EAP653-2 | Access Point | 192.168.178.61 | EAP653-A8-42-A1-5F-6C-E8.fritz.box | ✅ Aktiv | Omada Access Point |
| EAP653-3 | Access Point | 192.168.178.62 | EAP653-A8-42-A1-5F-6C-54.fritz.box | ✅ Aktiv | Omada Access Point |

#### Cluster Nodes

| Gerät | Typ | IP-Adresse | Hostname | Status | Notizen |
|-------|-----|------------|----------|--------|---------|
| Cluster-Mini-01 | Mac Mini | 192.168.178.29 | Cluster-Mini-01 | ✅ Aktiv | Render Node, M1, 16GB |
| Cluster-Mini-02 | Mac Mini | 192.168.178.30 | Cluster-Mini-02 | ✅ Aktiv | Render Node, M2, 8GB |
| Cluster-Mini-03 | Mac Mini | 192.168.178.31 | Cluster-Mini-03 | ✅ Aktiv | Render Node, M2, 8GB |
| Cluster-Mini-04 | Mac Mini | 192.168.178.32 | Cluster-Mini-04 | ✅ Aktiv | Render Node, M2, 8GB |
| Mac Studio | Mac Studio | Zu ermitteln | - | ✅ Aktiv | IP zu ermitteln |

#### Client-Geräte (Auswahl)

| Gerät | Typ | IP-Adresse | Hostname | Status | Notizen |
|-------|-----|------------|----------|--------|---------|
| iPad Pro M5 | Tablet | 192.168.178.41 | iPadPro-M5.fritz.box | ✅ Aktiv | Client-Gerät |
| iPad 3 | Tablet | 192.168.178.78 | iPad-3.fritz.box | ✅ Aktiv | Client-Gerät |
| PS5 | Gaming Console | 192.168.178.55 | PS5-A2830B.fritz.box | ✅ Aktiv | Client-Gerät |
| HP Drucker | Drucker | 192.168.178.56 | HP6EFBB3.fritz.box | ✅ Aktiv | Netzwerkdrucker |
| Wohnzimmer | Gerät | 192.168.178.67 | Wohnzimmer.fritz.box | ✅ Aktiv | Unbekanntes Gerät |

#### Sonos Geräte

| Gerät | Typ | IP-Adresse | Hostname | Status |
|-------|-----|------------|----------|--------|
| Sonos 1 | Speaker | 192.168.178.52 | Sonos-B8E937E060B8.fritz.box | ✅ Aktiv |
| Sonos 2 | Speaker | 192.168.178.76 | Sonos-B8E9376364EC.fritz.box | ✅ Aktiv |
| Sonos 3 | Speaker | 192.168.178.81 | Sonos-B8E93782F94A.fritz.box | ✅ Aktiv |
| Sonos 4 | Speaker | 192.168.178.83 | Sonos-5CAAFDA4DF1C.fritz.box | ✅ Aktiv |
| Sonos 5 | Speaker | 192.168.178.130 | Sonos-B8E93782F94A.fritz.box | ✅ Aktiv |
| Sonos 6 | Speaker | 192.168.178.158 | Sonos-7828CA9FE6B0.fritz.box | ✅ Aktiv |
| Sonos 7 | Speaker | 192.168.178.178 | Sonos-48A6B8ECA410.fritz.box | ✅ Aktiv |

#### Weitere Geräte

| Gerät | Typ | IP-Adresse | Hostname | Status | Notizen |
|-------|-----|------------|----------|--------|---------|
| Unbekannt 1 | - | 192.168.178.28 | - | ✅ Aktiv | Aktueller Scan-Host |
| Unbekannt 2 | - | 192.168.178.105 | ecb5fa804ec2.fritz.box | ✅ Aktiv | Container/VM? |
| Unbekannt 3 | - | 192.168.178.165 | - | ✅ Aktiv | Kein Hostname |
| Unbekannt 4 | - | 192.168.178.177 | SEC8425190E805B.fritz.box | ✅ Aktiv | Security-Gerät? |

---

## 4. Hardware Inventar

### 4.1 Cluster Nodes

#### Mac Mini Render Nodes

| Node | Hostname | IP-Adresse | Betriebssystem | CPU | RAM | Storage | Status |
|------|----------|------------|----------------|-----|-----|---------|--------|
| Node 1 | Cluster-Mini-01 | 192.168.178.29 | macOS | Apple M1 (8 Kerne) | 16 GB | Zu ermitteln | ✅ Aktiv |
| Node 2 | Cluster-Mini-02 | 192.168.178.30 | macOS | Apple M2 (8 Kerne) | 8 GB | Zu ermitteln | ✅ Aktiv |
| Node 3 | Cluster-Mini-03 | 192.168.178.31 | macOS | Apple M2 (8 Kerne) | 8 GB | Zu ermitteln | ✅ Aktiv |
| Node 4 | Cluster-Mini-04 | 192.168.178.32 | macOS | Apple M2 (8 Kerne) | 8 GB | Zu ermitteln | ✅ Aktiv |

**Hardware-Details**:

- **Cluster-Mini-01**:
  - Modell: Mac mini (Macmini9,1)
  - Chip: Apple M1
  - Kerne: 8 (4 Performance + 4 Efficiency)
  - RAM: 16 GB
  - Serial: C07GM0MBQ6P0
  - Activation Lock: Enabled

- **Cluster-Mini-02**:
  - Modell: Mac mini (Mac14,3)
  - Chip: Apple M2
  - Kerne: 8 (4 Performance + 4 Efficiency)
  - RAM: 8 GB
  - Serial: T64KJQCFKY
  - Activation Lock: Disabled

- **Cluster-Mini-03**:
  - Modell: Mac mini (Mac14,3)
  - Chip: Apple M2
  - Kerne: 8 (4 Performance + 4 Efficiency)
  - RAM: 8 GB
  - Serial: THFYG61JT7
  - Activation Lock: Enabled

- **Cluster-Mini-04**:
  - Modell: Mac mini (Mac14,3)
  - Chip: Apple M2
  - Kerne: 8 (4 Performance + 4 Efficiency)
  - RAM: 8 GB
  - Serial: G4G2176YFW
  - Activation Lock: Enabled

### 4.2 Weitere Hardware

| Gerät | Typ | IP-Adresse | Betriebssystem | Status | Notizen |
|-------|-----|------------|----------------|--------|---------|
| Mac Studio | Mac Studio | Zu ermitteln | macOS | ✅ Aktiv | Hardware-Spezifikationen zu ermitteln |
| PC 1 | PC | Zu ermitteln | Zu ermitteln | ❓ Unbekannt | Hardware-Spezifikationen zu ermitteln |
| PC 2 | PC | Zu ermitteln | Zu ermitteln | ❓ Unbekannt | Hardware-Spezifikationen zu ermitteln |

### 4.3 Netzwerkhardware

| Gerät | Modell | Ports | Funktion | Status | Notizen |
|-------|--------|-------|----------|--------|---------|
| Router | FRITZ!Box 7530 AX | 4x LAN, WLAN | Internet-Gateway, Router, DHCP, DNS | ✅ Aktiv | Firmware: FRITZ!OS 8.20 |
| Switch | TP-Link ES216G | 16 Ports | Managed Layer 2 Switch | ✅ Aktiv | IP: 192.168.178.96 |
| Controller | TP-Link OC200 | - | Omada Controller | ✅ Aktiv | IP: 192.168.178.68 |
| Access Point 1 | TP-Link EAP653 | - | WiFi 6 Access Point | ✅ Aktiv | IP: 192.168.178.40 |
| Access Point 2 | TP-Link EAP653 | - | WiFi 6 Access Point | ✅ Aktiv | IP: 192.168.178.61 |
| Access Point 3 | TP-Link EAP653 | - | WiFi 6 Access Point | ✅ Aktiv | IP: 192.168.178.62 |

---

## 5. Netzwerk Grundlagen

### 5.1 IP-Adressierung

#### IPv4 Subnetz

- **Subnetz**: 192.168.178.0/24
- **Subnetzmaske**: 255.255.255.0
- **Verfügbare IPs**: 192.168.178.1 - 192.168.178.254 (254 Hosts)
- **Gateway**: 192.168.178.1 (FRITZ!Box)

#### IP-Adressbereiche (Aktuell)

| Bereich | Verwendung | Größe | Status |
|---------|------------|-------|--------|
| 192.168.178.1 | Gateway (FRITZ!Box) | 1 | ✅ Belegt |
| 192.168.178.2-39 | Statische IPs / Reservierungen | 38 | ✅ Verfügbar |
| 192.168.178.29-32 | Cluster Nodes (statisch) | 4 | ✅ Belegt |
| 192.168.178.40-200 | DHCP-Bereich | 161 | ✅ Aktiv |
| 192.168.178.201-254 | Statische IPs / Reservierungen | 54 | ✅ Verfügbar |

**Aktuelle Belegung**:
- **Statische IPs** (außerhalb DHCP): Cluster Nodes (.29-.32)
- **DHCP-Bereich**: 192.168.178.40-200 (Lease-Zeit: 10 Tage)
- **Verfügbare statische IPs**: .2-.28, .33-.39, .201-.254

#### IP-Adressbereiche (Geplant für zukünftige Erweiterung)

| Bereich | Verwendung | Größe | Status |
|---------|------------|-------|--------|
| 192.168.178.2-50 | Infrastruktur (Router, Switches, Controller) | 49 | ⚪ Geplant |
| 192.168.178.51-100 | Server | 50 | ⚪ Geplant |
| 192.168.178.101-150 | Cluster Nodes / Container | 50 | ⚪ Geplant |
| 192.168.178.151-200 | Client-Geräte (DHCP) | 50 | ⚪ Geplant |
| 192.168.178.201-254 | Reservierungen / Statische IPs | 54 | ⚪ Geplant |

### 5.2 DHCP-Konfiguration

**Aktueller Status**: ✅ Konfiguriert und aktiv

**Aktuelle Konfiguration**:
- **DHCP-Server**: FRITZ!Box 7530 AX (192.168.178.1)
- **DHCP-Bereich**: 192.168.178.40 - 192.168.178.200
- **Lease-Zeit**: 10 Tage
- **Statische IPs**: Cluster Nodes (.29-.32) außerhalb DHCP-Bereich

**Geplante Erweiterungen**:
- IP-Reservierungen für Server konfigurieren
- DHCP-Bereich optimieren für bessere Strukturierung
- Separate DHCP-Bereiche für verschiedene Gerätetypen (später mit VLANs)

### 5.3 DNS-Konfiguration

**Aktueller Status**: ✅ Konfiguriert und aktiv

**Aktuelle Konfiguration**:
- **Lokaler DNS-Server**: 192.168.178.1 (FRITZ!Box)
- **DNS-Weiterleitung**: FRITZ!Box leitet DNS-Anfragen an ISP-DNS-Server weiter
- **DNSv4-Server**: Vom Internetanbieter zugewiesen (automatisch)
- **DNSv6-Server**: Vom Internetanbieter zugewiesen (automatisch)
- **Lokale Namensauflösung**: `.fritz.box` Domain aktiv

**Funktionen**:
- ✅ Lokale Hostname-Auflösung (z.B. `Cluster-Mini-01.fritz.box`)
- ✅ mDNS/Bonjour Unterstützung
- ✅ Automatische Hostname-Registrierung

**Geplante Erweiterungen**:
- Lokale DNS-Zonen für Cluster-Nodes konfigurieren
- Custom DNS-Einträge für Server hinzufügen
- DNS-Caching optimieren

### 5.4 NAT und Port Forwarding

**Aktueller Status**: ⚠️ Eingeschränkt durch CGNAT

**Wichtige Erkenntnis - Carrier-Grade NAT (CGNAT)**:
- ⚠️ **Keine öffentliche IPv4-Adresse** direkt zugewiesen
- ⚠️ **IPv4-Portfreigaben funktionieren nicht** von außen
- ✅ **IPv6 ist verfügbar**: `2a00:1f:3204:0000::1`
- ✅ **MyFRITZ! DynDNS aktiv**: `475cdg2rogmn8yah.myfritz.net:47924`

**Aktuelle Portfreigaben**:
- Keine IPv4-Portfreigaben konfiguriert
- HTTPS-Zugriff auf FRITZ!Box über MyFRITZ! (Port 47924)

**Lösungsansätze für externen Zugriff**:

1. **IPv6 Portfreigaben** (empfohlen):
   - Direkter Zugriff über IPv6-Adressen
   - Keine NAT-Probleme
   - Moderne Lösung

2. **VPN (später)**:
   - WireGuard oder IPSec VPN
   - Sicherer Zugriff ohne Portfreigaben
   - Zero Trust Networking

3. **MyFRITZ! DynDNS**:
   - Bereits aktiviert
   - Zugriff auf FRITZ!Box von außen möglich
   - Weitere Portfreigaben über MyFRITZ! möglich

4. **Öffentliches IPv4-Subnetz anfragen**:
   - Beim ISP (Vodafone) anfragen
   - Ermöglicht direkte IPv4-Portfreigaben
   - Möglicherweise kostenpflichtig

**Geplante Portfreigaben** (nach Lösung des CGNAT-Problems):
- SSH (Port 22) für Remote-Zugriff auf Server
- Weitere Ports nach Bedarf

**Sicherheitshinweis**: Portfreigaben werden später durch VPN/Zero Trust ersetzt.

### 5.5 Firewall-Regeln

**Aktueller Status**: Standard-FRITZ!Box Firewall aktiv

**Geplante Regeln**:
- Standard: Alle eingehenden Verbindungen blockieren
- Ausnahmen: Nur explizit freigegebene Ports
- Später: VPN-basierter Zugriff statt Portfreigaben

---

## Versionshistorie

### Version 0.2 - Netzwerkanalyse abgeschlossen (2026-03-08)

**Erstellt von**: AI Mentor + Sysadmin Agent

**Inhalt**:
- ✅ Vollständige Netzwerkanalyse durchgeführt
- ✅ Alle Geräte im Netzwerk identifiziert (25+ Geräte)
- ✅ Hardware-Spezifikationen der Mac Mini Cluster Nodes erfasst
- ✅ DHCP- und DNS-Konfiguration dokumentiert
- ✅ Netzwerktopologie vervollständigt
- ✅ CGNAT-Problem identifiziert und dokumentiert
- ✅ IPv6-Verfügbarkeit dokumentiert
- ✅ MyFRITZ! DynDNS dokumentiert
- ✅ Omada Controller und Access Points identifiziert
- ✅ ES216G Switch identifiziert

**Wichtige Erkenntnisse**:
- ⚠️ Carrier-Grade NAT (CGNAT) verhindert IPv4-Portfreigaben
- ✅ IPv6 ist verfügbar für externen Zugriff
- ✅ MyFRITZ! DynDNS aktiviert
- ✅ Omada WLAN-Infrastruktur vorhanden (OC200 + 3x EAP653)
- ✅ TP-Link ES216G Managed Switch vorhanden

**Offene Fragen**:
- Mac Studio IP-Adresse und Hardware-Spezifikationen
- PC Hardware-Spezifikationen und IP-Adressen
- Storage-Kapazitäten der Mac Minis
- Render Farm Software-Details
- Unbekannte Geräte identifizieren (.28, .105, .165, .177)

**Nächste Schritte**:
1. Mac Studio Hardware-Spezifikationen erfassen
2. PC Hardware-Spezifikationen erfassen
3. Unbekannte Geräte identifizieren
4. Render Farm Dokumentation beginnen
5. Version 0.3: Netzwerkzugriff von außen (IPv6 oder VPN)

---

### Version 0.1 - Initiale Infrastruktur (2026-03-08)

**Erstellt von**: AI Mentor + Sysadmin Agent

**Inhalt**:
- Projektübersicht und Lernziele
- Dokumentation der aktuellen Infrastruktur
- Netzwerktopologie (erste Version)
- Hardware-Inventar (teilweise)
- Netzwerkgrundlagen (Grundlagen)

---

## Anhang

### A. Glossar

- **DHCP**: Dynamic Host Configuration Protocol - automatische IP-Adressvergabe
- **DNS**: Domain Name System - Namensauflösung
- **NAT**: Network Address Translation - Übersetzung zwischen privaten und öffentlichen IPs
- **CGNAT**: Carrier-Grade NAT - NAT auf ISP-Ebene, verhindert direkten IPv4-Zugriff
- **VLAN**: Virtual Local Area Network - logische Netzwerksegmentierung
- **Subnetz**: Teilnetzwerk innerhalb eines größeren Netzwerks
- **MyFRITZ!**: DynDNS-Service von AVM für FRITZ!Box-Router
- **Omada**: TP-Link's zentralisierte Netzwerkverwaltungsplattform
- **EAP**: Enterprise Access Point - professionelle WLAN-Access-Points

### B. Nützliche Befehle

#### Netzwerkscan (macOS/Linux)
```bash
# Alle Geräte im Netzwerk scannen
nmap -sn 192.168.178.0/24

# Detaillierter Scan eines Hosts
nmap -A 192.168.178.1
```

#### IP-Konfiguration anzeigen
```bash
# macOS
ifconfig

# Linux
ip addr show
```

#### Routing-Tabelle anzeigen
```bash
# macOS/Linux
netstat -rn
# oder
route -n
```

#### DNS-Auflösung testen
```bash
# Hostname auflösen
nslookup hostname
# oder
dig hostname
```

---

## 6. Netzwerkzugriff von außen

### 6.1 Aktuelle Situation

**Problem**: Carrier-Grade NAT (CGNAT) verhindert direkten IPv4-Zugriff von außen.

**Verfügbare Lösungen**:
1. ✅ IPv6 (bereits verfügbar)
2. ✅ MyFRITZ! DynDNS (bereits aktiviert)
3. ⚪ VPN (geplant für Phase 8)
4. ⚪ Öffentliches IPv4-Subnetz beim ISP anfragen

### 6.2 IPv6 Zugriff

**IPv6-Adresse der FRITZ!Box**: `2a00:1f:3204:0000::1`

**Vorteile**:
- Direkter Zugriff ohne NAT-Probleme
- Moderne Lösung
- Keine zusätzlichen Kosten

**Nachteile**:
- Client muss IPv6 unterstützen
- Nicht alle Netzwerke haben IPv6

### 6.3 MyFRITZ! DynDNS

**Domain**: `475cdg2rogmn8yah.myfritz.net`  
**HTTPS-Port**: `47924`

**Zugriff**: `https://475cdg2rogmn8yah.myfritz.net:47924`

**Funktionen**:
- Zugriff auf FRITZ!Box von außen
- Weitere Portfreigaben möglich
- Automatische IP-Updates

### 6.4 Geplante Implementierung (Version 0.3)

- IPv6-Portfreigaben konfigurieren
- SSH-Zugriff über IPv6 einrichten
- VPN-Vorbereitung (Phase 8)

---

**Ende Version 0.2**
