# Modul 09: Cortex-Mesh mit Tailscale — Drei Macs, ein Netz

**Dauer**: 30 Minuten Lesezeit, plus ~5 Min Setup pro Gerät
**Schwierigkeit**: ⭐⭐⭐ Mittel bis Fortgeschritten
**Voraussetzungen**: Modul 02 (Netzwerk-Grundlagen), Modul 03 (IP-Adressen), Modul 08 (CGNAT)
**Version**: 0.2 · Stand: 2026-04-30

> Dieses Tutorial dokumentiert exakt die Einrichtung, die Claude in der Session
> vom 2026-04-20 + 2026-04-21 für den Cortex-Mesh zwischen `cluster-mini-02`,
> `praxis-studio` und `macbookpro-intel` durchgeführt hat. Sie sollen jeden Schritt
> nachvollziehen und bei zukünftigen Geräten selbst wiederholen können.

---

## 📚 Teil 1 — Theorie

### Was ist der Cortex-Mesh?

Ein **Mesh-Netzwerk** verbindet alle Geräte so miteinander, dass jedes jedes andere
direkt erreicht — unabhängig vom Standort, NAT, Firewall oder Mobilfunk.
Technisch nutzen wir **Tailscale**, eine kommerzielle Abstraktion über
**WireGuard** (Open-Source-VPN).

Konkret heißt das für Sie: Von jedem Ihrer Macs aus können Sie per

```bash
ssh home   # erreicht den Mac Mini zu Hause
ssh praxis # erreicht das MacBook Pro in der Praxis
ssh studio # erreicht den Mac Studio in Zi2
```

auf jeden anderen zugreifen. **Ohne** Portfreigabe an der FRITZ!Box. **Ohne** VPN-Konfiguration.
**Ohne** DynDNS-Bastelei (das war 2026-04-08 noch ein Thema — siehe Modul 08).

### Warum Tailscale und nicht klassisch VPN?

| Kriterium | Klassisches VPN (z.B. WireGuard selbst) | Tailscale |
|---|---|---|
| Server nötig? | ja, mindestens einer mit öffentlicher IP | nein |
| NAT/CGNAT-Traversierung | nur mit öffentlicher IP | automatisch (DERP-Relay + STUN) |
| iOS-/iPadOS-Client | WireGuard-App, manuelle Konfig | Tailscale-App + Login |
| Geräte-ACL | Firewall-Regeln, manuell | Tag-basiert, JSON-Policy |
| Kosten (bei 2 Usern, <10 Geräten) | 0 € + Zeit | 0 € (Free-Tier) |
| Vendor-Lock-In | niedrig | höher (aber mit klarem Exit zu **Headscale**, einer Open-Source-Variante) |

Die Entscheidung ist in `Nexus/specs/cortex-mesh/00_KONZEPT.md` §1 und §7 dokumentiert,
inklusive Migrationspfad zu selbstgehostetem **Headscale** auf einem Proxmox-VM,
falls wir später vom Tailscale-Cloud-Dienst weg wollen.

### Die vier Schichten (aus 00_KONZEPT.md §3)

```
┌─────────────────────────────────────────────────────┐
│ Schicht 4: Nexus-Leitstand (devices.json, nx-*.sh)   │   (Phase 4, später)
├─────────────────────────────────────────────────────┤
│ Schicht 3: GUI-Remote-Desktop                        │   (Phase 3, später)
├─────────────────────────────────────────────────────┤
│ Schicht 2: Terminal-Access                           │   heute: ✅
│  (~/.ssh/config, cc-session.sh, tmux, mosh)          │
├─────────────────────────────────────────────────────┤
│ Schicht 1: Transport = Tailscale                     │   heute: ✅
│  (WireGuard-Mesh, P2P mit DERP-Fallback)             │
└─────────────────────────────────────────────────────┘
```

**Was heute (2026-04-21) steht:** Schichten 1 und 2 funktionieren produktiv zwischen
`cluster-mini-02` und `praxis-studio`. `macbookpro-intel` (MacBook Pro) wartet auf die 5-Minuten-
Einrichtung nach `PRAXIS_MAC_ANLEITUNG.md`.

---

## 📚 Teil 2 — Die Architektur-Entscheidungen

Diese Entscheidungen wurden 2026-04-20 getroffen und sind **eingefroren**.
Wenn Sie später ein weiteres Gerät hinzufügen, gelten sie unverändert:

| # | Frage | Entscheidung | Warum |
|---|---|---|---|
| 1 | Identity-Provider | **Apple-ID** | Datensparsam (Private Relay), auf allen Geräten aktiv |
| 2 | Tailnet-Name | ~~**`cortex`**~~ → **`piranha-marlin.ts.net`** | Wunschname `cortex` war auf Tailscale-Personal-Plan nicht wählbar (nur 4 Random-Fun-Names). Siehe Fallstrick 4. |
| 3 | Gerätenamen | ~~Schema `<ort>-<typ>`~~ → **Schema `<typ>-<subtyp>-<nr>` bzw. `<typ>-<chip>`** (Revision 2026-04-21 abends) | `cluster-mini-02` (3 Minis geplant), `macbookpro-intel` (Silicon-MBP folgt), `praxis-studio` (Ort-Typ, passt weiterhin). |
| 4 | ACL-Struktur | **Hierarchische Tags** | Neues Gerät = nur Tag setzen, nie Policy ändern |
| 5 | SSH-Auth | `tailscale ssh` primär, ed25519 fallback | Keine Keys auf iOS, Fallback bei Tailscale-Ausfall |
| 6 | Tailscale-Installation | **Homebrew Formula**, NICHT Cask | (siehe „Fallstrick 1" unten) |

Das Zusammenspiel ist die Kernidee: **ACLs werden zwischen Tag-Gruppen formuliert, nicht zwischen einzelnen Geräten.**
Die Regel lautet:

```
tag:cortex-host-mac  ↔  tag:cortex-host-mac   # jeder Mac spricht mit jedem Mac
tag:cortex-client-ios → tag:cortex-host-mac   # iOS-Clients dürfen zu Macs
```

Damit haben wir **Full-Mesh zwischen allen Macs automatisch** — das ist es, was Sie
am 2026-04-21 angefordert haben („jeder Rechner mit dem jeweils anderen"). Wenn nächste
Woche ein vierter Mac dazukommt, bekommt er einfach das Tag `tag:cortex-host-mac` — **fertig**,
keine Policy-Änderung nötig.

---

## 🛠 Teil 3 — Die Einrichtung pro Gerät (exakt so, wie heute durchgeführt)

### Schritt 1 — Was Claude auf Ihrem Gerät vorbereitet (ohne Passwort nötig)

Diese Schritte habe ich am 2026-04-21 auf `praxis-studio` ausgeführt und
sie sind **plattform-agnostisch** — auf jedem Mac identisch:

**a) Homebrew-Formula-Installation (nicht Cask!):**

```bash
brew install tmux mosh tailscale
```

`tailscale` (das Command-Line-Tool) und `tailscaled` (der Daemon) landen in
`/opt/homebrew/bin/` (Apple Silicon) bzw. `/usr/local/bin/` (Intel).

**b) SSH-Config-Block in `~/.ssh/config`:**

```ssh-config
# === Cortex-Mesh ===
Host studio praxis-studio praxis-studio.piranha-marlin.ts.net
  HostName 100.119.241.21
  User zimmer2

Host home cluster-mini-02 cluster-mini-02.piranha-marlin.ts.net
  HostName 100.127.125.48
  User cluster-mini-02

Host praxis macbookpro-intel macbookpro-intel.piranha-marlin.ts.net
  HostName macbookpro-intel.piranha-marlin.ts.net
  User ssmd

Host *.piranha-marlin.ts.net home cluster-mini-02 praxis macbookpro-intel studio praxis-studio
  ServerAliveInterval 60
  ServerAliveCountMax 3
  TCPKeepAlive yes
```

**Warum IPs statt DNS-Namen?** MagicDNS auflöst `<name>.piranha-marlin.ts.net` nur
dann, wenn der Client eingebucht ist und der Tailnet-Admin MagicDNS aktiviert hat.
Solange das nicht der Fall ist oder der Tailnet-Cache noch alt ist, funktionieren
Namens-Resolutionen nicht. Tailscale-IPs im `100.x`-Bereich sind dagegen **pro Gerät
stabil** innerhalb eines Tailnets — solange das Gerät nicht entfernt wird, behält
es seine IP. Deshalb die `HostName 100.x.y.z`-Zeilen als robusteste Variante.

**c) `~/bin/cc-session.sh` (tmux-Helper, siehe Teil 5):**

Wird hochkopiert und ausführbar gemacht. Enthält die Projektpfad-Mapping-Tabelle.

**d) `~/.zshenv` ergänzen, damit `~/bin` im PATH liegt:**

```zsh
case ":$PATH:" in
  *":$HOME/bin:"*) ;;
  *) export PATH="$HOME/bin:$PATH" ;;
esac
```

**Warum `~/.zshenv` und nicht `~/.zshrc`?** `ssh host cc-session.sh …` ruft
eine **non-interactive, non-login** shell auf. Für die liest zsh NUR `~/.zshenv`,
nicht `~/.zshrc` oder `~/.zprofile`. Wenn `~/bin` nicht in `~/.zshenv` steht,
muss man bei jeder SSH-Invocation den vollen Pfad `~/bin/cc-session.sh` angeben.

### Schritt 2 — Was Sie am Gerät ausführen müssen (einmalig, mit Passwort)

Drei Befehle in Terminal.app:

```bash
sudo tailscaled install-system-daemon
sudo tailscale up --hostname=<gerätename> --ssh --accept-routes
tailscale status
```

**Was jede Zeile tut:**

- `tailscaled install-system-daemon` registriert Tailscale als macOS-LaunchDaemon.
  Das ist **nicht** der Menüleisten-App-Weg — die App läuft in einer Sandbox,
  die `--ssh` blockiert. Siehe „Fallstrick 1".
- `tailscale up --hostname=<name> --ssh --accept-routes`:
  - `--hostname` setzt den Namen im Tailnet (bei uns `praxis-studio` für Zi2-Mac Studio)
  - `--ssh` aktiviert den Tailscale-SSH-Server (ersetzt klassischen OpenSSH auf Port 22)
  - `--accept-routes` bereitet die spätere Proxmox-Subnet-Route vor
- Der Befehl zeigt eine Zeile `To authenticate, visit: https://login.tailscale.com/a/XXXX`.
  ⌘-Doppelklick öffnet Safari → „Sign in with Apple" → fertig.
- `tailscale status` verifiziert: Sie sehen alle Geräte mit `100.x.y.z`-IPs.

### Schritt 3 — Nach-Arbeit in der Admin-Konsole (einmalig, Browser)

Diese Klicks kann Claude nicht durchführen, weil sie einen eingeloggten Browser
mit Apple-ID-Session verlangen:

| # | URL | Aktion |
|---|---|---|
| 1 | [admin/settings/general](https://login.tailscale.com/admin/settings/general) | Tailnet-Name aus 4 Random-Fun-Names wählen (siehe Fallstrick 4). Am 2026-04-21 abends auf `piranha-marlin.ts.net` gesetzt. |
| 2 | [admin/dns](https://login.tailscale.com/admin/dns) | MagicDNS-Toggle aktivieren |
| 3 | [admin/machines](https://login.tailscale.com/admin/machines) | Tags `tag:cortex-admin`, `tag:cortex-host-mac` jedem Gerät zuweisen |
| 4 | [admin/acls](https://login.tailscale.com/admin/acls) | Policy-JSON aus `01_PHASE1_TRANSPORT.md §2.4` einspielen |

Nach Punkt 1+2 funktionieren die Kurznamen (`ssh home` → `cluster-mini-02.piranha-marlin.ts.net` → 100.89.x.x)
ohne IP-Fallback. Nach Punkt 3+4 greift die Tag-basierte ACL.

---

## ⚠️ Teil 4 — Drei Fallstricke, die wir live getroffen haben

### Fallstrick 1 — macOS-Tailscale-Cask blockiert SSH-Server

**Was passiert ist (2026-04-20 auf cluster-mini-02):**
`brew install --cask tailscale` installiert die Menüleisten-App. Die läuft in einer
**macOS App-Sandbox** und verweigert den SSH-Server-Start:

```
The Tailscale SSH server does not run in sandboxed Tailscale GUI builds.
```

Selbst wenn man danach die Formula installiert, blockiert die **System-Extension**
der GUI-App (`io.tailscale.ipn.macsys.network-extension`) weiter. **Reboot ist
zwingend**, um die Extension sauber zu entladen.

**Korrektur-Prozedur** (falls jemand aus Versehen den Cask-Weg nimmt):

```bash
sudo rm -rf /Applications/Tailscale.app
sudo pkill Tailscale 2>/dev/null
# REBOOT
sudo tailscaled install-system-daemon
sudo tailscale up --hostname=<name> --ssh --accept-routes
```

**Regel:** Auf macOS **immer Formula**, nie Cask. Die `PRAXIS_MAC_ANLEITUNG.md` und
`MAC_STUDIO_ANLEITUNG.md` beginnen deshalb mit `brew install tailscale` (ohne `--cask`).

Pattern: `Nexus/_memory/patterns/macos-tailscale-cask-sandbox-blocks-ssh.md`.

### Fallstrick 2 — `tailscale ssh` mappt User 1:1 und scheitert bei Usernamen-Mismatch

**Was passiert ist (2026-04-21 beim ersten SSH-Test Studio → Home):**

```bash
# Studio-User ist "zimmer2", Home-User ist "cluster-mini-02".
ssh 100.127.125.48
# tailscale: failed to look up local user "zimmer2"
# Connection closed by 100.127.125.48 port 22
```

**Warum:** `tailscale ssh` nimmt den **lokalen User des Aufrufers** und sucht den
gleichen Namen auf dem Ziel. Existiert er nicht → Abbruch.

**Lösung:** User explizit angeben:

```bash
ssh cluster-mini-02@100.127.125.48   # → funktioniert
```

Bzw. in der SSH-Config fest verdrahten:

```ssh-config
Host home
  HostName 100.127.125.48
  User cluster-mini-02
```

Dann reicht `ssh home`.

**Warum das Tutorial das erwähnt:** Wenn Sie selbst einen neuen Mac einbinden
(z.B. ein privates MacBook mit anderem Benutzernamen), müssen Sie den
Host-Block pro Zielgerät mit dem **Remote-Username** bestücken. Das ist auch
der Grund, warum `devices.json` das Feld `network.ssh_user` pro Gerät
führt — es ist nicht der lokale User, sondern der Ziel-User.

### Fallstrick 4 — Tailnet-Name auf Personal-Plan nicht frei wählbar

**Was passiert ist (2026-04-21 abends):** Wunschname `cortex` für das Tailnet im
Admin-Panel eingetragen → Dialog zeigt nur 4 zufällige Tier-Wortpaare zur Auswahl
(`grolar-larch`, `leopon-catla`, `sturgeon-mora`, `wholphin-tuatara`, `piranha-marlin`).
Freie Namenswahl gibt's erst ab Starter-Plan (~6 $/User·Monat).

**Konsequenz:** Wir haben `piranha-marlin.ts.net` gewählt (Option B). Der DNS-Suffix
taucht nur in FQDNs auf, die man selten tippt — Kurznamen `cluster-mini-02`,
`praxis-studio`, `macbookpro-intel` funktionieren über MagicDNS + SSH-Config-Aliases
genauso wie mit einem Wunsch-Namen.

**Warnung im Rename-Dialog:** Wenn der Name in HTTPS-Zertifikaten landet (z.B. via
`tailscale serve` oder `funnel`), wird er **gebunden** — kein zweiter Roll mehr.

**Zukunftspfad:** Bei Skalierung zum Mehrbenutzer-Mesh oder Interesse an ACL-Editor,
Policy-API oder Audit-Log: Upgrade auf Starter. Dann freier Rename auf `cortex`
(oder beliebig) möglich.

### Fallstrick 5 — Periodische Re-Authentifizierung (`checkPeriod`)

**Was passiert ist (2026-04-30, Cluster-Mini-02 → Praxis-Studio):**
Nach einigen Tagen Pause ein simpler `ssh praxis-studio "..."` brachte:

```
# Tailscale SSH requires an additional check.
# To authenticate, visit: https://login.tailscale.com/a/lfbab84f380a61
Connection to 100.119.241.21 port 22 timed out
```

Der TCP-Connect ging durch, aber Tailscale-SSH verlangte eine Browser-Re-Auth.
Bei `BatchMode=yes` (z.B. in Skripten oder von Claude im Hintergrund) gibt's keinen
interaktiven Wartemodus → Timeout → Exit 255.

**Warum:** Die Tailscale-ACL-Policy enthält pro Regel ein Feld `checkPeriod` (z.B.
`"12h"` oder `"7d"`). Nach Ablauf verlangt der **Aufrufer** (nicht das Ziel!) eine
frische Apple-ID-Bestätigung im Browser, bevor SSH-Sessions zustandekommen. Das
ist die zweite Schutzschicht oberhalb der WireGuard-Auth. Standardwert in unserer
Policy ist 12 h für `tag:cortex-admin` (siehe `01_PHASE1_TRANSPORT.md §2.4`).

**Lösung — interaktiv:**

```bash
ssh praxis-studio
# Browser öffnet sich automatisch oder URL erscheint im Terminal.
# Apple-ID-Login → Bestätigung → SSH läuft sofort durch.
```

Der erzeugte Auth-Link ist **5–15 Minuten** gültig. Wer ihn nicht rechtzeitig
öffnet, muss den SSH-Versuch wiederholen, um einen neuen Link zu erzeugen.

**Lösung — nicht-interaktive Skripte:**

```bash
# Vor dem Skript-Lauf einmal von Hand einloggen (ein normaler ssh-Aufruf reicht).
# Die Auth-Session überlebt dann checkPeriod lang für alle weiteren Aufrufe.
ssh praxis-studio 'true'   # interaktiv durch-authen
./mein-skript.sh           # läuft jetzt non-interactive durch
```

**Diagnose-Signal:**

| Symptom | Diagnose |
|---|---|
| Output-Zeile mit `https://login.tailscale.com/a/...` + `Connection ... timed out` | Re-Auth fällig (dieser Fallstrick) |
| `Permission denied (publickey)` | klassisches SSH-Key-Problem (nicht Tailscale-Auth) |
| `Connection refused` | Daemon ist down oder `--ssh` fehlt (siehe Task-Matrix Teil 7) |
| `failed to look up local user` | User-Mismatch (Fallstrick 2) |

**Längere Auth-Sessions (optional):**

In der Admin-Konsole → ACL-Policy → `checkPeriod` z.B. auf `30d` erhöhen.
**Trade-off:** weniger Reib, aber bei verlorenem/gestohlenem Gerät länger
ungeschützter Zugriff bis Tag-Removal greift.

Pattern: `Nexus/_memory/patterns/tailscale-ssh-periodic-recheck.md`.

### Fallstrick 3 — MagicDNS ist standardmäßig in der Admin-Konsole AUS

**Was passiert ist:** `ssh cluster-mini-02.piranha-marlin.ts.net` → `Could not resolve hostname`.

**Warum:** Der Tailscale-Client löst MagicDNS-Namen nur auf, wenn im Tailnet-Admin
der Toggle aktiviert ist. Bei neu angelegten Tailnets ist er standardmäßig AUS.

**Lösung:** Admin-Konsole → [admin/dns](https://login.tailscale.com/admin/dns) → „MagicDNS" → an.

**Zwischenlösung** (wir nutzen sie aktuell): IP-basierte SSH-Config mit
hartcodierten `100.x.y.z`-Adressen. Funktioniert sofort, überlebt Tailnet-Rename
und MagicDNS-Aktivierung als Fallback.

### Fallstrick 6 — Henne-Ei: ACL vor Tags einspielen (gelernt 2026-05-03)

**Was passiert ist:** Beim Versuch, am Gerät über „Edit ACL tags…" einen Tag
zu vergeben, der noch nicht in der Policy als `tagOwners` definiert ist,
verweigert Tailscale: „you are not a tag owner".

**Warum:** Tailscale validiert Tag-Vergabe gegen die Policy. Ein Tag, der
nicht in `tagOwners` deklariert ist, existiert formal nicht — auch wenn die
Admin-Console einen separaten „Create Tag"-Dialog anbietet.

**Lösung:** Reihenfolge umkehren — **erst** ACL-Policy mit `tagOwners` einspielen,
**dann** Tags an Geräten vergeben. Der zusätzliche Klick durch den „Create Tag"-
Dialog ist nicht nötig: Tags entstehen implizit durch ihre Erwähnung in der
Policy.

### Fallstrick 7 — MagicDNS-Toggle existiert nur in der App, nicht in der Formula

**Was passiert ist:** Auf cluster-mini-02 (Tailscale via brew-Formula) sucht
man vergeblich nach einem Tailscale-Menüleisten-Icon — Standard-Anleitungen,
die „Use Tailscale DNS" als Klick-Toggle beschreiben, laufen ins Leere.

**Warum:** Die App-Variante (Cask) liefert die Menüleisten-UI mit, die Formula
liefert nur die CLI. Wir nutzen Formula bewusst, weil die Cask-Sandbox Tailscale-SSH
blockiert (Fallstrick 1).

**Lösung — CLI-Äquivalent:**

```bash
sudo tailscale set --accept-dns=true
```

Verifikation:
```bash
tailscale dns status | grep "Tailscale DNS"
# Erwartet: Tailscale DNS: enabled.
```

**Wichtig zu sudo + Claude-Code:** Der `! sudo …`-Trick im Claude-Code-Prompt hat
kein interaktives Terminal — sudo kann darum keine Passwort-Eingabe abfragen
und scheitert mit „a terminal is required". Sudo-Befehle immer im **separaten
Terminal-Fenster** ausführen.

### Fallstrick 8 — `~/.ssh/config` mit FQDN als HostName ist instabil

**Was passiert ist:** `ssh praxis hostname` schlug fehl mit „Could not resolve
hostname macbookpro-intel.piranha-marlin.ts.net" — obwohl `nslookup` denselben
FQDN gegen `100.100.100.100` erfolgreich auf `100.115.230.94` löst.

**Warum:** macOS-getaddrinfo respektiert Tailscale-Split-DNS für `*.ts.net`-
Suffixe nicht zuverlässig in allen Pfaden. nslookup fragt direkt den
Tailscale-Resolver, ssh nutzt den System-Resolver — die liefern unterschiedliche
Ergebnisse.

**Lösung:** In `~/.ssh/config` für jeden Mesh-Host die **Tailscale-IP** als
`HostName` setzen, nicht den FQDN. Der MagicDNS-Suffix taucht weiterhin in
den `Host`-Aliasen auf, damit die Symmetrie der Config gewahrt bleibt:

```sshconfig
Host praxis macbookpro-intel macbookpro-intel.piranha-marlin.ts.net
  HostName 100.115.230.94          # ← IP, nicht FQDN
  User ssmd
```

IPs sind im Personal-Plan stabil und überleben Tailnet-Renames.

### Fallstrick 9 — Auto-Sync-Drift bei `nexus-sync.sh` ist kein Datenverlust

**Was passiert ist:** Auf macbookpro-intel scheiterte der nexus-sync-Cron
8 Tage lang mit Exit 1 — `git pull --ff-only` blockierte an einer untracked
Datei + 7 modifizierten Files (`Second Brain/10 Projekte/*.md`,
`_memory/pending-instructions.md` u. a.).

**Warum:** Die modifizierten Files sind reiner Output von `sync-second-brain.py`,
das auf jedem Mac alle 5 Minuten läuft und gegen den **lokalen** MEMORY.md-Stand
generiert. Wenn ein Gerät Tage hinter Remote ist, generiert sein Cron Inhalte,
die gegen den Remote-Stand „rückwärts driften".

**Lösung — Auto-Drift-Recovery:**

```bash
# 1. Drift verwerfen (kein Verlust, weil regenerierbar)
git restore .config/heartbeats/<host>.heartbeat \
            "Second Brain/10 Projekte/<projekt>.md" \
            _memory/pending-instructions.md
# 2. identische untracked Symlinks entfernen
rm "Second Brain/90 Sessions/<datum>_<slug>.md"
# 3. Pull
git pull --ff-only
# 4. Verifikation: manueller Sync-Lauf
bash ~/Cortex/Nexus/nexus-sync.sh    # erwartet: SYNC: OK
```

**Erkennungsmerkmal Auto-Drift:** Diff zeigt nur Datums-Bumps und
AUTO-START-Blocks (zwischen `<!-- AUTO-START -->` / `<!-- AUTO-END -->`).
Echter manueller Inhalt steht außerhalb dieser Blöcke.

**Pattern:** `Nexus/_memory/patterns/auto-drift-recovery-via-restore.md` (folgt).

---

## 🧰 Teil 5 — `cc-session.sh` erklärt

Das Skript ist das Herzstück von Phase 2 (Terminal-Access). Zweck:

> **Eine tmux-Session pro Projekt. Überlebt Verbindungsabbrüche.
> Jede SSH-Verbindung attacht an dieselbe Session wie zuvor.**

### Code (Auszug)

```bash
#!/usr/bin/env bash
set -eu
PROJECT="${1:?project name required}"

case "$PROJECT" in
  cortex-web)      DIR="$HOME/Cortex/projects/Cortex-Web" ;;
  praxis-webseite) DIR="$HOME/Local Sites/.../themes/praxiszentrum" ;;
  juvantis)        DIR="$HOME/Cortex/projects/Juvantis" ;;
  # ... weitere Projekte
  *) echo "Unknown project: $PROJECT"; exit 1 ;;
esac

if [ ! -d "$DIR" ]; then
  echo "Projektordner existiert nicht auf diesem Gerät" >&2; exit 2
fi

if tmux has-session -t "$PROJECT" 2>/dev/null; then
  exec tmux attach-session -t "$PROJECT"
else
  exec tmux new-session -s "$PROJECT" -c "$DIR" "claude"
fi
```

### Warum das funktioniert

1. **`exec tmux …`** ersetzt die aktuelle Shell durch tmux. Beim Beenden von tmux
   (z.B. Verbindungsabbruch) läuft die Session **auf dem Remote-Mac weiter**.
2. **`tmux has-session`** unterscheidet: erste Verbindung → neue Session, spätere
   Verbindungen → `attach`. So bekommen Sie immer den exakt gleichen Stand wiederholt.
3. **`claude`** als letztes Argument startet Claude Code im Projekt-Ordner,
   sobald die Session frisch erzeugt wird. Bei `attach` läuft Claude bereits
   oder wurde bewusst beendet — Sie sehen dann die tmux-Bash.

### Typischer Arbeitsablauf

```bash
# Vom Mac Studio Zi2 (Praxis) morgens:
ssh home cc-session.sh cortex-web
# → Verbindet Sie in den Home-Mac, attacht an Cortex-Web-Session
#   (oder erzeugt sie neu, falls erster Start heute)

# … Arbeiten in Claude Code …

# Verbindung trennen ohne Session zu beenden: Strg+B, dann D
# Oder einfach Terminal schließen.

# Mittags vom MacBook Pro (Bus, Café, wherever):
ssh home cc-session.sh cortex-web
# → Exakt die gleiche Session, gleiche Chat-Historie, gleiche offene Edits.
```

### Iterative Projekt-Erweiterung

Neues Projekt dazu? Case-Zweig ergänzen:

```bash
case "$PROJECT" in
  cortex-web)      DIR="$HOME/Cortex/projects/Cortex-Web" ;;
  # ...
  neues-projekt)   DIR="$HOME/Cortex/projects/Neues-Projekt" ;;
  *) echo "Unknown project: $PROJECT"; exit 1 ;;
esac
```

Dann auf allen Macs das Skript aktualisieren (`scp ~/bin/cc-session.sh home:~/bin/`
vom Mac mit der neuesten Version aus). Falls Sie lieber synchronisieren wollen, können wir
das Skript später ins Nexus-Repo umziehen und via `nexus-sync.sh` gleichzeitig verteilen.

---

## ✅ Teil 6 — Verifikations-Befehle

Diese Befehle geben Ihnen jederzeit den Mesh-Status:

```bash
# Alle Geräte im Tailnet
tailscale status

# Nur eigene IPs
tailscale ip -4
tailscale ip -6

# Ping über Mesh (zeigt ob P2P-direkt oder DERP-Relay)
tailscale ping cluster-mini-02

# SSH-Konnektivität nicht-interaktiv
ssh -o BatchMode=yes home 'hostname; whoami'

# Remote Skript-Exit-Code
ssh home '~/bin/cc-session.sh nonexistent'
# Erwartet: "Unknown project" + Liste, EXIT=1
```

### Live-verifiziert am 2026-04-21

| Test | Ergebnis |
|---|---|
| `tailscale ping cluster-mini-02` (aus Studio) | pong via DERP(fra), 5/5, ~210ms |
| `ssh home 'hostname'` | `Cluster-Mini-02.local` |
| `ssh home '~/bin/cc-session.sh nonexistent'` | Unknown project + 9-Projekt-Liste, EXIT=1 |

---

## 🎯 Teil 7 — Praxis-Task-Matrix

**„Ich sitze am Mac Studio und will am Cortex-Web-Projekt arbeiten, das nur auf dem Home-Mac liegt."**
→ `ssh home cc-session.sh cortex-web`

**„Ich fahre in die Praxis, will aber meinen Cortex-Web-Chat vom Home-Mac weiterführen."**
→ Am Home-Mac: `cc-session.sh cortex-web` → tmux-Session läuft weiter.
→ In der Praxis vom Mac Studio: `ssh home cc-session.sh cortex-web` → attacht an dieselbe Session.

**„Der Mac ist neu, wie binde ich ihn ein?"**
→ `brew install tmux mosh tailscale` → `sudo tailscaled install-system-daemon`
→ `sudo tailscale up --hostname=<ort>-<typ> --ssh --accept-routes` → Safari-Login
→ `scp cc-session.sh <hostname>:~/bin/` von einem bereits eingerichteten Gerät.
→ SSH-Config-Block dorthin kopieren, Tag `tag:cortex-host-mac` setzen.

**„Tailscale zeigt einen `100.x`-Ping, aber SSH timeoutet."**
→ Vermutlich `--ssh`-Flag fehlt. `sudo tailscale set --ssh` nachholen.
→ Oder: klassisches macOS-Remote-Login ist aus (wir nutzen es bewusst nicht, siehe Fallstrick 2).

**„Ich will aus dem Handy-Hotspot von unterwegs verbinden."**
→ Sollte direkt funktionieren. Tailscale traversiert CGNAT und Hotel-WLANs automatisch
(notfalls via DERP-Relay, was nur minimalen Latenz-Impact hat).

---

## 📎 Teil 8 — Weiterführende Dokumente

- **Konzept + Roadmap:** `Nexus/specs/cortex-mesh/00_KONZEPT.md`
- **Phase-1-Spec (Transport):** `Nexus/specs/cortex-mesh/01_PHASE1_TRANSPORT.md` — enthält ACL-Policy-JSON
- **Phase-2-Spec (Terminal):** `Nexus/specs/cortex-mesh/02_PHASE2_TERMINAL.md` — enthält iOS-App-Vergleichstabelle
- **Klick-Anleitungen pro Gerät:**
  - `Nexus/specs/cortex-mesh/MAC_STUDIO_ANLEITUNG.md`
  - `Nexus/specs/cortex-mesh/PRAXIS_MAC_ANLEITUNG.md`
- **Wiedereinstiegs-Anleitung nach Pause:** `Nexus/specs/cortex-mesh/RESUME.md` (Blocker-Matrix pro Gerät)
- **Pattern:** `Nexus/_memory/patterns/macos-tailscale-cask-sandbox-blocks-ssh.md`
- **Pattern:** `Nexus/_memory/patterns/tailscale-ssh-cross-user-mapping.md`
- **Pattern:** `Nexus/_memory/patterns/tailscale-ssh-periodic-recheck.md`
- **Session-Logs:**
  - `Nexus/_memory/logs/2026-04-20_cortex-mesh-phase1-phase2.md` (Tag 1, Home-Mac-Setup, Cask-Falle)
  - `Nexus/_memory/logs/2026-04-21_cortex-mesh-mac-studio-prep.md` (Tag 2, Mac-Studio + Remote-Home-Finalisierung)
- **Devices-Registry:** `Nexus/.config/devices.json` (Network-Block pro Gerät)

---

## 🔮 Teil 9 — Was als Nächstes passiert

**Noch offen (Stand 2026-04-21):**

1. **Praxis-Mac (MacBook Pro):** 5-Minuten-Einrichtung in der Praxis (folgen `PRAXIS_MAC_ANLEITUNG.md`). Dann Full-Mesh über 3 Macs.
2. **iPhone + iPad:** App Store → Tailscale → Login. Separate Mini-Phase, nicht zeitkritisch.
3. **Admin-Console-Pflege:** MagicDNS an, ACL-Policy einspielen, Tags setzen. (Tailnet-Rename auf `piranha-marlin.ts.net` bereits am 2026-04-21 abends erfolgt — siehe Fallstrick 4.)
4. **Phase 3 (GUI-Remote-Desktop):** Kandidaten sind macOS Screen Sharing (VNC, kommt gratis), NoMachine (schnell), RustDesk (self-hosted). Entscheidung steht noch aus.
5. **Phase 4 (Nexus-Leitstand):** `nx`-Skripte (`nx ssh`, `nx status`, `nx exec`), Obsidian-Dashboard mit Live-Status.
6. **Phase 5a (Proxmox-Integration):** Praxis-Proxmox-Host ins Mesh, kritische VMs ebenfalls — ermöglicht Docker-Container etc. direkt per `ssh proxmox`.
7. **Phase 5c (Migration zu Headscale):** Selbstgehosteter Tailscale-Server auf Proxmox, sobald die Infrastruktur steht.

**Nicht geplant:** Klassisches Port-Forwarding an der FRITZ!Box. Tailscale löst das Problem eleganter und CGNAT-kompatibel.

---

*Dieses Tutorial wird weitergepflegt, wann immer Änderungen an Mesh-Architektur, ACL oder Tooling erfolgen. Aktuelle Version: siehe Dateiname und Versionszeile oben.*
