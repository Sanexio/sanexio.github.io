# Proxmox Tutorial 04 — Netzwerk

> **Voraussetzungen:** 01-grundlagen.md, Netzwerk-Grundlagen (`_tutorials/netzwerk-sysadmin/`)
> **Ziel:** Netzwerk-Bridges, VLANs und Firewall in Proxmox konfigurieren.

---

## Netzwerk-Grundlagen in Proxmox

Proxmox verbindet VMs und Container über **virtuelle Bridges** (Netzwerkbrücken)
mit dem physischen Netzwerk. Eine Bridge funktioniert wie ein virtueller Switch:
Alle VMs, die an der gleichen Bridge hängen, können miteinander kommunizieren.

### Standard-Setup

Nach der Installation hat Proxmox eine Bridge namens `vmbr0`, die an die
physische Netzwerkkarte gebunden ist:

```
Internet ←→ Router/Firewall ←→ physischer Switch ←→ Server (eth0)
                                                        ↓
                                                     vmbr0 (Bridge)
                                                    ↙   ↓   ↘
                                                 VM1   VM2   CT1
```

Alle VMs und Container auf `vmbr0` sind im gleichen Netzwerk wie der
physische Server — sie bekommen IPs aus dem gleichen Bereich.

## Bridges konfigurieren

### Neue Bridge erstellen (Web-Interface)

1. **Node** → **Network** Tab
2. **Create** → **Linux Bridge**
3. Einstellungen:
   - Name: `vmbr1` (fortlaufende Nummerierung)
   - IPv4/CIDR: z.B. `10.10.10.1/24` (Gateway für VMs auf dieser Bridge)
   - Bridge ports: leer lassen (kein physischer Port = isoliertes Netzwerk)
4. **Create** → **Apply Configuration**

### Wann braucht man mehrere Bridges?

- **vmbr0:** Produktiv-Netzwerk (Server, die ins LAN müssen)
- **vmbr1:** Management-Netzwerk (nur für Admin-Zugriff)
- **vmbr2:** Isoliertes Test-Netzwerk (VMs können nur untereinander kommunizieren)
- **vmbr3:** DMZ (Dienste, die von außen erreichbar sein sollen)

## VLANs — Netzwerk-Segmentierung

VLANs (Virtual LANs) trennen Netzwerke logisch, ohne extra Kabel. In der Praxis
sinnvoll für:

- **VLAN 10:** Server (DC, Fileserver)
- **VLAN 20:** Arbeitsplätze (PCs, Drucker)
- **VLAN 30:** Medizintechnik (SONO, EKG, Laborgeräte)
- **VLAN 40:** WLAN / IoT
- **VLAN 50:** Gäste (Internet-Only)

### VLAN-aware Bridge einrichten

1. Node → Network → `vmbr0` bearbeiten
2. **VLAN aware** Checkbox aktivieren
3. Apply Configuration

Jetzt können VMs beim Erstellen ein VLAN-Tag bekommen:
- VM → Network → VLAN Tag: `10` (diese VM ist dann in VLAN 10)

### Wichtig

VLANs funktionieren nur, wenn auch der physische Switch VLANs unterstützt
(Managed Switch) und entsprechend konfiguriert ist. Die Firewall (Eterno)
muss als Inter-VLAN-Router agieren.

## Firewall

Proxmox hat eine eingebaute Firewall auf drei Ebenen:

### Ebene 1: Datacenter-Firewall
Gilt für alle Nodes und VMs. Standardmäßig deaktiviert.
Aktivieren: Datacenter → Firewall → Options → Firewall: Yes

### Ebene 2: Node-Firewall
Gilt für den Proxmox-Host selbst.
Aktivieren: Node → Firewall → Options → Firewall: Yes

### Ebene 3: VM/CT-Firewall
Gilt für eine einzelne VM oder einen Container.
Aktivieren: VM → Firewall → Options → Firewall: Yes

### Typische Firewall-Regeln

| Richtung | Quelle | Ziel | Port | Aktion | Zweck |
|----------|--------|------|------|--------|-------|
| IN | Praxis-LAN | Proxmox | 8006 | ACCEPT | Web-Interface |
| IN | Praxis-LAN | Proxmox | 22 | ACCEPT | SSH |
| IN | Any | Proxmox | Any | DROP | Alles andere blocken |
| IN | VLAN 20 | DC (VLAN 10) | 53, 88, 389, 445 | ACCEPT | AD, DNS, SMB |
| IN | VLAN 30 | Any | Any | DROP | Medizintechnik isoliert |

**Vorsicht:** Falsche Firewall-Regeln können dich vom Server aussperren!
Immer erst testen, bevor man `DROP all` aktiviert. Im Notfall: IPMI/BMC-Zugang
nutzen (funktioniert unabhängig von Proxmox).

## WireGuard VPN

Für sicheren Fernzugriff auf den Proxmox-Server (z.B. von zuhause oder unterwegs):

WireGuard ist ein modernes, schnelles VPN-Protokoll. Einrichtung:

1. Entweder auf der Firewall (Eterno) — empfohlen
2. Oder als Container auf Proxmox (z.B. `wg-easy` Docker-Image)

Der VPN-Tunnel verschlüsselt die Verbindung und gibt dir Zugriff auf das
Praxis-Netzwerk, als wärst du vor Ort.

---

## Nächste Schritte

- **05-sicherheit.md** — Zugriffsschutz, Updates, Hardening
- **06-monitoring-und-wartung.md** — Server überwachen
