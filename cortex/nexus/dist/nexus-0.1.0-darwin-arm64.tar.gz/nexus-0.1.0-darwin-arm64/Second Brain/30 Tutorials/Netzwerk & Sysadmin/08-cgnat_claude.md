# CGNAT verstehen — Claude-Workflow

**Einsatzbereich:** Automatische Netzwerk-Erreichbarkeits-Tests, IPv6-Konfiguration, VPN-Vorbereitung

**Wann ist dieser Workflow sinnvoll?**
- Du möchtest automatisch testen, ob CGNAT dein Netzwerk beeinflusst
- Du brauchst IPv6-Erreichbarkeitstests von außen
- Du möchtest ein Fallback-System für externen Zugriff vorbereiten
- Du brauchst Monitoring für Portfreigabe-Funktionalität

---

## Szenario

Dr. Stracke möchte wissen, ob sein Netzwerk von außen über IPv6 erreichbar ist. Er möchte auch ein Monitoring-System, das regelmäßig überprüft, ob IPv6-Zugriff funktioniert.

---

## Workflow-Schritte

### 1. IPv6-Erreichbarkeitstests

Claude erstellt ein Skript, das:
- Testet, ob Router über IPv6 erreichbar ist
- SSH-Zugriff via IPv6 überprüft
- Web-Zugriff via IPv6 checkt
- Ergebnisse loggt

**Aufruf:**
```bash
python3 scripts/ipv6_reachability_test.py
```

**Ergebnis:**
```
IPv6-Erreichbarkeits-Tests (2026-04-03 10:30 UTC)
================================================

FRITZ!Box IPv6: 2a00:1f:3204:0000::1

Ping über IPv6:
✅ 2a00:1f:3204:0000::1 ist erreichbar (lokal)

SSH über IPv6 (aus Netzwerk):
✅ ssh://[2a00:1f:3204:0000::1] funktioniert

MyFRITZ! Domain:
✅ 475cdg2rogmn8yah.myfritz.net:47924 erreichbar

Status: IPv6 Zugriff funktioniert ✅
```

### 2. CGNAT-Diagnose-Skript

Claude erstellt ein Skript, das:
- Öffentliche IP-Adresse abruft
- Prüft, ob es eine private Range ist
- Warnt vor CGNAT-Problemen
- Empfiehlt Lösungen

**Aufruf:**
```bash
python3 scripts/cgnat_detection.py
```

**Ergebnis:**
```
Öffentliche IP-Adresse: 203.0.113.42
IP-Range: Nicht in privater Range ✅

CGNAT-Status: ⚠️ WAHRSCHEINLICH AKTIV
Begründung: Keine direkte öffentliche IPv4-Portfreigabe

Verfügbare Lösungen:
1. ✅ IPv6 (bereits verfügbar)
2. ✅ MyFRITZ! (bereits konfiguriert)
3. ⚪ VPN (geplant für Phase 8)
4. ⚪ Öffentliches IPv4-Subnetz (beim ISP anfragen)

Empfehlung: Verwende IPv6 für externen Zugriff
```

### 3. MyFRITZ! Funktionsprüfung

Claude erstellt Skripts für:
- Test der MyFRITZ!-Domain-Erreichbarkeit
- Automatische Zertifikat-Überwachung
- DynDNS-Updates prüfen

**Aufruf:**
```bash
python3 scripts/myfritz_check.py
```

**Ergebnis:**
```
MyFRITZ! Status Check
====================
Domain: 475cdg2rogmn8yah.myfritz.net
Port: 47924

DNS-Auflösung: ✅ Funktioniert
Zertifikat: ✅ Gültig (bis 2027-03-04)
HTTPS-Verbindung: ✅ Funktioniert
DynDNS Update: ✅ Aktuell

Status: MyFRITZ! vollständig funktionsfähig ✅
```

### 4. IPv6-Adress-Tracking

Claude erstellt Überwachung für:
- IPv6-Präfix-Änderungen
- Neue IPv6-Adressen erkennen
- IPv6-Konfiguration validieren

**Aufruf:**
```bash
python3 scripts/ipv6_monitor.py --router 192.168.178.1
```

**Ergebnis:**
```
IPv6-Konfiguration
==================
Global Unicast: 2a00:1f:3204:0000::1 ✅
Link-Local: fe80::1 ✅
Präfix: 2a00:1f:3204:0000::/64 ✅

Stabilität: Stabil (keine Änderungen letzte 30 Tage) ✅
```

---

## Wichtige Befehle für Automation

```bash
# Öffentliche IPv4-Adresse prüfen
curl ifconfig.me

# IPv6-Adresse prüfen
curl -6 ifconfig.me

# Router via IPv6 pingen
ping6 2a00:1f:3204:0000::1

# SSH über IPv6 testen
ssh -6 admin@2a00:1f:3204:0000::1

# MyFRITZ! Domain auflösen
nslookup 475cdg2rogmn8yah.myfritz.net
```

---

## Wann nutzt man diesen Workflow?

✅ **Nutze Claude-Automation:**
- Regelmäßige IPv6-Tests
- Monitoring von Zugriff von außen
- Automatische MyFRITZ!-Prüfung
- Historische Daten für Zuverlässigkeit
- Alerts bei Ausfällen

❌ **Nutze stattdessen manuelle Tests (Modul 08-cgnat_manuell.md):**
- Einmalige Überprüfung
- Ad-hoc Diagnose
- Manuelle Troubleshooting

---

## Typisches Workflow-Beispiel

**Szenario:** Täglich um 10:00 UTC

**Mit Claude-Automation:**
1. IPv6-Erreichbarkeit testen
2. MyFRITZ! prüfen
3. Öffentliche IP abrufen
4. CGNAT-Status überprüfen
5. Report erstellen:
   ```
   ✅ IPv6 Zugriff funktioniert
   ✅ MyFRITZ! aktiv
   ✅ Öffentliche IP stabil
   ⚠️ CGNAT aktiv (normal)
   ```

6. Falls Problem: Alert senden

---

## Beste Praktiken

1. **IPv6 nutzen:** Für externen Zugriff empfohlen
2. **MyFRITZ! als Fallback:** Für FRITZ!Box-Zugriff
3. **Tägliche Checks:** Zuverlässigkeit monitoren
4. **VPN später:** Phase 8 für Zero Trust Access
5. **ISP kontaktieren:** Falls öffentliche IPv4 nötig

---

**Nächster Schritt:** Siehe Modul 08-cgnat_manuell.md für manuelle Diagnose und Troubleshooting.
