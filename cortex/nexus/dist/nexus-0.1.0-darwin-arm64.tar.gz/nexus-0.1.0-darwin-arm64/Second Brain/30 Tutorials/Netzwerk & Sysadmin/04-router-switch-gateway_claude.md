# Router, Switch und Gateway — Claude-Workflow

**Einsatzbereich:** Automatische Netzwerk-Diagnose, Konfigurationsanalyse, Routing-Optimierung

**Wann ist dieser Workflow sinnvoll?**
- Du möchtest den Router automatisch monitoren (Status, CPU, RAM)
- Du brauchst ein Skript für Routing-Tabellen-Analyse
- Du möchtest Switch-Port-Auslastung tracken
- Du brauchst automatische KonfigurationsBackups des Routers
- Du möchtest Gateway-Durchsatz (Bandbreite) messen und grafisch darstellen

---

## Szenario

Dr. Stracke möchte wissen, wie viel Bandbreite der Router aktuell nutzt und ob der Internet-Zugang optimal läuft. Statt manuell in die FRITZ!Box zu schauen, sollen regelmäßige Reports mit Grafiken erstellt werden.

---

## Workflow-Schritte

### 1. Router-Diagnose-Skript (Python)

Claude erstellt ein Skript, das:
- Sich zur FRITZ!Box verbindet (UPnP/TR-064 API)
- Aktuelle Throughput-Werte ausliest
- CPU-, RAM- und Temperature-Infos abruft
- DHCP-Lease-Informationen zeigt
- Ergebnisse in JSON speichert

**Aufruf:**
```bash
python3 scripts/router_diagnostics.py --router 192.168.178.1
```

**Ergebnis:**
```json
{
  "router": "FRITZ!Box 7530 AX",
  "timestamp": "2026-04-03T10:30:00Z",
  "connection": {
    "downstream_mbps": 150,
    "upstream_mbps": 20,
    "status": "connected"
  },
  "system": {
    "cpu_percent": 35,
    "ram_percent": 62,
    "temperature_c": 48
  },
  "dhcp": {
    "active_clients": 28,
    "lease_duration_hours": 240
  }
}
```

### 2. Routing-Tabellen-Analyse (Python)

Claude erstellt Skripte für:
- Abrufen der Routing-Tabelle
- Analyse der Default Route
- Erkennung von Routing-Problemen
- Vergleich mit vorherigen Konfigurationen

**Aufruf:**
```bash
python3 scripts/routing_analysis.py --show-all
```

**Ergebnis:**
```
Routing-Tabelle
===============
Destination       Gateway         Interface  Status
0.0.0.0/0        192.168.178.1    eth0       ✅ Active (Default)
192.168.178.0/24 192.168.178.1    eth0       ✅ Direct
127.0.0.1        127.0.0.1        lo         ✅ Loopback
```

### 3. Switch-Port-Monitoring (SNMP)

Claude erstellt Skripte für:
- Abfrage der Switch-Port-Status via SNMP
- Erkennung von aktiven vs. inaktiven Ports
- Auslastungsmessung
- Fehlerrate-Tracking

**Aufruf:**
```bash
python3 scripts/switch_monitoring.py --device 192.168.178.96
```

**Beispiel-Output:**
```
TP-Link ES216G Port-Status
==========================
Port 1:  Cluster-Mini-01    192.168.178.29    ✅ UP (1000 Mbps)
Port 2:  Cluster-Mini-02    192.168.178.30    ✅ UP (1000 Mbps)
...
Port 15: Leer              -                   ⚪ DOWN
Port 16: Leer              -                   ⚪ DOWN

Aktive Ports: 14/16
Auslastung: 87%
```

### 4. Automatische Reports und Grafiken

Claude erstellt:
- Tägliche Performance-Reports
- Bandbreitenauslastungs-Grafiken (matplotlib)
- HTML-Dashboards
- PDF-Reports für Dr. Stracke

**Beispiel-Grafik:**
```
Bandbreite letzte 24 Stunden
============================
200 |       ╭─────╮
    |      ╱       ╲
150 |     ╱         ╲
    |    ╱           ╲
100 |───╱             ╲───
    |
 50 |
    |
  0 └─────────────────────
    0h   6h   12h  18h  24h
```

### 5. Konfiguration-Backups

Claude erstellt automatisch:
- Tägliche Backups der FRITZ!Box-Konfiguration
- Versionsvergleiche (Änderungen erkennen)
- Alerts bei kritischen Änderungen

**Aufruf:**
```bash
python3 scripts/router_backup.py --backup /backups/fritz
```

---

## Wichtige Befehle für Automation

```bash
# Router erreichbarkeit testen
ping 192.168.178.1

# Routing-Tabelle anzeigen (macOS/Linux)
netstat -rn
route -n

# Gateway anzeigen
netstat -rn | grep default

# Switch SNMP-Abfrage (falls aktiviert)
snmpget -v2c -c public 192.168.178.96 sysUpTime.0

# SSH auf Router (falls aktiviert)
ssh admin@192.168.178.1
```

---

## Wann nutzt man diesen Workflow?

✅ **Nutze Claude-Automation:**
- Regelmäßiges Monitoring (täglich)
- Performance-Analysen
- Automatische Reports
- Trends und Vorhersagen
- Konfigurationsversioning

❌ **Nutze stattdessen manuelle Web-UI (Modul 04-router-switch-gateway_manuell.md):**
- Einmalige Konfiguration
- Visuelle Geräte-Verwaltung
- Ad-hoc Troubleshooting
- Firmware-Updates
- Sicherheitseinstellungen

---

## Typisches Workflow-Beispiel

**Szenario:** Dr. Stracke möchte wissen, ob der Internet-Zugang optimal läuft.

**Mit Claude-Automation:**
1. Claude führt `router_diagnostics.py` aus
2. Skript liest aktuelle Werte von FRITZ!Box
3. Claude erstellt einen Report:
   - Download: 150 Mbps ✅ (normal)
   - Upload: 20 Mbps ✅ (normal)
   - Router-Temperatur: 48°C ✅ (normal)
   - CPU-Auslastung: 35% ✅ (normal)

4. Wenn Probleme erkannt werden:
   - "Download ist nur 50 Mbps - unter Normal!"
   - Empfehlung: Gerät neu starten

---

## Beste Praktiken

1. **Täglich monitoren:** Status um 10:00 UTC abrufen
2. **Alerts nur bei Problemen:** Nicht zu viele Benachrichtigungen
3. **Historische Daten:** 30-Tage-Trend verfolgen
4. **Konfigurationsbackups:** Wöchentlich
5. **Reports:** Monatlich für Dr. Stracke

---

**Nächster Schritt:** Siehe Modul 04-router-switch-gateway_manuell.md für Web-UI-basierte Konfiguration (einmalige Einrichtung).
