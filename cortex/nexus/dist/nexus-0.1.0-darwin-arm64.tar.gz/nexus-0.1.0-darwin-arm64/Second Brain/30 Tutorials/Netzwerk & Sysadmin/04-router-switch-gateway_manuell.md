# Router, Switch und Gateway — Manueller Workflow

**Einsatzbereich:** Web-UI-Navigation, einmalige Konfiguration, visuelle Verwaltung

**Wann ist dieser Workflow sinnvoll?**
- Du möchtest die FRITZ!Box zum ersten Mal konfigurieren
- Du brauchst eine visuelle Übersicht über die Netzwerk-Struktur
- Du möchtest Firewall-Regeln manually setzen
- Du möchtest die Switch-Verwaltung über Omada Console verstehen
- Du brauchst Port-Weiterleitungen zu konfigurieren

---

## Szenario

Dr. Stracke möchte seine Netzwerk-Infrastruktur (Router, Switch, Gateway) verstehen und überprüfen, dass alles korrekt konfiguriert ist.

---

## Workflow-Schritte

### Schritt 1: FRITZ!Box Oberfläche öffnen

1. Öffne deinen Browser
2. Navigiere zu: **http://192.168.178.1** oder **http://fritz.box**
3. Melde dich an (falls nötig mit deinem FRITZ!Box-Passwort)
4. Du siehst das Dashboard mit Überblick

**Was siehst du:**
- Internet-Status (grüne LED = verbunden)
- Verbundene Geräte
- WLAN-Status
- Andere Geräte im Netzwerk

### Schritt 2: Internet- und Gateway-Information prüfen

1. Gehe zu **"Internet"** → **"Zugangsdaten"**
2. Du siehst:
   - **Internet-Status:** Verbunden
   - **DSL-Verbindung:** Von deinem ISP (Vodafone)
   - **DNS-Server:** Automatisch konfiguriert
   - **IPv6:** Aktiviert (2a00:1f:3204:0000::1)

**Was bedeutet das:**
- Dein Router ist das **Gateway** (192.168.178.1)
- Alle Geräte im Netzwerk senden Traffic durch diesen Router
- Dieser Router leitet Traffic ins Internet weiter

### Schritt 3: DHCP- und DHCP-Server-Einstellungen prüfen

1. Gehe zu **"Heimnetz"** → **"Netzwerk"** → **"Netzwerkeinstellungen"**
2. Du siehst die DHCP-Konfiguration:
   - **DHCP-Server:** Aktiviert
   - **DHCP-Bereich:** 192.168.178.40 - 192.168.178.200
   - **Lease-Zeit:** 10 Tage

**Was bedeutet das:**
- Neue Geräte erhalten automatisch eine IP aus dem Bereich .40-.200
- Cluster Nodes (.29-.32) sind außerhalb dieses Bereichs (statische IPs)

### Schritt 4: Netzwerk-Geräte anzeigen

1. Gehe zu **"Heimnetz"** → **"Netzwerk"**
2. Du siehst eine Liste aller verbundenen Geräte:
   - Router selbst (.1)
   - Switch (ES216G .96)
   - Cluster Nodes (.29-.32)
   - Access Points (.40, .61, .62)
   - Client-Geräte (iPad, PS5, etc.)

**Beobachtung:**
- Insgesamt ca. 28-30 Geräte online
- Die meisten über WiFi, Cluster Nodes über Kabel
- Cluster Nodes haben konsistente IPs (nicht DHCP)

### Schritt 5: Firewall-Einstellungen prüfen

1. Gehe zu **"Sicherheit"** → **"Firewall"**
2. **Firewall:** Aktiviert (grüner Schalter)
3. **Sicherheitsstufe:** Hoch

**Was bedeutet das:**
- Alle eingehenden Verbindungen sind blockiert (außer Response auf ausgehende Anfragen)
- Dein Netzwerk ist vor Angriffen geschützt
- Portfreigaben sind notwendig für externen Zugriff (später)

---

## Wichtige Router-Funktionen verstehen

### Der Gateway

Dein Gateway ist: **192.168.178.1 (FRITZ!Box)**

**Was macht der Gateway:**
1. **Internet-Verbindung:** Verbindet zum ISP (Vodafone)
2. **NAT:** Übersetzt private IPs (.178.x) in deine öffentliche IP
3. **DHCP:** Vergibt automatisch IPs an neue Geräte
4. **DNS:** Übersetzt Hostnamen in IP-Adressen
5. **Firewall:** Blockiert unerwünschte Verbindungen

### Der Switch

Dein Switch ist: **192.168.178.96 (TP-Link ES216G)**

**Was macht der Switch:**
1. **Verbindet Geräte:** 16 Ports für Kabel-Verbindungen
2. **Leitet Traffic:** Zwischen Geräten im gleichen Netzwerk
3. **Intelligent:** Liest MAC-Adressen und leitet nur notwendigen Traffic weiter
4. **Fernverwaltet:** Über Omada Controller konfigurierbar

### Unterschied Router ↔ Switch

| Funktion | Router | Switch |
|----------|--------|--------|
| Verbindet | Verschiedene Netzwerke | Geräte im gleichen Netzwerk |
| Internet | Ja, mit ISP | Nein, lokal nur |
| DHCP | Ja | Nein |
| Firewall | Ja | Nein |
| Konfiguration | Web-UI | Omada Controller |

---

## Praktische Übung: Gateway testen

1. Öffne Terminal (auf Mac)
2. Gib ein: `netstat -rn | grep default`
3. Du siehst: `default        192.168.178.1      UGSc       en7`

**Das bedeutet:**
- Dein Computer kennt sein Gateway: 192.168.178.1
- Alle Pakete für "externe" Ziele gehen an diesen Gateway
- Der Gateway leitet sie ins Internet weiter

---

## Manuelles Troubleshooting

### Problem: "Keine Internetverbindung"

**Manuelles Troubleshooting via FRITZ!Box:**
1. Gehe zu **"Internet"** → **"Zugangsdaten"**
2. Prüfe **"Internet-Status"**: Sollte grün/verbunden sein
3. Falls rot:
   - Prüfe Kabel zum Modem
   - Neustarten: **"System"** → **"Sicherung"** → **"Neustart"**
   - Warte 2 Minuten

### Problem: "Gerät bekommt keine IP-Adresse"

**Manuelles Troubleshooting:**
1. Gehe zu **"Heimnetz"** → **"Netzwerk"**
2. Prüfe DHCP-Status: Sollte aktiviert sein
3. Neustarten Sie das betroffene Gerät
4. Oder: Manuelle IP-Zuweisung auf dem Gerät (192.168.178.100)

### Problem: "Gerät ist nicht erreichbar"

**Manuelles Troubleshooting:**
1. Gehe zu **"Heimnetz"** → **"Netzwerk"**
2. Prüfe, ob Gerät in der Liste ist
3. Prüfe Netzwerk-Verbindung (Kabel/WiFi)
4. Versuche zu pingen: Terminal → `ping 192.168.178.29`

---

## Wann nutzt man diesen Workflow?

✅ **Nutze manuelle Web-UI:**
- Erste Konfiguration des Routers
- Visuelle Geräte-Verwaltung
- Firewall-Einstellungen
- Portfreigaben konfigurieren
- Sicherheitsupdate installieren

❌ **Nutze stattdessen Claude-Automation (Modul 04-router-switch-gateway_claude.md):**
- Regelmäßiges Monitoring
- Automatische Reports
- Konfigurationsbackups
- Performance-Analysen

---

## Praktischer Tipp für Dr. Stracke

1. **Merke dir:** Gateway = 192.168.178.1 (FRITZ!Box)
2. **Merke dir:** Switch = 192.168.178.96 (Kabel-Verteiler)
3. **Merke dir:** Cluster Nodes = .29-.32 (statische IPs)
4. **Regel:** Jeden Monat die FRITZ!Box-Konfiguration sichern (Backup)

---

**Nächster Schritt:** Siehe Modul 05-dhcp.md für automatische IP-Vergabe im Detail.
