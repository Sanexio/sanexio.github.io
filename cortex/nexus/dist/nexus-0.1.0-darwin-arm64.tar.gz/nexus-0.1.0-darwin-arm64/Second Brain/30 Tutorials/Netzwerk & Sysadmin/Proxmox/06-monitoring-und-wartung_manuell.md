# Proxmox 06 — Manueller Workflow

> Regelmäßige Wartungsschritte zum Selbermachen.

---

## Schnell-Check: Ist alles okay? (5 Minuten)

```bash
# Per SSH auf den Proxmox-Host:
ssh root@192.168.10.31

# 1. Alle VMs/CTs laufen?
qm list
pct list

# 2. Storage-Belegung okay?
zpool list
df -h

# 3. ZFS gesund?
zpool status | grep -E "state:|errors:"
# Soll anzeigen: state: ONLINE / errors: No known data errors

# 4. RAM und CPU
free -h
uptime   # Load Average: unter Anzahl CPU-Kerne = gut

# 5. Letzter Backup-Status
ls -lt /var/log/vzdump/ | head -5
```

## Monatliche Wartung (Schritt für Schritt)

### 1. Snapshots der wichtigsten VMs erstellen

Im Web-Interface:
- DC (VM) → Snapshots → Take Snapshot → "vor-wartung-2026-04"
- Fileserver → Snapshots → Take Snapshot
- Repeat für alle kritischen VMs

### 2. Updates installieren

```bash
# Proxmox-Host
apt update
apt list --upgradable
# Prüfen ob etwas Kritisches dabei ist
apt dist-upgrade -y

# Container aktualisieren (pro Container)
pct enter 200
apt update && apt upgrade -y
exit
```

### 3. ZFS Scrub

```bash
# Scrub starten (kann Stunden dauern, aber Server läuft normal weiter)
zpool scrub rpool
zpool scrub SSDPool1

# Fortschritt prüfen
zpool status | grep scan
# z.B. "scan: scrub in progress since ..."

# Nach Abschluss: Ergebnis prüfen
zpool status
# "scan: scrub repaired 0B ... with 0 errors" = perfekt
```

### 4. Festplatten-Gesundheit

```bash
# SMART-Status aller Festplatten
for disk in /dev/sd?; do
  echo "=== $disk ==="
  smartctl -H $disk | grep "SMART overall"
done

# Detailliert für eine Platte
smartctl -a /dev/sda
```

### 5. Logs prüfen

```bash
# Letzte Kernel-Fehler
dmesg | grep -i -E "error|fail|warning" | tail -20

# Systemd-Fehler
journalctl -p err --since "30 days ago" | tail -30

# ZFS-Events
zpool events -v | tail -20
```

### 6. Aufräumen

```bash
# Alte Kernel entfernen
apt autoremove -y

# Journal-Logs trimmen
journalctl --vacuum-time=30d
journalctl --disk-usage

# Alte Backups prüfen (Retention)
# → Web-Interface: Storage → Backups → veraltete Backups löschen
```

## Wartungs-Checkliste (zum Abhaken)

- [ ] Snapshots vor Wartung erstellt
- [ ] Proxmox-Host aktualisiert
- [ ] VMs und Container aktualisiert
- [ ] ZFS Scrub gestartet und Ergebnis geprüft
- [ ] SMART-Status aller Festplatten okay
- [ ] Logs auf Fehler geprüft
- [ ] Storage-Belegung unter 80%
- [ ] Alte Backups aufgeräumt (Retention)
- [ ] Snapshots nach erfolgreicher Wartung entfernt (sparen Platz)

---

## Nächste Schritte

→ Bei Problemen: `_memory/errors/` durchsuchen oder Claude fragen
