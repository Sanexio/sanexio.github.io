# Proxmox 03 — Manueller Workflow

> Schritt-für-Schritt im Web-Interface und Terminal.

---

## Übung 1: Manuelles Backup erstellen

1. Im Web-Interface: VM oder CT auswählen
2. **Backup** Tab → **Backup now**
3. Einstellungen:
   - Storage: `HDDPool1` (oder verfügbarer Backup-Storage)
   - Mode: `Snapshot`
   - Compression: `ZSTD`
4. **Backup** klicken
5. Im Task-Log unten den Fortschritt beobachten

Per Terminal:
```bash
# VM 100 sichern (Snapshot-Modus, zstd-Kompression)
vzdump 100 --storage HDDPool1 --mode snapshot --compress zstd

# Container 200 sichern
vzdump 200 --storage HDDPool1 --mode snapshot --compress zstd

# Alle VMs und Container auf einmal
vzdump --all --storage HDDPool1 --mode snapshot --compress zstd
```

## Übung 2: Automatisches Backup einrichten

1. **Datacenter** → **Backup** (nicht Node, sondern Datacenter!)
2. **Add**:
   - Schedule: `tue,thu,sat 02:00` (Di, Do, Sa um 2 Uhr nachts)
   - Storage: `HDDPool1`
   - Mode: `Snapshot`
   - Compression: `ZSTD`
   - Send email to: deine E-Mail (Benachrichtigung bei Fehlern)
   - Selection: `All` (oder spezifische VMs)
   - Retention:
     - Keep daily: 7
     - Keep weekly: 4
     - Keep monthly: 3
3. **Create**

## Übung 3: Backup wiederherstellen (Test!)

**Wichtig:** Das ist eine Übung. Mach das mit einem Test-Container, nicht mit
einem Produktiv-System.

1. Storage → HDDPool1 → Backups
2. Ein Backup des Test-Containers (z.B. CT 200) auswählen
3. **Restore**:
   - Storage: `local-lvm` oder `SSDPool1`
   - CT ID: `299` (andere ID als Original, damit kein Konflikt!)
4. **Restore** klicken
5. CT 299 starten und prüfen, ob alles da ist
6. CT 299 wieder löschen (war nur ein Test)

## Übung 4: ZFS-Status prüfen

```bash
# Pool-Übersicht (Größe, Belegung, Status)
zpool list

# Detailstatus (Fehler, Scrub-Historie)
zpool status

# Letzter Scrub-Zeitpunkt und Ergebnis
zpool status | grep scan

# Snapshots auflisten
zfs list -t snapshot | head -20

# Alte Snapshots aufräumen (Vorsicht!)
# Erst auflisten, dann gezielt löschen:
zfs list -t snapshot -o name,used,creation
```

## Checkliste: Backup-Gesundheit

Prüfe regelmäßig (z.B. monatlich):

- [ ] Alle VMs/CTs werden automatisch gesichert?
- [ ] Backup-E-Mails kommen an (auch Erfolgs-Mails)?
- [ ] Speicherplatz im Backup-Pool ausreichend (< 80%)?
- [ ] Wiederherstellungs-Test durchgeführt?
- [ ] ZFS Scrub zeigt keine Fehler?

---

## Nächste Schritte

→ **04-netzwerk.md** — Netzwerk-Konfiguration
