# CGNAT verstehen — Manueller Workflow

**Einsatzbereich:** Manuelle Diagnose, Ad-hoc Tests, Troubleshooting von Zugriffsproblemen

**Wann ist dieser Workflow sinnvoll?**
- Du möchtest schnell prüfen, ob IPv6 funktioniert
- Du möchtest deine öffentliche IP-Adresse sehen
- Du brauchst Test-Zugriff auf dein Netzwerk von außen
- Du troubleshootest Verbindungsprobleme
- Du prüfst MyFRITZ! Funktionalität

---

## Szenario

Dr. Stracke möchte von unterwegs auf seinen Router zugreifen und braucht eine schnelle Überprüfung, ob alles funktioniert.

---

## Workflow-Schritte

### Schritt 1: Öffentliche IPv4-Adresse prüfen

**Terminal-Befehl:**
```bash
curl ifconfig.me
```

**Oder im Browser:**
- Gehe zu: https://whatismyipaddress.com

**Erwartetes Ergebnis:**
```
203.0.113.42
```

**Bedeutung:**
- Das ist deine öffentliche IPv4-Adresse vom ISP
- Diese Adresse ist über CGNAT gemeinsam mit anderen Kunden
- Portfreigaben auf dieser IP funktionieren NICHT

### Schritt 2: IPv6-Adresse prüfen

**Terminal-Befehl:**
```bash
curl -6 ifconfig.me
```

**Oder im Browser (von Gerät mit IPv6):**
- Gehe zu: https://whatismyipaddress.com (sollte IPv6 zeigen)

**Erwartetes Ergebnis:**
```
2a00:1f:3204:0000::1
```

**Bedeutung:**
- Das ist deine öffentliche IPv6-Adresse
- IPv6 hat KEINE CGNAT-Probleme
- Du kannst Portfreigaben über IPv6 machen

### Schritt 3: MyFRITZ! Domain prüfen

**Im Browser:**
1. Öffne: **https://475cdg2rogmn8yah.myfritz.net:47924**
2. Melde dich an (FRITZ!Box-Passwort)
3. Du solltest die FRITZ!Box Web-Oberfläche sehen

**Wenn funktioniert:**
- ✅ MyFRITZ! DynDNS ist aktiv
- ✅ Du kannst von außen auf deine FRITZ!Box zugreifen
- ✅ Externe IP-Änderungen werden automatisch aktualisiert

**Wenn nicht funktioniert:**
- ❌ Überprüfe Internet-Verbindung
- ❌ Prüfe in FRITZ!Box: **"Internet"** → **"Freigaben"** → **"FRITZ!Box-Dienste"**

### Schritt 4: IPv6-Konnektivität lokal prüfen

**Terminal-Befehl:**
```bash
# IPv6-Adresse des Routers pingen (lokal im Netzwerk)
ping6 2a00:1f:3204:0000::1
```

**Erwartetes Ergebnis:**
```
PING6(56=40+8+8 bytes) 2a00:1f:3204:0000::2 --> 2a00:1f:3204:0000::1
16 bytes from 2a00:1f:3204:0000::1, icmp_seq=0 hlim=64 time=1.234 ms
```

**Bedeutung:**
- ✅ IPv6 funktioniert im lokalen Netzwerk
- ✅ Router reagiert auf IPv6-Anfragen
- ✅ Basis für externen IPv6-Zugriff ist vorhanden

### Schritt 5: SSH-Zugriff testen (für Phase 8)

**Terminal-Befehl (lokal im Netzwerk):**
```bash
ssh -6 admin@[2a00:1f:3204:0000::1]
```

**Falls SSH nicht funktioniert:**
- Das ist normal - SSH ist vielleicht nicht aktiviert
- Wird in Phase 8 konfiguriert (VPN/Remote Access)

---

## CGNAT Probleme verstehen

### Problem: "Portfreigaben funktionieren nicht"

**Ursache:** CGNAT blockiert IPv4-Portfreigaben

**Symptom:**
- Du öffnest einen Port in FRITZ!Box (z.B. 8080)
- Von außen trotzdem nicht erreichbar
- Lokale Verbindung funktioniert

**Lösung:**
1. ✅ **IPv6 nutzen** - Moderne Lösung
2. ✅ **MyFRITZ! nutzen** - Für FRITZ!Box-Zugriff
3. ⚪ **VPN später** - Für alle Geräte im Netzwerk

### Problem: "Meine IP ändert sich ständig"

**Ursache:** CGNAT verteilt IPs neu

**Symptom:**
- Öffentliche IP war gestern anders
- Gerät von außen nicht mehr erreichbar

**Lösung:**
- ✅ **MyFRITZ! nutzen** - Domain bleibt immer gleich
- ✅ **DynDNS** - Automatische IP-Updates

---

## Checkliste: Ist CGNAT ein Problem für dich?

| Szenario | IPv4 | IPv6 | MyFRITZ! |
|----------|------|------|----------|
| Auf FRITZ!Box von außen zugreifen | ❌ | ✅ | ✅ |
| SSH auf Cluster Node | ❌ | ✅ | ❌ |
| Web-Service hosten | ❌ | ✅ | ❌ |
| Remote-Backup | ❌ | ✅ | ❌ |

**Fazit:** IPv6 ist die beste Lösung für externe Zugriffe mit CGNAT.

---

## Praktische Tests

### Test 1: IPv6 funktioniert?

```bash
# Lokal im Netzwerk
ping6 fe80::1%en7    # fe80::1 ist der Link-Local Präfix
```

Falls funktioniert → IPv6 ist aktiv

### Test 2: MyFRITZ! funktioniert?

```bash
# Domain auflösen
nslookup 475cdg2rogmn8yah.myfritz.net

# Oder einfach im Browser
https://475cdg2rogmn8yah.myfritz.net:47924
```

Falls funktioniert → MyFRITZ! ist erreichbar

### Test 3: Öffentliche IP prüfen

```bash
curl ifconfig.me
```

Falls Antwort → Internet-Verbindung funktioniert

---

## Wichtige IPv6-Begriffe

- **Global Unicast:** Öffentliche IPv6-Adresse (außen erreichbar)
- **Link-Local:** Lokale IPv6 (fe80::) nur im Subnetz
- **Dual-Stack:** IPv4 und IPv6 gleichzeitig
- **SLAAC:** Automatische IPv6-Adressvergabe
- **Präfix:** Netzwerk-Teil der IPv6-Adresse

---

## Wann nutzt man diesen Workflow?

✅ **Nutze manuelle Tests:**
- Schnelle Überprüfung
- Ad-hoc Diagnose
- Troubleshooting von Problemen
- Einmalige Überprüfung

❌ **Nutze stattdessen Claude-Automation (Modul 08-cgnat_claude.md):**
- Tägliche Tests
- Regelmäßiges Monitoring
- Historische Daten
- Automatische Alerts

---

## Wichtigste Lernpunkte

1. **CGNAT ist normal** - Viele ISPs nutzen es
2. **IPv6 ist die Lösung** - Modern und zukunftssicher
3. **MyFRITZ! als Fallback** - Für FRITZ!Box-Zugriff
4. **VPN kommt später** - Phase 8 für umfassende Remote-Zugriffe
5. **IPv4-Portfreigaben funktionieren NICHT** - Nicht sinnvoll bei CGNAT

---

**Nächster Schritt:** Phase 1 ist abgeschlossen! Siehe homelab-handbuch.md für Übersicht und Phase 2 Planung.
