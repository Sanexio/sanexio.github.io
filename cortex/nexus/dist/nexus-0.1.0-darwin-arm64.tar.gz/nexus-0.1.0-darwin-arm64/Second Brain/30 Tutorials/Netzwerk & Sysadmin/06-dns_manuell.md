# DNS — Manueller Workflow

**Einsatzbereich:** Ad-hoc Tests, manuelle Diagnose, Troubleshooting einzelner Hostnamen

**Wann ist dieser Workflow sinnvoll?**
- Du möchtest schnell testen, ob ein Hostname funktioniert
- Du brauchst die IP-Adresse eines Geräts
- Du möchtest DNS-Probleme untersuchen
- Du möchtest DNS-Cache leeren
- Du testest neue Hostnamen

---

## Szenario

Dr. Stracke möchte überprüfen, ob sein Cluster-Mini-01 über den Hostnamen erreichbar ist, und möchte wissen, welche IP-Adresse es hat.

---

## Workflow-Schritte

### Schritt 1: Einfache DNS-Auflösung mit nslookup

**macOS/Linux Terminal:**

1. Öffne das Terminal
2. Gib ein: `nslookup Cluster-Mini-01.fritz.box`

**Erwartetes Ergebnis:**
```
Server:         192.168.178.1
Address:        192.168.178.1#53

Name:   Cluster-Mini-01.fritz.box
Address: 192.168.178.29
```

**Das bedeutet:**
- DNS-Server: 192.168.178.1 (FRITZ!Box) ✅
- Hostname: `Cluster-Mini-01.fritz.box`
- IP-Adresse: `192.168.178.29` ✅

### Schritt 2: Schnelle IP-Abfrage mit host

**Einfacher und schneller als nslookup:**

```bash
host Cluster-Mini-01.fritz.box
```

**Erwartetes Ergebnis:**
```
Cluster-Mini-01.fritz.box has address 192.168.178.29
```

### Schritt 3: Detaillierte Abfrage mit dig

**Für mehr Details über DNS-Abfrage:**

```bash
dig Cluster-Mini-01.fritz.box
```

**Erwartetes Ergebnis:**
```
; <<>> DiG 9.10.6 <<>> Cluster-Mini-01.fritz.box
; (1 server found)
;; global options: +cmd
;; Got answer:
;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 12345
;; flags: qr rd ra; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 0

;; QUESTION SECTION:
;Cluster-Mini-01.fritz.box.     IN      A

;; ANSWER SECTION:
Cluster-Mini-01.fritz.box. 3600 IN      A       192.168.178.29

;; Query time: 2 msec
;; SERVER: 192.168.178.1#53(192.168.178.1)
;; WHEN: Fri Apr 03 10:30:00 UTC 2026
;; MSG SIZE  rcvd: 60
```

**Das bedeutet:**
- Status: NOERROR = Alles OK ✅
- Query time: 2 ms = Sehr schnell ✅
- SERVER: 192.168.178.1 = FRITZ!Box DNS ✅

### Schritt 4: Internet-Domain testen

**Internet-Domains auflösen:**

```bash
nslookup google.com
```

**Erwartetes Ergebnis:**
```
Server:         192.168.178.1
Address:        192.168.178.1#53

Non-authoritative answer:
Name:   google.com
Address: 142.250.185.14
```

**Das bedeutet:**
- "Non-authoritative" = Antwort aus DNS-Cache ✅
- Lokal bei FRITZ!Box gecacht
- Schnelle Antwort nächstes Mal

### Schritt 5: Alle Cluster Nodes auflösen

**Schnelle Überprüfung aller Nodes:**

```bash
# Alle Nodes in einer Zeile
for node in Cluster-Mini-01 Cluster-Mini-02 Cluster-Mini-03 Cluster-Mini-04; do
    echo "$node.fritz.box → $(host $node.fritz.box | grep "has address" | cut -d' ' -f4)"
done
```

**Erwartetes Ergebnis:**
```
Cluster-Mini-01.fritz.box → 192.168.178.29
Cluster-Mini-02.fritz.box → 192.168.178.30
Cluster-Mini-03.fritz.box → 192.168.178.31
Cluster-Mini-04.fritz.box → 192.168.178.32
```

---

## Troubleshooting: Wenn DNS nicht funktioniert

### Problem: "Hostname wird nicht aufgelöst"

**Fehlermeldung:**
```
nslookup: can't resolve 'invalid-hostname.fritz.box': Name or service not known
```

**Lösungsschritte:**
1. Hostname-Schreibweise prüfen (Groß-/Kleinschreibung)
2. `.fritz.box` suffix nicht vergessen
3. Gerät eingeschaltet? `ping 192.168.178.29`
4. Gerät im Netzwerk sichtbar? Siehe Modul 07-netzwerkscan

### Problem: "DNS-Server antwortet nicht"

**Fehlermeldung:**
```
nslookup: [error address lookup failed]
```

**Lösungsschritte:**
1. FRITZ!Box erreichbar? `ping 192.168.178.1`
2. Internetverbindung prüfen
3. DNS-Server neu starten: FRITZ!Box → **"Sicherung"** → **"Neustart"**

### Problem: "Auflösung ist langsam"

**Symptom:** dig zeigt `Query time: 500 msec` oder mehr

**Lösungsschritte:**
1. Laufe DNS-Cache: `sudo dscacheutil -flushcache` (macOS)
2. Internet-Verbindung prüfen
3. Andere DNS-Server testen: `nslookup google.com 8.8.8.8`

---

## Manueller DNS-Cache-Test

### Lokalen DNS-Cache anzeigen (macOS)

```bash
scutil --dns
```

**Zeigt:**
```
DNS configuration:
resolver #0
  search domain[0] : fritz.box
  nameserver[0] : 192.168.178.1
  flags : Request A records, Request AAAA records
```

### DNS-Cache leeren (macOS)

```bash
# Cache leeren
sudo dscacheutil -flushcache

# Bestätigung (nichts = erfolgreich)
echo "DNS-Cache geleert"
```

### DNS-Cache prüfen (Linux)

```bash
# Standard-DNS-Konfiguration
cat /etc/resolv.conf

# Ergebnis:
# nameserver 192.168.178.1
```

---

## Praktische Übung

**Übung 1: Cluster Node auflösen**
```bash
nslookup Cluster-Mini-01.fritz.box
```
Erwartetes Ergebnis: IP-Adresse 192.168.178.29

**Übung 2: Alle Nodes überprüfen**
```bash
for i in 29 30 31 32; do
    echo -n "192.168.178.$i: "
    ping -c 1 192.168.178.$i | grep "bytes from" | cut -d'(' -f2 | cut -d')' -f1
done
```

**Übung 3: DNS-Cache leeren und neu laden**
```bash
sudo dscacheutil -flushcache
nslookup google.com
```
Beobachte: Zweiter Aufruf sollte schneller sein (Cache)

---

## Wichtige DNS-Begriffe

- **Hostname:** Name eines Geräts (z.B. `Cluster-Mini-01`)
- **FQDN:** Vollständiger Name mit Domain (z.B. `Cluster-Mini-01.fritz.box`)
- **A-Record:** Mapping Hostname → IPv4-Adresse
- **DNS-Server:** Beantwortet Anfragen (192.168.178.1)
- **TTL:** Time To Live (wie lange Antwort gecacht wird)

---

## Wann nutzt man diesen Workflow?

✅ **Nutze manuelle Commands:**
- Schnelle Ad-hoc-Tests
- Einzelne Hostnamen überprüfen
- Troubleshooting
- DNS-Fehler untersuchen
- Cache-Management

❌ **Nutze stattdessen Claude-Automation (Modul 06-dns_claude.md):**
- Regelmäßige Tests (täglich)
- Alle Hostnamen automatisch testen
- Performance-Monitoring
- Historische Daten und Trends

---

**Nächster Schritt:** Siehe Modul 07-netzwerkscan.md für Netzwerk-Scans mit nmap.
