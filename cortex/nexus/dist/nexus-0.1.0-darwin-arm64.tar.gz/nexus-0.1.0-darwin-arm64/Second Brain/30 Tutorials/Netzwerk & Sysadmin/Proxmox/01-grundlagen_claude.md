# Proxmox 01 — Claude-Workflow

> Was Claude für dich automatisiert machen kann.

---

## Proxmox-Status abfragen

Du kannst Claude bitten, über SSH oder das Proxmox-API den Status zu prüfen:

```
"Claude, wie sieht es auf dem Proxmox-Server aus?"
→ Claude verbindet sich (wenn SSH/API verfügbar) und zeigt:
  - Welche VMs/Container laufen
  - CPU- und RAM-Auslastung
  - Storage-Belegung
```

## Server-Dokumentation pflegen

Claude kann die Praxis-Konfiguration aktualisieren:

```
"Claude, aktualisiere die Server-Dokumentation mit den neuen IP-Adressen."
→ Claude liest die bestehende Doku, fragt nach Änderungen,
  aktualisiert die Datei und prüft auf Konsistenz.
```

## Netzwerk-Analyse

Claude kann mit dem Netzwerk-Analyse-Skript arbeiten:

```
"Claude, scanne das Praxis-Netzwerk und zeig mir, welche Geräte online sind."
→ Claude nutzt _tutorials/netzwerk-sysadmin/01_netzwerk_analyse.sh
```

## Einschränkungen

- Claude hat **keinen direkten Zugriff** auf den Proxmox-Server (kein SSH in der Sandbox)
- Proxmox-Befehle können **vorbereitet** werden, müssen aber manuell ausgeführt werden
- Für den Zugriff: SSH-Tunnel oder VPN nötig (siehe 04-netzwerk.md)
