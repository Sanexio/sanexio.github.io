---
tags: [netzwerk, sysadmin, tailscale, ssh, wordpress, local-by-flywheel, praxis-webseite]
created: 2026-04-26
---

# 10 — Remote-Zugriff auf eine lokale Entwicklungs-Site

> Vom **Praxis-Mac** im Browser auf die **WordPress-Entwicklungs-Site**
> zugreifen, die auf dem **Home-Mac** in Local by Flywheel läuft —
> parallel zur SSH-Session, in der Claude Code arbeitet.

## 1. Warum überhaupt?

Der Workflow für die Praxis-Webseite ist **Local-First**: Code und Content
werden auf dem Home-Mac in Local by Flywheel entwickelt, dann selektiv
auf das Live-WordPress geschoben. Wenn du vom Praxis-Mac aus weiter
arbeiten willst (per SSH zu Claude Code), brauchst du im Browser eine
Vorschau — sonst arbeitest du blind.

**Das Problem:** Der lokale Webserver bindet auf `127.0.0.1:10003`. Von
außerhalb des Home-Macs kommst du nicht direkt rein, auch nicht über
Tailscale, weil „localhost" wörtlich nur die Maschine selbst meint.

**Die drei möglichen Wege:**

| # | Weg | Aufwand | Komfort |
|---|---|---|---|
| A | Tailscale-IP + `/etc/hosts` (direkt) | einmalig sudo | ⭐⭐⭐⭐⭐ |
| B | SSH-Tunnel (Port-Forwarding) | kein sudo, aber Terminal offen | ⭐⭐⭐ |
| C | Tailscale Serve (MagicDNS) | Cloud-Aktivierung nötig | ⭐⭐⭐ |

Variante A funktioniert in dieser Konstellation am saubersten, weil
Local-by-Flywheel bereits einen Master-nginx betreibt, der auf allen
Netzwerk-Interfaces lauscht (inkl. Tailscale).

## 2. Setup Variante A — Tailscale-IP + `/etc/hosts`

### 2.1 Was passiert technisch?

1. Local-by-Flywheel hat zwei nginx-Instanzen:
   - **Site-nginx** auf `localhost:10003` (interner Backend)
   - **Master-nginx** auf `*:80` und `*:443` (Reverse-Proxy, routet per
     Hostname)
2. Master-nginx hört auch auf der Tailscale-IP `100.127.125.48`
3. Wir tragen den Site-Hostnamen
   `gpmedicalcenterwestend-…-202604.local` im `/etc/hosts` des
   Praxis-Macs auf diese Tailscale-IP.
4. Im Browser tippst du die echte Site-URL — der Praxis-Mac schickt die
   Anfrage über Tailscale zum Master-nginx, der per Host-Header an die
   richtige Site routet.

### 2.2 Einrichtung (auf Praxis-Mac)

```bash
sudo nano /etc/hosts
```

Folgende Zeile am Ende einfügen:

```
100.127.125.48   gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604.local
```

`Ctrl+O`, Enter, `Ctrl+X`.

### 2.3 Aufrufen

```
https://gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604.local/
https://gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604.local/wp-admin/
```

Beim ersten Aufruf: Browser warnt vor selbstsigniertem Zertifikat
(„Diese Verbindung ist nicht sicher"). Das ist erwartet — Local-by-Flywheel
erstellt das Cert lokal. Einmal „Erweitert → trotzdem fortfahren"
akzeptieren, dann ist es vertraut.

## 3. Setup Variante B — SSH-Tunnel

Wenn du keinen `/etc/hosts`-Eintrag setzen willst (oder kein sudo hast):

```bash
ssh -L 8080:localhost:10003 cluster-mini-02
```

In der laufenden SSH-Session, Browser auf Praxis-Mac:

```
http://localhost:8080
```

**Caveat:** WordPress generiert seine internen Links auf den
Site-Hostnamen, nicht auf `localhost:8080`. Klicks auf Menü-Einträge
können ins Leere zeigen. Praktikabel, wenn du gezielt Pages per
direkter URL anschaust; weniger gut für intensive Klick-Navigation.

**zsh-Alias** zum bequemeren Aufruf:

```bash
echo "alias praxis-tunnel='ssh -L 8080:localhost:10003 cluster-mini-02'" >> ~/.zshrc
source ~/.zshrc
```

Dann reicht: `praxis-tunnel`.

## 4. Setup Variante C — Tailscale Serve

Tailscale kann selbst als Reverse-Proxy auftreten und einen lokalen
Port als sauberen MagicDNS-Hostnamen exponieren
(`https://cluster-mini-02.piranha-marlin.ts.net`). **Aber:** Im Tailnet
muss das Feature einmalig aktiviert werden — über
`https://login.tailscale.com/f/serve` mit dem Tailnet-Admin-Account.

Auf Home-Mac:

```bash
tailscale serve --bg 10003
tailscale serve status
```

Auch hier gilt der Caveat aus Variante B: WordPress sieht den
MagicDNS-Hostnamen, nicht die echte Site-URL → Klicks brechen
teilweise.

## 5. Funktionstest

Vor dem ersten Browser-Aufruf, vom Praxis-Mac:

```bash
# Tailscale-Verbindung steht?
tailscale ping cluster-mini-02

# Master-nginx auf Home-Mac antwortet?
curl -skI -H "Host: gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604.local" \
     https://100.127.125.48/
```

Erwartet: „pong" und `HTTP/2 200`.

## 6. Was wenn der Home-Mac aus war?

- Tailscale-IP bleibt gleich (vom Tailscale-Coordinator vergeben)
- Local-by-Flywheel-Site muss manuell gestartet werden (Local-App
  → Site → „Start site")
- Erst danach funktioniert der Remote-Zugriff wieder

## 7. Troubleshooting — Browser-Fallstricke (2026-05-05)

Auch wenn `/etc/hosts` korrekt steht, Tailscale-Ping „pong" liefert und
`curl -skI` HTTP 200 zeigt, kann der Browser trotzdem mit
`ERR_CONNECTION_REFUSED` blocken. Ursache liegt dann **im Browser**, nicht im Netz.

### 7.1 Symptom: Frontend selbst geht nicht (URL akzeptiert nichts)

**Wahrscheinliche Ursache:** DNS-Cache oder mDNS-Cache löst den
`.local`-Hostnamen weiterhin auf eine alte IP (oft `127.0.0.1` aus
früheren Local-by-Flywheel-Läufen, wo dort nichts mehr lauscht).

**Diagnose-Schritte (auf dem Browser-Mac, nicht in SSH-Session):**

```bash
# 1. /etc/hosts wirklich gesetzt?
grep gpmedical /etc/hosts

# 2. Tailscale-Tunnel zum Site-Host steht?
tailscale ping cluster-mini-02

# 3. Master-nginx antwortet via Tailscale-IP mit Host-Header?
curl -skI -H "Host: gpmedicalcenterwestend-…-202604.local" https://100.127.125.48/
```

Wenn alle drei grün und Browser trotzdem rot → Browser-Cache.

**Fix:**

```bash
# DNS-Cache hart leeren
sudo dscacheutil -flushcache
sudo killall -HUP mDNSResponder
```

**Wenn das nicht reicht — HSTS-Lock:** Chrome merkt sich für 30 Tage,
dass eine Domain mit Zertifikatsfehler abgelehnt wurde, und blockt
ohne nachzufragen.

- Chrome: `chrome://net-internals/#hsts` → „Delete domain security
  policies" → Hostname eingeben → Delete.
- Zusätzlich: `chrome://net-internals/#dns` → „Clear host cache".
- Browser komplett schließen + neu starten.

**Schnellster Test ohne Konfig-Eingriff:** Inkognito-Fenster öffnen
(`Cmd+Shift+N` Chrome, `Cmd+Shift+P` Safari) — der hat keinen DNS-Cache
und keinen HSTS-Lock.

### 7.2 Symptom: Frontend geht, aber `/wp-admin` zeigt ERR_CONNECTION_REFUSED

**Wahrscheinliche Ursache:** Browser-Zertifikat-Akzept ist an die
**exakte URL plus Query-String** gebunden, nicht an die Domain. Sie
haben „Trotzdem fortfahren" für die Frontend-URL geklickt — das gilt
nicht für andere Pfade.

**Was passiert technisch:**

1. Browser sendet `GET /wp-admin/`
2. WordPress antwortet mit `HTTP 302` und Header
   `Location: https://…/wp-login.php?redirect_to=…&reauth=1`
   (normales WP-Verhalten: nicht-eingeloggte User zur Login-Seite
   schicken)
3. Browser folgt dem Redirect → das ist eine **neue URL** mit
   Query-String → Browser fragt erneut nach Zertifikat-Akzept, blockt
   aber stattdessen sofort.

**Verifikation per curl (von Server-Seite oder anderem Mac):**

```bash
# 302 erwartet
curl -skI -H "Host: gpmedicalcenterwestend-…-202604.local" \
     https://100.127.125.48/wp-admin/

# 200 erwartet
curl -skI -H "Host: gpmedicalcenterwestend-…-202604.local" \
     https://100.127.125.48/wp-login.php
```

Beide Antworten heißt: Server-Seite ist gesund, Problem ist
ausschließlich der Browser-Zertifikat-Cache.

**Sofort-Fix:** Direkt `/wp-login.php` aufrufen statt `/wp-admin/`.
Damit umgeht man den Redirect, akzeptiert das Zertifikat einmal für
den exakten Login-Pfad, loggt sich ein — danach geht `/wp-admin` auch.

```
https://gpmedicalcenterwestend-…-202604.local/wp-login.php
```

**Saubere Dauerlösung:** Local-by-Flywheel-Zertifikat ins
macOS-Keychain importieren und als „immer vertraut" markieren. Dann
gilt es system-weit für alle URLs derselben Domain. Anleitung:

```bash
# Zertifikat exportieren auf Site-Host
SITE="/Users/cluster-mini-02/Local Sites/<site-slug>/conf/nginx/server.crt"
scp cluster-mini-02:"$SITE" ~/Downloads/local-cert.crt

# Auf Browser-Mac doppelt-klicken → Schlüsselbund öffnet
# → Zertifikat suchen → Doppelklick → „Vertrauen" aufklappen
# → „Bei Verwendung dieses Zertifikats" → „Immer vertrauen"
```

Danach kein Browser-Akzept-Tanz mehr nötig.

### 7.3 Mini-Heuristik

| Symptom | Erste Vermutung |
|---|---|
| Browser ERR_CONNECTION_REFUSED, curl OK | DNS-/HSTS-Cache → Inkognito-Test |
| Browser ERR_CERT_INVALID, curl OK | Zertifikat → einmal akzeptieren oder Keychain-Import |
| Browser endlos „verbindet…" | Tailscale-Tunnel down → `tailscale ping` |
| `/wp-admin` rot, Frontend grün | Redirect-URL hat keinen Cert-Akzept → `/wp-login.php` direkt |
| Login-Loop nach Login-Klick | Cookie-Domain-Mismatch → WP siteurl/home prüfen |

## 8. Glossar — Fachbegriffe

| Begriff | Bedeutung |
|---|---|
| **localhost / 127.0.0.1** | Spezielle IP, die immer „diese Maschine selbst" bedeutet. Dienste, die auf localhost lauschen, sind von außen unsichtbar. |
| **Port-Forwarding (SSH)** | SSH leitet Anfragen auf einen lokalen Port (z. B. 8080) verschlüsselt durch zur Remote-Maschine und zurück. Wirkt für den Browser wie ein lokaler Dienst. |
| **Reverse-Proxy** | Webserver vor anderen Webservern. Nimmt Anfragen entgegen, schaut auf den Host-Header, leitet weiter. Local-by-Flywheel nutzt nginx als Reverse-Proxy für mehrere Sites. |
| **Host-Header** | HTTP-Header, der den Hostnamen aus der URL enthält. Reverse-Proxies entscheiden anhand des Host-Headers, welche Site gemeint ist. |
| **`/etc/hosts`** | Lokale Datei, die Hostnamen direkt auf IPs mappt — ohne DNS. Wird vom Betriebssystem **vor** DNS abgefragt. |
| **Tailscale** | VPN-ähnliches Mesh: jedes Gerät bekommt eine private IP (`100.x.y.z`) und kann jedes andere Gerät im Tailnet direkt erreichen, egal wo es im Internet sitzt. |
| **MagicDNS** | Tailscale-Feature: vergibt jedem Gerät einen DNS-Namen wie `cluster-mini-02.piranha-marlin.ts.net`, ohne dass man IPs merken muss. |
| **Tailscale Serve** | Reverse-Proxy-Funktion von Tailscale selbst: exponiert einen lokalen Port als MagicDNS-URL mit automatischem HTTPS-Zertifikat. |
| **Local by Flywheel** | Desktop-App für lokale WordPress-Entwicklung. Erzeugt pro Site eigenen nginx + MySQL + PHP, plus einen Master-nginx, der per Hostname routet. |
| **Selbstsigniertes Zertifikat** | TLS-Zertifikat, das nicht von einer öffentlichen Zertifizierungsstelle ausgestellt wurde. Browser warnen. Für Entwicklung ausreichend — einmalig akzeptieren. |
| **WP_HOME / WP_SITEURL** | Zwei Konstanten in WordPress, die festlegen, unter welcher URL die Site erreichbar sein soll. Sind sie statisch (DB oder `wp-config.php`) gesetzt, generiert WP alle Links mit dieser URL — auch wenn der Browser unter einer anderen URL kommt. |

## 9. Verwandte Notizen

- [[09-cortex-mesh-tailscale]] — Tailscale-Setup im Cortex-Mesh
- [[03-ip-adressen]] — Wie IPs funktionieren
- [[06-dns]] — Wie Namen auf IPs übersetzt werden
- [[07-netzwerkscan_claude]] — Welche Dienste auf welchem Port lauschen
