# Proxmox 02 — Manueller Workflow

> Schritt-für-Schritt im Web-Interface und Terminal.

---

## Übung 1: Linux-Container erstellen

Wir erstellen einen einfachen Ubuntu-Container als Testumgebung.

### Im Web-Interface:

1. **Template herunterladen:**
   - Links: `local` (oder dein Storage) → CT Templates → Templates
   - Suche: `ubuntu-24.04-standard` → Download
   - Warte bis fertig (Task-Log unten)

2. **Container erstellen:**
   - Klicke **Create CT** (oben rechts)
   - CT ID: `200`
   - Hostname: `test-ubuntu`
   - Password: Ein sicheres Passwort vergeben
   - Template: `ubuntu-24.04-standard` auswählen
   - Root Disk: 8 GB
   - CPU: 1 Core
   - Memory: 1024 MB (1 GB)
   - Network: Bridge `vmbr0`, IPv4 = DHCP (oder statische IP)
   - **Finish**

3. **Container starten und einloggen:**
   - CT 200 auswählen → **Start**
   - **Console** klicken
   - Login: `root` + dein Passwort

4. **Testen:**
   ```bash
   # Bin ich online?
   ping -c 3 google.com

   # System-Info
   hostname
   cat /etc/os-release
   ```

5. **Container wieder stoppen:**
   - Web-Interface → CT 200 → **Shutdown**

### Per Terminal (SSH):

```bash
# Template herunterladen
pveam update
pveam download local ubuntu-24.04-standard_24.04-2_amd64.tar.zst

# Container erstellen
pct create 200 local:vztmpl/ubuntu-24.04-standard_24.04-2_amd64.tar.zst \
  --hostname test-ubuntu \
  --cores 1 \
  --memory 1024 \
  --rootfs local-lvm:8 \
  --net0 name=eth0,bridge=vmbr0,ip=dhcp \
  --password "DeinPasswort"

# Starten
pct start 200

# In den Container einloggen
pct enter 200

# Wieder raus
exit

# Stoppen
pct shutdown 200
```

## Übung 2: Snapshot erstellen und zurückrollen

1. Container 200 starten
2. Einloggen und eine Datei erstellen:
   ```bash
   echo "Hallo Welt" > /root/testdatei.txt
   cat /root/testdatei.txt   # Zeigt: Hallo Welt
   ```
3. Im Web-Interface: CT 200 → Snapshots → **Take Snapshot** → Name: `vor-test`
4. Datei löschen:
   ```bash
   rm /root/testdatei.txt
   ls /root/   # Datei ist weg!
   ```
5. Snapshot → `vor-test` auswählen → **Rollback**
6. Container startet neu, Datei ist wieder da:
   ```bash
   cat /root/testdatei.txt   # Zeigt wieder: Hallo Welt
   ```

## Übung 3: Container aufräumen

Wenn du den Test-Container nicht mehr brauchst:

```bash
# Per Terminal:
pct stop 200
pct destroy 200

# Oder im Web-Interface:
# CT 200 → Stop → More → Remove (Häkchen "Destroy unreferenced disks" setzen)
```

---

## Nächste Schritte

→ **03-storage-und-backup.md** — Backups automatisieren (wichtig!)
