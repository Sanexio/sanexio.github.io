# Modul 02: IP-Adressen verstehen

**Dauer**: 20 Minuten  
**Schwierigkeit**: ⭐ Einfach  
**Voraussetzungen**: Modul 01  
**Version**: 0.3

---

## 📚 Theorie

### Was ist eine IP-Adresse?

Eine **IP-Adresse** (Internet Protocol Adresse) ist wie eine **Hausadresse für Computer**. Genau wie jedes Haus eine eindeutige Adresse hat, hat jedes Gerät im Netzwerk eine eindeutige IP-Adresse.

**Beispiel**: 
- Dein Router hat die Adresse: `192.168.178.1`
- Cluster-Mini-01 hat die Adresse: `192.168.178.29`

### IPv4 Format

IPv4-Adressen bestehen aus **4 Zahlen**, die durch Punkte getrennt sind.

**Format**: `XXX.XXX.XXX.XXX`

**Beispiel**: `192.168.178.1`

Jede Zahl kann zwischen **0** und **255** sein.

**Warum?** Jede Zahl ist ein **Byte** (8 Bits), und 2^8 = 256 mögliche Werte (0-255).

### Subnetzmaske verstehen

Die **Subnetzmaske** sagt dir, welcher Teil der IP-Adresse das **Netzwerk** ist und welcher Teil der **Computer** ist.

**Beispiel**: `255.255.255.0`

- `255.255.255` = Netzwerk-Teil (fester Bereich)
- `.0` = Computer-Teil (variabler Bereich)

**Einfacher**: `/24` bedeutet, dass die ersten 24 Bits für das Netzwerk sind.

**Dein Netzwerk**: `192.168.178.0/24`
- Netzwerk: `192.168.178`
- Computer: `.0` bis `.255` (254 mögliche Geräte)

### Private vs. Öffentliche IPs

**Private IP-Adressen** (lokal):
- Nur in deinem Netzwerk gültig
- Beispiele: `192.168.x.x`, `10.x.x.x`, `172.16.x.x`
- Werden vom Router verwaltet

**Öffentliche IP-Adressen** (Internet):
- Weltweit eindeutig
- Werden vom Internetanbieter zugewiesen
- Erlauben Zugriff von außen

**Wichtig**: Deine Geräte haben private IPs. Der Router hat eine öffentliche IP (oder CGNAT, siehe Modul 07).

### Erweiterte IP-Konzepte

**CIDR-Notation (Classless Inter-Domain Routing)**: Eine kompakte Schreibweise für Subnetze. Format: `IP-Adresse/Präfix-Länge`. Beispiel: `192.168.178.0/24` bedeutet, dass die ersten 24 Bits das Netzwerk definieren.

**Präfix-Länge**: Die Anzahl der Bits, die für das Netzwerk verwendet werden. `/24` = 24 Bits für Netzwerk, 8 Bits für Hosts. `/24` ermöglicht 2^8 - 2 = 254 Hosts (minus Netzwerk- und Broadcast-Adresse).

**Netzwerk-Adresse**: Die erste Adresse im Subnetz (Host-Bits = 0). Beispiel: `192.168.178.0` ist die Netzwerk-Adresse für `/24`.

**Broadcast-Adresse**: Die letzte Adresse im Subnetz (Host-Bits = 1). Beispiel: `192.168.178.255` ist die Broadcast-Adresse für `/24`. Pakete an diese Adresse werden an alle Geräte im Subnetz gesendet.

**Host-Adresse**: Eine Adresse, die einem Gerät zugewiesen werden kann. Im `/24` Subnetz sind das `.1` bis `.254`.

**Subnetting**: Das Aufteilen eines größeren Netzwerks in kleinere Subnetze. Beispiel: Ein `/24` Netzwerk kann in mehrere `/25` oder `/26` Subnetze aufgeteilt werden.

**Supernetting**: Das Zusammenfassen mehrerer kleinerer Netzwerke zu einem größeren Netzwerk.

**RFC 1918**: Spezifiziert die privaten IP-Adressbereiche:
- `10.0.0.0/8` (10.0.0.0 - 10.255.255.255)
- `172.16.0.0/12` (172.16.0.0 - 172.16.255.255)
- `192.168.0.0/16` (192.168.0.0 - 192.168.255.255)

Dein Netzwerk verwendet `192.168.178.0/24`, was Teil des RFC 1918 Bereichs ist.

**NAT (Network Address Translation)**: Übersetzt private IPs in öffentliche IPs. Dein Router führt NAT durch, damit alle Geräte mit privaten IPs ins Internet können.

**APIPA (Automatic Private IP Addressing)**: Wenn ein Gerät keine IP vom DHCP-Server erhält, vergibt es sich selbst eine IP aus `169.254.0.0/16`. Zeigt an, dass DHCP nicht funktioniert.

**Loopback-Adresse**: `127.0.0.1` (localhost) - Adresse, die auf den eigenen Computer verweist. Wird für lokale Tests verwendet.

**Link-Local-Adresse**: IPv4-Adressen im Bereich `169.254.0.0/16`, die automatisch vergeben werden, wenn kein DHCP verfügbar ist.

**Multicast**: IP-Adressen im Bereich `224.0.0.0/4` für Gruppenkommunikation. Ein Paket wird an mehrere Empfänger gesendet.

**Unicast**: Normale Punkt-zu-Punkt Kommunikation zwischen zwei Geräten.

**Anycast**: Eine IP-Adresse, die mehreren Geräten zugewiesen werden kann. Das Paket wird an das nächste Gerät mit dieser Adresse geroutet.

**Wildcard-Maske**: Die Umkehrung der Subnetzmaske. Wird in Routing-Tabellen verwendet. Beispiel: Subnetzmaske `255.255.255.0` → Wildcard `0.0.0.255`.

**VLSM (Variable Length Subnet Masking)**: Verwendung unterschiedlicher Subnetzmasken in verschiedenen Teilen des Netzwerks für effiziente Adressnutzung.

---

## 🎯 Ziel dieses Moduls

Nach diesem Modul verstehst du:
- ✅ Was eine IP-Adresse ist
- ✅ Wie IPv4-Adressen aufgebaut sind
- ✅ Was eine Subnetzmaske bedeutet
- ✅ Unterschied zwischen privaten und öffentlichen IPs
- ✅ Deine eigenen IP-Adressen finden können
- ✅ CIDR-Notation verstehen und verwenden können
- ✅ Netzwerk-, Broadcast- und Host-Adressen unterscheiden
- ✅ Subnetting-Konzepte kennen
- ✅ RFC 1918 private Adressbereiche kennen
- ✅ NAT, APIPA, Loopback, Multicast, Unicast verstehen

---

## 📋 Schritt-für-Schritt

### Schritt 1: Deine eigene IP-Adresse finden

**Was machen wir?**  
Wir finden heraus, welche IP-Adresse dein Computer hat.

**macOS**:

1. Öffne das **Terminal** (Finder → Programme → Dienstprogramme → Terminal)

2. Gib diesen Befehl ein:
```bash
ifconfig | grep "inet " | grep -v 127.0.0.1
```

**Erwartetes Ergebnis**:  
Du siehst eine Zeile wie:
```
inet 192.168.178.28 netmask 0xffffff00 broadcast 192.168.178.255
```

**Das bedeutet**:
- **IP-Adresse**: `192.168.178.28`
- **Subnetzmaske**: `0xffffff00` = `255.255.255.0`
- **Broadcast**: `192.168.178.255` (Adresse für alle Geräte)

**Alternative (einfacher)**:
```bash
ipconfig getifaddr en0
```
(Ersetze `en0` durch dein Netzwerk-Interface, z.B. `en7`)

---

### Schritt 2: IP-Adressen deiner Cluster Nodes prüfen

**Was machen wir?**  
Wir schauen uns die IP-Adressen deiner Mac Mini Cluster Nodes an.

**Deine Cluster Nodes**:

| Node | IP-Adresse | Bedeutung |
|------|------------|-----------|
| Cluster-Mini-01 | 192.168.178.29 | Erster Render Node |
| Cluster-Mini-02 | 192.168.178.30 | Zweiter Render Node |
| Cluster-Mini-03 | 192.168.178.31 | Dritter Render Node |
| Cluster-Mini-04 | 192.168.178.32 | Vierter Render Node |

**Beobachtung**: Die IPs sind **aufeinanderfolgend** (.29, .30, .31, .32). Das macht es einfacher, sie zu merken!

---

### Schritt 3: Subnetz verstehen

**Was machen wir?**  
Wir analysieren dein Subnetz.

**Dein Subnetz**: `192.168.178.0/24`

**Aufschlüsselung**:

- **192.168.178** = Netzwerk-Teil (fester Bereich)
- **.0** bis **.255** = Computer-Teil (254 mögliche Geräte)
- **.0** = Netzwerk-Adresse selbst (wird nicht verwendet)
- **.255** = Broadcast-Adresse (für alle Geräte)
- **.1** = Gateway (dein Router)

**Verfügbare IPs**: `.2` bis `.254` (253 Geräte)

---

### Schritt 4: IP-Bereiche verstehen

**Was machen wir?**  
Wir schauen uns an, welche IP-Bereiche für was verwendet werden.

**Aktuelle Verteilung**:

| Bereich | Verwendung | Beispiel |
|---------|------------|----------|
| .1 | Gateway (Router) | 192.168.178.1 |
| .2 - .39 | Statische IPs / Reservierungen | Verfügbar |
| .29 - .32 | Cluster Nodes (statisch) | 192.168.178.29 |
| .40 - .200 | DHCP-Bereich | Automatisch vergeben |
| .201 - .254 | Statische IPs / Reservierungen | Verfügbar |

**DHCP-Bereich**: `192.168.178.40 - 192.168.178.200`
- Geräte erhalten automatisch eine IP aus diesem Bereich
- Lease-Zeit: 10 Tage

**Statische IPs**: `.29 - .32`
- Cluster Nodes haben feste IPs
- Werden nicht vom DHCP-Server vergeben
- Immer die gleiche Adresse

---

## 💻 Befehle

### IP-Adresse anzeigen (macOS)

```bash
# Alle Netzwerk-Interfaces anzeigen
ifconfig

# Nur IP-Adresse anzeigen (einfacher)
ipconfig getifaddr en0

# Mit Subnetzmaske
ifconfig | grep "inet " | grep -v 127.0.0.1
```

### IP-Adresse anzeigen (Linux)

```bash
# Alle Netzwerk-Interfaces anzeigen
ip addr show

# Oder
ifconfig
```

### Netzwerk-Interface finden

```bash
# macOS
route get default | grep interface

# Linux
ip route | grep default
```

---

## ✅ Erwartetes Ergebnis

Nach diesem Modul solltest du:

1. ✅ Deine eigene IP-Adresse finden können
2. ✅ IP-Adressen deiner Cluster Nodes kennen
3. ✅ Verstehen, was eine Subnetzmaske ist
4. ✅ Den Unterschied zwischen privaten und öffentlichen IPs verstehen
5. ✅ IP-Bereiche in deinem Netzwerk interpretieren können

---

## ⚠️ Mögliche Fehlerquellen

### Problem: Befehl funktioniert nicht

**Lösung**:
- Prüfe, ob du im Terminal bist (nicht im Browser)
- Prüfe die Schreibweise des Befehls
- Versuche den alternativen Befehl

### Problem: Ich sehe mehrere IP-Adressen

**Lösung**:
- Das ist normal! Dein Computer kann mehrere Netzwerk-Interfaces haben
- Suche nach der IP, die mit `192.168.178` beginnt
- Das ist deine lokale Netzwerk-IP

### Problem: Ich verstehe die Subnetzmaske nicht

**Lösung**:
- Denke an eine Postleitzahl: Die ersten Zahlen sind das Gebiet (Netzwerk), die letzten sind die Straße (Computer)
- `/24` bedeutet einfach: Die ersten 24 Bits sind das Netzwerk
- Für den Anfang reicht es zu wissen: `/24` = 254 mögliche Geräte

---

## 📝 Zusammenfassung

**Was hast du gelernt?**

1. **IP-Adresse**: Eindeutige Adresse für jedes Gerät im Netzwerk
2. **Format**: `XXX.XXX.XXX.XXX` (z.B. `192.168.178.1`)
3. **Subnetzmaske**: Zeigt, welcher Teil Netzwerk und welcher Computer ist
4. **Private IPs**: Nur lokal gültig (z.B. `192.168.x.x`)
5. **Öffentliche IPs**: Weltweit eindeutig (vom ISP zugewiesen)

**Wichtige Begriffe**:
- **IP-Adresse**: Eindeutige Adresse eines Geräts (Layer 3)
- **Subnetzmaske**: Definiert Netzwerk- und Host-Teil (z.B. 255.255.255.0)
- **CIDR-Notation**: Kompakte Schreibweise für Subnetze (z.B. /24)
- **Präfix-Länge**: Anzahl der Bits für das Netzwerk (z.B. /24 = 24 Bits)
- **Netzwerk-Adresse**: Erste Adresse im Subnetz (Host-Bits = 0)
- **Broadcast-Adresse**: Letzte Adresse im Subnetz (Host-Bits = 1)
- **Host-Adresse**: Adresse für ein Gerät (.1 bis .254 bei /24)
- **Subnetz**: Gruppe von Geräten im gleichen Netzwerk
- **Subnetting**: Aufteilen eines Netzwerks in kleinere Subnetze
- **Supernetting**: Zusammenfassen mehrerer Netzwerke
- **RFC 1918**: Spezifikation für private IP-Adressbereiche
- **Gateway**: Router, der das Netzwerk verlässt
- **NAT**: Network Address Translation - Übersetzung privater in öffentliche IPs
- **APIPA**: Automatic Private IP Addressing (169.254.0.0/16)
- **Loopback**: 127.0.0.1 (localhost) - Adresse für lokale Tests
- **Link-Local**: Automatisch vergebene Adressen ohne DHCP (169.254.0.0/16)
- **Multicast**: Gruppenkommunikation (224.0.0.0/4)
- **Unicast**: Punkt-zu-Punkt Kommunikation
- **Anycast**: Eine IP-Adresse für mehrere Geräte (nächstes Gerät erhält Paket)
- **Wildcard-Maske**: Umkehrung der Subnetzmaske (für Routing)
- **VLSM**: Variable Length Subnet Masking - unterschiedliche Subnetzmasken
- **DHCP**: Automatische IP-Vergabe
- **Statische IP**: Feste, nicht änderbare IP-Adresse

**Deine Netzwerk-Daten**:
- **Subnetz**: `192.168.178.0/24`
- **Gateway**: `192.168.178.1`
- **DHCP-Bereich**: `192.168.178.40 - 200`
- **Cluster Nodes**: `.29 - .32` (statisch)

---

## 🔗 Verweise

**Handbuch-Kapitel**:
- Kapitel 2.3: Lokales Netzwerk
- Kapitel 5.1: IP-Adressierung

**Nächstes Modul**:  
➡️ [Modul 03: Router, Switch und Gateway](../TUTORIAL.md#modul-03-router-switch-und-gateway)

---

## 🎓 Selbstprüfung

Beantworte diese Fragen für dich selbst:

- [ ] Kann ich meine eigene IP-Adresse finden?
- [ ] Verstehe ich das Format einer IPv4-Adresse?
- [ ] Kann ich erklären, was eine Subnetzmaske ist?
- [ ] Weiß ich, welche IP-Adressen meine Cluster Nodes haben?
- [ ] Verstehe ich den Unterschied zwischen privaten und öffentlichen IPs?

**Wenn du alle Fragen mit "Ja" beantworten kannst, bist du bereit für Modul 03!** 🎉

---

**Ende Modul 02**
