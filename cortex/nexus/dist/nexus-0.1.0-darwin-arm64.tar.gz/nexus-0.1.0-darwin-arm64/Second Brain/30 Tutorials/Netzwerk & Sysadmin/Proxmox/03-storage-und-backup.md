# Proxmox Tutorial 03 — Storage und Backup

> **Voraussetzungen:** 01-grundlagen.md, 02-vms-und-container.md
> **Ziel:** Storage-Pools verstehen, Backups einrichten und automatisieren.

---

## Storage-Konzepte

Proxmox unterscheidet zwischen verschiedenen Storage-Typen:

### Lokaler Storage

Direkt an den Server angeschlossene Festplatten:

| Typ | Beschreibung | Einsatz |
|-----|-------------|---------|
| **Directory** | Einfacher Ordner auf dem Dateisystem | ISOs, Templates, Backups |
| **LVM** | Logical Volume Manager — flexible Partitionen | VM-Disks |
| **LVM-Thin** | LVM mit Thin Provisioning (Platz wird erst bei Bedarf belegt) | VM-Disks (effizient) |
| **ZFS** | Modernes Dateisystem mit eingebauter Redundanz | Alles (empfohlen) |

### ZFS — Das Dateisystem der Wahl

ZFS ist auf dem Praxis-Server im Einsatz und bietet:

- **Datenintegrität:** Erkennt und repariert Bitrot automatisch
- **Snapshots:** Momentaufnahmen ohne Platzverlust
- **Compression:** Daten werden automatisch komprimiert (spart Platz)
- **Mirror/RAID:** Eingebaute Redundanz
- **Scrub:** Regelmäßige Integritätsprüfung

**Die Storage-Pools auf dem Praxis-Server:**

```
rpool (2× NVMe Mirror)
├── rpool/ROOT          ← Proxmox-System
├── rpool/data          ← Schnelle VM-Disks
└── rpool/swap          ← Swap-Bereich

SSDPool1 (2× U.2 NVMe Mirror)
└── Große VMs, Datenbanken

HDDPool1 (4× SATA HDD)
└── Backups, Archiv
```

## Backup-Strategien

Backups sind das Wichtigste auf einem Server. Ohne Backup ist jeder Fehler,
jeder Hardwareausfall und jeder Ransomware-Angriff eine Katastrophe.

### Die 3-2-1-Regel

- **3** Kopien deiner Daten (Original + 2 Backups)
- **2** verschiedene Medien (z.B. SSD + HDD, oder lokal + Cloud)
- **1** Kopie außer Haus (Offsite-Backup)

### Backup-Typen in Proxmox

| Typ | Beschreibung | Dauer | Platzbedarf |
|-----|-------------|-------|-------------|
| **Full Backup** | Komplette Kopie der VM | Lang | Hoch |
| **Snapshot-Backup** | VM läuft weiter während des Backups | Mittel | Hoch |
| **Incremental** | Nur Änderungen seit letztem Backup | Kurz | Niedrig |

### Backup-Schedule einrichten

Automatische Backups sind Pflicht. So richtest du sie ein:

1. **Datacenter** → **Backup** (links im Menü)
2. **Add** → Neuen Backup-Job erstellen:
   - **Node:** Dein Server
   - **Storage:** `HDDPool1` (oder externer Storage)
   - **Schedule:** z.B. `daily at 02:00` (nachts, wenn niemand arbeitet)
   - **Selection Mode:** `All` oder bestimmte VMs auswählen
   - **Mode:** `Snapshot` (VM muss nicht gestoppt werden)
   - **Compression:** `zstd` (schnell und effizient)
   - **Retention:** z.B. 7 tägliche, 4 wöchentliche, 3 monatliche
3. **Create**

### Retention (Aufbewahrung)

Nicht jedes Backup muss ewig aufbewahrt werden:

```
Tägliche Backups:    7 Stück behalten (letzte Woche)
Wöchentliche:        4 Stück behalten (letzter Monat)
Monatliche:          3 Stück behalten (letztes Quartal)
```

So hast du immer 14 Wiederherstellungspunkte, ohne dass der Speicher überläuft.

## Backup wiederherstellen

Im Ernstfall — so stellst du eine VM wieder her:

1. **Storage** → **HDDPool1** (oder wo die Backups liegen) → **Backups**
2. Backup-Datei auswählen (z.B. `vzdump-qemu-100-2026_04_03-02_00_00.vma.zst`)
3. **Restore** klicken
4. Ziel-Storage und VM-ID auswählen
5. **Restore** — VM wird wiederhergestellt

**Wichtig:** Teste die Wiederherstellung regelmäßig! Ein Backup, das nicht
funktioniert, ist kein Backup.

## ZFS-Wartung

### Scrub — Integritätsprüfung

ZFS prüft regelmäßig alle Daten auf Fehler. Das passiert automatisch
(Standard: monatlich), kann aber auch manuell angestoßen werden:

```bash
# Scrub starten
zpool scrub rpool

# Status prüfen
zpool status
```

Ein Scrub sollte keine Fehler finden. Wenn doch, hat ZFS sie automatisch
repariert (dank Mirror).

### Speicherplatz prüfen

```bash
# ZFS-Pools anzeigen
zpool list

# Detaillierte Belegung
zfs list

# Snapshots (belegen auch Platz!)
zfs list -t snapshot
```

**Faustregel:** ZFS-Pools sollten nie über 80% Belegung kommen.
Darüber hinaus wird die Performance deutlich schlechter.

---

## Nächste Schritte

- **04-netzwerk.md** — Netzwerk-Konfiguration und VLANs
- **05-sicherheit.md** — Firewall und Zugriffsschutz
