# Proxmox 04 — Claude-Workflow

> Was Claude für dich automatisiert machen kann.

---

## Netzwerk-Diagramm erstellen

```
"Claude, erstelle ein Netzwerk-Diagramm für unsere Praxis
mit allen VLANs, Servern und Geräten."

→ Claude erstellt ein Mermaid- oder SVG-Diagramm basierend
  auf der Praxis-Konfiguration.
```

## Firewall-Regeln generieren

```
"Claude, erstelle Firewall-Regeln für Proxmox,
die die Medizintechnik vom Rest des Netzwerks isolieren."

→ Claude generiert die iptables-Regeln oder die Web-Interface-Konfiguration.
```

## VLAN-Planung

```
"Claude, plane die VLAN-Struktur für die Praxis mit
Server, Arbeitsplätze, Medizintechnik und Gäste-WLAN."

→ Claude erstellt einen vollständigen VLAN-Plan mit
  IP-Bereichen, Subnetzmasken und Routing-Regeln.
```

## Einschränkungen

- Netzwerk-Änderungen können den Server-Zugriff unterbrechen
- Immer erst planen lassen, dann manuell umsetzen
- Bei VLAN-Änderungen: Physischen Switch-Zugriff sicherstellen
