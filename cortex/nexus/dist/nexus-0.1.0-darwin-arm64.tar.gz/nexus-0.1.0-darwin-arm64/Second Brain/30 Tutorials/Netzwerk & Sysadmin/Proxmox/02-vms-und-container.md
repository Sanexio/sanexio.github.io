# Proxmox Tutorial 02 — VMs und Container

> **Voraussetzungen:** 01-grundlagen.md
> **Ziel:** VMs und Container erstellen, konfigurieren und verwalten.

---

## Virtuelle Maschinen (VMs) erstellen

### Was du brauchst

Bevor du eine VM erstellen kannst, brauchst du ein **ISO-Image** — das ist die
Installationsdatei des Betriebssystems (wie eine virtuelle CD). ISOs lädst du
vorher hoch:

1. Web-Interface → Storage (z.B. `local`) → **ISO Images** → **Upload**
2. ISO-Datei auswählen (z.B. `Win2025_Server.iso` oder `ubuntu-24.04.iso`)

### VM-Erstellung Schritt für Schritt

Klicke oben rechts auf **Create VM**. Der Assistent führt dich durch:

**Tab 1 — General:**
- **VM ID:** Eindeutige Nummer (z.B. 100, 101, 102 — Proxmox schlägt die nächste freie vor)
- **Name:** Sprechender Name (z.B. `dc01-win`, `fileserver`, `pihole`)

**Tab 2 — OS:**
- ISO-Image auswählen
- Typ: `Microsoft Windows` oder `Linux` (je nach OS)

**Tab 3 — System:**
- **BIOS:** OVMF (UEFI) für moderne Systeme, SeaBIOS für ältere
- **Machine:** q35 (Standard für moderne VMs)
- **TPM:** Für Windows 11/2025 aktivieren

**Tab 4 — Disks:**
- **Storage:** Wo die virtuelle Festplatte liegt (z.B. SSDPool1)
- **Disk Size:** Wie groß (z.B. 64 GB für Windows, 32 GB für Linux)
- **Format:** raw (schneller) oder qcow2 (Snapshots möglich)

**Tab 5 — CPU:**
- **Cores:** Anzahl CPU-Kerne (z.B. 4 für einen Server)
- **Type:** `host` für beste Performance, `x86-64-v3` für Kompatibilität

**Tab 6 — Memory:**
- **Memory:** RAM in MB (z.B. 8192 = 8 GB)
- **Ballooning:** Kann RAM dynamisch anpassen (empfohlen: aktivieren)

**Tab 7 — Network:**
- **Bridge:** `vmbr0` (Standard-Netzwerkbrücke)
- **Model:** VirtIO (schnellster virtuelle Netzwerk-Adapter)

**Confirm → Finish** — VM ist erstellt, aber noch nicht gestartet.

### Typische VM-Konfigurationen

| VM | Zweck | CPU | RAM | Disk | OS |
|----|-------|-----|-----|------|----|
| Domain Controller | AD, DNS, DHCP | 4 Kerne | 8 GB | 64 GB (SSD) | Windows Server 2025 |
| File Server | Dateiablage | 4 Kerne | 16 GB | 200 GB (SSD) + HDD-Mount | Windows Server 2025 |
| Application Server | Praxissoftware | 4 Kerne | 16 GB | 128 GB (SSD) | Windows Server 2025 |
| Linux-Test | Experimente | 2 Kerne | 4 GB | 32 GB (SSD) | Ubuntu 24.04 |

## Container (LXC) erstellen

Container sind schneller einzurichten als VMs:

### Templates herunterladen

1. Storage (z.B. `local`) → **CT Templates** → **Templates**
2. Template auswählen (z.B. `ubuntu-24.04-standard`, `debian-12-standard`)
3. Herunterladen

### Container-Erstellung

Klicke oben rechts auf **Create CT**:

**Basics:**
- **CT ID:** Nummer (z.B. 200, 201)
- **Hostname:** z.B. `pihole`, `monitoring`
- **Password:** Root-Passwort für den Container

**Template:** Vorher heruntergeladenes Template auswählen

**Disks:** Speicherplatz (oft reichen 8–16 GB)

**CPU:** 1–2 Kerne reichen meist

**Memory:** 512 MB – 2 GB je nach Dienst

**Network:** IP-Adresse (statisch empfohlen) oder DHCP

### Typische Container-Einsätze

| Container | Zweck | CPU | RAM | Disk |
|-----------|-------|-----|-----|------|
| Pi-Hole | DNS-basierter Werbeblocker | 1 Kern | 512 MB | 8 GB |
| Nginx Proxy | Reverse Proxy für Webdienste | 1 Kern | 512 MB | 4 GB |
| Monitoring | Grafana + Prometheus | 2 Kerne | 2 GB | 16 GB |
| Docker-Host | Docker-Container betreiben | 2 Kerne | 4 GB | 32 GB |

## VM/Container verwalten

### Snapshots — Sicherheitsnetz vor Änderungen

Ein Snapshot friert den aktuellen Zustand ein. Wenn danach etwas schiefgeht,
kannst du in Sekunden zurückrollen:

1. VM/CT auswählen → **Snapshots** Tab
2. **Take Snapshot** → Namen vergeben (z.B. "vor-update")
3. Änderung durchführen
4. Falls nötig: **Rollback** zum Snapshot

**Faustregel:** VOR jedem Windows-Update oder Software-Installation einen
Snapshot machen.

### Ressourcen ändern

CPU und RAM können im laufenden Betrieb (Hotplug) oder nach Neustart geändert
werden:

1. VM/CT auswählen → **Hardware** Tab
2. Doppelklick auf "Memory" oder "Processors"
3. Werte anpassen → OK
4. Je nach Einstellung: Neustart nötig

### Klonen

Eine bestehende VM als Vorlage nutzen:

1. VM rechtsklick → **Clone**
2. **Full Clone** (komplett eigenständige Kopie) oder **Linked Clone** (teilt Basis-Disk)
3. Neue ID und Namen vergeben

## Häufige Probleme

**VM startet nicht:**
- Genug RAM frei? (Node → Summary → Memory prüfen)
- ISO noch eingehängt? (Hardware → CD-Drive prüfen)
- UEFI/BIOS richtig eingestellt?

**Container hat kein Netzwerk:**
- IP-Adresse korrekt konfiguriert?
- Bridge richtig zugewiesen?
- Firewall blockiert? (Datacenter → Firewall prüfen)

**Windows-VM ist langsam:**
- VirtIO-Treiber installiert? (Ohne: Standard-Emulation, sehr langsam)
- Ballooning-Agent in Windows installiert?

---

## Nächste Schritte

- **03-storage-und-backup.md** — Speicher organisieren und Backups automatisieren
- **04-netzwerk.md** — Netzwerke konfigurieren
