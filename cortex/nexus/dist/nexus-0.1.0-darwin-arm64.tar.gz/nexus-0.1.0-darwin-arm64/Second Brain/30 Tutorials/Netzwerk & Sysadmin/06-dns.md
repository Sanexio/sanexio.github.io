# Modul 05: DNS - Namensauflösung

**Dauer**: 20 Minuten  
**Schwierigkeit**: ⭐⭐ Mittel  
**Voraussetzungen**: Modul 02, Modul 03  
**Version**: 0.3

---

## 📚 Theorie

### Was ist DNS?

**DNS** steht für **Domain Name System** (Domain-Namen-System).

**Einfach erklärt**: DNS ist wie ein **Telefonbuch für das Internet**. Statt sich IP-Adressen merken zu müssen (z.B. `142.250.185.14`), kannst du einfach einen Namen verwenden (z.B. `google.com`). DNS übersetzt den Namen in die IP-Adresse.

**Ohne DNS**: Du müsstest IP-Adressen auswendig lernen.  
**Mit DNS**: Du gibst einfach `google.com` ein, DNS findet die IP-Adresse automatisch.

### Wie funktioniert DNS?

**Der DNS-Prozess** (vereinfacht):

1. **Du gibst ein**: `google.com` im Browser
2. **Dein Computer fragt DNS-Server**: "Was ist die IP-Adresse von google.com?"
3. **DNS-Server antwortet**: "142.250.185.14"
4. **Dein Computer verbindet sich** mit dieser IP-Adresse

**Dein DNS-Server**: FRITZ!Box 7530 AX (192.168.178.1)

### Lokale vs. Internet-DNS

**Lokale DNS** (in deinem Netzwerk):
- Auflösung von Hostnamen wie `Cluster-Mini-01.fritz.box`
- Verwaltet von deiner FRITZ!Box
- Funktioniert nur im lokalen Netzwerk

**Internet-DNS**:
- Auflösung von Domain-Namen wie `google.com`
- Verwaltet von DNS-Servern im Internet
- Funktioniert weltweit

**Deine FRITZ!Box**: Macht beides!
- Lokale Namensauflösung (`.fritz.box`)
- Weiterleitung an Internet-DNS-Server

### DNS-Server Hierarchie

**Wie DNS funktioniert** (vereinfacht):

1. **Dein Computer** fragt lokalen DNS-Server (FRITZ!Box)
2. **FRITZ!Box** fragt ISP-DNS-Server (Vodafone)
3. **ISP-DNS** fragt Root-DNS-Server
4. **Root-DNS** verweist an Top-Level-Domain-Server (.com)
5. **TLD-Server** verweist an Domain-Server (google.com)
6. **Domain-Server** gibt IP-Adresse zurück
7. **Antwort** kommt zurück zu deinem Computer

**Caching**: Jede Stufe speichert die Antwort, damit nicht jedes Mal die ganze Kette durchlaufen werden muss.

### Erweiterte DNS-Konzepte

**DNS-Record-Typen**: Verschiedene Arten von DNS-Einträgen:
- **A-Record**: IPv4-Adresse (z.B. google.com → 142.250.185.14)
- **AAAA-Record**: IPv6-Adresse
- **CNAME-Record**: Alias für einen anderen Namen (z.B. www → example.com)
- **MX-Record**: Mail Exchange - E-Mail-Server
- **PTR-Record**: Reverse DNS - IP zu Name (z.B. 14.185.250.142.in-addr.arpa → google.com)
- **NS-Record**: Name Server - autoritativer DNS-Server für eine Domain
- **SOA-Record**: Start of Authority - Informationen über die Zone
- **TXT-Record**: Text-Einträge (z.B. für SPF, DKIM)
- **SRV-Record**: Service-Lokalisierung (z.B. für SIP, LDAP)

**Authoritative DNS-Server**: Ein DNS-Server, der die autoritative Antwort für eine Domain hat. Enthält die originalen DNS-Records.

**Recursive DNS-Server**: Ein DNS-Server, der Anfragen für den Client löst, indem er andere Server fragt. Deine FRITZ!Box ist ein Recursive DNS-Server.

**Root DNS-Server**: 13 Root-Server weltweit (a.root-servers.net bis m.root-servers.net). Der Einstiegspunkt für alle DNS-Anfragen.

**TLD-Server (Top-Level Domain)**: Server für Top-Level-Domains wie .com, .de, .org. Verwaltet von Registry-Organisationen.

**DNS-Zone**: Ein Bereich der DNS-Hierarchie, der von einem autoritativen Server verwaltet wird. Beispiel: Die Zone "google.com" wird von Google's DNS-Servern verwaltet.

**Zone File**: Eine Datei mit allen DNS-Records einer Zone.

**DNS-Forwarder**: Ein DNS-Server, der Anfragen an andere Server weiterleitet. Deine FRITZ!Box leitet an ISP-DNS-Server weiter.

**DNS-Cache**: Gespeicherte DNS-Antworten für schnellere Auflösung. Reduziert Netzwerk-Traffic und verbessert Performance.

**TTL (Time To Live)**: Gültigkeitsdauer eines DNS-Records im Cache. Nach Ablauf wird der Record erneut abgefragt.

**DNS-Propagation**: Die Zeit, die benötigt wird, bis DNS-Änderungen weltweit sichtbar sind. Abhängig von TTL-Werten.

**Round-Robin DNS**: Mehrere IP-Adressen für einen Namen. Server werden abwechselnd zurückgegeben für Lastverteilung.

**DNS-Load Balancing**: Verteilung von Anfragen auf mehrere Server durch DNS.

**Split-Brain DNS**: Verschiedene DNS-Antworten je nach Quelle (z.B. intern vs. extern).

**DNS-Spoofing**: Angriff, bei dem falsche DNS-Antworten gegeben werden. Wird durch DNSSEC verhindert.

**DNSSEC (DNS Security Extensions)**: Kryptografische Signierung von DNS-Records zur Verhinderung von Spoofing.

**DNS-over-HTTPS (DoH)**: DNS-Anfragen über HTTPS verschlüsselt. Verbessert Privatsphäre.

**DNS-over-TLS (DoT)**: DNS-Anfragen über TLS verschlüsselt. Alternative zu DoH.

**mDNS (Multicast DNS)**: Lokale Namensauflösung ohne zentralen Server. Verwendet von Apple (Bonjour) und Linux (Avahi). `.local` Domain.

**LLMNR (Link-Local Multicast Name Resolution)**: Windows-Alternative zu mDNS für lokale Namensauflösung.

**DNS-Server-Hierarchie**:
1. **Stub Resolver**: Auf dem Client (z.B. macOS resolver)
2. **Recursive Resolver**: FRITZ!Box oder ISP-DNS
3. **Root-Server**: Einstiegspunkt (.root-servers.net)
4. **TLD-Server**: Top-Level-Domain (.com, .de)
5. **Authoritative Server**: Domain-spezifischer Server

**DNS-Query-Typen**:
- **Iterative Query**: Server gibt Verweis auf anderen Server zurück
- **Recursive Query**: Server löst vollständig auf und gibt Antwort zurück

**DNS-Port**: UDP Port 53 (Standard), TCP Port 53 (für große Antworten oder Zone-Transfers).

**Zone Transfer**: Übertragung einer kompletten Zone von einem DNS-Server zu einem anderen. Wird für Replikation verwendet.

**DNS-Resolver**: Software, die DNS-Anfragen stellt. Teil des Betriebssystems oder als separater Service.

**DNS-Root-Hints**: Liste der Root-DNS-Server. Wird verwendet, um den ersten Kontakt herzustellen.

**DNS-Suffix**: Automatisch angehängter Domain-Name. Beispiel: `.fritz.box` wird automatisch angehängt.

**FQDN (Fully Qualified Domain Name)**: Vollständiger Domain-Name inklusive aller Ebenen. Beispiel: `Cluster-Mini-01.fritz.box.` (mit Punkt am Ende).

**Hostname**: Name eines Geräts ohne Domain. Beispiel: `Cluster-Mini-01`.

**DNS-Round-Trip-Time**: Zeit für eine DNS-Anfrage und Antwort. Wird durch Caching reduziert.

---

## 🎯 Ziel dieses Moduls

Nach diesem Modul verstehst du:
- ✅ Was DNS ist und wie es funktioniert
- ✅ Unterschied zwischen lokaler und Internet-DNS-Auflösung
- ✅ DNS-Server-Konfiguration verstehen
- ✅ Hostnamen auflösen können
- ✅ DNS-Probleme diagnostizieren können
- ✅ DNS-Record-Typen kennen (A, AAAA, CNAME, MX, PTR, NS, SOA, TXT, SRV)
- ✅ Authoritative vs. Recursive DNS-Server unterscheiden
- ✅ DNS-Hierarchie verstehen (Root, TLD, Authoritative)
- ✅ DNS-Caching, TTL, Propagation verstehen
- ✅ DNSSEC, DoH, DoT kennen
- ✅ mDNS, LLMNR für lokale Auflösung verstehen

---

## 📋 Schritt-für-Schritt

### Schritt 1: DNS-Server-Konfiguration prüfen

**Was machen wir?**  
Wir schauen uns die DNS-Konfiguration deiner FRITZ!Box an.

1. Öffne die FRITZ!Box Oberfläche: `http://192.168.178.1`

2. Gehe zu **"Internet"** → **"Zugangsdaten"** → **"DNS-Server"**

**Erwartetes Ergebnis**:  
Du siehst:
- ✅ "Vom Internetanbieter zugewiesene DNSv4-Server verwenden" (aktiviert)
- ✅ "Vom Internetanbieter zugewiesene DNSv6-Server verwenden" (aktiviert)

**Das bedeutet**:
- FRITZ!Box verwendet automatisch die DNS-Server von Vodafone
- Weiterleitung an ISP-DNS-Server für Internet-Auflösung
- Lokale DNS-Auflösung (`.fritz.box`) funktioniert zusätzlich

---

### Schritt 2: Lokale DNS-Auflösung testen

**Was machen wir?**  
Wir testen, ob lokale Hostnamen aufgelöst werden können.

**macOS Terminal**:

1. Öffne das Terminal

2. Teste die Auflösung eines Cluster Nodes:
```bash
ping -c 2 Cluster-Mini-01.fritz.box
```

**Erwartetes Ergebnis**:  
Du siehst:
```
PING Cluster-Mini-01.fritz.box (192.168.178.29): 56 data bytes
64 bytes from 192.168.178.29: icmp_seq=0 ttl=64 time=0.123 ms
64 bytes from 192.168.178.29: icmp_seq=1 ttl=64 time=0.145 ms
```

**Das bedeutet**:
- Hostname `Cluster-Mini-01.fritz.box` wurde aufgelöst
- IP-Adresse: `192.168.178.29`
- Gerät ist erreichbar

**Alternative - nur Auflösung (ohne Ping)**:
```bash
nslookup Cluster-Mini-01.fritz.box
```

---

### Schritt 3: Internet-DNS-Auflösung testen

**Was machen wir?**  
Wir testen, ob Internet-Domains aufgelöst werden können.

**macOS Terminal**:

1. Teste die Auflösung von google.com:
```bash
nslookup google.com
```

**Erwartetes Ergebnis**:  
Du siehst:
```
Server:		192.168.178.1
Address:	192.168.178.1#53

Non-authoritative answer:
Name:	google.com
Address: 142.250.185.14
```

**Das bedeutet**:
- DNS-Server: `192.168.178.1` (deine FRITZ!Box)
- Domain: `google.com`
- IP-Adresse: `142.250.185.14`
- "Non-authoritative": Antwort kommt aus Cache, nicht direkt vom Domain-Server

**Alternative - mit dig**:
```bash
dig google.com
```

---

### Schritt 4: DNS-Server-Hierarchie verstehen

**Was machen wir?**  
Wir verstehen, welche DNS-Server verwendet werden.

**DNS-Server-Kette**:

1. **Dein Computer** → Fragt lokalen DNS-Server
   - DNS-Server: `192.168.178.1` (FRITZ!Box)

2. **FRITZ!Box** → Weiterleitung an ISP-DNS
   - DNS-Server: Vom Vodafone zugewiesen (automatisch)

3. **ISP-DNS** → Fragt Root-DNS-Server
   - Root-Server: `.` (Root des DNS-Baums)

4. **Root-DNS** → Verweist an TLD-Server
   - TLD-Server: `.com`, `.de`, etc.

5. **TLD-Server** → Verweist an Domain-Server
   - Domain-Server: `google.com`

6. **Domain-Server** → Gibt IP-Adresse zurück
   - IP: `142.250.185.14`

**Caching**: Jede Stufe speichert die Antwort für spätere Anfragen.

---

### Schritt 5: Lokale Hostnamen auflösen

**Was machen wir?**  
Wir testen die Auflösung aller Cluster Nodes.

**macOS Terminal**:

```bash
# Alle Cluster Nodes auflösen
for node in Cluster-Mini-01 Cluster-Mini-02 Cluster-Mini-03 Cluster-Mini-04; do
    echo "=== $node.fritz.box ==="
    nslookup $node.fritz.box | grep -A 1 "Name:"
done
```

**Erwartetes Ergebnis**:  
Du siehst für jeden Node:
```
=== Cluster-Mini-01.fritz.box ===
Name:	Cluster-Mini-01.fritz.box
Address: 192.168.178.29
```

**Das bedeutet**:
- Lokale DNS-Auflösung funktioniert
- Jeder Node hat einen Hostnamen
- Hostnamen werden automatisch von FRITZ!Box verwaltet

---

## 💻 Befehle

### DNS-Auflösung testen

```bash
# Hostname auflösen (nslookup)
nslookup hostname

# Oder mit dig (detaillierter)
dig hostname

# Oder mit host (einfach)
host hostname
```

### DNS-Server anzeigen

```bash
# macOS
scutil --dns | grep "nameserver\[0\]"

# Oder
cat /etc/resolv.conf

# Linux
cat /etc/resolv.conf
```

### DNS-Cache leeren (macOS)

```bash
# DNS-Cache leeren
sudo dscacheutil -flushcache
sudo killall -HUP mDNSResponder
```

### Ping mit Hostname

```bash
# Hostname auflösen und ping
ping -c 4 Cluster-Mini-01.fritz.box

# Nur IP anzeigen
ping -c 1 Cluster-Mini-01.fritz.box | grep "PING" | awk '{print $3}' | tr -d '()'
```

---

## ✅ Erwartetes Ergebnis

Nach diesem Modul solltest du:

1. ✅ Verstehen, was DNS ist und wie es funktioniert
2. ✅ Lokale Hostnamen auflösen können
3. ✅ Internet-Domains auflösen können
4. ✅ DNS-Server-Konfiguration verstehen
5. ✅ DNS-Probleme diagnostizieren können

---

## ⚠️ Mögliche Fehlerquellen

### Problem: Hostname wird nicht aufgelöst

**Lösung**:
- Prüfe, ob Gerät eingeschaltet ist
- Prüfe Netzwerkverbindung
- Prüfe DNS-Server-Konfiguration
- Versuche mit IP-Adresse direkt (z.B. `ping 192.168.178.29`)

### Problem: Internet-Domains werden nicht aufgelöst

**Lösung**:
- Prüfe Internetverbindung
- Prüfe DNS-Server-Konfiguration in FRITZ!Box
- Versuche anderen DNS-Server (z.B. Google: `8.8.8.8`)
- DNS-Cache leeren

### Problem: DNS-Auflösung ist langsam

**Lösung**:
- Das ist normal beim ersten Mal (DNS muss auflösen)
- Nachfolgende Anfragen sind schneller (Caching)
- Prüfe Internetverbindung
- Prüfe DNS-Server (manchmal sind andere DNS-Server schneller)

---

## 📝 Zusammenfassung

**Was hast du gelernt?**

1. **DNS**: Übersetzt Namen in IP-Adressen
2. **DNS-Server**: Beantwortet DNS-Anfragen
3. **Lokale DNS**: Auflösung von Hostnamen im Netzwerk (`.fritz.box`)
4. **Internet-DNS**: Auflösung von Domain-Namen (`.com`, `.de`)
5. **DNS-Hierarchie**: Mehrstufiges System mit Caching

**Wichtige Begriffe**:
- **DNS**: Domain Name System
- **DNS-Server**: Beantwortet DNS-Anfragen
- **A-Record**: IPv4-Adresse (z.B. google.com → 142.250.185.14)
- **AAAA-Record**: IPv6-Adresse
- **CNAME-Record**: Alias für einen anderen Namen
- **MX-Record**: Mail Exchange - E-Mail-Server
- **PTR-Record**: Reverse DNS - IP zu Name
- **NS-Record**: Name Server - autoritativer DNS-Server
- **SOA-Record**: Start of Authority - Zone-Informationen
- **TXT-Record**: Text-Einträge (SPF, DKIM)
- **SRV-Record**: Service-Lokalisierung
- **Authoritative DNS-Server**: Hat autoritative Antwort für Domain
- **Recursive DNS-Server**: Löst Anfragen durch Abfrage anderer Server
- **Root DNS-Server**: Einstiegspunkt (a.root-servers.net bis m.root-servers.net)
- **TLD-Server**: Top-Level-Domain Server (.com, .de)
- **DNS-Zone**: Bereich der DNS-Hierarchie
- **Zone File**: Datei mit DNS-Records einer Zone
- **DNS-Forwarder**: Weiterleitung an andere Server
- **DNS-Cache**: Gespeicherte DNS-Antworten
- **TTL**: Time To Live - Gültigkeitsdauer im Cache
- **DNS-Propagation**: Zeit für weltweite Verbreitung von Änderungen
- **Round-Robin DNS**: Mehrere IPs für Lastverteilung
- **DNS-Load Balancing**: Lastverteilung durch DNS
- **Split-Brain DNS**: Verschiedene Antworten je nach Quelle
- **DNS-Spoofing**: Angriff mit falschen DNS-Antworten
- **DNSSEC**: DNS Security Extensions - kryptografische Signierung
- **DNS-over-HTTPS (DoH)**: Verschlüsselte DNS über HTTPS
- **DNS-over-TLS (DoT)**: Verschlüsselte DNS über TLS
- **mDNS**: Multicast DNS - lokale Auflösung (.local)
- **LLMNR**: Link-Local Multicast Name Resolution (Windows)
- **DNS-Query-Typen**: Iterative vs. Recursive Query
- **DNS-Port**: UDP/TCP Port 53
- **Zone Transfer**: Übertragung einer Zone zwischen Servern
- **DNS-Resolver**: Software für DNS-Anfragen
- **DNS-Root-Hints**: Liste der Root-Server
- **DNS-Suffix**: Automatisch angehängter Domain-Name
- **FQDN**: Fully Qualified Domain Name - vollständiger Name
- **Hostname**: Name ohne Domain
- **DNS-Round-Trip-Time**: Zeit für DNS-Anfrage/Antwort

**Deine DNS-Konfiguration**:
- **Lokaler DNS-Server**: FRITZ!Box (192.168.178.1)
- **Internet-DNS**: Vom ISP zugewiesen (automatisch)
- **Lokale Domain**: `.fritz.box`
- **Hostnamen**: Cluster-Mini-01.fritz.box → 192.168.178.29

---

## 🔗 Verweise

**Handbuch-Kapitel**:
- Kapitel 2.3: Lokales Netzwerk
- Kapitel 5.3: DNS-Konfiguration

**Nächstes Modul**:  
➡️ [Modul 06: Netzwerkscan durchführen](../TUTORIAL.md#modul-06-netzwerkscan-durchführen)

---

## 🎓 Selbstprüfung

Beantworte diese Fragen für dich selbst:

- [ ] Kann ich erklären, was DNS ist?
- [ ] Kann ich lokale Hostnamen auflösen?
- [ ] Kann ich Internet-Domains auflösen?
- [ ] Verstehe ich die DNS-Server-Konfiguration?
- [ ] Kann ich DNS-Probleme diagnostizieren?

**Wenn du alle Fragen mit "Ja" beantworten kannst, bist du bereit für Modul 06!** 🎉

---

**Ende Modul 05**
