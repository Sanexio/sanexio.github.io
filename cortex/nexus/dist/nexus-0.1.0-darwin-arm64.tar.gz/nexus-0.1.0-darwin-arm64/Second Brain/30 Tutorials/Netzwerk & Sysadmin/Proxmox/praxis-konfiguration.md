# Proxmox — Praxis-Konfiguration (Referenz)

> **ACHTUNG:** Diese Datei enthält sensible Informationen (IP-Adressen,
> Zugangsdaten, Hardware-Seriennummern). Nicht teilen oder veröffentlichen.
>
> **Quelle:** Systemdokumentation von DIETZ DATA GmbH (08.08.2025)

---

## ISP & Internet

- **ISP-Netzwerk:** 192.168.11.114
- **Gateway:** 192.168.11.254
- **Feste IPv4 (zukünftig):** 217.86.154.23
- **Firewall (WAN-seitig):** 192.168.11.61 — FW01-Leerbachstrasse.digi.box

## Netzwerk-Segmente

| IP-Bereich | Zweck |
|------------|-------|
| 192.168.10.001–009 | Kritische Systeme (DC, Fileserver) |
| 192.168.10.011–029 | Clientbereich (Arbeitsplätze) |
| 192.168.10.030–049 | Hardware-Server-Bereich |
| 192.168.10.050–150 | DHCP-Bereich |
| 192.168.10.254 | Firewall |

## Server-Inventar

| IP | Hostname | Dienst | Zugang |
|----|----------|--------|--------|
| .1 | DC | Domain Controller (DNS, DHCP) | Windows Server 2025 |
| .9 | DC25 | Neuer Domain Controller | Windows Server 2025 |
| .10 | Fileserver | Dateiablage, Medizintechnik | Windows Server 2025 |
| .30 | SONO | Sonographie | Medizintechnik |
| .31 | doc-backhost-pve | Proxmox VE (Backup-Host) | https://192.168.10.31:8006 |
| .32 | doc-backhost-mgmt | IPMI/BMC (Backup-Host) | https://192.168.10.32 |
| .33 | doc-host1-pve | Proxmox VE (Haupt-Host) | https://192.168.10.33:8006 |
| .34 | doc-host1-mgmt | IPMI/BMC (Haupt-Host) | https://192.168.10.34 |
| .35 | doc-raspi | Raspberry Pi | SSH |
| .114 | DC VM | Domain Controller (virtuell) | Linux |

## Hardware-Spezifikation (Haupt-Host)

- **Gehäuse:** Inter-Tech 4U-4410
- **Netzteil:** Enermax Revolution D.F. X 1650W
- **Mainboard:** Supermicro MDB-H13SSL-N
- **CPU:** AMD Epyc 9135
- **RAM:** 4× Samsung 64 GB DDR5-6400 ECC (= 256 GB)
- **Boot-SSDs (rpool):** 2× Samsung PM9A3 960 GB M.2 NVMe (Mirror)
- **Daten-SSDs (SSDPool1):** 2× Samsung PM9A3 7,68 TB U.2 NVMe
- **HDDs (HDDPool1):** 4× Toshiba MG10ADA800E 8 TB SATA
- **NIC:** Broadcom P225P 10/25G
- **GPU:** Zotac GeForce RTX 5060 Ti 16 GB
- **Windows-Lizenz:** Standard 16-Core

## Netzlaufwerke

| Laufwerk | Server-Pfad | Netzwerk-Pfad |
|----------|------------|---------------|
| Userdata | E:\userdata | \\\\fileserver\userdata |
| Medizintechnik | E:\medtec | \\\\fileserver\medtec |

## Support-Kontakt

- **Dienstleister:** DIETZ DATA GmbH
- **Kontakt:** Dietrich Dietz
- **E-Mail:** d.dietz@dietz-data.de
- **Telefon:** 0177-8795077 / 0231-4949994-0

---

*Letzte Aktualisierung: 2025-08-08 (Installation) → Übernommen 2026-04-03*
