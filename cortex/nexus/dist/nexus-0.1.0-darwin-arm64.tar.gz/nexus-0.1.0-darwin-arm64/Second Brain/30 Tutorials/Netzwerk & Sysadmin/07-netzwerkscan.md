# Modul 06: Netzwerkscan durchführen

**Dauer**: 30 Minuten  
**Schwierigkeit**: ⭐⭐ Mittel  
**Voraussetzungen**: Modul 01-05  
**Version**: 0.3

---

## 📚 Theorie

### Was ist ein Netzwerkscan?

Ein **Netzwerkscan** ist wie eine **Bestandsaufnahme deines Netzwerks**. Du sendest Anfragen an alle möglichen IP-Adressen in deinem Netzwerk und schaust, welche Geräte antworten.

**Einfach erklärt**: Stell dir vor, du gehst durch dein Haus und rufst jeden Raum ab, um zu sehen, wer da ist. Ein Netzwerkscan macht das Gleiche - nur mit Computern im Netzwerk.

**Zweck**:
- Alle Geräte im Netzwerk finden
- IP-Adressen identifizieren
- Offene Ports finden
- Netzwerk-Topologie verstehen

### Wie funktioniert ein Netzwerkscan?

**Der Scan-Prozess** (vereinfacht):

1. **Scanner sendet Ping**: "Bist du da?" an jede IP-Adresse
2. **Gerät antwortet**: "Ja, ich bin hier!" (falls eingeschaltet)
3. **Scanner sammelt Antworten**: Liste aller erreichbaren Geräte
4. **Detaillierter Scan**: Weitere Informationen über gefundene Geräte

**Tools**:
- **nmap**: Professionelles Netzwerk-Scanning-Tool
- **ping**: Einfaches Tool zum Testen der Erreichbarkeit
- **arp**: Zeigt bekannte Geräte in der ARP-Tabelle

### nmap - Das Netzwerk-Scanning-Tool

**nmap** (Network Mapper) ist das Standard-Tool für Netzwerk-Scans.

**Funktionen**:
- Findet alle Geräte im Netzwerk
- Zeigt offene Ports
- Identifiziert Betriebssysteme
- Zeigt laufende Dienste

**Installation** (macOS):
```bash
brew install nmap
```

### Erweiterte Scan-Konzepte

**Port**: Ein Endpunkt für Netzwerk-Verbindungen. Jeder Service verwendet einen oder mehrere Ports. Ports 0-1023 sind Well-Known Ports (System-Ports), 1024-49151 sind Registered Ports, 49152-65535 sind Dynamic/Private Ports.

**Port-Status**:
- **Open**: Port ist offen und empfängt Verbindungen
- **Closed**: Port ist geschlossen, aber Gerät antwortet
- **Filtered**: Port ist durch Firewall blockiert, keine Antwort
- **Open|Filtered**: Unklar, ob offen oder gefiltert
- **Closed|Filtered**: Unklar, ob geschlossen oder gefiltert

**TCP-Scan**: Verwendet TCP-Verbindungen. Verschiedene Scan-Typen:
- **SYN-Scan (-sS)**: Sendet SYN-Paket, wartet auf SYN-ACK (Stealth-Scan)
- **Connect-Scan (-sT)**: Vollständige TCP-Verbindung (weniger stealth)
- **FIN-Scan (-sF)**: Sendet FIN-Paket
- **NULL-Scan (-sN)**: Sendet Paket ohne Flags
- **Xmas-Scan (-sX)**: Sendet Paket mit FIN, PSH, URG Flags

**UDP-Scan (-sU)**: Scannt UDP-Ports. Langsamer als TCP, da UDP zustandslos ist.

**OS-Detection (-O)**: Erkennt Betriebssystem durch Analyse von Netzwerk-Paketen.

**Service-Version-Detection (-sV)**: Erkennt Versionen von laufenden Services.

**Script-Scanning (-sC oder --script)**: Verwendet NSE (Nmap Scripting Engine) für erweiterte Tests.

**NSE (Nmap Scripting Engine)**: Skriptsprache für erweiterte nmap-Funktionen. Viele vorgefertigte Scripts verfügbar.

**Stealth-Scanning**: Scan-Techniken, die weniger auffällig sind. SYN-Scan ist stealthier als Connect-Scan.

**Firewall-Evasion**: Techniken zum Umgehen von Firewalls:
- **Fragmentierung (-f)**: Aufteilen von Paketen
- **Decoy-Scans (-D)**: Verstecken der eigenen IP hinter Decoy-IPs
- **Idle-Scan (-sI)**: Verwendung eines Zombie-Hosts
- **Source-Port-Spoofing (--source-port)**: Vortäuschen eines bestimmten Source-Ports

**Timing-Templates (-T0 bis -T5)**: Verschiedene Geschwindigkeitsstufen:
- **T0 (Paranoid)**: Sehr langsam, schwer zu erkennen
- **T1 (Sneaky)**: Langsam
- **T2 (Polite)**: Langsam, aber schneller
- **T3 (Normal)**: Standard-Geschwindigkeit
- **T4 (Aggressive)**: Schnell
- **T5 (Insane)**: Sehr schnell, kann ungenau sein

**Host-Discovery**: Methoden zum Finden aktiver Hosts:
- **Ping-Scan (-sn)**: Nur Host-Discovery, keine Port-Scans
- **ARP-Scan**: Verwendet ARP für lokale Netzwerke
- **ICMP-Echo**: Standard-Ping
- **TCP-SYN-Ping (-PS)**: Sendet SYN an bestimmte Ports
- **TCP-ACK-Ping (-PA)**: Sendet ACK-Pakete
- **UDP-Ping (-PU)**: Sendet UDP-Pakete

**Port-Range**: Spezifische Ports scannen:
- `-p 80,443`: Nur Ports 80 und 443
- `-p 1-1000`: Ports 1 bis 1000
- `-p-`: Alle 65535 Ports

**Output-Formate**:
- **Normal (-oN)**: Menschenlesbares Format
- **XML (-oX)**: XML-Format für Parsing
- **Grepable (-oG)**: Einfaches Format für grep
- **All (-oA)**: Alle Formate

**Banner-Grabbing**: Abrufen von Service-Bannern zur Identifikation. Teil von Service-Version-Detection.

**Fingerprinting**: Identifikation von Services oder Betriebssystemen durch Analyse von Antworten.

**Network-Topology-Discovery**: nmap kann Netzwerk-Topologie erkennen durch Analyse von TTL-Werten und Routing-Informationen.

**Vulnerability-Scanning**: NSE-Scripts können bekannte Schwachstellen scannen.

**Compliance-Scanning**: Prüfung auf Einhaltung von Sicherheitsrichtlinien.

**Network-Mapping**: Erstellung einer Karte des Netzwerks mit allen Geräten und Verbindungen.

**Traffic-Analysis**: Analyse von Netzwerk-Traffic-Mustern.

**Packet-Crafting**: Erstellen von benutzerdefinierten Netzwerk-Paketen für Tests.

**Traceroute**: Verfolgung des Wegs eines Pakets durch das Netzwerk. nmap kann Traceroute integrieren (--traceroute).

**IPv6-Scanning**: nmap unterstützt IPv6-Scans mit `-6` Option.

**Proxied-Scanning**: Scans über Proxy-Server durchführen.

**Parallel-Scanning**: Mehrere Scans gleichzeitig ausführen für Geschwindigkeit.

---

## 🎯 Ziel dieses Moduls

Nach diesem Modul verstehst du:
- ✅ Was ein Netzwerkscan ist und warum er wichtig ist
- ✅ nmap installieren und verwenden können
- ✅ Einen Netzwerkscan durchführen können
- ✅ Scan-Ergebnisse interpretieren können
- ✅ Geräte im Netzwerk identifizieren können
- ✅ Port-Status verstehen (Open, Closed, Filtered)
- ✅ TCP-Scan-Typen kennen (SYN, Connect, FIN, NULL, Xmas)
- ✅ UDP-Scanning, OS-Detection, Service-Version-Detection verstehen
- ✅ NSE (Nmap Scripting Engine) kennen
- ✅ Stealth-Scanning und Firewall-Evasion-Techniken verstehen
- ✅ Timing-Templates, Host-Discovery-Methoden kennen

---

## 📋 Schritt-für-Schritt

### Schritt 1: nmap installieren

**Was machen wir?**  
Wir installieren nmap, das Tool für Netzwerk-Scans.

**macOS**:

1. Öffne das Terminal

2. Prüfe, ob Homebrew installiert ist:
```bash
which brew
```

3. Falls Homebrew nicht installiert ist, installiere es:
```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

4. Installiere nmap:
```bash
brew install nmap
```

**Erwartetes Ergebnis**:  
Du siehst:
```
==> Downloading nmap
==> Installing nmap
==> Summary
🍺  /opt/homebrew/Cellar/nmap/7.97: 1,234 files, 45.6MB
```

5. Prüfe Installation:
```bash
nmap --version
```

**Erwartetes Ergebnis**:  
Du siehst die nmap-Version, z.B.:
```
Nmap version 7.97
```

---

### Schritt 2: Einfacher Netzwerkscan

**Was machen wir?**  
Wir führen einen einfachen Scan durch, um alle Geräte im Netzwerk zu finden.

**macOS Terminal**:

1. Führe einen Ping-Scan durch:
```bash
nmap -sn 192.168.178.0/24
```

**Was macht dieser Befehl?**
- `-sn`: Ping-Scan (nur prüfen, ob Geräte erreichbar sind)
- `192.168.178.0/24`: Dein gesamtes Subnetz scannen

**Erwartetes Ergebnis**:  
Du siehst eine Liste wie:
```
Starting Nmap 7.97 ( https://nmap.org ) at 2026-03-08 18:43 +0100
Nmap scan report for 192-168-178-1.fritz.box (192.168.178.1)
Host is up (0.00050s latency).
Nmap scan report for 192.168.178.28
Host is up (0.00123s latency).
Nmap scan report for Cluster-Mini-01 (192.168.178.29)
Host is up (0.00089s latency).
...
Nmap done: 1 IP address (1 host up) scanned in 2.34 seconds
```

**Das bedeutet**:
- Alle erreichbaren Geräte werden aufgelistet
- Hostname wird angezeigt (falls verfügbar)
- IP-Adresse wird angezeigt
- Latenz (Antwortzeit) wird angezeigt

---

### Schritt 3: Scan-Ergebnisse interpretieren

**Was machen wir?**  
Wir analysieren die Scan-Ergebnisse.

**Typische Ergebnisse**:

1. **Router**:
   ```
   Nmap scan report for 192-168-178-1.fritz.box (192.168.178.1)
   ```
   - Hostname: `192-168-178-1.fritz.box`
   - IP: `192.168.178.1`
   - Das ist dein Router (Gateway)

2. **Cluster Nodes**:
   ```
   Nmap scan report for Cluster-Mini-01 (192.168.178.29)
   ```
   - Hostname: `Cluster-Mini-01`
   - IP: `192.168.178.29`
   - Das ist einer deiner Render Nodes

3. **Andere Geräte**:
   ```
   Nmap scan report for iPadPro-M5.fritz.box (192.168.178.41)
   ```
   - Hostname: `iPadPro-M5.fritz.box`
   - IP: `192.168.178.41`
   - Das ist ein iPad

**Beobachtung**:  
- Geräte mit Hostnamen sind einfacher zu identifizieren
- Geräte ohne Hostname zeigen nur die IP-Adresse

---

### Schritt 4: Detaillierter Scan eines Geräts

**Was machen wir?**  
Wir führen einen detaillierten Scan eines Geräts durch, um mehr Informationen zu erhalten.

**macOS Terminal**:

1. Scanne den Router detailliert:
```bash
nmap -A 192.168.178.1
```

**Was macht dieser Befehl?**
- `-A`: Aktiviert OS-Erkennung, Versionserkennung, Script-Scanning
- `192.168.178.1`: IP-Adresse des Routers

**Erwartetes Ergebnis**:  
Du siehst detaillierte Informationen:
```
Starting Nmap 7.97 ( https://nmap.org ) at 2026-03-08 18:43 +0100
Nmap scan report for 192-168-178-1.fritz.box (192.168.178.1)
Host is up (0.00050s latency).
Not shown: 994 closed tcp ports (conn-refused)
PORT     STATE SERVICE  VERSION
21/tcp   open  ftp
53/tcp   open  domain   NLnet Labs NSD
80/tcp   open  http     FRITZ!Box http config
443/tcp  open  ssl/http FRITZ!Box http config
5060/tcp open  sip      AVM FRITZ!OS SIP
8181/tcp open  http     AVM FRITZ!Box 7300-series WAP http config
```

**Das bedeutet**:
- **Port 21**: FTP-Server (Dateiübertragung)
- **Port 53**: DNS-Server
- **Port 80**: HTTP (Web-Interface)
- **Port 443**: HTTPS (verschlüsseltes Web-Interface)
- **Port 5060**: SIP (VoIP-Telefonie)
- **Port 8181**: WAP HTTP Config

**Wichtig**: Offene Ports zeigen, welche Dienste auf dem Gerät laufen.

---

### Schritt 5: Scan-Skript verwenden

**Was machen wir?**  
Wir verwenden das bereits erstellte Scan-Skript.

**macOS Terminal**:

1. Gehe ins Projekt-Verzeichnis:
```bash
cd /Users/ssmd/Desktop/Cluster
```

2. Führe das Scan-Skript aus:
```bash
./scripts/01_netzwerk_analyse.sh
```

**Erwartetes Ergebnis**:  
Du siehst eine strukturierte Ausgabe mit:
- Netzwerk-Interface
- IP-Konfiguration
- Gateway
- Subnetz
- DNS-Server
- Netzwerkscan-Ergebnisse

**Vorteil**: Das Skript macht alles automatisch und strukturiert!

---

### Schritt 6: Geräte identifizieren

**Was machen wir?**  
Wir identifizieren die gefundenen Geräte.

**Aus deinem Scan** (Beispiel):

| IP-Adresse | Hostname | Typ | Status |
|------------|----------|-----|--------|
| 192.168.178.1 | 192-168-178-1.fritz.box | Router | ✅ |
| 192.168.178.28 | - | Unbekannt | ✅ |
| 192.168.178.29 | Cluster-Mini-01 | Mac Mini | ✅ |
| 192.168.178.30 | Cluster-Mini-02 | Mac Mini | ✅ |
| 192.168.178.31 | Cluster-Mini-03 | Mac Mini | ✅ |
| 192.168.178.32 | Cluster-Mini-04 | Mac Mini | ✅ |
| 192.168.178.40 | EAP653-... | Access Point | ✅ |
| 192.168.178.41 | iPadPro-M5 | iPad | ✅ |
| ... | ... | ... | ... |

**Aufgabe**: Identifiziere unbekannte Geräte!

---

## 💻 Befehle

### Einfacher Netzwerkscan

```bash
# Ping-Scan (nur erreichbare Geräte finden)
nmap -sn 192.168.178.0/24

# Schneller Scan (nur häufigste Ports)
nmap -F 192.168.178.0/24
```

### Detaillierter Scan

```bash
# Vollständiger Scan mit OS-Erkennung
nmap -A 192.168.178.1

# Nur bestimmte Ports scannen
nmap -p 80,443,22 192.168.178.1
```

### Scan-Optionen

```bash
# Schneller Scan (weniger genau)
nmap -T4 192.168.178.0/24

# Verbose Ausgabe (mehr Details)
nmap -v 192.168.178.0/24

# Scan-Ergebnisse in Datei speichern
nmap -sn 192.168.178.0/24 -oN scan_ergebnisse.txt
```

---

## ✅ Erwartetes Ergebnis

Nach diesem Modul solltest du:

1. ✅ nmap installiert haben
2. ✅ Einen Netzwerkscan durchführen können
3. ✅ Scan-Ergebnisse interpretieren können
4. ✅ Geräte im Netzwerk identifizieren können
5. ✅ Detaillierte Scans durchführen können

---

## ⚠️ Mögliche Fehlerquellen

### Problem: nmap nicht gefunden

**Lösung**:
- Prüfe Installation: `which nmap`
- Falls nicht installiert: `brew install nmap`
- Prüfe PATH: `echo $PATH`

### Problem: Scan dauert sehr lange

**Lösung**:
- Das ist normal! Ein vollständiger Scan kann mehrere Minuten dauern
- Verwende `-T4` für schnelleren Scan
- Verwende `-F` für schnellen Scan (nur häufige Ports)

### Problem: Keine Geräte gefunden

**Lösung**:
- Prüfe Netzwerkverbindung
- Prüfe Subnetz (sollte 192.168.178.0/24 sein)
- Prüfe Firewall-Einstellungen
- Versuche einzelnes Gerät: `ping 192.168.178.1`

### Problem: Zu viele Ergebnisse

**Lösung**:
- Speichere Ergebnisse in Datei: `-oN ergebnisse.txt`
- Filtere Ergebnisse: `grep "Cluster-Mini" ergebnisse.txt`
- Verwende spezifischeren Scan

---

## 📝 Zusammenfassung

**Was hast du gelernt?**

1. **Netzwerkscan**: Findet alle Geräte im Netzwerk
2. **nmap**: Professionelles Netzwerk-Scanning-Tool
3. **Ping-Scan**: Findet erreichbare Geräte
4. **Detaillierter Scan**: Zeigt Ports und Dienste
5. **Geräte-Identifikation**: Hostnamen helfen bei der Identifikation

**Wichtige Begriffe**:
- **Netzwerkscan**: Suche nach Geräten im Netzwerk
- **nmap**: Network Mapper - Tool für Netzwerk-Scans
- **Ping-Scan (-sn)**: Einfacher Scan, prüft nur Erreichbarkeit
- **Port**: Endpunkt für Netzwerk-Verbindungen (0-65535)
- **Well-Known Ports**: Ports 0-1023 (System-Ports)
- **Registered Ports**: Ports 1024-49151
- **Dynamic/Private Ports**: Ports 49152-65535
- **Port-Status**: Open, Closed, Filtered, Open|Filtered, Closed|Filtered
- **TCP-Scan**: Scan mit TCP-Verbindungen
- **SYN-Scan (-sS)**: Stealth-Scan mit SYN-Paketen
- **Connect-Scan (-sT)**: Vollständige TCP-Verbindung
- **FIN-Scan (-sF)**: Scan mit FIN-Paketen
- **NULL-Scan (-sN)**: Scan ohne Flags
- **Xmas-Scan (-sX)**: Scan mit FIN, PSH, URG Flags
- **UDP-Scan (-sU)**: Scan von UDP-Ports
- **OS-Detection (-O)**: Betriebssystem-Erkennung
- **Service-Version-Detection (-sV)**: Service-Version-Erkennung
- **Script-Scanning (-sC)**: Verwendung von NSE-Scripts
- **NSE**: Nmap Scripting Engine - Skriptsprache für nmap
- **Stealth-Scanning**: Unauffällige Scan-Techniken
- **Firewall-Evasion**: Umgehen von Firewalls
- **Fragmentierung (-f)**: Aufteilen von Paketen
- **Decoy-Scans (-D)**: Verstecken der eigenen IP
- **Idle-Scan (-sI)**: Verwendung eines Zombie-Hosts
- **Source-Port-Spoofing**: Vortäuschen eines Source-Ports
- **Timing-Templates (-T0 bis -T5)**: Geschwindigkeitsstufen
- **Host-Discovery**: Methoden zum Finden aktiver Hosts
- **ARP-Scan**: Verwendung von ARP für lokale Netzwerke
- **ICMP-Echo**: Standard-Ping
- **TCP-SYN-Ping (-PS)**: Ping mit SYN-Paketen
- **TCP-ACK-Ping (-PA)**: Ping mit ACK-Paketen
- **UDP-Ping (-PU)**: Ping mit UDP-Paketen
- **Port-Range**: Spezifische Ports scannen (-p)
- **Output-Formate**: Normal (-oN), XML (-oX), Grepable (-oG)
- **Banner-Grabbing**: Abrufen von Service-Bannern
- **Fingerprinting**: Identifikation durch Analyse
- **Network-Topology-Discovery**: Erkennung der Netzwerk-Topologie
- **Vulnerability-Scanning**: Schwachstellen-Scanning
- **Compliance-Scanning**: Prüfung auf Richtlinien-Einhaltung
- **Network-Mapping**: Erstellung einer Netzwerk-Karte
- **Traffic-Analysis**: Analyse von Traffic-Mustern
- **Packet-Crafting**: Erstellen von benutzerdefinierten Paketen
- **Traceroute**: Verfolgung des Paket-Wegs
- **IPv6-Scanning**: Scans für IPv6 (-6)
- **Proxied-Scanning**: Scans über Proxy
- **Parallel-Scanning**: Mehrere Scans gleichzeitig

**Deine Scan-Ergebnisse**:
- **Router**: 192.168.178.1 (FRITZ!Box)
- **Cluster Nodes**: .29-.32 (Mac Minis)
- **Access Points**: .40, .61, .62 (EAP653)
- **Weitere Geräte**: Viele Client-Geräte

---

## 🔗 Verweise

**Handbuch-Kapitel**:
- Kapitel 3: Netzwerk Topologie
- Kapitel 4: Hardware Inventar

**Skripte**:
- `scripts/01_netzwerk_analyse.sh`

**Nächstes Modul**:  
➡️ [Modul 07: CGNAT verstehen](../TUTORIAL.md#modul-07-cgnat-verstehen)

---

## 🎓 Selbstprüfung

Beantworte diese Fragen für dich selbst:

- [ ] Kann ich nmap installieren?
- [ ] Kann ich einen Netzwerkscan durchführen?
- [ ] Kann ich Scan-Ergebnisse interpretieren?
- [ ] Kann ich Geräte im Netzwerk identifizieren?
- [ ] Kann ich einen detaillierten Scan durchführen?

**Wenn du alle Fragen mit "Ja" beantworten kannst, bist du bereit für Modul 07!** 🎉

---

**Ende Modul 06**
