# Proxmox 02 — Claude-Workflow

> Was Claude für dich automatisiert machen kann.

---

## VM-Konfiguration generieren

Claude kann dir die optimale Konfiguration für eine neue VM vorschlagen:

```
"Claude, ich brauche eine VM für einen Windows-Fileserver
mit ca. 500 GB Speicher. Was empfiehlst du?"

→ Claude berechnet: CPU, RAM, Disk, Storage-Pool,
  und gibt dir die Werte für den Erstellungs-Assistenten.
```

## Proxmox-Befehle vorbereiten

Wenn du lieber per Terminal arbeitest, erstellt Claude die Befehle:

```
"Claude, erstelle mir den Befehl für eine neue Ubuntu-VM
mit 4 Kernen und 8 GB RAM."

→ qm create 105 --name ubuntu-test --cores 4 --memory 8192 \
  --net0 virtio,bridge=vmbr0 --scsihw virtio-scsi-single \
  --scsi0 SSDPool1:32 --cdrom local:iso/ubuntu-24.04.iso \
  --boot order=scsi0;ide2 --ostype l26
```

## Checkliste für neue VMs

Claude kann eine Checkliste generieren und abhaken:

```
"Claude, ich richte einen neuen Domain Controller ein.
Erstell mir eine Checkliste."

→ Claude erstellt eine vollständige Schritt-für-Schritt-Anleitung
  mit Prüfpunkten für Netzwerk, DNS, DHCP, Firewall-Regeln.
```

## Einschränkungen

- Kein direkter SSH/API-Zugriff auf den Proxmox-Host aus Cowork
- Befehle werden vorbereitet, Ausführung erfolgt manuell
- Für Live-Zugriff: Cursor + Claude Code mit SSH-Tunnel nutzen
