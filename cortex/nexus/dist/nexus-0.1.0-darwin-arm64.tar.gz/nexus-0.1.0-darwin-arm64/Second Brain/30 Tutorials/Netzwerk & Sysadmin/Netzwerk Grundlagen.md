---
type: tutorial
aliases: [Netzwerk, Sysadmin, IP, DNS, Router, Homelab]
tags:
  - tutorial
  - netzwerk
  - sysadmin
source: Second Brain/30 Tutorials/Netzwerk & Sysadmin/
legacy_path: _tutorials/netzwerk-sysadmin/ (Symlink)
---

# Netzwerk & Sysadmin — Tutorial-Übersicht

> Quellpfad: `Second Brain/30 Tutorials/Netzwerk & Sysadmin/` (Single Source of Truth)
> Legacy-Pfad: `_tutorials/netzwerk-sysadmin/` → Symlink

Netzwerke sind überall — zwischen deinem Mac, dem Drucker, deinem Homelab, iPhone und der Cloud. Diese Tutorials erklären, wie Daten von A nach B kommen.

---

## Warum dieses Wissen?

- Dein Homelab (Proxmox, VMs) sind übers Netzwerk verbunden
- Juvantis braucht Internet für HealthKit-Sync und Cloud-Daten
- Gelegentliche Netzwerk-Fehler kannst du selbst diagnostizieren
- Du kannst deine Infrastruktur selbst warten und optimieren

---

## Module

### 00 — Schichtenmodell und Webhosting
**Wie liegen die OSI-Schichten und das Webhosting-Stack-Modell zusammen?**

- ISO/OSI-Schichten als Brücke zwischen Hardware und Anwendung
- Stack-Mapping: Apache, PHP, MySQL, Domain → Schicht
- Praktische Beispiele aus deinem Hosting-Setup (domainfactory)

**Dateien:**
- Theorie: `00-schichtenmodell-und-webhosting.md`

---

### 01 — Grundlagen (Kurzübersicht)
**Schneller Einstieg in Netzwerk-Konzepte.**

- IP-Adressen (wie Postleitzahlen für Computer)
- DNS (wie ein Adressbuch für Websites)
- Ports (wie Fenster auf einem Haus)
- SSH (sichere Verbindung zu anderen Computern)
- Netzwerk-Diagnostik Basics

**Dateien:**
- Theorie: `01-grundlagen.md`

---

### 02 — Was ist ein Netzwerk?
**Verstehen, wie Geräte miteinander kommunizieren.**

Lerninhalte:
- **Lokales Netzwerk (LAN):** Deine Geräte zu Hause (schnell, sicher)
- **Internet (WAN):** Weltweites Netzwerk (öffentlich)
- **Grundkomponenten:** Geräte, Verbindungen, Router, Switch
- **Netzwerk-Terminologie:** Node, LAN, WAN, Broadcast, Unicast

Deine Cluster-Mini-01 bis Cluster-Mini-04 sind jeweils Nodes im Netzwerk.

**Dateien:**
- Theorie: `02-was-ist-ein-netzwerk.md`

---

### 03 — IP-Adressen
**Die "Postleitzahl" deines Computers.**

- **IPv4:** `XXX.XXX.XXX.XXX` (4 Zahlen à 0-255)
  - Lokal: `192.168.x.x`, `10.0.0.x`, `172.16-31.x.x`
  - Öffentlich: Alles andere
  - Localhost: `127.0.0.1` (dein Computer selbst)
- **IPv6:** Moderne Alternative (Hexadezimal)
- **Subnetzmaske:** Bestimmt, welche Adressen im gleichen Netz sind
- **Default Gateway:** Router für Zugriff außerhalb des Netzes

**Dateien:**
- Theorie: `03-ip-adressen.md`

---

### 04 — Router, Switch, Gateway
**Hardware, die dein Netzwerk verbindet.**

- **Router:** Verbindet lokales Netzwerk mit Internet
- **Switch:** Verbindet mehrere Geräte im LAN
- **Gateway:** Zugang zu anderen Netzwerken
- **VLAN:** Virtuelle Unterteilung eines Netzes
- **Praxis:** Wie ist dein Homelab verdrahtet?

**Dateien:**
- Theorie: `04-router-switch-gateway.md`

---

### 05 — DHCP
**Automatische IP-Adressenvergabe.**

- Wie bekommen Geräte ihre IP-Adressen?
- **DHCP-Server:** Verteilt Adressen aus einem Pool
- **Lease-Zeit:** Wie lange eine Adresse gültig ist
- **Statische IPs:** Feste Adressen für Server
- **Troubleshooting:** Wenn DHCP nicht funktioniert

**Dateien:**
- Theorie: `05-dhcp.md`

---

### 06 — DNS
**Das Adressbuch des Internets.**

DNS übersetzt Namen in IP-Adressen:
- `sanexio.eu` → `1.2.3.4` (irgendeine IP)

Inhalte:
- **DNS-Server:** Google (8.8.8.8), Cloudflare (1.1.1.1), dein lokaler
- **DNS-Record-Typen:** A, AAAA, CNAME, MX, TXT
- **Nameserver:** Wer speichert deine Domain-Infos?
- **Propagation:** Warum Änderungen Zeit brauchen
- **Troubleshooting:** `nslookup`, `dig`

**Dateien:**
- Theorie: `06-dns.md`

---

### 07 — Netzwerk-Scan & Diagnostik
**Herausfinden, welche Geräte im Netzwerk sind.**

Tools und Techniken:
- **`nmap`:** Port-Scanning, Geräte-Erkennung
- **`ping`:** Erreichbarkeit prüfen
- **`arp`:** MAC-Adressen auflösen
- **`tcpdump`:** Netzwerk-Traffic analysieren
- **`netstat`, `lsof`:** Offene Ports und Verbindungen

Praktische Szenarien:
- Homelab-Inventur (welche IPs, welche Geräte?)
- Fehlersuche (warum antwortet der Server nicht?)
- Sicherheit (welche Ports sind offen?)

**Dateien:**
- Theorie: `07-netzwerkscan.md`

---

### 08 — CGNAT
**Carrier-Grade NAT — wenn dein ISP dich versteckt.**

- **NAT:** Network Address Translation (dein Router)
- **CGNAT:** Mehrere Nutzer teilen sich eine öffentliche IP
- **Problem:** Du kannst von außen nicht auf dein Homelab zugreifen
- **Lösungen:** Port-Forwarding, VPN, andere ISP, Dynamic DNS
- **Erkennung:** Wie prüfst du, ob CGNAT aktiv ist?

**Dateien:**
- Theorie: `08-cgnat.md`

---

### 09 — Cortex-Mesh mit Tailscale
**Drei Macs in einem privaten Mesh-Netzwerk via WireGuard.**

- Setup-Cookbook für Cluster-Mini-02, Praxis-Studio, MacBook-Pro
- Tailscale-Installation, Apple-ID-Login, MagicDNS-Aktivierung
- SSH-Aliases (`ssh home`, `ssh praxis`, `ssh studio`)
- Live-Verifikation der Verbindungen

**Datei:** `09-cortex-mesh-tailscale.md`

---

### 10 — Remote-Zugriff auf lokale Entwicklungs-Site
**Vom Praxis-Mac auf die WordPress-Dev-Site auf dem Home-Mac.**

- Drei Wege: `/etc/hosts` direkt, SSH-Tunnel, Tailscale Serve
- Local-by-Flywheel-Stacks (`localhost:10003`) tailnet-weit erreichbar machen
- Praktische Umsetzung mit Tailscale-IP

**Datei:** `10-remote-zugriff-local-dev.md`

---

### 11 — VPN-Grundlagen + dein Cortex-Setting
**Theorie zu VPN und Live-Snapshot deines Tailnets.**

- Was ein VPN technisch ist, welche Bauformen, welche Protokolle (WireGuard, OpenVPN, IPsec)
- Tailscale als Mesh-Implementierung — Coordination-Server, DERP-Relays, MagicDNS, ACLs
- Live-Snapshot deines Tailnets `7vwcqsnty6@privaterelay.appleid.com` mit allen Geräten + Services
- Befehls-Cheatsheet, Sicherheits-Risiken (Apple-ID-Lock-in), Troubleshooting (M5/Intel-IP-Konflikt)

**Datei:** `11-vpn-grundlagen-und-cortex-setting.md`

---

## Bonus: Homelab-Handbuch

**Datei:** `homelab-handbuch.md`

Deine komplette Infrastruktur-Dokumentation:
- Cluster-Mini-01 bis 04 Konfiguration
- Netzwerk-Topologie
- VLANs und Firewall-Regeln
- Backup- und Monitoring-Setup
- Checklisten für Troubleshooting

---

## Lern-Reihenfolge

1. **01 — Grundlagen** (Basis, 5 Min Überblick)
2. **02 — Was ist ein Netzwerk?** (Konzepte)
3. **03 — IP-Adressen** (Addressing-Schema)
4. **04 — Router, Switch, Gateway** (Hardware)
5. **05 — DHCP** (Automatische Vergabe)
6. **06 — DNS** (Namen → IPs)
7. **07 — Netzwerk-Scan** (Diagnostik-Tools)
8. **08 — CGNAT** (Spezialfall: ISP-Limit)
9. **11 — VPN-Grundlagen + Cortex-Setting** (Theorie + dein Tailnet)
10. **09 — Cortex-Mesh mit Tailscale** (Setup-Cookbook)
11. **10 — Remote-Zugriff auf lokale Entwicklungs-Site** (Anwendung)
12. **Homelab-Handbuch** (Deine Praxis)

(Die alte 1-bis-9-Lern-Reihenfolge bleibt darunter erhalten — duplicate
ignorieren; sie wird beim nächsten Doc-Refresh konsolidiert.)
7. **07 — Netzwerk-Scan** (Diagnostik-Tools)
8. **08 — CGNAT** (Spezialfall: ISP-Limit)
9. **Homelab-Handbuch** (Deine Praxis)


<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

- [[30 Tutorials/Netzwerk & Sysadmin/00-schichtenmodell-und-webhosting|00-schichtenmodell-und-webhosting]]
- [[30 Tutorials/Netzwerk & Sysadmin/01-grundlagen|01-grundlagen]]
- [[30 Tutorials/Netzwerk & Sysadmin/02-was-ist-ein-netzwerk|02-was-ist-ein-netzwerk]] · [[30 Tutorials/Netzwerk & Sysadmin/02-was-ist-ein-netzwerk_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/02-was-ist-ein-netzwerk_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/03-ip-adressen|03-ip-adressen]]
- [[30 Tutorials/Netzwerk & Sysadmin/04-router-switch-gateway|04-router-switch-gateway]] · [[30 Tutorials/Netzwerk & Sysadmin/04-router-switch-gateway_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/04-router-switch-gateway_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/05-dhcp|05-dhcp]]
- [[30 Tutorials/Netzwerk & Sysadmin/06-dns|06-dns]] · [[30 Tutorials/Netzwerk & Sysadmin/06-dns_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/06-dns_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/07-netzwerkscan|07-netzwerkscan]] · [[30 Tutorials/Netzwerk & Sysadmin/07-netzwerkscan_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/07-netzwerkscan_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/08-cgnat|08-cgnat]] · [[30 Tutorials/Netzwerk & Sysadmin/08-cgnat_claude|Claude]] · [[30 Tutorials/Netzwerk & Sysadmin/08-cgnat_manuell|Manuell]]
- [[30 Tutorials/Netzwerk & Sysadmin/09-cortex-mesh-tailscale|09-cortex-mesh-tailscale]]
- [[30 Tutorials/Netzwerk & Sysadmin/10-remote-zugriff-local-dev|10-remote-zugriff-local-dev]]
- [[30 Tutorials/Netzwerk & Sysadmin/homelab-handbuch|homelab-handbuch]]

<!-- /auto-moc-links -->