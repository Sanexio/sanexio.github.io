# Was ist ein Netzwerk — Claude-Workflow

**Einsatzbereich:** Automation von Geräte-Erkennung, Switch-Management, Omada-Integration

**Wann ist dieser Workflow sinnvoll?**
- Du möchtest die verfügbaren Geräte im Netzwerk automatisch erfassen
- Du brauchst ein Python-Skript, das Geräte-Informationen strukturiert sammelt
- Du möchtest den Omada Controller für Switch-Management via API nutzen
- Du brauchst eine Geräte-Datenbank (JSON/CSV) mit allen Netzwerk-Komponenten
- Du möchtest Geräte-Änderungen (neue Nodes, neue APs) automatisch tracken

---

## Szenario

Dr. Stracke möchte regelmäßig überprüfen, welche Geräte im Netzwerk online sind, und eine aktuelle Inventarliste führen. Statt manuell die FRITZ!Box zu prüfen und nmap zu starten, sollen alle Informationen automatisch gesammelt werden.

---

## Workflow-Schritte

### 1. Geräte-Inventar erstellen (Python-Skript)

Claude erstellt ein Python-Skript, das:
- Die FRITZ!Box ausliest (API, falls verfügbar, oder Web-Scraping)
- Netzwerkscans durchführt (nmap)
- Geräte-Informationen in JSON speichert
- Vergleiche mit vorherigen Scans durchführt (neue/fehlende Geräte)

**Aufruf:**
```bash
python3 scripts/device_inventory.py --output devices.json --format json
```

**Ergebnis:**
```json
{
  "scan_date": "2026-04-03T10:30:00Z",
  "devices": [
    {
      "ip": "192.168.178.1",
      "hostname": "fritz.box",
      "type": "Router",
      "mac": "AA:BB:CC:DD:EE:FF",
      "status": "online"
    },
    {
      "ip": "192.168.178.29",
      "hostname": "Cluster-Mini-01",
      "type": "Mac Mini",
      "mac": "11:22:33:44:55:66",
      "status": "online"
    }
  ]
}
```

### 2. Omada Controller API nutzen (Python-Skript)

Claude erstellt ein Skript für:
- Authentifizierung am Omada Controller
- Abrufen von Switch-Status
- Abrufen von Access-Point-Status
- Konfiguration von VLANs (später)

**Aufruf:**
```bash
python3 scripts/omada_api.py --controller https://euw1-omada-cloud.tplinkcloud.com --list-devices
```

### 3. Reports generieren (Claude)

Claude erstellt automatisch:
- Tägliche Geräte-Status-Reports
- Vergleiche mit vorherigen Tagen (neue Geräte, offline Geräte)
- HTML-Reports für Dr. Stracke
- CSV-Export für Tabellenkalkulation

**Beispiel-Report:**
```
Netzwerk-Status 2026-04-03 10:30 UTC
=====================================

Geräte online: 28/30
Offline-Geräte: 2

Neue Geräte (heute): 0
Offline seit: 1 Tag (1 Gerät)

Router: FRITZ!Box (192.168.178.1) - ✅ Online
Switch: TP-Link ES216G (192.168.178.96) - ✅ Online
Controller: OC200 (192.168.178.68) - ✅ Online

Cluster Nodes: Alle 4 online ✅
Access Points: 3/3 online ✅
...
```

### 4. Automatische Benachrichtigungen

Claude konfiguriert:
- Alerts wenn Cluster-Nodes offline gehen
- Alerts wenn neue Geräte sich verbinden
- Wöchentliche Inventory-Reports

---

## Wann nutzt man diesen Workflow?

✅ **Nutze Claude-Automation:**
- Regelmäßige Netzwerk-Scans (täglich, wöchentlich)
- Geräte-Tracking und Änderungserkennung
- Reports und Analysen
- Omada Controller-Integration
- Automatische Benachrichtigungen

❌ **Nutze stattdessen manuelle Web-UI (Modul 02-was-ist-ein-netzwerk_manuell.md):**
- Erste Orientierung im Omada Controller
- Switch manuell zu Controller hinzufügen
- Web-basierte Konfiguration
- Einmalige Setup-Aufgaben

---

## Typisches Workflow-Beispiel

**Szenario:** Dr. Stracke möchte wissen, ob alle 4 Cluster Nodes online sind.

**Mit Claude-Automation:**
1. Claude führt Python-Skript aus → `device_inventory.py`
2. Skript scannt Netzwerk, speichert JSON
3. Claude parst JSON und zeigt Status:
   - Cluster-Mini-01: 192.168.178.29 ✅ (M1, 16GB)
   - Cluster-Mini-02: 192.168.178.30 ✅ (M2, 8GB)
   - Cluster-Mini-03: 192.168.178.31 ✅ (M2, 8GB)
   - Cluster-Mini-04: 192.168.178.32 ✅ (M2, 8GB)

**Vorteile:**
- Schnell, automatisiert
- Strukturierte Daten für weitere Verarbeitung
- Historische Daten für Trends
- Integration mit anderen Systemen

---

## Wichtige Befehle für Automation

```bash
# Schneller Netzwerkscan (nmap)
nmap -sn 192.168.178.0/24 -oX scan.xml

# ARP-Tabelle auslesen
arp -a

# FRITZ!Box TR-064 API (falls aktiviert)
curl http://fritz.box:49000/upnp/control/upnpcommon1

# SSH auf Cluster Node
ssh admin@192.168.178.29
```

---

## Beste Praktiken

1. **Regelmäßige Scans:** Täglich um 10:00 UTC
2. **Daten speichern:** JSON für Maschinenlesbarkeit, CSV für manuelle Analyse
3. **Vergleiche:** Heute vs. Gestern vs. Woche-vorher
4. **Alerts:** Nur bei kritischen Änderungen (Nodes offline)
5. **Reports:** Wöchentlich für Dr. Stracke

---

**Nächster Schritt:** Siehe Modul 02-was-ist-ein-netzwerk_manuell.md für Web-UI-basierte Schritte (erste Einrichtung).
