# Netzwerkscan — Claude-Workflow

**Einsatzbereich:** Automatische Geräte-Erkennung, Netzwerk-Mapping, Port-Monitoring

**Wann ist dieser Workflow sinnvoll?**
- Du möchtest täglich automatisch alle Geräte im Netzwerk überprüfen
- Du brauchst eine Geräte-Inventur mit Status und Hardware-Info
- Du möchtest neue Geräte automatisch erkennen
- Du möchtest Offline-Geräte-Alerts bekommen
- Du brauchst ein Netzwerk-Monitoring-System

---

## Szenario

Dr. Stracke möchte wissen, ob alle Cluster Nodes online sind, und er möchte benachrichtigt werden, wenn eines ausfällt. Statt manuell nmap zu starten, soll das automatisch passieren.

---

## Workflow-Schritte

### 1. Automatisches Netzwerk-Scan-Skript

Claude erstellt ein Python-Skript mit nmap-Integration, das:
- Täglich einen Scan durchführt
- Alle Geräte identifiziert
- Ergebnisse in JSON/CSV speichert
- Mit vorherigen Scans vergleicht

**Aufruf:**
```bash
python3 scripts/netzwerk_scan.py --subnet 192.168.178.0/24 --json devices.json
```

**Ergebnis (devices.json):**
```json
{
  "scan_date": "2026-04-03T10:30:00Z",
  "devices": [
    {
      "ip": "192.168.178.29",
      "hostname": "Cluster-Mini-01",
      "status": "online",
      "mac": "AA:BB:CC:DD:EE:FF",
      "type": "Mac Mini M1",
      "latency_ms": 0.89
    },
    {
      "ip": "192.168.178.30",
      "hostname": "Cluster-Mini-02",
      "status": "online",
      "mac": "11:22:33:44:55:66",
      "type": "Mac Mini M2",
      "latency_ms": 0.91
    }
  ],
  "summary": {
    "total_devices": 28,
    "online": 28,
    "offline": 0,
    "new_devices": 0
  }
}
```

### 2. Port-Scan für kritische Geräte

Claude erstellt ein Skript, das:
- SSH-Port (22) auf Cluster Nodes prüft
- Web-Ports (80, 443) auf Router/Switch prüft
- Sicherheitslücken erkennt

**Aufruf:**
```bash
python3 scripts/port_scan.py --targets Cluster-Mini-01 Cluster-Mini-02 --ports 22,80,443
```

**Ergebnis:**
```
Port-Scan Results (Cluster-Mini-01)
===================================
IP: 192.168.178.29
Port 22 (SSH): OPEN ✅
Port 80 (HTTP): CLOSED
Port 443 (HTTPS): CLOSED

Status: Erreichbar für SSH ✅
```

### 3. Geräte-Änderungen erkennen

Claude erstellt Vergleich mit gestrigem Scan:

```
Netzwerk-Vergleich: Heute vs. Gestern
=====================================

NEUE GERÄTE (Heute): 0
OFFLINE GERÄTE (War online, jetzt offline): 0
WIEDER ONLINE (War offline, jetzt online): 0

Status: Stabil ✅
```

### 4. Automatische Alerts

Claude konfiguriert:
- Alert wenn Cluster-Node offline geht
- Alert wenn neues unbekanntes Gerät sich verbindet
- Täglicher Status-Report

**Beispiel-Alert:**
```
⚠️ ALERT: Cluster-Mini-03 offline!
IP: 192.168.178.31
Status: OFFLINE (war online gestern 10:30)
Ursachen:
- Stromleitungstrennung
- Netzwerkverbindung getrennt
- Gerät neustarten/crashen

Empfehlung: Gerät prüfen/neu starten
```

### 5. Netzwerk-Visualisierung

Claude erstellt automatisch:
- ASCII-Diagramm des Netzwerks
- Graphische Geräte-Status-Übersicht
- HTML-Reports

**Beispiel-Diagram:**
```
Netzwerk-Topologie (2026-04-03)
===============================

       [Internet]
           |
      [FRITZ!Box]
      192.168.178.1
           |
      [ES216G Switch]
      192.168.178.96
           |
    +------+------+------+
    |      |      |      |
  [CM1]  [CM2]  [CM3]  [CM4]
   .29    .30    .31    .32
   ✅     ✅     ✅     ✅
```

---

## Wichtige Befehle für Automation

```bash
# Schneller Netzwerkscan (nur Host-Discovery)
nmap -sn 192.168.178.0/24

# Detaillierter Scan (mit Ports)
nmap -sV 192.168.178.29

# Scan-Output in XML (für Parsing)
nmap -sn 192.168.178.0/24 -oX scan.xml

# Nur bestimmte IPs scannen
nmap -sn 192.168.178.29-32

# Sehr schnell (aber weniger genau)
nmap -T5 -sn 192.168.178.0/24
```

---

## Wann nutzt man diesen Workflow?

✅ **Nutze Claude-Automation:**
- Täglich automatische Scans
- Historische Daten sammeln
- Trends erkennen
- Automatische Reports
- Alerts bei Problemen

❌ **Nutze stattdessen manuelle nmap Commands (Modul 07-netzwerkscan_manuell.md):**
- Einmalige Scans
- Ad-hoc Diagnose
- Spezifische Port-Analysen
- Troubleshooting

---

## Typisches Workflow-Beispiel

**Szenario:** Täglich um 10:00 UTC

**Mit Claude-Automation:**
1. Python-Skript startet automatisch
2. nmap scannt Netzwerk: 192.168.178.0/24
3. Ergebnisse in JSON speichern
4. Mit gestrigem Scan vergleichen
5. Report erstellen:
   - ✅ Alle Cluster Nodes online
   - ✅ Alle Access Points online
   - ✅ Keine neuen unbekannten Geräte
   - ✅ Keine Geräte offline

6. Wenn Problem: Alert-Email senden
7. Archivieren für historische Daten

---

## Beste Praktiken

1. **Täglich scannen:** Immer um 10:00 UTC
2. **Speichern:** Alle Scans archivieren (30 Tage)
3. **Vergleichen:** Mit Tag davor
4. **Alerts:** Nur wichtige Ereignisse
5. **Reports:** Wöchentlich zusammenfassen

---

**Nächster Schritt:** Siehe Modul 07-netzwerkscan_manuell.md für manuelle nmap-Befehle und Analyse.
