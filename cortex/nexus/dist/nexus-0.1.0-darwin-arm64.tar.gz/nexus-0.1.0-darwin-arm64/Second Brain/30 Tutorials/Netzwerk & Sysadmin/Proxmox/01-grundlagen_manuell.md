# Proxmox 01 — Manueller Workflow

> Was du selbst im Browser oder Terminal machst.

---

## Web-Interface öffnen

1. Öffne einen Browser (Chrome, Firefox, Safari)
2. Navigiere zu `https://<SERVER-IP>:8006`
3. Login mit deinen Zugangsdaten
4. Du siehst das Proxmox-Dashboard

**Tipp:** Falls der Browser eine Sicherheitswarnung zeigt (wegen selbst-signiertem
Zertifikat), klicke auf "Erweitert" → "Trotzdem fortfahren". Das ist normal bei
lokalen Servern.

## Erste Orientierung im Web-Interface

Das Interface ist in drei Bereiche aufgeteilt:

```
┌──────────────┬────────────────────────────────────┐
│              │                                    │
│  Baum        │  Hauptbereich                      │
│  (links)     │  (zeigt Details zum ausgewählten   │
│              │   Element)                         │
│  - Datacenter│                                    │
│    - Node    │  Tabs: Summary, Notes, Shell,      │
│      - VM 1  │  Network, Disks, ...               │
│      - VM 2  │                                    │
│      - CT 1  │                                    │
│              │                                    │
├──────────────┴────────────────────────────────────┤
│  Log-Bereich (unten) — zeigt Tasks und Logs       │
└───────────────────────────────────────────────────┘
```

## Wichtige Buttons

| Button | Wo | Was es tut |
|--------|-----|-----------|
| **Create VM** | Oben rechts | Neue virtuelle Maschine erstellen |
| **Create CT** | Oben rechts | Neuen Container erstellen |
| **Start** | VM/CT auswählen → oben | VM/Container starten |
| **Shutdown** | VM/CT auswählen → oben | Sauber herunterfahren |
| **Console** | VM/CT auswählen → oben | Bildschirm der VM öffnen (wie Monitor) |
| **Backup** | VM/CT → Backup-Tab | Backup erstellen |

## SSH-Zugang zum Proxmox-Host

Wenn du direkt auf die Kommandozeile des Proxmox-Hosts zugreifen willst:

```bash
# Vom Mac-Terminal aus:
ssh root@<SERVER-IP>

# Beispiel:
ssh root@192.168.10.31
```

Nach dem Login bist du auf dem Proxmox-Host und kannst Befehle ausführen.

## Wichtigste Proxmox-Befehle (Terminal)

```bash
# Alle VMs und Container auflisten
qm list              # VMs
pct list              # Container

# VM starten / stoppen
qm start 100         # VM mit ID 100 starten
qm shutdown 100      # VM sauber herunterfahren
qm stop 100          # VM sofort stoppen (Notfall!)

# Container starten / stoppen
pct start 200        # Container 200 starten
pct shutdown 200     # Container herunterfahren

# Ressourcen anzeigen
pvesh get /nodes     # Node-Informationen
df -h                # Festplatten-Belegung
htop                 # CPU/RAM live anzeigen (Ctrl+C zum Beenden)
```

## Übung: Erste Erkundung

1. Öffne das Web-Interface im Browser
2. Klicke auf den Node-Namen (links im Baum)
3. Schau dir den "Summary"-Tab an — du siehst CPU, RAM, Storage auf einen Blick
4. Klicke auf eine laufende VM → "Console" → Du siehst den Bildschirm der VM
5. Schließe die Console wieder (einfach Tab schließen)

---

## Nächste Schritte

→ **02-vms-und-container.md** — Selbst VMs und Container erstellen
