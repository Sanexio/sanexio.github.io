# Netzwerkscan — Manueller Workflow

**Einsatzbereich:** Ad-hoc Netzwerk-Diagnose, manuelle nmap-Befehle, Troubleshooting

**Wann ist dieser Workflow sinnvoll?**
- Du möchtest schnell wissen, welche Geräte online sind
- Du möchtest einen spezifischen Scan durchführen
- Du brauchst detaillierte Port-Informationen zu einem Gerät
- Du troubleshootest Netzwerk-Probleme
- Du analysiert Services auf einem Gerät

---

## Szenario

Dr. Stracke möchte überprüfen, welche Cluster Nodes online sind, und ob die Netzwerk-Verbindungen funktionieren.

---

## Workflow-Schritte

### Schritt 1: Einfacher Ping-Scan

**Schnelle Überprüfung: Wer ist online?**

```bash
nmap -sn 192.168.178.0/24
```

**Ergebnis:**
```
Starting Nmap 7.97 ( https://nmap.org )
Nmap scan report for 192-168-178-1.fritz.box (192.168.178.1)
Host is up (0.00050s latency).
Nmap scan report for Cluster-Mini-01 (192.168.178.29)
Host is up (0.00089s latency).
...
Nmap done: 256 IP addresses (28 hosts up) scanned in 8.23 seconds
```

**Das bedeutet:**
- `-sn` = Nur Ping, keine Port-Scans (schnell)
- 28 Geräte sind online
- Alle Cluster Nodes antworten ✅

### Schritt 2: Nur Cluster Nodes scannen

**Schneller Scan nur der Nodes:**

```bash
nmap -sn 192.168.178.29-32
```

**Ergebnis:**
```
Nmap scan report for Cluster-Mini-01 (192.168.178.29)
Host is up (0.00089s latency).
Nmap scan report for Cluster-Mini-02 (192.168.178.30)
Host is up (0.00078s latency).
Nmap scan report for Cluster-Mini-03 (192.168.178.31)
Host is up (0.00092s latency).
Nmap scan report for Cluster-Mini-04 (192.168.178.32)
Host is up (0.00088s latency).

Nmap done: 4 IP addresses (4 hosts up) scanned in 0.56 seconds
```

**Beobachtung:**
- Alle 4 Nodes online ✅
- Latenzen sehr niedrig (<1ms) ✅
- Verbindung ausgezeichnet

### Schritt 3: Detaillierter Scan eines Nodes

**Ports und Services überprüfen:**

```bash
nmap -A 192.168.178.29
```

**Ergebnis:**
```
Starting Nmap 7.97 ( https://nmap.org )
Nmap scan report for Cluster-Mini-01 (192.168.178.29)
Host is up (0.00089s latency).
Not shown: 997 closed tcp ports (conn-refused)
PORT     STATE SERVICE     VERSION
22/tcp   open  ssh         OpenSSH 9.6
5900/tcp open  vnc         Apple Remote Desktop
51413/tcp open  torrentd     Transmission
...
```

**Das bedeutet:**
- Port 22 (SSH): Offen ✅ → Remote-Zugriff möglich
- Port 5900 (VNC): Offen ✅ → Fernsteuerung möglich
- Verschiedene Services laufen

### Schritt 4: Nur bestimmte Ports scannen

**Schneller Scan für bestimmte Ports:**

```bash
nmap -p 22,80,443 192.168.178.29-32
```

**Ergebnis:**
```
Nmap scan report for Cluster-Mini-01 (192.168.178.29)
PORT     STATE SERVICE
22/tcp   open  ssh
80/tcp   closed
443/tcp  closed

Nmap scan report for Cluster-Mini-02 (192.168.178.30)
PORT     STATE SERVICE
22/tcp   open  ssh
80/tcp   closed
443/tcp  closed

...
```

**Bedeutung:**
- SSH (22) ist auf allen Nodes offen → Fernzugriff möglich
- HTTP/HTTPS nicht nötig für Render-Nodes

### Schritt 5: Schneller vs. gründlicher Scan

**Sehr schnell (aber weniger genau):**
```bash
nmap -F 192.168.178.0/24
```

**Langsam aber sehr gründlich:**
```bash
nmap -sV 192.168.178.0/24
```

---

## Praktische Übungen

### Übung 1: Status aller Cluster Nodes prüfen

```bash
for ip in 192.168.178.29 192.168.178.30 192.168.178.31 192.168.178.32; do
    echo -n "$ip: "
    ping -c 1 -W 1 $ip 2>/dev/null | grep "bytes from" >/dev/null && echo "✅ Online" || echo "❌ Offline"
done
```

**Erwartetes Ergebnis:**
```
192.168.178.29: ✅ Online
192.168.178.30: ✅ Online
192.168.178.31: ✅ Online
192.168.178.32: ✅ Online
```

### Übung 2: Gesamtes Netzwerk überblicken

```bash
nmap -sn 192.168.178.0/24 | grep "Nmap scan report"
```

**Zeigt nur die Hostnamen:**
```
Nmap scan report for 192-168-178-1.fritz.box (192.168.178.1)
Nmap scan report for Cluster-Mini-01 (192.168.178.29)
Nmap scan report for Cluster-Mini-02 (192.168.178.30)
...
```

### Übung 3: Netzwerk-Scan speichern

```bash
nmap -sn 192.168.178.0/24 > netzwerk_scan.txt
cat netzwerk_scan.txt
```

**Speichert Ergebnis in Datei für spätere Referenz**

---

## Troubleshooting mit nmap

### Problem: "Gerät sollte online sein, aber nmap findet es nicht"

**Lösungsschritte:**
1. Direkter Ping: `ping 192.168.178.29`
2. Falls Ping funktioniert, aber nmap nicht:
   - Versuche `-P0` Option: `nmap -P0 192.168.178.29`
   - Oder TCP-Ping: `nmap -PA 192.168.178.29`

### Problem: "Scan dauert zu lange"

**Lösungsschritte:**
1. Benutze `-F` für schnelle Scan: `nmap -F 192.168.178.0/24`
2. Oder `-T4` für aggressive Timing: `nmap -T4 -sn 192.168.178.0/24`
3. Oder nur Ping-Scan: `nmap -sn 192.168.178.0/24`

### Problem: "Ich weiß nicht, welche Ports offen sind"

**Lösung:** Detaillierter Scan mit Service-Erkennung
```bash
nmap -sV 192.168.178.29
```

---

## Wichtige nmap-Optionen

| Option | Bedeutung | Beispiel |
|--------|-----------|----------|
| `-sn` | Ping-Scan (schnell) | `nmap -sn 192.168.178.0/24` |
| `-p 22` | Nur Port 22 | `nmap -p 22 192.168.178.29` |
| `-A` | Aggressiv (OS, Versionen) | `nmap -A 192.168.178.29` |
| `-sV` | Service-Versionen | `nmap -sV 192.168.178.0/24` |
| `-F` | Schnell (nur häufige Ports) | `nmap -F 192.168.178.0/24` |
| `-T4` | Aggressive Timing | `nmap -T4 192.168.178.0/24` |
| `-oN file` | Speichern in Datei | `nmap -sn ... -oN result.txt` |

---

## Wann nutzt man diesen Workflow?

✅ **Nutze manuelle nmap-Befehle:**
- Schnelle Ad-hoc-Überprüfung
- Spezifische Geräte-Diagnose
- Port-Analyse
- Troubleshooting
- Einmalige Überprüfung

❌ **Nutze stattdessen Claude-Automation (Modul 07-netzwerkscan_claude.md):**
- Täglich wiederkehrende Scans
- Historische Daten
- Vergleiche über Zeit
- Automatische Alerts
- Reports

---

## Praktischer Tipp für Dr. Stracke

**Schneller täglicher Check:**
```bash
# Alle Cluster Nodes in 1 Sekunde prüfen
nmap -sn 192.168.178.29-32
```

**Wenn Problem:** Detaillierter Scan
```bash
nmap -A 192.168.178.29
```

**Wenn viele Geräte überprüfen:**
```bash
nmap -sn 192.168.178.0/24 | grep -c "Host is up"
```

---

**Nächster Schritt:** Siehe Modul 08-cgnat.md für NAT und externen Zugriff.
