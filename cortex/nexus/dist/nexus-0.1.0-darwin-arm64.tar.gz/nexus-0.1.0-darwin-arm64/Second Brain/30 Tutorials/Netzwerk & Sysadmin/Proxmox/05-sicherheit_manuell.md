# Proxmox 05 — Manueller Workflow

> Schritt-für-Schritt: Server absichern.

---

## Übung 1: System-Updates durchführen

```bash
# 1. VORHER: Snapshot der wichtigsten VMs machen (Web-Interface)

# 2. Proxmox-Host aktualisieren
ssh root@192.168.10.31
apt update
apt list --upgradable

# 3. Updates installieren
apt dist-upgrade -y

# 4. Prüfen ob Neustart nötig
ls /var/run/reboot-required 2>/dev/null && echo "REBOOT NÖTIG" || echo "Kein Reboot nötig"

# 5. Falls nötig: Geplanten Zeitpunkt für Neustart wählen (z.B. nach Praxisschluss)
```

## Übung 2: SSH-Key einrichten

Auf dem Mac:
```bash
# 1. Key generieren (falls noch nicht vorhanden)
ssh-keygen -t ed25519 -C "dr.stracke@praxis"
# → Speicherort: Standard (~/.ssh/id_ed25519)
# → Passphrase: Optional, aber empfohlen

# 2. Key auf den Server kopieren
ssh-copy-id root@192.168.10.31

# 3. Testen: Verbindung OHNE Passwort
ssh root@192.168.10.31
# Sollte direkt verbinden (oder Passphrase des Keys fragen)

# 4. ERST JETZT Passwort-Login deaktivieren (auf dem Server):
# nano /etc/ssh/sshd_config
# → PasswordAuthentication no
# systemctl restart sshd

# 5. In NEUEM Terminal testen, ob Key-Login funktioniert
# → Wenn ja: alles gut
# → Wenn nein: NICHT die alte Session schließen! Änderung rückgängig machen.
```

## Übung 3: Fail2Ban installieren

```bash
# Auf dem Proxmox-Host:
apt install fail2ban -y

# Status prüfen
systemctl status fail2ban

# Aktuelle Bans anzeigen
fail2ban-client status sshd

# Eine IP manuell entbannen (falls du dich selbst ausgesperrt hast)
fail2ban-client set sshd unbanip 192.168.10.100
```

## Übung 4: 2FA einrichten

1. Installiere eine TOTP-App auf dem Handy:
   - iOS: „Authenticator" oder „Google Authenticator"
   - Android: „Google Authenticator" oder „Aegis"

2. Im Proxmox Web-Interface:
   - Oben rechts auf deinen Benutzernamen klicken
   - **TFA** → **Add** → **TOTP**
   - QR-Code mit der App scannen
   - 6-stelligen Code eingeben → Bestätigen

3. **Recovery Keys** notieren und sicher aufbewahren!
   (Falls du das Handy verlierst)

4. Abmelden und neu einloggen — jetzt wird der Code abgefragt.

## Notfall: Ausgesperrt?

Falls du dich versehentlich aussperrst:

**Option 1: IPMI/BMC** (Browser)
- `https://192.168.10.32` oder `https://192.168.10.34`
- Dort: Remote-Konsole öffnen → direkt am Server einloggen

**Option 2: Physischer Zugang**
- Monitor + Tastatur an den Server anschließen
- Direkt einloggen (Passwort-Login funktioniert lokal immer)

**Option 3: Rescue-Modus**
- Server von USB/ISO booten
- Root-Partition mounten
- SSH-Config oder Passwort zurücksetzen

---

## Nächste Schritte

→ **06-monitoring-und-wartung.md** — Server überwachen
