---
type: tutorial-landing
domain: gaming
aliases: [Gaming, Browser-Spiele, Emscripten, WebAssembly, WASM]
tags:
  - tutorial
  - gaming
  - webassembly
  - emscripten
source: Second Brain/30 Tutorials/Gaming/
---

# Gaming — Tutorial-Domäne

> Quellpfad: `Second Brain/30 Tutorials/Gaming/`
> Diese Domäne sammelt Tutorials rund um Browser-Spiele, Emscripten,
> WebAssembly und alles, was damit zusammenhängt — wenn man ein Desktop-Spiel
> in den Browser bringen oder verstehen möchte, wie fremder Game-Code im Web
> funktioniert.

> [!info] Lesezeit: 5 Min Übersicht · DOOM-Modul: ~30 Min · Voraussetzung: Terminal-Grundlagen

---

## 1. Wann ist Gaming für dich relevant?

Direkter Praxis-Nutzen ist gering — die Domäne existiert primär als
**Lehr-Sandbox** für Themen, die du anderswo brauchst:

| Was du in Gaming-Tutorials lernst | Wo es dir später hilft |
|---|---|
| **WebAssembly (WASM)** verstehen | Performance-kritische Web-Module (z. B. Avatar-Renderer für Juvantis im Browser) |
| **Emscripten** = C/C++ → Browser kompilieren | Wenn ein bestehendes Tool (Linux-CLI, älteres C-Programm) im Browser laufen soll |
| **Canvas + JavaScript** für Pixel-Animationen | Eigene Visualisierungen (z. B. Wartezeit-Heatmap aus SmartQ-Daten) |
| **Pointer-Lock, WebAudio** | Custom-UX-Features in Webseiten |
| **Asset-Trennung** (Engine ≠ Daten) | Generelles Architektur-Prinzip — gilt für jede Anwendung |

Plus: ein DOOM-Port im Browser ist ein **fertiges Demo-Asset** für Tech-
Veranstaltungen oder Mitarbeiter-Onboarding („so flexibel ist das Web").

---

## 2. Module

| # | Datei | Theorie | Claude | Manuell |
|---|-------|---------|--------|---------|
| 01 | DOOM im Browser | [[Gaming/01-doom-im-browser\|Theorie]] | [[Gaming/01-doom-im-browser_claude\|Claude-Workflow]] | [[Gaming/01-doom-im-browser_manuell\|Manuell]] |

**Praktisches Beispiel:** lebt in `projects/Gaming/Doom/`. Start: `bash start.sh` → Port 8765.

---

## 3. Mögliche zukünftige Module (Roadmap)

Werden bei Bedarf ergänzt — bisher nicht aktiv:

- **02** — Eigenes Spiel mit Canvas + JavaScript (Raycaster-Grundlagen)
- **03** — Emscripten selbst installieren und C-Code kompilieren
- **04** — WebAssembly (WASM) richtig: wann WASM, wann asm.js, wann beides
- **05** — Game-Loop-Architektur (Update / Render / Input getrennt)

Wenn dich eines dieser Themen interessiert, kannst du es als `[!frage]` oder
`[!anweisung]` im Vault hinterlegen — Claude legt dann das Modul an.

---

## 4. Begriffe, die in dieser Domäne wichtig sind

| Begriff | Bedeutung |
|---|---|
| **Engine** | Der Code, der das Spiel rechnet (Grafik, Physik, Logik) |
| **Assets** | Die Daten: Levels, Sprites, Sounds, Musik |
| **WAD** | DOOM-Datenformat („Where's All the Data") seit 1993 |
| **IWAD** | Haupt-WAD mit allen Basis-Assets (`freedoom1.wad`) |
| **PWAD** | Zusatz-WAD mit Custom-Leveln, die die IWAD ergänzen |
| **Emscripten** | Compiler, der C/C++ nach JavaScript/WebAssembly übersetzt |
| **asm.js** | Spezielle JavaScript-Variante, fast so schnell wie C (2013+) |
| **WebAssembly (WASM)** | Binary-Format, das Browser noch schneller ausführen (2017+) |
| **Canvas** | HTML5-Element zum Pixel-genau-Malen im Browser |
| **WebAudio** | Browser-API für Sound-Effekte und MIDI |
| **MIDI** | Musik-Format (nicht aufgezeichnete Töne, sondern Noten) |
| **Pointer-Lock** | Browser-API: Maus-Cursor verstecken und unendlich bewegen |
| **Game-Loop** | Endlosschleife: Input → Update → Render → wieder von vorn |

---

## 5. Wichtige Regeln (siehe [[_MOC Regeln|GLOBAL_RULES]])

- **LL-027 — Lizenz vor Code prüfen:** Bei externen Assets IMMER die Lizenz checken.
  - DOOM1.WAD von id Software ist **nicht frei** (kommerziell).
  - **FreeDoom** ist BSD-lizenziert (frei nutzbar).
  - Bei Avatar-Quellen: Ready Player Me Standard ist CC-BY-NC-SA → für sanexio.eu **verboten**. Mixamo (Adobe) ist kommerziell frei. Siehe `projects/Juvantis/DHT/AVATAR_SOURCES.md`.
- **Asset-Trennung:** Bei Spielen immer Engine und Daten getrennt halten. Wenn
  du die Daten austauschen kannst, ohne den Code anzufassen, ist dein Projekt
  zukunftssicher. (Gilt auch für Web-Apps: Theme ↔ Content getrennt.)

---

## 6. Lern-Reihenfolge

Bisher nur ein Modul:

1. [[Gaming/01-doom-im-browser|01 — DOOM im Browser (Theorie)]] — was alles passiert, wenn ein 1993er C-Programm im 2026er Browser läuft
2. [[Gaming/01-doom-im-browser_manuell|01 — Manuell]] — selbst zum Laufen bringen
3. [[Gaming/01-doom-im-browser_claude|01 — Claude]] — Claude-gestützter Aufbau

---

## Verwandte Notizen

- [[_MOC Tutorials]] — Dach-MOC aller Tutorials
- [[_Basiswissen Schnelleinstieg]] — Gaming ist nicht in den Pflichtpfaden, aber Querverweis auf WebAssembly
- [[Webentwicklung Grundlagen]] — Browser-Stack-Hintergrund


<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

- [[30 Tutorials/Gaming/01-doom-im-browser|01-doom-im-browser]] · [[30 Tutorials/Gaming/01-doom-im-browser_claude|Claude]] · [[30 Tutorials/Gaming/01-doom-im-browser_manuell|Manuell]]

<!-- /auto-moc-links -->
