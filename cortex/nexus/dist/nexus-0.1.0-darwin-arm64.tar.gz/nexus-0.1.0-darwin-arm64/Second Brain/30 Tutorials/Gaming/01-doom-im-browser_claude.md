# DOOM im Browser — Claude-Workflow

> Dieser Workflow beschreibt, wie Du Claude bittest, das DOOM-Projekt neu
> aufzusetzen, zu updaten oder zu aendern. Theorie: [[01-doom-im-browser]].

---

## Aus dem Nichts installieren (auf neuem Geraet)

Prompt fuer Claude:

> "Setze mir `projects/Gaming/Doom/` neu auf — Option A aus dem letzten Mal
> (FreeDoom Phase 1 + doomgeneric-WASM-Port). Alles runterladen, konfigurieren,
> testen."

Was Claude dann macht (in dieser Reihenfolge):

1. Pruefen, ob `projects/Gaming/` existiert, ggf. Ordner anlegen
2. `doomgeneric.js` aus `grubbyplaya/doomgenericjs` holen (~3 MB)
3. `freedoom1.wad` aus dem FreeDoom GitHub Release laden (~29 MB, ZIP entpacken)
4. MIDI-Libs in `vendor/` laden
5. `index.html`, `boot.js`, `start.sh`, `README.md` schreiben
6. HTTP-Server starten + verifizieren dass alle Endpoints `200 OK` liefern
7. Dir den Browser-Link geben

**Rechenzeit:** ca. 2 Minuten.

---

## Bestehendes Projekt updaten

### FreeDoom auf neue Version aktualisieren

Prompt:

> "Schau, ob FreeDoom ein neues Release hat, und update `projects/Gaming/Doom/freedoom1.wad`."

Was Claude macht:

1. GitHub API abfragen: `api.github.com/repos/freedoom/freedoom/releases/latest`
2. Vergleichen mit der aktuellen Version (steht in README.md oder als Kommentar
   in `index.html`)
3. Falls neuer: Download, ersetzen, CREDITS aktualisieren, README bumpen
4. Testen, dass die WAD ladbar ist (`curl -I` auf den lokalen Server)

### Engine auf neue doomgeneric-Version updaten

Prompt:

> "Update die DOOM-Engine in `projects/Gaming/Doom/engine.js` auf die neueste
> doomgeneric-Version."

Achtung: Ein Engine-Update kann die DGJS_*-API aendern. Claude muss dann
`boot.js` nachziehen. **Vor dem Update:** Alte `engine.js` nach
`archiv/v4-vor-update/` sichern.

---

## Erweitern

### FreeDoom Phase 2 (DOOM II-Ersatz) hinzufuegen

Prompt:

> "Lade auch `freedoom2.wad` und baue einen Auswahl-Screen, ueber den ich
> zwischen Phase 1 und Phase 2 umschalten kann."

Was Claude dann macht:

1. `freedoom2.wad` aus demselben FreeDoom Release holen
2. `index.html`: Radio-Buttons im Start-Overlay (Phase 1 / Phase 2)
3. `boot.js`: Je nach Auswahl andere `-iwad`-Argument an Module.arguments haengen
4. README aktualisieren

### Custom PWADs (Fan-Levels) laden

Prompt:

> "Ich habe in `projects/Gaming/Doom/pwads/` eine `mylevel.wad`. Baue ein
> Dropdown in den Startbildschirm, in dem ich zusaetzliche PWADs aktivieren kann."

Was Claude dann macht:

1. PWAD-Dateien im Ordner per `fetch()` auflisten (ueber den HTTP-Server-Dir-Listing)
2. Dropdown/Checkboxen im Overlay
3. In `boot.js`: Module.arguments += `['-merge', 'mylevel.wad']` (oder `-file`)
4. FS.writeFile() fuer jede aktive PWAD

---

## Fehlersuche

### "WAD-Download fehlgeschlagen"

Prompt:

> "Das Spiel zeigt 'WAD-Download fehlgeschlagen'. Was ist los?"

Was Claude prueft:

1. Laeuft `start.sh` ueberhaupt? → `lsof -i :8765`
2. Ist `freedoom1.wad` im Ordner? → `ls -la projects/Gaming/Doom/*.wad`
3. Antwortet der HTTP-Server mit 200? → `curl -I http://localhost:8765/freedoom1.wad`
4. Wird die Datei vollstaendig ausgeliefert? → `curl -s -o /dev/null -w "%{size_download}\n" http://localhost:8765/freedoom1.wad` muss 28795076 liefern

### Schwarzer Bildschirm nach dem Klick

Prompt:

> "Ich klicke auf SPIELEN und dann wird der Screen schwarz, nichts passiert."

Was Claude prueft:

1. Browser-Konsole (mit Claude-CLI-Screenshot): Fehlermeldung?
2. Typische Ursachen:
   - `_toDoomKey` nicht exportiert → Emscripten-Build kaputt
   - `doomgeneric_Create` wird nicht aufgerufen → boot.js hat Fehler
   - Canvas-Context nicht gefunden → Selector stimmt nicht

Claude kann in diesem Fall einen **headless Browser-Test** machen:

```bash
npx -y playwright-chromium --version  # pruefen ob verfuegbar
# dann automatisch Seite laden und Konsolen-Output lesen
```

### Kein Ton

Prompt:

> "Das Spiel laeuft, aber ich hoere nichts."

Claude prueft:

1. AudioContext-Status: muss `running` sein, nicht `suspended`
2. Wurde `DGJS_InitSound()` aufgerufen? → Browser-Konsole nach `Init` filtern
3. Wurde `DGJS_StartSound` jemals getriggert?

Oft Loesung: Auf den Canvas klicken (AudioContext braucht User-Gesture).

---

## Anpassen

### Aussehen / UI

Prompt:

> "Mache den Startbildschirm schlichter — weg mit dem roten Gradient,
> stattdessen ein schwarzes Bild mit einem kleinen DOOM-Logo oben links."

Claude editiert nur `index.html` (CSS-Block). **Niemals** engine.js anfassen
— das ist ein kompilierter Build.

### Steuerung umbelegen

Prompt:

> "Ich moechte dass die Leertaste statt CTRL auf 'Schiessen' gelegt wird."

Claude editiert `boot.js`, die `document.addEventListener('keydown'...)`.
Beispiel: statt `_toDoomKey(e.keyCode)` ein Custom-Mapping wenn `e.code === 'Space'`.

---

## NICHT machen

- **Nie** `engine.js` manuell editieren. Ist 3 MB compilierter Code.
  Aenderungen gehen in `boot.js` (die Hooks) oder ggf. in den C-Source bei
  doomgeneric (dann muss Emscripten neu compiliert werden — anderes Tutorial).
- **Nie** die WAD veraendern (keine Hex-Edits). Levels aendert man mit einem
  Level-Editor (SLADE, Doom Builder) und erzeugt dann PWADs.
- **Nie** DOOM-Original-Assets (doom.wad, doom2.wad von id Software) committen
  oder oeffentlich hosten — das ist Urheberrechtsverletzung. FreeDoom nutzen.

---

## Siehe auch

- [[01-doom-im-browser]] — Theorie, wie das Ganze funktioniert
- [[01-doom-im-browser_manuell]] — wenn Du es selbst ohne Claude nachbauen willst
