# DOOM im Browser — Manueller Workflow

> Schritt-fuer-Schritt-Anleitung, wenn Du es selbst (ohne Claude) nachbauen
> willst — auf einem neuen Geraet, oder nur zum Verstehen.
> Theorie: [[01-doom-im-browser]].

---

## Voraussetzungen

- macOS oder Linux mit Terminal
- `curl` (vorinstalliert)
- `python3` (vorinstalliert auf macOS)
- `unzip` (vorinstalliert)
- Moderner Browser (Chrome, Safari, Firefox — alle reichen)

Keine weiteren Installationen noetig.

---

## Schritt 1: Projektordner anlegen

```bash
mkdir -p ~/Cortex/projects/Gaming/Doom
cd ~/Cortex/projects/Gaming/Doom
```

---

## Schritt 2: DOOM-Engine laden (doomgenericjs)

```bash
# Clone das Repo nach /tmp (wir brauchen nur eine Datei daraus)
git clone --depth 1 https://github.com/grubbyplaya/doomgenericjs.git /tmp/doomgenericjs

# Kopiere die fertige Emscripten-Engine ins Projekt
cp /tmp/doomgenericjs/doomgeneric/doomgeneric.js ./engine.js

# Groesse pruefen — sollte ca. 3 MB sein
ls -lh engine.js
```

**Was passiert hier?** Die Datei `engine.js` ist die DOOM-Engine, die ein anderer
Entwickler bereits mit Emscripten (einem C→JS-Compiler) uebersetzt hat. Wir
sparen uns damit die ~30 Minuten, in denen wir selbst Emscripten installieren
und den Compile-Vorgang durchfuehren muessten.

---

## Schritt 3: FreeDoom WAD laden

```bash
# FreeDoom Release ZIP holen (~24 MB)
curl -L -o /tmp/freedoom.zip \
  https://github.com/freedoom/freedoom/releases/download/v0.13.0/freedoom-0.13.0.zip

# Nur die benoetigte WAD + Lizenzen rausholen
unzip -j /tmp/freedoom.zip \
  "freedoom-0.13.0/freedoom1.wad" \
  "freedoom-0.13.0/COPYING.txt" \
  "freedoom-0.13.0/CREDITS.txt" \
  -d .

# Lizenzdateien umbenennen (klarer, von wem sie sind)
mv COPYING.txt LICENSE-FREEDOOM.txt
mv CREDITS.txt CREDITS-FREEDOOM.txt

# Groessen pruefen
ls -lh freedoom1.wad LICENSE-FREEDOOM.txt
```

Ergebnis:
- `freedoom1.wad` — 28.8 MB
- `LICENSE-FREEDOOM.txt` — BSD-Lizenz
- `CREDITS-FREEDOOM.txt` — Liste der Mitwirkenden

---

## Schritt 4: MIDI-Player laden (fuer Musik)

```bash
mkdir vendor
curl -L -o vendor/midi-player.js \
  https://fraigo.github.io/javascript-midi-player/midiplayer/MIDIPlayer.js
curl -L -o vendor/midi-file.js \
  https://fraigo.github.io/javascript-midi-player/midiplayer/MIDIFile.js
curl -L -o vendor/webaudiofontplayer.js \
  https://fraigo.github.io/javascript-midi-player/midiplayer/WebAudioFontPlayer.js

ls -la vendor/
```

**Warum noch eine externe Bibliothek?** DOOM-Musik ist im **MIDI-Format**. Die
DOOM-Engine uebergibt uns die MIDI-Bytes, aber wir muessen sie selbst abspielen.
Browser koennen MIDI nativ nicht — deshalb der JavaScript-Player.

---

## Schritt 5: `index.html` schreiben

Minimaler Startpunkt:

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>DOOM</title>
  <style>
    body { background: black; margin: 0; }
    canvas { image-rendering: pixelated; width: 100vw; height: 100vh; }
    button { position: absolute; top: 50%; left: 50%;
             transform: translate(-50%, -50%); padding: 20px; font-size: 24px; }
  </style>
</head>
<body>
  <canvas id="doomCanvas" width="320" height="200"></canvas>
  <button id="start">SPIELEN</button>

  <script src="vendor/webaudiofontplayer.js"></script>
  <script src="vendor/midi-file.js"></script>
  <script src="vendor/midi-player.js"></script>
  <script src="boot.js"></script>
  <script src="engine.js"></script>
</body>
</html>
```

**Die Reihenfolge der `<script>`-Tags ist wichtig:**
1. MIDI-Libs ZUERST (damit `MIDIPlayer` global verfuegbar ist)
2. Dann `boot.js` (definiert `window.Module` und die `DGJS_*` Callbacks)
3. Dann `engine.js` (liest `window.Module` und feuert die Callbacks ab)

---

## Schritt 6: `boot.js` schreiben (der Glue-Code)

Die vollstaendige Version steht im Projekt. Hier der wesentliche Kern:

```javascript
// Canvas vorbereiten
const canvas = document.getElementById('doomCanvas');
const ctx    = canvas.getContext('2d');
const screen = new ImageData(320, 200);

// Input-Queue
const keyQueue = [];

// Emscripten Module konfigurieren (MUSS vor engine.js existieren)
window.Module = {
  canvas: canvas,
  noInitialRun: true,  // wir starten spaeter selbst
  onRuntimeInitialized: () => console.log('DOOM bereit'),
};

window.DGJS_MusicType = true;

// WAD laden und dann starten
fetch('freedoom1.wad')
  .then(r => r.arrayBuffer())
  .then(buf => {
    const bytes = new Uint8Array(buf);
    document.getElementById('start').onclick = () => {
      FS.writeFile('/freedoom1.wad', bytes);
      Module.arguments = ['-iwad', 'freedoom1.wad'];
      Module.ccall('doomgeneric_Create');
      setInterval(Module._doomgeneric_Tick, 0);
      document.getElementById('start').remove();
    };
  });

// Render-Callback
window.DGJS_DrawFrame = (ptr, w, h) => {
  const src = Module.HEAPU8.subarray(ptr, ptr + w * h * 4);
  for (let i = 0; i < w * h * 4; i += 4) {
    screen.data[i]     = src[i + 2];  // R aus B
    screen.data[i + 1] = src[i + 1];  // G
    screen.data[i + 2] = src[i];      // B aus R
    screen.data[i + 3] = 255;
  }
  ctx.putImageData(screen, 0, 0);
};

// Input-Callbacks
window.DGJS_GetKey  = () => keyQueue.shift() || [0, 0];
window.DGJS_SetTitle = () => {};

document.addEventListener('keydown', e => keyQueue.push([_toDoomKey(e.keyCode), 1]));
document.addEventListener('keyup',   e => keyQueue.push([_toDoomKey(e.keyCode), 0]));

// Musik + Sound — siehe vollstaendige boot.js
window.DGJS_InitMusic = () => true;
window.DGJS_RegisterSong = () => 0;
window.DGJS_PlaySong = () => {};
// ... weitere Stubs fuer DGJS_StopSong, DGJS_InitSound etc.
```

---

## Schritt 7: Start-Skript

```bash
cat > start.sh <<'EOF'
#!/usr/bin/env bash
cd "$(dirname "$0")"
( sleep 1 && open "http://localhost:8765/" ) &
exec python3 -m http.server 8765 --bind 127.0.0.1
EOF

chmod +x start.sh
```

---

## Schritt 8: Starten und testen

```bash
./start.sh
```

Browser oeffnet sich automatisch. Du solltest sehen:
1. Einen "SPIELEN"-Button
2. Nach Klick: DOOM-Titelbild
3. Nach weiterem Klick: E1M1-Level

Tastatur: `WASD` zum Bewegen, `Leertaste` fuer Tueren, `Enter` im Menue.

---

## Was haettest Du sonst noch tun koennen?

### Emscripten selbst installieren und bauen

Wenn Du die Engine von Grund auf neu bauen willst (z.B. weil Du C-Code der
Engine anpassen willst):

```bash
# Emscripten SDK installieren
git clone https://github.com/emscripten-core/emsdk.git
cd emsdk
./emsdk install latest
./emsdk activate latest
source ./emsdk_env.sh

# doomgeneric Source holen
git clone https://github.com/grubbyplaya/doomgenericjs.git
cd doomgenericjs/doomgeneric

# Bauen (nutzt das mitgelieferte Makefile)
make -f makefile.module

# Ergebnis: doomgeneric.js + doomgeneric.wasm (je nach Config)
```

Das dauert ca. 30 Minuten (emsdk-Download) + 5 Minuten (Build).

### DOOM II-Ersatz (FreeDoom Phase 2) zusaetzlich laden

```bash
unzip -j /tmp/freedoom.zip "freedoom-0.13.0/freedoom2.wad" -d .
```

Dann in `boot.js` das `'-iwad'`-Argument anpassen, oder einen Auswahl-Screen
bauen.

---

## Fehlerbilder

| Symptom                         | Ursache                                | Fix                                     |
|---------------------------------|----------------------------------------|-----------------------------------------|
| Leere Seite, nichts passiert    | `file://` statt `http://`              | `start.sh` ausfuehren                   |
| "Module is not defined"         | `<script>`-Reihenfolge falsch          | `boot.js` VOR `engine.js` laden         |
| "_toDoomKey is not defined"     | engine.js nicht geladen / falsche Vers. | engine.js neu kopieren                  |
| Canvas bleibt schwarz           | `Module.ccall('doomgeneric_Create')` fehlt | in boot.js pruefen                 |
| Kein Ton                        | AudioContext suspended                 | In Canvas klicken nach Spielstart       |
| Zwischenablage-Shortcuts greifen | Browser faengt Tasten ab              | `e.preventDefault()` in keydown         |

---

## Siehe auch

- [[01-doom-im-browser]] — Theorie, Architektur, Lizenzen
- [[01-doom-im-browser_claude]] — dasselbe mit Claude automatisiert
