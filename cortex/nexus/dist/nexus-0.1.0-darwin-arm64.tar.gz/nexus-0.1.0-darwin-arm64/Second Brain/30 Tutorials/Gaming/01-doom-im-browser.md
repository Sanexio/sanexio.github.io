# DOOM im Browser — Wie funktioniert das eigentlich?

## Was lernst du hier?

Wie man ein **25 Jahre altes C-Programm** (die originale DOOM-Engine von 1993) ohne
Neuschreiben in einem modernen Browser zum Laufen bringt — und warum das erstaunlich
sauber funktioniert. Dieses Tutorial erklaert die Technik hinter `projects/Gaming/Doom/`.

**Warum brauche ich das?** Weil das dieselbe Technik ist, mit der:
- Google Earth im Browser laeuft
- AutoCAD Web funktioniert
- Figma C++-Code im Browser ausfuehrt
- Spotify / Zoom Video-Codecs auf der Webseite haben

Kurz: **Jede komplexe Desktop-Anwendung, die im Browser laeuft, nutzt im Kern
dieselbe Idee wie unsere DOOM-Installation.**

---

## Die drei Komponenten

Ein vollstaendig lauffaehiges Browser-DOOM besteht aus **drei Teilen**, die
unabhaengig voneinander lizenziert und entwickelt wurden:

| Teil       | Was ist das?                              | Groesse    | Lizenz   |
|------------|-------------------------------------------|------------|----------|
| **Engine** | Die DOOM-Engine selbst (in C geschrieben) | ~3 MB      | GPL v2   |
| **WAD**    | Levels, Sprites, Sounds, Musik            | ~29 MB     | BSD      |
| **Browser-Glue** | Tastatur/Maus/Canvas verbinden      | ~13 KB     | eigen    |

Der Clou: **Engine und WAD stammen aus zwei verschiedenen Projekten**, die sich
nicht kennen. DOOM trennt seit 1993 strikt zwischen Code und Daten — darum
funktionieren beliebige WADs mit beliebigen DOOM-Klonen. Das ist die gleiche
Architektur wie z.B. "Game Boy ROMs" auf einem "Game Boy Emulator".

---

## Teil 1: Die Engine (engine.js)

### Was ist das?

Die Datei `engine.js` im Projekt ist **keine normale JavaScript-Datei**. Sie ist
der komplette C-Code der DOOM-Engine, der automatisch in JavaScript uebersetzt
wurde. Schritt fuer Schritt:

1. **DOOM Source Code** (id Software, 1997 als GPL freigegeben) — ca. 35 000 Zeilen C
2. **doomgeneric** (ozkl/doomgeneric, GitHub) — DOOM so umgeschrieben, dass man
   Grafik/Tastatur/Sound austauschen kann. 18 C-Dateien.
3. **Emscripten** (Mozilla/LLVM) — ein Compiler, der C-Code nach JavaScript
   uebersetzt. Das Ergebnis heisst **asm.js** und laeuft in allen Browsern.
4. **doomgenericjs** (grubbyplaya, GitHub) — liefert die fertige `engine.js`
   (3 MB), die man einfach per `<script src="engine.js">` laden kann.

### Wie kann C-Code in JavaScript laufen?

Emscripten uebersetzt jede C-Funktion in eine JavaScript-Funktion. Aus:

```c
int add(int a, int b) { return a + b; }
```

wird (vereinfacht):

```javascript
function _add(a, b) { return (a + b) | 0; }
```

Das `| 0` sorgt dafuer, dass `a + b` als **Integer** behandelt wird (JavaScript kennt
eigentlich nur Fliesskomma-Zahlen). Das ist der Trick hinter asm.js: Durch solche
Hinweise kann der Browser das JavaScript fast so schnell ausfuehren wie echten
C-Code. Auf einem M2 Mac erreicht DOOM damit ueber 200 FPS.

### Der C-Speicher lebt in einem grossen Array

DOOM erwartet einen Speicher, in dem es schreiben und lesen kann (`malloc`, `free`,
`memcpy` — alles Standard C). Emscripten simuliert diesen Speicher mit einem
**riesigen JavaScript-Array**:

```javascript
Module.HEAPU8   // Uint8Array, 16 MB lang, "der C-Heap"
Module.HEAP32   // Int32Array,  dieselben Bytes, anders interpretiert
```

Wenn DOOM im C-Code die Funktion `malloc(1024)` aufruft, gibt ihm Emscripten
eine Zahl zurueck — z.B. `524288`. Das ist kein echter Speicher-Pointer, sondern
ein **Index in HEAPU8**. Die naechsten 1024 Bytes ab Index 524288 gehoeren jetzt
DOOM, bis es `free()` aufruft.

**Warum wichtig?** Weil unser Glue-Code (`boot.js`) mit diesem Speicher arbeiten
muss. Wenn DOOM "hier ist das fertige Bild" sagt und einen Pointer `framePtr`
liefert, holen wir die Pixel aus `HEAPU8` raus und malen sie ins Canvas.

---

## Teil 2: Die WAD-Datei (freedoom1.wad)

### Was ist das?

**WAD** steht fuer **"Where's All the Data"** — so hat John Carmack den DOOM-
Dateicontainer 1993 genannt. Eine WAD-Datei enthaelt:

- Alle Levels (E1M1 Hangar, E1M2 Nuclear Plant, ...)
- Alle Sprites (Monster, Waffen, Munition)
- Alle Texturen (Waende, Boden, Decke)
- Alle Soundeffekte (Schuss, Schrei, Explosion)
- Alle Musik (MIDI im DOOM-eigenen MUS-Format)
- Kleine Grafiken (Menu, Status-Bar)

Die DOOM-Engine selbst enthaelt KEINE Assets — nur den Code. Das ist warum die
Engine nur 3 MB, die WAD aber 29 MB gross ist.

### Warum FreeDoom und nicht DOOM1?

Die **originale DOOM1.WAD** von id Software ist kommerziell (auch die 1993er
Shareware-Version, die offiziell frei kopiert werden durfte, ist kein Open
Source — id Software behaelt die Rechte an Sprites, Leveln, Musik).

**FreeDoom** ist ein Community-Projekt, das seit 2001 eigene Levels, Sprites und
Sounds im exakt gleichen WAD-Format erstellt. FreeDoom ist **BSD-lizenziert** —
frei fuer alle Zwecke, auch kommerziell. Die Levels sind **absichtlich** sehr
aehnlich zu DOOM 1 gestaltet, aber mit eigenen Namen und eigenem Stil.

- **FreeDoom Phase 1** (`freedoom1.wad`, 28 MB) = Ersatz fuer Ultimate DOOM (4 Episoden)
- **FreeDoom Phase 2** (`freedoom2.wad`, 28 MB) = Ersatz fuer DOOM II (32 Level)

Die Engine merkt nicht, dass es FreeDoom ist statt DOOM1. Sie sieht nur "eine
WAD-Datei im richtigen Format" und spielt sie ab.

---

## Teil 3: Browser-Glue (boot.js)

### Was muss der Glue-Code tun?

Die DOOM-Engine erwartet eine bestimmte Umgebung:

1. **"Gib mir den Inhalt der WAD-Datei"** — wir laden `freedoom1.wad` per
   `XMLHttpRequest` und schreiben die Bytes in das virtuelle Emscripten-
   Dateisystem (`FS.write`).
2. **"Zeichne diesen Pixel-Puffer aufs Bild"** — wir holen die Pixel aus
   `Module.HEAPU8` und malen sie via `putImageData` aufs Canvas.
3. **"Welche Taste ist gedrueckt?"** — wir horchen auf `keydown`/`keyup`-Events
   und pushen die in eine Queue, aus der DOOM sich bedient.
4. **"Spiel diesen Soundeffekt ab"** — wir erstellen einen WebAudio-Buffer
   und spielen ihn ueber `AudioContext` ab.
5. **"Spiel diese Musik ab"** — DOOM gibt uns MIDI-Bytes; wir geben sie an
   einen JavaScript-MIDI-Player weiter.

### Die DGJS_*-Callbacks

doomgenericjs definiert eine Liste an Funktionen, die unser Glue-Code bereit-
stellen MUSS. Alle beginnen mit `DGJS_`:

| Callback                | Was DOOM damit tut                       |
|-------------------------|------------------------------------------|
| `DGJS_DrawFrame`        | "Hier ist das fertige Bild des Frames"   |
| `DGJS_GetKey`           | "Welche Taste wurde als naechstes gedrueckt?" |
| `DGJS_SetTitle`         | "Setze den Fenster-Titel"                |
| `DGJS_InitMusic`        | "Richte den Music-Treiber ein"           |
| `DGJS_PlaySong`         | "Spiel diesen Song (MIDI) ab"            |
| `DGJS_StartSound`       | "Spiel diesen Soundeffekt ab"            |
| `DGJS_CacheSFX_PCM`     | "Cache diesen Soundeffekt im Speicher"   |

**So funktioniert der Frame-Loop** (vereinfacht, aus `boot.js`):

```javascript
// 1. Emscripten ist bereit → WAD ins virtuelle FS schreiben
FS.writeFile('/freedoom1.wad', wadBytes);

// 2. DOOM starten mit Argument "-iwad freedoom1.wad"
Module.arguments = ['-iwad', 'freedoom1.wad'];
Module.ccall('doomgeneric_Create');

// 3. 60x pro Sekunde einen Frame rechnen
setInterval(() => {
  Module._doomgeneric_Tick();   // ← hier laufen 35k Zeilen C-Code
  // Module._doomgeneric_Tick ruft intern DGJS_DrawFrame(...) auf,
  // das unser JS-Code implementiert — so kommt das Bild ins Canvas.
}, 0);
```

### Pixel-Format: warum BGRA und nicht RGBA?

DOOM's interner Pixel-Puffer hat die Reihenfolge **Blau - Gruen - Rot - Alpha**
(historische Gruende aus der Windows-GDI-API von 1993). Ein HTML-Canvas will
aber **Rot - Gruen - Blau - Alpha**. Darum vertauscht unser `DGJS_DrawFrame`
Callback Byte 0 und Byte 2:

```javascript
for (let i = 0; i < pixelCount * 4; i += 4) {
  canvas[i]     = framebuffer[i + 2]; // R <- B
  canvas[i + 1] = framebuffer[i + 1]; // G = G
  canvas[i + 2] = framebuffer[i];     // B <- R
  canvas[i + 3] = 255;                // A immer voll
}
```

Das sind ~256 000 Byte-Swaps pro Frame. Klingt viel, laeuft aber auf einer
modernen CPU in unter einer Millisekunde.

---

## Gesamtbild

```
┌────────────────────────────────────────────────────────────────┐
│                          BROWSER                                │
│                                                                 │
│   ┌─────────────────────────────┐                               │
│   │  index.html                 │ ← UI, Startbildschirm, Canvas │
│   └───────────┬─────────────────┘                               │
│               │                                                 │
│   ┌───────────▼─────────────────┐                               │
│   │  boot.js                    │ ← Glue-Code                   │
│   │  - WAD-Download             │                               │
│   │  - DGJS_* Callbacks         │                               │
│   │  - Keyboard, Mouse, Audio   │                               │
│   └───────────┬─────────────────┘                               │
│               │                                                 │
│   ┌───────────▼─────────────────┐                               │
│   │  engine.js                  │ ← DOOM-Engine (asm.js)        │
│   │  = doomgeneric (C)          │   Emscripten-Build            │
│   │  + Module.HEAPU8 (16 MB)    │                               │
│   │  + FS (virtuelles Filesys)  │                               │
│   └───────────┬─────────────────┘                               │
│               │                                                 │
│               │ liest                                           │
│   ┌───────────▼─────────────────┐                               │
│   │  freedoom1.wad  (29 MB)     │ ← Assets                      │
│   └─────────────────────────────┘                               │
│                                                                 │
└────────────────────────────────────────────────────────────────┘
```

---

## Was ist der Unterschied zu unserer frueheren Version?

Die alte `projects/Gaming/Doom/` (jetzt in `archiv/v3-raycaster-proceduralgen/`)
war ein **handgeschriebener Raycaster** — ein Versuch, DOOM "nachzubauen":

| Aspekt             | Alter Raycaster (v3) | Neue WASM-Version          |
|--------------------|----------------------|----------------------------|
| Engine             | 80 KB JavaScript     | 3 MB asm.js (C kompiliert) |
| Levels             | prozedural generiert | echte DOOM-Leveldaten      |
| Sprites            | per Code gemalt      | echte Sprite-Grafiken      |
| Sounds             | keine                | 110+ echte Soundeffekte    |
| Musik              | keine                | echte MIDI-Songs           |
| Kollisionserkennung | vereinfacht         | BSP-Tree (original DOOM)   |
| Aussehen           | "Doom-inspiriert"    | nicht vom Original zu unterscheiden |

**Lektion:** Ein grosses Spiel "nachzuschreiben" ist faktisch unmoeglich.
Der praktikable Weg: Die originale Engine nutzen (GPL) und nur die Daten
ersetzen (FreeDoom).

---

## Lizenz-Aspekte (wichtig!)

Aus [[LL-027|LL-027 Lizenzen vor Code pruefen]]: Bei externen
Quellen IMMER zuerst die Lizenz pruefen.

| Komponente     | Lizenz        | Kommerziell erlaubt? |
|----------------|---------------|-----------------------|
| DOOM-Engine    | GPL v2        | Ja, aber Quellcode muss offen bleiben |
| doomgeneric    | GPL v2        | Ja, dito              |
| FreeDoom WAD   | BSD           | **Ja, ohne Einschraenkungen** |
| MIDI-Player    | MIT           | Ja                    |

**Fuer Sanexio/Juvantis heisst das:** Diese DOOM-Version duerfte man sogar auf
einer kommerziellen Website einsetzen — solange der Quellcode der Engine offen
bleibt (GPL). Fuer das reine Hobby-Projekt auf dem Home-Mac irrelevant.

---

## Workflows

- [[01-doom-im-browser_claude|Claude-Workflow]] — so laesst Du Claude das Projekt
  aufsetzen, updaten oder anpassen
- [[01-doom-im-browser_manuell|Manueller Workflow]] — so baust Du es Schritt fuer
  Schritt selbst nach

---

## Was hast Du jetzt gelernt?

- **asm.js / WebAssembly**: Alte C-Programme koennen im Browser laufen, indem man
  sie mit Emscripten "uebersetzt". Der Code ist dann JavaScript, aber ein sehr
  spezielles, fast so schnelles wie natives C.
- **Emscripten-Module**: Das globale `Module`-Objekt ist der Kontaktpunkt
  zwischen Browser und C-Code. `HEAPU8` ist der C-Speicher, `FS` ist ein
  virtuelles Dateisystem.
- **DOOM-Architektur**: DOOM trennt seit 1993 zwischen Engine (Code) und WAD
  (Daten). Deshalb kann man die Daten austauschen (FreeDoom), ohne den Code
  anzufassen.
- **Lizenz-Schichten**: Ein Projekt kann aus Komponenten mit verschiedenen
  Lizenzen (GPL + BSD + MIT) bestehen. Die strengste Lizenz gewinnt — in unserem
  Fall GPL fuer den Engine-Teil.

---

## Weiterfuehrende Konzepte

- [[30 Tutorials/Terminal/03-npm-node|NPM und Node.js]] — wie moderne Web-Builds entstehen
- Warum kompiliert Emscripten nach asm.js / WASM? → `Second Brain/50 Wissen/WebAssembly.md` (TODO)
- DOOM-Leveldesign und das BSP-Konzept → [[Proxmox Grundlagen|spaeter mal]]

---

*Version: 1.0 · Erstellt 2026-04-17*
