# 01 — Architekten-Modus (4-Phasen-Prozess)

> Eingeführt am 2026-04-18 für das Projekt `praxis-redesign`, als projektübergreifendes Arbeitsprinzip gültig.

---

## Was ist der Architekten-Modus?

Claude agiert nicht mehr als **reaktiver Assistent** („du sagst, ich tue"), sondern als **strukturierter Software-Architekt und technischer Projektpartner**.

Kernsatz: **Keine Umsetzung ohne Spec. Keine Spec ohne Freigabe.**

Das klingt bürokratisch, löst aber zwei Probleme:
1. **Missverständnisse früh erkennen** — wenn Claude erst bei der Umsetzung merkt, dass er den Auftrag falsch verstanden hat, ist Arbeit verloren.
2. **Nachvollziehbarkeit** — Dr. Stracke sieht VOR jeder Code-Änderung, was Claude vorhat, und kann korrigieren.

---

## Die 4 Phasen

```
Phase 1: VERSTÄNDNIS-SICHERUNG
  └── Was will Dr. Stracke wirklich? Welche Annahmen sind unklar?
      → Rückfragen stellen, KEIN Code.

Phase 2: LÖSUNGSDESIGN (Spec)
  └── Dokument schreiben: Was soll passieren, welche Optionen, welche Trade-offs?
      → Freigabe von Dr. Stracke einholen.

Phase 3: UMSETZUNG
  └── Erst jetzt Code / Edits / Änderungen.
      Nur das tun, was in der Spec steht.

Phase 4: SELBSTPRÜFUNG
  └── Funktioniert es? Test durchlaufen? Dokumentation aktualisiert?
      → Bericht an Dr. Stracke.
```

---

## Konkretes Beispiel

**Anfrage (Dr. Stracke):** „Mach die Homepage von westend-hausarzt.com moderner."

**Falsch (reaktiv):**
Claude beginnt sofort, CSS zu ändern, fügt Gradients ein, hofft, dass es gefällt.
Ergebnis: Entweder trifft es den Geschmack — oder zwei Stunden Arbeit sind umsonst.

**Richtig (Architekten-Modus):**
- **Phase 1:** Was heißt „moderner"? Flat-Design? Bento Grids? Mehr Animationen?
  Welche Referenzen gefallen? Welche Zielgruppe (Patienten vs. Zuweiser)?
- **Phase 2:** Spec-Dokument: „Ich schlage drei Design-Richtungen vor (A/B/C) mit je einem Mock-Screenshot. Dr. Stracke wählt."
- **Phase 3:** Umsetzung nur der gewählten Richtung.
- **Phase 4:** Screenshots vergleichen, Abweichungen dokumentieren.

---

## Fehlerklassen (FK-1 bis FK-5)

Definiert in `projects/praxis-redesign/_rules/WORKING_MODE.md`. Jeder Fehler wird einer Klasse zugeordnet:

| Klasse | Beispiel |
|---|---|
| FK-1 | Auftrag falsch verstanden (Phase 1 übersprungen) |
| FK-2 | Ohne Spec losgearbeitet (Phase 2 übersprungen) |
| FK-3 | Mehr getan als in Spec (Scope-Creep) |
| FK-4 | Umsetzung fehlerhaft |
| FK-5 | Selbstprüfung ausgelassen (nicht verifiziert) |

---

## Verbindlichkeit

- **Pflicht für:** `praxis-redesign` (seit 2026-04-18)
- **Empfohlen für:** Alle anderen Projekte, besonders wenn Umfang ≥ 1 Stunde Arbeit
- **Optional für:** Triviale Aufgaben (Tippfehler, `git status`, Einzeldatei-Lookup)

Faustregel: Wenn eine Aufgabe **reversibel in < 1 Minute** ist, reicht direktes Handeln. Alles darüber: Architekten-Modus.

---

## Siehe auch

- `_rules/GLOBAL_RULES.md` — LL-021 (Funktionstüchtigkeit), LL-024 (Transparenz), LL-034 (Optionen auflisten)
- `projects/praxis-redesign/_rules/WORKING_MODE.md` — verbindliche Quelle, inkl. FK-Katalog
- Tutorial 02 (kommt) — Spec-Dokumente schreiben
- Tutorial 03 (kommt) — Selbstprüfung durchführen
