# 02 — Selbstregulierende Memory-Systeme

**Warum:** Memory-Dateien (Index-Dokumente, Session-Resumes, Project-READMEs) wachsen linear mit jeder Session. Niemand löscht proaktiv. Irgendwann sprengt die Pflicht-Init das Read-Limit und Claude kann den eigenen Kontext nicht mehr einlesen. Passiert in Session 22 (Cortex-Web, 120 k Tokens). V4-Kur brachte 240 KB auf 78 KB; V5 macht den Mechanismus dauerhaft.

## Das Grundproblem

Drei Wachstums-Mechanismen:

1. **Session-Logs in Indices** — Jede Session append't einen „Vorher: Session X …" Absatz in die Aktive-Projekte-Tabelle. Nach 15 Sessions ist eine Tabellenzelle 15 KB groß.
2. **§3-legacy-Stapel in SESSION_RESUME** — Jeder Session-Ende-Workflow hinterlässt einen Legacy-Block. Sie stapeln sich.
3. **Sprint-Logs in CLAUDE.md** — Projekt-Abschnitte wachsen mit jeder Sprint-Session.

Alle drei sind **dokumentarisch sinnvoll, aber im falschen Ort**. Sie gehören in ein Archiv, nicht in die Pflicht-Lese-Datei.

## Die drei Rettungs-Prinzipien

### Prinzip 1: Index vs. Speicher

Trenne zwei Rollen strikt:
- **Index-Datei** (MEMORY.md): zeigt WAS wo liegt, max 1-3 Zeilen pro Projekt, 10 k Token-Budget.
- **Speicher-Datei** (SESSION_RESUME.md): aktueller Stand des Projekts, max 15 k Tokens, nur jüngste Session live.
- **Archiv-Ordner**: alles ältere, git-tracked aber NICHT in Pflicht-Init geladen.

### Prinzip 2: Retention-1

SESSION_RESUME.md hält IMMER nur die letzte Session als §3. Alles ältere wird in `_archive/sessions/YYYY-MM/session-XX-thema.md` verschoben. §7 Archive-Index-Tabelle verweist darauf.

### Prinzip 3: Auto-Enforcement

Ohne automatische Durchsetzung verrottet jedes Prinzip. Daher: Bei jedem „Session beenden" läuft `cortex-sanitizer --probe`; bei Hard-Warn automatisch `--apply`; immer `--learn` für Trend-Daten.

## Werkzeug: cortex-sanitizer

Liegt unter `Nexus/tools/cortex-sanitizer/` — projekt-übergreifend, Git-synct, auf allen Geräten verfügbar.

```
cortex-sanitizer/
├── rotate.sh            Dispatcher
├── probes/
│   ├── growth-log.sh    JSONL-Append bei jedem Run
│   ├── redundancy-scan  Paragraphen-Duplikate
│   └── stale-ref-scan   tote Pfad-Links
├── actions/
│   └── rotate-session-resume.sh   Auto-Rotation
└── logs/
    ├── growth.jsonl     Trend-Historie
    └── reports/         Redundanz- und Stale-Ref-Reports
```

## Modi

| Modus | Wann | Exit |
|---|---|---|
| `--probe` | Routinecheck | 0 = ok, 1 = Hard-Warn |
| `--plan` | Report + Vorschläge | wie probe |
| `--apply` | Auto-Rotation | 0 = rotiert/nichts zu tun |
| `--learn` | alle Probes + Trend-Log | 0 = immer |

## Token-Budgets (LL-044)

| Datei | Soft | Hard-Warn |
|---|---:|---:|
| `<projekt>/SESSION_RESUME.md` | 15 k | 20 k |
| `Nexus/_memory/MEMORY.md` | 10 k | 15 k |
| `Nexus/CLAUDE.md` | 12 k | 18 k |
| `Nexus/_rules/GLOBAL_RULES.md` | 12 k | 18 k |

## Der Git-Trick mit `_archive/`

Wenn der Parent-Ordner in `.gitignore` steht (`_archive/`), können Kinder **nicht** per `!`-Exception re-included werden. Lösung: Parent als Wildcard ignorieren (`_archive/*`), dann greifen Exceptions.

```gitignore
# Vorher (falsch):
_archive/
!_archive/sessions/      ← greift NICHT

# Nachher (richtig):
/_archive/*
!/_archive/sessions/
!/_archive/sessions/**
sites/*/_archive/        ← Sub-Projekt-Archive bleiben ignoriert
```

## Selbstlern-Komponenten

**Growth-Log (JSONL):** Jeder `--learn`-Run appended pro überwachter Datei eine Zeile mit Zeitstempel, Bytes, Tokens, Status. Über Wochen sichtbar: welche Datei wächst wie schnell.

**Redundanz-Scan:** awk extrahiert Paragraphen ≥ 160 Zeichen, zählt identische Textblöcke. Ausgabe: Top-20 Duplikate mit Fundstellen. Manuell reviewen — keine Auto-Entfernung.

**Stale-Ref-Scan:** grep extrahiert Pfad-Referenzen (`~/Cortex/...`, `projects/...`, `Nexus/...`), testet Existenz, meldet tote Links. False-Positives bei Platzhaltern wie `YYYY-MM-DD` — Review-only.

## Wann nutzen

- Als Mechanismus beim Aufbau neuer Projekte (von Anfang an richtig strukturieren)
- Als Einmal-Kur, wenn Memory-Dateien unübersichtlich wurden
- Als Growth-Monitor für Management-Dashboards (Wachstum = Signal für Strukturänderungsbedarf)

## Lessons Learned

- **Bash 3 kann keine assoziativen Arrays** (macOS default `/bin/bash`) — Inline-Daten-Tabelle mit `|`-Trennzeichen und `while read` nutzen
- **awk + Shell-Command-Substitution ist fragil** — saubere Paragraphen-Extraktion per `RS=""` und newline-replace, dann sort+uniq
- **Auto-Sync in Nexus** (launchd, 5 min) commit't manchmal vor dem manuellen Commit — mit kurzen Task-Läufen einkalkulieren
- **Spec vor Implementierung** zahlt sich bei komplexen Tools aus — klare Akzeptanzkriterien machen Phase-3-Umsetzung zielgerichtet

## Querverweise

- Pattern: `Nexus/_memory/patterns/self-regulating-token-budget.md`
- Spec: `Nexus/tools/cortex-sanitizer/specs/SPEC.md` (V4) + `SPEC-V5.md` (seit 2026-04-24 im Nexus, LL-047)
- Regel: `Nexus/_rules/GLOBAL_RULES.md §21` (LL-044)
- Session-Integration: `Nexus/_rules/SESSION_LIFECYCLE.md §2 Schritt 3b`

---

## 2026-04-28 Evolution — LL-053 Hot/Warm/Cold + Hardgate

Trigger: Cortex-Web `SESSION_RESUME.md` wuchs trotz V5-Sanitizer auf **27 k Read-Tokens** (Session 50). LL-044 war Soft-Warn ohne Mechanismus. LL-053 (Session 51, 2026-04-28) liefert vier neue Mechanismen:

### Drei Schichten statt zwei Rollen

Vorher: Index (MEMORY.md) + Speicher (SESSION_RESUME.md) + Archiv. Jetzt formal:

| Schicht | Was | Cap | Lade-Regel |
|---|---|:---:|---|
| **HOT** | Aktueller Stand, letzte 1–2 Sessions detailliert | 12 k | immer geladen |
| **WARM** | Index aller Sessions (`SESSION_INDEX.md`, neu) | 5 k | beim Sessionstart |
| **COLD** | Detail-Chroniken pro Session in `_archive/sessions/` | unbegrenzt | on-demand (Lazy-Read) |

### Sliding-Window statt Retention-1

`N` (aktuell) und `N-1` (Vortag) bleiben in `§3` detailliert. `N-2` rotiert ins Cold. Bündel-Ausnahme: Wenn N-2 zu einem zusammenhängenden Sprint mit N-3, N-4 etc. gehört (gleicher Tag), gehen sie als Bündel ins Cold (z. B. `sessions-43-46-catch-up.md` für 4 Sessions an einem Sonntag).

### Hardgate statt Soft-Apply

`rotate.sh --enforce` (V5.3) wirft **Exit 1 bei Soft-Cap-Verletzung** (nicht erst bei Hard-Warn wie `--probe`). Pflichtige Pre-Commit-Vorbedingung. Der „Session beenden"-Workflow stoppt, bis die Verletzung behoben ist. Der bestehende `--apply`-Modus (V4) bleibt für Auto-Rotation, aber `--enforce` ist die Hardgate.

### Single-Source-Pflicht

Hot-Files dürfen Cold-Inhalte **niemals duplizieren**, nur referenzieren mit Anchor-Links: `_archive/sessions/2026-04/sessions-43-46-catch-up.md#s45`. Anti-Pattern: §1.0-Catch-Up-Tabelle UND §3-legacy-Block für dieselbe Session.

### Cap-Verschärfung

| Datei | Vorher | LL-053 neu |
|---|:---:|:---:|
| `<projekt>/SESSION_RESUME.md` | 15 k | **12 k** |
| `<projekt>/SESSION_INDEX.md` | — | **5 k** (neu) |

### Tooling neu

- `Nexus/tools/cortex-sanitizer/rotate.sh --enforce` (V5.3) — Hardgate
- `Nexus/tools/session-index/build.sh` — generiert WARM-Schicht aus `_archive/sessions/`

### Lifecycle-Integration

Neuer **Schritt 3c** im „Session beenden"-Workflow (LL-042):
1. Sliding-Window-Rotation (N-2 ins Cold)
2. `SESSION_INDEX.md` regenerieren
3. `--enforce` als Hardgate

### SSoT

`Nexus/_rules/MEMORY_LAYERS.md` — vollständige Definition (LL-053a Sliding-Window, LL-053b Hardgate, LL-053c Lazy-Read, LL-053d Single-Source).
Pattern: `Nexus/_memory/patterns/session-archive-sliding-window.md`.

### Pilot-Effekt

Erste Anwendung (Session 51, Cortex-Web): Resume −16,5 % Tokens, GLOBAL_RULES −2,9 %. Drei Cold-Archives mit ~32 KB Detail-Chronik ausgelagert. `--enforce` Exit 0 nach Sweep.
