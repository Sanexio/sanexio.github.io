---
type: tutorial
aliases: [Arbeitsweise, Arbeitsweise & Prozess, Prozess, Architekten-Modus, Zusammenarbeit]
tags:
  - tutorial
  - arbeitsweise
  - prozess
source: Second Brain/30 Tutorials/Arbeitsweise & Prozess/
legacy_path: _tutorials/arbeitsweise-prozess/ (Symlink)
---

# Arbeitsweise & Prozess — Grundlagen

> Quellpfad: `Second Brain/30 Tutorials/Arbeitsweise & Prozess/`
> Diese Domäne ist keine technische Domäne, sondern „**wie** wir zusammen
> arbeiten" — die übergeordneten Denk- und Arbeitsmuster, die Claude und du
> über alle Projekte hinweg nutzen.

> [!info] Lesezeit: 5 Min Übersicht · jede Detail-Seite ~10–15 Min · Voraussetzung: keine

---

## 1. Warum gibt es diese Domäne?

Bei einer einzelnen Aufgabe spielt die Arbeitsweise keine große Rolle. Bei einem
laufenden, jahrelangen Projekt mit vielen Sessions, Geräten und Teilprojekten
**entscheidet die Arbeitsweise, ob das System nutzbar bleibt** oder im Chaos
versinkt.

Die 9 Module dieser Domäne fassen die Lehren zusammen, die in der Cortex-Web-
und Praxis-Webseiten-Arbeit gewachsen sind. **Jedes Modul löst ein konkretes
Problem**, das einmal Reibung erzeugt hat.

| Was passiert ohne diese Disziplin? | Welches Modul greift? |
|---|---|
| Code wird vor dem Verständnis geschrieben → muss wieder weggeworfen werden | **01 — Architekten-Modus** |
| MEMORY.md wächst auf 50 k Token, Sessionstart bricht ab | **02 — Memory-Systeme** |
| Adapter-Patterns werden nochmal neu erfunden statt wiederverwendet | **03/04 — Cross-Site-Adapter** |
| Praxis-Inhalt landet versehentlich auf Juvantis-Seite (HWG-Verstoß!) | **04 — Adapter-Guards** |
| Theme-Files werden überschrieben, Custom-Code geht verloren | **05 — Theme-File-Write** |
| Falsche Aufgabe priorisiert, „dringend" ≠ „wichtig" | **06 — Prio-Leiter** |
| Dr. Stracke schreibt eine Anweisung in den Vault, Claude sieht sie nie | **07 — Vault-Kommunikation** |
| 200 Pages-Migration startet ohne Sortier-System → blockiert | **08 — Content-Triage** |
| Notizen werden geschrieben, niemand findet sie wieder | **09 — Graph-Vernetzung** |
| Jede Session muss Architektur neu erklären | **07 — Lazy-Path-Shortcuts** |

---

## 2. Die 9 Module im Überblick

### 01 — Architekten-Modus
**Verstehen → Lösungsdesign → Umsetzung → Selbstprüfung. Keine Umsetzung ohne Spec.**

Der wichtigste Mode-Switch: Bevor Claude Code anfasst, wird die Aufgabe analysiert,
in eine Spec gegossen, und du gibst frei. Verhindert „schnell mal angefangen, dann
festgefahren". Aktiviert seit 2026-04-18 verbindlich für `praxis-redesign`,
projektübergreifend beachten.

→ [[Arbeitsweise & Prozess/01-architekten-modus|Theorie]] · [[Arbeitsweise & Prozess/01-architekten-modus_claude|Claude-Workflow]] · [[Arbeitsweise & Prozess/01-architekten-modus_manuell|Manuell]]

---

### 02 — Selbstregulierende Memory-Systeme
**Warum MEMORY.md, SESSION_RESUME.md und CLAUDE.md harte Token-Budgets haben.**

Memory-Dateien wachsen, wenn man sie lässt. Irgendwann passt der Sessionstart nicht
mehr ins Read-Limit. Lösung: Budgets (10 k / 15 k / 12 k) + Sanitizer-Tool, das
bei Session-Ende warnt und alte Inhalte ins Archiv rotiert. Spec: `Nexus/tools/cortex-sanitizer/specs/SPEC.md` (V4 + V5).

→ [[Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme|Theorie]]

---

### 03 — Cross-Site-Adapter — Diff-Strategie
**Wie ein gemeinsamer Inhalt (Trunk) zwei sehr unterschiedliche Webseiten füttert.**

Pattern A–F des Cross-Site-Transfer: Der Inhalt wird einmal im Trunk geschrieben,
Adapter rendern ihn für WordPress und Shopify. Diff-Strategie definiert, wie
Änderungen verfolgt werden ohne dass Adapter divergieren.

→ [[Arbeitsweise & Prozess/03-cross-site-adapter-diffs|Theorie]]

---

### 04 — Cross-Site-Adapter — Guards
**Kontrolle, dass Praxis-Inhalt nie auf Juvantis landet (und umgekehrt).**

Praxis-Webseite untersteht HWG, Juvantis nicht. Wenn Adapter den falschen
Inhalt rendert → rechtliches Risiko. Guards sind Code-Garantien, die das
verhindern. Wie [[LL-029]] für Avatar-Morphs (Gesicht NIE deformieren), nur für
Webseiten-Content.

→ [[Arbeitsweise & Prozess/04-cross-site-adapter-guards|Theorie]]

---

### 05 — Adapter-Theme-File-Write — Idempotenz
**Adapter müssen Theme-Files schreiben, ohne andere Änderungen zu zerstören.**

Wenn ein Adapter `style.css` neu schreibt, dürfen manuell hinzugefügte Custom-
Regeln nicht verloren gehen. Lösung: Markierte Blöcke (`/* AUTO-START */ ... /* AUTO-END */`),
die nur innerhalb dieser Marker schreiben, idempotent (mehrfacher Lauf = gleiches
Ergebnis).

→ [[Arbeitsweise & Prozess/05-adapter-theme-file-write|Theorie]]

---

### 06 — Projekt-Prio-Leiter (holistisch)
**P1–P5 system-tragend, Popt/Pios nur bei Pain-Point. Vermeidet Infra-Symmetrie-Drift.**

Eine Sortier-Logik für „was zuerst?". Trennt:
- **P1–P5:** Aufgaben, die das System tragen (Pflicht-Init, Pre-Live-Blocker, Sicherheit, Datenintegrität, Geräte-Verfügbarkeit)
- **Popt:** Optimierungen, nur wenn ein konkreter Pain-Point besteht
- **Pios:** „nice to have" — explizit nicht jetzt

Anwendungsbeispiel: Cortex-Web-Prio-Leiter (CW-PRIO-001).

→ [[Arbeitsweise & Prozess/06-projekt-prio-leiter-holistic|Theorie]]

---

### 07a — Lazy-Path-Shortcuts statt Framework
**Pragmatische Pfad-Abkürzungen schlagen jedes vorgekochte Framework.**

Wenn ein Pattern nur 2× im Projekt vorkommt, baut man kein Framework — man notiert
sich die Pfad-Shortcuts. Erst ab 3+ identischen Stellen wird abstrahiert. Verhindert
Premature Abstraction.

→ [[Arbeitsweise & Prozess/10-lazy-path-shortcuts-statt-framework|Theorie]]

---

### 07b — Vault-Kommunikation
**Wie du Claude über `[!frage]`/`[!anweisung]`-Callouts ansprichst.**

Vault-Dateien sind bidirektionaler Arbeitsraum. Du schreibst eine Frage als Callout
in eine Notiz; das Sync-Skript scannt alle 5 Minuten und sammelt offene Einträge in
`_memory/pending-questions.md` und `pending-instructions.md`. Claude beantwortet
beim nächsten Sessionstart oder beim Befehl „Nexus Anweisungen abarbeiten".

→ [[Arbeitsweise & Prozess/07-vault-kommunikation|Theorie]]

---

### 08 — Content-Archive-Triage
**200-Page-Migrationen handhabbar machen.**

Wenn 189 alte Seiten in eine neue Webseite müssen, ist „eine nach der anderen lesen"
kein Plan. Triage-System: jede Page bekommt einen Status (kept/dropped/merge/rewrite),
landet in einem Inventory-CSV mit MD5-Contract. So kann Claude Cluster-weise
arbeiten und du behältst den Überblick.

Einsatz: Praxis-Webseite Sprint 2 S2.3-D (189 Pages), B-2 Legacy-Triage (S33).

→ [[Arbeitsweise & Prozess/08-content-archive-triage|Theorie]]

---

### 09 — Vault-Graph-Vernetzung
**Wie der Obsidian-Graph echte Domänen-Cluster sichtbar macht statt Sternen.**

Wenn jede Notiz einzeln im Graph steht, hilft der Graph nicht. Lösung: MOC-Auto-
Links (`inject_moc_links.py` in `Nexus/tools/vault-audit/`) verbindet alle Module
mit ihrer Landing-Page → Domänen werden im Graph als Cluster sichtbar.

→ [[Arbeitsweise & Prozess/09-vault-graph-vernetzung|Theorie]]

---

## 3. Empfohlene Lernreihenfolge

Wenn du die ganze Domäne durchgehen willst, in dieser Reihenfolge:

1. **01 — Architekten-Modus** (15 Min) — der wichtigste Mode-Switch, alles andere baut darauf auf
2. **06 — Prio-Leiter** (10 Min) — wie Aufgaben sortiert werden
3. **07b — Vault-Kommunikation** (10 Min) — wie du mit Claude **außerhalb** des Chats redest
4. **02 — Memory-Systeme** (10 Min) — warum MEMORY.md nicht beliebig wachsen darf
5. **08 — Content-Triage** (10 Min) — Migration großer Inhalts-Mengen
6. **03 / 04 / 05 — Cross-Site-Adapter-Trio** (je 10 Min) — nur relevant, wenn dich Cortex-Web-Architektur interessiert
7. **07a — Lazy-Path-Shortcuts** (5 Min) — Anti-Pattern „premature framework"
8. **09 — Graph-Vernetzung** (5 Min) — eher Tooling als Konzept

**Mindest-Set für „verstehe wie wir arbeiten":** Module 01, 06, 07b. Reicht für 80 % der täglichen Sessions.

---

## 4. Wann greifen welche Regeln aus [[GLOBAL_RULES]]?

Diese Domäne ist die **konzeptuelle Heimat** vieler globaler Regeln:

| LL | Regel | Modul |
|---|---|---|
| **LL-021** | Implementierung = funktionstüchtig (Delivery-Checkliste) | 01 — Architekten-Modus |
| **LL-022** | Tutorials proaktiv ergänzen | 09 — Graph-Vernetzung |
| **LL-023** | Session-Start: MEMORY.md + GLOBAL_RULES.md zuerst lesen | 02 — Memory-Systeme |
| **LL-024** | Transparente Kommunikation (WAS / WARUM / WAS BEDEUTET DAS) | 01 — Architekten-Modus |
| **LL-034** | Optionen auflisten statt Empfehlung | 06 — Prio-Leiter |
| **LL-041** | Tutorial-Hierarchie selbständig gestalten | 09 — Graph-Vernetzung |
| **LL-042** | „Session beenden" = 6-Schritte-Workflow | 02 — Memory-Systeme |
| **LL-043** | „Projekt fortsetzen" = Standard-Einstieg | 02 — Memory-Systeme |
| **LL-044** | Token-Budgets für Memory-Dateien | 02 — Memory-Systeme |
| **LL-045** | Vault-Kommunikation per Callouts | 07b — Vault-Kommunikation |
| **LL-046** | Umlaute im Vault-Inhalt, ASCII in Dateinamen | — |
| **LL-047** | Verortungsregel „Ein Artefakt, ein Ort" | — |
| **LL-048** | Projekt-Übersicht + Telegram-Modus bei Session-Start | — |
| **LL-049** | Sync-Hygiene + Pre-Session-Pull | — |

---

## 5. Wann diese Domäne erweitern?

- Wenn aus der Praxis ein neues, wiederholbares Arbeitsmuster entsteht (nach 3+
  Anwendungen) → eigenes Modul
- Wenn eine LL-Regel erklärungsbedürftig genug ist, dass eine Tutorial-Seite
  helfen würde → Querverweis im passenden Modul oder neues Modul
- Wenn Claude eine Aufgabe wiederholt schief macht und eine neue Regel
  abgeleitet wird → Tutorial nachziehen

Die Domäne wächst **organisch** mit den Lessons Learned, nicht nach Plan ([[LL-035]]).

---

## Verwandte Notizen

- [[_MOC Tutorials]] — Dach-MOC aller Tutorials
- [[_Basiswissen Schnelleinstieg]] — Pfad D („Wie wir zusammenarbeiten")
- [[_MOC Regeln]] — alle LL-Regeln
- [[Cortex-Web]] — Projekt, in dem viele dieser Patterns gewachsen sind
- [[praxis-webseite]] — Architekten-Modus seit 2026-04-18


<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

- [[30 Tutorials/Arbeitsweise & Prozess/01-architekten-modus|01-architekten-modus]] · [[30 Tutorials/Arbeitsweise & Prozess/01-architekten-modus_claude|Claude]] · [[30 Tutorials/Arbeitsweise & Prozess/01-architekten-modus_manuell|Manuell]]
- [[30 Tutorials/Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme|02-selbstregulierende-memory-systeme]]
- [[30 Tutorials/Arbeitsweise & Prozess/03-cross-site-adapter-diffs|03-cross-site-adapter-diffs]]
- [[30 Tutorials/Arbeitsweise & Prozess/04-cross-site-adapter-guards|04-cross-site-adapter-guards]]
- [[30 Tutorials/Arbeitsweise & Prozess/05-adapter-theme-file-write|05-adapter-theme-file-write]]
- [[30 Tutorials/Arbeitsweise & Prozess/06-projekt-prio-leiter-holistic|06-projekt-prio-leiter-holistic]]
- [[30 Tutorials/Arbeitsweise & Prozess/07-vault-kommunikation|07-vault-kommunikation]]
- [[30 Tutorials/Arbeitsweise & Prozess/08-content-archive-triage|08-content-archive-triage]]
- [[30 Tutorials/Arbeitsweise & Prozess/09-vault-graph-vernetzung|09-vault-graph-vernetzung]]
- [[30 Tutorials/Arbeitsweise & Prozess/10-lazy-path-shortcuts-statt-framework|10-lazy-path-shortcuts-statt-framework]]

<!-- /auto-moc-links -->
