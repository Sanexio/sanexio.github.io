---
type: tutorial
id: 09-vault-graph-vernetzung
aliases: [Vault-Graph, Graph-Vernetzung, Obsidian-Graph]
tags:
  - tutorial
  - vault
  - obsidian
  - arbeitsweise
---

# 09 — Vault-Graph-Vernetzung

> **Ziel:** Verstehen, warum der Obsidian-Graph zerfallen aussieht, und wie man
> ihn so pflegt, dass er ein einziger zusammenhängender Wissenskern bleibt.

## Was zeigt der Graph eigentlich?

Obsidian rendert den Graph aus drei Bestandteilen:

1. **Echte `.md`-Dateien** im Vault (Knoten).
2. **Wiki-Links** `[[Ziel]]` zwischen Dateien (Kanten).
3. **Optional:** unaufgelöste Wiki-Links als graue Phantom-Knoten und
   verwaiste Dateien — abhängig von `graph.json`-Einstellungen.

Wenn der Graph in viele kleine Inseln zerfällt, gibt es vier mögliche
Ursachen — alle vier können gleichzeitig auftreten:

## Ursache 1: echte Orphans

Eine `.md`-Datei hat **keinen einzigen Wiki-Link** rein oder raus. Sie
existiert im Vault, taucht aber im Graph als isolierter Punkt auf.

**Häufigste Quelle:** TUT-001-Drei-Dateien-Pakete (`XX-thema.md`,
`_claude.md`, `_manuell.md`), die nie in einer Domain-Landing-Page
verlinkt wurden. Auch Session-Logs, die nur per Dateipfad referenziert
werden, nicht per Wiki-Link.

**Fix:** Eine **Map of Content (MOC)** für die Domäne anlegen oder
ergänzen, die alle Dateien per Wiki-Link aufzählt.

## Ursache 2: Phantom-Links

Eine Datei enthält einen Wiki-Link wie `[[Foo]]`, aber keine Datei mit Stem `Foo.md`
existiert im Vault. Obsidian zeichnet einen grauen Phantom-Knoten.

**Häufigste Quellen:**
- Tippfehler oder Schreibvariante (`Claude-OS Übersicht` vs.
  `Claude-OS Uebersicht.md`).
- Wiki-Link auf eine Datei **außerhalb** des Vaults
  (z. B. `[[GLOBAL_RULES]]` zeigt auf `Nexus/_rules/GLOBAL_RULES.md`).
- Relative Pfade `[[../Proxmox]]` — Obsidian löst die nicht zuverlässig
  auf.

**Fixes:**
- Tippfehler: Linkziel korrigieren.
- Externe Datei: Im Vault eine **Pointer-Notiz** anlegen, die kurz
  erklärt + auf den externen Pfad verweist.
- Relative Pfade: durch absolute Wiki-Links mit Vault-relativem Pfad
  ersetzen, z. B. `[[30 Tutorials/Terminal/03-npm-node]]`.

## Ursache 3: Duplikat-Stems

Mehrere `.md`-Dateien tragen denselben Namen (z. B. `01-grundlagen.md`
existiert in `Terminal/`, `iOS/`, `Proxmox/` …). `[[01-grundlagen]]`
löst dann uneindeutig auf. Obsidian wählt eine, der Rest bleibt
unverlinkt.

**Fix:** Wiki-Links **immer mit Pfad-Präfix** schreiben:
`[[Terminal/01-grundlagen]]`, `[[Proxmox/01-grundlagen]]`. Dateinamen
selbst nicht umbenennen — das würde alte Pfad-Referenzen brechen.

## Ursache 4: getrennte Subgraphen ohne Brücke

Zwei Bereiche sind in sich gut vernetzt, hängen aber nicht zusammen
(z. B. Juvantis-Cluster und Praxis-Cluster). Im Graph sind das zwei
parallele Universen.

**Fix:** In den Projekt-/Workflow-Notizen einen Block
`## Verwandte Notizen` mit Wiki-Links auf Schwester-Projekte und
gemeinsame MOCs. **Nicht künstlich verbinden** — nur wo echte Bezüge
bestehen.

## Werkzeug: vault-audit

Im Cortex liegt das Tool `Nexus/tools/vault-audit/` mit drei Skripten:

```bash
# 1. Audit lesen — zeigt Orphans, Phantoms, Connected Components
python3 Nexus/tools/vault-audit/vault_audit.py

# 2. Tutorial-Landings vernetzen (idempotent)
python3 Nexus/tools/vault-audit/inject_moc_links.py

# 3. Session-Logs mit Kontext-Block versehen (idempotent)
python3 Nexus/tools/vault-audit/inject_session_context.py
```

Die Inject-Skripte arbeiten über das Pattern
`idempotent-auto-block-via-marker` (in `Nexus/_memory/patterns/`) — jeder Lauf liefert denselben
Endzustand, unabhängig davon, ob der Block schon existiert.

## Erfolgsmetriken

| Metrik | Guter Wert | Warnsignal |
|---|---|---|
| Echte Orphans | < 5 % aller Dateien | > 20 % → MOC-Revision |
| Connected Components | 1–3 | > 10 → Graph zerfallen |
| Größter Cluster | > 80 % aller Dateien | < 50 % → strukturell tot |
| Phantom-Link-Ziele | < 10 unique | > 30 → Link-Pflege nötig |

Erste Pflege-Session am 2026-04-25 hat den Cortex-Vault von **127
Orphans / 129 Komponenten / 56 % Hauptcluster** auf **0 / 1 / 100 %**
gebracht.

## Empfohlene `graph.json`-Einstellungen

```json
{
  "hideUnresolved": true,
  "showOrphans": false
}
```

Beides auf `true`/`false` zu setzen, bevor der Vault sauber ist, würde
echte Probleme **verstecken**. Erst aufräumen, dann Filter aktivieren —
ab da fallen neue Orphans/Phantoms sofort auf.

## Verwandte Notizen

- [[Arbeitsweise Grundlagen]] — Domäne
- `idempotent-auto-block-via-marker` (in `Nexus/_memory/patterns/`) — Pattern für die Inject-Skripte
- [[02-selbstregulierende-memory-systeme]] — Schwester-Pattern
- [[LL-047]] — Tool-Verortung im Nexus
- [[_MOC Tutorials]]
