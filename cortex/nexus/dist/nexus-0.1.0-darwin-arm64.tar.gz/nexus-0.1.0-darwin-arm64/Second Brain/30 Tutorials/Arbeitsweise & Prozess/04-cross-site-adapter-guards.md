# 04 — Cross-Site-Adapter-Guards (Pre-Write-Classification)

**Kontext:** Cortex-Web, Session 27 (2026-04-23), Task N-8
**Related:** Tutorial 03 (cross-site-adapter-diffs), Pattern `adapter-pattern-classification-guard.md`

---

## Worum geht es

Wenn Sie einen Adapter bauen, der aus dem Trunk etwas in eine Live-Site schreibt
(Shopify-Page, WordPress-Page, Theme-Asset, Produkt), besteht das meiste
Design-Denken nicht darin, wie man erfolgreich schreibt — das ist Mechanik.
Der anspruchsvolle Teil ist: **was soll beim Schreiben NICHT passieren?**

Ein blinder `PUT /pages/<id>.json` ist idempotent gegen sich selbst (zweimal
derselbe Payload = gleicher Live-Zustand), aber er ist **nicht** idempotent
gegen strukturelle Verschiebungen der Live-Seite. Wenn jemand im Shopify-Admin
die Seite auf ein Theme-Template umgestellt hat (Pattern B), überschreibt ein
Trunk-Push die Page wieder in Pattern A zurück. Das Backup sichert zwar die
Daten, aber das Theme-Binding geht verloren — und der Operator sieht das erst
im Browser.

Dieses Tutorial zeigt drei zusammenhängende Konzepte, die solche Fehler
abfangen, **bevor** sie passieren.

---

## Konzept 1 — Diskriminator-Felder im Lookup

Wenn der Adapter ohnehin einen Lookup macht (`GET /pages.json?handle=…`),
dann kann er in derselben Anfrage **Klassifizierungs-Felder** mitabfragen.
Shopify REST erlaubt `fields=id,handle,...` — jedes zusätzliche Feld kostet
nichts extra.

```js
// Vorher
lookup = await client.get(`/pages.json?handle=${h}&fields=id,handle,published_at,title,updated_at`);

// Nachher
lookup = await client.get(`/pages.json?handle=${h}&fields=id,handle,published_at,title,updated_at,template_suffix`);
```

Das zusätzliche Feld `template_suffix` erlaubt die Unterscheidung:

- `null` / `""` → Pattern A (body_html trägt den Inhalt)
- `"uber-uns"` (oder anderer Wert) → Pattern B (Theme rendert aus Template-Asset)

Merksatz: **Der Lookup ist nicht nur ein Existenz-Check, sondern eine
Klassifikations-Gelegenheit. Nutzen Sie sie.**

---

## Konzept 2 — Guard-Reihenfolge grob-vor-fein

Sie haben vier Arten von Guards beim Update-Pfad:

```
1. Payload-Sanity     (Trunk hat gültigen Inhalt)
2. Lookup             (Live existiert, welche Klasse?)
3. Pattern-Guard      (Live-Klasse ↔ Trunk-Klasse)      ← grob
4. Publish-Guard      (ist Live publiziert?)            ← fein
5. Backup             (CW-008)
6. Write (POST/PUT)
```

Die Reihenfolge ist nicht beliebig. Die Pattern-Konversion B → A ist **strukturell
gröber** als ein Publish-Overwrite. Wenn beide Guards anschlagen würden, soll
der grobere zuerst melden — weil er den Operator zu einer anderen Entscheidung
zwingt (soll ich wirklich konvertieren?) als der feinere (soll ich wirklich eine
live-published Seite überschreiben?).

**Praktisch:** Der Pattern-Guard-Block wird vor dem Publish-Block im
`else if (pages.length === 1)`-Zweig platziert. Code-seitig zehn Zeilen, dafür
sieht der Operator Pattern-Probleme, auch wenn die Page unpublished wäre.

---

## Konzept 3 — Opt-In-Override statt Default-Silent

Wenn der Guard ausgelöst hat, muss der Operator ihn explizit überschreiben
können — aber **nie** still. Das Muster:

```js
const allowPatternOverride = process.env.ALLOW_PATTERN_OVERRIDE === "1";
// ...
if (isPatternB && !allowPatternOverride) {
  die(2, `target page ... is Pattern B (template_suffix="${liveTemplateSuffix}") ` +
         `— a Pattern-A push would discard the theme binding. ` +
         `Set ALLOW_PATTERN_OVERRIDE=1 to proceed.`);
}
```

Drei Design-Entscheidungen:

1. **Env-Variable, kein CLI-Arg.** Env-Flags müssen aktiv geschrieben werden
   (`ALLOW_PATTERN_OVERRIDE=1 bash …`), ein versehentliches Setzen ist
   unwahrscheinlich. CLI-Args können leicht durch History-Recall oder
   Copy-Paste mitwandern.
2. **Default = verweigern.** Der Guard ist immer aktiv. Kein globaler
   „Strict-Mode" — es gibt nur den Ausnahme-Flag.
3. **Error-Message nennt Flag wörtlich.** Nicht „refuse pattern override" —
   sondern `Set ALLOW_PATTERN_OVERRIDE=1 to proceed`. Der Operator muss nicht
   rätseln, welche Flag gemeint ist. Das spart 5 Minuten beim Freitag-Abend-Rollout.

---

## Wann NICHT machen

- Wenn die Live-Seite **immer** in derselben Pattern-Klasse ist (z.B. alle
  Produkte sind strukturell gleich): Pattern-Guard ist Ballast.
- Wenn der Adapter **nur erzeugen**, nie **updaten** kann: kein Pattern-Drift
  möglich (es gibt keinen Live-Vorgänger).
- Bei **Metafield-Writes**: Metafelder kollidieren nicht strukturell, sie
  koexistieren. Dort ist der Guard-Typ anders (Namespace-Konflikt vermeiden).

---

## Zusammenhang mit Tutorial 03 (Adapter-Diffs)

Die drei Konzepte aus Tutorial 03 (Build-then-Fetch-then-Diff als read-only
Drift-Detektor) und die drei aus Tutorial 04 (Guards als write-time Drift-Blocker)
sind zwei Seiten desselben Denkens:

| | Tutorial 03 | Tutorial 04 |
|---|---|---|
| Wann | **Vor** dem Push | **Während** des Push |
| Wie | read-only (2× GET) | 1× GET + Guard, dann PUT/Abort |
| Wer löst aus | Operator, explizit | Adapter, automatisch |
| Ausgabe | Text-/JSON-Report | Exit 2 + klare Message |

In der Praxis: Sie laufen `cw-transfer diff` erst, sehen den Drift, entscheiden
„doch nicht pushen" oder „bewusst konvertieren". Wenn Sie es vergessen und
direkt pushen, greift Tutorial-04-Logik und hält Sie zurück. **Zwei unabhängige
Sicherheitsebenen, beide aus demselben Lookup-Feld gespeist.**

---

## Wenn Sie einen neuen Adapter bauen

Vier Fragen zum Start:

1. Welche **Diskriminator-Felder** unterscheiden die Pattern meines Ziel-Objekts?
2. Bekomme ich sie **kostenlos im Lookup** (zusätzlicher `fields=`-Parameter)?
3. Welches ist die **gröbste Aktion**, die mein Adapter schiefgehen lassen kann?
   (Das wird der erste Guard.)
4. Wie **overridbar** soll der Guard sein? (Env-Flag, kein Default-on.)

Wenn Sie diese vier Fragen haben, ist der Guard in ~15 Zeilen gebaut. Das
Tutorial-04-Konzept ist also kein Architektur-Eingriff — es ist ein
**Design-Reflex**.

---

## Referenzen

- Code: `adapters/shopify/pages-to-shopify.mjs` Zeilen 120–131 (Guard-Block)
- Spec: `specs/cross-site-transfer/N-8_pattern-a-vs-b-guard.md`
- Pattern: `Nexus/_memory/patterns/adapter-pattern-classification-guard.md`
- Tutorial 03 (Adapter-Diffs): `Second Brain/30 Tutorials/Arbeitsweise & Prozess/03-cross-site-adapter-diffs.md`
- Tutorial 01 (Architekten-Modus): gleicher Ordner
