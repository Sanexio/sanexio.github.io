# 05 — Adapter, die Theme-Dateien schreiben (Pattern B reverse)

**Kurz:** Manche Cross-Site-Adapter schreiben ihre Payload nicht in eine
API, sondern direkt ins Theme-Dateisystem. Das ist der richtige Weg, wenn
die Ziel-Plattform keine saubere Daten-API für den gewünschten Inhalt hat,
oder wenn die Daten vom Theme-Rendering gelesen werden müssen. Dieses
Tutorial erklärt, wie man so einen Adapter baut — am konkreten Beispiel
N-1 (Cortex-Web, 2026-04-23).

**Gelernt in:** Cortex-Web Session 29, Front N-1 `wp:template` (team data
für `/team/`). Pattern-Kandidat: `wp-theme-data-json` in
`Nexus/_memory/patterns/`.

---

## Wann gilt dieser Weg?

Es gibt zwei grundsätzliche Arten, Daten in eine Ziel-Plattform zu bringen:

| Weg | Wann | Beispiel |
|---|---|---|
| **Daten-API** (REST, GraphQL) | Plattform hat sauberes Endpoint für den Inhaltstyp | Shopify-Product (`POST /products.json`), WP-Page (`POST /wp/v2/pages`) |
| **Theme-File-Write** | Daten werden vom Theme-Layer konsumiert, keine API existiert (oder die API-Route ist zu grobkörnig) | Shopify-Template-Asset (`PUT /themes/.../assets.json`), WP-Inc-Data (Filesystem fs.writeFile) |

Theme-File-Write ist **Pattern B** aus `Cortex-Web/specs/cross-site-transfer/PATTERNS.md`.

## Typische Symptome, die auf Theme-File-Write zeigen

- Das Theme hat ein hardcoded PHP-Array (`$team_members = [...]`) oder ein
  Shopify-Section-Liquid mit langer Blockliste.
- Das Trunk-YAML-Set existiert schon (z.B. aus einer Subsumption).
- Es gibt keinen vernünftigen API-Endpoint, der „schreibe mir 8 Team-
  Mitglieder am Stück" kann (oder er ist zu grob, z.B. Post-Meta als ein
  einziges großes Feld).
- Der Konsumenten-Code im Theme sollte nicht umgeschrieben werden.

## Die 5 Bausteine

Jeder Theme-File-Write-Adapter hat dieselbe Struktur, egal ob Shopify
oder WP:

1. **Build-Step** — liest Trunk, validiert gegen Schema (AJV), rendert
   Payload-JSON. Output: `{ asset: { path, value }, meta: {…} }`.
2. **Push-Step** — liest Payload von stdin, sichert Vorversion (CW-008),
   schreibt neue Datei.
3. **Backup-Guard** — `.backups/<timestamp>_<key>` BEVOR der neue Inhalt
   geschrieben wird. Ohne erfolgreiches Backup kein Write.
4. **Stable Serialization** — JSON mit sorted keys + 2-space indent +
   trailing newline. Garantiert diffbare Artefakte.
5. **Orchestrator** — `sync-<entity>-<target>.sh` als Shell-Shortcut
   (build | push), typisch 30 Zeilen.

Beides (Shopify + WP) teilt alle 5 Bausteine. Der Unterschied steckt nur
in Schritt 2: Shopify macht `PUT /themes/.../assets.json`, WP macht
`fs.writeFile(themePath/asset.path)`.

## Filesystem-Safety (der WP-Teil, den Shopify nicht hat)

Wenn der Push-Step direkt ins Filesystem schreibt, brauchst du **zwei
zusätzliche Safeguards**, die bei REST nicht nötig sind:

```js
// 1. asset.path darf nicht aus dem Theme-Root entkommen
const assetRel = payload.asset.path.replace(/^\/+/, "");
if (assetRel.includes("..") || assetRel.startsWith("/")) {
  die(1, `unsafe asset.path: ${payload.asset.path}`);
}

// 2. Resolved target must stay inside theme root
const targetPath = resolve(themePath, assetRel);
if (!targetPath.startsWith(resolve(themePath) + "/")) {
  die(1, `resolved target escapes theme root`);
}
```

Ohne diese Checks könnte ein Angreifer mit einer vergifteten Payload
außerhalb des Theme-Ordners schreiben. Bei REST kann das die Plattform
ausschließen, bei Filesystem-Adaptern bist du selbst dafür verantwortlich.

## Theme-Patch: JSON-first + Inline-Fallback

Der einzige "invasive" Schritt: das Theme muss die neue Datei lesen statt
des hardcoded Arrays. Rezept (generisch):

```php
function <fn>_from_json() {
    static $cache = null;
    if ( $cache !== null ) return $cache;
    $file = THEME_PATH . '/inc/data/<entity>.json';
    if ( ! is_readable( $file ) ) { $cache = false; return null; }
    $raw = @file_get_contents( $file );
    if ( $raw === false ) { $cache = false; return null; }
    $data = json_decode( $raw, true );
    if ( ! is_array( $data ) || empty( $data ) ) { $cache = false; return null; }
    $cache = $data;
    return $cache;
}

function <fn>() {
    $from_json = <fn>_from_json();
    if ( is_array( $from_json ) ) return $from_json;
    // Fallback: keep the inline-array as fail-safe. Do NOT delete it.
    $<entity> = [ /* original hardcoded data */ ];
    return $<entity>;
}
```

**Kernpunkt:** Das Inline-Array bleibt als Fail-Safe. Wer es löscht, sobald
die JSON-Datei existiert, fliegt bei einem einzigen fs-Error in eine weiße
Seite. Das Inline-Array kostet vielleicht 2 KB pro Request — vernachlässigbar,
Rettung im Ernstfall.

## Paritäts-Nachweis: die Eintrittskarte

Vor dem Merge muss bewiesen werden, dass JSON-Pfad und Inline-Fallback
inhaltlich dasselbe liefern. Rezept:

```bash
# Mode A: JSON liegt im Theme, pxz_team_doctors() liest sie
PARITY_MODE=json   php parity-check.php > out.json

# Mode B: JSON wird temporär umbenannt, Funktion fällt auf Inline zurück
PARITY_MODE=inline php parity-check.php > out.inline

# Nach alphabetischer Key-Sortierung: diff Exit 0 erwartet
diff out.json out.inline; echo "Exit $?"
```

Dr. Stracke hat diese Parität zur harten AK gemacht (N-1 AK-11). Der
Grund ist einfach: ohne Parität ist der „Fail-Safe-Fallback" keiner —
er würde bei File-Missing eine *andere* Datenform liefern, und genau
dann braucht man den Fallback.

## Was **nicht** in dieses Pattern gehört

- Kein Live-Prod-Push via Filesystem. Prod ist oft auf einem Host ohne
  Dateizugriff (domainfactory für die Praxis-Site). Der Weg dorthin ist
  git push ins Theme-Repo + Prod-Pull, nicht fs.writeFile.
- Kein Media-Upload. Bilder/Videos gehören in die Media-API (Shopify Files,
  WP Media Library), nicht ins Theme-File-Write. Das Pattern ist für
  **strukturierte Daten**.
- Keine Script/CSS/Liquid-Regenerierung. Pattern D aus PATTERNS.md
  (Theme-Asset-Overwrite für Liquid selbst) ist gefährlich — nur in
  Notfällen, nicht Standard.

## Ein-Satz-Zusammenfassung

„Wenn das Ziel-Theme strukturierte Daten aus dem Trunk braucht und keine
passende Daten-API hat, schreib eine JSON-Datei ins Theme, lass das Theme
sie laden und behalte das alte Inline-Array als Fail-Safe. Mit Backup vor
Write, Paritäts-Nachweis vor Merge, und ohne jemals das Theme-Root zu
verlassen."

## Referenz-Session

- Cortex-Web Commit `963c93d` (Adapter + Spec + Evidence)
- Theme-Commit `29dcaf8` (PXZ 2.7.22: inc/data/team.json + inc/team-data.php-Patch)
- Spec: `projects/Cortex-Web/specs/cross-site-transfer/N-1_wp-template-adapter.md`
- Pattern: `Nexus/_memory/patterns/wp-theme-data-json.md`
