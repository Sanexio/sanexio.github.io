# 01 — Architekten-Modus (Manueller Workflow — Dr. Stracke)

> Wie Dr. Stracke den Architekten-Modus einfordert und kontrolliert.

---

## Wann den Modus aktiv einfordern

- Projekt-Setup (neuer Ordner, neue Architektur)
- Nicht-triviale Änderungen an bestehendem Code (> 10 Zeilen, > 1 Datei)
- Alles, was später in Produktion läuft
- Aufgaben, bei denen Claude in der Vergangenheit danebenlag

**Nicht nötig für:**
- „Was bedeutet dieser Fehler?" (Info-Anfrage)
- „Liste mir die Dateien auf"
- Einzeiler

---

## Woran erkennt Dr. Stracke, dass Claude im Architekten-Modus arbeitet?

**Gute Signale:**
- Claude fragt zurück, BEVOR er etwas ändert („Ich verstehe die Aufgabe so …")
- Claude schlägt eine Spec vor ODER legt sie als Datei an
- Bei mehreren Optionen: Vergleichstabelle, keine Vorauswahl
- Nach Umsetzung: Funktionstest + Bericht

**Warnzeichen (Abweichung):**
- Claude fängt sofort an zu ändern, ohne zurückzufragen
- Claude empfiehlt eine Option direkt, statt Optionen aufzulisten
- Claude sagt „fertig", ohne zu zeigen, dass es läuft
- Claude ändert mehr als vereinbart

---

## Korrigierend eingreifen

Wenn eine Phase übersprungen wurde:

| Beobachtung | Rückmeldung an Claude |
|---|---|
| „Claude hat schon angefangen, ohne Rückfrage" | „Stop. Erst Phase 1 — was hast du verstanden?" |
| „Claude empfiehlt Option A direkt" | „LL-034 — zeig mir alle Optionen, ich wähle selbst." |
| „Claude sagt fertig, aber ich sehe keinen Test" | „Phase 4 fehlt — verifizier das bitte." |
| „Claude hat mehr getan als vereinbart" | „Scope-Creep (FK-3). Bitte rollback der Extras." |

---

## Nach jeder Session

- Hat Claude einen **Session-Log** angelegt (`_memory/logs/YYYY-MM-DD_thema.md`)?
- Wurde `MEMORY.md` aktualisiert, wenn neue Erkenntnisse da sind?
- Wenn Fehler gemacht wurden: Stehen sie im Fehlerprotokoll (mit FK-Klasse)?

Falls nein: nachfordern. Das ist kein Nice-to-have — das ist der Kern des selbstlernenden Systems.
