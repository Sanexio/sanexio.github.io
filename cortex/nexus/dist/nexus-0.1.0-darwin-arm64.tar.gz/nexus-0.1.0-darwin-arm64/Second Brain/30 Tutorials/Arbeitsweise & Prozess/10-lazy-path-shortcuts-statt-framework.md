# 07 — Lazy-Path-Shortcut statt Framework (Session 32)

> **Domäne:** Arbeitsweise & Prozess
> **Eingeführt:** 2026-04-24, Session 32 Cortex-Web Block A
> **Verwandt:** 01-architekten-modus, 06-projekt-prio-leiter-holistic

## Kernlektion

**Wenn ein Ziel in einer Session erreichbar ist, baut man keinen Generalisierungs-Framework, der dasselbe Ziel als Spezialfall abdeckt.** Der Framework kommt später, wenn das dritte oder vierte Vorkommen auftaucht und die Kosten der Wiederholung den Bau rechtfertigen.

## Das Beispiel (Cortex-Web Block A)

**Ursprünglicher Plan:** P1-a Medien-Registry als Tool `tools/media/register.mjs`.
- Registry-Schema mit 10+ Feldern (`alt.de/en`, Platform-Targets, sha256-Dedup, `media://`-URIs)
- WP-REST-Upload UND Shopify-GraphQL-Upload
- AJV-Validation
- Idempotenz via Hash
- ≈ 60+ Zeilen Adapter-Code + Schema + YAML-Registry

**Was Dr. Stracke wollte:** 2 von 8 Ärzten haben Fotos — sollen sichtbar sein, damit `/team/` nicht nur Initialen zeigt.

**Der schlanke Weg (umgesetzt):**
1. `wp media import` für 2 Fotos → Attachment-IDs 9683 / 9684
2. `image: 9683` bzw. `image: 9684` direkt in die 2 Trunk-YAMLs
3. Schema: `image` akzeptiert zusätzlich `integer`
4. Renderer: `typeof member.image === "number" ? member.image : 0`
5. Build + Push → 2 Profile live mit Foto

**Aufwand:** 4 Datei-Änderungen. Keine neue Registry. Keine neue Tool-Binary.

## Die Ersparnis-Logik

| | Framework-Weg | Schlanker Weg |
|---|---|---|
| Session-Zeit | 1–2 Sessions | ½ Session |
| Neue Files | 4 (Tool + Schema + Registry + Doku) | 0 |
| Test-Flächen | Upload × 2 Platforms × Schema × Dedup | 1× curl auf /team/ |
| Risiko FK-3 | hoch (plausible Scheinlösung) | niedrig (minimaler Surface) |
| Re-Use-Dividende | erst ab 5. Medium | erst ab 5. Medium |

Der Framework amortisiert sich **nicht** bei 2 Uploads. Bei 8 Arzt-Fotos würde er sich vielleicht lohnen — aber 6 davon brauchen erst einen Foto-Shoot-Termin. Die Amortisations-Schwelle liegt in weiter Zukunft.

## Wann *doch* Framework?

Signal-Triggers:
- **Drittes manuelles Vorkommen desselben Patterns** — „Ich habe das schon dreimal so gemacht" → jetzt abstrahieren
- **Cross-Device-Pflicht** — Prod-Deploy braucht reproduzierbaren Mechanismus → Framework ist Infrastruktur, nicht Kosmetik
- **Mehrere Konsumenten** — wenn eine Praxis UND ein iOS-App UND Shopify dieselbe Media-Auflösung brauchen → Resolver sinnvoll

Solange nur **einer** ruft und der Ruf **einmalig ist**, reicht der direkte Weg.

## Verbindung zur Prio-Leiter (CW-PRIO-001)

Schlanker Pfad ist der Default bei P1–P5 (Alltags-Wert). Framework-Bauen landet auf Popt (gefrierend). Diese Regel verhindert, dass Claude aus reiner Architektur-Eleganz in Infra-Drift zurückfällt.

## Anti-Pattern

```
# FALSCH: 
„Ich baue den Media-Registry-Framework jetzt gleich, dann ist er später fertig."
→ Session endet mit 80 % fertigem Framework + 0 Fotos live.

# RICHTIG:
„Ich mache die 2 Uploads schlank, notiere im Follow-up, dass die Re-Use-Schwelle
noch nicht erreicht ist, und markiere den Registry-Bau als Popt."
→ Session endet mit 2 Fotos live + klarem Follow-up-Pointer.
```

## Selbst-Prüffrage vor jeder Implementierung

1. **Wie oft werde ich diesen Pfad in den nächsten 3 Sessions laufen?** <3 → schlank. ≥3 → Framework-Kandidat.
2. **Ist der Framework selbst in dieser Session fertig?** Nein → auf Popt verschieben.
3. **Kostet der Framework weniger als die Summe der schlanken Wiederholungen?** Nein → schlank bleiben.

## Warum das schwer ist

Claude (und jeder Ingenieur) findet den Framework-Weg *ästhetisch befriedigender* — er sieht vollständiger aus, klingt nach „richtiger" Lösung. Aber im Praxisalltag zählt der **Alltags-Wert** (CW-PRIO-001): Was bringt die Praxis heute live näher? Nicht was elegant klingt.
