# 06 — Projekt-Prio-Leiter für Multi-Projekt-Systeme

**Domäne:** Arbeitsweise & Prozess
**Quelle:** Cortex-Web Session 31 (2026-04-23)
**Lesezeit:** ~6 Minuten
**Für:** Dr. Stracke / sich selbst (Claude)

---

## Warum dieses Tutorial

Bei langlaufenden Projekten mit mehreren Sub-Systemen
(hier: Cortex-Web + Juvantis + Praxis-Webseite) entsteht eine typische
Gefahr: Die Infrastruktur wird immer eleganter, die Adapter immer
symmetrischer — aber **spürbarer Fortschritt für den Nutzer** stagniert.

Session 31 hat dieses Muster empirisch belegt:

> Von 10 vorangegangenen Sessions flossen **7 in Adapter-/Diff-/
> Guard-Symmetrie**. Gleichzeitig war die Medien-Registry leer, die
> Prod-Deploy-Pipeline existierte nicht als Pipeline, und die
> Praxis-Webseite war nicht deployed.

Der Architekt (hier: Claude) hat den Drift mitgetragen, weil jede einzelne
Session in sich plausibel war. Der Projektleiter (hier: Dr. Stracke) hat
den Drift zuerst bemerkt: *„Wir kommen nicht vom Fleck."*

**Fehlerklasse:** FK-3 (Plausible Scheinlösung) — auf Programmleitungs-Ebene.

---

## Das Gegenmittel: Prio-Leiter P1–P6 + Popt + Pios

Jedes Multi-Projekt-System bekommt eine **explizite Prio-Leiter** in
seiner `_config/RULES.md`. Die Leiter besteht aus zwei Gruppen:

### System-tragend (dominiert)

- **P1** — Fundament-Infrastruktur, die den Content-Alltag erst möglich
  macht (z. B. Medien-Registry, Auth-Pipeline, Secrets-Workflow).
- **P2** — Deployment-Pipelines (wiederholbarer Weg vom Edit zum Live).
- **P3** — Content-Rest / Feature-Rest zum Launch-fähigen Zustand.
- **P4** — Der eigentliche Launch-Meilenstein (z. B. Prod-Go-Live).
- **P5** — Alltags-Routine nach dem Launch (Content-Pflege wird Gewohnheit,
  nicht Einzel-Leistung).
- **P6** — Letzte große Scope-Erweiterung (z. B. Mehrsprachigkeit).

### Aufschiebbar (nur bei Pain-Point)

- **Popt** — Optionale Architektur-Vervollständigung (letzte Adapter-
  Quadranten, akademische Symmetrie). Nur, wenn ein konkreter, benannter
  Pain heute etwas blockiert.
- **Pios** / **Px**-Familie — Zukünftige Integrationen, die auf externe
  Reifung warten (hier: iOS-App, Design-Token-Adapter). Gefrierend offen,
  bis das externe Projekt aktiv wird.

---

## Wie das die Session-Führung verändert

### Regel 1 — `SESSION_RESUME.md §0 Roadmap` steht ganz oben

Die Prio-Leiter ist kein Anhang, sondern der **erste Block**, den Claude
bei jedem „Projekt fortsetzen" liest. Die aktuelle Prio-Position (welcher
Block ist dran) ist immer sofort sichtbar.

### Regel 2 — `§5 Sofort-Status-Frage` hat einen Default

Statt einer Liste aus 8 gleichrangigen Fronten schlägt `§5` **einen**
Default vor: den nächsten P1–P5-Schritt. Andere Optionen (Popt/Pios,
Ad-hoc) sind Fußnote, nicht gleichrangig.

### Regel 3 — Pain-Point-Pflicht für Popt/Pios

Wenn Claude eine Popt- oder Pios-Front vorschlägt, muss der konkrete
Pain-Point explizit benannt werden: *Was wird heute blockiert, weil das
fehlt?* Ohne benannten Pain-Point ist die Antwort: verschieben.

### Regel 4 — Session-Audit als Selbstkorrektur

Alle ~10 Sessions: Zählen, wie viele P1–P5 vs. Popt/Pios waren. Bei Drift
> 50 % in Popt/Pios: Prio-Leiter neu verankern, Projekt-Regel schärfen.

---

## Beispiel (Cortex-Web Session 31)

**Vorher (was nah gewesen wäre):** „N-6.5 macht den Diff-Quadrant 100 %
komplett. Lass uns das als nächste Session machen."

**Nachher (mit Prio-Leiter):** „N-6.5 ist Popt — kein aktueller Pain-Point.
Wir machen stattdessen P1 (Medien-Registry), weil ohne die alle
Content-Flows Torsos bleiben. N-6.5 bleibt offen, bis jemand ein
konkretes Szenario hat, das ohne `wp:page-diff` blockiert ist."

---

## Was dieses Tutorial NICHT ist

- Kein Tool — die Prio-Leiter ist Text, keine Automatik.
- Keine Sanitizer-Aufgabe — der Sanitizer hält Token-Budgets, nicht
  Prioritäten.
- Kein Ersatz für Dr.-Stracke-Entscheidungen — er kann jederzeit
  „Ad-hoc-Front" anordnen. Die Leiter ist der **Default-Pfad**, nicht
  die einzige Pfadoption.

---

## Verwandte Patterns + Regeln

- `Nexus/_memory/patterns/holistic-system-priority.md` (Pattern-Formulierung)
- `Cortex-Web/_config/RULES.md` → `CW-PRIO-001` (Projekt-spezifische
  Instanziierung)
- Tutorial `02-selbstregulierende-memory-systeme.md` (Sanitizer V4+V5 —
  Token-Ebene, nicht Prio-Ebene)

---

## Erkennungs-Signal für den nächsten Drift

Wenn Dr. Stracke (oder ein anderer Projektleiter) fragt *„Was bringt
uns das konkret?"* oder *„Wir kommen nicht vom Fleck"* — ist der
Drift-Alarm aktiv. Reaktion: Session-Audit + Prio-Leiter-Neuverankerung,
**nicht noch eine Architektur-Schicht**.
