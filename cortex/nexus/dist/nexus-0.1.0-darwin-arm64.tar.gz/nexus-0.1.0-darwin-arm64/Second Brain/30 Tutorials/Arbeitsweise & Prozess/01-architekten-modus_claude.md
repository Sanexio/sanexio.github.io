# 01 — Architekten-Modus (Claude-Workflow)

> Wie Claude den 4-Phasen-Prozess praktisch umsetzt.

---

## Phase 1 — Verständnis-Sicherung

**Was Claude tut:**
- Pflicht-Dateien lesen: `Nexus/CLAUDE.md`, `_memory/MEMORY.md`, `_rules/GLOBAL_RULES.md` + projektspezifische `_rules/WORKING_MODE.md`, `ARCHITECTURE.md`.
- Den Auftrag in eigenen Worten zurückspielen: „Ich verstehe die Aufgabe so — …. Stimmt das?"
- Unklare Begriffe, Zielgruppen, Erfolgskriterien explizit nachfragen.

**Was Claude NICHT tut:**
- Code schreiben, Dateien bearbeiten, Tools installieren.
- Annahmen heimlich treffen („wird schon passen").

**Ausgang der Phase:** Dr. Stracke bestätigt das Verständnis oder präzisiert.

---

## Phase 2 — Lösungsdesign (Spec)

**Was Claude tut:**
- Spec-Dokument anlegen (oft unter `<projekt>/specs/<sprint>/<name>.md`).
- Inhalt: Ziel, Annahmen, Optionen mit Vor-/Nachteilen (LL-034!), Aufwandsschätzung, Risiken.
- Bei ≥ 3 Optionen: Vergleichstabelle.
- Entscheidungsblock: „Offen — Freigabe nötig zu X, Y, Z."

**Was Claude NICHT tut:**
- Eine Option vorauswählen (LL-034).
- „Wird dann schon passen"-Umsetzung starten.

**Ausgang der Phase:** Dr. Stracke zeichnet eine Variante frei — dann erst Phase 3.

---

## Phase 3 — Umsetzung

**Was Claude tut:**
- Spec öffnen, Schritte abarbeiten.
- Jeden Schritt im Chat erklären (WAS / WARUM / WAS BEDEUTET DAS — LL-024).
- TaskCreate/TaskUpdate für Fortschritt.
- Bei Überraschungen (Datei sieht anders aus als erwartet): **STOP**, Phase 1 oder 2 wiederholen.

**Was Claude NICHT tut:**
- Mehr umsetzen als in der Spec (Scope-Creep = FK-3).
- Zusätzliche Refactorings „nebenbei".

---

## Phase 4 — Selbstprüfung

**Was Claude tut:**
- Funktioniert die Änderung? (Test laufen lassen, curl, Screenshot, Pre-Flight-Script).
- Sind alle Dokumente aktualisiert? (`MEMORY.md`, Session-Log, Tutorial falls neu).
- Wurde ein Fehler gemacht? → ins Fehlerprotokoll mit FK-Klasse.
- Bericht im Chat mit: Was ist fertig, was steht noch aus.

**Was Claude NICHT tut:**
- „Fertig" sagen, ohne verifiziert zu haben (LL-021).

---

## Trigger für Phasen-Wechsel

| Signal | Aktion |
|---|---|
| Dr. Stracke sagt „verstanden, mach weiter" zum Auftrag | → Phase 2 |
| Dr. Stracke zeichnet Option in Spec frei | → Phase 3 |
| Claude hat alle Schritte der Spec abgearbeitet | → Phase 4 |
| Dr. Stracke fragt etwas Neues | → zurück zu Phase 1 |
| Unerwartetes auftaucht | → zurück zu Phase 1 oder 2 |
