---
aliases:
  - Content-Archive Triage
  - Legacy-Triage
tags:
  - arbeitsweise
  - content-migration
  - praxis-webseite
  - cortex-web
---

# Content-Archive Triage — Systematische Sichtung vor Kuration

Dieses Tutorial beschreibt den Workflow, mit dem aus einem archivierten Content-Bestand (z. B. 189 Pages aus einer alten WordPress-Site) eine **entscheidungsreife Kurations-Roadmap** wird. Konkret angewandt in Session 33 für den `legacy/de`-Cluster der Praxis-Webseite (25 Pages).

---

## Worum geht es?

Vor jeder Content-Migration hat man typischerweise einen Archiv-Ordner mit dutzenden oder hunderten Dateien. Die intuitive Frage „setzen wir uns einfach hin und pflegen alles ein?" ist teuer und fehleranfällig, weil:

- 30–50 % der Dateien sind Leer-Stubs, i18n-Dubletten oder saisonale Fragmente
- 10–20 % sind **Goldstücke** (Inhalte, die an ganz anderer Stelle wertvoll sind als ihre Cluster-Zuordnung vermuten lässt)
- der Rest verteilt sich auf drei sehr unterschiedliche Aufwandsklassen (eigene Page · Merge in bestehende Seite · nur Archiv)

**Triage** bedeutet: vor dem ersten Kurations-Schritt jede Datei **einmal** anschauen und genau eine von fünf Empfehlungen vergeben. Danach wissen alle Folge-Sessions, was sie tun müssen, ohne jedes Mal die Meta-Entscheidung zu wiederholen.

---

## Wann lohnt sich das?

✅ **Triage anwenden, wenn:**
- Archiv hat **≥ 15 Einheiten**
- Inhalte sind **heterogen** (kurze Stubs neben langen Patient-Info-Pages)
- **mehrere** Folge-Sessions für Kuration geplant
- es gibt eine **Freigabe-Instanz** (z. B. Dr. Stracke), deren Entscheidungen strukturiert gesammelt werden müssen
- **i18n-/Legacy-Cluster** mit Dubletten und Leer-Einträgen drohen

❌ **Triage überspringen, wenn:**
- weniger als 10 Einheiten im Archiv
- alle Inhalte trivial homogen (z. B. 20 identische Produkt-Beschreibungen)

---

## Die vier Bewertungs-Dimensionen

Jede Archive-Datei wird gegen **vier Fragen** geprüft:

| Dimension | Leitfrage | Indikator |
|---|---|---|
| **Content-Substanz** | Steht da echter Text oder nur Platzhalter/Shortcode? | Textlänge nach HTML-Strip (`chars`), Anwesenheit von `[wpforms ...]`, `[santapress]` etc. |
| **Redundanz** | Deckt der neue Sprint das Thema schon ab? | Gegen Inventar-Tabelle des neuen Sprints prüfen |
| **Cluster-Fehler** | Ist das eine falsch einsortierte i18n-/Leer-Datei? | Titel in FR/EN/ES, 0-char-Body, Sprach-Hinweise im Text |
| **Launch-Relevanz** | Trägt der Inhalt zum Go-Live-Ziel bei? | HWG-Konformität, Patient-Service, Rechtsquelle, Info-Kern |

---

## Die fünf Empfehlungs-Kategorien

Nach der Sichtung bekommt jede Datei genau eine Empfehlung:

| Emoji | Kategorie | Bedeutung |
|:-:|---|---|
| 📥 | **PFLEGEN** | Neue eigene Page im Trunk anlegen, eigenes Template |
| 🔀 | **MERGEN** | Inhalt-Bestandteile in bestehende Target-Page übernehmen |
| 📚 | **ARCHIV-ONLY** | Bleibt im Archive, keine Live-Anlage |
| ❓ | **DR.-STRACKE-FRAGE** | Business-/Legal-/Terminologie-Entscheidung erforderlich |
| 🗑 | **LÖSCHEN** | Keine Trunk-Anlage (Archive-Datei bleibt trotzdem — Immutability) |

**Wichtig:** „Löschen" heißt **nicht** das Archive-File zu entfernen. Das Archiv ist unveränderlich (siehe Tutorial zu Content-Archive-Anlage). „Löschen" heißt: in der neuen Seite existiert diese Page nicht.

---

## Workflow in vier Schritten

### Schritt 1 — Vorbereitung (5 Min)

- Scope festlegen: welche Pages/welcher Cluster?
- Inventar-Filter: `cluster=<scope>` aus Inventory-CSV extrahieren
- Grund-Metadaten pro Datei: ID, Slug, Titel, Body-Chars, Image-Count, Template

### Schritt 2 — Inspektion (60–90 Min bei 25 Pages)

Für jede Datei:
- HTML aus Body entfernen, erste 500–800 Zeichen lesen
- Leere Dateien explizit als solche markieren (0 chars)
- Mojibake-Befund notieren (z. B. `?` statt Umlaut → Legacy-UTF8-Problem)
- Kurz-Zusammenfassung in einem Satz

### Schritt 3 — Klassifikation (30–60 Min)

Triage-Spec schreiben mit Unter-Tabellen je Empfehlungs-Kategorie. Spalten:

```
# | slug (id) | chars | Inhalt (kurz) | Empfehlung | Ziel/Begründung
```

Anschließend:
- Zusammenfassungs-Matrix (Anzahl je Kategorie, Launch-Impact)
- Goldstücke hervorheben (Content, der an überraschender Stelle wertvoll ist)
- `DR.-STRACKE-FRAGE`-Block mit konkreten offenen Fragen
- Folge-Arbeits-Backlog in Unter-Blöcken mit Aufwands-Schätzung

### Schritt 4 — Freigabe-Loop (je Session 15–30 Min)

- Triage-Spec committen
- Dr. Stracke klärt offene Fragen
- Antworten einarbeiten (Post-Freigabe-Update-Commit)
- Triage-Spec wird zur Kurations-Roadmap für B-2a/b/c/d-Sessions

---

## Goldstücke erkennen

Nicht jede Datei gehört wirklich in den Cluster, in dem sie liegt. Das sind die **Goldstücke** — und das Finden lohnt extra Aufmerksamkeit.

### Beispiel aus S33

In `legacy/de/` lag eine Datei namens `docteur-en-med-s-saul-375.md` (6586 Zeichen, französischer Slug, deutscher Inhalt). Oberflächlich: „Legacy-Arzt-Profil". Bei der Sichtung: **ausführliche Bio mit Ausbildung, Stationen, Qualifikationen**.

Klassifikation: **MERGEN → B-1** — diese Datei ist Bio-Rohmaterial für einen ganz anderen Folge-Sprint (B-1 „Arzt-Bios pflegen"). Statt einer separaten Bio-Recherche-Session mit Dr. Stracke (Rückfrage, CV-Mail, Antwort, Ausformulieren) reicht ein Extraktions-Schritt:

1. Mojibake-Fix: `Fach?rztin` → `Fachärztin`, `Br?ssel` → `Brüssel`, `Universit?` → `Université`
2. HWG-Filter: werbende Formulierungen raus, faktische Daten behalten
3. Sprachverdichtung: 6586 → ~900 Zeichen, 4 Absätze
4. Ziel: `trunk/content/team/docteur-saul.yaml:bio.de`

Ergebnis: 1 von 7 fehlenden Arzt-Bios ist **ohne Dr.-Stracke-Input** fertig. Das ist der Hebel des Triage-Patterns.

---

## Anti-Patterns

| ❌ Anti-Pattern | ✅ Besser |
|---|---|
| Binäre Triage (nur PFLEGEN/LÖSCHEN) | Fünf-Kategorien-Schema inkl. MERGEN und ARCHIV-ONLY |
| Claude entscheidet alles allein | Kategorie `DR.-STRACKE-FRAGE` ist Pflicht für Business/Legal/Terminologie |
| Triage und Kuration in einer Session | Strikte Trennung: erst klassifizieren, dann ausführen |
| Mündliche Triage-Ergebnisse | Immer Markdown-Spec mit Commit |
| LÖSCHEN bedeutet Archive-File entfernen | Archive-File bleibt (Immutability), nur keine Trunk-Neuanlage |

---

## Mojibake — Der stille Legacy-Begleiter

Viele alte WordPress-Exporte haben das Problem, dass Umlaute und Sonderzeichen zu `?` werden (fehlerhafte Konvertierung UTF-8 → ISO-8859 → UTF-8). Bei Bio-Extraktion muss das bereinigt werden.

**Typische Fälle:**

| Legacy | Richtig |
|---|---|
| `Fach?rztin` | `Fachärztin` |
| `Br?ssel` | `Brüssel` |
| `Universit?` | `Université` |
| `Franz?sisch` | `Französisch` |
| `P?diatrie` | `Pädiatrie` |
| `Ober?rztin` | `Oberärztin` |
| `K?rperverletzungen` | `Körperverletzungen` |
| `da?os` | `daños` |
| `Le?n` | `León` |
| `?ffentliches` | `öffentliches` |
| `flie?end` | `fließend` |
| `2005 ? 2018` | `2005–2018` (en-dash) |

**Regel:** Mojibake wird beim Extrahieren **in den Trunk** gefixt, nicht in der Archive-Datei. Archive bleibt unverändert.

---

## Verwandte Tutorials

- [06 Projekt-Prio-Leiter (holistic)](./06-projekt-prio-leiter-holistic.md) — wie man Cluster-Kuration gegen Infrastruktur-Drift abgrenzt
- [10 Lazy Path Shortcuts statt Framework](./10-lazy-path-shortcuts-statt-framework.md) — wann 15-Minuten-Lösung statt Re-Use-Framework
- [01 Architekten-Modus](./01-architekten-modus.md) — 4-Phasen-Prozess, unter dem die Triage als Phase-1-Verständnis läuft

---

## Referenz-Anwendung

- **Triage-Spec:** `projects/Cortex-Web/sites/praxis-webseite/specs/sprint-2/B-2_legacy-de-triage.md`
- **Pattern:** `Nexus/_memory/patterns/content-archive-triage.md`
- **Commits:** `a859d51` (Erstfassung) · `ce50c6d` (Freigabe-Update) · `ace49ed` (Goldstück-Anwendung Docteur-Saul-Bio)
