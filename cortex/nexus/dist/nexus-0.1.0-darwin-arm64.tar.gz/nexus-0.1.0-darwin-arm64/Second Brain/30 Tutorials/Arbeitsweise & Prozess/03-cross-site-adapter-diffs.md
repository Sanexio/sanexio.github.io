# 03 — Cross-Site-Adapter mit Diff-Pfad ergänzen

**Kurz:** Wenn ein Adapter Inhalte zwischen zwei Plattformen überträgt
(z.B. Trunk → Shopify), braucht man oft auch einen Read-Only-Diff,
der vor einem Push zeigt, ob sich überhaupt etwas verändern würde.
Dieses Tutorial erklärt das **Build-then-Fetch-then-Diff-Pattern**,
mit dem man so einen Diff-Pfad ohne Code-Duplikation und ohne
Refactor des Push-Pfads ergänzt.

**Gelernt in:** Cortex-Web Session 26 (2026-04-23), Front N-6
`cw-transfer diff shopify:page`. **Erweitert in Session 28
(2026-04-23), Front N-6.2 `cw-transfer diff shopify:template`:**
symmetrisches Pre-Processing + canonical-JSON für strukturierte
Payloads. **Erweitert in Session 30 (2026-04-23), Front N-6.3
`cw-transfer diff wp:template`:** Filesystem-Variante (Read statt
API-GET) + Renderer-Handle-Arg für Collection-Renderer + Extended-
Evidence-Rezept (Drift-Test mit Restore).

---

## Warum überhaupt ein Diff?

In einer normalen Cross-Site-Pipeline gibt es zwei Verben:

- **push** — Trunk → Site (schreibend, idempotent oder destruktiv)
- **pull** — Site → Trunk-Proto (lesend, für Re-Subsumption)

Was fehlt: **„Würde ein Push überhaupt etwas verändern?"**

Ohne Antwort auf diese Frage hat man drei Probleme:

1. **Pre-Push-Verifikation fehlt.** Operator pusht „auf gut Glück" — der
   Push kann no-op sein, dann hat man umsonst Backups erzeugt (CW-008
   schreibt vor jedem Update ein Backup) und Rate-Limits verbraucht.
2. **Drift-Detection fehlt.** Wenn jemand das Live-Asset manuell editiert
   (Verstoß gegen CW-001 „Trunk ist Master"), erkennt man das nicht ohne
   irgendeinen Vergleich.
3. **CI-Integration fehlt.** Pre-Commit-Hooks und Drift-Reports brauchen
   einen klaren Exit-Code (0=identisch, 1=Diff, 2=Fehler), den der Push-
   Pfad nicht liefern kann (er pusht ja schon).

Antwort: ein Diff-Tool, das **read-only** vergleicht.

---

## Naive Lösung — und warum sie schlecht ist

Erste Idee: „Ich baue im Diff-Tool selbst die Render-Logik nach, die der
Build-Tool macht, und vergleiche dann mit dem Live-Asset."

Konsequenzen:
- **Render-Logik existiert zweimal** → bei Bug-Fix muss man beide pflegen
- **Schema-Validation duplizieren** → das ist Schema-Drift garantiert
- **Build-Tool darf sich nie inkompatibel ändern** → unmöglich auf Dauer

Zweite Idee: „Ich refactore den Build-Tool zu einer ESM-Funktion, die
ich importiere."

Konsequenzen:
- **Push-Pfad muss angefasst werden** → Risiko für produktiven Code
- **Modul-Boundaries müssen erst sauber sein** → großer Vorab-Refactor
- **Build-Tool kann nicht mehr standalone laufen** ohne Wrapper

Beide Ansätze kosten zu viel.

---

## Lösung — Spawn als Black-Box

Der Diff-Tool **spawnt** den existierenden Build-Tool als Sub-Prozess
und liest dessen stdout.

```
Trunk-YAML
   ↓ spawnSync("bun", ["build-X.mjs", inputPath])
   ↓ stdout
Local-Payload (JSON)
                          + GET /admin/api/.../live-asset.json
                          ↓
                          Live-State (JSON)
   ↓
   field-by-field compare
   ↓
   text- or JSON-output
   ↓
   exit(0) wenn equal · exit(1) wenn diff · exit(2) wenn error
```

In Code (ohne Boilerplate):

```js
// adapters/<target>/diff-X.mjs
import { spawnSync } from "node:child_process";
import { createClient } from "./lib/<target>-client.mjs";

// Step A — local payload via build-tool sub-process
const buildRes = spawnSync(
  "bun",
  ["adapters/<target>/build-X.mjs", inputPath],
  { cwd: REPO_ROOT, stdio: ["ignore", "pipe", "inherit"], encoding: "utf8" }
);
if (buildRes.status !== 0) die(2, `build failed (exit ${buildRes.status})`);
const local = JSON.parse(buildRes.stdout);

// Step B — live state via read-only API call
const live = await client.get(`/...?...`);

// Step C — field-by-field comparison
const result = {
  spec: "<target>:<type>",
  source: inputPath,
  fields: { /* per-field equal/local/live */ },
  result: "EQUAL",
  diff_count: 0
};
// fill result.fields, then:
process.exit(result.result === "EQUAL" ? 0 : 1);
```

---

## Zwei harte Garantien (Code-Review-Checkliste)

### G-1 — Read-Only

Der Diff-Tool-Code darf nur GET-Aufrufe enthalten. Verifikation:

```bash
grep -E 'client\.(post|put|delete)\(' diff-X.mjs
# soll 0 Matches liefern
```

(Achtung: Substring-Grep matched auch Kommentare. Auf das Aufruf-Pattern
mit öffnender Klammer prüfen — `client.post(`, nicht nur `client.post`.)

### G-2 — Exit-Code-Trinität

| Exit | Bedeutung | Wann |
|:-:|---|---|
| 0 | EQUAL | Live-State matcht Local-Payload in allen verglichenen Feldern |
| 1 | DIFF | ≥ 1 Feld differiert ODER Live-Asset existiert nicht |
| 2 | ERROR | Config (env), Netzwerk, Build-Sub-Prozess failed, JSON-Parse-Fehler |

Diese Trinität ist wichtig für CI-Integration: ein Pre-Commit-Hook
„blockiere wenn Diff zu Live existiert" prüft `exit-code != 0`,
unterscheidet aber nicht zwischen DIFF und ERROR.

---

## Field-Compare-Konventionen

### Normalisierung vor Vergleich

Backends melden oft semantisch gleiche Werte syntaktisch unterschiedlich
zurück. Beispiel Shopify Pages:

```js
function normTemplateSuffix(v) {
  // Shopify treats empty string and null interchangeably
  if (v === undefined || v === null || v === "") return null;
  return v;
}
```

Sonst zeigt der Diff fälschlich „local=null, live=''" als DIFF an.

### Konditionale Felder

Manche Felder haben einen erwarteten Default-Drift, der nicht actionable ist.
Beispiel N-6: das `published`-Feld. Trunk ist immer draft (CW-001), Live ist
oft published. Das ist kein echter Drift.

Lösung: konditional vergleichen, default skipped:

```js
if (publishFlag) {
  // compare published
} else {
  result.fields.published = {
    skipped: true,
    reason: "PUBLISH env not set — Trunk-draft vs. Site-published is expected"
  };
}
```

### Long-String-Diffs

`body_html`, `description`, `body_md` etc. können mehrere kB lang sein.
Volle Diffs gehören NICHT in einen Adapter-Diff-Tool — sie fluten das
Terminal. Statt dessen:

```js
{
  equal: false,
  local_length: 8505,
  live_length: 0,
  first_diff_offset: 0
}
```

Wer den vollen Diff will, nimmt den Build-Output und ein dediziertes
Diff-Tool (`diff`, `dwdiff`, `jq`). Im Adapter-Diff sieht man, **dass**
sich was ändert und an welcher Position — den Inhalt klärt der Operator.

---

## Output-Modi (Best-Practice)

Zwei Modi anbieten, beide aus derselben internen `result`-Struktur:

```bash
# Default — human readable
$ cw-transfer diff shopify:page trunk/.../ueber-uns.yaml
spec             : shopify:page
handle           : uber-uns
title            : EQUAL ("Über uns")
template_suffix  : DIFFER (local=null, live="uber-uns")
body_html        : DIFFER (local 8505 chars, live 0 chars, first diff at offset 0)
RESULT           : DIFF (2 fields)

# JSON — for tooling
$ FORMAT=json cw-transfer diff shopify:page trunk/.../ueber-uns.yaml
{"spec":"shopify:page","handle":"uber-uns","fields":{"title":{"equal":true,...},...},"result":"DIFF","diff_count":2}
```

Pre-Commit-Hooks und CI-Drift-Reporter konsumieren JSON; Operator-Sessions
am Terminal lesen text.

---

## Wann das Pattern nicht greift

| Bedingung | Hindernis |
|---|---|
| Build-Tool > 2s Laufzeit | Sub-Spawn-Roundtrip zu lästig → refactore zur ESM-Funktion |
| Build-Tool gibt Logs auf stdout aus | JSON.parse failt → Konvention: Logs nur auf stderr |
| Build-Tool hat keinen klar definierten Output-Shape | Diff-Tool kann nichts vergleichen → erst Output normieren |
| Live-State hat nicht-deterministische Felder | Vergleich liefert immer Diff → diese Felder ignorieren oder normalisieren |

Wenn man zwei oder mehr dieser Bedingungen trifft: refactor lohnt sich.

---

## Anwendung in Cortex-Web

Kanonisches Beispiel (Session 26 N-6):
- Build: `adapters/shopify/build-page.mjs <yaml>` → JSON `{page: {handle, title, body_html, ...}}`
- Diff:  `adapters/shopify/diff-page.mjs <yaml>` → spawnt build, GET `/pages.json?handle=...`, vergleicht

Zweite Anwendung (Session 28 N-6.2) — Pattern B Template-Asset-Diff:
- Build: `adapters/shopify/build-template.mjs <yaml>` → JSON `{asset: {key, value: "/* auto-comment */\n{sections...}"}}`
- Diff:  `adapters/shopify/diff-template.mjs <yaml>` → spawnt build, GET `/themes/<id>/assets.json?asset[key]=...`, vergleicht

Dritte Anwendung (Session 30 N-6.3) — WP-Theme-File-Diff (FS-Variante):
- Build: `adapters/wordpress/build-team.mjs` (arg-los, 8 YAMLs → 1 JSON) → `{asset: {path: "inc/data/team.json", value: "<array-json>"}}`
- Diff:  `adapters/wordpress/diff-team.mjs <renderer>` → spawnt build, `readFileSync(<theme>/<asset.path>)`, vergleicht

Geplant (noch offen):
- `cw-transfer diff shopify:product` — Product-Diff inkl. Variants (N-6.4)
- `cw-transfer diff wp:page` — WP-Page-Diff (Pattern A, setzt WP-REST-Auth voraus)

---

## Zwei Lehren aus N-6.2 — Diff von strukturierten Payloads

Bei Pattern-B-Pages ist der Vergleichsgegenstand kein Roh-HTML-Blob,
sondern ein **strukturiertes JSON-Asset** (Shopify-Template mit
`sections`, `order`, `blocks`). Das verändert zwei Details des
Basis-Patterns:

### Lehre 1 — Symmetrisches Pre-Processing

Wenn **sowohl** die lokale Build-Tool-Ausgabe **als auch** der
Live-Server-Response denselben auto-generierten Prefix tragen, muss
der Strip-Schritt auf **beiden Seiten identisch** angewandt werden.

Bei Shopify-Templates tragen beide einen Header-Comment:
```
/*
 * ------------------------------------------------------------
 * IMPORTANT: The contents of this file are auto-generated.
 * ...
 */
{ "sections": { ... }, "order": [...] }
```

Naive Lösung: Strip nur auf Live-Seite (so wie `extract-template.mjs`
es macht). Dann ist jeder Diff trivialerweise positiv, weil die
lokale Seite den Comment noch enthält und die Live-Seite nicht mehr.

Korrekte Lösung: Eine `HEADER_STRIP_RE` Konstante, die auf **beide**
Seiten angewandt wird, bevor `JSON.parse` aufgerufen wird.

**Faustregel:** Wenn das Build-Tool seinen eigenen Output nicht
wiederverwendbar als Input für den Push-Adapter produzieren kann
(also der Build-Output wirklich „sendefertig" ist), dann ist
Pre-Processing **asymmetrisch** — das ist der Hinweis, beide Seiten
gleichartig zu behandeln.

### Lehre 2 — Canonical-JSON für strukturierte Payloads

JSON-Assets haben ein semantisches Problem: die Key-Reihenfolge
innerhalb von Objekten ist nicht semantisch relevant. Wenn Shopify
den Roundtrip macht, kann sich die Key-Reihenfolge ändern, obwohl
der Inhalt gleich ist. Ein naiver String-Vergleich wäre trivialerweise
positiv.

**Lösung:** Canonical-JSON — vor dem Vergleich werden beide Seiten
rekursiv mit sortierten Objekt-Keys re-stringified:

```js
function canonicalize(value) {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (value !== null && typeof value === "object") {
    const out = {};
    for (const key of Object.keys(value).sort()) {
      out[key] = canonicalize(value[key]);
    }
    return out;
  }
  return value;
}

const localCanon = JSON.stringify(canonicalize(localTemplate));
const liveCanon = JSON.stringify(canonicalize(liveTemplate));
const offset = firstDiffOffset(localCanon, liveCanon);
```

**Wichtig:** Arrays werden NICHT sortiert — sie sind semantisch
geordnet. Template-`order`-Array = Section-Rendering-Reihenfolge.
Block-`block_order` = Block-Rendering-Reihenfolge. Nur
Objekt-Keys werden sortiert.

**Ergebnis in N-6.2:** Trunk `ueber-uns.yaml` liefert 4836 Zeichen
canonical, Shopify-Live liefert 4836 Zeichen canonical, offset=null.
EQUAL — und damit ein byte-genauer Roundtrip-Beweis für
content-bridge-v1 aus Session 22.

---

## Drei Lehren aus N-6.3 — Filesystem-Adapter-Diffs

Bei N-6.3 ist die "Live"-Seite keine HTTP-API, sondern eine Datei auf
dem lokalen Filesystem (das WordPress-Theme-Verzeichnis). Das klingt
banal, verändert aber drei Details des Basis-Patterns.

### Lehre 1 — Renderer-Handle statt Source-File als CLI-Arg

Bei Shopify-Templates passt `diff shopify:template <yaml>` — ein YAML
produziert ein Template. Bei WP-Team-Daten aggregiert der Renderer
8 YAMLs zu 1 JSON. `<yaml>` als Arg ist semantisch falsch.

**Lösung:** Renderer-Handle (ein String aus einer Registry):

```js
const DIFF_RENDERERS = {
  team: { build_tool: "adapters/wordpress/build-team.mjs",
          source_desc: "trunk/content/team/*.yaml" }
  // zukünftig: services, diagnostik, ...
};

const handle = process.argv[2];
const cfg = DIFF_RENDERERS[handle];
if (!cfg) die(1, `unknown renderer handle "${handle}" (known: ${Object.keys(DIFF_RENDERERS).join(", ")})`);
```

**Warum das wichtig ist:** CLI-Grammatik bleibt stabil, auch wenn
der Trunk später neue Collection-Renderer bekommt. Tippfehler
(`diff wp:template teamm`) schlagen sofort mit enumerierter
Fehlermeldung fehl, statt in der Build-Sub-Prozess-Logik unterzugehen.

### Lehre 2 — Filesystem-Fetch hat andere Sonderfälle als API-Fetch

| Dimension | HTTP-Fetch (N-6, N-6.2) | FS-Fetch (N-6.3) |
|---|---|---|
| Nicht existent | HTTP 404 → Exception mit `\b404\b` regex | `!existsSync(path)` → sauber testbar |
| Auth | Token + Header | Theme-Pfad-Resolution + Escape-Guard |
| Bytes-Round-Trip | Backend kann Header-Prefix injizieren → Strip nötig | Datei kommt 1:1 zurück → kein Strip |
| Metadaten | `updated_at`, `size` aus API-Response | `statSync(...).mtime`, `.size` |

**Path-Escape-Guard Pflicht** bei FS-Adaptern — nicht nur Schönheit,
sondern Safety. Der `asset.path` aus dem Build-Tool MUSS validiert
werden, dass er nicht mit `..` oder `/` beginnt und nach `resolve()`
unter dem Theme-Root bleibt. Sonst ist der Diff-Adapter ein
Pfad-Traversal-Vektor, selbst ohne Write-Calls:

```js
const assetRel = localPayload.asset.path.replace(/^\/+/, "");
if (assetRel.includes("..") || assetRel.startsWith("/")) die(2, "unsafe asset.path");
const targetPath = resolve(themePath, assetRel);
if (!targetPath.startsWith(resolve(themePath) + "/")) die(2, "escapes theme root");
```

### Lehre 3 — Extended Evidence ist bei FS-Adaptern billig und pflichtig

Bei API-Adaptern ist ein Drift-Test teuer: man muss wirklich Live
mutieren, was oft gegen Policies verstößt (CW-006 gerichtet-explizit,
kein Test-Push auf Produktiv-Shopify). Bei FS-Adaptern ist das
anders — die Theme-Datei liegt lokal, ist in einem Git-Repo, und
ein `cp original /tmp/ && mutate && diff && cp /tmp/ original &&
diff` dauert Sekunden.

**Rezept (sollte jeder FS-Diff-Adapter-Self-Check zeigen):**

1. Original in `/tmp/<test>-backup.json` sichern (+ MD5 capture)
2. Mutation 1: Feld ändern → erwarte DIFF nur im `<payload>_json`-Feld
3. Mutation 2: Collection-Element entfernen → erwarte DIFF in allen
   drei Dimensionen (count/slugs/json)
4. ABSENT-Fall: Datei wegbewegen (`mv original original.tmp`) → erwarte
   Exit 1 mit `live_file: ABSENT`
5. Restore aus `/tmp/` → MD5-Vergleich gegen Backup
6. Re-Diff → erwarte Exit 0 EQUAL

Das ist 10 Minuten extra Arbeit und bringt 3 Extra-AKs plus den
**echten Regressions-Schutz**: wenn jemand später den Renderer oder
das PHP-Lade-Pattern anfasst und einen Drift einführt, kippt der
Diff-Adapter auf Exit 1 — und ist damit der objektive Beweis, dass
das frühere Verhalten verloren geht. Für eine dauerhafte Webseite
ist das die Kern-Garantie.

**Ergebnis in N-6.3:** Parity Exit 0, Feld-Mutation Exit 1 (1 Feld),
Member-Removal Exit 1 (3 Felder), ABSENT Exit 1 (1 Feld), Restore
MD5-match, Re-Diff Exit 0. 16/16 AKs.

---

## Verwandte Tutorials

- 01 — Architekten-Modus (Spec-First, Selbstprüfung)
- 02 — Selbstregulierende Memory-Systeme (Cortex-Sanitizer V5 als anderes Adapter-Architektur-Pattern)

## Verwandte Patterns (in Nexus)

- `build-then-fetch-then-diff` (Session 26) — gleicher Stoff, kompakter
- `adapter-runtime-flag-vs-content-state` (Session 24) — wie Push-Pfade
  Trunk-State vom Runtime-Flag trennen
- `cross-site-transfer-registry` (Session 22) — Renderer/Extractor-Registry
  als Schwester-Konzept zu DIFF_TOOLS

---

*Autor: Claude (Architekten-Modus, Cortex-Web Session 26 autonom Cluster-Mini-02). Verifiziert in `cw-transfer` v1 + `adapters/shopify/diff-page.mjs`, 12/12 AKs.*
