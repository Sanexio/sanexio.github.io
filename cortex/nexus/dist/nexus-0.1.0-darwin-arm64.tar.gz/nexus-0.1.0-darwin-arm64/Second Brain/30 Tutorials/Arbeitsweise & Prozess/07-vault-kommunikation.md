---
type: tutorial
tutorial-id: TUT-VAULT-COMM-01
aliases: [Vault-Kommunikation, Callouts, Fragen an Claude]
tags:
  - tutorial
  - arbeitsweise
  - vault
  - obsidian
---

# Vault-Kommunikation — Wie Dr. Stracke mit Claude über Obsidian-Notizen spricht

Seit **2026-04-24** ist das Second Brain nicht nur eine Wissens-Anzeige, sondern
ein **bidirektionaler Arbeitsraum**. Dr. Stracke kann in jeder Vault-Datei
Fragen und Anweisungen hinterlegen — Claude liest sie automatisch und antwortet
im gleichen Dokument. Spec: [[LL-045]].

---

## 🎯 Die zwei Modi

| Modus | Wann | Syntax | Claude reagiert |
|---|---|---|---|
| **Frage** | Passiv — „wenn du Zeit hast" | `> [!frage]` | Beim nächsten Sessionstart wird Dr. Stracke auf offene Fragen hingewiesen |
| **Anweisung** | Aktiv — „bitte machen" | `> [!anweisung]` | Erst beim expliziten Befehl **„Nexus Anweisungen abarbeiten"** |

Die Trennung ist bewusst: Fragen stapeln sich ohne Druck, Anweisungen lösen gezielte Aktionen aus.

---

## ✍️ So stellen Sie eine Frage

Öffnen Sie **irgendeine** Datei im Second Brain (Projekt-Notiz, Regel,
Tutorial — egal welche) und schreiben Sie irgendwo:

~~~markdown
> [!frage] Kurzer Titel
> Hier steht Ihre eigentliche Frage.
> Sie kann mehrzeilig sein, solange jede Zeile mit `> ` beginnt.
~~~

**Was passiert:**
1. Das Sync-Skript läuft alle 5 Minuten.
2. Es findet Ihren Callout und legt die Frage in `_memory/pending-questions.md`.
3. Beim nächsten Claude-Start bekommen Sie: *„Sie haben 1 offene Frage in `<Datei>`. Beantworten?"*
4. Claude antwortet direkt in der Datei — als neuer Callout-Block unter der Frage:

~~~markdown
> [!antwort]- 2026-04-24
> Ihre Antwort. Der Bindestrich macht den Block eingeklappt,
> damit die Datei übersichtlich bleibt.
~~~

5. Der Austausch wird zusätzlich in [[Dialog]] chronologisch archiviert.

---

## 📋 So geben Sie eine Anweisung

~~~markdown
> [!anweisung] Content-Archive prüfen
> Gehe durch sites/praxis-webseite/_content-archive/ und zähle,
> wie viele Pages noch im Status "unprocessed" sind.
~~~

**Was passiert:**
1. Der Sync-Skript sammelt sie in `_memory/pending-instructions.md`.
2. **Nichts passiert weiter**, bis Sie explizit sagen: **„Nexus Anweisungen abarbeiten"**.
3. Dann arbeitet Claude die Liste ab und schreibt direkt unter jede Anweisung:

~~~markdown
> [!erledigt]- 2026-04-24
> Ergebnis: 23 Pages im Status "unprocessed" gefunden.
> Details in _content-archive/unprocessed-inventory.md.
~~~

4. Im Chat erhalten Sie einen Kurz-Report: was erledigt, was blieb offen.

---

## 🔍 Wichtige Regeln

### 1. Callouts in Code-Blöcken werden **ignoriert**
Beispiele wie in diesem Tutorial (in ` ``` `-Blöcken) lösen nichts aus. Das ist
beabsichtigt — Sie können die Syntax dokumentieren, ohne dass Claude reagiert.

### 2. Claude-Antworten folgen **direkt** auf Ihre Frage
Zwischen `[!frage]` und `[!antwort]` darf höchstens eine Leerzeile sein.
Antworten woanders in der Datei werden nicht als Reply erkannt.

### 3. Ein beantworteter Dialog verschwindet nicht
- In der Ursprungsdatei: bleibt als Callout-Paar sichtbar (eingeklappt).
- Im Dialog-Log `00 Kontext/Dialog.md`: als chronologischer Eintrag mit Datum, Datei-Link, Thema.

### 4. Wann scannt Claude?
Automatisch alle 5 Minuten im Hintergrund (`nexus-sync.sh`). Sie müssen nichts triggern.

### 5. Geräteübergreifend
Der Vault liegt im Nexus-Git-Repo, das auf allen 3 Cortex-Geräten synct.
Eine Frage auf dem Mac Studio wird auf dem MacBook beantwortet — alles
landet überall an.

---

## 🗺️ Wo finde ich was?

| Datei | Inhalt |
|---|---|
| `_memory/pending-questions.md` | Alle offenen Fragen (Queue) |
| `_memory/pending-instructions.md` | Alle offenen Anweisungen (Queue) |
| `Second Brain/00 Kontext/`[[Dialog]] | Chronologisches Q&A-Log |
| [[DASHBOARD]] | Anzahl offener Einträge + Projekt-Status |

---

## 💡 Typische Anwendungsfälle

### Während Sie ein Tutorial lesen
Sie verstehen einen Abschnitt nicht:

~~~markdown
> [!frage] Was bedeutet "Hard-Guard" hier?
> Ich verstehe den Begriff im Kontext von Avatar-Morphs nicht.
~~~

→ Claude erklärt beim nächsten Mal direkt im Tutorial.

### Während Sie eine Projekt-Notiz anschauen
Sie wollen Details:

~~~markdown
> [!anweisung] Erkläre mir den Pattern-A-Flow Schritt für Schritt
> Ich brauche eine Entwickler-Sicht: welche Dateien, welche Hooks,
> in welcher Reihenfolge.
~~~

→ Nach Befehl „Nexus Anweisungen abarbeiten" bekommt die Notiz einen
langen `[!erledigt]`-Block mit Flow-Diagramm.

### Für wiederkehrende Check-Aufgaben
Im DASHBOARD selbst:

~~~markdown
> [!anweisung] Wöchentlicher Sprint-Report praxis-webseite
> Fasse die letzten 5 Session-Logs des Projekts zusammen.
> Was ist fertig, was steht an, welche Risiken?
~~~

---

## 🧠 Warum das so gebaut ist

Dr. Strackes Arbeitsweise: **Arzt, abends und am Wochenende verfügbar, iPad
oft unterwegs**. Claude muss nicht sofort antworten können — aber jede
Frage darf nicht verloren gehen. Der Vault ist das einzige Medium, das:

1. Offline funktioniert (iPad ohne Netz)
2. Geräteübergreifend synchronisiert ist (Nexus-Git)
3. Nicht von Chat-Verlauf-Limits betroffen ist (wie Cowork oder Terminal-Sessions)
4. Kontext bewahrt (die Frage steht genau in der Notiz, auf die sie sich bezieht)

So wird das Second Brain zur persistenten Arbeitsfläche zwischen Sessions.

---

## Verwandte Notizen

- [[LL-045]] — Regel-Spec Vault-Kommunikation
- [[Dialog]] — Kommunikations-Log
- [[DASHBOARD]] — Live-Status + Queue-Counter
- [[01-architekten-modus]] — Wie Claude an Aufgaben herangeht
- [[LL-042]] — Session beenden
- [[LL-043]] — Projekt fortsetzen

*Letzte Aktualisierung: 2026-04-24*
