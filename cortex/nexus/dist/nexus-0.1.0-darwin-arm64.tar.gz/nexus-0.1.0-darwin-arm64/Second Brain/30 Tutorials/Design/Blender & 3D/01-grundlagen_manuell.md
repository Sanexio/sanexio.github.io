# Blender: Grundlagen — Manueller Workflow

## Wann nutze ich diesen Weg?

Du brauchst den manuellen Workflow wenn:
- Du Blender als 3D-Programm verstehen und lernen möchtest
- Du feine Details selbst kontrollieren möchtest (nicht per Skript)
- Du kleine, schnelle Änderungen direkt in der UI machst (einfacher als Skript-Anpassung)
- Du keine Programmier-Erfahrung brauchst und nur "klicken" möchtest

**Beispiel aus Juvantis:** Du öffnest Blender, fügst manuell Sphären für Head, Cubes für Body zusammen, färbst sie ein und exportierst. Reines Point-and-Click.

---

## Der Manuell-Workflow: 5 Schritte

```
1. Blender öffnen → Welcome-Screen weg
      ↓
2. Basis-Objekte hinzufügen (Cube, Sphere, Cylinder)
      ↓
3. Objekte positionieren & skalieren (G, R, S Shortcuts)
      ↓
4. Farben & Materialien zuweisen
      ↓
5. Exportiert als USDZ → iOS-App
```

---

## Schritt 1: Blender öffnen und Szene vorbereiten

**Öffne Blender:**
- Doppelklick auf Blender-Icon

**Schließe Welcome-Screen:**
- Klick irgendwo auf die 3D-View oder Esc

**Szene löschen (optional):**
```
A  (wähle Alles)
X  (lösche Alles)
Y  (bestätige Löschen)
```

Jetzt hast du eine leere Szene — perfekt zum Bauen!

---

## Schritt 2: Avatar manuell bauen

### Teil 1: Body (als Cube)

1. **Objekt hinzufügen:**
   ```
   Shift + A
   ```
   Menu öffnet sich

2. **Mesh > Cube**
   - Ein Würfel erscheint in deiner Szene

3. **Body skalieren (zu Rechteck):**
   ```
   S        (Skalier-Mode aktiv)
   Z        (nur auf Z-Achse)
   2        (2x höher)
   Enter    (bestätigen)
   ```
   Dein Cube ist jetzt ein Rechteck (Body-Form)

---

### Teil 2: Head (als Sphere)

1. **Neue Sphere hinzufügen:**
   ```
   Shift + A → Mesh > UV Sphere
   ```

2. **Head nach oben verschieben:**
   ```
   G        (Grab-Mode)
   Z        (nur Z-Achse)
   2.5      (2.5 units nach oben)
   Enter
   ```

3. **Head kleiner machen:**
   ```
   S        (Skalier-Mode)
   0.6      (nur 60% der Größe)
   Enter
   ```

---

### Teil 3: Eyes (kleine Spheres)

1. **Linkes Auge:**
   ```
   Shift + A → Mesh > UV Sphere
   ```

2. **Positionieren (links von Head):**
   ```
   G → X → -0.2 → Enter
   G → Y → 0.3 → Enter
   G → Z → 2.8 → Enter
   ```

3. **Skalieren (klein):**
   ```
   S → 0.15 → Enter
   ```

4. **Rechtes Auge (Shift+D = Duplicate):**
   ```
   Shift + D    (Duplicate Modus)
   X → 0.4      (nach rechts spiegel)
   Enter
   ```

---

## Schritt 3: Materialien (Farben) zuweisen

Dein Avatar sieht jetzt grau aus. Lass ihn bunt werden!

### Body färben (Blau)

1. **Klick auf Body** (wird orange)

2. **Rechts Panel:**
   - Suche das grüne Kugel-Icon (**Material Properties**)
   - Klick **"New"** (neues Material)

3. **Base Color:**
   - Klick auf das Farb-Quadrat
   - Wähle Blau (#1A3A4A oder einfach blau aus der Farbpalette)
   - Klick **Done**

Body ist jetzt blau!

### Head färben (Hautfarbe)

1. **Klick auf Head** (wird orange)

2. **Rechts → Material Properties → "New"**

3. **Base Color → Hautfarbe:**
   - Hellbraun/Beige auswählen
   - Oder direkter: RGB-Werte → R: 212, G: 165, B: 116 (Hautfarbe)

4. **Done**

Head ist jetzt hautfarben!

### Eyes färben (Weiß)

1. **Klick auf linkes Auge**

2. **Material Properties → "New"**

3. **Base Color → Weiß**

4. **Done**

5. **Rechtes Auge auch weiß machen:**
   ```
   Shift + Klick auf rechtes Auge (beide selected)
   Rechts: Material von linkem Auge auf rechtes übertragen
   (Oder einfach selbst "New" + Weiß)
   ```

---

## Schritt 4: Feinschliff und Ansicht

### Alle Objekte zusammen anschauen

```
Home-Taste  (oder Numpad 0)
```

Das zoomt auf alle Objekte in deiner Szene. Du siehst deinen Avatar!

### Navigation

```
Mittl. Maus + Drag    = Orbit (drehen)
Shift + Mittl. + Drag = Pan (verschieben)
Scroll                = Zoom
```

Drehe deinen Avatar herum und schaue ihn von allen Seiten an!

### Standard-Ansichten

```
Numpad 7  = Draufsicht (schau von oben)
Numpad 1  = Vorderansicht
Numpad 3  = Seitenansicht
Home      = Fit All (zoom auf alles)
```

---

## Schritt 5: Exportieren als USDZ

1. **File > Export > Universal Scene Description (.usdz)**

2. **Dateiname eingeben:**
   ```
   Beispiel: juvantis_avatar_v1.usdz
   ```

3. **Export-Settings (rechts im Dialog):**
   - ✓ **Animations** (falls du Shape Keys hast)
   - ✓ **Materials** (damit Farben erhalten bleiben)
   - ✓ **Smoothing** (glattere Oberflächen)

4. **Klick "Export USD/USDZ"**

Fertig! Die `.usdz`-Datei ist bereit für deine iOS-App.

---

## Häufige Anfängerfehler

### Problem: "Ich sehe nichts!"

**Grund:** Modell ist außerhalb der Sicht oder zu groß/klein.

**Lösung:**
```
Home-Taste drücken (Fit All)
```

---

### Problem: "Ich kann nicht zoomen!"

**Grund:** Falscher Maus-Button.

**Lösung:** Nutze die **Mittlere** Maustaste (Scroll-Rad), nicht Links- oder Rechts-Klick!

---

### Problem: "Meine Farben sehen doof aus"

**Grund:** Material-Eigenschaften sind zu simpel.

**Lösung:**
- Erhöhe die **Metallic**-Eigenschaft (glänzend)
- Oder nutze **Roughness** (raue Oberfläche)

Im Properties-Panel (Material) findest du diese Regler.

---

### Problem: "Ich möchte Augen mit schwarzer Iris"

**Lösung:** Mach zwei Augen-Sphären pro Auge:
1. Weiße Sphere (äußeres Auge)
2. Schwarze, kleinere Sphere (Iris) — leicht nach vorne verschieben

---

## Shortcuts-Spickzettel für manuelles Arbeiten

| Shortcut | Was es macht |
|----------|--------------|
| `Tab` | Object ↔ Edit Mode |
| `G` | Verschieben (Grab) |
| `R` | Rotieren |
| `S` | Skalieren |
| `X`, `Y`, `Z` | Achse eingrenzen |
| `A` | Alles wählen |
| `Alt+A` | Alles abwählen |
| `B` | Box Select |
| `Shift+D` | Duplizieren |
| `Shift+A` | Objekt hinzufügen |
| `Home` | Fit All |
| `Scroll` | Zoom |
| `Mittl. Maus + Drag` | Orbit |

---

## Wann ist manuell besser als Claude?

- **Kleine Änderung:** "Mach den Head 10% größer" → 5 Sekunden manuell
- **Schnelle Tests:** "Wie sieht es mit roten statt blauen Haaren aus?" → Farbe ändern, sofort sehen
- **Verstehen, wie es funktioniert:** Du lernst Blender, statt nur Scripts zu kopieren

---

## Next Steps

1. **Einfacher Avatar (wie oben)** bauen und speichern
2. **Experimentieren:** Farben ändern, Objekte verschieben
3. **Exportieren:** Als USDZ speichern
4. **iOS-Test:** In deine Juvantis-App laden und anschauen

---

**💡 Merksatz:** Manuelles Modellieren ist langsamer für komplexe Dinge, aber besser für kleine Anpassungen und zum Lernen. Nutze es für Prototypen und Experimenten!
