# Design-Skills: Claude-Workflow

## Wie nutze ich die Design-Skills mit Claude?

Wenn die Skills aktiv sind (in `~/.claude/skills/` installiert), aktivieren sie sich automatisch, sobald du nach Frontend- oder Design-Aufgaben fragst. Du musst sie nicht explizit aufrufen.

---

## Beispiel-Prompts

### Einfache Website erstellen

**Was du sagst:**
> "Baue mir eine Landing Page für das Praxiszentrum Dr. Stracke & Kollegen. Teal-Farbschema."

**Was Claude intern tut:**
1. Erkennt "Landing Page" → aktiviert `frontend-design` + `ui-ux-pro-max`
2. Erkennt "Praxiszentrum" → Branche: Medizin
3. Erkennt "Teal-Farbschema" → nutzt #028090 / #00A896 / #02C39A
4. Generiert Design-System (CSS-Variablen)
5. Wählt mutige Ästhetik statt generischem Design
6. Baut die Seite

---

### Design-System zuerst generieren

**Was du sagst:**
> "Generiere ein Design-System für eine moderne SaaS-App im Bereich Gesundheitsdaten."

**Was Claude liefert:**
- CSS-Variablen (Farben, Fonts, Spacing, Shadows)
- Font-Pairing Empfehlung mit Google Fonts Link
- Stil-Empfehlung (z.B. Glassmorphism + Clean)
- Anti-Patterns die vermieden werden

---

### Stil gezielt vorgeben

**Was du sagst:**
> "Erstelle eine Portfolio-Seite im Brutalism-Stil. Schwarz-weiß mit einem roten Akzent."

**Was Claude tut:**
- Liest Brutalism-Regeln aus `ui-ux-pro-max` (dicke Borders, Monospace, roh)
- Setzt `frontend-design`-Regeln um (keine generischen Fonts, mutige Entscheidungen)
- Committet zum Stil (kein Halb-Brutalism)

---

### Komponente anfordern

**Was du sagst:**
> "Ich brauche eine Pricing-Section mit drei Tarifen. Modern, animiert."

**Was Claude tut:**
- Nutzt `21st-dev-magic` für die Komponenten-Struktur (Pricing Card Pattern)
- Nutzt `frontend-design` für Hover-Effekte und Animationen
- Nutzt `ui-ux-pro-max` für Farbpalette und Font-Pairing

---

### Juvantis-Website verbessern

**Was du sagst:**
> "Die Hero-Section auf sanexio.eu ist zu generisch. Mach sie mutiger."

**Was Claude tut:**
1. Analysiert den aktuellen Stand
2. Schlägt eine ästhetische Richtung vor (z.B. "Organic/Natural" für Health-Tech)
3. Wählt distinctive Fonts (z.B. Syne für Headlines)
4. Fügt Atmosphäre hinzu (Mesh-Gradient, Staggered Reveals)
5. Implementiert im Shopify Liquid Theme

---

### iOS-App Design

**Was du sagst:**
> "Wie sollte das Farbschema für die Juvantis iOS-App aussehen? SwiftUI."

**Was Claude tut:**
- Nutzt `ui-ux-pro-max` mit Stack-Filter: SwiftUI
- Empfiehlt Accent Color, Semantic Colors
- Liefert SF Symbols Empfehlungen
- Beachtet iOS Human Interface Guidelines

---

## Fortgeschrittene Prompts

### Mehrere Varianten vergleichen

> "Zeig mir die gleiche Landing Page in drei verschiedenen Stilen: Minimal, Glassmorphism und Editorial. Als Screenshots oder HTML-Dateien."

### Dark Mode

> "Erstelle eine Dark-Mode-Variante der Praxis-Website. Beachte: nicht einfach invertieren."

### Responsive Check

> "Die Website muss auf iPhone SE bis 27-Zoll-Monitor perfekt aussehen. Zeig mir die Breakpoints."

### Accessibility

> "Prüfe das Design auf Accessibility: Kontrast-Ratio, Touch-Targets, Keyboard-Navigation."

---

## Was du NICHT sagen musst

Die Skills liefern automatisch:
- ✅ Distinctive Fonts (du musst nicht "nimm keine generischen Fonts" sagen)
- ✅ Kohärente Farbpalette (automatisch basierend auf Branche/Kontext)
- ✅ Animationen (Page-Load, Hover-States, Transitions)
- ✅ Responsive Design (Mobile-First ist default)
- ✅ CSS-Variablen (Design-System wird automatisch angelegt)

---

## Typische Fehler vermeiden

### ❌ Zu vage
> "Mach mir eine Website"

### ✅ Besser
> "Erstelle eine Landing Page für eine Hausarztpraxis. Zielgruppe: Patienten 30-70 Jahre. Vertrauenswürdig, modern, aber nicht kalt."

### ❌ Claude den Stil wählen lassen
> "Wähle irgendein Design"

### ✅ Besser
> "Stil: Soft/Pastel mit Glassmorphism-Elementen" oder "Überrasch mich mit einer mutigen Richtung und erkläre warum"

### ❌ Zu viele Constraints
> "Nutze Inter, mach alles blau, Standard-Layout, keine Animationen"

### ✅ Besser
> "Lass den Skills freie Hand beim Design, aber halte dich ans Teal-Farbschema"

---

## Nächste Schritte

- **Installation auf dem Mac**: Siehe `01-design-skills_manuell.md`
- **Theorie & Hintergrund**: Siehe `01-design-skills.md`
- **Shopify-Integration**: Die Skills funktionieren auch mit Liquid-Templates
