# Blender: Grundlagen — Claude-Workflow

## Wann nutze ich diesen Weg?

Du brauchst den Claude-Workflow wenn:
- Du ein komplexes Avatar-Modell brauchst, das schneller entsteht
- Du Python-basierte Automatisierung nutzen möchtest
- Du kein manuelles Modellieren lernen willst, sondern schnell Ergebnisse brauchst
- Du komplexe Shape Keys oder Animationen für die iOS-App benötigst

**Beispiel aus Juvantis:** Du sagst zu Claude: "Erstelle einen Avatar mit humanoidem Körper, benutzerdefinierten Farben und Smile-Animation." Claude schreibt dir ein Blender-Python-Skript, das du dann ausführst.

---

## Der Claude-Workflow: 3 Schritte

```
1. Claude schreibt Blender-Python-Skript
      ↓
2. Du kopierst es in Blender's Scripting-Panel
      ↓
3. Du drückst Play → Avatar entsteht
      ↓
4. Exportiert als USDZ → iOS-App fertig
```

---

## Schritt 1: Prompt an Claude schreiben

Beschreib, was du in Blender haben möchtest:

**Gutes Beispiel:**
```
Erstelle ein Blender-Python-Skript, das:
- Einen humanoidalen Avatar mit Body, Head, Arms und Legs erzeugt
- Body: blauer Cylinder
- Head: hautfarbige Sphere mit großeren Augen
- Arms/Legs: dünne Cylinders
- Shape Key "Smile" für Lächeln
- USDZ-Export zu ~/avatar.usdz
```

**Schlechtes Beispiel:**
```
Mach einen Avatar
```

Claude schreibt dir dann ein komplettes Python-Skript mit `bpy`.

---

## Schritt 2: Skript in Blender kopieren

1. **Blender öffnen** (starten, Welcome-Screen schließen)
2. **Oben rechts:** Tab-Bereich → Klick auf **"Scripting"**
3. Neue Layout öffnet sich mit Python-Editor (links) und 3D Viewport (rechts)
4. **Rechts im Editor:** Klick auf **"New"** (oder **Text > Create New Text Block**)
5. **Copy-Paste:** Claudius Skript-Code einfügen

---

## Schritt 3: Skript ausführen

```
Im Scripting-Tab:
- Play-Icon drücken (oben rechts im Python-Editor)
  oder Alt + P
```

**Was passiert:**
- Das Skript läuft
- In der 3D View (rechts) siehst du in **Echtzeit**, wie dein Avatar entsteht
- Im Konsolen-Output (unten) siehst du `print()`-Ausgaben

---

## Schritt 4: USDZ exportieren

Wenn das Skript fertig ist und dein Avatar in der 3D View sichtbar ist:

1. **File > Export > Universal Scene Description (.usdz)**
2. **Dateiname:** z.B. `juvantis_avatar.usdz`
3. **Export-Settings (rechts):**
   - ✓ Animations (wenn Shape Keys da sind)
   - ✓ Materials
   - ✓ Smoothing
4. **Klick "Export USD/USDZ"**

Die `.usdz`-Datei ist jetzt für deine iOS-App bereit!

---

## Häufige Claude-Anfragen für Juvantis

### Anfrage 1: Basis-Avatar mit Farben

```
Schreib ein Blender-Skript, das:
- Body: dunkelblau (#1A3A4A)
- Head: hautfarben (#D4A574)
- Eyes: weiß mit schwarzer Iris
- Alles als USDZ speichern
```

→ Claude liefert dir ein vollständiges Skript, 1:1 einsatzbereit.

### Anfrage 2: Avatar mit Health-Visualisierung

```
Erstelle ein Python-Skript für einen Avatar, der:
- Eine "glow" Aura um den Körper zeigt (grün = gesund)
- Heart-Rate-Puls durch Material-Animation darstellt
- Verschiedene Shape Keys für Emotionen: happy, sad, neutral
- USDZ-Export mit Animations
```

→ Claude schreibt komplexere Animation-Logik für dich.

### Anfrage 3: Schnelle Modifikation

Wenn du ein bestehendes Skript ändern möchtest:

```
Änder das Skript von eben so, dass:
- Das Lächeln intensiver wird (Shape Key von 0.5 auf 0.8)
- Die Augen größer werden
- Export zu ~/new_avatar.usdz
```

→ Claude liefert das modifizierte Skript.

---

## Fehlerbehandlung

### Fehler: "ModuleNotFoundError: No module named 'bpy'"

**Grund:** Du versuchst, das Skript außerhalb von Blender auszuführen.

**Lösung:** Immer im **Blender Scripting-Tab** ausführen, nicht in Terminal!

---

### Fehler: "No context data"

**Grund:** Keine aktive Szene oder keine passende Struktur.

**Lösung:** Am Anfang des Skripts saubere Szene:
```python
import bpy
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
# Jetzt frisch bauen
```

Claude schreibt das normalerweise bereits ein, aber falls nicht, frag danach.

---

## Tipps und Best Practices

### Tip 1: Incremental Workflow

Statt alles auf einmal zu schreiben, bau iterativ:

```
1. Claude schreibt Basis-Avatar-Skript
2. Du testest → Größe passt nicht
3. Du fragst Claude: "Skaliere alles 1.5x größer"
4. Claudius modifiziertes Skript → Neuer Test
```

Das ist schneller und sicherer als großes Trial-and-Error.

### Tip 2: Unterschiedliche Varianten

```
Claude, schreib mir 2 Varianten des Avatar-Skripts:
- Variant 1: Minimalistisch (wenig Polygone, schnell)
- Variant 2: Detail-Modell (viele Polygone, schön)
```

Dann testets du beide und wählst eine für iOS.

### Tip 3: Kommentare nutzen

Frag Claude nach gut-kommentierten Skripten:

```
Schreib das Skript mit ausführlichen Kommentaren,
damit ich verstehe, welcher Teil was macht.
```

Das hilft dir, das Skript später zu verändern.

---

## Next Steps

1. **Einfaches Test-Skript:** Frag Claude nach einem einfachen "Hello Avatar"-Skript
2. **Kopieren & Ausführen:** In Blender Scripting-Tab → Play
3. **Variationen:** Ändere Farben, Größe, Shapes → Claude schreibt neues Skript
4. **Export:** Als USDZ speichern → In deine iOS-App laden

---

**💡 Merksatz:** Mit Claude-Workflow sparst du Stunden beim Modellieren. Dein Job ist, gute Prompts zu schreiben, Claudius Job ist, Python-Code zu schreiben, der in Blender läuft.
