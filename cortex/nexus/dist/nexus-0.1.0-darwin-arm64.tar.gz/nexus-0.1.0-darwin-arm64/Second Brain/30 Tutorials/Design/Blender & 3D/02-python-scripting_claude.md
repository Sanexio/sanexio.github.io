# Blender: Python Scripting — Claude-Workflow

## Wann nutze ich diesen Weg?

Du brauchst den Claude-Workflow wenn:
- Du komplexe Animationen oder Shape Keys brauchst (nicht einfach per Hand)
- Du hunderte von ähnlichen Objekten generieren möchtest
- Du mathematische Berechnungen für Modelle brauchst
- Du Parameter ändern möchtest, ohne Code zu schreiben (Claude macht das für dich)

**Beispiel aus Juvantis:** Du brauchst ein Avatar-Modell mit 10 verschiedenen "Expressions" (Smile, Surprised, Sad, etc.). Claude schreibt ein Skript, das alle Shape Keys auf einmal erstellt. Du brauchst nur noch den Play-Button zu drücken.

---

## Der Claude-Workflow: Script-Erstellung

```
1. Du beschreibst, was du brauchst (mit Details!)
      ↓
2. Claude schreibt Blender-Python-Skript (mit bpy)
      ↓
3. Du kopierst in Blender Scripting-Tab
      ↓
4. Du drückst Play → Skript läuft
      ↓
5. Falls Fehler: Du fragst Claude um Anpassung
      ↓
6. Exportierst USDZ
```

---

## Gute Prompts für Claude schreiben

### Beispiel 1: Avatar mit Shape Keys

**GUTER Prompt:**
```
Schreib ein Blender-Python-Skript, das:
1. Einen humanoidalen Avatar erstellt (Cube für Body, Sphere für Head)
2. 5 Shape Keys für Mimik:
   - "Smile": Mund-Ecken nach oben
   - "Sad": Augen zusammenkneifen
   - "Surprised": Augen weit öffnen
   - "Wink": Ein Auge schließen
   - "Blink": Beide Augen schließen
3. Jeder Shape Key sollte realistisch animiert sein
4. Farben: Body blau, Head hautfarben, Eyes weiß
5. Exportiere als ~/avatar_expressions.usdz mit Animations
```

**SCHLECHTER Prompt:**
```
Mach mir Shape Keys für Mimik
```

Der gute Prompt hat **Kontext, Details, Reihenfolge**. Claude versteht sofort, was zu tun ist.

---

### Beispiel 2: Modell mit Parametern

**GUTER Prompt:**
```
Erstelle ein Python-Skript mit Parametern am Anfang:
- avatar_height = 2.0
- body_width = 0.5
- head_size = 0.6
- skin_color = (1.0, 0.8, 0.7)  # RGB
- body_color = (0.2, 0.5, 1.0)

Das Skript soll einen Avatar mit diesen Parametern bauen.
Später kann ich diese Werte ändern und nur Play drücken,
ohne den Code zu editieren.
```

→ Claude schreibt parametrisiertes Skript. Du änderst nur die Zahlen oben!

---

### Beispiel 3: Komplexe Animation

**GUTER Prompt:**
```
Schreib ein Blender-Skript, das:
- Einen Avatar mit Körper und Gliedmaßen erstellt
- Eine "Heart Beat" Animation: Der Körper pulsiert leicht
  - 30 Frames Animation
  - Heartbeat von 60 BPM (eine Schlag pro Sekunde)
- Eine "Breathing" Animation: Oberkörper bewegt sich leicht auf/ab
  - 60 Frames (2 Sekunden)
  - Natürliches Atmen-Tempo
- Beide Animationen zusammen spielen
- USDZ-Export mit Animations (30 FPS)
```

→ Claude erstellt komplexe Keyframe-Animationen für dich!

---

## Workflow im Detail: Fehlerbehandlung

### Fehler 1: "NameError: name 'xyz' is not defined"

**Das bedeutet:** Claude hat eine Variable vergessen oder falsch benannt.

**Was du fragst:**
```
Das Skript gibt den Fehler:
NameError: name 'bpy' is not defined

Was fehlt?
```

**Claude antwortet:**
```
Ah, sorry! Am Anfang muss stehen:
import bpy
```

Er gibt dir die Zeile zum Einfügen.

### Fehler 2: "Operator bpy.ops... poll() failed"

**Das bedeutet:** Der Befehl funktioniert nicht im Blender-Kontext.

**Was du fragst:**
```
Das Skript bricht ab mit:
RuntimeError: Operator bpy.ops.mesh.primitive_cube_add() poll() failed

Das Modell wird nicht erstellt. Wie fixe ich das?
```

**Claude schreibt um auf Low-Level API:**
```python
# Statt bpy.ops (häufig fehleranfällig)
# Nutze Low-Level API:
mesh = bpy.data.meshes.new("BodyMesh")
obj = bpy.data.objects.new("Body", mesh)
bpy.context.collection.objects.link(obj)
```

### Fehler 3: Shape Keys funktionieren nicht richtig

**Was du fragst:**
```
Die Shape Keys werden erstellt, aber die Vertices bewegen sich nicht.
Der Shape Key "Smile" hat keinen visuellen Effekt.

Wie ändere ich Shape Keys mit Vertex-Verschiebungen?
```

**Claude erklärt und gibt Code für BMesh-Manipulation.**

---

## Iterativer Workflow: Anfang bis Ende

### Phase 1: Basis erstellen

```
Du: "Schreib ein Python-Skript für einen Avatar mit Body, Head, Arms"
Claude: [komplettes Skript]
Du: kopierst, spielst ab → Avatar da!
```

### Phase 2: Anpassungen

```
Du: "Der Avatar ist zu klein. Skaliere alles 1.5x größer."
Claude: [modifiziertes Skript]
Du: kopierst, spielst ab → Avatar größer!
```

### Phase 3: Shape Keys hinzufügen

```
Du: "Füge 3 Shape Keys hinzu: Smile, Frown, Neutral"
Claude: [erweitertes Skript mit Shape Keys]
Du: kopierst, spielst ab → Animations da!
```

### Phase 4: Export konfigurieren

```
Du: "Exportiere mit Animations als ~/final_avatar.usdz"
Claude: [Export-Code wird hinzugefügt]
Du: spielst ab → USDZ wird automatisch erstellt!
```

---

## Spezielle Claude-Prompts für Juvantis

### Health-Avatar mit Glow

```
Schreib ein Skript, das:
- Einen Avatar mit Körper, Kopf, Armen erstellt
- Eine "Glow"-Animation um den Körper
  - Grün für guten Health Score
  - Orange für mittelmäßig
  - Rot für schlecht
- Shape Key "Healthy" und "Unhealthy"
- USDZ-Export mit allen Animations
```

### Avatar mit mehreren Skins

```
Erstelle ein Skript mit Liste von Skins:
skins = [
  {"name": "Standard", "body_color": (0.2, 0.5, 1.0)},
  {"name": "Sport", "body_color": (1.0, 0.2, 0.2)},
  {"name": "Professional", "body_color": (0.1, 0.1, 0.1)},
]

Das Skript sollte automatisch alle 3 Varianten erstellen
und separat exportieren.
```

### Avatar für Bewegungsanalyse

```
Schreib ein Skript, das:
- Einen Avatar mit markierten Gelenken erstellt
  (kleine rote Kugeln an Knöcheln, Knien, Hüften, etc.)
- Skelett-Struktur für Motion Capture
- Shape Keys für verschiedene Bewegungen:
  - "Walk" (eine Schritt-Position)
  - "Run" (Lauf-Position)
  - "Jump" (Sprung-Position)
- USDZ mit allen Variations
```

---

## Best Practices beim Scripting mit Claude

### Best Practice 1: Kommentare verlangen

```
Schreib das Skript mit ausführlichen Kommentaren
auf Deutsch, damit ich verstehe, was jede Sektion macht.
```

Claude schreibt dann:
```python
# 1. SETUP: Blender importieren und Szene löschen
import bpy
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# 2. BODY: Blauen Cylinder für Körper erstellen
bpy.ops.mesh.primitive_cylinder_add(...)
# usw.
```

### Best Practice 2: Fehlerbehandlung einbauen

```
Baue Fehlerbehandlung ein, damit das Skript
nicht abstürzt, wenn etwas fehlt:
- Check: Ist ein Objekt vorhanden?
- If not: Erstelle es
- Gib aussagekräftige Fehlermeldungen aus
```

Claude schreibt:
```python
if obj.type != 'MESH':
    print("FEHLER: Kein Mesh-Objekt!")
    sys.exit(1)
```

### Best Practice 3: Separates Testskript

```
Schreib zwei Versionen:
1. test_avatar.py - minimal, schnell, für Tests
2. final_avatar.py - komplett mit allen Details

Ich teste erst mit test_avatar, wenn es OK ist,
nutze ich final_avatar.
```

---

## Tipps zum Debuggen

### Fehlerausgang ansehen

Blender Scripting-Tab:
- **Unten rechts:** System Console ist offen
- Dort siehst du `print()`-Ausgaben und Fehler
- Klick auf **"Toggle Console Window"** um sie größer zu machen

### Intermediate Prints einbauen

Frag Claude:
```
Füge print()-Statements ein nach jedem Schritt:
1. Nach Cube-Erstellung
2. Nach Shape Key-Erstellung
3. Vor Export

Damit sehe ich im Konsolen-Output, wo das Skript ist.
```

### Testweise mit kleinerem Modell

```
Mach erst eine "Light"-Version des Skripts:
- Nur Body + Head (keine Arms, Legs, Eyes)
- Nur 2 Shape Keys statt 10
- Schneller Export

Wenn das funktioniert, bau ich auf zu full_avatar.
```

---

## Next Steps

1. **Einfaches Claude-Skript:** Frag Claude nach "Avatar mit Body, Head, Arms"
2. **Kopieren & Testen:** In Blender Scripting-Tab → Play
3. **Fehler beheben:** Falls Error, Fehlermeldung zu Claude
4. **Iterativ erweitern:** Shape Keys, Farben, Animationen
5. **Export:** USDZ zum Finalen Avatar

---

**💡 Merksatz:** Gute Prompts → gute Skripte. Je genauer du beschreibst, was du brauchst, desto besser wird Claudius Code. Nutze jede Iteration zum Lernen.
