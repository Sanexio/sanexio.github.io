# Tutorial: Blender MCP Server — Claude Code direkt mit Blender verbinden

**ID:** TUT-BLE-003
**Stand:** 2026-04-11 (erweitert um cluster-mini-02-Setup)
**Voraussetzung:** Tutorial 01 (Grundlagen), Tutorial 02 (Python Scripting)
**Kontext:** Juvantis / Digital Health Twin — Avatar-Pipeline

> **Drei-Dateien-Regel (TUT-001):** Dieses Tutorial erklärt die Theorie und die
> Fehlerdiagnose. Die konkreten Schritt-für-Schritt-Installationen stehen in:
> - `03-blender-mcp-setup_claude.md` — **automatisierter** Weg (Claude
>   installiert alles selbst per Skript, keine Klicks nötig)
> - `03-blender-mcp-setup_manuell.md` — **manueller** Weg (GUI-Klickanleitung)
>
> **Geräte-Hinweis:** Die ursprüngliche Installation (Abschnitte weiter unten)
> wurde 2026-04-10 auf dem Mac `ssmd` mit `pip3 install blender-mcp`
> durchgeführt. Auf `cluster-mini-02` (2026-04-11) wurde ein schlankerer Weg
> genommen: `brew install uv` + direkte `addon.py` aus GitHub. Beide Wege sind
> gültig; auf neuen Rechnern bevorzugt den Weg aus `_claude.md`.

---

## Was ist Blender MCP?

Bisher musste Claude Code Blender-Skripte erstellen, die du manuell in Blender
ausführst (Alt+P im Scripting-Tab). Mit **Blender MCP** kann Claude Code
Blender **direkt steuern** — Objekte erstellen, löschen, Materialien setzen,
exportieren — alles ohne manuelles Kopieren.

### Architektur (3 Schichten)

```
Claude Code ←(stdio)→ blender-mcp Server (Python) ←(TCP:9876)→ Blender Addon
```

**Schicht 1: Blender Addon**
- Läuft innerhalb von Blender als Python-Addon
- Öffnet einen TCP-Socket auf Port 9876
- Empfängt JSON-Befehle und führt sie über Blenders Python-API (bpy) aus

**Schicht 2: blender-mcp Server**
- Eigenständiger Python-Prozess (installiert via `pip install blender-mcp`)
- Wird von Claude Code per stdio gestartet und gesteuert
- Übersetzt MCP-Tool-Aufrufe in TCP-Befehle an das Blender-Addon
- Ist die "Brücke" zwischen Claude Code und Blender

**Schicht 3: Claude Code**
- Liest die MCP-Konfiguration beim Start aus `.mcp.json` oder `~/.claude.json`
- Startet den blender-mcp Server automatisch als Kindprozess
- Bekommt Blender-Tools (Objekte erstellen, Material setzen, etc.) in seine Tool-Liste

**Wichtig:** Claude Code lädt MCP-Server **nur beim Start**. Wenn die Config
nachträglich geändert wird oder Blender noch nicht läuft, muss Claude Code
neu gestartet werden.

---

## Installation

### Schritt 1: blender-mcp Python-Paket installieren

```bash
pip3 install blender-mcp
```

Prüfen:
```bash
pip3 show blender-mcp
# Sollte Version 1.5.6+ zeigen
```

### Schritt 2: Blender-Addon installieren

Das Addon wird mit dem pip-Paket mitgeliefert. Installation in Blender:

1. Blender öffnen → Edit → Preferences → Add-ons
2. Oben rechts: "Install from Disk" klicken
3. Navigiere zum Addon-Pfad:
   ```bash
   # Pfad finden:
   python3 -c "import blender_mcp; print(blender_mcp.__file__)"
   # Das Addon liegt im selben Verzeichnis als addon.py
   ```
4. `addon.py` auswählen → "Install Add-on"
5. In der Addon-Liste: "BlenderMCP" aktivieren (Checkbox)

### Schritt 3: MCP in Claude Code registrieren

**Methode A — User-Scope (empfohlen, kein GDrive-Problem):**
```bash
claude mcp add blender -- /Users/ssmd/.local/bin/uvx blender-mcp
```

**Methode B — Project-Scope (.mcp.json im Projektordner):**
```json
{
  "mcpServers": {
    "blender": {
      "command": "uvx",
      "args": ["blender-mcp"]
    }
  }
}
```

**Hinweis:** Methode B funktioniert NICHT zuverlässig auf GDrive wegen EDEADLK-Locks.
Auf lokalem Dateisystem oder iCloud ist Methode B vorzuziehen.

---

## Workflow bei jeder Session

**Reihenfolge ist kritisch — ERST Blender, DANN Claude Code:**

1. **Blender öffnen** und Projekt/Datei laden
2. **MCP Server starten:**
   - Im 3D-Viewport: `N` drücken (Seitenleiste rechts öffnen)
   - Tab **"BlenderMCP"** wählen
   - **"Start MCP Server"** klicken
   - Status muss zeigen: "Running on port 9876"
3. **Verifizieren dass der Port offen ist:**
   ```bash
   lsof -i :9876
   # Muss einen Python-Prozess zeigen
   ```
4. **Claude Code starten** (im Juvantis-Ordner)
5. **MCP-Status prüfen:**
   ```
   /mcp
   ```
   "blender" muss Status **"connected"** zeigen.
6. **Beim ersten Mal:** Claude Code fragt nach Bestätigung ("Allow MCP server?") → **Yes**

---

## Bekannte Probleme und Lösungen

### Problem 1: "No route to host" (Errno 65)

**Symptom:** blender-mcp startet, kann aber Blender nicht erreichen.
```
BlenderMCPServer - ERROR - Failed to connect to Blender: [Errno 65] No route to host
```

**Ursache:** Das Blender-Addon hat den TCP-Socket nicht korrekt geöffnet.
Die UI zeigt "Running on port 9876", aber `lsof -i :9876` zeigt nichts.

**Diagnose:**
```bash
# Prüfen ob IRGENDETWAS auf 9876 lauscht:
lsof -i :9876

# Wenn leer: Blender-Addon hat den Socket nicht gebunden
```

**Lösung:**
1. In Blender: "Disconnect from MCP server" klicken
2. 5 Sekunden warten
3. "Start MCP Server" erneut klicken
4. `lsof -i :9876` prüfen

Falls das wiederholt fehlschlägt:
- Blender komplett schließen und neu öffnen
- Addon deaktivieren und wieder aktivieren (Preferences → Add-ons)
- Blender-Version prüfen (4.x empfohlen)
- Addon neu installieren (neueste Version von pip)

### Problem 2: "Connection refused" (Errno 61)

**Symptom:** blender-mcp versucht sich zu verbinden, wird aber abgewiesen.

**Ursache:** Blender-Addon läuft nicht oder wurde noch nicht gestartet.

**Lösung:** N-Panel → BlenderMCP → "Start MCP Server"

### Problem 3: Claude Code zeigt keine Blender-Tools

**Symptom:** `/mcp` zeigt "blender" nicht oder mit Status "failed".

**Mögliche Ursachen:**

| Ursache | Prüfung | Lösung |
|---------|---------|--------|
| Config nicht gefunden | `claude mcp list` im Terminal | `claude mcp add blender -- uvx blender-mcp` |
| GDrive-Lock auf .mcp.json | Nur bei GDrive-Pfad | User-Scope verwenden (Methode A) |
| uvx nicht im PATH | `which uvx` | Vollständigen Pfad in Config angeben |
| blender-mcp Paket fehlt | `pip3 show blender-mcp` | `pip3 install blender-mcp` |
| Server startet mit Fehler | `uvx blender-mcp 2>&1` im Terminal testen | Fehlerausgabe lesen |
| Approval abgelehnt | `/mcp` zeigt "denied" | `claude mcp reset-project-choices` |

### Problem 4: .mcp.json wird auf GDrive nicht gelesen (EDEADLK)

**Symptom:** Claude Code ignoriert die .mcp.json im Projektordner.

**Ursache:** GDrive-Dateisystem-Lock (Errno 35 / EDEADLK). Betrifft alle
Dateien auf Google Drive — sowohl Binärdateien als auch Textdateien.

**Lösung:** MCP per User-Scope registrieren:
```bash
claude mcp add blender -- /Users/ssmd/.local/bin/uvx blender-mcp
```
Das schreibt in `~/.claude.json` (lokal, kein GDrive).

**Langfristige Lösung:** Claude-OS von GDrive auf lokales Dateisystem oder
iCloud migrieren. Dann funktioniert `.mcp.json` im Projektordner zuverlässig.

### Problem 5: Zwei MCP-Einträge (blender + blender-mcp)

**Symptom:** `/mcp` zeigt "blender" UND "blender-mcp" — beide failed.

**Ursache:** Doppelte Registrierung (einmal per CLI, einmal per .mcp.json).

**Lösung:**
```bash
claude mcp remove blender-mcp
```
Nur einen Eintrag behalten.

---

## Nützliche Diagnose-Befehle

```bash
# MCP-Server auflisten:
claude mcp list

# Blender-Port prüfen:
lsof -i :9876

# blender-mcp isoliert testen (zeigt Startup-Fehler):
/Users/ssmd/.local/bin/uvx blender-mcp 2>&1 | head -20

# Python-Socket-Test zu Blender:
python3 -c "import socket; s=socket.socket(); s.settimeout(3); s.connect(('127.0.0.1', 9876)); print('OK'); s.close()"

# Addon-Pfad finden:
python3 -c "import blender_mcp; import os; print(os.path.dirname(blender_mcp.__file__))"

# MCP-Approval zurücksetzen:
claude mcp reset-project-choices

# Duplikat entfernen:
claude mcp remove blender-mcp
```

---

## Zusammenhang mit der Avatar-Pipeline

Nach erfolgreicher MCP-Verbindung kann Claude Code:
- GLB-Dateien direkt in Blender laden (z.B. `avaturn_sick.glb`)
- Meshes deformieren (Adipositas-Simulation, Belly/Flanken-Expansion)
- Materialien ändern (Yellow-Tint für Steatosis)
- Ergebnisse als GLB exportieren
- Alles ohne manuelles Alt+P — direkt aus dem Cursor-Terminal

**Bestehende Skripte als Referenz:**
- `avaturn_adipose.py` — Bone-Scaling-Ansatz (funktioniert NICHT mit model-viewer)
- `avaturn_adipose_vertex.py` — Vertex-Deformation (funktioniert, bevorzugt)
- `build_avatar_variants.py` — Mixamo-Varianten (Prototyp v0.1)

Die Logik dieser Skripte kann Claude Code jetzt interaktiv über MCP anwenden,
statt sie headless auszuführen.

---

**Version:** 1.0
**Erstellt:** 2026-04-10
**Nächstes Tutorial:** 04-troubleshooting.md (allgemeines Blender-Troubleshooting)
