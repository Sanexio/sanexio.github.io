# Design-Skills für Claude: Professionelle Frontends ohne AI-Slop

## Was lernst du hier?

Wenn Claude Websites, Apps oder Frontends baut, sehen die Ergebnisse oft gleich aus: dieselben Fonts (Inter, Roboto), dieselben Farben (lila Gradienten auf weiß), dieselbe Struktur. Das nennt man **"AI-Slop"** — generisches KI-Design ohne Charakter.

In diesem Tutorial lernst du:
- Was Design-Skills sind und warum sie funktionieren
- Welche drei Skills wir installiert haben und was jeder tut
- Wie die Skills zusammenarbeiten
- Wie du sie auf deinem Mac aktivierst

**Warum brauche ich das?** Weil du damit:
- Websites bekommst, die professionell und einzigartig aussehen
- Kein generisches KI-Design mehr akzeptieren musst
- Klare Kontrolle über Farben, Fonts und Stil hast
- Von einer Datenbank mit 84+ Styles, 161 Farbpaletten und 57 Font-Pairings profitierst

---

## Hintergrund: Warum sehen KI-Frontends gleich aus?

Claude (und alle KI-Modelle) lernen aus riesigen Mengen von Code. Wenn man ohne spezielle Anweisungen nach einem Frontend fragt, wählt Claude den "statistisch sichersten" Weg:

- **Font**: Inter (am häufigsten im Training)
- **Farbe**: Blau/Lila auf Weiß (häufigstes Muster)
- **Layout**: Zentrierter Header, drei Spalten, Footer
- **Animation**: Keine (sicherste Wahl)

Das Ergebnis: Alles sieht aus wie eine Template-Website von 2023.

**Design-Skills** lösen dieses Problem, indem sie Claude VOR dem Coden klare Regeln geben:
- Welche Fonts verboten sind
- Welche Design-Richtungen möglich sind
- Welche Farbkombinationen zusammenpassen
- Welche UX-Patterns professionell wirken

---

## Die drei Design-Skills im Überblick

Wir haben drei Skills installiert, die sich ergänzen:

```
┌──────────────────────────────────────────────────────────┐
│                    DESIGN-WORKFLOW                        │
│                                                          │
│  1. UI-UX Pro Max        → Design-System generieren      │
│     (Farben, Fonts,        (WAS wählen wir?)             │
│      Style-Datenbank)                                    │
│                                                          │
│  2. Frontend Design      → Ästhetische Richtung          │
│     (Kreativ-Regeln,       (WIE setzen wir es um?)       │
│      Anti-Patterns)                                      │
│                                                          │
│  3. 21st.dev Magic       → Komponenten bauen             │
│     (UI-Bibliothek,        (WOMIT bauen wir es?)         │
│      fertige Elemente)                                   │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

### Skill 1: Frontend Design

**Quelle**: Anthropic (offiziell) — https://github.com/anthropics/claude-code
**Datei**: `Claude-OS/skills/frontend-design/SKILL.md`

Dieses Skill ist das "Gehirn" für kreative Entscheidungen. Es sagt Claude:

- **Fonts**: Niemals Inter, Roboto, Arial, Open Sans verwenden. Stattdessen mutige Fonts wählen (Playfair Display, JetBrains Mono, Bricolage Grotesque, etc.)
- **Farben**: Keine lila Gradienten auf weiß. Dominant-Farbe + scharfer Akzent statt zaghafter Gleichverteilung.
- **Layout**: Unerwartete Layouts, Asymmetrie, Overlap. Nicht das Standard-Grid.
- **Animation**: Ein gut orchestrierter Page-Load schlägt verstreute Micro-Interactions.
- **Hintergründe**: Atmosphäre und Tiefe statt solider Farben.

**Kern-Prinzip**: "Wähle eine klare konzeptuelle Richtung und setze sie mit Präzision um. Mutiger Maximalismus und raffinierter Minimalismus funktionieren beide — der Schlüssel ist Intentionalität, nicht Intensität."

**Stil-Optionen**: Brutal Minimal, Maximalist Chaos, Retro-Futuristic, Organic/Natural, Luxury/Refined, Playful, Editorial/Magazine, Brutalist/Raw, Art Deco, Soft/Pastel, Industrial.

---

### Skill 2: UI-UX Pro Max

**Quelle**: nextlevelbuilder — https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
**Datei**: `Claude-OS/skills/ui-ux-pro-max/SKILL.md`

Dieses Skill ist die "Datenbank" — ein Nachschlagewerk mit konkreten Design-Daten:

| Inhalt | Menge | Beispiele |
|--------|-------|-----------|
| Styles | 84+ | Glassmorphism, Brutalism, Neumorphism, Bento Grid |
| Farbpaletten | 161 | Nach Stimmung, Branche, Kontext |
| Font-Pairings | 57 | Getestete Heading+Body-Kombinationen |
| Produkt-Typen | 161 | SaaS, E-Commerce, Portfolio, Dashboard |
| UX-Guidelines | 99 | Accessibility, Animation, Layout, Typografie |
| Chart-Typen | 25 | Bar, Line, Pie, Scatter, Heatmap |
| Tech-Stacks | 10 | React, Next.js, Vue, SwiftUI, Flutter |

**Was es tut**: Wenn du sagst "Erstelle eine Website für eine Arztpraxis", durchsucht der Skill die Datenbank und findet automatisch:
- Passende Branchenfarben (Teal, Arctic Clean)
- Passende Fonts (Seriös + Lesbar)
- Passenden Stil (Clean, Minimalist, Trust-focused)
- UX-Regeln für den Kontext (Accessibility, Touch-Targets, Kontrast)

Es generiert dann ein vollständiges **Design-System** mit CSS-Variablen, das Claude als Grundlage für die Implementierung nutzt.

**Branchenpaletten** (Auszug):

| Branche | Empfohlene Palette | Begründung |
|---------|-------------------|------------|
| Medizin | Arctic Clean / Teal Trust | Vertrauen, Sauberkeit |
| Finanzen | Midnight Ocean | Seriosität |
| Tech/SaaS | Neon Cyber | Innovation |
| E-Commerce | Sunset Warm | Kaufimpuls |

---

### Skill 3: 21st.dev Magic

**Quelle**: 21st.dev — https://github.com/21st-dev/magic-mcp
**Datei**: `Claude-OS/skills/21st-dev-magic/SKILL.md`

Dieses Skill ist die "Werkstatt" — eine Bibliothek mit fertigen, professionellen UI-Komponenten:

- **Navigation**: Navbar, Sidebar, Breadcrumbs, Tabs
- **Hero Sections**: Split, Full-Screen, Animated, Video, Minimal
- **Cards**: Product, Blog, Pricing, Team, Stats
- **Formulare**: Contact, Login, Multi-Step, Search, File Upload
- **Feedback**: Toast, Modal, Tooltip, Alert, Skeleton Loader
- **Data Display**: Table, Timeline, Accordion, Badge, Avatar Group
- **Marketing**: CTA, Testimonial, Feature Grid, Logo Wall, Newsletter

**Besonderheit**: 21st.dev bietet zusätzlich einen **MCP-Server** an. Das ist ein Service, der direkt in Claude Code oder Cursor integriert werden kann. Wenn aktiv, kann Claude `/ui create a pricing card` eingeben und bekommt sofort eine professionelle Komponente generiert.

**Für den MCP-Server brauchst du**: Einen API-Key von https://21st.dev (kostenloser Account möglich).

---

## Wie die Skills zusammenarbeiten

Hier ein konkretes Beispiel. Du sagst: *"Baue mir eine Landing Page für das Praxiszentrum."*

**Ohne Design-Skills** (vorher):
→ Inter Font, blaue Buttons, weißer Hintergrund, generisches Layout. Langweilig.

**Mit Design-Skills** (jetzt):

1. **UI-UX Pro Max** aktiviert sich und denkt:
   - Branche: Medizin → Teal Trust Palette (#028090, #00A896, #02C39A)
   - Produkt-Typ: Arztpraxis-Website → Vertrauen, Seriösität, Zugänglichkeit
   - Font-Pairing: Satoshi (Headlines) + Source Serif 4 (Body)
   - Style: Clean Minimalism mit sanften Akzenten
   - Generiert CSS-Variablen als Design-System

2. **Frontend Design** aktiviert sich und ergänzt:
   - Ästhetische Richtung: Luxury/Refined (passend zu Arztpraxis)
   - Hintergrund: Subtiler Mesh-Gradient statt flaches Weiß
   - Animation: Staggered Reveal beim Page-Load
   - Layout: Asymmetrisches Hero-Section mit Overlap-Elementen
   - Typ-Extreme: Heading 900-Weight, Body 300-Weight

3. **21st.dev Magic** liefert die Bausteine:
   - Hero Section: Split-Variante mit Bild rechts
   - Feature Grid: Bento-Layout mit Icons
   - Testimonial: Slider mit Sterne-Rating
   - Contact Form: Multi-Step mit Validierung
   - Footer: Kompakt mit Social Links

Das Ergebnis sieht aus, als hätte ein Designer es gemacht — nicht eine KI.

---

## Wo liegen die Dateien?

```
Claude-OS/
├── skills/
│   ├── frontend-design/
│   │   └── SKILL.md          ← 186 Zeilen, Kreativ-Regeln
│   ├── ui-ux-pro-max/
│   │   └── SKILL.md          ← 338 Zeilen, Design-Datenbank
│   └── 21st-dev-magic/
│       └── SKILL.md          ← 141 Zeilen, Komponenten-Katalog
```

Die Skills liegen aktuell im `Claude-OS/skills/`-Ordner als **Quell-Dateien**. Um sie zu aktivieren, müssen sie nach `~/.claude/skills/` auf deinem Mac kopiert werden (siehe nächster Abschnitt: Manuelle Installation).

---

## Was bedeutet "SKILL.md"?

Jeder Skill besteht aus einer `SKILL.md`-Datei mit zwei Teilen:

**1. YAML-Frontmatter** (zwischen `---` Markern):
```yaml
---
name: frontend-design
description: >
  Frontend Design Skill für professionelle UI-Entwicklung...
autoTrigger: true
---
```
Das sagt Claude: "Wann soll dieser Skill aktiviert werden?" Die `description` enthält Keywords, bei denen der Skill automatisch geladen wird.

**2. Markdown-Inhalt** (nach dem Frontmatter):
Die eigentlichen Anweisungen, Regeln und Datenbanken. Das ist der Text, den Claude liest und befolgt, wenn der Skill aktiv ist.

---

## Glossar

| Begriff | Bedeutung |
|---------|-----------|
| **AI-Slop** | Generisches, langweiliges KI-Design ohne Charakter |
| **Design-System** | Festgelegte Farben, Fonts, Abstände als CSS-Variablen |
| **Font-Pairing** | Zwei Schriftarten, die harmonisch zusammenpassen |
| **Glassmorphism** | Milchglas-Effekt mit `backdrop-filter: blur()` |
| **Neumorphism** | Soft-3D-Effekt durch doppelte Schatten |
| **Brutalism** | Bewusst rohe, unpolierte Ästhetik |
| **Bento Grid** | Ungleichmäßiges Grid-Layout (wie eine Bento-Box) |
| **MCP-Server** | Model Context Protocol — Dienst, der Claude Zugriff auf externe Tools gibt |
| **SKILL.md** | Die Datei, die einen Claude-Skill definiert |
| **Frontmatter** | Metadaten am Anfang einer Markdown-Datei (zwischen `---`) |
| **CSS-Variablen** | Wiederverwendbare Werte in CSS: `--color-primary: #028090` |
| **Staggered Reveal** | Elemente erscheinen nacheinander mit kurzer Verzögerung |

---

## Nächste Schritte

- **Installation**: Siehe `01-design-skills_manuell.md` für die Schritt-für-Schritt-Anleitung
- **Claude-Workflow**: Siehe `01-design-skills_claude.md` für Beispiel-Prompts
- **Shopify**: Die Skills können auch für Juvantis-Website-Design genutzt werden
- **iOS**: UI-UX Pro Max enthält auch SwiftUI-Guidelines für die Juvantis-App
