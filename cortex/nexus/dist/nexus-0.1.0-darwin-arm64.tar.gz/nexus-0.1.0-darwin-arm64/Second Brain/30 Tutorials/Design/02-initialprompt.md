# Initialprompt: Wie Claude-OS sich selbst steuert

## Was lernst du hier?

Claude hat kein Langzeitgedächtnis zwischen Sessions. Jede neue Konversation startet
bei Null — Claude weiß nicht, was in der letzten Session passiert ist, welche Fehler
gemacht wurden oder welche Regeln gelten.

Die Lösung: **CLAUDE.md** — eine Datei, die bei JEDER Session automatisch gelesen wird.
Dort steht alles, was Claude wissen muss, bevor eine Aufgabe beginnt.

In diesem Tutorial lernst du:
- Was CLAUDE.md ist und warum sie so wichtig ist
- Was der "Initialprompt" ist und wie er funktioniert
- Wie das selbstlernende System aus Fehlern lernt
- Warum Claude manchmal trotzdem Regeln "vergisst" — und wie wir das verhindern

---

## Das Problem: Claude vergisst alles

Stell dir vor, du hättest einen sehr fähigen Mitarbeiter, der jeden Morgen komplett
vergisst, was gestern passiert ist. Er kennt weder die Praxis-Regeln, noch die
Fehler der letzten Woche, noch wo die Dateien liegen.

Das ist genau, was bei jeder neuen Claude-Session passiert. Die einzige Möglichkeit,
dieses "Gedächtnis" herzustellen, ist über Dateien, die Claude am Anfang liest.

---

## Die Lösung: Drei Schichten des Gedächtnisses

```
Schicht 1: CLAUDE.md          ← Wird AUTOMATISCH geladen (Betriebshandbuch)
Schicht 2: MEMORY.md          ← Muss aktiv gelesen werden (Gedächtnis)
Schicht 3: GLOBAL_RULES.md    ← Muss aktiv gelesen werden (Regelwerk)
```

### Schicht 1: CLAUDE.md (automatisch)

Diese Datei wird von Cowork/Claude Code automatisch bei jeder Session geladen.
Das ist wie das Handbuch, das auf dem Schreibtisch liegt, wenn der Mitarbeiter
morgens zur Arbeit kommt.

**Wo sie liegt:** `Claude-OS/CLAUDE.md` (Projekt-Ebene)
**Was drin steht:**
- Wer der Nutzer ist (Dr. Stracke, Praxis, Rolle)
- Welche Projekte existieren und wie sie aufgebaut sind
- Der **Initialprompt** (die verbindliche Checkliste)
- Technische Details (SmartQ, GDrive, Farbschema)

Es gibt auch eine **globale CLAUDE.md** unter `.claude/CLAUDE.md`, die für ALLE
Projekte gilt (nicht nur Claude-OS). Dort steht eine Kurzversion des Initialprompts.

### Schicht 2: MEMORY.md (muss gelesen werden)

Das ist das eigentliche "Gedächtnis". Es enthält:
- **Top-Fehler**: Die 22 schlimmsten Fehler, die nie wieder passieren dürfen
- **Goldene Regeln**: Die wichtigsten Arbeitsregeln
- **Aktive Projekte**: Was gerade läuft
- **Pfad-Referenzen**: Wo alles liegt

**Wo sie liegt:** `_memory/MEMORY.md`
**Problem:** Diese Datei wird NICHT automatisch geladen. Claude muss sie aktiv lesen.
Genau dafür gibt es den Initialprompt — er zwingt Claude, MEMORY.md als ersten
Schritt zu lesen.

### Schicht 3: GLOBAL_RULES.md (muss gelesen werden)

Das Regelwerk mit allen übergreifenden Regeln:
- Wie Dateien verarbeitet werden (Input → Verarbeitung → Output)
- Wie das Fehlersystem funktioniert
- Dateiumbenennung, GDrive-Regeln, CashFlow-Regeln
- **Neu:** Delivery-Checkliste (LL-021), Tutorial-Pflicht (LL-022), Session-Start (LL-023)

**Wo sie liegt:** `_rules/GLOBAL_RULES.md`

---

## Der Initialprompt im Detail

Der Initialprompt steht ganz am Anfang der CLAUDE.md und ist eine verbindliche
Checkliste mit 6 Schritten:

| Schritt | Was passiert | Warum |
|---------|-------------|-------|
| 1. Gedächtnis laden | MEMORY.md lesen | Fehler + Regeln kennen |
| 2. Regeln laden | GLOBAL_RULES.md lesen | Arbeitsweise kennen |
| 3. Aufgabe analysieren | Projekt + Skills identifizieren | Kontext verstehen |
| 4. Delivery-Standard | Prüfkette festlegen | Ergebnis muss funktionieren |
| 5. Kommunikation | WAS, WARUM, WAS BEDEUTET DAS | Dr. Stracke versteht alles |
| 6. Session-Abschluss | Fehler + Regeln + Tutorial updaten | System lernt |

---

## Wie das selbstlernende System funktioniert

Das ist der Kern von Claude-OS: Jeder Fehler wird zum Fortschritt.

```
Fehler passiert
    ↓
Fehler wird in FEHLERPROTOKOLL.md dokumentiert (GF-XXX)
    ↓
Neue Regel wird abgeleitet (LL-XXX)
    ↓
Regel wird in GLOBAL_RULES.md oder projekt-spezifische RULES.md eingetragen
    ↓
MEMORY.md wird aktualisiert (Top-Fehler, Goldene Regeln)
    ↓
Nächste Session liest MEMORY.md → kennt den Fehler → macht ihn nicht mehr
```

**Konkretes Beispiel aus heute:**

1. **Fehler:** Design-Skills wurden als Dateien abgelegt, aber nicht als aktive Skills installiert
2. **Dokumentiert als:** GF-006 im FEHLERPROTOKOLL.md
3. **Neue Regeln:** LL-021 (Vollständige Implementierung), LL-022 (Tutorial-Pflicht), LL-023 (Session-Start), LL-024 (Transparente Kommunikation)
4. **In GLOBAL_RULES.md:** Neue Abschnitte 14-17
5. **In MEMORY.md:** Neue Goldene Regeln, Pfad-Referenz für Skills
6. **In CLAUDE.md:** Initialprompt am Anfang

Ab der nächsten Session wird jede Claude-Instanz diese Regeln kennen.

---

## Warum Claude trotzdem manchmal "vergisst"

Drei typische Gründe:

1. **CLAUDE.md ist zu lang**: Je länger die Datei, desto weniger Gewicht hat jeder
   einzelne Punkt. Deshalb steht der Initialprompt ganz am ANFANG — das Wichtigste
   zuerst.

2. **Aktives Lesen wird übersprungen**: CLAUDE.md wird automatisch geladen, aber
   MEMORY.md und GLOBAL_RULES.md müssen aktiv gelesen werden. Wenn Claude das
   überspringt (wie heute), fehlt das Kontextwissen.

3. **Neue Session = neues Claude**: Jede Session ist eine komplett neue Instanz.
   Es gibt keine Vererbung von "Erfahrung" — nur was in den Dateien steht, wird
   übertragen.

**Die Lösung:** Der Initialprompt macht Schritt 1 und 2 zur harten Pflicht.
Nicht "sollte gelesen werden", sondern "MUSS gelesen werden, BEVOR irgendwas
anderes passiert."

---

## Glossar

| Begriff | Bedeutung |
|---------|-----------|
| **CLAUDE.md** | Konfigurationsdatei, die bei jeder Session automatisch geladen wird |
| **Initialprompt** | Verbindliche Checkliste am Anfang der CLAUDE.md |
| **MEMORY.md** | Gedächtnis-Datei mit Fehlern, Regeln und Projektstand |
| **GLOBAL_RULES.md** | Übergreifendes Regelwerk für alle Projekte |
| **LL-XXX** | Lessons Learned — nummerierte Regeln aus Fehlern |
| **GF-XXX** | Globale Fehler — nummerierte Einträge im Fehlerprotokoll |
| **Session** | Eine einzelne Konversation mit Claude (altes Wissen geht verloren) |
| **Selbstlernendes System** | Fehler → Dokumentation → Regel → nächste Session kennt es |

---

## Nächste Schritte

- **Design-Skills**: Siehe `01-design-skills.md` — wie die neuen Skills funktionieren
- **Terminal**: Siehe `../terminal-befehle/01-grundlagen.md` — Grundlagen
- **Eigene Regeln**: Wenn du merkst, dass Claude etwas falsch macht, sag es — ich dokumentiere es und es passiert nicht mehr
