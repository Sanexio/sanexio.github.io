# Blender MCP Setup — Claude-Workflow (automatisiert)

**ID:** TUT-BLE-003-CLAUDE
**Stand:** 2026-04-11 (erstellt auf cluster-mini-02, Blender 5.0.1)
**Voraussetzung:** Homebrew installiert, Blender installiert

---

## Wann nutze ich diesen Weg?

Du sagst zu Claude einfach: *"Installiere den Blender-MCP-Server auf diesem
Rechner und verbinde ihn."* — und Claude erledigt alle Schritte ohne einen
einzigen Klick in der Blender-Oberfläche. Das ist der **bevorzugte Weg**, weil
er reproduzierbar ist, auf jedem neuen Rechner funktioniert und keine
Klick-Anleitungen braucht.

---

## Was Claude automatisch macht (5 Schritte)

### Schritt 1: `uv`/`uvx` via Homebrew installieren

```bash
brew install uv
uvx --version   # → 0.11.x
```

`uv` ist der moderne Python-Paketmanager (Rust-basiert, sehr schnell). `uvx`
ist der Teil davon, der Python-Tools einmalig ausführt, ohne sie global zu
installieren. Der Blender-MCP-Server wird via `uvx blender-mcp` gestartet.

### Schritt 2: Blender-MCP-Addon direkt aus dem GitHub-Repo laden

Statt das Addon über die Blender-GUI zu installieren, lädt Claude die
`addon.py` direkt von GitHub herunter:

```bash
curl -sL -o /tmp/blender_mcp_addon.py \
  https://raw.githubusercontent.com/ahujasid/blender-mcp/main/addon.py
```

Das ist eine einzelne Python-Datei (~110 KB). Keine ZIP, kein pip-Paket
notwendig — das Addon ist komplett in dieser Datei enthalten.

### Schritt 3: Addon in den Blender-Scripts-Ordner kopieren

Blender sucht Addons beim Start in einem versionsspezifischen Ordner:

```bash
# Blender 5.0.x:
~/Library/Application Support/Blender/5.0/scripts/addons/

# Blender 4.5 LTS:
~/Library/Application Support/Blender/4.5/scripts/addons/
```

Claude legt den Ordner an (falls noch nicht da) und kopiert das Addon hinein
unter dem Modulnamen `blender_mcp_addon.py`:

```bash
mkdir -p "$HOME/Library/Application Support/Blender/5.0/scripts/addons"
cp /tmp/blender_mcp_addon.py \
   "$HOME/Library/Application Support/Blender/5.0/scripts/addons/blender_mcp_addon.py"
```

**Wichtig:** Wenn Blender gerade läuft, muss es vorher geschlossen werden —
sonst lädt die Instanz das neue Addon nicht. Claude beendet Blender per
`osascript -e 'tell application "Blender" to quit'`.

### Schritt 4: Blender starten, Addon aktivieren, Server starten — in einem Rutsch

Der entscheidende Trick: Blender kann beim Start ein Python-Kommando
ausführen. Claude nutzt das, um das Addon zu aktivieren und den MCP-Server
sofort hochzufahren — **ohne einen einzigen manuellen Klick**:

```bash
nohup /Applications/Blender.app/Contents/MacOS/Blender --python-expr "
import bpy
bpy.ops.preferences.addon_enable(module='blender_mcp_addon')
bpy.ops.wm.save_userpref()
bpy.ops.blendermcp.start_server()
" > /tmp/blender_mcp_launch.log 2>&1 &
```

Was hier passiert:
- `--python-expr "..."` — Blender führt nach dem Laden das eingebettete
  Python-Skript aus
- `addon_enable(module='blender_mcp_addon')` — Addon wird registriert
- `save_userpref()` — der Aktivierungs-Status wird dauerhaft gespeichert,
  sodass zukünftige Blender-Starts das Addon automatisch laden
- `blendermcp.start_server()` — ruft den Operator auf, der den TCP-Socket auf
  Port 9876 öffnet
- `nohup ... &` — Blender läuft als Hintergrundprozess weiter, auch wenn die
  Terminal-Session schließt

### Schritt 5: End-to-End-Verifikation per direktem TCP-Ping

Claude prüft in zwei Stufen, dass alles funktioniert:

**5a. Port offen?**
```bash
lsof -iTCP:9876 -sTCP:LISTEN
# Erwartet: Blender ... TCP localhost:9876 (LISTEN)
```

**5b. Antwortet der Server auf ein echtes Kommando?**

Claude schickt per Python-Socket direkt eine JSON-Anfrage an Port 9876 —
ohne über `uvx blender-mcp` zu gehen. Das isoliert die Blender-Seite als
Fehlerquelle:

```python
import socket, json
s = socket.socket()
s.connect(('127.0.0.1', 9876))
s.sendall(json.dumps({'type': 'get_scene_info', 'params': {}}).encode())
resp = json.loads(s.recv(65536).decode())
print(resp['status'], resp['result']['name'],
      [o['name'] for o in resp['result']['objects']])
```

Erwartete Antwort: `success Scene ['Cube', 'Light', 'Camera']` (der Default-
Würfel, den Blender bei einer leeren Szene zeigt).

Wenn **beide** Checks positiv sind, ist die Blender-Seite fertig. Die
Claude-Code-Seite (siehe unten) folgt separat.

---

## Claude-Code-Seite: `.mcp.json` verbinden

Für das Projekt `Juvantis` existiert bereits eine projektlokale `.mcp.json`:

```json
{
  "mcpServers": {
    "blender": {
      "command": "uvx",
      "args": ["blender-mcp"]
    }
  }
}
```

**Wichtig:** Claude Code liest diese Datei **nur beim Start**. Damit
`mcp__blender__*`-Tools in einer Session verfügbar sind, muss Claude Code
**aus dem Ordner `projects/Juvantis/` heraus gestartet werden** — dann lädt
es automatisch den MCP-Eintrag und verbindet sich via `uvx blender-mcp` mit
dem bereits laufenden Blender auf Port 9876.

Innerhalb einer bereits laufenden Session tauchen die Tools **nicht
nachträglich** auf, selbst wenn du den Blender-Server während der Session
aktivierst. Das ist kein Bug, sondern das MCP-Protokoll: Tools werden einmal
beim Handshake ausgehandelt.

---

## Wenn etwas schiefläuft

| Symptom | Ursache | Claude-Fix |
|---|---|---|
| `uvx not found` | Homebrew-PATH fehlt | `brew install uv` erneut, PATH prüfen |
| `lsof -iTCP:9876` leer trotz laufendem Blender | Addon wurde nicht aktiviert | Log in `/tmp/blender_mcp_launch.log` prüfen |
| `addon_enable` wirft `module not found` | Dateiname ≠ Modulname | Datei heißen wie im `addon_enable(module=...)` angegeben |
| TCP-Test liefert Timeout | Blender hängt im Splash-Screen | Blender manuell einmal öffnen, damit Splash weggeklickt wird |
| MCP-Tools fehlen in Claude Code trotz offenem Port | `.mcp.json` nicht geladen | Claude Code aus `projects/Juvantis/` neu starten |

---

## Warum dieser Weg besser ist als der Manuell-Weg

- **Reproduzierbar:** Ein Shell-Skript reicht, um auf einem neuen Rechner
  komplett von Null zu installieren
- **Versionsunabhängig:** Das Addon-ZIP aus pip (`pip install blender-mcp`)
  kann bei Versionssprüngen kaputtgehen, die `addon.py` aus dem GitHub-Main-
  Branch ist immer die aktuelle Referenz
- **Keine Klick-Anleitung:** Du musst nicht wissen, wo das N-Panel in Blender
  ist oder wie das Preferences-Fenster aussieht
- **Verifizierbar:** Der direkte TCP-Ping beweist, dass die Blender-Seite
  wirklich funktioniert — unabhängig davon, ob Claude Code die Tools sieht
  oder nicht

---

**Version:** 1.0
**Gerät:** cluster-mini-02 (Mac mini, Apple Silicon, Darwin 24.5.0)
**Getestet mit:** Blender 5.0.1, uv 0.11.6, blender-mcp Addon v1.2
