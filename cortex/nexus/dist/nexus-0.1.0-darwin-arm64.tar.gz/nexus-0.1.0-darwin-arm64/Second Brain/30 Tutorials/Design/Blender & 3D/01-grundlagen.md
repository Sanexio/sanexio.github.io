# Blender: Grundlagen

## Was lernst du hier?

Blender ist das kostenlose 3D-Programm für Modellierung, Animation und Rendering. Für dein Juvantis-Projekt brauchst du Blender um:
- 3D-Avatare zu erstellen
- Shape Keys (Gesichtsausdrücke) einzubauen
- USDZ zu exportieren (für iOS SceneKit)

**Keine 3D-Erfahrung nötig.** Blender sieht komplex aus, aber die Basics sind schnell gelernt.

---

## Installation

**Download:** https://www.blender.org/download/

Für Juvantis-Entwicklung brauchst du mindestens Blender 3.0+.

Nach Installation: Einfach starten und die Welcome-Seite kann weg.

---

## Interface: Orientierung

Blender's Oberfläche hat mehrere Haupt-Bereiche:

```
┌─────────────────────────────────────────────────┐
│ Top: Timeline (für Animation)                   │
├──────────┬──────────────────┬───────────────────┤
│ Outliner │  3D Viewport     │ Properties Panel  │
│ (links)  │  (Mitte)         │ (rechts)          │
│          │                  │                   │
│ Alle     │ Deine Szene      │ Material, Mesh,   │
│ Objekte  │ mit 3D-Modellen  │ Settings, etc.    │
│          │                  │                   │
└──────────┴──────────────────┴───────────────────┘
```

**Outliner (links):** Zeigt alle Objekte in deiner Szene (Camera, Light, Mesh, etc.)

**3D Viewport (Mitte):** Hier siehst du und bearbeitest dein 3D-Modell

**Properties Panel (rechts):** Material, Texturen, Lights, etc.

---

## Navigation im 3D Raum

Die wichtigsten "Flugkommandos":

### Orbit (Drehen)
```
Mittlere Maustaste + Drag
```

Dreht die Ansicht um dein Modell herum.

### Pan (Verschieben)
```
Shift + Mittlere Maustaste + Drag
```

Verschiebt die Ansicht links/rechts/oben/unten.

### Zoom
```
Scroll-Rad nach oben/unten
```

oder `+`/`-` auf dem Numpad.

### "Fit All" (Alles sehen)
```
Home-Taste
```

oder `Numpad 0` und `Numpad .` (je nach Blender-Version).

**Numpad Views (für Standard-Ansichten):**
- `Numpad 7` = Draufsicht (Top View)
- `Numpad 1` = Vorderansicht (Front View)
- `Numpad 3` = Seitenansicht (Right View)
- `Numpad 0` = Camera View (was die Kamera sieht)

---

## Objekt-Mode vs. Edit-Mode

Blender hat zwei Hauptmodi:

### Object Mode
Du verschiebst, rotierst, skalierst ganze Objekte.

```
Dein Avatar hat einen "Body", "Head", "Arms"
Jeder ist ein separates Objekt.

Object Mode:
├─ Body verschieben
├─ Head rotieren
└─ Arms skalieren
```

**Shortcut:** `Tab` drücken zum Wechseln

### Edit Mode
Du veränderst die Form eines Objekts (Vertices, Edges, Faces).

```
Dein Avatar's Head hat 1000 Vertices (Punkte).

Edit Mode:
├─ Vertex 1 verschieben → Mund wird schief
├─ Vertex 2-100 verschieben → Nase wird größer
└─ Face 200 rotieren → Auge wird schräg
```

**Shortcut:** `Tab` drücken zum Wechseln

---

## Grundlegende Mesh-Operationen

### Auswählen (Select)

**Einzelnes Objekt wählen (Object Mode):**
```
Linksklick auf Objekt im Viewport
```

Das Objekt wird orange.

**Mehrere Objekte wählen:**
```
Shift + Linksklick
```

Oder `B` drücken für "Box Select" (zeichne ein Rechteck um die Objekte).

**Alles wählen:**
```
A
```

**Alles abwählen:**
```
Alt + A
```

**In Edit Mode: Vertices wählen**
```
Linksklick auf Vertex
Shift + Linksklick für mehrere
```

---

### Verschieben (Move)

```
G (Grab)
```

Drücke `G` und die Maus wird zum "Grab-Mode". Jetzt:
- Bewege die Maus = Objekt folgt
- `X` drücken = nur auf X-Achse
- `Y` drücken = nur auf Y-Achse
- `Z` drücken = nur auf Z-Achse
- `Eingabe` = bestätigen
- `Esc` = abbrechen

**Beispiel: Head nach oben verschieben**
```
1. Klick auf Head (wird orange)
2. Drücke G (Grab-Mode)
3. Drücke Z (nur auf Z-Achse)
4. Bewege Maus nach oben
5. Klick oder Eingabe zum Bestätigen
```

---

### Rotieren (Rotate)

```
R (Rotate)
```

Ähnlich wie `G`:
- Drücke `R` = Rotation-Mode
- `X`, `Y`, oder `Z` = um diese Achse rotieren
- Zahl eingeben = genauer rotieren (z.B. `45` für 45 Grad)
- `Eingabe` = bestätigen

**Beispiel: Head 30 Grad um Y-Achse drehen**
```
1. Klick auf Head
2. R (Rotate)
3. Y (um Y-Achse)
4. 30 (30 Grad)
5. Eingabe
```

---

### Skalieren (Scale)

```
S (Scale)
```

- Drücke `S` = Scale-Mode
- Bewege Maus = Objekt wird größer/kleiner
- `Shift + Z` = nur X und Y (nicht Z)
- Zahl eingeben = exakt skalieren (z.B. `1.5` für 50% größer)

**Beispiel: Body 1.2x größer machen**
```
1. Klick auf Body
2. S (Scale)
3. 1.2 (20% größer)
4. Eingabe
```

---

## Neues Objekt hinzufügen

```
Shift + A
```

Öffnet das "Add Menu". Wähle:
- **Mesh** > Cube (ein Würfel)
- **Mesh** > UV Sphere (eine Kugel)
- **Mesh** > Cylinder (ein Zylinder)
- etc.

**Einfacher Avatar bauen:**
```
1. Cube hinzufügen (Body)
2. Scale zu rechteckiger Form (S, dann Z für nur Höhe)
3. UV Sphere hinzufügen (Head)
4. Sphere verschieben (G, Z nach oben)
5. Sphere kleiner skalieren (S, 0.6)
```

---

## Materialien und Farben

### Einfache Farbe zuweisen

1. Wähle dein Objekt (z.B. Body)
2. Schau rechts in den Properties Panel
3. Suche "Material Properties" (grüne Kugel-Icon)
4. Klick "New"
5. Unter "Base Color" → Klick auf die Farbe und wähle

Dein Objekt wird jetzt farbig!

---

## Der Juvantis-Workflow: Blender → USDZ → iOS

Das ist dein typischer Workflow:

```
1. Modell in Blender erstellen/bearbeiten
   ├─ Body, Head, Arms modellieren
   ├─ Farben/Materialien zuweisen
   └─ Shape Keys für Mimik (Augen, Mund)

2. In Blender als USDZ exportieren
   File > Export > Universal Scene Description (.usdz)

3. USDZ in Xcode zu iOS-App hinzufügen
   ├─ Xcode öffnen
   ├─ Projekt > Assets.xcassets
   └─ USDZ-Datei drag & drop

4. In Swift/SwiftUI anzeigen
   ModelContainer()  // Zeigt 3D-Modell
```

---

## Shape Keys: Ausdrücke und Animationen

Shape Keys sind "Variationen" eines Modells. Mit ihnen kannst du:
- Augenlider öffnen/schließen
- Mund lächeln/traurig
- Nase vergrößern/verkleinern

### Shape Key erstellen

1. Wähle dein Objekt (z.B. Head)
2. Rechts: "Object Data Properties" (grünes Dreieck-Icon)
3. Scroll zu "Shape Keys"
4. Klick das "+"-Icon ("New Shape Key")
5. Ein Shape Key "Key 1" wird erstellt

### Shape Key editieren

1. Shape Key "Key 1" ist ausgewählt
2. Drücke `Tab` um in Edit Mode zu gehen
3. Editiere das Modell (z.B. bewege Vertices für Lächeln)
4. Drücke `Tab` um zurück zu gehen

Jetzt kannst du den Slider neben "Key 1" bewegen und siehst die Animation!

---

## USDZ exportieren

USDZ ist Apples Standard für 3D-Modelle in iOS.

### Export-Schritte

1. **File > Export > Universal Scene Description (.usdz)**
2. **Dateinamen eingeben:** z.B. `avatar.usdz`
3. **Wichtige Settings (rechts im Export-Dialog):**
   - ✓ "Animations" (wenn du Shape Keys hast)
   - ✓ "Materials"
   - ✓ "Smoothing"
4. **Klick "Export USD/USDZ"**

Die `.usdz` Datei ist jetzt bereit für iOS!

---

## Häufige Probleme

### Problem: "Nichts ist sichtbar!"

**Grund:** Dein Modell ist sehr groß/klein oder außerhalb der Viewport.

**Lösung:**
```
Home-Taste drücken
```

Das zoomt auf alle Objekte.

---

### Problem: "Ich kann nicht in die Viewport zoomen"

**Grund:** Du drückst die falsche Maustaste.

**Lösung:** Nutze die **mittlere** Maustaste (Scroll-Rad) für Orbit/Zoom.

---

### Problem: "Mein Modell sieht hässlich aus"

Das ist normal! 3D-Modellierung braucht Übung. Tipps:
- Nutze mehr Vertices (Subdivide)
- Nutze Normalmap oder Textur
- Schau Blender-Tutorials auf YouTube

---

## Zusammenfassung: Die wichtigsten Shortcuts

| Shortcut | Was es macht |
|----------|--------------|
| `Tab` | Object Mode ↔ Edit Mode |
| `G` | Verschieben (Grab) |
| `R` | Rotieren |
| `S` | Skalieren |
| `X`, `Y`, `Z` | Achse eingrenzen (nach G/R/S) |
| `A` | Alles auswählen |
| `Alt+A` | Alles abwählen |
| `B` | Box Select |
| `Scroll` | Zoom |
| `Mittl. Maus + Drag` | Orbit (Drehen) |
| `Shift + Mittl. Maus + Drag` | Pan (Verschieben) |
| `Numpad 7` | Top View |
| `Numpad 1` | Front View |
| `Home` | Fit All |

---

## Nächste Schritte

1. **Installiere Blender** und öffne es einmal

2. **Spiel mit Navigation:**
   ```
   - Drehe die Ansicht (Mittl. Maus)
   - Zoom (Scroll)
   - Home-Taste (Fit All)
   ```

3. **Erstelle einen einfachen Avatar:**
   - Cube (Body)
   - Sphere (Head)
   - Smaller Spheres (Augen)
   - Cylinder (Arme)

4. **Exportiere als USDZ:**
   - File > Export > USDZ
   - Speichere irgendwo

5. **Nächstes Tutorial:** Blender > Python Scripting (für komplexere Shapes)

---

**💡 Tipp:** 3D-Modellierung ist ein Handwerk. Je mehr du übst, desto besser wirst du. YouTube hat tausende Blender-Tutorials — schau die an!
