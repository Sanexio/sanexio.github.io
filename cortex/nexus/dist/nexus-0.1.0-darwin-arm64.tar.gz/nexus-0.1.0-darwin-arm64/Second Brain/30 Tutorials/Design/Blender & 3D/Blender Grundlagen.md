---
type: tutorial
aliases: [Blender, 3D, Modellierung, Animation, Python-Scripting, Shape Keys]
tags:
  - tutorial
  - blender
  - 3d
  - scripting
source: Second Brain/30 Tutorials/Blender & 3D/
legacy_path: _tutorials/blender/ (Symlink)
---

# Blender & 3D-Modellierung — Tutorial-Übersicht

> Quellpfad: `Second Brain/30 Tutorials/Blender & 3D/` (Single Source of Truth)
> Legacy-Pfad: `_tutorials/blender/` → Symlink auf diesen Ordner

Blender ist das kostenlose 3D-Programm für Modellierung, Animation und Rendering. Für dein Juvantis-Projekt brauchst du Blender um 3D-Avatare zu erstellen, Shape Keys einzubauen und USDZ zu exportieren (für iOS SceneKit).

---

## Keine 3D-Erfahrung nötig

Blender sieht komplex aus, aber die Basics sind schnell gelernt. Und: **Claude kann Python-Skripte generieren, die in Blender ausgeführt werden.** Das ist schneller als alles manuell zu bauen.

---

## Installation

**Download:** https://www.blender.org/download/

Für Juvantis-Entwicklung brauchst du **mindestens Blender 3.0+**. Nach Installation: Einfach starten und die Welcome-Seite kann weg.

---

## Module

### 01 — Grundlagen
**Orientierung in Blender, erste Modelle, Basis-Navigation.**

Lerninhalte:

**Oberflächen-Übersicht:**
```
┌─────────────────────────────────────────────────┐
│ Top: Timeline (für Animation)                   │
├──────────┬──────────────────┬───────────────────┤
│ Outliner │  3D Viewport     │ Properties Panel  │
│ (links)  │  (Mitte)         │ (rechts)          │
│          │                  │                   │
│ Alle     │ Deine Szene      │ Material, Mesh,   │
│ Objekte  │ mit 3D-Modellen  │ Settings, etc.    │
└──────────┴──────────────────┴───────────────────┘
```

- **Outliner (links):** Alle Objekte in deiner Szene
- **3D Viewport (Mitte):** Hier bearbeitest du dein Modell
- **Properties Panel (rechts):** Material, Texturen, Lights

**Navigation im 3D-Raum:**
- **Middle Mouse** (Rad drehen): Orbit-View (rumdrehen)
- **Shift + Middle Mouse:** Pan (verschieben)
- **Scroll:** Zoom in/out
- **Numpad 7:** Top-View
- **Numpad 1:** Front-View

**Erste Modelle:**
- **Cube, Sphere, Cylinder hinzufügen:** Shift+A
- **Objekt wählen:** Click (orange Umrandung)
- **Löschen:** X-Taste
- **Transformieren:** G (Greifen/Bewegen), R (Rotieren), S (Skalieren)
- **Edit Mode vs. Object Mode:** TAB zum Wechseln

**Mode Cheat-Sheet:**
- **Object Mode:** Bearbeite Objekte als Ganzes
- **Edit Mode:** Bearbeite Vertices (Eckpunkte), Edges, Faces
- **Sculpt Mode:** Wie Ton formen (für organische Formen)

**Module:**
- Theorie: `01-grundlagen.md`

---

### 02 — Python Scripting (bpy)
**Automatisierung: Modelle generieren per Code.**

Mit Blender's Python API (`bpy`) kannst du:
- Modelle automatisch generieren
- Shape Keys programmieren (für Avatar-Mimik)
- Alles exportieren per Skript
- Sich wiederholende Aufgaben automatisieren
- **Für Juvantis:** Claude generiert Code, du führst ihn aus

Lerninhalte:

**Blender Scripting Tab öffnen:**
1. Oben rechts: "Scripting" klicken (oder "+" neben Tab-Name)
2. Python-Editor öffnet sich (links) + 3D Viewport (rechts)
3. Code schreiben, Ergebnisse live sehen!

**Erstes Script — Objekt erstellen:**
```python
import bpy

# Alle löschen (sauberer Start)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Cube hinzufügen
bpy.ops.mesh.primitive_cube_add(size=2, location=(0, 0, 0))
cube = bpy.context.object
cube.name = "MyFirstCube"
```

**Wichtige Objekte & Methoden:**
- `bpy.context` → Aktuelle Szene, Objekte, Viewports
- `bpy.context.object` → Das gerade gewählte Objekt
- `bpy.context.collection` → Alle Objekte der aktuellen Collection
- `bpy.ops.*` → Operationen (Add, Delete, etc.)
- `bpy.data.*` → Alle Daten (Objects, Materials, Meshes)

**Mesh-Bearbeitung:**
- Vertices lesen/schreiben
- Mesh-Daten manipulieren
- Shape Keys hinzufügen

**Für Avatare wichtig:**
- Shape Keys für verschiedene BMI-Zustände (schlank/krank/gesund)
- Body-Morphing basiert auf Taillenumfang-Metrik (nicht Volumen!)

**Module:**
- Theorie: `02-python-scripting.md`

---

### 03 — Blender MCP-Setup
**Claude direkt mit deinem Blender kommunizieren lassen.**

Blender MCP ist eine Brücke, mit der Claude Python-Skripte direkt in deinem laufenden Blender ausführen kann.

Lerninhalte:

**Setup auf deinem Mac:**
- Addon installieren
- Port konfigurieren (9876)
- Claude mit deinem Blender verbinden

**Praktische Nutzung:**
- Claude: "Erstelle einen Avatar mit BMI 28"
- Claude generiert Python-Code
- Code lädt in Blender
- Avatar wird live generiert
- Du siehst Ergebnis sofort

**Module:**
- Theorie: `03-blender-mcp-setup.md`
- Claude-Workflow: `03-blender-mcp-setup_claude.md`
- Manuell: `03-blender-mcp-setup_manuell.md`

---

### 04 — Troubleshooting
**Wenn etwas schiefgeht: Lösungen für häufige Fehler.**

Häufige Probleme:
- **Mesh-Fehler:** N-Gons, selbst-schneidende Faces, Doppel-Vertices
- **Material-Probleme:** Texturen laden nicht, Farben falsch
- **Export-Fehler:** USDZ exportiert falsch oder gar nicht
- **Performance:** Blender läuft langsam mit großem Modell
- **Python-Fehler:** Script bricht ab mit Fehlermeldung
- **Kamera & Rendering:** Falscher Viewport, seltsame Schatten

**Lösungs-Toolbox:**
- Mesh-Cleanup: `Shift+M` → "Merge by Distance"
- Normalen prüfen: `Alt+N` → "Recalculate Normals"
- UV-Unwrap überprüfen
- Render Engine wechseln (Eevee vs. Cycles)

**Module:**
- Theorie: `04-troubleshooting.md`

---

## Lern-Reihenfolge

1. **01 — Grundlagen** (Oberfläche, Navigation, erste Modelle)
2. **02 — Python Scripting** (Automatisierung mit Code)
3. **03 — Blender MCP-Setup** (Claude → Blender Integration)
4. **04 — Troubleshooting** (Wenn's nicht läuft)

---

## Wichtige Shortcuts

| Shortcut | Aktion |
|----------|--------|
| `Shift+A` | Neues Objekt hinzufügen |
| `X` | Löschen |
| `G` | Greifen (Bewegen) |
| `R` | Rotieren |
| `S` | Skalieren |
| `TAB` | Edit Mode ↔ Object Mode |
| `1, 3, 7` (Numpad) | Front, Side, Top View |
| `0` (Numpad) | Camera View |
| `F12` | Render (Bild generieren) |
| `.` (Numpad) | Frame All (Alles im Viewport zeigen) |
| `H` | Hide (Ausblenden) |
| `Alt+H` | Unhide All |

---

## Juvantis-Spezifisches

### Avatar-Pipeline (Shape Keys Workflow)

1. **Base-Modell:** Neutraler Avatar (z.B. Avaturn)
2. **Shape Keys erstellen:**
   - "Slim" (BMI 20) — Tailly schmal
   - "Healthy" (BMI 23) — Normal
   - "Overweight" (BMI 28) — Bauch
   - "Obese" (BMI 34) — Deutlich sichtbar
3. **Tailly-Umfang-Metrik:** Nicht Volumen, sondern Convex-Hull-Umfang im Bauchbereich
4. **Hard-Guards:** Gesicht NIE deformieren! (Regel LL-029)
5. **Kleidungs-Meshes:** Beide (Hose + Hemd) bei Morphs anfassen (Regel LL-031)
6. **Export:** Als USDZ für iOS SceneKit

### Health-Daten Visualisierung

- Farben für verschiedene Zustände (krank=rot, gesund=grün)
- Animationen basiert auf HealthKit-Daten
- Performance: Auf iPhone muss es flüssig laufen!


<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

- [[30 Tutorials/Design/Blender & 3D/01-grundlagen|01-grundlagen]] · [[30 Tutorials/Design/Blender & 3D/01-grundlagen_claude|Claude]] · [[30 Tutorials/Design/Blender & 3D/01-grundlagen_manuell|Manuell]]
- [[30 Tutorials/Design/Blender & 3D/02-python-scripting|02-python-scripting]] · [[30 Tutorials/Design/Blender & 3D/02-python-scripting_claude|Claude]] · [[30 Tutorials/Design/Blender & 3D/02-python-scripting_manuell|Manuell]]
- [[30 Tutorials/Design/Blender & 3D/03-blender-mcp-setup|03-blender-mcp-setup]] · [[30 Tutorials/Design/Blender & 3D/03-blender-mcp-setup_claude|Claude]] · [[30 Tutorials/Design/Blender & 3D/03-blender-mcp-setup_manuell|Manuell]]
- [[30 Tutorials/Design/Blender & 3D/04-troubleshooting|04-troubleshooting]]

<!-- /auto-moc-links -->