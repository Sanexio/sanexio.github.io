# Blender MCP Setup — Manuell-Workflow (GUI-Variante)

**ID:** TUT-BLE-003-MANUELL
**Stand:** 2026-04-11
**Voraussetzung:** Homebrew installiert, Blender installiert
**Wann nutzen:** Wenn du den Installationsweg selbst verstehen und
nachvollziehen möchtest, oder wenn kein Claude Code zur Verfügung steht

---

## Warum es zwei Wege gibt

Den kompletten Automatik-Weg findest du in `03-blender-mcp-setup_claude.md`.
Dieser hier ist die GUI-Variante: alles Schritt für Schritt mit Erklärung,
was du klickst und warum. Nützlich, um einmal selbst gesehen zu haben, wie
das Addon in Blender aussieht und wo die Schalter liegen.

---

## Schritt 1 — `uv` installieren (Terminal)

Öffne das Terminal (Spotlight: Cmd+Leertaste → „Terminal") und tippe:

```bash
brew install uv
```

Was passiert:
- Homebrew lädt ein kleines Kommandozeilen-Werkzeug namens `uv` herunter
- `uv` ist der moderne Python-Paketmanager — er ersetzt das langsame `pip`
- Mitgeliefert wird auch `uvx`, das Python-Tools einmalig ausführt, ohne sie
  global zu installieren (wie `npx` bei Node.js)

Prüfen, ob es geklappt hat:
```bash
uvx --version
```
Erwartet: eine Ausgabe wie `uvx 0.11.6 (Homebrew ...)`.

---

## Schritt 2 — Blender-MCP-Addon herunterladen

Das Addon ist eine einzelne Python-Datei, die du dir aus dem GitHub-Repo
holst:

**Variante A (einfach, im Browser):**
1. Gehe zu: https://github.com/ahujasid/blender-mcp
2. Klicke auf `addon.py`
3. Rechts oben: **Download raw file** (Icon mit Pfeil nach unten)
4. Die Datei landet in deinem Download-Ordner als `addon.py`

**Variante B (Terminal, ein Befehl):**
```bash
curl -sL -o ~/Downloads/addon.py \
  https://raw.githubusercontent.com/ahujasid/blender-mcp/main/addon.py
```

---

## Schritt 3 — Addon in Blender installieren

1. **Blender öffnen** (Spotlight → „Blender")
2. Oben in der Menüleiste: **Edit → Preferences…** (das Einstellungsfenster
   öffnet sich)
3. Links im Preferences-Fenster: **Add-ons** anklicken
4. Oben rechts: **Install from Disk…** klicken (bei älteren Blender-Versionen
   heißt der Button einfach **Install…**)
5. Navigiere zu deinem Download-Ordner → `addon.py` auswählen → **Install
   Add-on**
6. In der Addon-Liste (Suchfeld oben nutzen) nach **„BlenderMCP"** suchen
7. Das **Checkbox-Kästchen links neben dem Namen** anklicken → Addon ist
   aktiviert

**Wichtig:** Jetzt unbedingt die Preferences speichern, sonst ist das
Addon beim nächsten Blender-Start wieder weg:
- Unten links im Preferences-Fenster: Hamburger-Menü (drei Linien) → **Save
  Preferences**

Du kannst das Preferences-Fenster jetzt schließen.

---

## Schritt 4 — MCP-Server in Blender starten

1. Im Haupt-Viewport (da wo der Würfel steht) die Taste **N** drücken — rechts
   öffnet sich eine schmale Seitenleiste mit Tabs
2. In der Seitenleiste den Tab **BlenderMCP** anklicken (er steht unten und
   ist nach der Addon-Aktivierung dazugekommen)
3. Button **Connect to Claude** (oder je nach Version **Start MCP Server**)
   anklicken
4. Status sollte sich ändern auf: **Running on port 9876**

Falls der Button nichts tut oder der Status nicht wechselt, siehe den
Troubleshooting-Abschnitt im Haupt-Tutorial `03-blender-mcp-setup.md`.

### Verifizieren (optional, im Terminal)

```bash
lsof -iTCP:9876 -sTCP:LISTEN
```
Erwartet: eine Zeile, in der `Blender` als Prozess auf `localhost:9876` lauscht.

---

## Schritt 5 — Claude Code verbinden

Die Datei `.mcp.json` im Ordner `projects/Juvantis/` ist bereits fertig
konfiguriert — du musst dort **nichts** ändern.

Du musst lediglich sicherstellen, dass Claude Code **aus diesem Ordner
heraus** gestartet wird, damit die Konfigurationsdatei beim Start gelesen
wird:

```bash
cd "~/Library/Mobile Documents/com~apple~CloudDocs/Claude-OS/projects/Juvantis"
claude
```

Nach dem Start:
```
/mcp
```
eingeben. Es sollte ein Eintrag `blender` mit Status **connected** erscheinen.
Beim ersten Start fragt Claude Code dich einmal um Erlaubnis („Allow MCP
server?") — mit **Yes** bestätigen.

**Reihenfolge ist kritisch:**
1. Erst Blender öffnen + MCP-Server starten
2. Dann Claude Code starten
Wenn du Claude Code startest, bevor der Blender-Server läuft, funktioniert
die Verbindung nicht und du musst Claude Code neu starten.

---

## Was du jetzt testen kannst

Frage Claude (innerhalb der Claude-Code-Session im Juvantis-Ordner):

> „Wie sieht die aktuelle Szene in Blender aus?"

Claude sollte das MCP-Tool `get_scene_info` aufrufen und dir die Objekte in
der Szene zurückliefern — beim allerersten Aufruf der Default-Würfel plus
Light plus Camera.

---

## Woran erkenne ich, dass alles funktioniert?

| Check | Wo | Erwartet |
|---|---|---|
| `uv` installiert | Terminal: `uvx --version` | `uvx 0.11.x` |
| Addon aktiviert | Blender → Edit → Preferences → Add-ons | „BlenderMCP" mit Checkbox an |
| Server läuft | Blender → N-Panel → BlenderMCP | „Running on port 9876" |
| Port offen | Terminal: `lsof -iTCP:9876 -sTCP:LISTEN` | Blender-Prozess wird gelistet |
| Claude Code verbunden | Claude Code: `/mcp` | `blender: connected` |

Wenn alle fünf Haken stehen, ist die Installation fertig.

---

**Version:** 1.0
**Gerät:** cluster-mini-02
**Getestet mit:** Blender 5.0.1, uv 0.11.6, blender-mcp Addon v1.2
