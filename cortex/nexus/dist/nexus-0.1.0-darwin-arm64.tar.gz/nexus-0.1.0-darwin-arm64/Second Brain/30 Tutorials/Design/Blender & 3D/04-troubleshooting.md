# Tutorial: Blender Troubleshooting — Häufige Probleme und Lösungen

**ID:** TUT-BLE-004
**Stand:** 2026-04-10
**Voraussetzung:** Tutorial 01-03
**Quelle:** Dokumentierte Fehler aus der Juvantis Avatar-Pipeline

---

## Fehler-Kategorie 1: Netzwerk und Verbindung

### Blender-Addon zeigt "Running" aber Port ist nicht offen

**So erlebt:** Blender N-Panel zeigt "Running on port 9876", aber:
```bash
lsof -i :9876
# → Keine Ausgabe (Port ist nicht offen)
```

**Was passiert technisch:**
Das BlenderMCP-Addon versucht einen TCP-Socket zu öffnen, scheitert aber still.
Die UI aktualisiert ihren Status trotzdem auf "Running", weil der Fehler
nicht an die UI zurückgemeldet wird.

**Ursachen:**
1. Eine andere Blender-Instanz blockiert den Port
2. macOS Firewall blockiert lokale Sockets
3. Das Addon hat einen internen Python-Fehler beim Socket-Bind

**Lösung-Kaskade:**
```
Schritt 1: Disconnect + Reconnect im N-Panel
    ↓ funktioniert nicht?
Schritt 2: Blender komplett schließen und neu öffnen
    ↓ funktioniert nicht?
Schritt 3: Addon deaktivieren → Blender neu starten → Addon aktivieren
    ↓ funktioniert nicht?
Schritt 4: Addon komplett deinstallieren und neu installieren
    ↓ funktioniert nicht?
Schritt 5: Blender System Console prüfen (Window → Toggle System Console)
           dort stehen die eigentlichen Python-Fehlermeldungen
```

**Prüfung nach jedem Schritt:**
```bash
lsof -i :9876
# Muss zeigen: Blender oder Python auf TCP *:9876 (LISTEN)
```

### "No route to host" vs. "Connection refused"

| Fehler | Bedeutung | Aktion |
|--------|-----------|--------|
| `Errno 65: No route to host` | TCP-Paket kann die Ziel-IP nicht erreichen | Blender bindet auf falscher Adresse — Addon neu starten |
| `Errno 61: Connection refused` | IP erreichbar, aber kein Dienst auf dem Port | Blender-Addon nicht gestartet — im N-Panel starten |
| `Errno 48: Address already in use` | Port belegt von anderem Prozess | `lsof -i :9876` → Prozess identifizieren und beenden |
| `timeout` | Paket gesendet, keine Antwort | Firewall oder falsches Netzwerk-Interface |

---

## Fehler-Kategorie 2: GDrive / Dateisystem

### EDEADLK bei .mcp.json und Tutorial-Dateien

**So erlebt:** Cowork oder Claude Code kann keine Dateien auf GDrive lesen:
```
EDEADLK: unknown error, read
cp: error reading '...': Resource deadlock avoided
```

**Was passiert technisch:**
Google Drive File Stream (FUSE-Mount) setzt Dateisystem-Locks, die von der
Sandbox-Umgebung (Cowork VM, Claude Code Container) nicht aufgelöst werden können.
Betrifft ALLE Dateitypen — auch .md und .json.

**Workaround (kurzfristig):**
```bash
# osascript-Weg (nur auf dem Mac, nicht in Sandbox):
osascript -e 'do shell script "cp /Users/ssmd/Library/CloudStorage/GoogleDrive-team@sanexio.de/Meine\\ Ablage/Claude-OS/datei.md /tmp/datei.md"'
```

**Lösung (langfristig):**
Claude-OS auf lokales Dateisystem migrieren (`~/Claude-OS` oder `~/Documents/Claude-OS`).
Optional iCloud-Sync als Backup. GDrive-spezifische Workarounds (LL-015, LL-016)
werden dann obsolet.

### Schreibzugriff funktioniert, Lesezugriff nicht

**Beobachtung:** `Write` auf GDrive-Dateien funktioniert oft, `Read` und `cp` nicht.

**Erklärung:** FUSE-Mounts behandeln Schreib- und Lesezugriffe unterschiedlich.
Neue Dateien werden im lokalen Cache erstellt (kein Lock nötig), bestehende
Dateien erfordern einen Read-Lock vom GDrive-Daemon (der fehlschlägt).

---

## Fehler-Kategorie 3: MCP-Konfiguration

### Doppelte MCP-Einträge

**So erlebt:** `/mcp` in Claude Code zeigt "blender" UND "blender-mcp".

**Ursache:** Ein Eintrag aus `claude mcp add` (User-Scope in `~/.claude.json`),
ein zweiter aus `.mcp.json` (Project-Scope im Projektordner).

**Lösung:**
```bash
# Duplikat entfernen:
claude mcp remove blender-mcp

# Prüfen:
claude mcp list
# Sollte nur EINEN "blender"-Eintrag zeigen
```

### MCP-Server Status "failed" nach Claude Code Start

**Diagnose-Ablauf:**

```
1. /mcp → Status prüfen
   ↓ "failed"?
2. blender-mcp isoliert testen:
   uvx blender-mcp 2>&1 | head -20
   ↓ Fehler lesen
3. Häufige Fehler:
   a) "No route to host" → Blender-Addon nicht aktiv (siehe oben)
   b) "ModuleNotFoundError" → blender-mcp nicht installiert
   c) "command not found: uvx" → uvx nicht im PATH
```

### uvx vs. pip vs. pipx — Was verwenden?

| Tool | Vorteil | Nachteil |
|------|---------|----------|
| `uvx` | Isolierte Umgebung, kein Dependency-Konflikt | Muss im PATH sein, Downloads bei jedem Start |
| `pip install` | Schneller Start (keine Downloads) | Kann mit System-Python kollidieren |
| `pipx` | Isoliert wie uvx, aber persistent installiert | Zusätzliches Tool nötig |

**Empfehlung:** `uvx` für MCP-Server (Claude Code erwartet das), `pip` für
lokale Tests. Der vollständige Pfad (`/Users/ssmd/.local/bin/uvx`) in der
Config vermeidet PATH-Probleme.

---

## Fehler-Kategorie 4: Avatar-Export

### model-viewer ignoriert Bone-Scale-Deformationen

**So erlebt:** In Blender sieht der Avatar dick aus, auf der Website nicht.

**Ursache:** Google `<model-viewer>` evaluiert die Skin (Armature) im
**Rest Pose**, nicht im Pose Mode. Bone-Scales werden ignoriert.

**Lösung:** Armature-Modifier anwenden (= Deformation in Vertices "einbrennen"),
dann Armature löschen und OHNE Skins exportieren.

Referenz: `avaturn_adipose.py` (Kommentar oben im Skript erklärt das Problem).

### GLB-Export zeigt keine Deformation

**Checkliste:**
1. Wurde der Armature-Modifier **applied** (nicht nur gesetzt)?
2. Wurde das Armature-Objekt **gelöscht** nach dem Apply?
3. Export-Settings: `export_skins=False`?
4. Richtige Meshes deformiert? (`avaturn_body`, `avaturn_look_0`, `avaturn_look_1`)
5. Gesichts-Guard aktiv? (Vertices oberhalb Y ≥ 1.5 dürfen NICHT verändert werden)

---

## Diagnose-Cheat-Sheet

```bash
# === Netzwerk ===
lsof -i :9876                    # Wer lauscht auf dem Port?
python3 -c "import socket; s=socket.socket(); s.settimeout(3); s.connect(('127.0.0.1', 9876)); print('OK'); s.close()"

# === MCP ===
claude mcp list                  # Alle registrierten Server
claude mcp remove SERVERNAME     # Server entfernen
claude mcp reset-project-choices # Approval-Entscheidungen zurücksetzen
/mcp                             # In Claude Code: Live-Status

# === blender-mcp ===
pip3 show blender-mcp            # Version und Pfad
which uvx                        # uvx-Pfad finden
uvx blender-mcp 2>&1 | head -20 # Server isoliert testen

# === Blender ===
# In Blenders Python Console:
import addon_utils
[m.bl_info['name'] for m in addon_utils.modules() if 'MCP' in m.bl_info.get('name','')]
# → Zeigt ob BlenderMCP-Addon geladen ist
```

---

**Version:** 1.0
**Erstellt:** 2026-04-10
**Quelle:** Session 2026-04-10 — Blender MCP Setup-Probleme mit GDrive/EDEADLK
