---
type: tutorial
aliases: [Design, Design-Skills, Frontend, UI/UX, Anti-AI-Slop, Figma]
tags:
  - tutorial
  - design
  - frontend
  - ui-ux
source: Second Brain/30 Tutorials/Design/
legacy_path: _tutorials/design/ (Symlink)
---

# Design-Skills für Claude — Tutorial-Übersicht

> Quellpfad: `Second Brain/30 Tutorials/Design/` (Single Source of Truth)
> Legacy-Pfad: `_tutorials/design/` → Symlink

Wenn Claude Websites, Apps oder Frontends baut, sehen die Ergebnisse oft generisch aus: dieselben Fonts, dieselben Farben, dieselbe Struktur. Das nennt man **"AI-Slop"** — generisches KI-Design ohne Charakter.

Diese Tutorials zeigen dir, wie du professionelle, einzigartige Designs bekommst.

---

## Das Problem: Warum sehen KI-Frontends gleich aus?

Claude (und alle KI-Modelle) lernen aus riesigen Mengen von Code. Ohne spezielle Anweisungen wählt Claude den "statistisch sichersten" Weg:

- **Font:** Inter (am häufigsten im Training)
- **Farbe:** Blau/Lila auf Weiß (häufigstes Muster)
- **Layout:** Zentrierter Header, drei Spalten, Footer
- **Animation:** Keine (sicherste Wahl)

Ergebnis: Alles sieht aus wie eine Template-Website von 2023.

---

## Die Lösung: Design-Skills

**Design-Skills** geben Claude VOR dem Coden klare Regeln:
- Welche Fonts verboten sind
- Welche Design-Richtungen möglich sind
- Welche Farbkombinationen zusammenpassen
- Welche UX-Patterns professionell wirken

Mit den drei Design-Skills hast du zugriff auf:
- **84+ Styles** (moderne Designrichtungen)
- **161 Farbpaletten** (harmonisch kombiniert)
- **57 Font-Pairings** (Typography-Experten-Auswahl)

---

## Module

### 01 — Design-Skills für Claude
**Verstehen, wie die drei Skills zusammenarbeiten.**

Die drei Design-Skills:

**1. UI-UX Pro Max** (Farben, Fonts, Style-Datenbank)
- Generiert ein Design-System für dein Projekt
- Antwortet: "WAS sollen wir bauen?"
- 161 Farbpaletten (warm, kühl, modern, klassisch, etc.)
- 57 Font-Pairings (Heading + Body)
- Style-Guidelines (Spacing, Shadows, Border-Radius)

**2. Frontend-Design** (Code-Richtlinien)
- Antwortet: "WIE bauen wir es?"
- Rendert den Code professionell
- Moderne Patterns (Bento Grids, Scroll-Animations)
- Anti-AI-Slop Regeln
- Responsive Design für Mobile

**3. Design-System-Validator** (Kontrolle)
- Prüft: "Passt das alles zusammen?"
- Vergleicht gegen die Design-Guidelines
- Flag Verstöße (falsche Font, Farbe out-of-range, zu viel Spacing)
- Gibt Feedback zum Überarbeiten

**Workflow:**

```
┌─────────────────────────────────────────────────┐
│ 1. UI-UX Pro Max                                │
│    → Design-System generieren (Farben, Fonts)   │
│    → Output: Design-Richtlinien (JSON/Markdown)│
└─────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────┐
│ 2. Frontend-Design                              │
│    → Mit Design-Richtlinien Code schreiben      │
│    → Modern, responsive, anti-slop              │
│    → Output: HTML/CSS/React/Vue                 │
└─────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────┐
│ 3. Validator (optional, für Qualitätsprüfung)  │
│    → Vergleicht Code gegen Design-System        │
│    → Flag Abweichungen                          │
│    → Output: Feedback & Überarbeitungen         │
└─────────────────────────────────────────────────┘
```

**Module:**
- Theorie: `01-design-skills.md`
- Claude-Workflow: `01-design-skills_claude.md`
- Manuell: `01-design-skills_manuell.md`

---

### 02 — Initial Prompt — Die richtige Frage stellen
**Wie du Claude briefest, um großartige Designs zu bekommen.**

Der Initial Prompt ist das Fundament. Mit dem falschen Prompt bekommst du AI-Slop, auch wenn Design-Skills aktiv sind.

Lerninhalte:

**Was ein guter Prompt enthält:**

1. **Projekt-Kontext:**
   ```
   "Ich baue die Website für Sanexio (Digital Health Twin Startup).
   Zielgruppe: Ärzte (40-60) und Tech-Nutzer (25-35)."
   ```

2. **Design-Anforderungen (explizit!):**
   ```
   "Moderne, saubere Ästhetik. Keine bunten Gradienten.
   Farbe: Teal-basiert (#028090, #00A896, #02C39A).
   Font: Keine Inter, eher Poppins oder Fraunces für Heading.
   Layout: Bento Grid, asymmetrisch, viel Whitespace."
   ```

3. **Use-Cases:**
   ```
   "Nutzer wollen einen 3D-Avatar sehen, der ihre Gesundheit visualisiert.
   Oben: Beschreibung. Mitte: Avatar (3D, interaktiv).
   Unten: Health-Metriken in Cards."
   ```

4. **Tech Stack (falls relevant):**
   ```
   "React + Tailwind CSS, oder HTML + CSS?
   Muss SEO-optimiert sein (Server-Side Rendering?).
   Animation-Budget: Können wir framer-motion nutzen?"
   ```

5. **Inspirationen (optional aber hilfreich):**
   ```
   "Inspiriert von: Figma (dunkel, clean),
   Apple Health (Daten-Visualisierung),
   Stripe (Whitespace, Typografie)."
   ```

**Beispiel: Ein guter vs. schlechter Prompt**

❌ **Schlecht:**
```
"Baue eine schöne Website für mein Startup."
```

✅ **Gut:**
```
"Baue eine Juvantis-Landing-Page:
- Zielgruppe: Ärzte (Alter 40-60) und Tech-Nutzer (25-35)
- Design: Modern, teal-basiert, viel Whitespace
- Hero: Großes 3D-Avatar-Bild (interaktiv), kurzer CTA
- Section 2: 'Wie es funktioniert' mit 3 Schritten
- Section 3: Testimonials von Ärzten
- Tech: HTML + CSS (CSS Grid für responsive)
- Keine Gradienten, keine Animationen außer Scroll-Fade
- Font: Poppins (Body), Fraunces (Headings)"
```

**Anti-AI-Slop Checkliste im Prompt:**
- [ ] Fonts explizit nomen (NICHT Inter)
- [ ] Farbpalette definiert (mit Hex-Codes)
- [ ] Whitespace-Richtung (viel vs. kompakt?)
- [ ] Animation-Budget (viel, mittel, wenig?)
- [ ] Responsive-Strategie (Mobile-first?)
- [ ] Inspirationen mitgeben (Figma, Apple, Stripe?)
- [ ] Layout explizit (Bento, 3-Spalten, etc.)

**Module:**
- Theorie: `02-initialprompt.md`

---

## Lern-Reihenfolge

1. **01 — Design-Skills** (Verstehen, wie sie arbeiten)
2. **02 — Initial Prompt** (Richtig briefen, um große Designs zu kriegen)

---

## Dein Teal-Farbschema (Juvantis)

Diese Farben sollten immer in Juvantis-Designs verwendet werden:

| Name | Hex | RGB | Verwendung |
|------|-----|-----|-----------|
| **Teal Dark** | `#028090` | (2, 128, 144) | Text, Headings, Buttons |
| **Teal Medium** | `#00A896` | (0, 168, 150) | Hover-States, Akzente |
| **Teal Light** | `#02C39A` | (2, 195, 154) | Backgrounds, Cards |
| **Neutral Dark** | `#333333` | (51, 51, 51) | Body-Text |
| **Neutral Light** | `#F5F5F5` | (245, 245, 245) | Backgrounds |
| **White** | `#FFFFFF` | (255, 255, 255) | Cards, Sections |

Alle bisherigen Juvantis-Designs nutzen dieses Schema:
- Homepage (18+ Sections)
- DHT-Page (Avatar-Vergleich)
- Shopify-Theme


<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

- [[30 Tutorials/Design/01-design-skills|01-design-skills]] · [[30 Tutorials/Design/01-design-skills_claude|Claude]] · [[30 Tutorials/Design/01-design-skills_manuell|Manuell]]
- [[30 Tutorials/Design/02-initialprompt|02-initialprompt]]

<!-- /auto-moc-links -->