# Blender: Python Scripting — Manueller Workflow

## Wann nutze ich diesen Weg?

Du brauchst den manuellen Workflow wenn:
- Du Blender-Python selbst schreiben lernen möchtest
- Du experimentieren und verstehen willst, wie bpy funktioniert
- Du bereits Python-Erfahrung hast
- Du kleine, einfache Automationen selbst bauen möchtest (kein AI-Help nötig)

**Beispiel aus Juvantis:** Du brauchst ein einfaches Skript, das 5 Würfel in einer Reihe erstellt. Du schreibst es selbst — ist nur 10 Zeilen Code.

---

## Der Manuell-Workflow: Schreiben und Lernen

```
1. Blender öffnen → Scripting-Tab
      ↓
2. Code selbst tippen (oder vom Tutorial kopieren)
      ↓
3. Play → Fehler sehen → Code anpassen
      ↓
4. Iterativ debuggen bis es funktioniert
      ↓
5. Stolz sein!
```

---

## Schritt 1: Scripting-Tab öffnen

1. **Blender öffnen**
2. **Oben rechts → "Scripting" Tab** (oder `+` drücken und suchen)
3. Neue Layout mit Python-Editor (links) und 3D View (rechts)

---

## Schritt 2: Erstes Skript — Hallo Würfel!

**Kopiere oder schreibe diesen Code in den Python-Editor (links):**

```python
import bpy

# Alle Objekte löschen (saubere Szene)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Einen Würfel erstellen
bpy.ops.mesh.primitive_cube_add(size=2, location=(0, 0, 0))

# Aktives Objekt greifen und umbenennen
cube = bpy.context.object
cube.name = "MeinErsterWürfel"

# Konsole-Output
print(f"✓ Würfel erstellt: {cube.name}")
```

**Play drücken (Alt + P):**
- In der 3D View (rechts) erscheint ein Würfel!
- Unten rechts in der Konsole siehst du: `✓ Würfel erstellt: MeinErsterWürfel`

**Erste Datei speichern:**
```
Text > Save As → "my_first_cube.py"
```

---

## Schritt 3: Objekte modifizieren

**Neuer Code (im gleichen Editor):**

```python
import bpy
import math

# Würfel vorbereiten
cube = bpy.data.objects[0]

# Größe ändern (skalieren)
cube.scale = (2, 1, 1)  # Breiter, normaler Höhe, normal tief

# Position verschieben
cube.location = (0, 0, 1)  # 1 unit nach oben

# Rotation (45 Grad um X-Achse)
cube.rotation_euler = (math.radians(45), 0, 0)

print(f"Würfel: {cube.name}")
print(f"Position: {cube.location}")
print(f"Größe: {cube.scale}")
```

**Play:**
- Der Würfel dreht sich, bewegt sich nach oben, wird breiter
- Perfekt für Verständnis!

---

## Schritt 4: Mehrere Objekte erstellen

```python
import bpy

# Szene löschen
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# 5 Würfel in einer Reihe erstellen
for i in range(5):
    x_position = i * 2  # Jeder Würfel 2 units weiter rechts

    bpy.ops.mesh.primitive_cube_add(
        size=1,
        location=(x_position, 0, 0)
    )

    cube = bpy.context.object
    cube.name = f"Cube_{i+1}"
    print(f"Würfel {i+1} erstellt bei X={x_position}")

print("Fertig! 5 Würfel nebeneinander.")
```

**Play:**
- 5 Würfel nebeneinander in einer Reihe!
- Ideal für erste Programmier-Erfahrung in Blender

---

## Schritt 5: Materialien per Code

```python
import bpy

# Aktives Objekt (Cube von oben)
obj = bpy.context.object

# Neues Material erstellen
mat = bpy.data.materials.new(name="MyMaterial")
mat.use_nodes = True

# Farb-Node für Material-Einstellung
bsdf = mat.node_tree.nodes["Principled BSDF"]

# Farbe setzen: Rot (R, G, B, Alpha)
bsdf.inputs['Base Color'].default_value = (1.0, 0.2, 0.2, 1.0)

# Material zum Objekt hinzufügen
if obj.data.materials:
    obj.data.materials[0] = mat
else:
    obj.data.materials.append(mat)

print("Material zugewiesen!")
```

**Play:**
- Dein Würfel wird rot!

---

## Schritt 6: Shape Keys selbst erstellen

**Shape Keys für einfache Animation:**

```python
import bpy

# Aktives Objekt (Sphere) vorbereiten
obj = bpy.context.object

if obj.type != 'MESH':
    print("FEHLER: Nicht einmal ein Mesh!")
else:
    # Basis Shape Key (falls nicht vorhanden)
    if not obj.data.shape_keys:
        basis = obj.shape_key_add(name="Basis")

    # Neuer Shape Key "Groß"
    shape_big = obj.shape_key_add(name="Big")

    # Neuer Shape Key "Klein"
    shape_small = obj.shape_key_add(name="Small")

    print(f"Shape Keys erstellt für {obj.name}!")

    # Alle Shape Keys auflisten
    for sk in obj.data.shape_keys.key_blocks:
        print(f"  - {sk.name}")
```

**Play:**
- Shape Keys sind erstellt!
- Jetzt kannst du in Blender GUI die Slider verschieben und animieren

---

## Schritt 7: Export per Skript

**USDZ automatisch exportieren:**

```python
import bpy

# Definiere Export-Pfad
export_path = "/Users/ssmd/Desktop/my_avatar.usdz"

# Exportiere als USDZ
bpy.ops.export_usdz.usdz(
    filepath=export_path,
    export_animations=True,
    export_materials=True,
    export_smooth_groups=True
)

print(f"✓ Exportiert zu: {export_path}")
```

**Wichtig:** Änder `/Users/ssmd/Desktop/` zu deinem echten Pfad!

**Play:**
- Datei wird automatisch auf deinem Desktop gespeichert
- Ready für iOS-App!

---

## Häufige Fehler im Manuell-Scripting

### Fehler 1: "IndexError: bpy.data.objects[0] does not exist"

**Grund:** Du versuchst, auf Objekt zu greifen, das nicht existiert.

**Lösung:**
```python
# Sicher prüfen
if len(bpy.data.objects) > 0:
    cube = bpy.data.objects[0]
else:
    print("FEHLER: Keine Objekte in der Szene!")
```

---

### Fehler 2: "TypeError: unhashable type"

**Grund:** Du versuchst, ein nicht-kompatibles Datenformat zu verwenden.

**Lösung:** Types checken:
```python
# Falsch
location = "0, 0, 0"  # String!

# Richtig
location = (0, 0, 0)  # Tuple!
```

---

### Fehler 3: "AttributeError: 'Mesh' object has no attribute 'xyz'"

**Grund:** Das Attribut existiert nicht.

**Lösung:** Alle verfügbaren Attribute anschauen:
```python
print(dir(bpy.context.object))
```

Die Ausgabe zeigt alle verfügbaren Properties.

---

## Debugging-Techniken

### Technik 1: Print-Statements

```python
import bpy

obj = bpy.context.object
print(f"Objekt: {obj.name}")
print(f"Typ: {obj.type}")
print(f"Position: {obj.location}")
print(f"Größe: {obj.scale}")
```

Alles was du `print()` sagst, siehst du unten rechts in der Konsole.

### Technik 2: Schrittweise bauen

Statt großes Skript auf einmal, Build es stück für stück:

```python
# Schritt 1: Szene löschen
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
print("Schritt 1: Szene gelöscht")

# Schritt 2: Würfel erstellen
bpy.ops.mesh.primitive_cube_add()
print("Schritt 2: Würfel erstellt")

# Schritt 3: Würfel skalieren
bpy.context.object.scale = (2, 1, 1)
print("Schritt 3: Würfel skaliert")
```

Nach jedem Play siehst du, bei welchem Schritt Fehler kommen.

### Technik 3: Try-Except für Fehlertoleranz

```python
import bpy

try:
    cube = bpy.data.objects["MyCube"]
    cube.scale = (2, 2, 2)
    print("✓ Würfel gefunden und skaliert")
except KeyError:
    print("FEHLER: Würfel 'MyCube' existiert nicht!")
except Exception as e:
    print(f"Unbekannter Fehler: {e}")
```

Dein Skript stürzt nicht ab, sondern gibt dir hilfreiche Fehlermeldungen.

---

## Kleine Projekte zum Üben

### Projekt 1: Random-Avatar Generator

```python
import bpy
import random

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Zufällige Größen
size = random.uniform(0.5, 2.0)

# Zufällige Farbe
color = (random.random(), random.random(), random.random(), 1.0)

# Würfel erstellen
bpy.ops.mesh.primitive_cube_add(size=size)
cube = bpy.context.object

# Material zuweisen
mat = bpy.data.materials.new("RandomColor")
mat.use_nodes = True
mat.node_tree.nodes["Principled BSDF"].inputs['Base Color'].default_value = color
cube.data.materials.append(mat)

print(f"Random Avatar: Size={size:.2f}, Color=RGB{color[:3]}")
```

### Projekt 2: Animation-Keyframes

```python
import bpy

# Aktives Objekt
obj = bpy.context.object

# Keyframe 1: Start (Frame 1)
obj.location = (0, 0, 0)
obj.keyframe_insert(data_path="location", frame=1)

# Keyframe 2: Mitte (Frame 30)
obj.location = (2, 0, 0)
obj.keyframe_insert(data_path="location", frame=30)

# Keyframe 3: Ende (Frame 60)
obj.location = (0, 0, 0)
obj.keyframe_insert(data_path="location", frame=60)

print("Animation erstellt: Objekt bewegt sich nach rechts und zurück")
```

---

## Next Steps

1. **Erstes Skript:** Kopiere "Hallo Würfel" und spiele es ab
2. **Experiment:** Ändere Größe, Farbe, Position → Play → Sieh Ergebnisse
3. **Fehler sammeln:** Schreib Code falsch → Fehler sehen → Verstehen
4. **Kleine Projekte:** Random Generator, Animation
5. **Größere Automationen:** Wenn du bereit bist, frag Claude um Hilfe

---

**💡 Merksatz:** Manuelles Scripting ist langsamer für komplexe Dinge, aber du VERSTEHST was los ist. Das ist wertvoll für Debugging und Anpassungen später. Nutze es zum Lernen und für einfache Aufgaben!
