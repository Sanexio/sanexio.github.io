# Design-Skills: Manuelle Installation

## Voraussetzungen

- macOS mit Claude Code installiert (CLI)
- Terminal-Zugriff
- Optional: API-Key von 21st.dev (für den MCP-Server)

---

## Schritt 1: Skills-Ordner finden

Die Claude Code Skills liegen standardmäßig hier:

```bash
~/.claude/skills/
```

Prüfe, ob der Ordner existiert:

```bash
ls -la ~/.claude/skills/
```

Falls er nicht existiert, erstelle ihn:

```bash
mkdir -p ~/.claude/skills/
```

---

## Schritt 2: Design-Skills kopieren

Die drei Skill-Ordner liegen in deinem Claude-OS-Workspace:

```
Claude-OS/skills/frontend-design/SKILL.md
Claude-OS/skills/ui-ux-pro-max/SKILL.md
Claude-OS/skills/21st-dev-magic/SKILL.md
```

Kopiere sie nach `~/.claude/skills/`:

```bash
# Pfad anpassen falls dein Claude-OS-Ordner woanders liegt
CLAUDE_OS="$HOME/Claude-OS"

# Frontend Design Skill
mkdir -p ~/.claude/skills/frontend-design
cp "$CLAUDE_OS/skills/frontend-design/SKILL.md" ~/.claude/skills/frontend-design/

# UI-UX Pro Max Skill
mkdir -p ~/.claude/skills/ui-ux-pro-max
cp "$CLAUDE_OS/skills/ui-ux-pro-max/SKILL.md" ~/.claude/skills/ui-ux-pro-max/

# 21st.dev Magic Skill
mkdir -p ~/.claude/skills/21st-dev-magic
cp "$CLAUDE_OS/skills/21st-dev-magic/SKILL.md" ~/.claude/skills/21st-dev-magic/
```

**Alternativ** — alles auf einmal:

```bash
for skill in frontend-design ui-ux-pro-max 21st-dev-magic; do
  mkdir -p ~/.claude/skills/$skill
  cp "$CLAUDE_OS/skills/$skill/SKILL.md" ~/.claude/skills/$skill/
done
```

---

## Schritt 3: Prüfen ob die Skills erkannt werden

Starte Claude Code neu und prüfe:

```bash
claude --skills
```

Oder frage Claude direkt:

> "Welche Skills hast du aktiv?"

Du solltest `frontend-design`, `ui-ux-pro-max` und `21st-dev-magic` in der Liste sehen.

---

## Schritt 4: 21st.dev MCP-Server einrichten (optional)

Der 21st.dev Magic Skill funktioniert auch ohne MCP-Server (als Referenz-Datenbank). Aber MIT MCP-Server bekommst du zusätzlich die Möglichkeit, Komponenten per Sprachbefehl generieren zu lassen.

### 4a. API-Key besorgen

1. Gehe zu https://21st.dev
2. Account erstellen (GitHub-Login möglich)
3. Unter Settings → API-Key generieren
4. Key kopieren

### 4b. MCP-Server installieren

**Automatisch (empfohlen):**

```bash
npx @21st-dev/cli@latest install claude --api-key DEIN_API_KEY
```

**Manuell** — bearbeite `~/.claude/mcp_config.json`:

```bash
# Datei öffnen (oder erstellen falls nicht vorhanden)
nano ~/.claude/mcp_config.json
```

Füge ein (oder ergänze den `mcpServers`-Block):

```json
{
  "mcpServers": {
    "@21st-dev/magic": {
      "command": "npx",
      "args": ["-y", "@21st-dev/magic@latest"],
      "env": {
        "API_KEY": "DEIN_API_KEY_HIER"
      }
    }
  }
}
```

Speichern mit `Ctrl+O`, `Enter`, `Ctrl+X`.

### 4c. Prüfen

Starte Claude Code neu. Der MCP-Server sollte beim Start geladen werden:

```
MCP: @21st-dev/magic connected
```

---

## Schritt 5: CLAUDE.md ergänzen (optional aber empfohlen)

Im Video von Julian Ivanov wird empfohlen, die Design-Skills auch in der `CLAUDE.md` deines Projekts zu referenzieren. Das verstärkt die Wirkung.

Öffne die `CLAUDE.md` deines Projekts (z.B. `Claude-OS/CLAUDE.md`) und füge hinzu:

```markdown
## Design-Regeln

- Nutze den `frontend-design` Skill für alle UI-Entscheidungen
- Nutze `ui-ux-pro-max` für Design-System-Generierung
- Nutze `21st-dev-magic` für Component-Inspiration
- Keine generischen AI-Aesthetics
- Bold, distinctive Design-Choices
- Performance-optimiert (Core Web Vitals)
```

---

## Troubleshooting

### Skills werden nicht erkannt

**Prüfe die Ordnerstruktur:**
```bash
ls ~/.claude/skills/frontend-design/SKILL.md
ls ~/.claude/skills/ui-ux-pro-max/SKILL.md
ls ~/.claude/skills/21st-dev-magic/SKILL.md
```

Alle drei Dateien müssen existieren. Falls nicht: Kopier-Befehl wiederholen.

### MCP-Server startet nicht

**Node.js prüfen:**
```bash
node --version
```

Du brauchst Node.js 18+ (idealerweise 20+). Falls nicht installiert:

```bash
brew install node
```

**npx testen:**
```bash
npx --version
```

### Skill wird nicht automatisch getriggert

Wenn der Skill nicht automatisch aktiviert wird, kannst du ihn manuell aufrufen:

```
/frontend-design
```

oder

```
/ui-ux-pro-max
```

### Falscher Stil wird gewählt

Sei spezifischer in deinem Prompt:

> ❌ "Mach eine Website"
> ✅ "Mach eine Website im Editorial-Stil mit Syne als Heading-Font"

---

## Zusammenfassung der Befehle

| Was | Befehl |
|-----|--------|
| Skills-Ordner prüfen | `ls ~/.claude/skills/` |
| Skills kopieren | `cp -r skills/frontend-design ~/.claude/skills/` |
| MCP installieren | `npx @21st-dev/cli@latest install claude --api-key KEY` |
| MCP-Config bearbeiten | `nano ~/.claude/mcp_config.json` |
| Claude Code neu starten | Claude Code beenden und neu öffnen |
| Skill manuell aufrufen | `/frontend-design` oder `/ui-ux-pro-max` |

---

## Quellen

- Frontend Design Skill: https://github.com/anthropics/claude-code/tree/main/plugins/frontend-design
- UI-UX Pro Max: https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
- 21st.dev Magic MCP: https://github.com/21st-dev/magic-mcp
- Video-Anleitung (Julian Ivanov): https://www.youtube.com/watch?v=MHki2JLR428
- Anthropic Cookbook — Frontend Aesthetics: https://platform.claude.com/cookbook/coding-prompting-for-frontend-aesthetics

---

## Nächste Schritte

- **Theorie verstehen**: Siehe `01-design-skills.md`
- **Claude-Prompts lernen**: Siehe `01-design-skills_claude.md`
- **Juvantis-Website**: Skills im Shopify-Projekt einsetzen
- **iOS-App**: SwiftUI-Guidelines aus `ui-ux-pro-max` nutzen
