# Blender: Python Scripting (bpy)

## Was lernst du hier?

Mit Blender's Python API (`bpy`) kannst du:
- Modelle automatisch generieren
- Shape Keys programmieren (für Avatar-Mimik)
- Alles exportieren per Skript
- Sich wiederholende Aufgaben automatisieren

**Für Juvantis wichtig:** Claude Code kann Python-Skripte generieren, die in Blender ausgeführt werden. Das ist schneller als alles manuell zu bauen.

---

## Blender Scripting Tab öffnen

In Blender:
1. Oben rechts: Klick auf "Scripting" (oder "+" neben dem Tab-Namen)
2. Neue Blender-Layout öffnet mit Scripting-Panel

```
┌──────────────────────────────────┐
│ Python Editor (links)            │
│ (Schreib hier dein Skript)       │
├──────────────────────────────────┤
│ 3D Viewport (rechts)             │
│ (Sehe die Ergebnisse live!)      │
└──────────────────────────────────┘
```

---

## Erstes Script: Objekt erstellen

```python
import bpy

# Alle Mesh-Objekte löschen (um sauber zu starten)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# Cube hinzufügen
bpy.ops.mesh.primitive_cube_add(size=2, location=(0, 0, 0))

# Wähle das neue Objekt
cube = bpy.context.object
cube.name = "MyFirstCube"
print(f"Cube erstellt: {cube.name}")
```

**Wie du das ausführst:**
1. Kopiere den Code in den Scripting-Tab
2. Drücke das Play-Icon (oder `Alt + P`)
3. In der 3D View erscheint ein Würfel!

**Was der Code macht:**
- `bpy.ops.object.select_all()` = wähle alle Objekte
- `bpy.ops.object.delete()` = lösche sie
- `bpy.ops.mesh.primitive_cube_add()` = erstelle einen Cube
- `bpy.context.object` = das gerade aktive Objekt (der Cube)
- `cube.name = "..."` = benenne ihn um

---

## Objekte modifizieren: Eigenschaften ändern

```python
import bpy

# Wähle das erste Objekt in der Szene
obj = bpy.data.objects[0]

# Größe verändern (skalieren)
obj.scale = (2, 2, 1)  # 2x breiter, 1x höher

# Position verändern
obj.location = (0, 0, 5)  # Nach oben verschieben

# Rotation
import math
obj.rotation_euler = (math.radians(45), 0, 0)  # 45 Grad um X-Achse

print(f"Objekt: {obj.name}")
print(f"Position: {obj.location}")
print(f"Größe: {obj.scale}")
```

---

## Materialien und Farben

```python
import bpy

# Erstelle neues Material
mat = bpy.data.materials.new(name="MyMaterial")
mat.use_nodes = True

# Hole den "Base Color" Node
bsdf = mat.node_tree.nodes["Principled BSDF"]

# Setze die Farbe (RGBA: Rot, Grün, Blau, Alpha)
bsdf.inputs['Base Color'].default_value = (1.0, 0.2, 0.5, 1.0)  # Rosa

# Setze Material zu glänzend (Metallic)
bsdf.inputs['Metallic'].default_value = 0.8

# Füge Material zu einem Objekt hinzu
obj = bpy.context.object
if obj.data.materials:
    obj.data.materials[0] = mat
else:
    obj.data.materials.append(mat)

print("Material zugewiesen!")
```

---

## Shape Keys: Mimik und Animation programmieren

Shape Keys sind super wichtig für deinen Avatar. Hier's wie du sie per Skript erstellst:

```python
import bpy

# Nimm den aktuellen Objekt (Head)
obj = bpy.context.object

# Stelle sicher, dass es ein Mesh ist
if obj.type != 'MESH':
    print("Fehler: Das ist kein Mesh-Objekt!")
else:
    # Erstelle einen Shape Key "Basis" (der Default)
    if not obj.data.shape_keys:
        basis = obj.shape_key_add(name="Basis")

    # Erstelle einen neuen Shape Key "Lächeln"
    smile = obj.shape_key_add(name="Smile")

    # Gib dem Shape Key einen Wert (0-1)
    # smile.value = 0.5  # Halb-Lächeln

    print(f"Shape Keys erstellt!")
    for sk in obj.data.shape_keys.key_blocks:
        print(f"  - {sk.name}")
```

---

## Shape Key mit Vertex-Verschiebung editieren

Das ist fortgeschrittener, aber möglich:

```python
import bpy
import bmesh

obj = bpy.context.object

if obj.type != 'MESH':
    print("Fehler: Nicht einmal ein Mesh!")
else:
    # Hole den Shape Key "Smile" (du musst ihn vorher erstellt haben)
    if "Smile" not in obj.data.shape_keys.key_blocks:
        print("Smile Shape Key existiert nicht!")
    else:
        smile_key = obj.data.shape_keys.key_blocks["Smile"]

        # Wechsle zu Edit Mode (um Vertices zu bearbeiten)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')

        # Bekomme BMesh (Blender Mesh für Scripting)
        me = obj.data
        bm = bmesh.from_edit_mesh(me)

        # Verschiebe die ersten 5 Vertices nach oben (für Lächeln)
        for i, vertex in enumerate(bm.verts[:5]):
            smile_key.data[vertex.index].co.z += 0.1  # 0.1 unit nach oben

        # Update und zurück zu Object Mode
        bmesh.update_edit_mesh(me)
        bpy.ops.object.mode_set(mode='OBJECT')

        print(f"Shape Key 'Smile' editiert!")
```

---

## Avatar selbst bauen: Ein komplettes Skript

Hier's ein Skript, das einen einfachen Avatar mit Body, Head und Eyes erstellt:

```python
import bpy
import math

# Leere die Szene
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

# 1. BODY (Cylinder)
bpy.ops.mesh.primitive_cylinder_add(radius=0.5, depth=2, location=(0, 0, 1))
body = bpy.context.object
body.name = "Body"

# Material für Body (blau)
mat_blue = bpy.data.materials.new("BodyMaterial")
mat_blue.use_nodes = True
mat_blue.node_tree.nodes["Principled BSDF"].inputs['Base Color'].default_value = (0.2, 0.5, 1.0, 1.0)
body.data.materials.append(mat_blue)

# 2. HEAD (UV Sphere)
bpy.ops.mesh.primitive_uv_sphere_add(radius=0.6, location=(0, 0, 2.5))
head = bpy.context.object
head.name = "Head"

# Material für Head (hautfarbe)
mat_skin = bpy.data.materials.new("SkinMaterial")
mat_skin.use_nodes = True
mat_skin.node_tree.nodes["Principled BSDF"].inputs['Base Color'].default_value = (1.0, 0.8, 0.7, 1.0)
head.data.materials.append(mat_skin)

# Shape Key für Lächeln
if not head.data.shape_keys:
    head.shape_key_add(name="Basis")
head.shape_key_add(name="Smile")

# 3. LEFT EYE (kleine Sphere)
bpy.ops.mesh.primitive_uv_sphere_add(radius=0.15, location=(-0.2, 0.3, 2.8))
eye_l = bpy.context.object
eye_l.name = "EyeLeft"

mat_white = bpy.data.materials.new("EyeMaterial")
mat_white.use_nodes = True
mat_white.node_tree.nodes["Principled BSDF"].inputs['Base Color'].default_value = (1.0, 1.0, 1.0, 1.0)
eye_l.data.materials.append(mat_white)

# 4. RIGHT EYE
bpy.ops.mesh.primitive_uv_sphere_add(radius=0.15, location=(0.2, 0.3, 2.8))
eye_r = bpy.context.object
eye_r.name = "EyeRight"
eye_r.data.materials.append(mat_white)

print("Avatar erstellt!")
print(f"  - Body: {body.name}")
print(f"  - Head: {head.name} (mit Smile Shape Key)")
print(f"  - Eyes: {eye_l.name}, {eye_r.name}")
```

**Wenn du das ausführst:**
1. Play-Icon drücken
2. In der 3D View erscheint ein einfacher Avatar mit Körper, Kopf und Augen!

---

## USDZ exportieren per Skript

```python
import bpy
import os

# Exportiere die Szene als USDZ
export_path = "/Users/ssmd/Desktop/avatar.usdz"

bpy.ops.export_usdz.usdz(
    filepath=export_path,
    export_animations=True,
    export_materials=True,
    export_smooth_groups=True
)

print(f"USDZ exportiert zu: {export_path}")
```

**Wichtig:** Ersetze `/Users/ssmd/Desktop/` mit deinem echten Pfad!

---

## Skripte speichern und wiederverwenden

Du kannst ein Skript speichern und später wieder laden:

### 1. Skript als Datei speichern

```
Im Scripting-Tab:
Text > Save As
→ Speichere als: create_avatar.py
```

### 2. Skript wieder laden

```
Text > Open Recent
→ Wähle create_avatar.py
```

### 3. Skript aus der Command Line ausführen

```bash
blender --python ~/path/to/create_avatar.py --render-frame 0
```

Oder mit Output-Datei:

```bash
blender --python ~/create_avatar.py -o ~/output/avatar.usdz
```

---

## Claude Code + Blender Workflow

So funktioniert die Integration:

```
1. Du sagst zu Claude:
   "Erstelle ein Python-Skript für einen Avatar mit..."

2. Claude generiert ein bpy-Skript

3. Du kopierst das Skript in Blender's Scripting Tab

4. Drückst Play

5. Avatar ist da!

6. Exportierst als USDZ

7. Nutzt in iOS-App
```

**Beispiel-Prompt für Claude:**
```
Erstelle ein Blender Python-Skript, das:
- Eine Kugel für den Kopf erzeugt
- Ein Rechteck für den Körper
- Zwei kleine Kugeln für Augen
- Ein Shape Key "Lächeln" für Mimik
- Alles als USDZ zu ~/avatar.usdz exportiert
```

Claude generiert dann den Code, den du 1:1 in Blender nutzen kannst!

---

## Häufige Fehler in bpy

### Fehler: "No context data"

**Grund:** Du versuchst, etwas zu tun, aber es gibt kein aktives Objekt.

**Lösung:**
```python
# Sicher eine Objekt haben
obj = bpy.data.objects.get("MyObject")
if not obj:
    print("Objekt nicht gefunden!")
```

---

### Fehler: "Operator bpy.ops... poll() failed"

**Grund:** Der Befehl funktioniert nicht im aktuellen Kontext.

**Lösung:** Nutze low-level API statt `bpy.ops`:

```python
# Statt:
bpy.ops.mesh.primitive_cube_add()

# Besser:
mesh = bpy.data.meshes.new("CubeMesh")
obj = bpy.data.objects.new("Cube", mesh)
bpy.context.collection.objects.link(obj)
```

---

### Fehler: "AttributeError: ... has no attribute ..."

**Grund:** Das Attribut/die Eigenschaft existiert nicht.

**Lösung:** Print alle verfügbaren Attribute:
```python
print(dir(bpy.context.object))
```

---

## Zusammenfassung: bpy Cheat Sheet

| Code | Was es macht |
|------|--------------|
| `bpy.ops.mesh.primitive_cube_add()` | Cube erstellen |
| `bpy.ops.mesh.primitive_uv_sphere_add()` | Sphere erstellen |
| `bpy.context.object` | Das aktive Objekt |
| `obj.location = (x, y, z)` | Position setzen |
| `obj.scale = (x, y, z)` | Größe setzen |
| `obj.rotation_euler = (x, y, z)` | Rotation setzen |
| `obj.shape_key_add(name="...")` | Shape Key erstellen |
| `bpy.data.materials.new(name)` | Material erstellen |
| `bpy.ops.export_usdz.usdz(...)` | Als USDZ exportieren |

---

## Nächste Schritte

1. **Probiere das Avatar-Skript aus:**
   - Kopiere es in Blender
   - Drücke Play
   - Sieh dein Modell!

2. **Experimentiere mit Shape Keys:**
   - Füge Shape Keys hinzu
   - Ändere Vertex-Positionen
   - Animiere den Avatar

3. **Exportiere als USDZ:**
   - Nutze das Export-Skript
   - Lade es in deine iOS-App

4. **Frag Claude:**
   - "Erstelle ein Skript für..."
   - Nutze die generierten Skripte in Blender

---

**💡 Tipp:** Blender's Scripting ist mächtig, aber auch komplex. Wenn ein Skript nicht funktioniert, checke:
1. Gibt es ein aktives Objekt?
2. Ist der Objekt-Typ richtig?
3. Gibt es Fehler in der Python Console (rechts unten)?

**Helpful Resource:** https://docs.blender.org/api/current/
