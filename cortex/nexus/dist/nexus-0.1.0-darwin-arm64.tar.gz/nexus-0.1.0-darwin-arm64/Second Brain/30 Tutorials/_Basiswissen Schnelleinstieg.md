---
type: moc
aliases: [Basiswissen, Schnelleinstieg, Tutorial-Karte, Wo anfangen, Onboarding]
tags:
  - moc
  - tutorial
  - basiswissen
  - schnelleinstieg
source: Second Brain/30 Tutorials/_Basiswissen Schnelleinstieg.md
---

# Basiswissen — Schnelleinstieg

> **Wo anfange ich?** Diese Seite ist die zentrale Karte über alle Tutorials.
> Sie zeigt, welche Themen es gibt, was sie für **deinen** Alltag bedeuten und
> in welcher Reihenfolge du sie sinnvoll lernst.

> [!info] Lesezeit
> - Diese Seite überfliegen: **5 Minuten**
> - Eine Domäne-Landing-Page lesen: **5–10 Minuten**
> - Ein einzelnes Modul (Theorie): **10–20 Minuten**

---

## 1. Deine Lernprioritäten — woher kommt die Reihenfolge?

Aus `_memory/MEMORY.md` (Nutzer-Kontext) sind drei Prioritäten festgehalten:

| # | Schwerpunkt | Warum |
|---|-------------|-------|
| **1** | **Sysadmin Praxis** | Praxis-Server (Proxmox, DC, File-Server, Praxissoftware) selbst warten und verstehen. Ausfälle kosten direkt Patienten-Zeit. |
| **2** | **Web-Programmierung** | Praxis-Webseite (WordPress) und Juvantis-Webseite (Shopify) selbst gestalten und reparieren können. |
| **3** | **iOS DHT** | Juvantis-iOS-App — Digital Health Twin mit personalisiertem 3D-Avatar. Spätsommer 2026 Launch. |

Querschnittsthemen ohne harte Reihenfolge: **Arbeitsweise**, **Design**, **Terminal**, **Git**.

---

## 2. Domänen-Karte (alle Tutorials in einem Blick)

> **Domain-Status mit Modul-Counts steht jetzt zentral in [[_MOC Tutorials]]
> §"Tutorial-Domänen".** Diese Seite hier konzentriert sich auf Lernpfade
> — die Status-Tabelle wird nicht mehr doppelt gepflegt (Drift-Quelle, vor
> Sprint F2 Reorg).
>
> **Kurzform für den schnellen Überblick:**

- 🟢 **Solide** (operative Tiefe, mehrere Module): Cortex & Nexus · Arbeitsweise · Terminal · Netzwerk & Sysadmin · Proxmox · **Webdesign (12, generisch)** · **WordPress (22, Praxis-Lessons)** · Shopify & Liquid · Blender & 3D
- 🟡 **Basis vorhanden:** iOS & Swift
- 🟠 **Dünn / Landing:** Browser-Automatisierung · Gaming · KI & Claude · Python · Sicherheit & Datenschutz

Verteiler-Domänen (Dach-Files ohne eigenen Status): **Webentwicklung** (über Webdesign + WordPress + Shopify + Browser-Automatisierung) · **Design** (über Blender + Design-Skills).

Vollständige Tabelle mit Modul-Counts → [[_MOC Tutorials]].

---

## 3. Empfohlene Lernpfade

### Pfad A — „Praxis-Sysadmin verstehen" (höchste Priorität)

> Ziel: Du kannst die Praxis-Hardware lesen, Probleme einordnen und mit dem
> EDV-Dienstleister auf Augenhöhe sprechen. **~3–4 Stunden zum Überfliegen.**

1. [[Netzwerk Grundlagen]] · 5 Min Übersicht — IP, DNS, DHCP, Router, Switch, Gateway
2. [[Netzwerk & Sysadmin/03-ip-adressen|IP-Adressen]] · 10 Min — Was sind 192.168.x.x vs. öffentliche IPs?
3. [[Netzwerk & Sysadmin/06-dns|DNS]] · 10 Min — Wie wird `westend-hausarzt.com` zu einer IP?
4. [[Proxmox Grundlagen]] · 5 Min Übersicht — Was ist Virtualisierung?
5. [[Netzwerk & Sysadmin/Proxmox/01-grundlagen|Proxmox 01]] · 15 Min — Hypervisor-Konzept, Typ 1 vs. 2
6. [[Netzwerk & Sysadmin/Proxmox/02-vms-und-container|Proxmox 02]] · 15 Min — VMs vs. Container, wann was?
7. [[Netzwerk & Sysadmin/Proxmox/03-storage-und-backup|Proxmox 03]] · 15 Min — Backup-Strategien (DAS Praxis-Thema)
8. [[Netzwerk & Sysadmin/Proxmox/05-sicherheit|Proxmox 05]] · 15 Min — Firewall, Zugriff, SSL
9. [[Netzwerk & Sysadmin/Proxmox/praxis-konfiguration|Praxis-Konfig]] · 30 Min — Dein konkretes Setup

**Querverweise:** [[Netzwerk & Sysadmin/homelab-handbuch|Homelab-Handbuch]] für deine Cluster-Minis · [[Netzwerk & Sysadmin/09-cortex-mesh-tailscale|Tailscale-Mesh]] für Geräte-übergreifende Verbindung.

---

### Pfad B — „Web-Programmierung von 0 auf 1" (Priorität 2)

> Ziel: Du verstehst, wie deine Webseiten technisch funktionieren. Du kannst
> Texte ändern, Bilder tauschen, Layout-Probleme einordnen. **~3 Stunden.**

1. [[Webentwicklung Grundlagen]] · 10 Min — Was ist eine Webseite? Frontend/Backend, Stacks
2. [[Terminal Grundlagen]] · 10 Min — Du brauchst Terminal-Basics für alles Weitere
3. [[Terminal/01-grundlagen|Terminal 01]] · 20 Min — Die 30 Befehle, die du 90 % brauchst
4. [[Git Grundlagen]] · 10 Min — Was ist Versionskontrolle?
5. [[Terminal/02-git|Terminal 02 (Git)]] · 20 Min — Die 7 Git-Befehle
6. [[Webdesign Grundlagen]] · 10 Min — Übersicht 12 Kapitel (generisch) + [[WordPress Grundlagen]] für 22 Praxis-Lessons
7. [[Webentwicklung/Webdesign/01-webdesign-basics|Webdesign 01]] · 20 Min — HTML/CSS-Basics
8. [[Webentwicklung/Webdesign/05-design-tokens-und-cascade|Webdesign 05]] · 15 Min — Design-Tokens (das System hinter „Farbe ändern")
9. [[Shopify Grundlagen]] · 10 Min — Shopify-Theme-Aufbau (Sections, Templates, Snippets)
10. [[Webentwicklung/Shopify & Liquid/01-liquid-basics|Shopify 01 — Liquid]] · 20 Min — Template-Sprache

**Querverweise:** Wenn dich CSS-Spezifität verwirrt → [[Webentwicklung/Webdesign/09-css-spezifitaet-und-komponenten-schichten|Webdesign 09]]. Wenn dich „Wie kommen Daten in die Seite?" interessiert → [[WordPress/04-wp-rest-api-adapter-mit-application-passwords|WordPress 04 (WP-REST-API)]].

---

### Pfad C — „iOS-App Grundverständnis" (Priorität 3)

> Ziel: Du verstehst, wie Juvantis-iOS gebaut ist. Du kannst Code-Reviews
> sinnvoll mitgehen. **~2 Stunden.**

1. [[iOS Grundlagen]] · 10 Min — Warum Swift, was kann Xcode, MVVM-Begriff
2. [[iOS & Swift/01-grundlagen|iOS 01]] · 30 Min — Swift-Syntax (Variablen, Typen, Optionals, Funktionen)
3. [[iOS & Swift/02-swiftui|iOS 02]] · 40 Min — SwiftUI: Navigation, State, Listen, Async, HealthKit
4. [[Design/Blender & 3D/01-grundlagen|Blender 01]] · 20 Min — Avatar-Pipeline-Hintergrund
5. [[Design/Blender & 3D/02-python-scripting|Blender 02]] · 20 Min — Wie Claude Avatare baut

**Querverweise:** Avatar-Lizenz-Gefahren → [[LL-027]]. BMI-Morphing-Metrik → [[LL-032]].

---

### Pfad D — „Wie wir zusammenarbeiten" (Querschnitt, immer relevant)

> Ziel: Du verstehst, **wie** Claude und du zusammen arbeiten — und warum
> bestimmte Regeln existieren. Erspart später viele Reibungen. **~1 Stunde.**

1. [[Arbeitsweise Grundlagen]] · 5 Min — Übersicht der 9 Module
2. [[Arbeitsweise & Prozess/01-architekten-modus|01-Architekten-Modus]] · 15 Min — 4-Phasen-Prozess (Verständnis → Design → Umsetzung → Selbstprüfung)
3. [[Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme|02-Memory-Systeme]] · 10 Min — Warum MEMORY.md nicht beliebig wachsen darf (Token-Budgets)
4. [[Arbeitsweise & Prozess/06-projekt-prio-leiter-holistic|06-Prio-Leiter]] · 10 Min — Welche Aufgabe verdient deine Zeit?
5. [[Arbeitsweise & Prozess/07-vault-kommunikation|07-Vault-Kommunikation]] · 10 Min — Wie du Claude über `[!frage]`/`[!anweisung]`-Callouts ansprichst
6. [[Arbeitsweise & Prozess/08-content-archive-triage|08-Content-Triage]] · 10 Min — Wie 200 Pages in eine handhabbare Sortierung kommen

---

## 4. Wenn du nur 30 Minuten hast

> Schnellkurs „verstehe das Cortex-Ökosystem". Reihenfolge nicht zufällig:

1. [[_MOC Tutorials]] · 2 Min — die offizielle Tutorial-Karte
2. [[Arbeitsweise Grundlagen]] · 3 Min — wie wir zusammenarbeiten
3. [[Terminal Grundlagen]] · 5 Min — was du im Terminal überhaupt machst
4. [[Netzwerk Grundlagen]] · 5 Min — was hinter „IP", „DNS", „Router" steckt
5. [[Webentwicklung Grundlagen]] · 5 Min — Frontend vs. Backend, WordPress vs. Shopify
6. [[Design Grundlagen]] · 5 Min — warum KI-Webseiten oft langweilig aussehen und was dagegen hilft
7. **Eine konkrete Frage formulieren** → in Vault als `> [!frage]` oder direkt im Chat — Claude verzweigt dann zum richtigen Modul

---

## 5. Wenn ein Thema nicht da ist

Phase 2 (2026-04-25) hat die wichtigsten vier Lücken geschlossen — die Tabelle zeigt verbliebene Gaps:

| Thema | Status | Wo es heute steht |
|---|---|---|
| ~~**KI / Claude / LLM-Grundlagen**~~ | ✅ **Phase 2** angelegt | [[KI & Claude Grundlagen]] (Landing-Page, Module folgen bei Bedarf) |
| ~~**Python für Praxis-Tools**~~ | ✅ **Phase 2** angelegt | [[Python Grundlagen]] (Landing-Page) |
| ~~**WordPress für Admins**~~ | ✅ **Phase 2 + Sprint F2 (22 Praxis-Module)** | [[WordPress Grundlagen]] mit 22 Modulen aus Praxis-Webseiten-Sprint |
| ~~**Sicherheit & Datenschutz**~~ | ✅ **Phase 2** angelegt | [[Sicherheit & Datenschutz Grundlagen]] (Landing-Page) |
| **HTML / CSS / JS Grundlagen** | bisher implizit in Webdesign | [[Webentwicklung/Webdesign/01-webdesign-basics|Webdesign 01]] deckt CSS-Cascade an, kein dediziertes HTML-Modul |
| **Datenbanken / SQL / Excel-Power** | bisher nicht | Relevant für SmartQ-Auswertungen, EÜR-Analyse |
| **MCP-Server bauen** | als Roadmap-Modul in [[KI & Claude Grundlagen]] | telegram-bridge ist gebaut, aber kein Lehrmaterial — Modul 03 dort geplant |
| **Praxis-Server konkret** (DC, File-Server, AFIAS-Anbindung) | teilweise in Proxmox-Praxis-Konfig | Gerätespezifisches Onboarding könnte eigenes Modul werden |

**Wenn du eines dieser Themen brauchst:** Sag Bescheid — Claude legt eine neue Domäne an (Hierarchie wird nach LL-041 selbständig gewählt).

---

## 6. Konventionen — was du beim Lesen wissen solltest

- **Drei-Dateien-Regel ([[TUT-001]]):** Pro Modul gibt es bis zu drei Dateien
  - `XX-thema.md` — Theorie (das **WAS**)
  - `XX-thema_claude.md` — Wie Claude die Aufgabe für dich automatisiert
  - `XX-thema_manuell.md` — Wie du es selbst im Terminal/UI machst
- **Sprache:** Deutsch im Inhalt, Code-Kommentare auf Englisch.
- **Single Source of Truth:** Alle Tutorial-Dateien liegen physisch in `Second Brain/30 Tutorials/<Domäne>/`. `_tutorials/<slug>/` sind nur Symlinks für Legacy-Pfad-Referenzen.
- **Wiki-Links:** `[[Datei]]` führt direkt zur Datei in Obsidian. In Claude Code steht der Pfad meist als Kommentar daneben.

---

## 7. Updates an dieser Seite

- **2026-05-05 (Sprint F2 Reorg):** Domain-Status-Tabelle in §2 entfernt — wird jetzt zentral in [[_MOC Tutorials]] gepflegt (Drift-Quelle eliminiert). WordPress-Domäne von "🟠 Landing" auf "🟢 22 Module Praxis-Lessons" gewechselt durch Webdesign-Aufspaltung. Webdesign von "🟢 25+ gemischt" auf "🟢 12 generisch". Git & GitHub aufgelöst. Lernpfad B-Querverweise auf Webdesign-Module weiter gültig (neue Nummerierung 01-12).
- **2026-04-30:** Eigene Domäne **Cortex & Nexus** angelegt und am selben Tag vervollständigt.
- **2026-04-25 (Phase 2):** Vier neue Konzept-Domänen — KI & Claude, Python, WordPress, Sicherheit & Datenschutz.
- **2026-04-25 (initial):** Master-MOC angelegt — zentrale Karte über alle Domänen, Lernpfade A–D.

Wann wieder anfassen?
- Wenn eine neue Domäne dazu kommt → in Tabelle §2 ergänzen.
- Wenn eine Domäne von 🟠 dünn auf 🟡 mittel wechselt → Status-Spalte aktualisieren.
- Wenn ein Lernpfad sich in der Praxis als zu lang/kurz herausstellt → Reihenfolge korrigieren.

---

## Verwandte Notizen

- [[_MOC Tutorials]] — Tutorial-MOC (technisch, Domain-Index)
- [[_MOC Kontext]] — Nutzer- und Praxis-Kontext
- [[_MOC Regeln]] — Globale Regeln (LL-001 ff.)
- [[_MOC Tools]] — Tool-Übersicht (`_lib/`, `Nexus/tools/`)
