# iOS-Programmierung: SwiftUI — Manueller Workflow

## Wann nutze ich diesen Weg?

Du brauchst den manuellen Workflow wenn:
- Du SwiftUI tiefgreifend verstehen möchtest (nicht nur Code kopieren)
- Du ein Feature selbst bauen möchtest und dabei lernen willst
- Du bereits Basic Swift kennst und jetzt UI-Programmierung lernst
- Du jeden Modifier und sein Verhalten verstehen möchtest
- Du Fehler selbst debuggen und verstehen möchtest

**Beispiel aus Juvantis:** Du brauchst eine Health-Grid mit 4 Karten. Statt Claude zu fragen, schreibst du selbst LazyVGrid, ForEach, HStack, etc. und lernst dabei SwiftUI intimat.

---

## Der Manuell-Workflow: SwiftUI Schritt für Schritt

```
1. Einfache View schreiben (nur Text)
      ↓
2. Layout mit VStack/HStack/ZStack
      ↓
3. Modifier hinzufügen (Farben, Spacing, Shapes)
      ↓
4. Interaktion mit @State/Button
      ↓
5. Komplexere Strukturen (List, Grid, ForEach)
      ↓
6. State Management mit ViewModel
```

---

## Schritt 1: Text View mit Modifier

**Datei: HealthDetailView.swift**

```swift
import SwiftUI

struct HealthDetailView: View {
    var body: some View {
        Text("Mein Health")
            .font(.largeTitle)          // Große Schrift
            .fontWeight(.bold)          // Fett
            .foregroundColor(.blue)     // Blaue Farbe
            .padding()                  // Abstände drum herum
            .background(Color.gray.opacity(0.1))  // Grauer Hintergrund
            .cornerRadius(8)            // Runde Ecken
    }
}

#Preview {
    HealthDetailView()
}
```

**Was du siehst:**
- Großer, fetter, blauer Text
- Mit grauem Hintergrund und runden Ecken

**Modifier werden von innen nach außen angewendet:**
1. Text("Mein Health")
2. .font() Größe ändern
3. .foregroundColor() Farbe ändern
4. .padding() Abstände
5. .background() Hintergrund
6. .cornerRadius() Ecken runden

---

## Schritt 2: Layout mit VStack und HStack

```swift
struct HealthDetailView: View {
    var body: some View {
        VStack {  // Vertikal stapeln
            // Oben: Titel
            Text("Deine Health Metriken")
                .font(.title)

            // Darunter: 2 Zeilen mit 2 Spalten
            HStack {  // Horizontal stapeln
                VStack {
                    Text("Puls")
                    Text("72")
                        .font(.title2)
                    Text("bpm")
                        .font(.caption)
                }
                .padding()

                VStack {
                    Text("Schritte")
                    Text("8234")
                        .font(.title2)
                    Text("Steps")
                        .font(.caption)
                }
                .padding()
            }

            HStack {
                VStack {
                    Text("Wasser")
                    Text("2L")
                        .font(.title2)
                }
                .padding()

                VStack {
                    Text("Schlaf")
                    Text("7.5h")
                        .font(.title2)
                }
                .padding()
            }
        }
        .padding()
    }
}
```

**Layout sieht so aus:**
```
┌─────────────────────────┐
│ Deine Health Metriken   │
├─────────────┬───────────┤
│   Puls      │ Schritte  │
│    72       │   8234    │
│   bpm       │   Steps   │
├─────────────┼───────────┤
│   Wasser    │  Schlaf   │
│    2L       │   7.5h    │
└─────────────┴───────────┘
```

---

## Schritt 3: Spacing und Padding richtig nutzen

```swift
struct HealthDetailView: View {
    var body: some View {
        VStack(spacing: 16) {  // 16 points Abstand zwischen Views
            Text("Deine Metriken")
                .font(.title)

            HStack(spacing: 12) {
                // Metrik-Karten
                VStack {
                    Text("Puls")
                    Text("72")
                        .font(.title2)
                }
                .frame(maxWidth: .infinity)  // Füllt verfügbaren Platz
                .padding(12)                  // Abstand innen in Karte
                .background(Color.blue.opacity(0.1))
                .cornerRadius(8)

                VStack {
                    Text("Schritte")
                    Text("8234")
                        .font(.title2)
                }
                .frame(maxWidth: .infinity)
                .padding(12)
                .background(Color.green.opacity(0.1))
                .cornerRadius(8)
            }
            .padding()  // Abstand außen um HStack
        }
    }
}
```

**Was hier passiert:**
- `VStack(spacing: 16)` = 16 points zwischen Elementen
- `padding(12)` = 12 points Innen-Abstände
- `padding()` = Standardabstand (16 points)
- `frame(maxWidth: .infinity)` = füllt ganze Breite

---

## Schritt 4: State und Interaktion

```swift
struct HealthDetailView: View {
    @State var selectedMetric = "Puls"  // Welche Metrik ist ausgewählt

    var body: some View {
        VStack {
            Text("Deine Metriken")
                .font(.title)

            // Buttons zum Auswählen
            HStack(spacing: 8) {
                Button("Puls") {
                    selectedMetric = "Puls"
                }
                .buttonStyle(SelectedButtonStyle(isSelected: selectedMetric == "Puls"))

                Button("Schritte") {
                    selectedMetric = "Schritte"
                }
                .buttonStyle(SelectedButtonStyle(isSelected: selectedMetric == "Schritte"))

                Button("Wasser") {
                    selectedMetric = "Wasser"
                }
                .buttonStyle(SelectedButtonStyle(isSelected: selectedMetric == "Wasser"))
            }
            .padding()

            // Detail anzeigen je nach Auswahl
            switch selectedMetric {
            case "Puls":
                MetricDetailView(name: "Puls", value: "72", unit: "bpm")
            case "Schritte":
                MetricDetailView(name: "Schritte", value: "8234", unit: "Steps")
            case "Wasser":
                MetricDetailView(name: "Wasser", value: "2", unit: "L")
            default:
                Text("Unbekannt")
            }

            Spacer()  // Füllt restlichen Platz
        }
    }
}

// Custom Button Style für Selected/Unselected
struct SelectedButtonStyle: ButtonStyle {
    var isSelected: Bool

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(12)
            .background(isSelected ? Color.blue : Color.gray.opacity(0.2))
            .foregroundColor(isSelected ? .white : .black)
            .cornerRadius(8)
    }
}

// Sub-View für Metrik-Details
struct MetricDetailView: View {
    let name: String
    let value: String
    let unit: String

    var body: some View {
        VStack(spacing: 16) {
            Text(name)
                .font(.title2)
            Text(value)
                .font(.system(size: 48, weight: .bold))
                .foregroundColor(.blue)
            Text(unit)
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .padding()
        .background(Color.blue.opacity(0.05))
        .cornerRadius(12)
        .padding()
    }
}

#Preview {
    HealthDetailView()
}
```

**Was hier passiert:**
- `@State var selectedMetric` speichert Auswahl
- Button-Klick ändert selectedMetric → UI aktualisiert sich
- `switch` zeigt unterschiedliche Views je nach Auswahl
- `Spacer()` füllt restlichen Platz
- Custom ButtonStyle für Styling

---

## Schritt 5: ForEach und Listen

```swift
struct MetricsListView: View {
    let metrics = [
        ("Puls", "72", "bpm", Color.red),
        ("Schritte", "8234", "Steps", Color.green),
        ("Wasser", "2", "L", Color.blue),
        ("Schlaf", "7.5", "h", Color.purple),
    ]

    var body: some View {
        VStack {
            Text("Alle Metriken")
                .font(.title)

            List {  // List macht automatisch Reihen-Layout
                ForEach(metrics, id: \.0) { name, value, unit, color in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(name)
                                .font(.headline)
                            Text(unit)
                                .font(.caption)
                                .foregroundColor(.gray)
                        }

                        Spacer()

                        Text(value)
                            .font(.title2)
                            .foregroundColor(color)
                    }
                    .padding(8)
                }
            }
        }
    }
}
```

**ForEach-Syntax:**
```swift
ForEach(array, id: \.0) { item in
    // item ist jedes Element
}
```

Das `id: \.0` sagt: "use das erste Element (name) als unique ID".

---

## Schritt 6: Grid Layout (LazyVGrid)

```swift
struct HealthGridView: View {
    let metrics = [
        ("❤️", "Puls", "72", "bpm"),
        ("👟", "Schritte", "8234", "Steps"),
        ("💧", "Wasser", "2", "L"),
        ("😴", "Schlaf", "7.5", "h"),
    ]

    // 2 Spalten Grid
    let columns = [
        GridItem(.flexible(), spacing: 16),  // Spalte 1
        GridItem(.flexible(), spacing: 16),  // Spalte 2
    ]

    var body: some View {
        VStack {
            Text("Health Dashboard")
                .font(.title)

            ScrollView {
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(metrics, id: \.1) { icon, name, value, unit in
                        VStack(spacing: 8) {
                            Text(icon)
                                .font(.system(size: 36))
                            Text(name)
                                .font(.headline)
                            Text(value)
                                .font(.title2)
                                .foregroundColor(.blue)
                            Text(unit)
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 140)
                        .background(Color.blue.opacity(0.05))
                        .cornerRadius(12)
                    }
                }
                .padding()
            }
        }
    }
}
```

**Grid Layout:**
- `GridItem(.flexible())` = Spalte die Platz füllt
- `LazyVGrid(columns: columns)` = Grid mit definierten Spalten
- `ForEach` rendert Elemente in Grid

---

## Schritt 7: Animations und Übergänge

```swift
struct AnimatedMetricView: View {
    @State var isExpanded = false

    var body: some View {
        VStack {
            Button("Erweitere") {
                withAnimation(.easeInOut(duration: 0.3)) {
                    isExpanded.toggle()
                }
            }

            if isExpanded {
                VStack {
                    Text("Puls Details")
                    Text("72 bpm")
                        .font(.title)
                    Text("Normal")
                        .foregroundColor(.green)
                }
                .padding()
                .background(Color.green.opacity(0.1))
                .cornerRadius(8)
                .transition(.scale.combined(with: .opacity))
            }
        }
        .padding()
    }
}
```

**Animation Modifiers:**
- `withAnimation()` = Wrap State-Änderung in Animation
- `.easeInOut(duration:)` = Animation-Timing
- `.transition()` = Wie Element erscheint/verschwindet
- `.scale` = Skaliert beim Erscheinen
- `.opacity` = Fade In/Out

---

## Häufige Anfängerfehler

### Fehler: "Cannot assign to property: 'isExpanded' is immutable"

**Grund:** Ohne `@State` kann man Variable nicht ändern.

**Lösung:**
```swift
// Falsch
var isExpanded = false

// Richtig
@State var isExpanded = false
```

---

### Fehler: "List in VStack zeigt nur erste Reihe"

**Grund:** List braucht definierte Größe.

**Lösung:**
```swift
// Falsch
VStack {
    List { ... }
}

// Richtig
VStack {
    List { ... }
        .frame(height: 300)  // Oder dynamisch
}
```

---

### Fehler: "View ist zu komplex zu rendern"

**Grund:** Zu viel Logik in einer View.

**Lösung:** Aufteilen in kleine Sub-Views:

```swift
// Statt alles in HealthGridView
// Mache:

struct MetricCard: View {
    let icon: String
    let name: String
    let value: String
    var body: some View { ... }
}

struct HealthGridView: View {
    var body: some View {
        ForEach(...) { metric in
            MetricCard(...)  // Nutze Sub-View
        }
    }
}
```

---

## Debugging-Tipps

### Tip 1: Print-Statements in Closure

```swift
Button("Update") {
    print("Before: \(selectedMetric)")
    selectedMetric = "Puls"
    print("After: \(selectedMetric)")
}
```

Sieh in Xcode-Konsole, wenn Button geklickt wird.

### Tip 2: Preview-Modifikator

```swift
#Preview("Puls Selected") {
    HealthDetailView()  // Mit default state
}

#Preview("Schritte Selected") {
    // Wenn du state manuell setzen kannst
    @State var selectedMetric = "Schritte"
    return HealthDetailView()
}
```

Verschiedene Preview-Varianten für verschiedene States.

### Tip 3: Schrittweise bauen

Statt komplettes Grid auf einmal:
1. Text anzeigen
2. VStack/HStack Layout
3. Modifier (Farben, Padding)
4. Mehrere Elemente mit ForEach
5. Zu Grid umbauen (LazyVGrid)

Nach jedem Schritt: Preview checken.

---

## Kleine Übungsprojekte

### Projekt 1: Toggle Health Metric

```swift
struct HealthToggleView: View {
    @State var showPulse = true
    @State var showSteps = true
    @State var showWater = false

    var body: some View {
        Form {
            Toggle("Puls anzeigen", isOn: $showPulse)
            Toggle("Schritte anzeigen", isOn: $showSteps)
            Toggle("Wasser anzeigen", isOn: $showWater)

            if showPulse {
                Text("❤️ Puls: 72 bpm")
            }
            if showSteps {
                Text("👟 Schritte: 8234")
            }
            if showWater {
                Text("💧 Wasser: 2L")
            }
        }
    }
}
```

### Projekt 2: Health Data Editor

```swift
struct HealthEditorView: View {
    @State var heartRate = "72"
    @State var steps = "8234"

    var body: some View {
        Form {
            Section(header: Text("Messwerte eingeben")) {
                TextField("Herzfrequenz", text: $heartRate)
                    .keyboardType(.numberPad)
                TextField("Schritte", text: $steps)
                    .keyboardType(.numberPad)
            }

            Section {
                Button("Speichern") {
                    print("Gespeichert: \(heartRate), \(steps)")
                }
            }
        }
    }
}
```

---

## Next Steps

1. **Einfache View:** Text mit Modifiern schreiben
2. **Layout:** VStack/HStack kombinieren
3. **State:** @State und Button zum Ändern
4. **List:** ForEach über Array
5. **Grid:** LazyVGrid für 2+ Spalten
6. **Animations:** withAnimation und .transition

---

**💡 Merksatz:** Manuell schreiben braucht länger, aber du verstehst SwiftUI intuitiv. Jeder Modifier macht Sinn, nicht black-box. Das hilft beim Debugging und Anpassungen später!
