# iOS-Programmierung: SwiftUI Vertiefung

## Was lernst du hier?

SwiftUI-Grundlagen reichen für "Hallo Welt", aber echte Apps sind komplexer. Diese Lektion zeigt dir:
- Navigation zwischen Screens
- State Management für größere Datenmengen
- Listen und Grids (wichtig für Health-Daten in Juvantis)
- Formulare
- Asynchrone Operationen (Daten laden)

**Voraussetzung:** Du hast iOS-Programmierung > Grundlagen gelesen

---

## Navigation: Zwischen Views wechseln

### NavigationStack (ab iOS 16+)

Für moderne Apps nutzen wir `NavigationStack`. Das ist wie ein "Stack" (Stapel) von Screens:

```
[Home Screen] → [Detail Screen] → [Edit Screen]
     ↓              ↓
  tap Detail      tap Back
```

**Beispiel: Master-Detail Navigation**

```swift
import SwiftUI

struct PatientListView: View {
    let patients = ["Dr. Müller", "Dr. Schmidt", "Dr. Weber"]
    @State var selectedPatient: String?

    var body: some View {
        NavigationStack {
            List(patients, id: \.self) { patient in
                NavigationLink(value: patient) {
                    Text(patient)
                }
            }
            .navigationTitle("Patienten")
            .navigationDestination(for: String.self) { patient in
                PatientDetailView(name: patient)
            }
        }
    }
}

struct PatientDetailView: View {
    let name: String

    var body: some View {
        VStack {
            Text("Patient: \(name)")
            Text("Details hier...")
            NavigationLink("Zur Behandlung", value: "treatment")
                .navigationDestination(for: String.self) { page in
                    if page == "treatment" {
                        TreatmentView()
                    }
                }
        }
        .navigationTitle("Details")
    }
}

struct TreatmentView: View {
    var body: some View {
        Text("Behandlungsseite")
            .navigationTitle("Behandlung")
    }
}
```

**Was das tut:**
1. `NavigationStack` wrappet die ganze Navigation
2. `NavigationLink` ist ein Button, der zu einer neuen View navigiert
3. `.navigationDestination` definiert, welche View angezeigt wird
4. Automatisch "Zurück"-Button!

---

### TabView: Tabs wie in echten Apps

Für Apps mit mehreren Hauptbereichen (wie Health, Settings, etc.):

```swift
struct MainAppView: View {
    var body: some View {
        TabView {
            // Tab 1: Health
            HealthTrackerView()
                .tabItem {
                    Label("Health", systemImage: "heart.fill")
                }

            // Tab 2: Avatar
            AvatarView()
                .tabItem {
                    Label("Avatar", systemImage: "figure.stand")
                }

            // Tab 3: Settings
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gear")
                }
        }
    }
}

struct HealthTrackerView: View {
    var body: some View {
        Text("Deine Health-Daten")
    }
}

struct AvatarView: View {
    var body: some View {
        Text("Dein 3D-Avatar")
    }
}

struct SettingsView: View {
    var body: some View {
        Text("Einstellungen")
    }
}
```

Das sieht aus wie:
```
┌─────────────────┐
│ Deine Daten     │
│                 │
├─────────────────┤
│ [H] [A] [S]     │  ← Tabs unten
└─────────────────┘
```

---

## State Management: Daten über mehrere Views

Wenn mehrere Views die gleichen Daten brauchen, musst du sie im ViewModel zentralisieren.

### @ObservedObject und @Published

```swift
// ViewModel
class HealthModel: ObservableObject {
    @Published var heartRate: Int = 72
    @Published var steps: Int = 8234
    @Published var waterIntake: Int = 2000  // ml

    func addHeartRateMeasurement(_ rate: Int) {
        heartRate = rate
    }

    func addSteps(_ count: Int) {
        steps += count
    }
}

// View 1: Dashboard (zeigt Daten)
struct DashboardView: View {
    @ObservedObject var health: HealthModel

    var body: some View {
        VStack {
            Text("Puls: \(health.heartRate)")
            Text("Schritte: \(health.steps)")
            Text("Wasser: \(health.waterIntake) ml")
        }
    }
}

// View 2: Eingabe (ändert Daten)
struct InputView: View {
    @ObservedObject var health: HealthModel
    @State var newHeartRate = ""

    var body: some View {
        VStack {
            TextField("Puls eingeben", text: $newHeartRate)
            Button("Speichern") {
                if let rate = Int(newHeartRate) {
                    health.addHeartRateMeasurement(rate)
                    newHeartRate = ""
                }
            }
        }
    }
}

// In der Main App
struct ContentView: View {
    @StateObject var health = HealthModel()

    var body: some View {
        TabView {
            DashboardView(health: health)
                .tabItem { Label("Dashboard", systemImage: "chart.bar") }

            InputView(health: health)
                .tabItem { Label("Eingabe", systemImage: "pencil") }
        }
    }
}
```

**Was das tut:**
- `@Published` = "Wenn sich das ändert, sage allen Views Bescheid"
- `@ObservedObject` = "Ich beobachte dieses ViewModel"
- `@StateObject` = "Ich erstelle und besitze dieses ViewModel" (nutze das in der Main App)

**Der Fluss:**
```
InputView ändern → HealthModel.heartRate ändern → @Published
    ↓
DashboardView merkt Änderung → aktualisiert UI automatisch
```

---

### @EnvironmentObject: Globale Daten

Wenn du Daten an *viele* verschachtelte Views übergeben musst, ist `@EnvironmentObject` eleganter:

```swift
// In ContentView
@StateObject var health = HealthModel()

var body: some View {
    NavigationStack {
        MainView()
            .environmentObject(health)  // ← Mach `health` überall verfügbar
    }
}

// In einer verschachtelten View (egal wie tief)
struct DeepView: View {
    @EnvironmentObject var health: HealthModel

    var body: some View {
        Text("Puls: \(health.heartRate)")  // Kein Übergeben notwendig!
    }
}
```

Das ist besser als:
```swift
struct A: View { ... }  // Muss health übergeben
  struct B: View { ... }  // Muss health übergeben
    struct C: View { ... }  // Muss health übergeben
      struct D: View { ... }  // Endlich nutzt es health!
```

---

## Listen und Grids: Daten anzeigen

Deine Juvantis-App zeigt viele Health-Metriken. Hier sind die Wege:

### List: Einfache Listen

```swift
struct HealthListView: View {
    let measurements = [
        ("Puls", "72", "bpm"),
        ("Schritte", "8234", "Schritte"),
        ("Wasser", "2000", "ml"),
    ]

    var body: some View {
        List(measurements, id: \.0) { name, value, unit in
            HStack {
                Text(name)
                    .font(.headline)
                Spacer()  // Platz füllen
                Text("\(value) \(unit)")
                    .font(.subheadline)
            }
        }
        .listStyle(.plain)  // Entfernt graue Hintergründe
    }
}
```

---

### LazyVGrid: Karten-Grid (wie Pinterest)

Für deine Avatar-Galerie oder Health-Dashboard-Karten:

```swift
struct HealthGridView: View {
    let items = [
        ("Puls", "72", "red"),
        ("Schritte", "8234", "blue"),
        ("Kalorien", "2100", "orange"),
        ("Schlaf", "7.5h", "purple"),
    ]

    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]

    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 16) {
                ForEach(items, id: \.0) { name, value, color in
                    VStack {
                        Text(value)
                            .font(.title)
                            .foregroundColor(.white)
                        Text(name)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 100)
                    .background(Color(color))
                    .cornerRadius(8)
                }
            }
            .padding()
        }
    }
}
```

Das sieht aus wie:
```
┌────────┬────────┐
│ Puls   │ Schlaf │
│  72    │ 7.5h   │
├────────┼────────┤
│Schritte│Kalorien│
│ 8234   │ 2100   │
└────────┴────────┘
```

---

## Formulare: Eingaben sammeln

```swift
struct PatientFormView: View {
    @State var firstName = ""
    @State var lastName = ""
    @State var age = ""
    @State var selectedGender = "Weiblich"

    let genders = ["Männlich", "Weiblich", "Andere"]

    var body: some View {
        Form {
            Section(header: Text("Persönliche Daten")) {
                TextField("Vorname", text: $firstName)
                TextField("Nachname", text: $lastName)
                TextField("Alter", text: $age)
                    .keyboardType(.numberPad)  // Nummerntastatur
            }

            Section(header: Text("Geschlecht")) {
                Picker("Wähle Geschlecht", selection: $selectedGender) {
                    ForEach(genders, id: \.self) { gender in
                        Text(gender).tag(gender)
                    }
                }
            }

            Section {
                Button("Speichern") {
                    print("Gespeichert: \(firstName) \(lastName), \(age) Jahre")
                }
            }
        }
        .navigationTitle("Patientendaten")
    }
}
```

Das sieht aus wie ein echtes Formular mit Sections und Borders.

**Wichtige Modifier für Eingaben:**
```swift
TextField("Text", text: $userInput)
    .keyboardType(.numberPad)       // Nummerntastatur
    .textContentType(.emailAddress)  // Email-Tastatur
    .autocapitalization(.words)      // Groß-/Kleinschreibung

SecureField("Passwort", text: $password)  // Versteckt Text

Toggle("Notifications", isOn: $notificationsEnabled)
    .toggleStyle(.switch)

Picker("Wahl", selection: $selected) { ... }

DatePicker("Datum", selection: $date)
```

---

## Async/Await: Daten laden

Wenn deine App Daten vom Server laden muss (z.B. HealthKit, Cloud), musst du das asynchron machen (sonst friert die UI ein).

### Einfaches Async/Await

```swift
class DataManager: ObservableObject {
    @Published var heartRateData: [Int] = []
    @Published var isLoading = false
    @Published var error: String?

    func loadHeartRateData() async {
        isLoading = true
        defer { isLoading = false }

        do {
            // Simuliert Netzwerk-Anfrage (3 Sekunden)
            try await Task.sleep(nanoseconds: 3_000_000_000)

            // Erfolg: Daten laden
            heartRateData = [72, 75, 78, 74, 73]
        } catch {
            self.error = "Fehler beim Laden: \(error)"
        }
    }
}

struct DataView: View {
    @ObservedObject var manager = DataManager()

    var body: some View {
        VStack {
            if manager.isLoading {
                ProgressView()
                Text("Daten werden geladen...")
            } else if let error = manager.error {
                Text("Fehler: \(error)")
                Button("Erneut versuchen") {
                    Task {
                        await manager.loadHeartRateData()
                    }
                }
            } else {
                List(manager.heartRateData, id: \.self) { rate in
                    Text("Puls: \(rate)")
                }
            }
        }
        .onAppear {
            Task {
                await manager.loadHeartRateData()
            }
        }
    }
}
```

**Was passiert:**
1. View erscheint → `onAppear` ruft `loadHeartRateData()` auf
2. UI zeigt "Loading..." ProgressView
3. Nach 3 Sekunden → Daten geladen, Liste angezeigt
4. Nutzer sieht keine Verzögerung (UI ist responsive)

---

### HealthKit Integration (kurz)

Für deine Juvantis-App brauchst du HealthKit, um Health-Daten vom iPhone zu lesen:

```swift
import HealthKit

class HealthKitManager {
    let healthStore = HKHealthStore()

    func requestHealthKitAuthorization() async -> Bool {
        let typesToRead: Set = [
            HKObjectType.quantityType(forIdentifier: .heartRateVariability)!,
            HKObjectType.quantityType(forIdentifier: .stepCount)!,
        ]

        do {
            try await healthStore.requestAuthorization(toShare: [], read: typesToRead)
            return true
        } catch {
            print("HealthKit Authorization fehlgeschlagen: \(error)")
            return false
        }
    }
}
```

Das ist komplex — dafür gibt es separate Tutorials!

---

## Zusammenfassung: SwiftUI Patterns

| Pattern | Wann nutzen |
|---------|------------|
| `@State` | Lokal in einer View |
| `@ObservedObject` | Externe Daten, mehrere Views |
| `@EnvironmentObject` | Globale Daten, tiefe Verschachtelung |
| `NavigationStack` | Zwischen Screens navigieren |
| `TabView` | Mehrere Hauptbereiche |
| `List` | Lange Listen von Items |
| `LazyVGrid` | Grid-Layouts (2+ Spalten) |
| `Form` | Benutzereingaben sammeln |
| `async/await` | Daten von Server/HealthKit laden |

---

## Häufige Fehler und Lösungen

### Fehler: "Cannot assign to property: 'x' is immutable"

**Grund:** Du versuchst, eine `let`-Variable zu ändern.

**Lösung:**
```swift
var x = 5  // Nutze var statt let
x = 10     // Jetzt geht's
```

---

### Fehler: "Value of type 'View' cannot conform to 'View'"

**Grund:** Deine View hat mehrere `return`-Statements ohne zusätzliche View.

**Lösung:**
```swift
// Falsch
var body: some View {
    if condition {
        return Text("A")  // Error!
    } else {
        return Text("B")  // Error!
    }
}

// Richtig
var body: some View {
    if condition {
        Text("A")
    } else {
        Text("B")
    }
}
```

---

### Fehler: "State changes not reflecting in UI"

**Grund:** Du hast `@State` verwendet, aber es ist nicht reaktiv.

**Lösung:** Nutze `@StateObject` in der Parent View:
```swift
struct ContentView: View {
    @StateObject var viewModel = MyViewModel()  // ← @StateObject!
    // nicht: @ObservedObject var viewModel = MyViewModel()
}
```

---

## Nächste Schritte

1. **Baue eine kleine App:**
   - Tab View mit 2 Tabs
   - Erste Tab: Liste von Health-Metriken
   - Zweite Tab: Formular zum Eingeben

2. **Nutze HealthKit (später, wenn bereit):**
   - Lies tatsächliche Heart-Rate-Daten vom iPhone
   - Zeige sie in einer Liste

3. **Erkunde SwiftUI-Beispiele:**
   - Apple Developer: https://developer.apple.com/tutorials/swiftui

4. **Frage Claude:** Wenn du steckenbleibst, frag einfach: "Wie mache ich X in SwiftUI?"

---

**💡 Tipp:** Die beste Art zu lernen ist zu bauen. Fang an, eine kleine Health-Tracking-App zu schreiben. Jeder Fehler bringt dich näher zum Verständnis.
