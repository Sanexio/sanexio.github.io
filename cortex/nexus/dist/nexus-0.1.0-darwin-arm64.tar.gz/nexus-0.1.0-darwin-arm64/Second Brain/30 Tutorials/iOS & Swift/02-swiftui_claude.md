# iOS-Programmierung: SwiftUI — Claude-Workflow

## Wann nutze ich diesen Weg?

Du brauchst den Claude-Workflow wenn:
- Du komplexe SwiftUI-Layouts brauchst (Grids, Listen mit Custom Cells)
- Du mehrere interaktive Views mit State-Sharing brauchst
- Du Navigation und Routing automatisieren möchtest
- Du keinen Custom Code für häufig genutzte Pattern schreiben möchtest (Forms, Picker, DatePicker mit Validierung)

**Beispiel aus Juvantis:** Du brauchst ein Health-Dashboard mit 4 Karten in 2x2 Grid Layout, jede Karte mit unterschiedlichen Daten. Claude schreib die komplette View mit LazyVGrid, ForEach und Binding in 5 Minuten.

---

## Der Claude-Workflow: Views schnell schreiben

```
1. Du beschreibst, welche View du brauchst
      ↓
2. Claude schreibt Complete SwiftUI View
      ↓
3. Du kopierst in neue .swift File in Xcode
      ↓
4. Integrierst mit deinem ViewModel
      ↓
5. Cmd+R → View funktioniert sofort!
      ↓
6. Falls Anpassung: Claude modifiziert View
```

---

## Schritt 1: Gute View-Prompts für Claude

### Beispiel 1: Grid-Layout mit Health-Metriken

**GUTER Prompt:**
```
Schreib eine SwiftUI View "HealthGridView", die:

1. Layout: 2x2 Grid mit Health-Metriken-Karten
2. Jede Karte zeigt:
   - [Icon] Metrik-Name (z.B. ❤️ Puls)
   - Großer Wert (z.B. 72)
   - Unit (z.B. bpm)
   - Status-Farbe: grün (ok), orange (warning), rot (kritisch)

3. Data-Binding: @ObservedObject var healthViewModel
4. Daten: healthViewModel.heartRate, steps, waterIntake, sleep
5. Design:
   - Runde Ecken (cornerRadius: 12)
   - Leichter Schatten
   - Teal-Farbschema (#028090)
6. Interaktion: Tap-Geste zum Drilldown auf Detail-Screen

Code soll direkt in HealthGridView.swift einfügbar sein.
```

→ Claude schreibt komplette Grid-View mit LazyVGrid!

### Beispiel 2: Custom Form mit Validierung

**GUTER Prompt:**
```
Schreib eine SwiftUI Form "ProfileFormView", die:

1. Felder:
   - TextField für Name (mind. 2 Zeichen)
   - Picker für Geschlecht (Männlich, Weiblich, Andere)
   - DatePicker für Geburtsdatum
   - Stepper für Zielschritte (1000-50000)
   - Toggle für Notifications

2. Validierung:
   - Name < 2 Zeichen: rote Text-Warnung anzeigen
   - Geburtsdatum > Heute: Error-Meldung
   - Zielschritte: visueller Feedback für Range

3. Buttons:
   - "Speichern" (disabled wenn Validierung fehlschlägt)
   - "Abbrechen"

4. Integration: ViewModel mit @Published Properties
5. Fehler-Anzeige: Popup oder Alert bei Speichern

Code als komplette ProfileFormView.swift.
```

→ Claude schreibt Validation Logic!

### Beispiel 3: Animierte Transitions

**GUTER Prompt:**
```
Schreib eine AvatarTransitionView, die:

1. Zwei 3D-Avatare nebeneinander anzeigt (ModelContainer)
2. Tap auf einen Avatar → Smooth Transition zu Detail-View
3. Animationen:
   - Fade-In der Detail-View
   - Scale: Avatar vergrößert sich dabei
   - Transition dauer: 0.5 Sekunden
4. Zurück-Button mit umgekehrter Animation
5. Usage mit zwei USDZ-Modelle: avatar_healthy.usdz, avatar_unhealthy.usdz

Code als AvatarTransitionView.swift.
```

→ Claude schreibt `.transition()` und `.animation()` Modifier!

---

## Schritt 2: View integrieren in Xcode

### Neue File für View erstellen

```
Cmd+N → Swift File → Name: HealthGridView.swift
```

### Code einfügen

```
Von Claude Code kopieren (Cmd+A, Cmd+C)
In Xcode File (Cmd+A, Cmd+V)
```

### Mit ViewModel verbinden

Deine View nimmt ViewModel als Parameter:

```swift
struct HealthGridView: View {
    @ObservedObject var viewModel: HealthViewModel
    // ... rest of view
}
```

In ContentView oder Parent View:

```swift
struct ContentView: View {
    @StateObject var healthViewModel = HealthViewModel()

    var body: some View {
        HealthGridView(viewModel: healthViewModel)
    }
}
```

---

## Schritt 3: Live-Preview testen

### Preview mit ViewModel Mock

Claude gibt dir oft einen Mock-ViewModel:

```swift
#Preview {
    let mockVM = HealthViewModel()
    mockVM.heartRate = 72
    mockVM.steps = 8234
    return HealthGridView(viewModel: mockVM)
}
```

Das sieht in der Canvas-Preview!

### Build & Run im Simulator

```
Cmd+B (Build)
Cmd+R (Run im Simulator)
```

Sieh deine View in echter App!

---

## Häufige View-Anpassungen mit Claude

### Anpassung 1: Farb-Änderung

```
Die Karten-Farbe ist Blau (#1A5FA0).
Ich möchte Teal (#028090) für alle Karten und
Orange (#FF6B35) für Warning-Status.

Schreib die Updated HealthGridView.
```

→ Claude ändert `.foregroundColor`, `.background()` überall.

### Anpassung 2: Layout-Änderung

```
Die 2x2 Grid ist zu groß.
Ich möchte: 3 Karten in einer Reihe (responsive).

Schreib Updated LazyVGrid mit 3 Spalten.
```

→ Claude ändert GridItem() zu 3 items.

### Anpassung 3: Neue Interaktion

```
Wenn man auf eine Karte tippt, soll sich der Wert
für 1 Sekunde vergrößern (scale 1.1) und wieder zurück.

Schreib die Updated HealthGridView mit .animation().
```

→ Claude schreibt Scale-Animation!

### Anpassung 4: Daten-Fetching

```
Die View soll beim Erscheinen (onAppear)
automatisch Daten vom ViewModel laden.
Währenddessen ProgressView anzeigen.

Schreib Updated View mit .onAppear und isLoading State.
```

→ Claude schreibt async/await Loading!

---

## Best Practices für View-Code von Claude

### Best Practice 1: State Separation

```
Die View sollte @State nur für UI-State verwenden
(z.B. isExpanded, selectedTab).

Alle App-Data sollten vom ViewModel kommen (@ObservedObject).
```

Claude macht das normalerweise richtig, aber bei großen Views nachfragen.

### Best Practice 2: Reusable Components

```
Statt alle Logik in einer View:

Schreib mir:
1. HealthMetricCard: Wiederverwendbarer Card für eine Metrik
2. HealthGridView: Nutzt HealthMetricCard 4x

So kann ich eine Karte überall nutzen.
```

→ Claude strukturiert Code in kleine, wiederverwendbare Views.

### Best Practice 3: Dokumentation

```
Schreib ausführliche Doc-Comments für jede View:
/// HealthGridView
/// Zeigt 4 Health-Metriken in 2x2 Grid
/// - Parameter viewModel: HealthViewModel mit Daten
/// - Note: Erfordert aktiven HealthViewModel
```

→ Claude schreib dokumentiert!

---

## Juvantis-spezifische View-Prompts

### Prompt: Avatar mit Rotation

```
Schreib eine AvatarView, die:
- USDZ-Modell mit ModelContainer anzeigt
- Rotation mit Finger-Gesten steuern
- Zoom mit Pinch-Geste (1.0x - 3.0x)
- Reset-Button um Original-Ansicht wiederherzustellen

Modell-Datei: avatar.usdz in Assets.
```

### Prompt: Health Data Visualization

```
Schreib eine ChartView für Juvantis, die:
- Linienchart von täglicher Schritte-Aktivität
- 7 Tage Daten (Mock-Daten oder echte)
- Y-Achse: 0-20000 Schritte
- X-Achse: Mo-So
- Farbe: Gradient von Teal zu Grün
- Interaktion: Tap auf Punkt → zeige Tages-Details

Mit vollständigem Code, ready für Integration.
```

### Prompt: Settings Screen mit Sections

```
Schreib eine SettingsView mit 4 Sections:

1. Profil:
   - Name, Alter, Geschlecht (Picker)

2. Health-Ziele:
   - Zielschritte (Stepper)
   - Wasser-Ziel in Litern
   - Schlaf-Ziel in Stunden

3. App-Einstellungen:
   - Dark Mode Toggle
   - Notifications Toggle

4. About:
   - App Version (1.0.0)
   - Link zu Privacy Policy

Alle Daten aus ViewModel (@Published).
```

---

## Fehler im View-Code und Debugging

### Fehler: "Cannot convert value of type 'ObservedObject<ViewModelType>' to expected argument type 'ViewModelType'"

**Grund:** Du versuchst, das @ObservedObject direkt zu übergeben.

**Was du fragst:**
```
Wenn ich HealthGridView(viewModel: healthViewModel) aufrufe,
gibt es Type-Error. Wie übergebe ich das richtig?
```

**Claude antwortet:**
```swift
// Richtig
HealthGridView(viewModel: healthViewModel)
// .

// healthViewModel ist bereits @StateObject oder @ObservedObject
// Keine $ oder Binding nötig!
```

### Fehler: "List in Form on watchOS is not supported"

**Grund:** Du versuchst, List innerhalb Form zu nutzen (manchmal problematisch).

**Was du fragst:**
```
Die Form mit List funktioniert nicht im Simulator.
Schreib mir die View ohne List, aber mit ähnlichem Layout.
```

→ Claude schreibt ForEach statt List.

### Fehler: "View hat zu viele Modifier oder ist zu komplex"

**Grund:** Swift UI kann sehr lange Views nicht rendern.

**Was du fragst:**
```
Die ComplexGridView wird nicht angezeigt.
Zeige mir, wie ich sie in kleinere Components aufteile.
```

→ Claude extrahiert Sub-Views (HealthMetricCard, etc.).

---

## Debugging-Tipps für Views

### Tip 1: Preview mit Mock Data

```swift
#Preview {
    let mockVM = HealthViewModel()
    mockVM.heartRate = 120  // Hoher Wert für Test
    mockVM.steps = 15000    // Hoher Wert für Warnung
    return HealthGridView(viewModel: mockVM)
}
```

Sieh sofort, wie View mit verschiedenen Daten aussieht.

### Tip 2: OnAppear Debugging

```swift
.onAppear {
    print("HealthGridView appeared")
    print("HeartRate: \(viewModel.heartRate)")
}
```

Sieh, ob View actually loaded wird.

### Tip 3: View Hierarchy in Xcode

```
Product > Debug > View Hierarchy (oder Cmd+D im Simulator)
```

Sieh alle Views und ihren Layout-Tree. Hilf beim Debuggen von Spacing/Sizing.

---

## Next Steps

1. **Einfache Grid:** Frag Claude nach "Health Metrics Grid"
2. **Integrieren:** Code in Xcode → mit ViewModel verbinden
3. **Test:** Cmd+B, Cmd+R
4. **Erweitern:** Forms, Charts, Animationen hinzufügen
5. **Polish:** Farben, Abstände, Transitions perfektionieren

---

**💡 Merksatz:** Claude für komplexe Views ist unglaublich produktiv. Du beschreibst Layout und Interaktion, Claude schreibt SwiftUI. Das ist 10x schneller als von Hand!
