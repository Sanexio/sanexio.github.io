# iOS-Programmierung: Grundlagen — Claude-Workflow

## Wann nutze ich diesen Weg?

Du brauchst den Claude-Workflow wenn:
- Du komplexe SwiftUI-Strukturen brauchst (Navigation, State Management)
- Du MVVM-Architektur für deine Juvantis-App brauchst
- Du HealthKit-Integration einbauen möchtest
- Du keine Zeit zum Tippwork hast und schnelle Ergebnisse brauchst
- Du einen großen Code-Block braucht, den du verstehen und anpassen möchtest

**Beispiel aus Juvantis:** Du brauchst eine komplette Tab-Navigation mit Health-Dashboard, Avatar-Ansicht und Settings. Claude schreibt dir die komplette SwiftUI-Struktur in 10 Minuten. Du brauchst nur noch den Code zu kopieren und in Xcode zu nutzen.

---

## Der Claude-Workflow: Code-Erstellung und Integration

```
1. Du beschreibst die Funktion, die du brauchst
      ↓
2. Claude schreibt Complete Swift/SwiftUI Code
      ↓
3. Du öffnest Xcode → neue File erstellen
      ↓
4. Code in Xcode einfügen
      ↓
5. Build & Run → funktioniert sofort!
      ↓
6. Falls Anpassungen: Du fragst Claude um Änderung
      ↓
7. Code aktualisieren, erneut probieren
```

---

## Schritt 1: Gute Prompts für Claude schreiben

### Beispiel 1: Komplette App-Struktur

**GUTER Prompt:**
```
Schreib eine komplette SwiftUI iOS-App für Juvantis mit:

1. Tab Navigation:
   - Tab 1 "Health": Zeigt Health-Metriken (Puls, Schritte, Wasser)
   - Tab 2 "Avatar": Zeigt 3D-Avatar (Model Container)
   - Tab 3 "Settings": Name, Alter, Ziele ändern

2. Data Model:
   - HealthData Struct mit heartRate, steps, waterIntake
   - UserProfile Struct mit name, age, healthGoals

3. ViewModel:
   - HealthViewModel: ObservableObject mit @Published Properties
   - Methoden zum Update von Health-Daten

4. Views:
   - HealthTrackerView: Liste von Metriken
   - AvatarView: ModelContainer für USDZ
   - SettingsView: Form zum Eingeben von Profildaten

5. Architektur: MVVM-Pattern
6. Sprache: Deutsch (UI-Text)
7. Assets: Verwende SF Symbols für Icons

Der Code soll komplett und direkt in Xcode einfügbar sein.
```

**SCHLECHTER Prompt:**
```
Mach eine Juvantis-App
```

Der gute Prompt hat **Struktur, Details, Anforderungen**. Claude versteht exakt, was nötig ist.

---

### Beispiel 2: Spezifische View-Komponente

**GUTER Prompt:**
```
Schreib eine SwiftUI View, die:
- Eine Liste von Health-Messungen anzeigt
- Jede Zeile: [Icon] Messung [Wert] [Unit]
- Beispiel: ❤️ Puls 72 bpm
- Farbliche Codierung: grün (gut), orange (ok), rot (schlecht)
- Swipe-Aktion zum Löschen
- Pull-to-Refresh

Der Code soll in eine bestehende Juvantis-App passen
und mit einem HealthViewModel kommunizieren.
```

→ Claude schreibt die komplette View!

---

### Beispiel 3: HealthKit Integration

**GUTER Prompt:**
```
Schreib einen HealthKit Manager mit folgenden Funktionen:

1. Request Authorization: HealthKit-Zugriff fragen
2. Read HeartRate: Aktuelle Herzfrequenz auslesen
3. Read Steps: Schritte vom heutigen Tag
4. Read WaterIntake: Wasseraufnahme
5. Write Measurement: Manuelle Messung speichern

Gib mir:
- HealthKitManager Klasse
- Alle error-handling
- Async/Await Pattern
- Deutsch Kommentare

Ich nutze das in meinem HealthViewModel.
```

→ Claude schreibt fertige HealthKit-Integration!

---

## Schritt 2: Code aus Claude kopieren und in Xcode einfügen

### In Xcode ein neue File erstellen

1. **Xcode öffnen** (Doppelklick auf Juvantis Projekt)

2. **File > New > File** (oder `Cmd+N`)

3. **Wähle: Swift File**

4. **Name eingeben:** z.B. `HealthViewModel.swift`

5. **Create**

### Code einfügen

1. **Gesamten Code von Claude kopieren** (Ctrl+A in Claudius Code-Block, Cmd+C)

2. **In Xcode Datei** (Cmd+A um alles zu wählen, falls Template da ist)

3. **Paste** (Cmd+V)

4. **Save** (Cmd+S)

---

## Schritt 3: Build und Test

### Build (Cmd+B)

```
Oben in Xcode:
- Product > Build
- oder Cmd+B
```

Fehler? Claude kann helfen — lies Fehlermeldung und frag Claude um Fix.

### Run im Simulator (Cmd+R)

```
Oben in Xcode:
- Product > Run
- oder Cmd+R
```

Der Simulator startet und deine App läuft!

### Interaktives Testen

```
- Tippe auf Buttons
- Schreibe Text in TextFields
- Navigiere zwischen Tabs
- Sieh deine Daten live aktualisieren
```

---

## Häufige Änderungen und Claude-Prompts

### Änderung 1: UI-Farben anpassen

```
Der Health-Tracker hat blaue Buttons. Ich möchte:
- Buttons: Teal (#028090)
- Text: Dunkelgrau (#1A1A1A)
- Hintergrund: Weiß

Schreib mir die Updated HealthTrackerView mit neuen Farben.
```

→ Claude gibt dir die aktualisierte View mit `.foregroundColor`, `.background()` Modifiern.

### Änderung 2: Neue Metrik hinzufügen

```
Ich möchte "Schlaf" (Sleep) als neue Metrik im Health-Tracker.
- Metrik: sleepHours (Double)
- Icon: bed.double.fill
- Unit: "h"
- Zielwert: 8 Stunden

Schreib mir:
1. Updated HealthData Struct
2. Updated HealthTrackerView mit Schlaf-Metrik
```

→ Claude gibt dir alle Änderungen.

### Änderung 3: Form-Validierung

```
Die Settings-Form nimmt alle Werte an.
Ich brauche Validierung:
- Name: mind. 2 Zeichen
- Alter: 1-120 Jahre
- Zielschritte: 100-50000

Zeige Fehler-Meldungen wenn Validierung fehlschlägt.
Schreib die Updated SettingsView.
```

→ Claude schreibt Validierungs-Logik.

---

## Fehlerbehandlung und Debugging

### Fehler: "Use of undeclared type 'HealthViewModel'"

**Grund:** Die Klasse existiert nicht oder ist in falscher Datei.

**Was du fragst:**
```
Mein Code gibt Error: Use of undeclared type 'HealthViewModel'

Wo muss HealthViewModel.swift stehen? Zeig mir die Struktur.
```

**Claude erklärt:**
```
HealthViewModel.swift muss im gleichen Projekt sein.
Struktur:
Juvantis/
├── Juvantis.swift  (App Entry)
├── ContentView.swift
├── Models/
│   ├── HealthData.swift
├── ViewModels/
│   ├── HealthViewModel.swift
└── Views/
    ├── HealthTrackerView.swift
```

### Fehler: "Cannot assign to immutable value"

**Grund:** Du versuchst, eine `let`-Variable zu ändern.

**Was du fragst:**
```
Error: Cannot assign to immutable value 'age'

Wie fixe ich das in der HealthViewModel?
```

**Claude antwortet:**
```swift
// Falsch
let age = 25
age = 26  // Error!

// Richtig
@Published var age = 25
age = 26  // OK!
```

### Fehler: "Preview provider incomplete"

**Grund:** Der Preview in Xcode funktioniert nicht.

**Was du fragst:**
```
Der Preview funktioniert nicht. Schreib mir einen
funktionierenden #Preview für HealthTrackerView.
```

→ Claude gibt dir den Preview-Code.

---

## Best Practices beim Claude-Coding

### Best Practice 1: Kommentare verlangen

```
Schreib den Code mit ausführlichen Deutsch-Kommentaren,
damit ich verstehe, was jeder Abschnitt macht.
```

Claude schreibt:
```swift
// MARK: - Health Daten Struktur
struct HealthData {
    // Herzfrequenz in BPM (Beats Per Minute)
    var heartRate: Int = 72

    // Schritte des heutigen Tages
    var steps: Int = 0
}
```

### Best Practice 2: MVVM-Struktur halten

```
Halte dich an MVVM-Pattern:
- Model: HealthData Struct
- ViewModel: HealthViewModel (ObservableObject)
- View: HealthTrackerView

Keine Geschäftslogik in der View!
```

→ Claude strukturiert Code sauber.

### Best Practice 3: Fehlertoleranz

```
Baue Fehlerbehandlung ein:
- Was wenn HealthKit nicht verfügbar ist?
- Was wenn User keine Permission gibt?
- Zeige aussagekräftige Fehler-Meldungen.
```

→ Claude schreibt try-catch und error handling.

---

## Juvantis-spezifische Prompts

### Prompt: MVVM Foundation

```
Schreib die komplette MVVM-Foundation für Juvantis:

1. Models:
   - HealthData (heartRate, steps, waterIntake)
   - UserProfile (name, age)

2. ViewModels:
   - HealthViewModel: Verwaltet Health-State
   - ProfileViewModel: Verwaltet User-Profile

3. Main App View mit Tab Navigation

Alle Dateien sollten separat und kopierpaste-ready sein.
```

### Prompt: HealthKit Integration

```
Schreib einen HealthKitManager, der:
- Automatisch beim App-Start HealthKit-Permission fragt
- HeartRate, Steps, und WaterIntake ausliest
- Daten an HealthViewModel updated

Mit vollständiger Fehlerbehandlung.
```

### Prompt: SceneKit Avatar Display

```
Schreib eine AvatarView, die:
- Eine USDZ-Datei mit ModelContainer anzeigt
- Rotation mit Finger-Gestur steuern
- Zoom mit Pinch-Geste

Die USDZ ist ~/avatar.usdz. Lade sie in Assets.
```

---

## Iterativer Workflow: Real-World Beispiel

### Phase 1: Basis

```
Du: "Schreib eine SwiftUI App mit 3 Tabs"
Claude: [kompletter Tab View Code]
Du: kopierst → Build & Run → 3 Tabs da!
```

### Phase 2: Daten

```
Du: "Füge HealthData Struct und HealthViewModel ein"
Claude: [Model + ViewModel Code]
Du: kopierst, integrierst → Tab 1 zeigt Daten!
```

### Phase 3: HealthKit

```
Du: "Integriere HealthKit zum Auslesen von echten Daten"
Claude: [HealthKitManager + Integration]
Du: kopierst → App zeigt echte Puls-Daten vom iPhone!
```

### Phase 4: Avatar

```
Tu: "Zeige 3D-Avatar in Tab 2 mit ModelContainer"
Claude: [AvatarView mit USDZ-Loading]
Du: kopierst, Asset hinzufügen → 3D-Avatar sichtbar!
```

### Phase 5: Polish

```
Du: "Fehler-Handling, Farben anpassen, Loading-States"
Claude: [Alle Verbesserungen]
Du: kopierst, testest → Professionelle App!
```

---

## Tips für schnelles Arbeiten

### Tip 1: Mehrere Dateien auf einmal

```
Schreib mir auf einmal:
1. HealthData.swift
2. HealthViewModel.swift
3. HealthTrackerView.swift

Mit klarer Trennung zwischen den Dateien.
```

→ Claude gibt dir alle 3 Dateien, du machst 3x Copy-Paste in Xcode.

### Tip 2: Xcode-Snippets speichern

Nach jedem erfolgreichen Code:
1. Markiere Code in Xcode
2. **Editor > Create Snippet**
3. Gib Namen ein: z.B. "HealthTrackerView Template"

Später: **⌘⌥/** zum Snippet-Menu öffnen.

### Tip 3: Regelmäßig Testen

Nach jedem neuen Code:
```
Cmd+B (Build)
Cmd+R (Run)
```

Fehler sofort sehen und Claude fragen.

---

## Next Steps

1. **Grundstruktur:** Frag Claude nach "Tab Navigation Template"
2. **Kopieren:** Code in Xcode einfügen
3. **Build & Test:** Cmd+B, Cmd+R
4. **Iterativ erweitern:** Jede Phase ein neuer Claude-Prompt
5. **Fertig:** Funktionsfähige Juvantis-App!

---

**💡 Merksatz:** Claude schreibt 90% des Code für dich. Dein Job ist: gute Prompts schreiben, Code integrieren, testen und Feedback geben. Das ist viel schneller als von Hand tippen!
