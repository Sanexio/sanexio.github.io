# iOS-Programmierung: Grundlagen — Manueller Workflow

## Wann nutze ich diesen Weg?

Du brauchst den manuellen Workflow wenn:
- Du Swift/SwiftUI als Sprache verstehen und lernen möchtest
- Du ein Projekt von Grund auf selbst aufbauen möchtest
- Du bereits Programmier-Erfahrung hast (nicht zwingend Swift)
- Du kleine, einfache Apps bauen möchtest (kein AI-Code nötig)
- Du die Fehler selbst debuggen möchtest und Lernen liebst

**Beispiel aus Juvantis:** Du öffnest Xcode, erstellst ein neues Projekt, schreibst selbst eine einfache View mit Text und Button, testet im Simulator. Reines Handwerk.

---

## Der Manuell-Workflow: Selbst schreiben und lernen

```
1. Xcode öffnen → Neues Projekt erstellen
      ↓
2. ContentView.swift öffnen
      ↓
3. Code selbst schreiben oder vom Tutorial kopieren
      ↓
4. Cmd+B (Build) → Fehler sehen → Anpassungen
      ↓
5. Cmd+R (Run im Simulator) → Ergebnis sehen
      ↓
6. Iterativ erweitern → Lernen durch Machen
```

---

## Schritt 1: Neues Xcode-Projekt erstellen

### Projekt starten

1. **Xcode öffnen**
2. **File > New > Project** (oder `Cmd+Shift+N`)
3. **iOS > App** wählen
4. **Einstellungen:**
   ```
   Product Name: Juvantis
   Organization Identifier: com.sanexio
   Interface: SwiftUI
   Language: Swift
   ```
5. **Create**

### Projekt-Struktur verstehen

```
Juvantis/
├── JuvantisApp.swift        ← App Entry Point
├── ContentView.swift         ← Main UI (hier schreibst du)
├── Assets.xcassets          ← Bilder, Icons, USDZ-Modelle
└── Juvantis.entitlements    ← App-Berechtigungen (HealthKit)
```

---

## Schritt 2: Erstes SwiftUI-Programm

### ContentView.swift öffnen

```
Linke Sidebar → Juvantis Projekt → ContentView.swift
```

Dort siehst du:
```swift
struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
            Text("Hello, world!")
        }
        .padding()
    }
}
```

### Hello World verändern

Ändere die `Text`-Zeile:

```swift
struct ContentView: View {
    var body: some View {
        VStack {
            Text("Willkommen bei Juvantis!")
                .font(.largeTitle)
                .foregroundColor(.blue)
            Text("Dein digitaler Health Avatar")
                .font(.subheadline)
        }
        .padding()
    }
}
```

### Preview anschauen

Rechts im Xcode siehst du **Canvas** (Preview):
- Dein Text wird live angezeigt!
- Wenn du Code änderst, aktualisiert sich Preview automatisch

---

## Schritt 3: Mit @State und Button interaktiv machen

**Ersetze ContentView.swift:**

```swift
import SwiftUI

struct ContentView: View {
    @State var buttonTaps = 0  // Zähler für Button-Klicks

    var body: some View {
        VStack {
            Text("Willkommen bei Juvantis")
                .font(.largeTitle)

            Text("Button-Klicks: \(buttonTaps)")
                .font(.headline)
                .padding()

            Button("Klick mich") {
                buttonTaps += 1  // Zähler erhöhen
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)
        }
        .padding()
    }
}
```

**Preview:**
- Siehst "Button-Klicks: 0"
- Klick "Klick mich" im Preview
- Zähler erhöht sich zu 1, 2, 3...
- State funktioniert!

---

## Schritt 4: TextInput und einfaches Formular

```swift
import SwiftUI

struct ContentView: View {
    @State var name = ""
    @State var age = ""

    var body: some View {
        Form {
            Section(header: Text("Persönliche Daten")) {
                TextField("Name", text: $name)
                TextField("Alter", text: $age)
                    .keyboardType(.numberPad)
            }

            Section {
                Button("Speichern") {
                    print("Gespeichert: \(name), \(age) Jahre")
                }
            }

            Section {
                if !name.isEmpty {
                    Text("Hallo, \(name)!")
                        .foregroundColor(.blue)
                }
            }
        }
        .navigationTitle("Profil")
    }
}
```

**Teste im Preview:**
- Schreib einen Namen
- Siehe sofort: "Hallo, [Name]!"
- Das ist SwiftUI Reactivity!

---

## Schritt 5: Mehrere Views (Navigation)

### Neue File erstellen für Health-View

**File > New > File > Swift File**
- Name: `HealthView.swift`

```swift
import SwiftUI

struct HealthView: View {
    var body: some View {
        VStack {
            Text("Health Tracker")
                .font(.largeTitle)

            List {
                HStack {
                    Text("Puls")
                    Spacer()
                    Text("72 bpm").foregroundColor(.red)
                }
                HStack {
                    Text("Schritte")
                    Spacer()
                    Text("8234").foregroundColor(.green)
                }
                HStack {
                    Text("Wasser")
                    Spacer()
                    Text("2L").foregroundColor(.blue)
                }
            }
        }
        .navigationTitle("Health")
    }
}
```

### ContentView mit Navigation

```swift
import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            VStack {
                Text("Juvantis")
                    .font(.largeTitle)

                NavigationLink("Zum Health Tracker", destination: HealthView())
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .navigationTitle("Home")
        }
    }
}
```

**Teste:**
- Preview zeigt Button
- Klick "Zum Health Tracker"
- HealthView öffnet sich
- "Zurück" Button erscheint automatisch!

---

## Schritt 6: ViewModel für State Management

### Neue File: HealthViewModel.swift

```swift
import Foundation

class HealthViewModel: ObservableObject {
    @Published var heartRate: Int = 72
    @Published var steps: Int = 8234
    @Published var waterIntake: Int = 2  // Liter

    func addSteps(_ count: Int) {
        steps += count
    }

    func updateHeartRate(_ rate: Int) {
        heartRate = rate
    }
}
```

### HealthView mit ViewModel

```swift
import SwiftUI

struct HealthView: View {
    @ObservedObject var viewModel = HealthViewModel()
    @State var newHeartRate = ""

    var body: some View {
        Form {
            Section(header: Text("Aktuelle Metriken")) {
                HStack {
                    Text("Puls")
                    Spacer()
                    Text("\(viewModel.heartRate) bpm")
                }
                HStack {
                    Text("Schritte")
                    Spacer()
                    Text("\(viewModel.steps)")
                }
            }

            Section(header: Text("Puls aktualisieren")) {
                TextField("Neue Herzfrequenz", text: $newHeartRate)
                    .keyboardType(.numberPad)

                Button("Speichern") {
                    if let rate = Int(newHeartRate) {
                        viewModel.updateHeartRate(rate)
                        newHeartRate = ""
                    }
                }
            }
        }
        .navigationTitle("Health")
    }
}
```

**Teste:**
- Gib neue Herzfrequenz ein
- Klick "Speichern"
- Wert oben aktualisiert sich
- ViewModel funktioniert!

---

## Schritt 7: Run im Simulator

### Build & Run

```
Oben in Xcode:
- Product > Run
- oder Cmd+R
```

Der Simulator öffnet sich mit deiner echten App!

### Im Simulator testen

```
- Tippe auf TextFields
- Klick Buttons
- Navigiere zwischen Screens
- Gib Daten ein → sieh Live-Updates
```

Das ist deine echte App, nicht nur Preview!

---

## Häufige Anfängerfehler

### Fehler: "Cannot find 'HealthViewModel' in scope"

**Grund:** HealthViewModel.swift ist nicht importiert.

**Lösung:**
```swift
// Am Anfang von HealthView.swift
import SwiftUI
import Foundation  // Für ObservableObject
```

Oder: ViewModel in den gleichen File wie View schreiben.

---

### Fehler: "Cannot assign to property: 'x' is immutable"

**Grund:** Du versuchst, eine `let`-Variable zu ändern.

**Lösung:**
```swift
// Falsch
let count = 0
count += 1  // Error!

// Richtig
@State var count = 0
count += 1  // OK!
```

---

### Fehler: "Initializer 'init(_:)' requires that 'MyClass' conform to 'View'"

**Grund:** Du versuchst, eine Klasse als View zu nutzen (muss Struct sein).

**Lösung:**
```swift
// Falsch
class ContentView: View { ... }

// Richtig
struct ContentView: View { ... }
```

---

## Debugging-Tipps

### Tip 1: Print-Statements nutzen

```swift
Button("Speichern") {
    print("Name: \(name)")  // Siehst in Xcode Konsole
    viewModel.updateName(name)
}
```

In Xcode: **View > Debug Area > Show Debug Area** (oder `Cmd+Shift+Y`)

Dort siehst du alle `print()`-Ausgaben.

### Tip 2: Preview-Fehler fixen

Wenn Preview nicht lädt:
```
Editor > Canvas > Reload (oder Cmd+Alt+P)
```

Oder: **Product > Build** (Cmd+B) zuerst.

### Tip 3: Schritt für Schritt bauen

Statt großes Feature auf einmal:
1. Text anzeigen
2. Text mit State verändern
3. Button zum Verändern
4. Übergeben an ViewModel

Nach jedem Schritt: Preview checken oder Run testen.

---

## Kleine Übungsprojekte

### Projekt 1: Counter App

```swift
struct ContentView: View {
    @State var count = 0

    var body: some View {
        VStack {
            Text("\(count)")
                .font(.system(size: 72, weight: .bold))

            HStack {
                Button("-") { count -= 1 }
                    .padding()
                Button("+") { count += 1 }
                    .padding()
            }
        }
    }
}
```

### Projekt 2: To-Do List

```swift
struct ContentView: View {
    @State var todos: [String] = []
    @State var newTodo = ""

    var body: some View {
        Form {
            Section {
                TextField("Neue Aufgabe", text: $newTodo)
                Button("Hinzufügen") {
                    todos.append(newTodo)
                    newTodo = ""
                }
            }

            Section(header: Text("Meine Aufgaben")) {
                List {
                    ForEach(todos, id: \.self) { todo in
                        Text(todo)
                    }
                }
            }
        }
    }
}
```

---

## Next Steps

1. **Neues Projekt:** Erstelle "Juvantis" wie oben
2. **Hello World:** Ändere Text und sehe Preview-Update
3. **Button & State:** Baue einen einfachen Counter
4. **Form:** TextField und Formular
5. **Navigation:** Mehrere Views verbinden
6. **ViewModel:** Health-Daten verwalten

---

**💡 Merksatz:** Manuelles Programmieren ist langsamer, aber du VERSTEHST jeden Fehler und lernst Swift tiefgreifend. Das hilft später beim Debugging und Anpassungen!
