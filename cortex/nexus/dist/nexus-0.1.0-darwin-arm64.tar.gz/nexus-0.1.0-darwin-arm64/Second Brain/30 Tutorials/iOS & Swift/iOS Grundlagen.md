---
type: tutorial
aliases: [iOS, Swift, SwiftUI, Xcode, iPhone, App-Entwicklung]
tags:
  - tutorial
  - ios
  - swift
  - swiftui
source: Second Brain/30 Tutorials/iOS & Swift/
legacy_path: _tutorials/ios-programmierung/ (Symlink)
---

# iOS-Programmierung mit Swift & SwiftUI — Tutorial-Übersicht

> Quellpfad: `Second Brain/30 Tutorials/iOS & Swift/` (Single Source of Truth)
> Legacy-Pfad: `_tutorials/ios-programmierung/` → Symlink

Swift ist die moderne Programmiersprache für iPhone, iPad und Mac. SwiftUI ist der neue Standard zum Bauen von Benutzeroberflächen (UIs).

---

## Warum diese Tutorials?

- **Juvantis-App** wird in Swift/SwiftUI gebaut
- **Anfängerfreundlich:** Swift ist relativ einsteigerfreundlich (im Vergleich zu Objective-C)
- **Xcode:** Direkt Code schreiben, testen und im Simulator sehen
- **Moderne Architektur:** MVVM (Model-View-ViewModel) für sauberen Code

---

## Was brauchst du?

- Mac (mit Xcode installiert)
- 1-2 Stunden Zeit für die Basics
- Neugier!

---

## Module

### 01 — Grundlagen
**Anfänger-freundliche Einfuehrung in Swift.**

Lerninhalte:
- **Variablen und Konstanten:**
  - `let` = unveränderlich (schneller & sicherer)
  - `var` = änderbar
- **Datentypen:**
  - `Int` (ganze Zahlen)
  - `Double` (Dezimalzahlen)
  - `String` (Text)
  - `Bool` (true/false)
  - `Array` (Liste)
  - `Dictionary` (Zuordnungen)
- **Kontroll-Strukturen:**
  - `if/else` (Bedingungen)
  - `for/while` (Schleifen)
  - `switch/case` (Mehrfach-Abzweigung)
- **Funktionen:** Eigene Funktionen schreiben
- **Optionals:** Mit Werten umgehen, die `nil` sein könnten
- **Type-Annotations:** Typen explizit angeben (Lesbarkeit)

**Praxis-Beispiel:** Eine einfache Rechner-App

**Module:**
- Theorie: `01-grundlagen.md`

---

### 02 — SwiftUI Vertiefung
**Vom "Hallo Welt" zur richtigen App.**

SwiftUI-Grundlagen reichen für einfache UIs, aber echte Apps sind komplexer. Dieses Modul zeigt:

**Navigation zwischen Screens:**
- **NavigationStack (iOS 16+):** Moderner Weg für Screen-Navigation
- Master-Detail Navigation (wie in Juvantis: Patient-Liste → Detail)
- Tab Navigation (unterschiedliche Bereiche)
- Sheet/Modal (Pop-ups)

**State Management:**
- **@State:** Lokale Variablen einer View
- **@StateObject:** Objekt, das sich nicht ändert
- **@EnvironmentObject:** Daten, die mehrere Views teilen
- **@Published:** Beobachtete Variablen (für MVVM)
- **ViewModel:** Trennung von UI-Logic und Daten

**Listen und Grids:**
- **List:** Scrollbare Liste von Items
- **ForEach:** Über Arrays iterieren
- **LazyVGrid:** Responsive Gitter-Layouts
- **Scrollable Content:** Für viele Daten

**Formulare:**
- **TextField, SecureField:** Text-Input
- **Toggle:** Schalter (An/Aus)
- **Picker, Stepper:** Selections
- **Form:** Strukturierte Formulare
- **Validierung:** Eingaben überprüfen

**Asynchrone Operationen (wichtig für HealthKit):**
- **Task:** Hintergrund-Operationen
- **async/await:** Modernes Syntax für Async-Code
- **URLSession:** Daten vom Internet laden
- **Error Handling:** Mit Fehlern umgehen

**Praktische Beispiele:**
- Patienten-Liste mit Detail-View
- Health-Daten vom HealthKit laden
- Formular für neue Patientendaten
- Avatar-Bild laden und anzeigen

**Module:**
- Theorie: `02-swiftui.md`

---

## Lern-Reihenfolge

1. **01 — Grundlagen** (Swift-Syntax, Datentypen, Logik)
2. **02 — SwiftUI Vertiefung** (Real-World Apps)

Jedes Modul baut auf dem vorherigen auf. Du brauchst das Wissen aus Modul 01, um Modul 02 zu verstehen.

---

## Xcode-Basics

### Xcode öffnen
1. Spotlight: `cmd + space` → `Xcode` eingeben
2. Oder: Applications/Xcode.app

### Neues Swift-Projekt starten
1. **File** → **New** → **Project**
2. Wähle **iOS** → **App**
3. Gib deinem Projekt einen Namen (z.B. "MyFirstApp")
4. Language: **Swift**, Interface: **SwiftUI**
5. **Create**

### Simulator öffnen
1. **Product** → **Destination** → dein Simulator (z.B. iPhone 15)
2. **Product** → **Run** (oder `cmd + R`)
3. App startet im Simulator — du siehst Änderungen live!

### Swift Playground (zum Lernen)
1. **File** → **New** → **Playground**
2. Kleine Snippets testen, ohne vollständige App
3. Gut zum Verstehen von Syntax und Datentypen

---

## Wichtige Konzepte für Juvantis

### HealthKit-Integration
Daten aus der Health-App des Nutzers lesen:
```swift
import HealthKit

let healthStore = HKHealthStore()
// HealthKit-Anfragen, Daten sammeln
```

### 3D-Avatar in SceneKit
`SceneKit` ist Apples 3D-Engine für iOS. Dein Avatar wird hier angezeigt:
```swift
import SceneKit

let scene = SCNScene(named: "avatar.usdz")
```

### MVVM-Architektur
- **Model:** Daten (Patient, Health-Daten)
- **View:** SwiftUI-UI
- **ViewModel:** Logik dazwischen (lädt Daten, verarbeitet Input)

Macht Code wartbar und testbar.


<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

- [[30 Tutorials/iOS & Swift/01-grundlagen|01-grundlagen]] · [[30 Tutorials/iOS & Swift/01-grundlagen_claude|Claude]] · [[30 Tutorials/iOS & Swift/01-grundlagen_manuell|Manuell]]
- [[30 Tutorials/iOS & Swift/02-swiftui|02-swiftui]] · [[30 Tutorials/iOS & Swift/02-swiftui_claude|Claude]] · [[30 Tutorials/iOS & Swift/02-swiftui_manuell|Manuell]]
<!-- PROJEKT-STAND verschoben nach _archive/projekt-stand-snapshots/ (Sprint F2 Reorg 2026-05-05) -->

<!-- /auto-moc-links -->
