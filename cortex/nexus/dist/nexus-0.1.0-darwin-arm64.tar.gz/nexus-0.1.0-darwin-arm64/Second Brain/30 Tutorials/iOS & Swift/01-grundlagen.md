# iOS-Programmierung: Grundlagen

## Was lernst du hier?
[!anweisung]: "Was lernst du hier?" kann raus 

Swift ist die moderne Programmiersprache für iPhone, iPad und Mac. SwiftUI ist der neue Standard um UIs (Benutzeroberflächen) zu bauen. Diese Lektion bringt dir die absoluten Basics näher — du brauchst kein Vorwissen.

**Warum lernst du das?**
- Deine Juvantis-App wird in Swift/SwiftUI gebaut
- Swift ist relativ anfängerfreundlich (im Vergleich zu Objective-C)
- Mit Xcode kannst du Code schreiben, testen und direkt im Simulator sehen

**Was du brauchst:**
- Mac (mit Xcode installiert)
- 1 Stunde Zeit für die Basics
- Neugier!

---

## Swift: Grundkonzepte

### Variablen und Konstanten

**Konstante (unveränderlich):**
```swift
let pi = 3.14159
let name = "Dr. Stracke"
```

`let` bedeutet: Diese Variable wird nicht mehr verändert. Ist schneller und sicherer.

**Variable (änderbar):**
```swift
var age = 42
age = 43  // Erlaubt
```

`var` bedeutet: Diese Variable kann sich ändern.

**Typ-Annotationen (optional, aber hilfreich):**
```swift
let pi: Double = 3.14159
let name: String = "Dr. Stracke"
var age: Int = 42
```

Swift erklärt sich den Typ oft selber ("type inference"), aber explizit ist besser lesbar.

---

### Datentypen

| Typ | Beispiel | Erklärung |
|-----|----------|-----------|
| `Int` | `42`, `-5` | Ganze Zahlen |
| `Double` | `3.14`, `2.5` | Dezimalzahlen |
| `String` | `"Hallo"`, `"123"` | Text |
| `Bool` | `true`, `false` | Wahr/Falsch |
| `Array` | `[1, 2, 3]` | Liste von Werten |
| `Dictionary` | `["key": "value"]` | Schlüssel-Wert-Paare |

---

### Strings und String Interpolation

```swift
let first = "Dr."
let last = "Stracke"
let greeting = "Hallo, " + first + last  // String-Konkatenation

let age = 42
let message = "Ich bin \(age) Jahre alt"  // String Interpolation
// Ausgabe: "Ich bin 42 Jahre alt"
```

String Interpolation mit `\(variable)` ist eleganter.

---

### if/else — Bedingungen

```swift
let age = 42

if age >= 18 {
    print("Du bist ein Erwachsener")
} else if age >= 13 {
    print("Du bist ein Teenager")
} else {
    print("Du bist ein Kind")
}
```

---

### Schleifen: for und while

**for-Schleife (über Array):**
```swift
let numbers = [1, 2, 3, 4, 5]

for number in numbers {
    print(number)  // 1, 2, 3, 4, 5
}
```

**for-Schleife (Bereichs-Iteration):**
```swift
for i in 1...5 {
    print(i)  // 1, 2, 3, 4, 5
}
```

Das `...` ist der "inclusive range" (von 1 bis 5, beide inklusive).

**while-Schleife:**
```swift
var counter = 0
while counter < 5 {
    print(counter)
    counter += 1  // Erhöhe um 1
}
```

---

### Funktionen

```swift
func greet(name: String) -> String {
    return "Guten Tag, \(name)!"
}

let message = greet(name: "Dr. Stracke")
print(message)  // "Guten Tag, Dr. Stracke!"
```

**Was das bedeutet:**
- `func` = Funktions-Deklaration
- `name: String` = Parameter: heißt `name`, ist Typ `String`
- `-> String` = Rückgabe: gibt ein `String` zurück
- `return` = was die Funktion zurückgibt

**Mehrere Parameter:**
```swift
func add(a: Int, b: Int) -> Int {
    return a + b
}

let sum = add(a: 5, b: 3)  // 8
```

**Optionale Rückgabe (kann auch nil sein):**
```swift
func findUser(name: String) -> String? {
    if name == "Admin" {
        return "Admin-Benutzer"
    }
    return nil  // Nicht gefunden
}
```

Das `?` bedeutet: "Kann auch nil sein" (kein Wert).

---

### Klassen und Structs

**Struct (Werttyp):**
```swift
struct User {
    var name: String
    var age: Int

    func describe() -> String {
        return "\(name) ist \(age) Jahre alt"
    }
}

let user = User(name: "Dr. Stracke", age: 42)
print(user.describe())  // "Dr. Stracke ist 42 Jahre alt"
```

**Klasse (Referenztyp):**
```swift
class Doctor {
    var name: String
    var specialty: String

    init(name: String, specialty: String) {
        self.name = name
        self.specialty = specialty
    }
}

let doc = Doctor(name: "Dr. Stracke", specialty: "Medizin")
print(doc.name)  // "Dr. Stracke"
```

**Unterschied:**
- `struct` = Werttyp (wird kopiert)
- `class` = Referenztyp (wird gemeinsam genutzt)

[!anweisung]: erkläre den Unterschied zwischen struct und class nochmal genauer

Für UIs nutzen wir meist Structs (einfacher, schneller).

---

## Xcode: Die IDE

Xcode ist der "Schreibtisch" für iOS-Entwicklung. Es ist komplex, aber du brauchst nur die Basics.

### Neues Projekt erstellen

1. Öffne Xcode
2. Wähle: **File > New > Project**
3. Wähle: **iOS > App**
4. Fülle aus:
   - **Product Name:** `Juvantis` (oder dein Name)
   - **Organization Identifier:** `com.sanexio` (oder deine Domain)
   - **Interface:** SwiftUI
   - **Language:** Swift
5. Klick: **Create**

[!anweisung]: "Neues Projekt erstellen kann entfallen"
---

### Xcode Interface

```
┌─────────────────────────────────────────┐
│ Xcode                                   │
├──────────────┬──────────────┬───────────┤
│   Navigator  │   Editor     │ Inspector │
│ (links)      │ (Mitte)      │ (rechts)  │
│              │              │           │
│ Files        │ Code editieren   Eigenschaften
│ Search       │              │           │
│ Breakpoints  │              │           │
└──────────────┴──────────────┴───────────┘
```

**Navigator (links):** Deine Dateien, Projekt-Struktur
**Editor (Mitte):** Hier schreibst du Code
**Inspector (rechts):** Details über die ausgewählte Datei

---

### Simulator starten 

1. Wähle oben: **iPhone 15** (oder dein Gerät)
2. Klick das Play-Icon (oder **Product > Run**)
3. Der Simulator öffnet sich und deine App läuft

```
┌──────────────────────┐
│ Simulator (iPhone)   │
│                      │
│   Deine App läuft!   │
│                      │
└──────────────────────┘

[!anweisung]: "Simulator starten kann entfallen"

---

## SwiftUI: User Interfaces bauen

SwiftUI ist eine "deklarative" UI-Sprache. Du beschreibst, wie deine UI aussehen soll, und SwiftUI kümmert sich um die Details.

### Einfache Views

**Text anzeigen:**
```swift
Text("Hallo, Welt!")
```

**Button:**
```swift
Button("Klick mich") {
    print("Button geklickt!")
}
```

**TextField (Eingabefeld):**
```swift
@State var userInput = ""

TextField("Name eingeben", text: $userInput)
```

Das `@State` ist eine spezielle Variable, die sich über Zeit ändern kann.

---

### Layout: VStack und HStack

```swift
VStack {              // Vertikal stapeln (von oben nach unten)
    Text("Titel")
    Text("Untertitel")
}
```

```swift
HStack {              // Horizontal stapeln (von links nach rechts)
    Text("Links")
    Text("Rechts")
}
```

**Verschachtelt:**
```swift
VStack {
    Text("Oben")
    HStack {
        Text("Unten-Links")
        Text("Unten-Rechts")
    }
}
```

---

### Modifiers: Styling

Modifiers verändern das Aussehen:

```swift
Text("Große Überschrift")
    .font(.largeTitle)
    .foregroundColor(.blue)
    .padding()  // Abstände drum herum
```

**Häufige Modifier:**
```swift
Text("Text")
    .font(.headline)                // Schriftgröße
    .foregroundColor(.blue)         // Textfarbe
    .padding()                      // Abstände
    .background(Color.gray)         // Hintergrund
    .cornerRadius(8)                // Runde Ecken
    .frame(width: 200, height: 50)  // Größe
```

---

### State: Interaktivität

`@State` ist, wie deine App sich "erinnert":

```swift
struct ContentView: View {
    @State var count = 0

    var body: some View {
        VStack {
            Text("Klicks: \(count)")
            Button("Klick") {
                count += 1  // Erhöhe den Counter
            }
        }
    }
}
```

Jedes Mal, wenn du den Button klickst, wird `count` erhöht und die UI aktualisiert sich automatisch.

---

## MVVM: Das Pattern für größere Apps

MVVM ist ein Strukturierungsmuster für größere Apps. Es trennt Daten (Model), Logik (ViewModel) und UI (View).

```
    View (SwiftUI)
        ↓ (fragt nach Daten)
    ViewModel (@ObservedObject)
        ↓ (verwaltet Logik)
    Model (Datenklasse)
        ↓ (speichert Zustand)
```

**Beispiel: Avatar-Health-Tracker**

```swift
// Model — die Daten
struct HealthData {
    var heartRate: Int = 72
    var steps: Int = 8234
}

// ViewModel — die Logik
class HealthViewModel: ObservableObject {
    @Published var health = HealthData()

    func updateHeartRate(_ rate: Int) {
        health.heartRate = rate
    }
}

// View — die UI
struct ContentView: View {
    @ObservedObject var viewModel = HealthViewModel()

    var body: some View {
        VStack {
            Text("Puls: \(viewModel.health.heartRate)")
            Button("Aktualisieren") {
                viewModel.updateHeartRate(78)
            }
        }
    }
}
```

**Was das bedeutet:**
- `@Published` = "Wenn sich das ändert, aktualisiere die UI"
- `@ObservedObject` = "Beobachte dieses ViewModel auf Änderungen"

---

## Wo finde ich Hilfe?

### Apple Developer Documentation
**https://developer.apple.com/documentation/swift/**

Die offizielle Dokumentation. Detailliert, manchmal trocken, aber immer korrekt.

### Swift Playgrounds (interaktives Lernen)
Im App Store oder mit Xcode. Interaktive Programmier-Lektionen.

### Ray Wenderlich (Tutorials)
**https://www.raywenderlich.com** — Gute Tutorials für iOS-Anfänger

### Stack Overflow
**https://stackoverflow.com/questions/tagged/swift** — Frag die Community!

---

## Zusammenfassung: Die wichtigsten Konzepte

| Konzept | Beispiel |
|---------|----------|
| `let` / `var` | `let name = "Dr. Stracke"` |
| `String`, `Int`, `Bool` | `let age: Int = 42` |
| Funktionen | `func greet(name: String) -> String` |
| `if`/`else` | `if age > 18 { ... }` |
| Schleifen | `for i in 1...5 { ... }` |
| Struct | `struct User { var name: String }` |
| SwiftUI View | `Text("Hallo")` |
| VStack / HStack | Vertikales/Horizontales Layout |
| `@State` | Interaktive Variablen |
| MVVM | Model, ViewModel, View |

---

## Nächste Schritte

1. **Installiere Xcode** (wenn nicht done):
   ```bash
   xcode-select --install
   ```

2. **Erstelle ein neues Projekt** (wie oben erklärt)

3. **Ändere den Standardtext:**
   Öffne `ContentView.swift` und ändere:
   ```swift
   Text("Hello, world!")
   ```
   zu:
   ```swift
   Text("Hallo, \(name)!")
   ```

4. **Lernlektion zwei:** iOS-Programmierung > SwiftUI — Vertiefung

---

**💡 Tipp:** Schreib viel Code. Jede Zeile, die du selbst tippst, hilft dir, Swift zu verstehen. Kopieren ist schnell, aber Lernen dauert.
