---
type: tutorial
aliases: [Sicherheit, IT-Sicherheit, Datenschutz, DSGVO, GDPR, 2FA, Passwort, Backup, Verschlüsselung]
tags:
  - tutorial
  - sicherheit
  - datenschutz
  - dsgvo
  - praxis
source: Second Brain/30 Tutorials/Sicherheit & Datenschutz/
---

# Sicherheit & Datenschutz — Grundlagen

> Du betreibst eine **Arztpraxis** und ein **Health-Tech-Startup**. Beide
> Welten arbeiten mit hochsensiblen Daten — Patientenakten, Gesundheits-
> daten, KV-Abrechnungen. Diese Seite gibt dir den Grundkanon: was du
> wissen, einrichten und prüfen solltest.

> [!info] Lesezeit: 15 Minuten · Voraussetzung: keine

> [!warning] Disclaimer
> Diese Seite ist Lehrmaterial, **keine Rechtsberatung**. Bei DSGVO-/Patientendaten-Zweifeln: Datenschutzbeauftragten + Rechtsanwalt einschalten.

---

## 1. Warum dieser Bereich für dich besonders wichtig ist

Drei Dimensionen, die bei dir zusammenkommen:

| Dimension | Was es heißt | Risiko bei Verstoß |
|---|---|---|
| **Patientenakten in der Praxis** | besondere Kategorie nach Art. 9 DSGVO | DSGVO-Bußgeld bis 20 M EUR oder 4 % Jahresumsatz |
| **Berufsgeheimnis** § 203 StGB | Schweigepflicht für Ärzte | Strafrechtlich (bis 1 Jahr Haft / Geldstrafe) |
| **Juvantis = Health-Tech-Startup** | Lifestyle-Produkt jetzt, später Medizinprodukt | MDR-Verordnung, BfArM-Anforderungen |

Plus die Standard-Risiken jedes IT-Betriebs: Erpressungs-Trojaner, Phishing,
Account-Übernahme, Datenverlust durch Hardware-Defekt.

**Faustregel:** Sicherheit ist nicht ein einzelnes Produkt, sondern eine **Schicht-Architektur**. Mehrere unabhängige Schichten so dass beim Versagen einer die nächste hält.

---

## 2. Die drei Schutzziele (das CIA-Modell)

| Ziel | Was es heißt | Beispiel-Bedrohung | Beispiel-Maßnahme |
|---|---|---|---|
| **Vertraulichkeit** (Confidentiality) | Nur Befugte sehen Daten | Datenleak, Hacker-Zugriff | Verschlüsselung, Zugriffsrechte, 2FA |
| **Integrität** (Integrity) | Daten sind unverändert / nicht manipuliert | Schadsoftware ändert Befund | Hash-Prüfsummen, Audit-Logs |
| **Verfügbarkeit** (Availability) | Daten sind erreichbar, wenn gebraucht | Festplatte stirbt, Ransomware sperrt | Backups, Redundanz, USV |

Bei einem **Patientendatensatz** musst du **alle drei** gleichzeitig einhalten. Backup ohne Verschlüsselung verletzt Vertraulichkeit. Verschlüsselung ohne Backup verletzt Verfügbarkeit. Backup nur einmal pro Monat verletzt Verfügbarkeit + Integrität.

---

## 3. Authentifizierung — wie du dich „beweist"

Drei Faktoren, die zur Identitäts-Prüfung dienen:

| Faktor | Was es ist | Beispiel |
|---|---|---|
| **Wissen** | Etwas, das du **weißt** | Passwort, PIN, Sicherheitsfrage |
| **Besitz** | Etwas, das du **hast** | iPhone mit Authenticator-App, Hardware-Key (YubiKey) |
| **Inhärenz** | Etwas, das du **bist** | Fingerabdruck, Face-ID |

**1FA** = nur einer dieser Faktoren (z. B. nur Passwort) → unzureichend.
**2FA / MFA** = mindestens zwei, idealerweise unterschiedlicher Klassen. Standard.

### 2FA für deine wichtigen Konten

| Account | 2FA-Methode (Empfehlung-Stärke) |
|---|---|
| **Apple-ID** | iPhone-Push (Inhärenz + Besitz) — sehr stark |
| **Google / GMail** | Authenticator-App + Backup-Codes |
| **GitHub** | Authenticator-App + Backup-Codes (oder YubiKey) |
| **Domain-Registrar (domainfactory)** | App-basiert; Domain-Hijacking ist verheerend |
| **WordPress (wp-admin)** | Plugin „Two-Factor" oder „Wordfence Login Security" |
| **Shopify-Admin** | Authenticator-App — **Pflicht** für Sanexio |
| **Stripe / Zahlungs-Anbieter** | Hardware-Key bevorzugt |
| **Apple-Developer** | App-basiert |
| **PVS / inSuite** | praxisspezifisch — beim Anbieter erfragen |

> **Anti-Pattern:** SMS-2FA. Wird vom Mobilfunk-SIM-Swap-Betrug ausgehebelt. Apps (Google Authenticator, Authy, 1Password) sind sicherer.

---

## 4. Passwörter — das Fundament

### Passwort-Manager statt Kopf

Ein Mensch kann sich keine 80 unterschiedlichen, starken Passwörter merken. Ein **Passwort-Manager** speichert sie alle hinter einem Master-Passwort.

| Passwort-Manager | Stärke | Kosten |
|---|---|---|
| **1Password** | Profi-Standard, exzellente macOS-/iOS-Integration | ~3 €/Monat |
| **Bitwarden** | Open Source, sehr gut, kostenlose Variante | 0 € / 10 €/Jahr für Premium |
| **Apple Schlüsselbund / iCloud Keychain** | Perfekt im Apple-Ökosystem, für reine Apple-User ausreichend | inklusive |
| **KeePass** (lokal) | Open Source, lokal, kein Cloud-Risiko | 0 € — aber selbst syncen |

**Bei dir:** vermutlich Mischung aus iCloud Keychain + LastPass o.Ä. — Audit lohnt sich.

### Passwort-Stärke

Drei Stufen, die im Praxis-Alltag zählen:

| Stufe | Kriterien | Wann nutzen |
|---|---|---|
| **Akzeptabel** | ≥12 Zeichen, gemischt | Standard-Webdienste |
| **Stark** | ≥16 Zeichen, gemischt, vom Manager generiert | Banking, Cloud-Dienste, GitHub |
| **Hochsicher** | ≥20 Zeichen, gemischt + 2FA mit Hardware-Key | Praxis-Admin, Domain-Registrar, 1Password-Master |

> **Master-Passwort des Passwort-Managers:** muss **du** dir merken. Empfehlung: 4–6 zufällige Wörter (z. B. „Wal-Trompete-Gardinenschnur-Kondensator"). Lange unsinnige Wort-Ketten sind sicherer als kryptische Sonderzeichen-Kürze.

---

## 5. Verschlüsselung — Daten sicher

Drei Aggregat-Zustände, in denen Verschlüsselung relevant ist:

| Zustand | Was schützt? | Bei dir |
|---|---|---|
| **Daten in Bewegung** (transit) | Daten zwischen zwei Punkten (Browser ↔ Server, iPhone ↔ Cloud) | HTTPS, TLS, SSH — **automatisch** für seriöse Dienste |
| **Daten im Ruhezustand** (at rest) | Daten auf Festplatte | FileVault auf Mac, Festplatten-Verschlüsselung der Praxis-Server, verschlüsseltes Backup |
| **Daten in Verarbeitung** (in use) | Daten im Arbeitsspeicher (sehr fortgeschritten) | nicht relevant für dich |

### Konkret bei dir:

| Gerät | Verschlüsselung aktiv? |
|---|---|
| **Cluster-Mini-02** (Home-Mac) | FileVault sollte AN sein — `Systemeinstellungen → Datenschutz & Sicherheit → FileVault` |
| **MacProIntel** (mobile MacBook Pro) | FileVault **Pflicht** — bei Verlust ist sonst alles offen |
| **Mac-Studio (praxis-studio)** | FileVault Pflicht |
| **Praxis-Server (Proxmox + VMs)** | LUKS / dm-crypt für Storage, separat zu konfigurieren |
| **iPhone** | iOS verschlüsselt automatisch, sobald Code gesetzt ist |
| **Backup-Festplatten** | Time Machine kann verschlüsseln — Pflicht |

---

## 6. Backups — die letzte Bastion

Das **3-2-1-Prinzip**:

> **3 Kopien** deiner Daten, auf **2 verschiedenen Medien**, davon **1 außer Haus**.

| Element | Bei dir konkret |
|---|---|
| **Original** | Aktuelle Daten auf Praxis-Server / Mac |
| **Kopie 1 (lokal)** | Time Machine auf externer Festplatte / NAS |
| **Kopie 2 (offsite)** | Cloud-Backup (Backblaze, Arq Cloud, eigener Server in anderer Lokation) |

### Praxis-spezifische Anforderungen

- **Backup-Frequenz:** mindestens täglich für Patientenakten
- **Aufbewahrung:** historische Versionen für mindestens 30 Tage (Erpressungs-Trojaner verschlüsseln, du fällst es 2–3 Wochen später auf)
- **Test:** Restore mindestens 1× pro Quartal **wirklich** durchspielen — sonst hast du kein Backup, sondern eine Hoffnung
- **Verschlüsselung:** Backups MÜSSEN verschlüsselt sein, sonst ist der Diebstahl der Backup-Festplatte ein Datenleak

> **Cortex-Tipp:** Proxmox hat eingebaute VM-Backup + Snapshot. [[Proxmox Grundlagen]] §03 beschreibt Storage und Backup-Strategien. Bei Praxis-Servern ist das die Schicht „Praxis-Server-Backup" — Mac-Backups sind separat.

---

## 7. DSGVO-Grundlagen für die Praxis

Die wichtigsten Säulen — vereinfacht:

### Rechtsgrundlagen

Datenverarbeitung ist nur erlaubt, wenn eine Rechtsgrundlage besteht. Bei dir typischerweise:

| Grundlage | Wofür typisch |
|---|---|
| **Art. 6 Abs. 1 b** Vertragserfüllung | Behandlungsvertrag, Rechnungsstellung |
| **Art. 9 Abs. 2 h** Gesundheitsversorgung | Patientendaten zur Behandlung |
| **Art. 6 Abs. 1 c** Rechtliche Verpflichtung | KV-Abrechnung, Aufbewahrungspflicht |
| **Art. 6 Abs. 1 a** Einwilligung | Newsletter, Marketing, Praxis-Webseiten-Tracking |

### Rechte der Patienten

Jede Person hat Anspruch auf:
- **Auskunft** (was speichert die Praxis?)
- **Berichtigung** (Falsches korrigieren)
- **Löschung** („Recht auf Vergessenwerden") — kollidiert mit Aufbewahrungspflicht
- **Einschränkung der Verarbeitung**
- **Datenübertragbarkeit** (Daten in lesbarem Format herausgeben)
- **Widerspruch**

→ Du musst **innerhalb 1 Monats** antworten können. Voraussetzung: du **weißt**, was wo gespeichert ist (Verfahrensverzeichnis).

### Verfahrensverzeichnis (Art. 30 DSGVO)

Pflicht für jede Praxis. Liste aller Verarbeitungstätigkeiten:
- PVS (inSuite/Doc Cirrus) → Patientenakten
- Buchhaltung → Stammdaten
- Webseite → Kontaktformular-Daten
- Newsletter (falls aktiv)
- Praxis-WLAN für Patienten (falls aktiv) → IPs
- Videoüberwachung (falls aktiv)
- KV-Abrechnung → Diagnose- + Leistungsdaten

### Auftragsverarbeitungs-Verträge (AV-Verträge)

Pflicht für jeden Dienstleister, der personenbezogene Daten verarbeitet:
- IT-Dienstleister
- Hosting-Provider (domainfactory)
- Cloud-Backup-Anbieter
- Buchhalter / Steuerberater
- Praxis-Software-Hersteller (inSuite)
- E-Mail-Provider

→ Vor Beginn der Zusammenarbeit unterschrieben, in Akte ablegen.

### Datenschutzbeauftragter (DSB)

Pflicht ab 20 Personen im Unternehmen, die regelmäßig personenbezogene Daten verarbeiten. Bei einer Arztpraxis mit besonderen Kategorien (Patientendaten) **immer Pflicht**, auch unter 20 — wegen Art. 37 Abs. 1 c DSGVO + § 38 BDSG.

→ Hast du? Falls nicht: das ist ein P0-Punkt. Externe DSB sind bezahlbar (~ 100–300 €/Monat).

---

## 8. Praxis-Sicherheits-Schichten konkret

| Schicht | Was du tun solltest |
|---|---|
| **Physisch** | Praxis abschließbar, Server-Raum mit Zugangskontrolle, Diebstahlsicherung |
| **Netzwerk** | getrennte VLANs (Patienten-WLAN ≠ Praxis-Netz), Firewall, IDS/IPS |
| **Endgeräte** | FileVault, automatische Bildschirmsperre, OS-Updates aktiviert |
| **Konten** | starke Passwörter, 2FA überall, getrennte Admin- vs. Tagesnutzer-Accounts |
| **Software** | Updates eingespielt (kein „Win 7" mehr), nur notwendige Software installiert |
| **Daten** | Verschlüsselung, Backups, klassifiziert nach Sensitivität |
| **Mensch** | Schulungen, Phishing-Sensibilisierung, klare Prozesse für Zwischenfälle |
| **Notfall** | Incident-Response-Plan: was tun bei Erpressung, Datenverlust, Diebstahl? |

---

## 9. Phishing & Social Engineering — die wahrscheinlichste Angriffsfläche

> **Statistisch:** Über 90 % der erfolgreichen Cyber-Angriffe starten mit einer **Phishing-Mail**.

### Erkennungs-Heuristiken

- Dringlichkeit künstlich erzeugt („SOFORT! Ihr Account wird gesperrt!")
- Absender-Adresse stimmt nicht (`amaz0n.de` statt `amazon.de`)
- Links führen woanders hin als angezeigt (in Mail-App lange auf Link drücken → echte URL sehen)
- Anhänge mit ungewohnten Endungen (`.exe`, `.zip`, `.html`)
- Banken/Behörden fragen NIE per Mail nach Passwort/PIN
- KV Hessen schickt keine Mahnungen per Mail mit Klick-Link

### Prozess für Mitarbeiter

1. **Im Zweifel nicht klicken**
2. Direkt den Absender auf bekanntem Weg kontaktieren (offizielle Telefonnummer, **nicht** aus der Mail)
3. Verdächtige Mail an dich weiterleiten
4. Nach klarem Phishing: Passwort sofort ändern, Konto-Logs prüfen

---

## 10. Geplante Module (Roadmap dieser Domäne)

- **01** — 2FA überall aktivieren — die Konto-Audit-Tour
- **02** — Passwort-Manager einrichten + alte Passwörter migrieren
- **03** — DSGVO-Verfahrensverzeichnis erstellen für die Praxis
- **04** — Backup-Strategie für Praxis-Server (3-2-1 konkret)
- **05** — FileVault auf allen Macs — Status-Check + Aktivierung
- **06** — Praxis-Phishing-Schulung als Mini-Workshop für Mitarbeiter
- **07** — Mac-Härtung: Gatekeeper, XProtect, Firewall, automatische Updates
- **08** — Incident-Response-Plan: was tun, wenn der Server verschlüsselt wurde?
- **09** — DSB-Auswahl + AV-Vertrags-Vorlagen
- **10** — TPM/Secure-Element + Hardware-Keys (YubiKey-Setup)

---

## 11. Begriffe-Spickzettel

| Begriff | Bedeutung |
|---|---|
| **DSGVO / GDPR** | Datenschutz-Grundverordnung (EU, seit 2018) |
| **BDSG** | Bundesdatenschutzgesetz (deutsche Ergänzung) |
| **DSB** | Datenschutzbeauftragter |
| **AV-Vertrag** | Auftragsverarbeitungs-Vertrag (Art. 28 DSGVO) |
| **TOMs** | Technische und Organisatorische Maßnahmen (Sicherheits-Konzept) |
| **2FA / MFA** | Zwei-/Mehr-Faktor-Authentifizierung |
| **TOTP** | Time-Based One-Time Password (das, was Google Authenticator generiert) |
| **HOTP** | HMAC-Based One-Time Password (Vorgänger, weniger üblich) |
| **TLS / HTTPS** | Verschlüsselte Verbindung Browser ↔ Server |
| **End-to-End-Verschlüsselung** | Server kann Inhalt nicht lesen (Signal, iMessage) |
| **VPN** | Virtuelles privates Netzwerk — verschlüsselt deinen Internet-Traffic |
| **IDS / IPS** | Intrusion Detection / Prevention System |
| **Firewall** | Netzwerk-Filter, blockiert unerwünschten Traffic |
| **Pentest** | Penetration-Test — beauftragter „freundlicher" Hack-Versuch |
| **CVE** | Common Vulnerabilities and Exposures — globale Sicherheitslücken-Liste |
| **Zero-Day** | Sicherheitslücke, die noch nicht gepatcht ist |
| **Ransomware** | Erpressungs-Trojaner (verschlüsselt Daten, fordert Lösegeld) |
| **Phishing** | Identitäts-Diebstahl per Mail/SMS/Anruf |
| **Social Engineering** | Manipulation von Menschen statt Technik |
| **Defense in Depth** | Mehrere Schutz-Schichten hintereinander |

---

## 12. Lern-Reihenfolge

1. **Diese Seite** — die Konzepte
2. **Modul 01** (sobald angelegt) — 2FA-Audit (deine Konten durchgehen)
3. **Modul 02** (sobald angelegt) — Passwort-Manager einrichten
4. **Modul 03** (sobald angelegt) — DSGVO-Verfahrensverzeichnis
5. **Modul 04** (sobald angelegt) — Backup-Strategie konkret
6. [[Proxmox Grundlagen]] §05 Sicherheit — Praxis-Server-spezifisch

---

## 13. Wichtige Cortex-Regeln zur Sicherheit

- **Secrets-Handhabung im Chat** ([[GLOBAL_RULES]] §Secrets) — nur App-Passwords/Tokens, nie Admin-Passwörter; nie loggen, nie committen
- **`.env` und Secrets-Dateien in `.gitignore`** — siehe [[Webentwicklung/Webdesign/04-credentials-und-env-dateien|Webdesign 04]]
- **LL-050** — destruktive Git-Operationen nur mit Freigabe (verhindert versehentliche Datenverluste)

---

## Verwandte Notizen

- [[_MOC Tutorials]] — Dach-MOC aller Tutorials
- [[_Basiswissen Schnelleinstieg]] — Querschnittspfad
- [[Proxmox Grundlagen]] §05 — Praxis-Server-Sicherheit
- [[WordPress Grundlagen]] — wp-admin 2FA, REST-API-Tokens
- [[Netzwerk Grundlagen]] — VLAN-Trennung, Firewall-Konzepte
- [[GLOBAL_RULES]] — Secrets-Regeln
