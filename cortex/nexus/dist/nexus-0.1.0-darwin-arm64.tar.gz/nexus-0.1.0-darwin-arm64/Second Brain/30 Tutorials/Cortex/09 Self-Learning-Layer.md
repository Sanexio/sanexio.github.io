---
title: Self-Learning-Layer
domain: cortex
modul: 09
level: fortgeschritten
status: kanonisch
---

# 09 — Self-Learning-Layer (Python)

> **Antwort in einem Satz:** Der Self-Learning-Layer ist die **Python-Schicht in `agent/`**, die Claude-Operationen orchestriert — sie liest Mode + Regeln + Skills, ruft das LLM (Anthropic-API), führt Skills aus, persistiert Sessions und Lessons; sie heißt „Self-Learning" weil die Strukturen für strukturelles Selbstlernen vorbereitet sind, aber der automatische Anteil heute nur teilaktiv ist (Detail: **[[06 Selbstlernendes System]]**).

In diesem Modul lernst du **welche Files den Layer ausmachen**, **wie der Loop konkret abläuft**, und **wo die Erweiterungs-Hebel liegen**.

## Wo es lebt — die Verzeichnis-Struktur

```
agent/                                  ← Self-Learning-Layer (Python)
├── __init__.py
├── cli.py                              ← Typer-CLI (Entry-Point)
├── loop.py                             ← Bootstrap, run, debrief
│
├── modes/                              ← Mode-Briefings (vom Hook injiziert)
│   ├── autonomy.md
│   ├── safe.md
│   └── tier3.md
│
├── memory/                             ← Memory-Subsystem
│   ├── store.py                        ← SQLite-FTS5-Wrapper
│   ├── golden_rules.py                 ← Renderer + Tier-3-Parser
│   ├── user_profile.py                 ← lädt USER.md
│   └── summarizer.py                   ← Session-Zusammenfassungen
│
├── skills/                             ← Skill-Engine + builtin Skills
│   ├── engine.py                       ← @skill-Decorator, Discovery, Run
│   ├── INDEX.md                        ← auto-generierter Skill-Index
│   └── builtin/
│       ├── capture_lesson.py
│       ├── doctor.py
│       ├── sanitizer.py
│       └── … (13 builtin Skills)
│
├── connexio/                           ← Multi-AI-Bridge
│   ├── kernel.py
│   ├── task_store.py
│   ├── lease_store.py
│   ├── http_server.py
│   ├── mcp_server.py
│   └── … (siehe [[08 Connexio]])
│
├── connexio_outbound/                  ← Multi-AI-Provider-Adapter
│   ├── anthropic_adapter.py
│   ├── openai_adapter.py
│   ├── gemini_adapter.py
│   └── ollama_adapter.py
│
├── providers/                          ← LLM-Provider-Abstraktion
│   ├── base.py
│   └── anthropic.py
│
└── cron/                               ← Cron-Recipe-System
    ├── runner.py
    └── recipes/*.toml
```

## Komponente 1 — Die CLI (`agent/cli.py`)

### Was sie macht

`cortex-agent` ist der zentrale Befehl, den du im Terminal tippst. Implementiert mit **Typer** (Python-Library für CLIs, ähnlich Click). Entry-Point in `pyproject.toml` als `cortex-agent = "agent.cli:app"`.

### Verfügbare Befehle

```bash
# Loop
cortex-agent run "<prompt>"                  # eine Loop-Iteration
cortex-agent bootstrap [--no-pull]           # Mode + User + Skills laden, System-Block-Größe melden

# Mode
cortex-agent mode get                        # aktuellen Modus anzeigen
cortex-agent mode set autonomy|safe          # Modus setzen

# Skills
cortex-agent skill list                       # alle registrierten Skills
cortex-agent skill run <name> [--args '{...}']  # Skill ausführen

# Memory
cortex-agent memory search "<query>"          # FTS5-Volltextsuche
cortex-agent memory facts [--kind <kind>]     # User-Facts anzeigen
cortex-agent memory add-fact <kind> <key> <value>  # Fact hinzufügen
```

### Wie es zusammenhängt

`cli.py` ist ein dünner Wrapper. Die echte Arbeit passiert in `loop.py`, `skills/engine.py`, `memory/store.py`. CLI sorgt für Argument-Parsing, Pretty-Output, Error-Handling.

## Komponente 2 — Die Loop (`agent/loop.py`)

### Pattern: Hermes-style

„Hermes-style" beschreibt das Loop-Pattern: **minimale, deterministische Schleife.** System-Prompt + User-Prompt rein, LLM-Antwort raus. Eine Iteration pro `cortex-agent run`. Keine verschachtelten Self-Calls, keine versteckten Agent-Schleifen.

**Begründung:** Komplexität entsteht durch klar getrennte Skills, nicht durch Loop-Rekursion. Wenn der Agent „mehr Schritte" braucht, ruft er einen Skill auf — der ist deterministisch, getestet, isoliert.

### Bootstrap-Phase

`bootstrap()` lädt vier Dinge:

```python
ctx = LoopContext(
    mode=get_mode(),                                  # autonomy|safe
    user=UserProfile.load(NEXUS_DIR/"_memory"/"USER.md"),
    store=MemoryStore(NEXUS_DIR/"_memory"/"memory.db"),
    skills=SkillEngine.discover(),                    # scannt agent.skills.builtin
    provider=AnthropicProvider(),                     # wenn ANTHROPIC_API_KEY gesetzt
)
```

Zusätzlich (optional): Pre-Pull (`git pull --ff-only` im Nexus, mit 15s-Timeout).

### Run-Phase

`run(ctx, user_input)`:

1. **System-Block bauen** (siehe nächste Sektion).
2. **Provider aufrufen** — `ctx.provider.complete(system=..., user=user_input, max_tokens=1024)`.
3. **Antwort zurückgeben** als String.

Wenn kein `ANTHROPIC_API_KEY` gesetzt: `_NullProvider` gibt nur System-Block-Größe und User-Prompt-Größe zurück (für Smoke-Tests).

### System-Block

Vier Teile, mit `---`-Separator zusammengeklebt:

```python
def system_block(ctx: LoopContext) -> str:
    parts = [
        load_mode_block(ctx.mode),       # autonomy.md oder safe.md
        ctx.user.system_block(),         # USER.md gerendert
        rules_block(),                   # golden_rules.py.system_prompt()
        _skills_section(ctx.skills),    # Liste verfügbarer Skills
    ]
    return "\n\n---\n\n".join(p for p in parts if p)
```

`rules_block()` ruft `system_prompt()` aus `agent/memory/golden_rules.py` auf — das injiziert den vollen tier3.md-Inhalt (Single Source seit P1-Refactor) + Wiederholungsfehler-Patterns GF-001..007.

## Komponente 3 — Memory-Subsystem (`agent/memory/`)

### `store.py` — SQLite-FTS5-Wrapper

Vier Tabellen (Detail: **[[05 Memory in 4 Schichten]]**):

```sql
CREATE VIRTUAL TABLE sessions USING fts5(ts, project, summary, full_text, tokenize='porter unicode61');
CREATE VIRTUAL TABLE patterns USING fts5(name, slug, body, tags, tokenize='porter unicode61');

CREATE TABLE skill_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    skill TEXT NOT NULL,
    args_json TEXT NOT NULL,
    result TEXT,
    ok INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE user_facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    ts REAL NOT NULL,
    UNIQUE(kind, key)
);
```

API:

```python
store.add_session(project, summary, full_text)
store.search(query, limit=10) -> list[SearchHit]
store.add_user_fact(kind, key, value)
store.recall_user_facts(kind=None)
store.log_skill_run(skill, args, result, ok)
store.register_skill(name, version, code_path, doc)
```

PRAGMA-Optimierungen: `journal_mode=WAL` (Write-Ahead Logging für Concurrency), `foreign_keys=ON`.

### `golden_rules.py` — Renderer + Tier-3-Parser

Parst die Kategorien aus `agent/modes/tier3.md` als Single Source und rendert daraus den vollen System-Block.

```python
TIER_3_HARDSTOPS = _parse_tier3_categories()  # ["Zugangsberechtigungen / Secrets", "Geld-Operationen", "Externe Empfänger"]

def system_prompt() -> str:
    # Lädt tier3.md komplett + REPEAT_ERRORS-Liste (GF-001..007)
    # Ergebnis: ~3700 Zeichen
```

`REPEAT_ERRORS` ist eine Python-Liste von `Rule`-Dataclasses (GF-001 OCR-Skew, GF-002 WP-CLI db query, …, GF-007 Übersetzungs-Audit). Diese werden im System-Block injiziert, damit ich beim nächsten Mal die Bug-Pattern erkenne, bevor ich in sie hineinlaufe.

### `user_profile.py` — `USER.md`-Lader

Parst `_memory/USER.md` in ein Python-Objekt. Stellt `system_block()`-Methode bereit für den Bootstrap.

### `summarizer.py` — Session-Zusammenfassungen

Aus Conversation-Tokens → kompakte Session-Summary → Insert in FTS5 `sessions`-Tabelle. Heute heuristisch, perspektivisch LLM-basiert.

## Komponente 4 — Skill-Engine (`agent/skills/`)

### Architektur

`@skill`-Decorator registriert Python-Funktionen global in `_REGISTRY`. `SkillEngine.discover()` scannt `agent.skills.builtin` via `pkgutil.iter_modules` und importiert alle Module → Decorator wird ausgeführt → Skill ist registriert.

```python
@skill(name="doctor", version="0.3.0", doc="Health-Check des Phoenix-Setups …")
def doctor(args: dict[str, Any]) -> str:
    # ...
    return "# Doctor-Report\n…"
```

### Execution + Logging

```python
engine = SkillEngine.discover()
result = engine.run("doctor", {"strict": False}, store=memory)
# → automatisch in skill_runs-Tabelle geloggt
```

Bei Exception: skill_runs-Eintrag mit `ok=0` + Error-String als result.

### Liste der 13 Builtin-Skills

Aus `agent/skills/INDEX.md`:

| Skill | Zweck |
|---|---|
| `capture-lesson` | Persistiert Lesson als Claude-Memory-File. |
| `connexio` | Connexio-Healthcheck, Audit-Tail, Server-Start. |
| `cron` | Phoenix-Cron — Recipe-Loader. |
| `curator` | Memory-Curation (facts, sessions, pending). |
| `doctor` | 10+-Punkte-Health-Check. |
| `outbound` | Connexio Outbound — externe KIs (OpenAI, Gemini, Ollama). |
| `pattern-miner` | Pattern-Extraktion (experimentell). |
| `sanitizer` | Memory-Wachstumskontrolle, VACUUM, TTL. |
| `scheduler` | LaunchAgent-Status. |
| `session-end` | Welle-Ende-Debrief in Memory. |
| `session-start` | Session-Start-Digest. |
| `spawn` | Spawn-Queue füllen/inspizieren. |
| `tutorial-curator` | Vault-Drift-Audit. |

## Komponente 5 — Providers (`agent/providers/`)

### `base.py` — Abstract Class

```python
class LLMProvider(ABC):
    @abstractmethod
    def complete(self, *, system: str, user: str, max_tokens: int = 1024) -> str: ...
```

### `anthropic.py` — Claude-Wrapper

Nutzt `ANTHROPIC_API_KEY` aus Umgebungsvariablen. Wrapper um `anthropic.Anthropic().messages.create(...)`.

### Geplant — weitere Provider

- OpenAI (für Codex-Expertise-Anfragen) — Stub in `connexio_outbound/openai_adapter.py`.
- Gemini (Multi-Modal) — Stub in `connexio_outbound/gemini_adapter.py`.
- Ollama (Offline-LLM) — Stub in `connexio_outbound/ollama_adapter.py`.

Diese sind noch nicht im Loop-Provider-Path; sie laufen über Connexio-Outbound (siehe nächste Komponente).

## Komponente 6 — Connexio-Outbound (`agent/connexio_outbound/`)

Wenn der Self-Learning-Layer **ein anderes Modell** für eine Sub-Aufgabe aufrufen will (z.B. „GPT-4 für Code-Review", „Gemini für Vision"), läuft das über `connexio_outbound`. 

Heute Stub — Architektur steht, produktiver Einsatz noch offen.

## Komponente 7 — Cron (`agent/cron/`)

### Was es ist

TOML-Recipe-Runner. Recipes sind kleine Dateien, die einen Skill periodisch ausführen.

```toml
# agent/cron/recipes/nightly-sanitizer.toml
name = "nightly-sanitizer"
description = "Memory-DB vacuumieren, Logs rotieren, stale Spawns archivieren"
frequency = "daily"
hour = 3
minute = 30
command = ["cortex-agent", "skill", "run", "sanitizer"]
require_approval = false
```

### Recipes heute

| Recipe | Frequenz | Zweck |
|---|---|---|
| `nexus-pull.toml` | (deaktiviert — Sync läuft via LaunchAgent) | Pull-Backup. |
| `nexus-push.toml` | manuell | Push-Backup. |
| `nightly-sanitizer.toml` | täglich 3:30 | Memory-DB + Logs aufräumen. |
| `tutorial-curator-weekly.toml` | wöchentlich | Vault-Drift-Audit. |
| `connexio-inbox-notify.toml` | stündlich | Inbox prüfen, neue Tasks pushen. |

### Stand

LaunchAgent `com.cortex.phoenix-cron.plist` ist im Repo (`agent/cron/launchagents/`), aber **nicht systemweit installiert**. Recipes laufen heute nicht automatisch — sie sind als Manifest vorhanden, nicht als Cron-Job.

## Wie ein typischer `cortex-agent run` abläuft

```
[1] User tippt: cortex-agent run "Pflege Memory aus letzter Session"
       │
       ▼
[2] cli.py parsed Argumente
       │
       ▼
[3] loop.bootstrap() lädt:
    • Mode aus state-file
    • USER.md
    • SkillEngine.discover() → 13 Skills registriert
    • MemoryStore (FTS5-DB)
    • AnthropicProvider
    • Optional: git pull --ff-only
       │
       ▼
[4] loop.system_block(ctx) baut System-Prompt:
    • Mode-Briefing (autonomy.md, ~480 Tokens)
    • USER.md gerendert (~200 Tokens)
    • Goldene Regeln (tier3.md + REPEAT_ERRORS, ~750 Tokens)
    • Skills-Section (13 Skills mit Doc-One-Liner, ~400 Tokens)
       │
       ▼
[5] AnthropicProvider.complete(system, user) → Antwort-String
       │
       ▼
[6] Optional: am Welle-Ende automatischer session_end-Skill,
    der die Session als Summary in memory.db schreibt
    (heute manuell zu triggern)
       │
       ▼
[7] Output an stdout
```

## Aktueller Stand — was läuft, was nicht

| Komponente | Status |
|---|---|
| `cli.py` Entry-Points | ✅ Alle (run, bootstrap, mode, skill, memory) funktional. |
| `loop.py` Single-Roundtrip | ✅ Stabil. |
| `golden_rules.py` Parser (Tier-3 aus tier3.md) | ✅ Aktiv — Single-Source-Parser nach dem Architektur-Refactor. |
| 13 Builtin-Skills | ✅ Registriert, ausführbar via CLI. |
| FTS5-Memory (sessions, patterns, skill_runs, user_facts) | ✅ Schreibt. Recall heuristisch. |
| Connexio-Integration | ✅ Tasks + Leases funktional. |
| Provider — Anthropic | ✅ Aktiv. |
| Provider — OpenAI/Gemini/Ollama | ⛔ Stub in connexio_outbound. |
| Cron-Recipes | ⛔ Im Repo, aber LaunchAgent nicht installiert. |
| Tool-Calling im Loop (Skills direkt aus LLM-Antwort) | ⛔ Nicht implementiert. Skills werden heute separat per CLI ausgeführt. |
| Automatischer session-end nach Welle | ⛔ Nicht im Standard-Flow. |

## Erweiterungs-Hebel — wie der Layer wirklich „lernend" wird

Verweis auf **[[06 Selbstlernendes System]]** für die strategischen Hebel. Hier nur die Python-spezifischen:

### Hebel A — Tool-Calling im Loop

Heute: ich gebe Markdown-Antworten, du tippst `cortex-agent skill run <name>`. Besser: das LLM gibt **strukturierte Tool-Calls** zurück (Anthropic-API unterstützt das nativ), `loop.py` führt sie aus, gibt Ergebnisse zurück. Aufwand: ~100 Zeilen Python.

### Hebel B — Auto-session-end

`loop.py` triggert automatisch `session-end` am Conversation-Ende (z.B. via Hook oder Stop-Signal). Heute manuell.

### Hebel C — Workflow-Engine

YAML-Workflows in `agent/workflows/*.yaml` (siehe **[[06 Selbstlernendes System]]** Hebel 5). Skill-Ketten statt isolierter Aufrufe.

### Hebel D — Semantischer Recall

`store.search()` nicht nur Keyword (FTS5), sondern Embedding-basiert (siehe **[[06 Selbstlernendes System]]** Hebel 3).

### Hebel E — Cron-Recipes aktivieren

LaunchAgent installieren, nightly-sanitizer + connexio-inbox-notify + tutorial-curator-weekly laufen lassen. Heute alles manuell.

## Public-Skeleton-Perspektive

Der ganze `agent/`-Layer ist **generisch** (Audit-Mapping ✅). Stracke-Spezifisches lebt außerhalb (`USER.md`, `medical-domain.md`, `devices.json`, Vault). Daher ist `agent/` 1:1 in den Public-Skeleton übernehmbar.

**Eine Anpassung nötig:** `doctor.py`-Pfade (POLICY_FILES, DRIFT_PATTERNS) sollten aus einer Config-Datei kommen, nicht hardcoded. Heute hardcoded auf Nexus-Layout — passt für jeden Teilnehmer, der die Standard-Struktur nutzt.

## Was du mit diesem Modul jetzt kannst

- Du verstehst, dass `agent/` die Python-Schicht ist, in der „Entscheidungen" passieren.
- Du kannst die 7 Komponenten benennen (CLI, Loop, Memory, Skills, Providers, Outbound, Cron).
- Du verstehst das Hermes-Pattern (Single-Roundtrip statt verschachtelter Loops).
- Du kennst alle 13 Builtin-Skills und ihren Zweck.
- Du weißt, was Cron-Recipes sind und warum sie heute nicht laufen.
- Du kennst die 5 Python-spezifischen Erweiterungs-Hebel.

## Verwandte Tutorials

- **[[01 Architektur und Schichten]]** — wo der Layer im Big Picture steht
- **[[05 Memory in 4 Schichten]]** — Memory-Architektur im Detail
- **[[06 Selbstlernendes System]]** — strategische Hebel zum Aktivieren
- **[[08 Connexio]]** — wie Multi-AI darüber läuft
- **[[10 Channel-Router]]** — wie Eingangs-Nachrichten in den Layer kommen
- `agent/skills/INDEX.md` — autoritative Skill-Liste
