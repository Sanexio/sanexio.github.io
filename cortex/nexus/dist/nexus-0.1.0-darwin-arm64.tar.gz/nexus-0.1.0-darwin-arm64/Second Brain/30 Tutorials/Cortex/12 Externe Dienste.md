---
title: Externe Dienste
domain: cortex
modul: 12
level: einsteiger-bis-fortgeschritten
status: kanonisch
---

# 12 — Externe Dienste

> **Antwort in einem Satz:** Cortex ist keine geschlossene Insel — er ruht auf einem kleinen Stapel externer Dienste (GitHub für Sync und Repos, Tailscale für SSH zwischen Macs, Obsidian für den Vault, Anthropic für die LLM-Anfragen, Telegram für mobile Bedienung), und dieses Modul zeigt **wofür Cortex jeden Dienst nutzt und was passiert, wenn er ausfällt**.

In diesem Modul lernst du **welche Dienste mitspielen**, **welche Cortex zwingend braucht und welche optional sind**, und **wie ein Public-Skeleton-Teilnehmer ohne deine privaten Konten ans Laufen kommt**.

## Übersicht — die fünf zentralen Dienste

```
                ┌──────────────────────────────────────────────┐
                │           CORTEX (auf deinem Mac)             │
                │                                              │
                │   Agent ↔ Channel-Router ↔ Memory ↔ Vault    │
                └──┬───────┬───────┬───────┬───────┬───────────┘
                   │       │       │       │       │
                   ▼       ▼       ▼       ▼       ▼
              ┌────────┐┌─────┐┌──────┐┌──────────┐┌─────────┐
              │GitHub  ││Tail-││Obsi- ││Anthropic ││Telegram │
              │        ││scale││dian  ││API       ││Bot-API  │
              │        ││Mesh ││App   ││(Claude)  ││         │
              └────────┘└─────┘└──────┘└──────────┘└─────────┘
              KRITISCH  KRIT.  OPTION. KRITISCH   OPTIONAL

   KRITISCH = Cortex funktioniert ohne nicht.
   OPTIONAL = Verlust ist Komfort-Einbuße, kein Ausfall.
```

## Dienst 1 — GitHub (Sanexio-Repos)

### Was Cortex davon nutzt

GitHub ist die **einzige Sync-Drehscheibe** zwischen deinen Macs. Es gibt keinen direkten Mac-zu-Mac-Sync — alles geht über GitHub.

Konkrete Repos:
- **`Sanexio/nexus`** — Steuerwerk + Vault + alle Regeln. Pflicht auf jedem Mac.
- **`Sanexio/cortex-web`** — praxis-webseite.
- Weitere Projekt-Repos je nach Werkprojekt.
- **`Sanexio/cortex-public`** (geplant) — Skeleton-Variante für Teilnehmer.

### Wie Cortex damit interagiert

| Mechanismus | Wann | Wer |
|---|---|---|
| `git pull --ff-only` | Alle 5 Min + vor jedem R2-Edit | `nexus-sync.sh` (LaunchAgent) und Anwender manuell |
| `git push` | Nach jeder Welle | `nexus-sync.sh` (für die Auto-Commit-Whitelist) und Claude bzw. Anwender manuell |
| `gh` CLI | PR-Erstellung, Issue-Lookup | Claude und Anwender im Terminal |
| Branch-Backup | `pre-phoenix-reset-2026-05-08`-Branch | Notfall-Rollback |

### Auth

SSH-Key in `~/.ssh/`, beim Onboarding eines Mac eingerichtet. Tier-3-geschützt (nicht überschreibbar durch KI).

### Wenn GitHub ausfällt

- **Lokale Arbeit** funktioniert weiter (kein Sync, aber Edits + lokaler Git).
- **Sync hängt** — Drift wächst, Heartbeats werden alt.
- **Recovery:** abwarten bis GitHub wieder da, dann normale `git pull` (FF, weil keine konkurrierenden Pushes möglich waren).

### Was Stracke-spezifisch ist

- Die konkreten Repo-Namen (`Sanexio/nexus`).
- SSH-Key.
- GitHub-Organisation (`Sanexio` als Owner).

### Public-Skeleton-Hinweis

Teilnehmer im Sanexio-Geschäftsmodell:
- Forken `Sanexio/cortex-public` in **eigenen GitHub-Account**.
- Ihre `nexus-sync.sh`-Konfiguration zeigt auf den eigenen Fork.
- **Kein Push zurück zu Sanexio** — der Stracke-Privat-Nexus bleibt unter Stracke-Kontrolle.
- Update-Pfad: Sanexio pflegt `cortex-public`, Teilnehmer pullen Updates per `git fetch upstream && git merge`.

## Dienst 2 — Tailscale (Mesh-VPN)

### Was es ist

**Tailscale** ist ein Mesh-VPN: deine Macs treten einem virtuellen Privat-Netz bei und können sich gegenseitig direkt erreichen (mit privaten IPs aus dem 100.x.x.x-Range), auch durch NAT/Firewalls hindurch. Authentifizierung läuft über deinen Tailscale-Account (z.B. via Google-SSO).

Dein Tailnet heißt **`piranha-marlin.ts.net`** (Personal-Plan, der Name war zufällig — „cortex" war beim Setup nicht verfügbar).

### Was Cortex davon nutzt

| Use-Case | Mechanismus |
|---|---|
| **SSH zwischen Macs** | `ssh ssmd@cluster-mini-02` über Tailscale-IP, Auth über Tailscale-SSH (keine eigenen SSH-Keys nötig). |
| **Mac-IPs für devices.json** | `.config/devices.json` trägt pro Mac die Tailscale-IP ein (`mesh_ip_v4`). |
| **Mosh** (Mobile Shell) | Optional, robustere SSH-Variante bei wackelnder Verbindung. |
| **Connexio-Cross-Device** (geplant) | Wenn Connexio cross-device gehen soll, läuft das über Tailscale-Loopback. |

### Tags und ACL

Cortex-Macs sind getagged mit `tag:cortex-admin` und `tag:cortex-host-mac`. Die ACL-Vorlage `Nexus/.config/tailscale-acl.json` definiert, welche Tags miteinander reden dürfen.

### Wenn Tailscale ausfällt

- **Lokale Arbeit unbeeinträchtigt.**
- **SSH zwischen Macs schlägt fehl** (Tailscale-IPs unerreichbar).
- **Sync funktioniert weiter** (geht über GitHub, nicht Tailscale).
- **Recovery:** `tailscale up --reset` lokal, falls Verbindung hängt. Bei Login-Verlust: `tailscale login` über Browser.

### Was Stracke-spezifisch ist

- Dein Tailnet-Name.
- Die konkreten IPs (`100.93.193.44` für M5 etc.).
- Dein Tailscale-Account.

### Public-Skeleton-Hinweis

Teilnehmer:
- Brauchen **eigenes Tailscale-Konto** (Personal-Plan reicht).
- Eigenes Tailnet, eigene Tags.
- `onboard-device.sh` führt durch Setup.
- **Keine Verbindung zum Stracke-Tailnet** — jeder Teilnehmer ist isoliert.

## Dienst 3 — Obsidian (Vault-App)

### Was es ist

**Obsidian** ist eine Markdown-Notizen-App, die einen Ordner als „Vault" behandelt. Features die Cortex nutzt:
- **Wikilinks** `[[Ziel]]` für interne Verlinkungen.
- **Graph-View** für visuelle Beziehungen zwischen Notizen.
- **Frontmatter** in YAML für strukturierte Metadaten.
- **MOC-Pattern** (Map of Content) für Indizes.

### Was Cortex davon nutzt

Eigentlich **nichts** außer das Format. Der Vault `Second Brain/` ist ein Ordner aus Markdown-Dateien, der **mit oder ohne Obsidian** lesbar/editierbar ist. Obsidian bringt die Komfort-Schicht:
- Schöner Editor mit Wikilink-Auto-Completion.
- Live-Preview + Graph-View.
- Mobile-Apps (iOS, Android) zur Vault-Bearbeitung unterwegs.

### Mobile Synchronisation — das offene Problem

Der Vault ist auf den Macs vollständig verfügbar, auf iOS und iPadOS bislang jedoch nicht. Damit fehlt ein durchgängiger Lese- und Notiz-Zugriff im mobilen Alltag.

Obsidian-Mobile kann grundsätzlich über drei Pfade syncen:

1. **Obsidian-Sync** (kostenpflichtiger Dienst von Obsidian) — überträgt den Vault über die Obsidian-Cloud.
2. **iCloud Drive** — liegt der Vault dort, kümmert sich iOS Files automatisch um die Synchronisation.
3. **Git via Working-Copy-App** — manuell pro Vault, kein Auto-Sync.

Derzeit ist keiner dieser drei Pfade aktiv. Der Vault liegt in `~/Cortex/Nexus/Second Brain/` und ist über Git synchronisiert — am mobilen Endgerät jedoch nicht angebunden.

Eine perspektivische Option ist eine eigene mobile Vault-App, die nativen iOS/iPad-Zugriff mit Mac-Sync verbindet, ohne den Obsidian-Stack vorauszusetzen. Sie steht derzeit nicht auf der aktiven Roadmap, ist aber als Architektur-Hebel notiert.

### Wenn Obsidian ausfällt / nicht installiert ist

- **Vault funktioniert weiter** — als Markdown-Files. `cat`, `grep`, jeder Editor.
- **Wikilinks brechen visuell** — aber der Text bleibt lesbar.
- **Graph-View weg** — kein Verlust an Inhalt.

Cortex hängt nicht von Obsidian ab. Obsidian ist deine Editor-Wahl, nicht eine Cortex-Komponente.

### Public-Skeleton-Hinweis

Teilnehmer:
- Können Obsidian nutzen oder einen beliebigen Markdown-Editor.
- Vault-Pfad ist konfigurierbar (Erweiterung in `tutorial_curator.py`, derzeit hardcoded).

## Dienst 4 — Anthropic API (Claude)

### Was es ist

Die **API von Anthropic**, über die meine Antworten kommen. Cortex nutzt sie auf zwei Wegen:

1. **Claude Code** (was du gerade benutzt) — eigene CLI/IDE, die direkt mit der API spricht.
2. **`agent/providers/anthropic.py`** im Self-Learning-Layer — `cortex-agent run` kann ebenfalls API-Calls absetzen.

### Auth

`ANTHROPIC_API_KEY` in der `.env`-Datei (Tier-3 — niemals committen).

### Modell-Wahl

Standardmäßig **Claude Opus 4.7** (1M Context). Andere verfügbare Modelle: Sonnet 4.6, Haiku 4.5. Modell-Auswahl in Claude Code via `/model` oder per `model`-Feld in `~/.claude/settings.json`.

### Kosten-Konsiderationen

API-Aufrufe kosten Geld (Input-Tokens + Output-Tokens). Optimierungen:
- **Prompt-Caching** — wiederholte Kontext-Blöcke werden cached, drastisch billiger.
- **System-Block-Größe** — kleiner System-Block = günstiger.
- **Modus-Wahl** — Opus ist teurer als Sonnet als Haiku. Für Routine reicht oft Sonnet.

Aktuell: System-Block ~3 KB (~750 Tokens), das ist im akzeptablen Rahmen.

### Wenn die API ausfällt

- **Du kannst nicht mit mir chatten** (kein Claude-Response).
- **Cortex-Infrastruktur funktioniert weiter** (Sync, Skills via CLI, Vault-Edits).
- **Recovery:** abwarten, Status auf `status.anthropic.com` prüfen.

### Fallback-Optionen (geplant)

`agent/connexio_outbound/` enthält Stub-Adapter für **OpenAI** (GPT-4), **Gemini** (Google), **Ollama** (lokal). Wenn aktiv: bei Anthropic-Ausfall könnte Cortex auf einen anderen Provider umschalten. Heute: nicht aktiviert.

### Public-Skeleton-Hinweis

Teilnehmer:
- Brauchen **eigenen Anthropic-API-Key** (über Console).
- Eigene `.env` mit ihrem Key.
- Kosten gehen auf ihre Anthropic-Rechnung.
- Sanexio liefert das Software-Skeleton, keine geteilten API-Credits.

## Dienst 5 — Telegram (Bot-API)

### Was es ist

Cortex nutzt einen Telegram-Bot (**`@sanexio_bot`**) als mobile Bedienoberfläche. Detail in **[[10 Channel-Router]]**.

### Was Cortex davon nutzt

- **getUpdates** — Long-Polling alle 5 Sek, holt eingehende Nachrichten.
- **sendMessage** — Antworten zurückschicken.
- **/-Befehle** — `/status`, `/spawn`, `/pause`, `/help`.

### Auth

`TELEGRAM_BOT_TOKEN` in `.env` (vom @BotFather erhalten). `TELEGRAM_ALLOWED_CHAT_IDS` whitelistet deine Chat-ID.

### Wenn Telegram ausfällt

- **Mobile Bedienung unterbrochen.**
- **Cortex-Infrastruktur unbeeinträchtigt** (Sync, Agent, Vault laufen weiter).
- **Recovery:** abwarten. Wenn lange weg: Bot-Token rotieren ist Tier-3.

### Stracke-spezifischer Status

Heute funktioniert nur **eingehende** Richtung zuverlässig. **Ausgehende Antworten kommen nur von Cluster-Mini-02**. Memory-Notiz: `project_telegram_only_cluster_mini_02.md`. Diagnose pro Mac siehe **[[10 Channel-Router]]**.

### Public-Skeleton-Hinweis

Teilnehmer:
- Brauchen **eigenen Telegram-Bot** (via @BotFather kostenlos registrieren).
- Eigene Chat-IDs in der `.env`.
- Optional — kein Telegram = kein Verlust außer Mobile-Komfort.

## Weitere Dienste (sekundär)

### Bun (JavaScript-Laufzeit)

- Wird benutzt für `gateway/` (Channel-Router).
- Installation: `brew install oven-sh/bun/bun`.
- Pflicht für Telegram-Bridge, optional sonst.

### uv (Python-Paketmanager)

- Wird benutzt für `agent/` (Self-Learning-Layer).
- Installation: `brew install astral-sh/uv/uv`.
- Pflicht für `cortex-agent`-CLI.

### Homebrew

- Standard-macOS-Paketmanager.
- Cortex hängt nicht direkt davon ab, aber die meisten anderen Dienste werden darüber installiert.

### Local-by-Flywheel (lokales WordPress)

- Optional, nur für praxis-webseite-Workflows relevant.
- Liefert lokale WP-Sites (`*.local`-Domains).
- Pfade in `~/Library/Application Support/Local/sites.json`.

### MCP-Server (verschiedene)

Claude Code lädt MCP-Server, die in `~/.claude.json` registriert sind. Cortex-relevant:
- `claude.ai Figma` — Design-Connect-Tools.
- `claude.ai Google Drive` — Drive-Zugriff.
- `telegram-bridge` — siehe oben.

Detail: `claude mcp list`.

## Diensteketten — wer hängt von wem ab?

```
┌─────────────────────────────────────────────────────────────┐
│                       CORTEX-LAUFFÄHIG                       │
└─────────────────────────────────────────────────────────────┘
              │                          │              │
              ▼                          ▼              ▼
         ┌─────────┐              ┌────────────┐  ┌──────────┐
         │ GitHub  │              │ Anthropic  │  │ Lokales  │
         │ (Sync)  │              │ API        │  │ macOS    │
         └─────────┘              │ (LLM)      │  │ (uv,bun) │
                                  └────────────┘  └──────────┘

              │                          │              │
              ▼ optional                 ▼ optional     ▼
         ┌─────────┐              ┌────────────┐  ┌──────────┐
         │Tailscale│              │ Telegram   │  │ Obsidian │
         │(Mac-zu- │              │ Bot-API    │  │ (Editor) │
         │ Mac SSH)│              │ (mobile UI)│  │          │
         └─────────┘              └────────────┘  └──────────┘
```

**Minimal-Setup für lauffähigen Cortex:**
- GitHub-Account + SSH-Key (Sync).
- Anthropic-API-Key (Claude-Antworten).
- macOS mit uv + bun installiert (Code-Ausführung).

**Optional:**
- Tailscale (für SSH zwischen Macs — bei einem einzelnen Mac unnötig).
- Telegram (für mobile Bedienung).
- Obsidian (für komfortable Vault-Bearbeitung).

## Was du mit diesem Modul jetzt kannst

- Du kennst die fünf zentralen Dienste (GitHub, Tailscale, Obsidian, Anthropic, Telegram) und ihre Rolle.
- Du weißt, welche kritisch sind (GitHub, Anthropic) und welche optional (Tailscale, Obsidian, Telegram).
- Du verstehst, dass Cortex **nicht von Obsidian abhängt** — der Vault wäre auch mit einem anderen Markdown-Editor nutzbar.
- Du kennst die Public-Skeleton-Konsequenzen pro Dienst (eigene Accounts, eigene Repos, isolierte Tailnets).
- Du weißt, dass die Mobile-Vault-Lücke (Obsidian-Sync) als deferred Idee in der MOC notiert ist.

## Verwandte Tutorials

- **[[02 Datei-Atlas]]** — wo Cortex die Dienst-Konfigurationen pflegt
- **[[07 Multi-Device-Sync]]** — GitHub als Sync-Drehscheibe im Detail
- **[[10 Channel-Router]]** — Telegram-Integration im Detail
- **[[14 Notfall und Recovery]]** — was tun bei Dienst-Ausfall (nächstes Modul)
- **[[15 Erweitern und Sichern]]** — wie ein neuer Mac in den Dienst-Verbund kommt
- `.config/devices.json` — Tailscale-Mesh-Konfiguration
- `.config/tailscale-acl.json` — Tailscale-ACL-Vorlage
