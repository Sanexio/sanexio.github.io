---
title: Notfall und Recovery
domain: cortex
modul: 14
level: fortgeschritten
status: kanonisch
---

# 14 — Notfall und Recovery

> **Antwort in einem Satz:** Dieses Modul ist das Notfall-Kochbuch — pro Symptom (Sync hängt, Hook greift nicht, Memory-DB korrupt, Telegram tot, Mac komplett ab, Tier-3-Block kaputt) eine Diagnose-Sequenz und eine Recovery-Reihenfolge; die meisten Fehler lassen sich in 5-15 Minuten beheben, wenn man weiß, welche der vier Schichten betroffen ist.

In diesem Modul lernst du **wie du Symptome triagierst**, **welche Befehle in welcher Reihenfolge sicher sind**, und **was du nie ohne Backup tun solltest**.

## Remote-Control als Recovery-Pfad

`claude remote-control` ist der bevorzugte Pfad, wenn von unterwegs auf einen Rechner zugegriffen werden muss, der lokal Probleme macht. Aktivierung (auf einem funktionierenden Rechner):

```bash
claude remote-control --spawn worktree
```

Dann via `claude.ai/code` oder QR-Code zur Claude-App: laufende Sessions sichtbar, Prompts möglich. Das ersetzt ssh in vielen Fällen.

## Allgemeine Triage-Regel

Bei jedem Cortex-Problem zuerst diese Frage: **Welche Schicht ist betroffen?**

| Schicht | Symptom-Hinweis |
|---|---|
| **Sync** | „Mein anderer Mac hat den Stand nicht", „Auto-Sync-Log meldet Fehler" |
| **Mode/Hook** | „Claude fragt obwohl autonomy", „Tier-3 wird nicht geblockt" |
| **Agent** | „cortex-agent CLI schlägt fehl", „Skill-Aufruf wirft Exception" |
| **Memory** | „cortex-agent memory search liefert nichts", „doctor meldet DB-Fehler" |
| **Gateway/Telegram** | „Bot antwortet nicht", „/status sagt nichts zurück" |
| **Connexio** | „Codex sieht meine Task nicht", „Lease hängt expired-aktiv fest" |
| **Vault** | „Wikilinks broken", „MOC zeigt nicht alle Tutorials" |

Wenn unklar: **`cortex-agent skill run doctor`** zuerst. Der Doctor-Skill checkt 15+ Punkte und sagt dir, welche Schicht klemmt.

## Notfall 1 — Sync hängt, Mac hinkt hinterher

### Symptom

- `git log --oneline -5` zeigt: letzter Commit ist Tage alt.
- `git fetch origin && git rev-list --left-right --count HEAD...origin/main` zeigt: `0	N` mit N > 0.
- `nexus-sync.log` zeigt entweder „BRANCH-SKIP" oder gar keine Einträge der letzten Stunde.

### Diagnose

```bash
cd ~/Cortex/Nexus

# 1. Auf welchem Branch?
git branch --show-current

# 2. LaunchAgent aktiv?
launchctl list | grep cortex
# Erwartet: com.cortex.nexus-sync mit PID oder "-"

# 3. Sync-Log Stand?
tail -20 _memory/logs/nexus-sync.log

# 4. Heartbeat-Alter?
ls -la .config/heartbeats/
# Erwartet: jeder Mac mit aktuellem mtime (< 1 Stunde)

# 5. Uncommitted Changes blockieren?
git status --short
```

### Recovery

**Fall A: Branch ist Feature-Branch, Mac steckt fest** (M5-Vorfall 2026-05-13)

```bash
git stash push -u -m "presync-stash-$(date +%Y%m%d)"
git checkout main
git pull --ff-only
git stash pop      # nur wenn Inhalt erwünscht; sonst stash drop
```

**Fall B: LaunchAgent nicht geladen**

```bash
launchctl load ~/Library/LaunchAgents/com.cortex.nexus-sync.plist
launchctl kickstart -k gui/$(id -u)/com.cortex.nexus-sync   # manuell triggern
sleep 5
tail -10 _memory/logs/nexus-sync.log
```

**Fall C: Echte Divergenz** (lokale Commits + Remote-Commits, FF nicht möglich)

```bash
git log --oneline -5         # was sind die lokalen Commits?
git log origin/main --oneline -5
# Entscheiden: rebase oder reset?

# Rebase (lokale Commits bleiben):
git pull --rebase

# ODER reset (lokale Commits verwerfen — nur wenn sicher!):
git fetch origin
git reset --hard origin/main
```

**Fall D: Uncommitted Changes blockieren Pull**

```bash
git stash push -u -m "presync-$(date +%s)"
git pull --ff-only
git stash pop
```

### Vorbeugung

- LaunchAgent auf jedem Mac laden (siehe **[[07 Multi-Device-Sync]]**).
- Hooks nicht verbasteln (Auto-Commit-Whitelist ist bewusst eng).

## Notfall 2 — Hook greift nicht (Autonomy-Mode wird ignoriert)

### Symptom

- Ich (Claude) frage in Claude Code „Soll ich…?" trotz `mode: autonomy`.
- Antworten enthalten keine Mode-spezifischen Hinweise.
- Tier-3-Block scheint nicht aktiv.

### Diagnose (siehe **[[11 Hooks und Mode-Injection]]** Detail)

```bash
# 1. State-File korrekt?
cat ~/.claude/state/cortex-mode.json
# Erwartet: {"mode": "autonomy", ...}

# 2. Skript existiert + ausführbar?
ls -la ~/Cortex/Nexus/tools/cortex-mode/bin/inject.sh
# Erwartet: -rwxr-xr-x

# 3. Skript läuft manuell?
echo '{"hook_event_name":"UserPromptSubmit","prompt":"test"}' \
  | bash ~/Cortex/Nexus/tools/cortex-mode/bin/inject.sh \
  | jq -r '.hookSpecificOutput.additionalContext' \
  | head -5
# Erwartet: Anfang von autonomy.md

# 4. Hook registriert?
jq -e '.hooks.UserPromptSubmit[] | select(.matcher == "") | .hooks[] | select(.type == "command") | .command' \
  ~/.claude/settings.json
# Erwartet: "bash $HOME/Cortex/Nexus/tools/cortex-mode/bin/inject.sh"
```

### Recovery

**Wenn der Hook fehlt** (häufigster Fall — die Hook-Registration in `~/.claude/settings.json` ist rechner-lokal und wird beim Onboarding manuell oder via `scripts/onboard-device.sh` gesetzt):

Snippet in `~/.claude/settings.json` ergänzen (im `hooks`-Block, mergen mit existierenden Sektionen):

```json
"hooks": {
  "UserPromptSubmit": [
    {
      "matcher": "",
      "hooks": [
        {
          "type": "command",
          "command": "bash $HOME/Cortex/Nexus/tools/cortex-mode/bin/inject.sh",
          "timeout": 10
        }
      ]
    }
  ]
}
```

Danach: **Claude Code neu starten oder `/hooks` öffnen** (sonst kennt der Watcher die neue Sektion nicht).

**Wenn Skript fehlt:**

```bash
cd ~/Cortex/Nexus && git pull --ff-only
ls tools/cortex-mode/bin/inject.sh
```

Sollte da sein — wenn nicht: Git-Working-Tree ist beschädigt, `git reset --hard origin/main` (Tier-2, im eigenen Repo OK).

**Wenn State-File korrupt:**

```bash
rm ~/.claude/state/cortex-mode.json
# Beim nächsten Hook-Aufruf wird es mit autonomy auto-re-init.
```

## Notfall 3 — Memory-DB-Probleme

### Symptom

- `cortex-agent memory search "..."` wirft SQLite-Fehler.
- `doctor` meldet „Memory-DB ist 0 bytes" oder „malformed".
- Skill-Aufrufe schreiben keine Logs in skill_runs-Tabelle.

### Diagnose

```bash
# 1. DB existiert?
ls -la ~/Cortex/Nexus/_memory/memory.db
# Erwartet: > 0 bytes

# 2. Integrity-Check
sqlite3 ~/Cortex/Nexus/_memory/memory.db "PRAGMA integrity_check;"
# Erwartet: "ok"

# 3. Tabellen vorhanden?
sqlite3 ~/Cortex/Nexus/_memory/memory.db ".tables"
# Erwartet: sessions, patterns, skill_runs, user_facts, skills, meta
```

### Recovery

**Fall A: DB ist 0 bytes oder neu**

Wird beim nächsten `cortex-agent bootstrap` automatisch initialisiert. Kein manuelles Eingreifen nötig.

**Fall B: DB malformed**

```bash
# Backup
cp ~/Cortex/Nexus/_memory/memory.db ~/Cortex/Nexus/_memory/memory.db.broken

# Versuch: Dump + Restore
sqlite3 ~/Cortex/Nexus/_memory/memory.db ".dump" > /tmp/memdump.sql
sqlite3 ~/Cortex/Nexus/_memory/memory.db.new < /tmp/memdump.sql

# Wenn ok:
mv ~/Cortex/Nexus/_memory/memory.db ~/Cortex/Nexus/_memory/memory.db.corrupt
mv ~/Cortex/Nexus/_memory/memory.db.new ~/Cortex/Nexus/_memory/memory.db
```

**Fall C: DB komplett verloren — Wiederaufbau**

Schichten 1+2 sind gitversioniert. Schicht 3 (memory.db) lässt sich nur aus Sessions/Skill-Runs wieder aufbauen — beides ist Mac-lokal.

```bash
# Neue leere DB initialisieren
rm ~/Cortex/Nexus/_memory/memory.db
cortex-agent bootstrap
# Vault + USER.md + golden-rules.md werden wieder gelesen.
# Historische Sessions sind weg — kein Disaster, weil Lessons in Schicht 1+4.
```

### Vorbeugung

`cortex-agent skill run sanitizer` nightly via Cron-Recipe. Macht VACUUM, archiviert alte Sessions, hält DB-Größe in Schach.

## Notfall 4 — Telegram-Bridge tot

### Symptom

- `/status` an `@sanexio_bot` bekommt keine Antwort.
- Bot empfängt deine Nachricht, aber Cortex schickt nichts zurück.
- (Bei Multi-Device: nur Cluster-Mini-02 antwortet — bekannt, siehe **[[10 Channel-Router]]**.)

### Diagnose

```bash
# 1. LaunchAgent läuft?
launchctl list | grep telegram

# 2. MCP-Bridge registriert?
claude mcp list | grep telegram-bridge

# 3. Token vorhanden?
[ -f ~/Cortex/Nexus/.env ] && grep -c TELEGRAM_BOT_TOKEN ~/Cortex/Nexus/.env || echo "MISSING"
# Erwartet: 1

# 4. Bridge-Logs
tail -30 ~/Cortex/Nexus/_memory/logs/telegram-bridge.log

# 5. API-Connectivity (manueller curl)
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/Cortex/Nexus/.env | cut -d= -f2)
curl -s "https://api.telegram.org/bot${TOKEN}/getMe" | jq
# Erwartet: {"ok":true, "result":{"username":"sanexio_bot",...}}
```

### Recovery

**Fall A: LaunchAgent unloaded**

```bash
launchctl load ~/Library/LaunchAgents/com.cortex.telegram-bridge.plist
launchctl list | grep telegram
```

**Fall B: Token abgelaufen / falsch**

Tier-3-Op (Token rotieren). Token via @BotFather erneut anfordern → `.env` aktualisieren (manueller Edit, ich darf das nicht direkt — Tier-3).

**Fall C: Multi-Device-Problem**

Memory-Notiz: `project_telegram_only_cluster_mini_02.md`. Aktuell wird der Bridge-Status nicht von allen Macs gepflegt. Workaround: für mobile Status-Abfragen nur Cluster-Mini-02 benutzen.

Fix-Sprint ausstehend; im Memory `project_telegram_only_cluster_mini_02.md` als offener Architektur-Punkt geführt.

## Notfall 5 — Tier-3 blockiert fälschlich

### Symptom

- Ich (Claude) sage „das ist Tier-3" für eine Operation, die nicht Tier-3 sein sollte.
- Oder umgekehrt: ein Tier-3-Trigger greift NICHT, obwohl er sollte.

### Diagnose

```bash
# 1. Was steht aktuell in tier3.md?
cat ~/Cortex/Nexus/agent/modes/tier3.md

# 2. Parser-Output?
cd ~/Cortex/Nexus && python3 -c "
from agent.memory.golden_rules import TIER_3_HARDSTOPS
print(TIER_3_HARDSTOPS)
"
# Erwartet: ['Zugangsberechtigungen / Secrets', 'Geld-Operationen', 'Externe Empfänger ohne User-Schleife']

# 3. AUTONOMY_CONTRACT konsistent?
grep -A 15 "R3 — Hochrisiko" _rules/AUTONOMY_CONTRACT.md
# Erwartet: Verweis auf tier3.md als Single Source.
```

### Recovery

**Fall A: tier3.md hat falsche Kategorie**

R2-Edit, manuell mit Freigabe:

```bash
# tier3.md editieren — Single Source. Änderung propagiert via Parser zu
# golden_rules.py.TIER_3_HARDSTOPS und zum injizierten System-Block.
$EDITOR ~/Cortex/Nexus/agent/modes/tier3.md
```

Nach Edit: nicht vergessen, dass der Hook erst beim nächsten Prompt neu liest.

**Fall B: Tier-3 wird im System-Prompt nicht injiziert**

Siehe Notfall 2 (Hook nicht aktiv).

**Fall C: User-Direktive blockiert ungewollt**

Siehe `_rules/user-directives.md`. Wenn pauschale Freigabe für eine Operation fehlt, die du eigentlich frei haben willst → Edit, R2.

## Notfall 6 — Mac komplett offline / abgestürzt

### Symptom

- Mac startet nicht oder ist physisch nicht erreichbar.
- Bei Mac-Studio: SSH via Tailscale antwortet nicht.

### Diagnose

```bash
# Tailscale-Status auf erreichbarem Mac
tailscale status
# Erwartet: jeder Mac mit "online" oder konkretem last-seen.

# Ping
tailscale ping <hostname>
```

### Recovery

**Fall A: Mac neu starten**

Physisch oder via Tailscale-SSH (`ssh ssmd@<host>` und `sudo shutdown -r now`).

**Fall B: Mac wirklich tot**

- **Sync-Stand auf dem toten Mac ist verloren**, sofern nichts gepusht wurde.
- Lessons in `~/.claude/projects/.../memory/` auf dem toten Mac sind verloren (siehe Cross-Device-Lücke in **[[05 Memory in 4 Schichten]]**).
- Cortex auf den anderen Macs läuft unbeeinträchtigt.

**Fall C: Tailscale-Login auf neuem Mac erneuern**

```bash
tailscale logout
tailscale login --hostname=$(scutil --get LocalHostName)
# Browser-Flow, einmaliger Auth-Code.
```

Danach: `tailscale ip` zeigt neue (oder dieselbe) IP, in `.config/devices.json` eintragen.

## Notfall 7 — Cortex-Komplett-Rollback

### Wenn du einen kompletten Reset brauchst (sehr selten)

Phoenix-Snapshot existiert als GitHub-Branch:

```bash
cd ~/Cortex/Nexus
git fetch origin pre-phoenix-reset-2026-05-08
git checkout pre-phoenix-reset-2026-05-08
# → Stand vom 2026-05-08, vor dem Architektur-Reset.

# Aufpassen: alle Architecture-Refactor-2026-05-Änderungen sind dann weg.
# Inkl. AC-Aufspaltung, Glossar, Public-Skeleton-Spec, golden-rules.md.
```

**Tier-3-Vorsicht:** Das ist ein destruktiver Sprung. Nur als allerletzte Option, wenn ein Refactor-Stand komplett unbrauchbar wäre.

Nach Rollback: `git checkout main` würde dich zurückbringen, aber lokale Änderungen wären weg. Vorher `git stash` oder Branch.

## Notfall 8 — Lease hängt expired-aktiv fest

### Symptom

- Codex / Cursor meldet: „Lease auf Scope X durch Claude blockiert, abgelaufen seit 2h".
- `doctor`-Skill meldet `0 expired active leases` nicht.

### Diagnose

```bash
sqlite3 ~/Cortex/Nexus/_memory/leases.db \
  "SELECT lease_id, agent, repo, scope, expires_at FROM leases WHERE released_at IS NULL;"
```

### Recovery

```bash
# Cleanup-Helper aus Connexio
cortex-agent skill run connexio --args '{"action":"cleanup_expired_leases"}'
# Oder direkt SQL:
sqlite3 ~/Cortex/Nexus/_memory/leases.db \
  "UPDATE leases SET released_at = datetime('now') WHERE released_at IS NULL AND expires_at < datetime('now');"
```

## Was du NIE ohne Backup tun solltest

| Operation | Warum gefährlich |
|---|---|
| `rm -rf ~/Cortex/` | Alle Werkprojekte + Nexus + Vault weg. Nur Git rettet die Repos, lokale gitignored Files weg. |
| `git push --force origin main` zur Phoenix-Reset-Branch | Würde den Backup-Branch überschreiben. |
| `launchctl unload` aller cortex-Plists | Kein Auto-Sync mehr, manueller Sync nötig. |
| `tailscale logout` ohne Login-Backup | Mac-zu-Mac-SSH weg bis re-login. |
| `~/.claude/settings.json` durch `>` überschreiben | Theme + Hooks + Plugins weg. Immer Edit-Tool oder vorheriges Backup. |
| `rm ~/.claude/state/cortex-mode.json` während Session | Auto-Re-Init bringt autonomy zurück, OK. Aber nicht mitten in einem `/safe-mode`-Workflow. |

## Doctor-Skill als zentraler Diagnose-Werkzeug

```bash
cortex-agent skill run doctor
# 10+-Punkte-Check: Mode, DB, Git, Policy, Drift, Runtime, Sync, Lease, Skills, Connexio.

cortex-agent skill run doctor --args '{"strict": true}'
# Wirft SystemExit(1) bei jeglichem Failure → für CI-Use.
```

Output-Beispiel:

```
# Doctor-Report

- [✓] **Mode-State-File** — mode=autonomy
- [✓] **Memory-DB** — 187392 bytes
- [✓] **USER.md** — /Users/ssmd/Cortex/Nexus/_memory/USER.md
- [✓] **Tutorials-Symlinks** — 14 Einträge
- [✓] **Second-Brain-Vault** — /Users/ssmd/Cortex/Nexus/Second Brain/30 Tutorials
- [✓] **Backup-Branch** — pre-phoenix-reset-2026-05-08
- [✗] **Git-Workspace** — 7 ungetrackte/modifizierte Pfade
- [✓] **Skills registriert** — 13 Skills
- [✓] **Policy-Set** — 19/19 Policy-Files vorhanden
- [✓] **Drift-Scan** — 4 Einstiegs-Files clean
- [✓] **Runtime-Größen** — logs=3 files (0.1 MB)
- [✓] **Sync (origin/main)** — in sync
- [✓] **Lease-Konsistenz** — 0 expired active leases

**Summary:** 12/13 OK (1 failed)
```

Der einzige typische Fail (Git-Workspace) ist OK, solange du gerade aktiv arbeitest. Nach `git commit && git push` sollte er grün werden.

## Aktueller Stand — was in der Recovery funktioniert

| Bereich | Recovery-Status |
|---|---|
| Sync-Recovery (Fall A–D) | ✅ Befehle dokumentiert und an realen Vorfällen erprobt. |
| Hook-Registration-Recovery | ✅ Snippet + Reload-Prozedur. |
| Memory-DB Wiederaufbau | ✅ Bootstrap-Pfad. |
| Telegram-Bridge | ⚠️ Multi-Device-Lücke offen. |
| Tier-3 Drift | ✅ Single Source via `agent/modes/tier3.md`. |
| Rechner komplett offline | ⚠️ Memory-Verlust ist real (Cross-Device-Sync-Lücke). |
| Phoenix-Komplett-Rollback | ✅ Backup-Branch existiert auf GitHub. |
| Lease-Cleanup | ✅ Sanitizer + manuelle SQL-Korrektur. |

## Was du mit diesem Modul jetzt kannst

- Du kannst Cortex-Probleme schichtweise triagieren.
- Du hast 8 konkrete Notfall-Szenarien mit Diagnose + Recovery.
- Du weißt, welche Operationen ohne Backup gefährlich sind.
- Du kannst den Doctor-Skill als ersten Anlaufpunkt nutzen.
- Du kennst den Phoenix-Komplett-Rollback-Pfad (selten nötig, aber gut zu wissen).

## Verwandte Tutorials

- **[[03 Autonomy und Safe Mode]]** — Hook-Registration und Mode-Mechanik (Notfall 2 prominent)
- **[[07 Multi-Device-Sync]]** — Sync-Mechanik (Notfall 1)
- **[[10 Channel-Router]]** — Telegram-Bridge (Notfall 4)
- **[[11 Hooks und Mode-Injection]]** — Hook-Details (Notfall 2)
- **[[13 Slash-Commands und CLI]]** — alle Befehle, die in diesem Modul vorkommen
- `agent/skills/INDEX.md` — Doctor, Sanitizer und andere Recovery-relevante Skills
- `HANDOVER_PHOENIX.md` §5 — Phoenix-Notfall-Rollback (Snapshot-Doku)
