---
title: Connexio
domain: cortex
modul: 08
level: fortgeschritten
status: kanonisch
---

# 08 — Connexio

> **Antwort in einem Satz:** Connexio ist die **read-only-Kontextfläche und Task-Bridge für Multi-AI-Kooperation** in Cortex — andere KIs (Codex, Cursor, Cline) lesen den Nexus-Kern ausschließlich über Connexio, schreiben dürfen sie nur in eng definierte Stores (Tasks, Reviews, Leases), und sensible Daten werden durch Tag-Filter geschützt.

In diesem Modul lernst du **was Connexio konkret ist**, **wie eine Codex-Übergabe abläuft**, und **wie Connexio im Sanexio-Public-Skeleton zur Plug-and-Play-Bridge wird**.

## Warum Connexio existiert

In Cortex laufen mehrere KIs parallel:
- **Claude** (= ich) hat Voll-Zugriff auf Nexus (R0–R2, R3 mit Freigabe).
- **Codex** (OpenAI) arbeitet auf Projekten unter `~/Cortex/projects/`.
- **Cursor / Cline / Gemini-CLI** sind weitere mögliche Editoren.

Wenn alle KIs direkt im Nexus-Kern schreiben dürften, gäbe es:
- **Race-Conditions** bei parallelen Edits.
- **Drift** zwischen Sichtweisen auf Regeln.
- **Compliance-Probleme** wenn eine externe KI Patient-Daten anfasst.

**Lösung:** Eine Vermittlungsschicht — **Connexio** — die definiert:
1. **Was darf gelesen werden?** (read-only, mit Tag-Filter für Sensibles)
2. **Was darf geschrieben werden?** (nur Tasks/Reviews/Leases via hardcoded API)
3. **Wer hat gerade die Sperre auf welchen Pfad?** (Lease-Mechanik)

## Die drei Komponenten von Connexio

```
                ┌──────────────────────────────────────┐
                │           CONNEXIO                    │
                │  (in agent/connexio/, Python)         │
                └──┬────────────────┬──────────────┬───┘
                   │                │              │
       ┌───────────▼────┐   ┌───────▼─────┐   ┌────▼─────────┐
       │  MCP-Server    │   │ HTTP-Server │   │   Kernel +   │
       │ (JSON-RPC)     │   │ (REST)      │   │   Stores     │
       │ stdin/stdout   │   │ localhost   │   │              │
       │                │   │ :7766       │   │  tasks.db    │
       │ Tools:         │   │             │   │  leases.db   │
       │ • get_user_… │   │ /healthz    │   │  audit.log   │
       │ • list_tasks   │   │ /context    │   │              │
       │ • handoff_…   │   │ /search     │   └──────────────┘
       │ • lease_…     │   │ /project/.. │
       └────────────────┘   └─────────────┘
              ▲                    ▲
              │                    │
     ┌────────┴───────┐    ┌───────┴──────────┐
     │ Codex, Cursor, │    │ Externe Tools,    │
     │ Cline (lokal)  │    │ Mobile Apps (Tail-│
     │                │    │ scale-Loopback)   │
     └────────────────┘    └──────────────────┘
```

### Komponente 1 — Kernel + Stores (`agent/connexio/kernel.py`)

**Was es ist:** die Python-Klasse, die alle Lese-/Schreib-Logik kapselt. Dahinter liegen zwei SQLite-Datenbanken:

- `_memory/tasks.db` — Task-State-Machine (proposed, accepted, in_progress, …) plus Mirror-JSON-Dateien.
- `_memory/leases.db` — Lease-Store mit TTL (Time-To-Live).

Zusätzlich:
- `_memory/audit/connexio-write.jsonl` — jeder Schreib-Zugriff loggt sich hier append-only.

**Schlüssel-Konstanten:**

- **`READABLE_ROOTS`** — Whitelist der Pfade, aus denen Connexio Read-Ops erlaubt. Heute u.a.: `_memory/USER.md`, `_memory/KNOWLEDGE.md`, `_memory/golden-rules.md`, `Second Brain/30 Tutorials/`, `~/Cortex/projects/*/SESSION_RESUME.md`.
- **`BLOCKED_FILE_PATTERNS`** — Regex-Liste blockierter Pfade. Z.B. `\.env`, `\.tar\.gz`, `id_rsa`, `\.claude\.json`, `telegram-bridge-state`, `spawn-queue\.db`, `connexio-audit`.
- **`BLOCKED_TAGS`** — bei FTS5-Searches werden Hits mit diesen Tags ausgefiltert: `medizin`, `patient`, `steuer`, `secret`, `auth`, `credential`.

### Komponente 2 — MCP-Server (`agent/connexio/mcp_server.py`)

**Was es ist:** Ein JSON-RPC-2.0-Server (Model Context Protocol = Anthropic-Standard für Tool-Brücken), der über stdin/stdout läuft. Andere KIs wie Codex registrieren ihn als MCP-Server und bekommen damit Cortex-spezifische Tools.

**Verfügbare Tools:**

| Tool | Zweck |
|---|---|
| `get_user_profile()` | Liefert `USER.md` als Markdown. |
| `list_projects()` | Alle Cortex-Projekte (aus `_projects/INDEX.md`). |
| `get_project(project_id)` | Projekt-Index + SESSION_RESUME. |
| `get_golden_rules()` | Liest `_memory/golden-rules.md`. |
| `search_patterns(query, project=None)` | FTS5-Suche mit `BLOCKED_TAGS`-Filter. |
| `get_recent_sessions(limit=10)` | Letzte Session-Summaries. |
| `get_tutorial(domain)` | Vault-Tutorials aus `Second Brain/30 Tutorials/`. |
| `handoff_to_agent(from, to, task_title, …)` | Direkte Übergabe einer Task an eine andere KI. |
| `inbox_for_agent(agent_id)` | Polling: offene Tasks für diese KI. |
| `lease_project(repo, scope, machine, agent, ttl_seconds)` | Lease anfordern (Default TTL: 3600s = 1h). |
| `release_lease(lease_id, agent)` | Lease freigeben. |
| `get_active_leases(repo=None, scope=None)` | Pre-Flight: andere KIs sehen aktive Locks. |

### Komponente 3 — HTTP-Server (`agent/connexio/http_server.py`)

**Was es ist:** Ein Loopback-only REST-Server auf `localhost:7766`. Auth via `X-Connexio-Key`-Header (Schlüssel aus env `CORTEX_CONNEXIO_KEY` oder `_memory/connexio.key`).

**Endpoints:**

| Pfad | Zweck |
|---|---|
| `GET /healthz` | Liveness-Check, kein Auth. |
| `GET /context?project=…` | Self-Onboarding-Block für externe KIs. |
| `GET /search?q=…&project=…` | Pattern-Suche mit BLOCKED_TAGS-Filter. |
| `GET /project/<id>` | Projekt-Details + Resume. |

**Loopback-only** heißt: nur über localhost erreichbar, nicht von außen via Netz. Über Tailscale-Mesh wäre eine cross-device-Variante denkbar, ist aber nicht aktiviert.

## Tasks — das Übergabe-Format

### State-Machine

```
proposed         → accepted | rejected
accepted         → in_progress | rejected
in_progress      → blocked | review_requested
blocked          → accepted | rejected
review_requested → approved | rejected
approved         → done
done             → (terminal)
rejected         → (terminal)
```

Detail: `_rules/tasks.md`.

### Pflichtfelder

Jede Multi-Agent-/R2-Task trägt:

- `id`, `title`, `created_by`, `assigned_to`
- `repo`, `scope`, `risk_level`
- `allowed_paths`, `forbidden_paths`, `claimed_paths`
- `base_commit`, `machine`
- `status`, `requires_human_approval`
- `acceptance_criteria`, `evidence`, `result`, `next_action`
- `updated_at`

### Persistenz — drei Schichten

Jede Task wird **dreifach** abgelegt:

1. **SQLite** (`_memory/tasks.db`) — lokal, schnelle Queries.
2. **JSON-Mirror** (`_memory/tasks-mirror/task-<id>.json`) — **gitversioniert**, damit Tasks auf allen Macs sichtbar sind nach `git pull`.
3. **Audit-Log** (`_memory/audit/connexio-write.jsonl`) — append-only, wer-wann-was.

Beispiel-Task (echtes File aus `_memory/tasks-mirror/`):

```json
{
  "id": "task-74331a710d43",
  "title": "Cortex Lean v3 L2 umsetzen",
  "created_by": "claude",
  "assigned_to": "codex",
  "repo": "Sanexio/nexus",
  "scope": "cortex-lean-v3-l2",
  "risk_level": "R2",
  "status": "done",
  "acceptance_criteria": [...],
  "allowed_paths": ["CLAUDE.md", "_rules/", "_memory/tasks-mirror/", "agent/connexio/"],
  "forbidden_paths": ["gateway/", "~/.codex/config.toml"],
  "claimed_paths": [...],
  "reviews": [
    {
      "id": "rev-eecb15d3f331",
      "reviewer": "codex",
      "verdict": "needs_human_approval",
      "notes": "..."
    },
    {
      "id": "rev-5779507455f7",
      "reviewer": "human",
      "verdict": "approved"
    }
  ],
  "evidence": { "handoff": "...", "spec": "..." }
}
```

## Leases — die Schreibsperre

### Was eine Lease ist

Eine **Lease** ist eine zeitlich begrenzte Schreibsperre auf eine Kombination aus `repo` und `scope`. Sie verhindert, dass zwei KIs gleichzeitig denselben Bereich bearbeiten.

### Schema

```python
{
  "lease_id": "lease-abc123",
  "repo": "Sanexio/nexus",
  "scope": "cortex-lean-v3-l2",
  "machine": "cluster-mini-02",
  "agent": "claude",
  "ttl_seconds": 3600,
  "acquired_at": "2026-05-13T05:30:00Z",
  "expires_at": "2026-05-13T06:30:00Z",
  "released_at": null   // null = aktiv
}
```

### API

```python
# Anfordern (in Python)
lease = lease_store.acquire_lease(
  repo="Sanexio/nexus",
  scope="cortex-lean-v3-l2",
  machine="cluster-mini-02",
  agent="claude",
  ttl_seconds=10800   # 3h
)

# Freigeben
lease_store.release_lease(lease.lease_id, agent="claude")

# Aktive prüfen
active = lease_store.get_active_leases(repo="Sanexio/nexus", scope="cortex-lean-v3-l2")
```

### TTL-Default

Standard: 1 Stunde. Bei längerer Arbeit (z.B. 3h-Refactor): explizit hochsetzen. Lease läuft nach `expires_at` automatisch ab — der `sanitizer`-Skill räumt expired-actives nightly auf.

### Konflikt-Verhalten

Wenn Lease bereits gehalten: `acquire_lease` schlägt fehl. Der anfragende Agent muss warten oder den Halter kontaktieren (Telegram, Outbox).

## End-to-End-Workflow — Claude übergibt eine Task an Codex

Konkretes Beispiel:

### Schritt 1: Pre-Flight (Claude auf Cluster-Mini-02)

```bash
cd ~/Cortex/Nexus && git pull --ff-only   # State-First
```

### Schritt 2: Lease anfordern

```python
import agent.connexio.lease_store as ls
lease = ls.acquire_lease(
  repo="Sanexio/nexus",
  scope="cortex-lean-v3-l2",
  machine="cluster-mini-02",
  agent="claude",
  ttl_seconds=10800
)
```

### Schritt 3: Task-Manifest schreiben

```python
import agent.connexio.task_store as ts

task = ts.create_task({
  "title": "Cortex Lean v3 L2 umsetzen",
  "created_by": "claude",
  "assigned_to": "codex",
  "repo": "Sanexio/nexus",
  "scope": "cortex-lean-v3-l2",
  "risk_level": "R2",
  "allowed_paths": ["CLAUDE.md", "_rules/", "_memory/tasks-mirror/"],
  "forbidden_paths": ["gateway/", "~/.codex/config.toml"],
  "acceptance_criteria": [
    "Connexio lease_project/release_lease/get_active_leases funktionieren lokal",
    "inbox_for_agent('codex') liefert diesen Task nach git pull",
    "Sanitizer strict archiviert mindestens einen TTL=0-Test-Memory-Eintrag"
  ],
  "evidence": {
    "handoff": "specs/cortex-lean-v3/HANDOFF-CODEX.md",
    "spec": "specs/cortex-lean-v3/00_KONZEPT.md"
  }
}, client_id="handoff:claude->codex")
# → schreibt task-74331a710d43.json + tasks.db + audit-log
```

### Schritt 4: Commit + Push (cross-device sichtbar)

```bash
git add _memory/tasks-mirror/task-74331a710d43.json
git commit -m "Handoff: cortex-lean-v3-l2 an Codex"
git push origin main
```

### Schritt 5: Codex liest Inbox (auf anderem Mac / anderer Session)

```bash
cd ~/Cortex/Nexus && git pull --ff-only
```

Dann via MCP-Tool:
```
inbox_for_agent("codex")
→ [{id: "task-74331a710d43", status: "proposed", …}]
```

### Schritt 6: Lease-Check (Codex)

```python
active = ls.get_active_leases(repo="Sanexio/nexus", scope="cortex-lean-v3-l2")
# Wenn Claude-Lease noch aktiv: STOP, warten oder Claude pingen.
# Wenn nicht: eigene Lease anfordern.

codex_lease = ls.acquire_lease(
  repo="Sanexio/nexus",
  scope="cortex-lean-v3-l2",
  machine="SSMD-MacBookPro-M5",
  agent="codex",
  ttl_seconds=10800
)
```

### Schritt 7: Codex arbeitet, aktualisiert Status

```python
ts.update_task_status("task-74331a710d43", "in_progress", note="Started on M5")
# … Arbeit …
ts.append_review("task-74331a710d43", reviewer="codex",
                 verdict="needs_human_approval", notes="Acceptance OK, Push offen")
ts.update_task_status("task-74331a710d43", "review_requested")
```

### Schritt 8: User-Freigabe + Done

Du reviewst, gibst Freigabe (`approved`). Codex:

```python
ts.append_review("task-74331a710d43", reviewer="human", verdict="approved")
ts.update_task_status("task-74331a710d43", "done")
ls.release_lease(codex_lease.lease_id, agent="codex")
```

Commit + Push der finalen JSON-Updates.

## Sicherheits-Schichten — was Connexio schützt

Drei Verteidigungs-Linien:

### Linie 1 — `READABLE_ROOTS`-Whitelist

Eine externe KI kann via Connexio NUR Pfade lesen, die explizit in `READABLE_ROOTS` aufgelistet sind. Beispiele was nicht drin ist:
- `_memory/USER.md` ist drin — aber gefiltert (siehe Linie 3).
- `agent/`, `gateway/`, `tools/`, `_rules/` sind NICHT drin → Codex kann sie nicht via Connexio lesen. Codex liest sie über sein lokales Git-Working-Tree (auf seinem Mac), wo sie über den Standard-Sync verfügbar sind.
- `.env`, `connexio-audit.log`, `*.tar.gz`, `id_rsa` sind NICHT drin → niemals.

### Linie 2 — `BLOCKED_FILE_PATTERNS`-Regex

Selbst wenn ein Pfad in `READABLE_ROOTS` läge: Regex blockt Secrets-Files (`\.env`, `\.claude\.json`, `id_rsa`, `id_ed25519`, `\.pem`, `\.key`, `\.tar\.gz`).

### Linie 3 — `BLOCKED_TAGS`-Filter bei Pattern-Suche

Wenn Codex `search_patterns("test")` aufruft und ein FTS5-Hit das Tag `#medizin` oder `#patient` hat → wird aus dem Ergebnis ausgefiltert. So sieht eine externe KI niemals Pattern, die als sensibel markiert sind.

Detail: `_rules/medical-domain.md` (Stracke-spezifisch) und `_rules/security.md`.

## AI-Cooperation-Outbox — der Markdown-Fallback

Vor Connexio gab es **Markdown-basierte Übergaben** in `~/Cortex/projects/_ai-cooperation-outbox/`. Format:

```
YYYY-MM-DD_<sender>-to-<receiver>_<topic>.md
```

**Status seit Lean v3:** Wird durch Connexio-`handoff_to_agent` ersetzt. Markdown-Outbox bleibt als **Read-Only-Archiv** bis 2026-06-12, danach Entscheidung zur Archivierung.

## Public-Skeleton-Perspektive (Sanexio-Geschäftsmodell)

Wenn andere Mediziner künftig Cortex installieren:

**Was öffentlich wird:**
- `agent/connexio/kernel.py` — generisch.
- `agent/connexio/mcp_server.py` — generisch.
- `agent/connexio/http_server.py` — generisch.
- `_rules/ai-cooperation.md`, `_rules/multi-ai-boundaries.md` — generisch.

**Was Stracke-only bleibt:**
- `BLOCKED_TAGS`-Liste mit `medizin`, `patient`, `steuer` (Public-Variante hat eigene Tags je nach Teilnehmer-Domain).
- Konkrete Task-Beispiele und Specs aus Stracke-Sprint.

**Was als Plug-and-Play-Lösung für weitere Rechner gedacht ist** — zentraler Wunsch an die Public-Variante:

- Pro Teilnehmer-Rechner: eigener Connexio-Key in `_memory/connexio.key`.
- Tailscale-Mesh für Inter-Rechner-Connexio über IPv4-Pinpoint-Routing.
- Onboarding-Skript, das den rechnerspezifischen `devices.json`-Eintrag plus Connexio-Setup erzeugt.

Detail: `specs/cortex-public-skeleton/00_KONZEPT.md`, Phase 3.

## Aktueller Stand — was läuft, was nicht

| Komponente | Status |
|---|---|
| Kernel + Stores (Tasks, Leases, Audit) | ✅ Aktiv. |
| MCP-Server | ✅ Implementiert. |
| HTTP-Server | ✅ Implementiert (lokal). |
| `get_golden_rules()` | ✅ Liest `_memory/golden-rules.md` (Pfad seit P1-Refactor korrekt). |
| Codex-Handoff-Workflow | ✅ Funktioniert (Beispiel: task-74331a710d43, done). |
| Lease-Mechanik | ✅ Implementiert, TTL-Cleanup via sanitizer. |
| BLOCKED_TAGS-Filter | ✅ Aktiv. |
| Cross-Device-Inbox-Polling | ⚠️ Funktioniert, aber Codex muss auf anderem Mac sein und `git pull` machen. |
| Connexio-Write-Surface über MCP | ⚠️ Geplant (`create_task`, `update_task_status`, `append_review`, `list_open_tasks`). Heute nur via Python-Imports. |
| Markdown-Outbox | ⏳ Deprecated bis 2026-06-12. |

## Was du mit diesem Modul jetzt kannst

- Du verstehst, dass Connexio die Brücke zwischen Cortex und externen KIs ist.
- Du kennst die drei Komponenten (Kernel, MCP-Server, HTTP-Server).
- Du verstehst das Task-Schema und die State-Machine.
- Du verstehst Leases (Schreibsperre mit TTL) und kannst aktive sehen.
- Du kennst die drei Sicherheits-Linien (READABLE_ROOTS, BLOCKED_FILE_PATTERNS, BLOCKED_TAGS).
- Du verstehst, wie Codex von Claude eine Aufgabe übernimmt (8-Schritte-Flow).
- Du kennst die Public-Skeleton-Perspektive für die Plug-and-Play-Erweiterung.

## Verwandte Tutorials

- **[[09 Self-Learning-Layer]]** — wie der Agent-Loop Connexio aufruft
- **[[02 Datei-Atlas]]** — Pfad-Übersicht aller Connexio-Files
- `_rules/ai-cooperation.md` — Claude × Codex Peer-Modell
- `_rules/multi-ai-boundaries.md` — andere KIs am Nexus-Kern
- `_rules/tasks.md` — Task-State-Machine + Pflichtfelder (kanonisch)
- `specs/claude-codex-cooperation/00_KONZEPT.md` — Architektur-Quelle
- `specs/cortex-lean-v3/00_KONZEPT.md` — Connexio-Erweiterungen
- `specs/cortex-public-skeleton/00_KONZEPT.md` — Plug-and-Play-Vision
