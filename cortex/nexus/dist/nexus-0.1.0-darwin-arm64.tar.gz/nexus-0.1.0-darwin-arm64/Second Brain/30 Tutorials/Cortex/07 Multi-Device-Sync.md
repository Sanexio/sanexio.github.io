---
title: Multi-Device-Sync
domain: cortex
modul: 07
level: fortgeschritten
status: kanonisch
---

# 07 — Multi-Device-Sync

> **Antwort in einem Satz:** Cortex synchronisiert sich zwischen deinen Macs **ausschließlich über GitHub** — ein LaunchAgent auf jedem Mac führt alle 5 Minuten das Skript `nexus-sync.sh` aus, das pullt, pusht und bei Drift alarmiert; in der Praxis funktioniert das im Normalbetrieb sauber, hat aber bekannte Schwachstellen bei Feature-Branches und persistentem Drift.

In diesem Modul lernst du **wie der Sync mechanisch läuft**, **warum manchmal Macs trotzdem hinterherhinken**, und **was du tun kannst wenn ein Mac stehengeblieben ist**.

## Das große Bild — Sync-Topologie

```
                         ┌────────────────────────────┐
                         │  GitHub  (Sanexio/nexus)   │
                         │  ← Single Source of Truth → │
                         └──┬──────┬──────┬──────┬────┘
                            │      │      │      │
                  pull/push │      │      │      │
                            │      │      │      │
         ┌──────────────────┼──────┼──────┼──────┴──────┐
         │                  │      │      │             │
    ┌────▼─────┐     ┌──────▼────┐ │  ┌───▼─────────┐ ┌─▼────────┐
    │  M5      │     │ Cluster-  │ │  │ SSMD-MBP    │ │ Mac-     │
    │ (mobile) │     │ Mini-02   │ │  │ (Intel,     │ │ Studio   │
    │          │     │ (home)    │ │  │  praxis)    │ │ (studio) │
    └──────────┘     └───────────┘ │  └─────────────┘ └──────────┘
                                   │
                            ┌──────▼──────┐
                            │ Cluster-    │
                            │ Mini-04     │
                            └─────────────┘

     Jeder Mac:
     • LaunchAgent com.cortex.nexus-sync alle 5 Min
     • beim Boot via RunAtLoad=true
     • führt nexus-sync.sh aus
     • aktualisiert .config/heartbeats/<host>.heartbeat
```

**Wichtige Festlegung:** Es gibt keinen Mac-zu-Mac-Sync. Alles geht über GitHub. Wenn GitHub down ist, gibt es keinen Sync. Tailscale-Mesh existiert zwar (für SSH zwischen Macs), wird aber für die normale Sync-Mechanik nicht genutzt.

## Komponente 1 — `nexus-sync.sh`

### Was es tut

Bash-Skript (`~/Cortex/Nexus/nexus-sync.sh`, ~600 Zeilen). Wird alle 5 Min aufgerufen. Sieben Phasen:

1. **Heartbeat schreiben** — `.config/heartbeats/<host>.heartbeat` mit aktuellem Timestamp.
2. **Heartbeat anderer Macs prüfen** — falls einer innerhalb der letzten 90 Sekunden aktiv war: Sync skippen (Race-Vermeidung).
3. **Branch-Check** — auf welchem Branch ist HEAD? Wenn `main`: weiter. Wenn Feature-Branch: **branch-aware FF** (versucht, `main` parallel weiterzuziehen, ohne den lokalen Branch zu wechseln).
4. **Drei-Punkte-Diff gegen `origin/main`** — wieviele Commits ahead, wieviele behind?
5. **Bei `behind > 0`** — `git pull --ff-only` versuchen. Auto-Resolve für auto-generierte Files (Dashboard, pending-questions, sync-drift).
6. **Auto-Commit-Whitelist** — bestimmte Pfade (Logs, Pending-Files, Dashboard, MOC-Files) werden automatisch committet und gepusht. Heartbeats laufen seit 2026-05-24 über separate Refs `refs/heartbeats/<host>`, nicht mehr über `main`-Commits (siehe Heartbeat-Mechanik unten).
7. **Alarm bei Divergenz** — wenn Pull mit Konflikt scheitert oder Drift persistent ist: Telegram-Push (heute nur von Cluster-Mini-02 funktional).

### Heartbeat-Mechanik im Detail

Heartbeat = der Unix-Timestamp der letzten Sync-Iteration eines Macs.

**Transport seit 2026-05-24: ephemere Refs statt main-Commits.** Vorher lag
`.config/heartbeats/<host>.heartbeat` in der Auto-Commit-Whitelist → jeder Lauf
jedes Macs erzeugte einen Commit auf `main` (~700/Tag, ≈100 % der Historie).
Jetzt besitzt jeder Mac den eigenen Ref `refs/heartbeats/<host>` und macht nur
darauf **force-update** (parentloser Commit, Timestamp = Commit-Message):

- **Schreiben:** `git commit-tree` (leerer Tree) + `git push --force origin <c>:refs/heartbeats/<host>`.
- **Lesen:** `git fetch '+refs/heartbeats/*:refs/heartbeats/*'`, dann `git log -1 --format=%s` je Ref.

Kein Multi-Writer-Konflikt (jeder Mac schreibt nur seinen Ref), kein
Historie-Wachstum (force-update, alte Objekte werden server-seitig GC't),
unsichtbar für `git log main`. Die lokalen `.config/heartbeats/<host>.heartbeat`
bleiben als **gitignored Lese-Cache** (Gateway/Doctor lesen sie unverändert) und
werden nach jedem Fetch neu materialisiert.

Wenn `M5` sieht: „Cluster-Mini-02 hat vor 23 Sekunden geschrieben" → Heartbeat-Skip auf M5, weil sonst Race auf demselben Branch.

### Auto-Commit-Whitelist

Aus `nexus-sync.sh`:

```
_memory/logs/*.log
_memory/logs/*.err
_memory/pending-questions.md
_memory/pending-instructions.md
_memory/health/sync-drift.json
Second Brain/00 Kontext/Dialog.md
Second Brain/10 Projekte/*.md
Second Brain/30 Tutorials/_MOC Tutorials.md
Second Brain/40 Regeln/_MOC Regeln.md
```

**Was bedeutet das in der Praxis?** Wenn du in Obsidian eine Projekt-Index-Datei (`Second Brain/10 Projekte/...`) änderst, wird sie beim nächsten Sync-Tick (5-Min-Takt) automatisch committet und gepusht — du musst nicht selbst `git commit` machen. Genauso für `_MOC Tutorials.md`.

**Was NICHT auto-committet wird:** alle anderen Tutorials, alle `_rules/*.md`, alle Code-Files, alle Specs. Die kommittest du manuell, oder ich für dich mit explizitem Auftrag.

### Branch-aware FF (Fix vom 2026-05-13)

**Vorfall M5 2026-05-13:** Ein Codex-PR wurde gemerged → die Branch `codex/local-first-discovery-k1-k5` auf GitHub gelöscht. M5 stand lokal noch auf diesem Branch (upstream gone). Der Sync-Skript-Lauf prüfte „Branch ≠ main → skip". 9 Stunden Drift, kein Alarm.

**Fix `de7a510`:** Auf einem Feature-Branch wird trotzdem versucht, `main` lokal zu aktualisieren (FF-Pull). Wenn das gelingt, ist `main` aktuell — der Feature-Branch wird nicht angetastet, aber wenn jemand auf `main` wechselt, ist er sofort aktuell.

## Komponente 2 — `com.cortex.nexus-sync.plist` (LaunchAgent)

### Was es tut

Datei in `~/Library/LaunchAgents/` (lokal pro Mac, nicht im Repo). Schlüssel:

```xml
<key>StartInterval</key>
<integer>300</integer>    <!-- alle 5 Min -->

<key>RunAtLoad</key>
<true/>                   <!-- bei Login starten -->

<key>ProgramArguments</key>
<array>
  <string>/bin/bash</string>
  <string>$HOME/Cortex/Nexus/nexus-sync.sh</string>
</array>
```

### Installation und Aktivierung

```bash
cp ~/Cortex/Nexus/com.cortex.nexus-sync.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.cortex.nexus-sync.plist
```

**Status prüfen:**

```bash
launchctl list | grep cortex
# Erwartete Ausgabe:
# <pid>  0  com.cortex.nexus-sync
# (oder "-" statt pid wenn gerade nicht laufend; "0" = letzter Exit-Code OK)
```

**Bei Reboot:** `RunAtLoad=true` sorgt dafür, dass der Sync direkt nach dem Boot läuft.

## Komponente 3 — `.config/devices.json`

### Was es ist

**Single Source of Truth für die Geräte-Registry.** Pro Mac:

```json
"SSMD-MacBookPro-M5": {
  "hostname": "SSMD-MacBookPro-M5",
  "arch": "arm64",
  "chip": "Apple M5 Pro",
  "role": "praxis-mobile",
  "platform": "macos",
  "projects": [
    {"name": "Nexus", "path": "~/Cortex/Nexus", "primary": true},
    {"name": "Cortex-Web", "path": "...", ...}
  ],
  "network": {
    "mesh_name": "macbookpro-silicon",
    "mesh_ip_v4": "100.93.193.44",
    "tailscale_tags": ["tag:cortex-admin", "tag:cortex-host-mac"],
    "ssh_method": "tailscale-ssh",
    "status": "online",
    "last_seen": "2026-05-15T..."
  }
}
```

### Wer schreibt?

- **`scripts/onboard-device.sh`** — beim Aufnehmen eines neuen Mac.
- **Du** manuell, wenn etwas ändert (IP-Migration, neuer Mac, Role-Wechsel).
- **Niemals automatisch von der KI** (R2-Schutz).

### Wer liest?

- `nexus-sync.sh` für Heartbeat-Pfad-Resolution.
- `doctor`-Skill für Geräte-Health-Check.
- Connexio für Multi-Device-Operations.
- Du, beim Diagnostizieren.

## Komponente 4 — Telegram-Alarm bei Drift

### Heutiger Stand

Wenn der Sync persistent fehlschlägt (z.B. Konflikt nicht auflösbar), sendet `nexus-sync.sh` einen Telegram-Push via Bridge.

**Bekannte Lücke (Spec `sync-alarm-escalation`, Stub):**
- Der Alarm wird einmal gesendet, dann hörte er auf.
- Wenn der Drift 9 Stunden lang anhält, gab es nach dem ersten Alarm Funkstille.

Der Spec sieht **Re-Alarm-Eskalation** vor: nach 30 Min ohne Auflösung → erneuter Alarm mit Priorität „kritisch". Implementierung ausstehend.

### Multi-Device-Telegram-Status

Heute sendet nur **Cluster-Mini-02** zuverlässig via Telegram. Andere Macs haben die Bridge installiert (siehe `tools/telegram-bridge/`), aber senden keine Status-/Alarm-Meldungen.

**Diagnose pro Mac** (Memory: `project_telegram_only_cluster_mini_02.md`):

```bash
launchctl list | grep telegram    # LaunchAgent aktiv?
claude mcp list | grep telegram-bridge   # MCP-Server registriert?
echo "${TELEGRAM_BOT_TOKEN:0:8}…"  # Token vorhanden?
```

Fix-Plan: separate Bug-Welle nach Tutorial-Rewrite.

## Drift-Recovery — was tun wenn ein Mac stehengeblieben ist

### Szenario 1: Mac hinkt 2 Tage hinter origin/main

**Diagnose:**
```bash
cd ~/Cortex/Nexus
git fetch origin
git status -uno
git rev-list --left-right --count HEAD...origin/main
```

Ausgabe `0	N` bedeutet: 0 ahead, N behind. Wenn N > 0:

**Recovery (im Normalfall):**
```bash
git pull --ff-only
```

Wenn das mit „divergiert" scheitert:
```bash
git log --oneline -10           # was sind die lokalen Commits?
git log origin/main --oneline -10  # was ist im Remote?
```

Wenn die lokalen Commits redundant sind (z.B. Auto-Sync-Commits, die durch einen PR-Squash-Merge obsolet wurden):

```bash
git stash push -u -m "safety-stash"
git checkout main
git pull --ff-only
git stash drop   # falls Inhalt verifiziert OK
```

Genau das war der M5-Recovery-Flow am 2026-05-15.

### Szenario 2: Mac auf totem Feature-Branch

```bash
git branch -a
# Wenn lokaler Branch existiert, Remote nicht mehr → upstream gone

git checkout main
git pull --ff-only
git branch -D <toter-branch>     # optional aufräumen
```

### Szenario 3: Konflikt im Auto-Resolve

Wenn `nexus-sync.sh` einen Konflikt hatte und Auto-Resolve nicht griff:

```bash
tail -30 _memory/logs/nexus-sync.log
# Zeigt: ALARM-Stelle, betroffene Files

git status               # welche Files konfligieren?
# manuelle Auflösung, dann:
git add <files>
git commit
git push
```

### Szenario 4: LaunchAgent läuft nicht

```bash
launchctl list | grep cortex
# Leer? → LaunchAgent unloaded.

launchctl load ~/Library/LaunchAgents/com.cortex.nexus-sync.plist
launchctl list | grep cortex     # erneut prüfen

# Log prüfen:
tail -20 ~/Cortex/Nexus/_memory/logs/nexus-sync.log
```

## Approval-Marker (`_memory/approvals/.enforce`)

Optionale strenge Schicht. Wenn die Datei `.enforce` existiert:

- Pushes mit Outgoing-Diff in R2-Pfaden (`_rules/`, `specs/`, `CLAUDE.md`, `SYSTEM_MAP.md`, `agent/`, `gateway/`, `tools/`, `nexus-sync.sh`) werden **blockiert**, wenn kein Approval-Marker `_memory/approvals/<task-id>.approved` für die Task existiert.

Default-Modus ist **weich**: warnt im Sync-Log, blockiert aber nicht. `.enforce` aktivierst du nur in Phasen erhöhter Vorsicht (z.B. vor einer kritischen Demo).

## Was im Vault automatisch mitkommt vs. nicht

Wichtig zu verstehen wegen der Tutorial-Edits:

| Pfad-Pattern | Auto-Commit? | Konsequenz |
|---|---|---|
| `Second Brain/10 Projekte/*.md` | Ja | Projekt-Index-Edits sind sofort auf allen Macs. |
| `Second Brain/30 Tutorials/_MOC Tutorials.md` | Ja | MOC-Edits sofort sichtbar. |
| `Second Brain/30 Tutorials/Cortex/*.md` | **Nein** | Tutorial-Inhalte musst du oder ich manuell committen. |
| `_rules/*.md` | **Nein** | Regel-Änderungen sind R2 — Sync-Skript fasst sie nicht an. |
| `agent/skills/builtin/*.py` | **Nein** | Code-Änderungen niemals auto. |

**Begründung:** Auto-Commit darf nur „Datenpunkte" (Heartbeats, Logs, generierte Status-Files) und sehr leichtgewichtige Strukturdateien (MOC) betreffen. Inhaltliche Änderungen brauchen manuellen Commit, damit die Commit-Message Sinn ergibt und Reviews möglich sind.

## Aktueller Stand — was läuft, was nicht

| Komponente | Status |
|---|---|
| `nexus-sync.sh` Standardfluss | ✅ Stabil. Branch-aware FF (Fix de7a510). Persistente Divergenz-Alarme (Fix 9706daa). |
| LaunchAgent auf M5, Cluster-Mini-02 | ✅ Aktiv. |
| LaunchAgent auf Mac-Studio, SSMD-MBP | ⚠️ Status unbekannt (Diagnose ausstehend). |
| Telegram-Alarm | ⚠️ Nur Cluster-Mini-02 sendet. |
| Re-Alarm-Eskalation | ⛔ Stub (`specs/sync-alarm-escalation/`). |
| Approval-Marker (`.enforce`) | ✅ Implementiert, default-aus. |
| Heartbeat-Race-Avoidance | ✅ Aktiv (90-Sek-Schwelle). |

## Was du mit diesem Modul jetzt kannst

- Du verstehst, dass Sync ausschließlich über GitHub läuft (kein Mac-zu-Mac).
- Du kennst die sieben Phasen von `nexus-sync.sh`.
- Du weißt, was in der Auto-Commit-Whitelist steht (und was nicht).
- Du kannst LaunchAgent-Status prüfen und neu laden.
- Du hast Recovery-Befehle für die vier häufigsten Drift-Szenarien.
- Du weißt um den M5-Vorfall 2026-05-13 und die Branch-aware-FF-Korrektur.
- Du verstehst, warum Multi-Device-Telegram heute eingeschränkt ist.

## Verwandte Tutorials

- **[[02 Datei-Atlas]]** — Pfad-Übersicht aller Sync-relevanten Files
- **[[14 Notfall und Recovery]]** — erweiterte Recovery-Szenarien
- `_rules/sync-policy.md` — kanonisches Runtime-Aggregat aller Sync-Regeln
- `specs/nexus-sync-reliability/00_KONZEPT.md` — Architektur der Reliability-Maßnahmen
- `specs/sync-alarm-escalation/00_KONZEPT.md` — Stub für Re-Alarm-Logik
- `specs/multi-device-multi-ai/00_KONZEPT.md` §4 — Multi-Device-Sync-Architektur
