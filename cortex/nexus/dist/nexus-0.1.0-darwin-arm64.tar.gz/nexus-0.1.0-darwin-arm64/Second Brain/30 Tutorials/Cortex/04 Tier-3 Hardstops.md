---
title: Tier-3 Hardstops
domain: cortex
modul: 04
level: einsteiger
status: kanonisch
---

# 04 — Tier-3 Hardstops

> **Antwort in einem Satz:** Tier-3 ist eine **kleine, scharf umrissene Liste von Operationen**, bei denen Claude (und jede andere KI im Cortex) **immer stoppen und auf deine ausdrückliche Freigabe warten muss** — unabhängig vom Modus, unabhängig vom Kontext.

## Was bedeutet „Tier"?

„Tier" (englisch für „Stufe" oder „Ebene") ist hier eine **Risiko-Klassifikation für Operationen**. Im Cortex/Nexus-Vertrag gibt es vier Stufen:

| Stufe | Was | Beispiel |
|---|---|---|
| **R0** | Read-only. Frei. | Datei lesen, `git status` |
| **R1** | Cortex-Projektarbeit. Frei innerhalb der Projekt-Repos. | Datei in `~/Cortex/projects/<projekt>/` schreiben, Tests ausführen |
| **R2** | Nexus-Kern. Nur mit Freigabe schreibbar. | Datei in `~/Cortex/Nexus/` ändern, Regeln updaten |
| **R3** | Hochrisiko. **Immer Stop**, Freigabe pflicht. | Secrets schreiben, Geld bewegen, Mail an Patient |

**Tier-3 = R3.** Die zwei Begriffe meinen dasselbe; die Detailliste der R3-Operationen heißt aus historischen Gründen „Tier-3-Hardstops" und liegt in `agent/modes/tier3.md`.

Detail zu R0–R3: `_rules/risk-levels.md`. Glossar mit allen Begriffen: `_rules/glossary.md`.

## Warum Tier-3 existiert

Es gibt Operationen, deren Schaden bei Fehlauslösung so groß ist, dass kein „Sorry, war doch nur" hilft:
- Ein Secret leakt → es ist im Git-Log → es ist ungewissermaßen bei dritten Parteien.
- Eine Mail geht an einen Patienten raus → DSGVO-Vorfall.
- Eine fehlerhafte Banking-Buchung läuft → Geld weg.
- Eine fremde GitHub-Org bekommt ungewollten Push → Reputationsschaden.

Diese **drei Kategorien** (Secrets, Geld, externe Empfänger) sind die drei Schutzzonen, die durch Tier-3 abgesichert sind. Innerhalb dieser Zonen ist die Schwelle: **immer Stop, immer Freigabe, immer Bestätigung im Debrief.**

## Die drei Kategorien

### 1. Zugangsberechtigungen / Secrets

Hardstop bei:

- `.env`-Files und alle Varianten (`.env.local`, `.env.production`, …) **schreiben** oder **neu anlegen**.
- `~/.claude.json` schreiben (MCP-Registrierung, Auth-Tokens).
- API-Keys, Bot-Tokens, Passwörter **committen** oder **loggen**.
- SSH-/GPG-Keys generieren oder rotieren.
- macOS-Keychain-Einträge ändern.
- Beliebige Dateien, die das Wort „secret", „token", „password", „credentials" im Namen tragen — schreiben.

**Lesen** dieser Dateien ist nicht Tier-3 (R0 = read-only ist immer erlaubt). Der Hardstop greift nur beim **Schreiben**, **Committen** oder **Anzeigen-im-Plaintext**.

#### Was sind .env-Files?

Eine `.env`-Datei ist eine textuelle Konfigurationsdatei, die **umgebungsspezifische Variablen** speichert — typischerweise:

```
ANTHROPIC_API_KEY=sk-ant-...
TELEGRAM_BOT_TOKEN=12345:abc...
DATABASE_PASSWORD=geheim123
SHOPIFY_ADMIN_TOKEN=shpat_...
```

Der Punkt am Anfang macht sie unsichtbar in normalen `ls`-Aufrufen (zeigt sich erst mit `ls -a`). Sie werden per Konvention von `.gitignore` ausgeschlossen — das heißt, **sie wandern niemals in Git**, weil sie sonst über das Remote-Repository auf GitHub für jeden Lese-Berechtigten sichtbar wären.

#### Was ist `.gitignore` — und welche verwandten Dateien gehören dazu?

`.gitignore` ist eine reine Textdatei im Wurzelverzeichnis eines Git-Repositories. Jede Zeile beschreibt ein Muster (Glob), das Git beim Indexieren ignoriert: betroffene Dateien werden nicht zum Staging-Bereich hinzugefügt, nicht committet und nicht gepusht. Typische Einträge in einem Cortex-Projekt:

```gitignore
.env
.env.*
!.env.example
node_modules/
*.log
.DS_Store
__pycache__/
_memory/memory.db
```

`!` invertiert ein Muster (eine `.env.example` darf trotzdem ins Repository, weil sie keine echten Secrets enthält). Die Reihenfolge der Regeln folgt dem üblichen Glob-Vorrang.

Im Umfeld von Git und GitHub gehören drei weitere Konventionsdateien dazu, die häufig zusammen mit `.gitignore` betrachtet werden:

| Datei | Aufgabe |
|---|---|
| **`.gitattributes`** | Datei-spezifische Attribute (Zeilenenden, Diff-Treiber, Binary-Markierung, Linguist-Sprache). Wichtig, wenn ein Repository plattformübergreifend gepflegt wird. |
| **`.env.example`** | Eingecheckte Vorlage mit denselben Schlüsseln wie `.env`, aber leeren oder Dummy-Werten. Dokumentiert, welche Variablen ein Projekt erwartet, ohne Secrets preiszugeben. |
| **`CODEOWNERS`** | GitHub-Konvention: Pfad-zu-Person-Mapping, das automatische Review-Anfragen bei Pull-Requests auslöst. |

Innerhalb von Cortex sind alle drei Konventionsdateien im Einsatz: `.gitignore` schließt Memory-Datenbanken und Secrets aus, `.gitattributes` normalisiert Zeilenenden zwischen den Rechnern, `.env.example` liegt für jedes Projekt mit externen Diensten bei.

**Warum sind `.env`-Files so kritisch?** Sie bündeln in einer einzigen Datei Tokens für mehrere Dienste. Ein einziger Leak kompromittiert mehrere Systeme gleichzeitig. Die klassische Schwachstelle: jemand committet `.env` versehentlich, pusht, und das Secret liegt auf GitHub. Auch ein späteres Force-Push entfernt den Stand nicht aus den GitHub-Caches und -Logs. Deshalb gilt: **lieber überhaupt nicht erst in den Index gelangen lassen.**

**Cortex-Praxis:** Lesen ist erlaubt (z. B. `os.environ['ANTHROPIC_API_KEY']` in Python). Schreiben oder Anzeigen im Klartext fällt unter Tier-3.

### 2. Geld-Operationen

Hardstop bei:

- Schreib-Ops in Accounting-Systeme (SmartQ, Buchhaltung, Steuern, Banking).
- PDF-Rechnungs-Versand an Patienten oder Kunden.
- Preisänderungen in Live-Shops (z.B. Shopify Live-Store).
- Direkte Banking-API-Aufrufe.

**Lesen** von Konten-Stand, Rechnungs-Templates etc. ist nicht Tier-3.

### 3. Externe Empfänger ohne User-Schleife

Hardstop bei:

- E-Mail / SMS / Slack-Versand an **andere Personen als dich** (Dr. Stracke).
- Patientenmails, Patient-Datenexport.
- GitHub-Issue-Close / PR-Merge in **fremden** Repos (deine eigenen Repos sind frei).
- Webhooks an dritte Parteien.

**Senden an den eigenen Telegram-Channel** ist explizit **nicht** Tier-3 — das ist sogar gewollt (Welle-Ende-Push, Status-Updates).

## Was NICHT mehr Tier-3 ist (pauschal freigegeben)

User-Direktive 2026-05-09: **alles innerhalb `~/Cortex/` ist frei**, solange es nicht in eine der drei Tier-3-Kategorien fällt. Diese Direktive engt den früheren breiteren Tier-3-Scope auf die drei oben genannten Kategorien ein.

Konkret **NICHT** Tier-3:

- **Git-Ops auf eigenen Repos** — `git push`, `git push --force`, `git reset --hard`, `git rebase`, `git branch -D`. Alle frei für eigene Repos. Bei fremden Repos: bleibt Tier-3 (Kategorie 3, „externer Empfänger").
- **Live-Deploys eigener Projekte** — praxis-webseite ins Production-WP, Juvantis-Shopify-Deploy, GitHub-Pages, Docker-Container.
- **WP-Admin-Schreibops auf eigenen Production-Domains** — Plugin-Konfig, Theme-Edits, Settings.
- **Figma-Edits** in deinen Files.
- **Google-Drive-Ops** (Lösch/Move/Rename) auf deinen eigenen Files.
- **Telegram-Senden an deinen User-Channel.**
- **Sub-Agent-Delegation** (z.B. an Codex via Connexio-Handoff).
- **WebFetch, WebSearch, lokale Skripte ausführen.**

**Die Idee:** *Alles, was schiefgehen kann, kannst du mit Git rückgängig machen oder ist trivial reproduzierbar. Tier-3 schützt nur das, was wirklich irreversibel ist (Secrets-Leak, Geld weg, externer Empfänger).*

Vollständige Liste „was nicht mehr Tier-3 ist" + die Stracke-spezifischen Pauschal-Freigaben: `_rules/user-directives.md`.

## Was passiert bei einem Tier-3-Trigger

Der Verlauf ist immer derselbe, in vier Schritten:

1. **Tool-Call wird NICHT ausgelöst.** Die KI hält an, bevor sie die Operation ausführt.
2. **Sie informiert dich:** was geplant war, warum es Tier-3 ist, eine etwaige Alternative.
3. **Sie wartet auf dein explizites Go** — „push", „delete", „send", „yes", „okay". Ein vages „mach mal" reicht nicht; die Bestätigung muss eindeutig zur konkreten Tier-3-Operation passen.
4. **Nach Freigabe** wird die Operation ausgeführt und im Welle-Ende-Debrief **erwähnt** („Tier-3-Op freigegeben: …").

Beispiel-Verlauf:

> *Du:* „Schreib einen Cronjob, der nachts die neuen Patientenakten als PDF an Frau X mailt."
> *Ich:* „Das ist Tier-3 (externer Empfänger + Patientendaten). Ich kann den Cron-Job vorbereiten und das Mail-Template schreiben, aber das `sendmail`-Tool ruf ich nicht ohne deine explizite Freigabe auf. Alternative: ich schreibe das Skript so dass es nur ein PDF im `~/Downloads/` ablegt und dir den Pfad meldet — dann verschickst du es manuell. Wie willst du?"

## Wie die KI „weiß" was Tier-3 ist

Der **gleiche Hook**, der die Modes injiziert (`tools/cortex-mode/bin/inject.sh`), injiziert IMMER auch `agent/modes/tier3.md` — egal ob du gerade im Autonomy- oder Safe-Modus bist. Das ist der zentrale Mechanismus.

### Was ist ein Hook?

Ein **Hook** ist ein Skript, das automatisch bei einem bestimmten Ereignis ausgeführt wird. Im Claude-Code-Kontext gibt es mehrere Hook-Events (PreToolUse, PostToolUse, UserPromptSubmit, …). Cortex nutzt den `UserPromptSubmit`-Hook: bei jeder von dir abgesendeten Nachricht läuft das Skript `inject.sh`, das den Mode-Block + Tier-3-Block als zusätzlichen Kontext oben an deinen Prompt klebt.

**Zur Hook-Registration siehe [[03 Autonomy und Safe Mode]]** — der Hook muss in `~/.claude/settings.json` eingetragen sein, sonst wird er nie aufgerufen.

Wenn du wissen willst, was wörtlich im Tier-3-Block steht:
```bash
cat ~/Cortex/Nexus/agent/modes/tier3.md
```

Die Datei ist menschlich lesbar, etwa 500 Tokens lang, und legt die drei Kategorien plus die explizite „nicht mehr Tier-3"-Liste fest. Sie ist die **Single Source** für den Tier-3-Block — sowohl der Hook als auch das Python-Modul `agent/memory/golden_rules.py` (Renderer für den System-Prompt-Block) lesen aus dieser einen Datei.

### Wo der Tier-3-Block in der KI-Antwort landet — kurze Verortung

Der Tier-3-Block ist Teil des `additionalContext`, den der UserPromptSubmit-Hook bei jedem abgesendeten Prompt oben in den Modell-Request einfügt. Das Modell liest ihn als verbindlichen Bestandteil des System-Auftrags und hält die Tier-3-Regel ein, weil sie dort steht.

Eine vollständige Beschreibung des Mechanismus — Tool-Loop, Pre- und Post-Hooks, Skill-Aufrufe, Permission-System sowie die Cortex-spezifischen Aufsätze — liefert **[[16 Harness — Wie Claude arbeitet]]**. Die technische Anatomie des `inject.sh`-Hooks im Detail steht in **[[11 Hooks und Mode-Injection]]**.

## Warum die Liste so klein ist

Ältere Versionen des Vertrags hatten 8+ Tier-3-Kategorien (inkl. Git-Push, Live-Deploy, Sub-Agents). Das führte zu **Reibung ohne Mehrwert**: ständige Rückfragen für Operationen, die du sowieso wolltest und die trivial reversibel sind.

Die aktuelle Form (drei Kategorien) ist eine bewusste Entscheidung — **wenig, aber scharf**. Tier-3 soll selten zuschlagen, dann aber zuverlässig. Wenn Claude bei jedem Git-Push fragen würde, würdest du den Tier-3-Trigger irgendwann ignorieren („yes, yes, yes, …") — und genau dann würde der echte gefährliche Trigger nicht mehr greifen. Sicherheits-Design 101: **weniger Alarme, mehr Wirkung pro Alarm.**

## Sonderfall: Tier-3 ausnahmsweise vorab freigeben

Es gibt seltene Fälle, wo du eine Tier-3-Operation **vorab freigeben** möchtest (z.B. „du darfst über Nacht E-Mails an Patientin Y schicken, das ist abgesprochen"). Dafür gibt es:

- **Approval-Marker:** Lege eine Datei `_memory/approvals/<task-id>.approved` an. Bei einer laufenden Task mit dieser ID wird die Tier-3-Schwelle für deren Scope vorab als freigegeben behandelt.
- **`_memory/approvals/.enforce`:** Diese leere Datei aktiviert den **harten** Approval-Modus für R2-Schreibops — kein Push ohne Approval-Marker. Standardmäßig ist die Logik weich (warnt, blockiert nicht).

Diese Mechaniken sind selten genutzt; der Normalfall ist die ad-hoc-Bestätigung im Chat.

## Was du mit diesem Modul jetzt kannst

- Du kennst die drei Tier-3-Kategorien: **Secrets, Geld, externe Empfänger.**
- Du weißt, was eine `.env`-Datei ist und warum sie kritisch ist.
- Du weißt, was ein Hook ist und wie der Tier-3-Block in jeden Prompt fließt.
- Du weißt, dass Git-Ops, Live-Deploys, Telegram-Senden an dich selbst, Sub-Agent-Delegation **nicht (mehr)** Tier-3 sind.
- Du weißt, dass Tier-3 mode-unabhängig hard blockiert und vom selben Hook injiziert wird wie der Mode-Block.
- Du verstehst, dass die Liste klein gehalten ist, damit jeder Tier-3-Alarm Gewicht hat.

## Verwandte Tutorials

- **[[03 Autonomy und Safe Mode]]** — die mode-abhängige Schicht
- **[[11 Hooks und Mode-Injection]]** — der technische Mechanismus im Detail
- **[[15 Erweitern und Sichern]]** — wenn Tier-3 erweitert werden soll (z. B. neue Compliance-Anforderungen)
