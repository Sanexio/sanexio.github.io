---
title: Selbstlernendes System
domain: cortex
modul: 06
level: fortgeschritten
status: kanonisch
---

# 06 — Selbstlernendes System

> **Antwort in einem Satz:** Cortex hat die Infrastruktur für ein selbstlernendes System — Lesson-Capture, Persistenz-Anker, Welle-Ende-Audit, Pattern-Mining — aber **operativ ist erst ein Teil aktiv**: explizit aufgerufene Lessons werden persistiert, automatische Muster-Erkennung aus Sessions läuft noch nicht produktiv.

In diesem Modul lernst du **was heute schon funktioniert**, **was noch Konzept ist**, und **wo die konkreten Hebel zum Aktivieren liegen**.

## Ehrliche Bestandsaufnahme

| Komponente | Status |
|---|---|
| **Lesson-Capture-Skill** (`capture-lesson`) | ✅ Aktiv. Schreibt Lessons als Memory-File. |
| **Lesson-Audit-Hook** (`lesson_audit.py`) | ✅ Aktiv. Emittiert Persistenz-Audit beim Welle-Ende. |
| **Persistenz-Anker** im Welle-Ende-Debrief | ✅ Aktiv (in autonomy.md/safe.md gefordert, in lesson-anchors.md spezifiziert). |
| **Pattern-Miner** (`pattern-miner`-Skill) | ⚠️ Experimentell. Nicht im Standardflow. |
| **Skill-Ketten** (`agent/workflows/*.yaml`) | ⛔ Nicht angelegt. Skills sind heute isoliert. |
| **Automatisches Recall im System-Prompt** | ⚠️ Heuristisch (Keyword-Match in FTS5-DB), nicht semantisch. |
| **Cross-Device-Lesson-Sync** | ⛔ Pro Mac lokal. Lessons auf M5 sind nicht automatisch auf Mac-Studio. |
| **Wiederholungsfehler-Patterns GF-001..007** | ✅ In `golden-rules.md`, vom System-Prompt-Renderer injiziert. |

**Fazit:** Die Architektur steht. Die Aktivierungs-Wellen für Automatisierung und Cross-Device-Sync laufen noch.

## Die Idee: Was „selbstlernend" bedeuten soll

In jeder Session passiert eines von zweien:
1. Etwas klappt gut → eine Beobachtung darüber wird festgehalten („dieser User mag explizite Pfad-Angaben").
2. Etwas schiefgeht → ein Fehler-Pattern wird festgehalten („Bei OCR Skew-Korrektur vorgeschaltet, sonst leere Outputs").

Diese Beobachtungen wandern in den **richtigen Persistenz-Träger** (Memory-File, Spec, CLAUDE.md, Hook-Code), damit die nächste Session davon profitiert. Das ist der Kern.

Was Cortex **nicht** ist: ein neuronales Netz, das beim Reden mit dir Gewichte anpasst. Cortex „lernt" durch **strukturelle Persistenz** — gespeicherte Markdown-Files, Code-Änderungen, Spec-Einträge. Das ist langsamer als Training, aber deterministischer und nachvollziehbar.

## Komponente 1 — Der `capture-lesson`-Skill

### Was er tut

Schreibt eine Lesson als Markdown-File mit Frontmatter in `~/.claude/projects/<slug>/memory/<type>_<slug>.md` und aktualisiert den `MEMORY.md`-Index. Detail in `agent/skills/builtin/capture_lesson.py` (287 Zeilen).

### Aufruf

```bash
cortex-agent skill run capture-lesson --args '{
  "kind": "feedback",
  "slug": "multi_ai_connexio_diagnose",
  "title": "Bei Codex-schlaeft-Diagnose Branches + Mirror pruefen",
  "description": "Diagnose-Reihenfolge bei Connexio-Handoffs",
  "rule": "Audit-Log auf main reicht nicht — Status-Updates können auf Codex-Branches liegen",
  "why": "Am 2026-05-13 zweimal als schlaeft diagnostiziert obwohl Codex auf Branch geliefert hatte",
  "how_to_apply": "git branch -r | grep agent, gh pr list, git show <branch>:tasks-mirror/<id>.json"
}'
```

### Vier Typen

| Typ | Wozu | Beispiel |
|---|---|---|
| `feedback` | Stil-Lessons (was Claude lernen soll) | „Fachbegriffe inline erklären" |
| `project` | Projekt-Stand / strategische Vorhaben | „Sanexio-Public-Skeleton geplant" |
| `reference` | Pointer zu externen Quellen | „Anthropic-Doku für Skills: …" |
| `user` | Profil-Ergänzungen | „User-Telefon: …" |

### Was er pflegt

- **Validierung vor Schreib-Op** (Pflichtfelder, snake-case-slug).
- **MEMORY.md-Index** automatisch aktualisiert.
- **Audit-Log** (`_memory/audit/capture-lesson.jsonl`) — wer hat wann was geschrieben.
- **Diff-Rendering** bei Update einer existierenden Lesson.
- **Noop** wenn Inhalt identisch.

## Komponente 2 — Der Lesson-Audit-Hook

### Was er tut

Wenn dein Prompt eine **Welle-Ende-Phrase** enthält („Session beenden", „debrief", „Phoenix fortsetzen", „was gelernt", „fertig für heute"), emittiert `tools/cortex-mode/bin/lesson_audit.py` einen Audit-Block, der im injizierten Kontext sichtbar wird.

### Format des Audit-Blocks

```
## Session Persistenz-Audit
- Session-Start: 2026-05-16T08:00:00Z
- Neue Memory-Lessons seit Session-Start: 2 (capture_lesson_*.md, …)
- Neue/geänderte Specs: 1 (architecture-refactor-2026-05)
- CLAUDE.md-Edits: 1 (Pflicht-Lesung erweitert)
- Skill/Hook/Mode-Erweiterungen: 0
- Pending im Welle-Ende-Debrief: jeder WAS GELERNT-Bullet braucht
  am Zeilen-Ende einen Persistenz-Anker.
- Autonomy-Mode: warnen und Anker-Check im Debrief sichtbar rendern.
```

### Wirkung pro Mode

| Mode | Verhalten bei fehlendem Anker |
|---|---|
| Autonomy | Warnen (Audit-Block sichtbar), nicht blockierend. |
| Safe | Blockierend — Welle-Ende nicht abschließbar ohne Anker. |

### Implementierungs-Logik

- Vergleicht `git log --since=<session_start>` für Nexus-Edits.
- Scannt `~/.claude/projects/*/memory/` per mtime nach neuen Memory-Files seit Session-Start.
- Grouped Spec-Edits, CLAUDE.md-Edits, Skill/Hook/Mode-Edits.
- Liest aktuellen Mode aus `~/.claude/state/cortex-mode.json`.

## Komponente 3 — Persistenz-Anker

### Die Regel

Jeder Bullet im Welle-Ende-Block **WAS GELERNT** braucht am Zeilen-Ende einen **Anker**, der zeigt wo die Lesson abgesichert wurde. Spezifiziert in `_rules/lesson-anchors.md`.

### Fünf erlaubte Anker

| Anker | Bedeutung |
|---|---|
| `-> feedback_<slug>.md` | Lesson als Memory-Eintrag geschrieben (via capture-lesson). |
| `-> specs/<slug>/` | Lesson in einer Spec verankert. |
| `-> CLAUDE.md` | Lesson als Regel in einer CLAUDE.md eingearbeitet. |
| `-> hook:<name>` | Lesson strukturell in einem Hook/Skill abgesichert (z.B. `hook:lesson_audit`). |
| `(ephemer)` | Bewusst nur Session-Kontext, kein persistenter Träger. |

### Warum so wichtig?

Ohne Anker ist eine Lesson **in der Session verloren**. „Heute habe ich gelernt, dass X" ohne Persistenz-Eintrag → bei der nächsten Session keine Spur. Genau dieser Verlust ist das Motiv für die ganze Architektur (Spec: `specs/lesson-persistence/00_KONZEPT.md`, Vorfall-Anlass 2026-05-13).

### Beispiel — guter Welle-Ende-Debrief

```
## WAS GEMACHT
- Hook-Bug auf M5 diagnostiziert, Hook in settings.json registriert.
- Memory feedback_check_hook_registration.md angelegt.
- Tutorial-Set 00–04 nach Anwender-Annotationen überarbeitet (6 Files, +566/-462).
- Commits 226e3174 → main → GitHub.

## WAS GELERNT
- Häufigste Bug-Klasse mit hohem Frust-Potenzial: „installiert aber nicht
  registriert" — primär bei Hooks. -> feedback_check_hook_registration.md
- Vor dem Schreiben „X funktioniert" lieber kurz prüfen, ob X auf diesem
  Rechner tatsächlich aktiv ist. -> feedback_no_aspirational_claims.md (vorhanden)
```

## Komponente 4 — Der `pattern-miner`-Skill (experimentell)

### Was er **soll**

Sessions aus der FTS5-DB lesen, mit LLM-Hilfe wiederkehrende Muster extrahieren und als `pattern`-Einträge persistieren.

### Was er **heute kann**

Heuristisch nach Session-Markern suchen. Optionaler Anthropic-API-Call für Pattern-Naming. Output ist Markdown, kein automatisches In-Memory-Schreiben.

### Warum nicht produktiv

Zwei Lücken:
1. **Keine semantische Ähnlichkeit** — der Miner findet nur Keyword-Matches, kein „diese drei Sessions handeln alle vom selben Bug".
2. **Kein Auto-Trigger** — der Miner läuft nur, wenn du `cortex-agent skill run pattern-miner` aufrufst. Er ist nicht in Skill-Ketten eingebunden.

Aktivierungs-Plan: siehe Optimierungshebel unten.

## Komponente 5 — Skill-Ketten (Workflows) — geplant

### Konzept

Wiederkehrende Skill-Sequenzen sollen als YAML-Workflows in `agent/workflows/*.yaml` strukturiert werden. Beispiele aus dem Skill-INDEX:

```yaml
# agent/workflows/welle-ende.yaml (Stub)
name: welle-ende
trigger: ["session beenden", "debrief", "phoenix fortsetzen"]
steps:
  - skill: capture-lesson    # für jeden ungeanker'ten Bullet
    if: pending_lessons > 0
  - skill: doctor
    args: { strict: false }
  - skill: session-end
```

### Stand heute

Nicht implementiert. Die Skill-Engine (`agent/skills/engine.py`) kennt keine Workflow-Definitionen. Skills werden einzeln aufgerufen.

### Aktivierungs-Plan

Audit-Empfehlung in `specs/architecture-refactor-2026-05/00_AUDIT.md` §E: YAML-Loader in `engine.py`, plus drei initiale Workflows (welle-ende, session-start, nightly).

## Konkrete Optimierungs-Hebel

Die zentrale Frage lautet: *Ist der Self-Learning-Layer aktiv, und wie wird er messbar besser?* Die folgenden sechs Hebel sind die priorisierten Stellen, an denen die Maschinerie heute vom strukturellen Zustand in einen tatsächlich lernenden Betrieb überführt wird.

### Hebel 1 — Auto-Capture am Welle-Ende

Heute manuell: ich rufe `capture-lesson` explizit auf, wenn ich einen Anker für ein WAS-GELERNT-Bullet brauche. Besser: **session-end-Skill triggert capture-lesson automatisch** für jeden Bullet ohne Anker — mit User-Bestätigung. Aufwand: ~50 Zeilen Python in `session_end.py`.

### Hebel 2 — Cross-Device-Memory-Sync

Heute lokal: Lesson auf M5 ist auf Cluster-Mini-02 unsichtbar. Optionen:

1. **Symlink-Ansatz:** `~/.claude/projects/-Users-ssmd-Cortex/memory/` → `Nexus/_memory/claude-projects/`. Vault-versioniert, jeder Mac liest dieselbe Datei. **Risiko:** der Pfad ist Mac-spezifisch (Hostname/User-Path); funktioniert nur wenn alle Macs dieselbe Username/Cortex-Pfad-Konvention haben.
2. **Periodischer Sync-Job:** Skript kopiert Memory-Files in den Nexus-Vault, committet sie. **Vorteil:** entkoppelt vom Symlink-Risiko. **Nachteil:** Latenz (5-Min-Sync).
3. **Centralized Memory-DB:** ein leader-Mac hält die Memory-DB, andere lesen via Connexio. **Vorteil:** instant. **Nachteil:** Online-Abhängigkeit.

Empfehlung (Audit): Variante 2 für den Anfang, evaluieren ob Variante 1 zusätzlich machbar ist.

### Hebel 3 — Semantischer Recall

Statt Keyword-Match → Embedding-basierte Ähnlichkeitssuche. Anthropic stellt keine Embedding-API; Alternativen: OpenAI text-embedding-3, lokal via Ollama (sentence-transformers). Speicherung als zusätzliche FTS5-Tabelle plus Vektor-Index (sqlite-vss).

Aktivierungs-Plan: Spec `specs/memory-semantic-recall/` (noch nicht angelegt).

### Hebel 4 — Pattern-Miner produktiv schalten

Wenn Hebel 1+3 stehen: Auto-Trigger des `pattern-miner` als nightly-Cron-Job. Output: erkannte Patterns → FTS5-`patterns`-Tabelle → werden via semantischen Recall in System-Block injiziert.

### Hebel 5 — Skill-Ketten

YAML-Loader in `engine.py` + drei initiale Workflows (welle-ende, session-start, nightly). Aufwand: ~150 Zeilen Python.

### Hebel 6 — Bug-Pattern-Check

GF-001..007 sind heute als Markdown in `_memory/golden-rules.md`. Pre-Tool-Use-Hook könnte vor risikoreichen Operationen (OCR, WP-CLI, Pre-Pull) gezielt warnen, wenn ein bekanntes Bug-Pattern droht. Erfordert: Trigger-Annotationen pro GF-Eintrag + neuer Hook.

## Wer was schreibt — die Verantwortungs-Matrix

| Schreib-Op | Wer |
|---|---|
| Vault-Inhalt (`Second Brain/`) | Du, oder ich nach expliziter Aufforderung. |
| `_memory/USER.md`, `KNOWLEDGE.md` | Du, oder ich nach expliziter Aufforderung. |
| `_memory/golden-rules.md` | Ich, wenn neue Goldene Regel destilliert wird. |
| `memory.db` (Sessions) | Agent-Loop automatisch am Welle-Ende. |
| `memory.db` (Skill-Runs) | Skill-Engine automatisch. |
| `memory.db` (Patterns) | `pattern-miner` (heute manuell, geplant automatisch). |
| `memory.db` (User-Facts) | `curator add-fact` oder via CLI. |
| `~/.claude/projects/<slug>/memory/*.md` | Ich via `capture-lesson` oder Write-Tool. |

## Was du mit diesem Modul jetzt kannst

- Du weißt, dass „selbstlernend" hier strukturelle Persistenz heißt, nicht neuronale Gewichts-Anpassung.
- Du verstehst die 5 Komponenten: capture-lesson, lesson-audit, anchors, pattern-miner, workflows.
- Du weißt, was heute funktioniert (Capture + Audit + Anker) und was Stub ist (Miner + Workflows + Cross-Device).
- Du kennst die 6 konkreten Optimierungs-Hebel und kannst sie priorisieren.
- Du kannst beim nächsten Welle-Ende-Debrief die Anker-Regel anwenden und siehst, ob ich sie einhalte.

## Verwandte Tutorials

- **[[05 Memory in 4 Schichten]]** — wo Lessons physisch landen
- **[[11 Hooks und Mode-Injection]]** — wie das Lesson-Audit-Skript triggert
- **[[15 Erweitern und Sichern]]** — die Optimierungs-Hebel als konkrete Wellen-Vorschläge
- `_rules/lesson-anchors.md` — die kanonische Anker-Spezifikation
- `agent/skills/INDEX.md` — alle Skills inkl. capture-lesson, session-end, pattern-miner
- `specs/lesson-persistence/00_KONZEPT.md` — die ursprüngliche Architektur-Entscheidung
