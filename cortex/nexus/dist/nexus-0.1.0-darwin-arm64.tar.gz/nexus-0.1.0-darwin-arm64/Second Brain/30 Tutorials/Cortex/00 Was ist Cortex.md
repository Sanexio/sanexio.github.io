---
title: Was ist Cortex
domain: cortex
modul: 00
level: einsteiger
status: kanonisch
---

# 00 — Was ist Cortex

> **Antwort in einem Satz:** Cortex ist eine persönliche, KI-gesteuerte Arbeitsumgebung, die auf beliebigen Rechnern im Verbund läuft — und zugleich die Grundlage eines dezentralisierten Werkzeugs, das Sanexio anderen Behandlern, normalen Anwendern und Patienten in einer abgespeckten Variante zur Verfügung stellt.

Wenn aus diesem Modul nur eine Sache hängenbleibt, dann diese: **Cortex ist kein einzelnes Programm, sondern ein zusammenwirkender Stapel aus vier Komponenten, der erst im Verbund Bedeutung gewinnt** — und gleichzeitig ein Geschäftsmodell, das in zwei Spielarten angeboten wird.

## Strategischer Rahmen — die zwei Spielarten

Cortex existiert parallel in zwei Varianten, die sich in Inhalt und Schreibrechten unterscheiden:

| Variante | Wer betreibt es | Was enthalten ist |
|---|---|---|
| **Private-Cortex** | Dr. Stracke auf seinen Rechnern | Voll-Funktionalität, Patient-Domäne, Praxis-Regeln, vollständiger Wissens-Vault |
| **Public-Cortex** | andere Behandler, Anwender, Patienten — alle, die Sanexio einlädt | Schlanke Skeleton-Version mit Kern-Mechanik, Teilnehmer ergänzen den eigenen Anwender-Layer |

Teilnehmer laden Cortex und eine generische Nexus-Variante von einem öffentlichen Sanexio-Repository herunter und betreiben sie lokal auf ihrem eigenen Rechner mit eigenen Credentials. Die Kern-Architektur (Nexus) bleibt unter alleiniger Kontrolle von Sanexio; Teilnehmer-Installationen kommunizieren nicht mit dem Privat-Nexus, sondern sind eigenständig.

Die Architektur ist so geschnitten, dass etwa 80 Prozent des Kerns ohne Anpassung übernommen werden können. Privates liegt in klar identifizierten Files (`_memory/USER.md`, `_rules/medical-domain.md`, `.config/devices.json`, `Second Brain/`). Detail: **[[15 Erweitern und Sichern]]** und `specs/cortex-public-skeleton/`.

## Die vier Bestandteile

```
~/Cortex/                              ← der Container auf jedem Rechner
│
├── Nexus/                             ← Steuerwerk: Regeln, Agent, Memory, Sync
│   ├── _rules/                            (was darf der Agent, was nicht)
│   ├── _memory/                           (was hat das System gelernt)
│   ├── agent/                             (Python-Code: Self-Learning-Layer)
│   ├── gateway/                           (TypeScript-Code: Channel-Router)
│   ├── Second Brain/                      (Obsidian-Wissensbasis)
│   ├── skills/                            (Claude-Code-Skill-Pakete)
│   └── …
│
├── projects/                          ← Werkstatt: hier wird gearbeitet
│   ├── Cortex-Web/                        (z. B. praxis-webseite)
│   ├── _ai-cooperation-outbox/            (Übergaben an andere KIs)
│   └── …
│
└── .codex/, .claude/                  ← lokale KI-Konfigurationen (pro Rechner)
```

| Begriff | Was es ist | Beispiel |
|---|---|---|
| **Cortex** | Das gesamte System auf einem Rechner. Oberbegriff. | „Mein Cortex" / „auf jedem Rechner läuft Cortex". |
| **Nexus** | Das Steuerwerk **innerhalb** Cortex. Regeln, Agent-Code, Memory-Datenbank (SQLite mit Volltextsuche), Vault, Synchronisations-Skripte. Ein Git-Repository (`Sanexio/nexus` auf GitHub). | „Nexus ist auf diesem Rechner zwei Tage hinter origin/main." |
| **Projects** | Die Werkstatt **neben** Nexus. Pro Werkprojekt ein eigenes Verzeichnis, in der Regel ein eigenes Git-Repository. | praxis-webseite, Cortex-Web, ein Shopify-Store, eine iOS-App. |
| **Second Brain** | Obsidian-Wissensbasis innerhalb Nexus (`Nexus/Second Brain/`). Tutorials, Regeln, Sessions, Glossar. | Diese Datei. |

**Kurzformel:** Cortex = Nexus + Projects + Second Brain (+ lokale Konfigurationen). Wer „aktualisier den Cortex" sagt, meint fast immer Nexus. Wer „dieses Projekt" sagt, meint einen Ordner unterhalb `~/Cortex/projects/`.

## Was Cortex leistet, das ein einzelner Rechner nicht leistet

### 1. Selbsttätige Synchronisation zwischen Rechnern

Jeder Rechner im Verbund führt einen LaunchAgent (`com.cortex.nexus-sync`) aus, der alle fünf Minuten das Skript `nexus-sync.sh` startet. Das Skript ruft `git pull --ff-only` und gegebenenfalls `git push` für Nexus auf, pflegt einen Heartbeat-Marker und alarmiert bei Drift. So bleibt jeder eingeschaltete Rechner ohne manuelles Zutun aktuell. Die Sync-Mechanik nutzt GitHub als zentrale Drehscheibe; es findet kein direkter Rechner-zu-Rechner-Austausch statt. Detail: **[[07 Multi-Device-Sync]]**.

### 2. Strukturelle Gedächtnis-Schichten

Lessons, Profile, Patterns und Vault-Wissen liegen in vier physisch getrennten Persistenz-Schichten — manuell gepflegter Obsidian-Vault, narrative Nexus-Memory-Files, SQLite-FTS5-Datenbank für Sessions und Patterns, plus per-Projekt-Memory in `~/.claude/projects/<projekt>/memory/`. Jede Schicht hat eine eigene Sync-Strategie (gitversioniert oder pro Rechner lokal). Detail: **[[05 Memory in 4 Schichten]]** und **[[06 Selbstlernendes System]]**.

Der **Self-Learning-Layer** ist ein priorisiertes Architektur-Thema. Ziel ist eine substanzielle automatische Pattern-Extraktion in jeder Session, sodass das System aus dem laufenden Betrieb messbar lernt. Heute funktioniert die strukturelle Lesson-Persistenz; die automatische Mining-Schicht ist im Aufbau (`pattern-miner`-Skill, experimentell).

### 3. Verbindliches Regelwerk

Nicht jeder Befehl wird ausgeführt. **Tier-3-Hardstops** halten KI-Operationen bei drei Kategorien an: Zugangsberechtigungen und Secrets, Geld-Operationen, externe Empfänger außerhalb des direkten Stracke-Kanals. Innerhalb von `~/Cortex/` sind die übrigen Operationen pauschal freigegeben. Die Regeln liegen unter `_rules/` als schlanke Familie fokussierter Files: ein kompakter Index (`AUTONOMY_CONTRACT.md`) verweist auf spezialisierte Detail-Files (`risk-levels.md`, `modes.md`, `stop-conditions.md`, `tasks.md`, …). Detail: **[[03 Autonomy und Safe Mode]]** und **[[04 Tier-3 Hardstops]]**.

### 4. Koordination mehrerer KIs (Connexio)

Claude arbeitet nicht isoliert. Codex, Cursor, Cline und Gemini-CLI können parallel auf demselben Rechner laufen. Damit sie sich nicht gegenseitig überschreiben, vermittelt ein eigener Layer namens **Connexio** — eine Read-only-Schnittstelle über HTTP und MCP plus ein gitversionierter Task-Mirror für saubere Übergaben. Tag-Filter blockieren sensible Inhalte (Patient, Steuer, Secret) für externe KIs. Detail: **[[08 Connexio]]**.

### 5. Zwei Mobile-Pfade — Info-Terminal und Project-Work

Mobile-Zugriff auf das laufende System läuft über zwei parallele Pfade mit klarer Rollenteilung:

| Pfad | Zweck | Werkzeug |
|---|---|---|
| **Info-Terminal** | Mesh-Status, Geräte-Übersicht, Permission-Approvals, Tier-3-Notifications | Telegram-Bot `@sanexio_bot` mit Befehlen `/status`, `/devices`, `/status <name>`, `/verdict <id> yes/no` |
| **Project-Work** | Live-Mirror laufender Sessions, mobile Steuerung, Multi-Rechner-Koordination, ad-hoc Spawns | `claude remote-control` mit Browser-Zugriff über `claude.ai/code` oder QR-Code zur Claude-App |

Telegram ist über die native App auf jedem Endgerät erreichbar; Remote-Control benötigt einen Anthropic-Account mit Subscription, dafür bietet es Live-Stream der laufenden Antworten. Detail zur Bedienung: **[[10 Channel-Router]]** und **[[12 Externe Dienste]]**.

## Wer macht was

| Rolle | Aufgabe |
|---|---|
| **Anwender (Dr. Stracke / Public-Teilnehmer)** | Aufträge formulieren über Terminal, Chat in Claude Code, Telegram-Befehle oder die Claude-App. Entscheidet bei Tier-3-Hardstops. Pflegt den Vault mit Lessons und Notizen. |
| **Claude** | Liest Regeln, prüft Status, führt Aufgaben aus, dokumentiert Lessons, schreibt in Projekte und nach Freigabe in Nexus. |
| **Codex, Cursor und andere KIs** | Bekommt Aufgaben über die Connexio-Bridge, schreibt ausschließlich in Projekte (nie in den Nexus-Kern), liefert über Git-Pull-Requests. |
| **`nexus-sync.sh`** | LaunchAgent-Skript, läuft alle fünf Minuten auf jedem Rechner. Pullt, pusht, alarmiert bei Drift. |
| **`inject.sh` (Hook)** | Bei jedem Prompt-Submit injiziert er den aktiven Modus und die Tier-3-Regeln in den Kontext. Setzt voraus, dass die Hook-Registration in `~/.claude/settings.json` erfolgt ist — siehe **[[11 Hooks und Mode-Injection]]**. |
| **Skills** (z. B. `doctor`, `capture-lesson`) | Werkzeuge innerhalb von Nexus, aufrufbar via `cortex-agent skill run <name>`. Liegen in `agent/skills/builtin/` und sind durch den Git-Sync auf jedem Rechner verfügbar. |

## Was du nach diesem Modul mitnimmst

- Cortex ist der Oberbegriff, Nexus das Steuerwerk, Projects die Werkstatt, Second Brain die Wissensbasis.
- Cortex existiert privat und öffentlich, mit klarer Trennlinie für Schreibrechte am Kern.
- Synchronisation, Gedächtnis, Regelwerk, Multi-AI-Koordination und Mobile-Zugriff (Info-Terminal + Remote-Control) sind die fünf Hauptfunktionen.
- Tier-3 ist die einzige Klasse von Operationen, bei der die KI immer anhält und auf Freigabe wartet.

## Verwandte Tutorials

- **[[01 Architektur und Schichten]]** — wie die Schichten zusammenspielen
- **[[02 Datei-Atlas]]** — jede Datei mit Rolle und Bedeutung
- **[[03 Autonomy und Safe Mode]]** — die zwei Modi und ihre Stops
- **[[10 Channel-Router]]** — Info-Terminal und Project-Work im Detail
- **[[15 Erweitern und Sichern]]** — Public-Skeleton und Härtungs-Pfade

## Glossar-Spickzettel (Detail in `_rules/glossary.md` und **[[99 Glossar]]**)

- **Cortex** = Container auf einem Rechner (`~/Cortex/`).
- **Nexus** = Steuerwerk in Cortex.
- **Projects** = Werkstatt (jedes Werkprojekt als eigener Ordner).
- **Second Brain** = Obsidian-Wissens-Vault innerhalb Nexus.
- **LaunchAgent** = macOS-Mechanismus für Hintergrund-Skripte.
- **Hook** = Skript, das automatisch bei einem Ereignis läuft (hier: bei jedem Prompt-Submit).
- **Tier-3** = Hardstop-Kategorie für Operationen, die immer Freigabe erfordern.
- **MCP** = Model Context Protocol; Standard für Tool-Brücken zwischen LLM und externen Diensten.
- **FTS5** = Full-Text-Search v5, SQLite-Volltextsuche.
- **Remote-Control** = Claude-Code-Funktion, die laufende Sessions zu `claude.ai/code` spiegelt.
