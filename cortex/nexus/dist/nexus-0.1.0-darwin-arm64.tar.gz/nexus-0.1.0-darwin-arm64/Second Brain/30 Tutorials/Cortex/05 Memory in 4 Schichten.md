---
title: Memory in 4 Schichten
domain: cortex
modul: 05
level: fortgeschritten
status: kanonisch
---

# 05 — Memory in 4 Schichten

> **Antwort in einem Satz:** Cortex speichert „Erinnerungen" in **vier physisch getrennten Schichten** — Obsidian-Vault (manuelles Wissen), Nexus-Memory-Files (Profil + Index), SQLite-FTS5-Datenbank (Volltext-Suche), Claude-Code-Memory (Per-Projekt-Lessons) — jede mit eigenem Zweck und eigener Sync-Strategie.

In diesem Modul lernst du **welche Schicht für was ist**, **warum sie getrennt sind** und **wo deine Lessons tatsächlich landen**.

## Überblick — die vier Schichten auf einen Blick

```
┌──────────────────────────────────────────────────────────────────┐
│  SCHICHT 1: VAULT — manuell gepflegtes Wissen                    │
│  Second Brain/  (Obsidian, gitversioniert)                       │
│  → Tutorials, Regeln, Fehlerprotokolle, Session-Notizen          │
│  → identisch auf allen Macs (via Git-Sync)                       │
│  → KI liest, schreibt fast nie selbst                            │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  SCHICHT 2: NEXUS-MEMORY — narrative Steuer-Files                │
│  _memory/USER.md, KNOWLEDGE.md, golden-rules.md                  │
│  → User-Profil, Vault-Pointer-Index, destillierte Regeln          │
│  → identisch auf allen Macs (via Git-Sync)                       │
│  → KI liest beim Session-Init                                    │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  SCHICHT 3: FTS5-DATENBANK — Volltextsuche                       │
│  _memory/memory.db  (SQLite, gitignored)                         │
│  → Sessions, Patterns, Skill-Runs, User-Facts                    │
│  → PRO MAC LOKAL (Index, lässt sich neu aufbauen)                │
│  → KI liest via "cortex-agent memory search", schreibt automatisch│
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  SCHICHT 4: CLAUDE-MEMORY — Per-Projekt-Lessons                  │
│  ~/.claude/projects/<projekt-slug>/memory/*.md                   │
│  → feedback_*.md, project_*.md, reference_*.md, user_*.md         │
│  → PRO MAC UND PRO PROJEKT LOKAL                                 │
│  → KI schreibt via capture-lesson Skill, liest am Session-Start  │
└──────────────────────────────────────────────────────────────────┘
```

## Schicht 1 — Vault (`Second Brain/`)

### Was es ist

Der **Obsidian-Vault** ist deine manuell gepflegte Wissensbasis. Format: Markdown-Dateien mit Frontmatter und Wikilinks (`[[Ziel]]`). Liegt **innerhalb** Nexus (`Nexus/Second Brain/`), damit er mit dem Git-Sync mitläuft.

### Struktur

```
Second Brain/
├── 00 Kontext       ← Dialog mit Claude (Dialog.md, …)
├── 10 Projekte      ← pro Projekt eine Index-Datei
├── 15 Workflows     ← bewährte Abläufe
├── 30 Tutorials     ← Wissensbasis nach Domäne (DIESES Tutorial liegt hier)
├── 40 Regeln        ← Praxis-Regeln (R-001 …)
├── 50 Fehler        ← Fehlerprotokolle (F-001 …, GF-001 …)
├── 60 Tools         ← Notizen zu eingesetzten Werkzeugen
├── 70 Glossar       ← Begriffsdefinitionen
├── 80 Templates     ← Obsidian-Templates
└── 90 Sessions      ← Session-Notizen, Lessons-Learned
```

### Wer schreibt?

- **Primär du** (Dr. Stracke) — in Obsidian beim manuellen Pflegen.
- **Sekundär die KI** — nur über explizit aufgerufene Skills (`tutorial-curator`, `capture-lesson` schreibt aber NICHT hier, sondern in Schicht 4).

### Schutzregel

Der Vault wird vom **Sanitizer-Skill nie gelöscht oder umgeschrieben** (siehe `_rules/retention.md`). Single-Source-of-Truth für Domänen-Wissen.

### Sync-Verhalten

Vollständig gitversioniert. Beim nächsten `git pull` hat der andere Mac den identischen Stand. Auto-Commit-Whitelist (siehe `_rules/sync-policy.md`) committet automatisch: `Second Brain/00 Kontext/Dialog.md`, `Second Brain/10 Projekte/*.md`, `Second Brain/30 Tutorials/_MOC Tutorials.md`, `Second Brain/40 Regeln/_MOC Regeln.md`. Alle anderen Vault-Änderungen committest du manuell.

## Schicht 2 — Nexus-Memory (`_memory/*.md`)

### Was es ist

Drei narrative Steuer-Files, die nach dem Architektur-Refactor bewusst schlank gehalten sind:

| Datei | Rolle | Größe |
|---|---|---|
| `_memory/USER.md` | Dein Profil: Rolle, Arbeits-Präferenzen, Domänen-Kontext | ~30 Zeilen |
| `_memory/KNOWLEDGE.md` | Pointer-Index zum Vault: welche Tutorial-Domain wo | ~40 Zeilen |
| `_memory/golden-rules.md` | Destillierte Goldene Regeln + Wiederholungsfehler-Patterns | ~100 Zeilen |

Vorher waren USER.md überbläht mit Geräte-Tabelle + Sicherheits-Block + Medical-Domain. Diese Inhalte sind jetzt in `_rules/` ausgegliedert (Stracke-Layer, im Public-Skeleton austauschbar).

### Wer schreibt?

Manuell, durch dich oder durch mich nach expliziter Aufforderung. **Keine** automatischen Schreibvorgänge — diese Files sind Read-Only aus der Agent-Loop-Perspektive.

### Sync-Verhalten

Gitversioniert. Auf allen Macs identisch.

## Schicht 3 — FTS5-Datenbank (`_memory/memory.db`)

### Was es ist

**SQLite-Datenbank** mit aktivierter Full-Text-Search v5. SQLite ist eine eingebettete Datenbank (eine einzige Datei, kein Server), FTS5 ist deren Volltextsuche-Engine.

### Schema (vier Tabellen)

| Tabelle | Inhalt |
|---|---|
| `sessions` | Zusammenfassungen abgeschlossener Sessions (project, summary, full_text). Volltext-indexiert. |
| `patterns` | Wiederkehrende Muster aus Sessions (name, slug, body, tags). Volltext-indexiert. |
| `skill_runs` | Jeder Skill-Aufruf wird hier protokolliert (skill, args, result, ok, timestamp). |
| `user_facts` | Strukturierte Fakten (kind, key, value). Z.B. „contact phone +49 1234". |

### Wer schreibt?

- **Agent-Loop** (`agent/loop.py`) schreibt Session-Zusammenfassungen am Welle-Ende.
- **Skill-Engine** (`agent/skills/engine.py`) loggt jeden Skill-Aufruf.
- **`curator`-Skill** kann manuell Facts hinzufügen.
- **`capture-lesson`-Skill** schreibt NICHT hierhin (sondern in Schicht 4).

### Wer liest?

- **`cortex-agent memory search "<query>"`** für Volltextsuche.
- **`cortex-agent memory facts [--kind X]`** für Fakten-Recall.
- **Agent-Loop** beim Bootstrap (recall relevant facts in System-Block).

### Warum pro Mac lokal?

Diese DB wächst schnell und unterscheidet sich pro Mac (welche Sessions liefen, welche Skills aufgerufen wurden). Wenn sie via Git synchronisiert würde:

- Jeder Sync würde sie mit-pushen — riesige Diffs (binär), viele Merge-Konflikte.
- Sessions sind Mac-lokales Arbeitsgeschehen — der Mac-Studio braucht nicht zu wissen, was M5 letzte Nacht im Detail kompiliert hat.

**Was trotzdem cross-device sichtbar werden soll** (Patterns, Lessons), wird zusätzlich in Schicht 1 (Vault als Markdown) oder Schicht 4 (Claude-Memory) abgelegt — diese Schichten sind gitversioniert oder zumindest dokumentiert.

### TTL und Verfallsdatum (Lean v3 §M3)

Facts in `memory.db` tragen ein `expires_at`-Feld. Nach Ablauf landen sie in einer **Quarantäne**, nicht im aktiven Recall-Index. Der `sanitizer`-Skill räumt das nightly auf.

Beispiel: ein temporärer Token für ein Sprint-Feature, der nach 30 Tagen automatisch aus dem aktiven Memory verschwindet.

### Recall im System-Prompt

Beim `cortex-agent run` werden relevante Facts und Patterns automatisch in den System-Block injiziert (`agent/memory/summarizer.py`). Heute heuristisch (Keyword-Match), perspektivisch semantisch (Embeddings — geplant).

## Schicht 4 — Claude-Code-Memory (`~/.claude/projects/<slug>/memory/`)

### Was es ist

**Per-Claude-Projekt-Memory** — Markdown-Dateien mit Frontmatter, die in Claude Code beim Session-Start automatisch in den Kontext geladen werden. Liegt außerhalb des Nexus-Repos, **pro Mac und pro Projekt lokal**.

Projekt-Slug wird aus dem Working-Directory abgeleitet: `~/Cortex/` → `-Users-ssmd-Cortex`.

### Struktur

```
~/.claude/projects/-Users-ssmd-Cortex/memory/
├── MEMORY.md                              ← Index (links zu allen Memory-Files)
├── feedback_<slug>.md                      ← Stil-Lessons (was Claude lernen soll)
├── project_<slug>.md                       ← Projekt-Stand / Vorhaben
├── reference_<slug>.md                     ← Pointer zu externen Quellen
└── user_<slug>.md                          ← Profil-Ergänzungen
```

Die vier Typen entsprechen Memory-Kategorien, die im Auto-Memory-System von Claude Code definiert sind.

### Beispiel — typischer Eintrag

`feedback_explain_jargon.md`:

```markdown
---
name: Fachbegriffe beim ersten Vorkommen kurz erklären
description: User erwartet inline-Erklärungen für Hook, JSON, FTS5, Tier, etc.
type: feedback
---

Wenn ich Fachbegriffe verwende, gehört eine inline Mini-Erklärung dazu.
Beispiel: „Ein Hook (Skript, das automatisch bei einem Event läuft) injiziert…"

**Why:** Anwender hat wiederholt „Was bedeutet X?" angemerkt — Fachbegriffe ohne Inline-Erklärung verlangsamen das Lesen.

**How to apply:**
- Beim ersten Auftauchen: Klammer-Erklärung oder Halbsatz.
- Akronyme erst ausschreiben.
- Im Glossar als Anker-Referenz.
```

### Wer schreibt?

- **`capture-lesson`-Skill** (`agent/skills/builtin/capture_lesson.py`) ist das Standard-Werkzeug. Aufruf z.B. via Welle-Ende oder explizit.
- **Ich (Claude)** direkt via Write-Tool, wenn der Kontext es nahelegt.

### Wer liest?

Claude Code lädt diese Files automatisch beim Session-Start des entsprechenden Projekts. Sie fließen unsichtbar in den Kontext.

### Sync-Verhalten — der wichtige Punkt

`~/.claude/projects/...` ist **NICHT** Teil des Nexus-Repos. Diese Memory-Files leben **nur auf dem Mac, auf dem sie geschrieben wurden**. Ein Lesson auf M5 ist nicht automatisch auf Mac-Studio sichtbar.

**Konsequenz:** Stil-Lessons, die ich an einem Mac lerne, sind nicht automatisch überall verfügbar. Das ist ein **bekanntes Optimierungsthema** (siehe Audit-Befund E.6 in `specs/architecture-refactor-2026-05/00_AUDIT.md`). Optionen für die Zukunft:

- Memory-Files in den Nexus-Vault spiegeln (gitversioniert mit-syncen).
- Centralized Memory-DB auf einem leader-Mac, Read-Replicas auf den anderen.
- Eigenes Sync-Skript für `~/.claude/projects/...`.

Heute: pro Mac manuell. Wenn du auf M5 etwas in mein Memory committed haben willst, muss ich es dort auch hinschreiben — automatisch passiert das nicht.

## Was wo hinkommt — die Entscheidungsmatrix

| Art der Information | Schicht |
|---|---|
| **Tutorial / How-To** | 1 (Vault) |
| **Praxis-Regel R-XXX** | 1 (Vault, 40 Regeln) |
| **Fehlerprotokoll** | 1 (Vault, 50 Fehler) |
| **User-Profil (statisch)** | 2 (Nexus-Memory `USER.md`) |
| **Vault-Pointer** | 2 (`KNOWLEDGE.md`) |
| **Goldene Regeln, Wiederholungsfehler** | 2 (`golden-rules.md`) |
| **Session-Zusammenfassung** | 3 (FTS5-DB, automatisch) |
| **Wiederkehrendes Muster (Pattern)** | 3 (FTS5-DB) |
| **Strukturierter Fakt** (z.B. „Anthropic-Kontakt: …") | 3 (FTS5-DB user_facts) |
| **Stil-Lesson („mag keine emojis")** | 4 (Claude-Memory `feedback_*.md`) |
| **Projekt-Vorhaben („Public-Skeleton angefangen")** | 4 (`project_*.md`) |
| **Externe Referenz (Doku-Pointer)** | 4 (`reference_*.md`) |

## Wichtige Schutzregel

Schichten 1, 2, 4 werden **nicht vom Sanitizer angetastet** — sie sind „Wissensdateien" laut `_rules/retention.md`. Auto-kuratierendes Umschreiben ist verboten. Nur explizit aufgerufene Skills (`tutorial-curator`, `capture-lesson`) dürfen schreiben.

Schicht 3 ist Runtime-Artefakt und wird vom Sanitizer **aktiv verwaltet** (TTL, VACUUM, Session-Archiv). Verluste hier sind unkritisch — die DB wird im Notfall neu aus den Schichten 1+2 aufgebaut.

## Aktueller Stand — was läuft, was nicht

| Schicht | Status |
|---|---|
| 1 — Vault | ✅ Aktiv, manuell gepflegt, gut strukturiert. |
| 2 — Nexus-Memory | ✅ Schlank nach Refactor-P3, Stracke-Layer ausgegliedert. |
| 3 — FTS5-DB | ⚠️ Aktiv, aber **Recall in System-Prompt heute heuristisch**. Semantische Suche (Embeddings) ausstehend. |
| 4 — Claude-Memory | ⚠️ Aktiv, aber **pro Mac lokal** — nicht cross-device. Sync-Konzept ausstehend. |

## Verwandte Tutorials

- **[[06 Selbstlernendes System]]** — wie das Lesson-Capturing operativ funktioniert
- **[[02 Datei-Atlas]]** — vollständige Pfad-Liste der `_memory/`-Inhalte
- **[[14 Notfall und Recovery]]** — was tun bei FTS5-DB-Korruption
- **[[15 Erweitern und Sichern]]** — Multi-Device-Memory-Sync-Pläne
