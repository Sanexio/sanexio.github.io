---
title: Autonomy und Safe Mode
domain: cortex
modul: 03
level: einsteiger
status: kanonisch
---

# 03 — Autonomy und Safe Mode

> **Antwort in einem Satz:** Cortex kennt zwei Betriebsmodi für die KI — **Autonomy** (Standard: durchziehen, keine Rückfragen außer bei Tier-3-Hardstops) und **Safe** (4-Phasen-Workflow mit Approval-Gate vor jeder Umsetzung) — Autonomy ist der harte Default, Safe wählst du explizit per Session.

## Die eine Regel zum Modus

**Autonomy ist immer der Default. Bei jedem Session-Start beginnt der Modus auf Autonomy.** Wer in einer bestimmten Session den Safe-Mode möchte, sagt das explizit (z. B. `/safe-mode`).

- **Default = autonomy.** Keine Ausnahmen, keine rechnerspezifischen Defaults.
- **Mode-Wechsel gilt pro Session.** Ein Wechsel mitten in einer Session greift für die laufende Session. Beim nächsten Session-Start steht der Modus wieder auf autonomy.
- **Keine rechnerspezifische Konfiguration.** Auf jedem Rechner gilt dieselbe Regel.

## Zwei Voraussetzungen, die beide stimmen müssen

Damit der Mode-Switch tatsächlich greift, müssen zwei voneinander unabhängige Mechanismen je Rechner einmal eingerichtet sein — der **Mode-Injection-Hook** und die **Custom-Slash-Commands**. Wenn einer von beiden fehlt, wirkt das System so, als ob der Mode-Wechsel ignoriert würde.

### 1. Hook in `~/.claude/settings.json` registriert

Das Skript `tools/cortex-mode/bin/inject.sh` produziert beim Aufruf valides JSON mit etwa drei Kilobyte `additionalContext` (Mode-Block, Tier-3, Goldene Regeln). Damit Claude Code es bei jedem Prompt aufruft, muss in `~/.claude/settings.json` unter `hooks.UserPromptSubmit` ein passender Eintrag liegen. Fehlt der Eintrag, läuft die Session faktisch ohne injizierten Mode-Kontext — alle Regeln gelten, aber Claude liest sie nicht und verhält sich entsprechend defensiver.

**Diagnose pro Rechner:**

```bash
jq -e '.hooks.UserPromptSubmit[] | select(.matcher == "") | .hooks[] | select(.type == "command") | .command' ~/.claude/settings.json
```

Erwartet: `"bash $HOME/Cortex/Nexus/tools/cortex-mode/bin/inject.sh"`. Wenn leer/Fehler: Hook fehlt.

**Fix:** Hook-Snippet in `~/.claude/settings.json` ergänzen (mergen mit bestehender Konfig). Detail im Memory `feedback_check_hook_registration.md`.

### 2. Slash-Commands `/autonomy-mode`, `/safe-mode`, `/cortex-mode` lokal installiert

Custom-Slash-Commands in Claude Code werden über Markdown-Files in `~/.claude/commands/<name>.md` registriert. Dieses Verzeichnis ist **rechner-lokal** (nicht Teil des Nexus-Repositories) — die drei Mode-Slash-Commands müssen also einmal pro Rechner lokal angelegt werden. Fehlt der Eintrag, antwortet Claude Code auf `/autonomy-mode` mit „Unknown command".

**Installation pro Rechner:**

```bash
cd ~/Cortex/Nexus && git pull --ff-only
bash tools/cortex-mode/bin/install_slash_commands.sh
```

Das Skript kopiert die drei Templates aus `tools/cortex-mode/commands-template/` nach `~/.claude/commands/`. Danach: **Claude Code neu starten oder `/hooks` öffnen**, damit die Command-Registry frisch eingelesen wird.

**Diagnose pro Rechner:**

```bash
ls ~/.claude/commands/ 2>&1
```

Erwartet: drei Dateien (`autonomy-mode.md`, `safe-mode.md`, `cortex-mode.md`).

### Beide Voraussetzungen müssen erfüllt sein

Beide Mechanismen sind unabhängig — und beide nötig:

- **Ohne registrierten Hook** wirkt der gesetzte Modus nicht, weil der Block nicht im Kontext landet.
- **Ohne installierte Slash-Commands** lässt sich der Modus nur über die CLI (`cortex-agent mode set autonomy`) wechseln, nicht über `/autonomy-mode`.

### Onboarding für neue und bestehende Rechner

Für **neue Rechner** existiert `scripts/onboard-device.sh`. Dieses Skript führt beide Schritte automatisch aus — Hook-Eintrag in `~/.claude/settings.json`, Slash-Commands aus dem Template-Ordner. Es ist der vorgesehene Weg, wenn ein zusätzlicher Rechner in den Cortex-Verbund aufgenommen wird.

Für **bestehende Rechner**, auf denen der Hook bisher fehlt, ist heute noch ein einmaliger manueller Aufruf von `bash tools/cortex-mode/bin/install_slash_commands.sh` plus das Hook-Snippet aus dem Memory `feedback_check_hook_registration.md` nötig. Ziel ist mittelfristig ein automatischer Selbst-Heilungs-Mechanismus, der bei einem Drift zwischen Repository-Zustand und lokaler Hook-Registration eigenständig nachzieht (Optimierungsthema: Hook-Drift-Auto-Sync, Detail siehe **[[15 Erweitern und Sichern]]**).

## Warum es zwei Modi gibt

Beispielszenario: Du bittest mich, etwas an einer Datei zu ändern.

Im **Autonomy-Modus** sage ich: gelesen, los — ich öffne die Datei, mache die Änderung, prüfe das Ergebnis, fertig. Im Welle-Ende-Debrief steht knapp, was ich gemacht habe.

Im **Safe-Modus** wäre derselbe Verlauf:
1. *Phase 1 — Verstehen:* Ich paraphrasiere die Aufgabe, identifiziere kritische Pfade, evtl. eine Klärungs-Frage.
2. *Phase 2 — Plan:* Konkrete Schritte als Liste mit Datei-Pfaden, Optionen wenn 2-3 plausible Pfade. **STOP, wartet auf dein OK.**
3. *Phase 3 — Umsetzen:* erst nach „ja"/„okay"/„go" → Edit + Verifikation.
4. *Phase 4 — Verifikation:* Diff zeigen, kurzer Selbst-Check.

**Welcher Modus ist „besser"?** Keiner. Sie sind für unterschiedliche Situationen.

- **Autonomy** ist schneller, weniger Reibung. Default. Für klar definierte Aufgaben.
- **Safe** ist langsamer, kontrollierter. Für Architektur-Entscheidungen, sensible Pfade — wo du in Phase 2 nochmal einen Stop willst, um den Plan zu prüfen.

## Die Mode-Datei

Wenn du wissen willst „in welchem Modus bin ich gerade":

```bash
cat ~/.claude/state/cortex-mode.json
```

Schema:
```json
{
  "mode": "autonomy",
  "since": "2026-05-09T10:16:31Z",
  "host": "SSMD-MacBookPro-M5",
  "set_by": "auto-init"
}
```

Wenn die Datei fehlt, legt der Hook sie beim nächsten Prompt mit `mode=autonomy` an (Auto-Init).

## Mode-Switch-Befehle

| Befehl | Wirkung |
|---|---|
| `/autonomy-mode` | Setzt `mode = autonomy`. Ab nächstem Prompt aktiv. |
| `/safe-mode` | Setzt `mode = safe`. Ab nächstem Prompt aktiv. |
| `/cortex-mode` | Zeigt nur den aktuellen Stand an. |

Die Slash-Commands sind nur verfügbar, wenn die Templates auf dem aktuellen Rechner lokal installiert sind — andernfalls antwortet Claude Code mit „Unknown command". Siehe oben unter **Zwei Voraussetzungen**.

CLI-Äquivalent (für Skripte oder als Fallback):

```bash
cortex-agent mode get               # zeigt aktuellen Modus
cortex-agent mode set safe          # setzt auf safe
cortex-agent mode set autonomy      # setzt auf autonomy
```

Der Mode-Wechsel wirkt **nicht rückwirkend** auf die laufende Antwort, sondern erst ab dem nächsten Submit.

## Was injiziert wird (das „warum verhält sich Claude so")

Bei **jedem** Prompt-Submit läuft `~/Cortex/Nexus/tools/cortex-mode/bin/inject.sh` — sofern als Hook registriert (siehe oben unter **Zwei Voraussetzungen**). Der Hook lädt:

1. **Mode-Briefing**: entweder `agent/modes/autonomy.md` oder `agent/modes/safe.md` — je nach State-File.
2. **Tier-3-Block**: immer `agent/modes/tier3.md` — mode-unabhängig.
3. **Optionale Helfer** (nur wenn Prompt triggert):
   - `local_first_discovery.py` — bei Keywords wie „clone", „repo", „wordpress", … (verhindert dass die KI ein Repo neu klont, wenn es lokal schon liegt).
   - `lesson_audit.py` — bei Welle-Ende-Phrasen wie „Session beenden", „debrief" (prüft, ob alle Lessons einen Persistenz-Anker haben).

Alles zusammen wird als `additionalContext`-Block oben an den Prompt gehängt. Token-Budget: ~3 KB.

## Autonomy im Detail

Der injizierte Block aus `agent/modes/autonomy.md` sagt der KI sinngemäß:

1. **Aufgabe verstanden? → Durchziehen.** Architektur-Phasen 1 (Verstehen) und 2 (Plan) laufen *intern* ab, ohne sichtbaren Pre-Op-Block. Phase 3 (Umsetzung) startet sofort.
2. **Verbotene Phrasen** im Autonomy-Mode: „Soll ich…?", „Möchtest du, dass ich…?", „Bevor ich anfange…", lange Pre-Op-Erklärungsblöcke.
3. **Nur in vier Fällen stoppen:**
   - **Echte Ambiguität** (zwei plausible Pfade).
   - **Tier-3-Operation** (siehe **[[04 Tier-3 Hardstops]]**).
   - **Token-Budget kritisch** (>80% der Conversation).
   - **Aufgabe erledigt** — dann Debrief.
4. **Freigegeben ohne Frage:** Alles innerhalb `~/Cortex/` (Write, Edit, Bash, Git, Tools, Telegram-Senden — Detail in `_rules/user-directives.md`).
5. **Welle-Ende-Debrief-Format:**
   ```
   WAS GEMACHT (Pflicht, 3–7 Bullets, faktisch)
   WAS GELERNT (nur wenn substantiell, mit Persistenz-Anker)
   STRATEGISCHE WAHLEN (nur bei echten Verzweigungen)
   ```
   Jeder „WAS GELERNT"-Bullet **muss** einen Anker tragen, der zeigt wo die Lesson persistiert wurde (`-> feedback_<slug>.md`, `-> specs/<slug>/`, `-> CLAUDE.md`, `-> hook:<name>`, oder `(ephemer)`). Detail: `_rules/lesson-anchors.md`.

## Safe im Detail

Der injizierte Block aus `agent/modes/safe.md` sagt der KI sinngemäß:

1. **Phase 1 — Verstehen.** Aufgabe paraphrasieren, Scope + Risiko notieren.
2. **Phase 2 — Plan.** Nummerierte Schritte mit Pfaden, kritische Dateien, Optionen aufzeigen. **HARD STOP** — auf explizites „ja"/„okay"/„go" warten.
3. **Phase 3 — Umsetzen.** Nach Approval: durchziehen, kurzes Begründungs-One-Liner pro Edit.
4. **Phase 4 — Verifikation.** Diff zeigen, Konsistenz-Check, Welle-Ende-Debrief mit Anker-Validierung.

**Sechs Stop-Trigger** statt vier (zusätzlich zu den Autonomy-Stops):
- Phase-2-Approval-Gate.
- Tier-3.
- Taktische Wahl mit 2–3 Pfaden.
- Echter Lern-Anlass.
- Konsistenz-Fehler in Phase 4.
- „WAS GELERNT" ohne Persistenz-Anker (blockierend im Safe-Modus).

Vollständige Stop-Liste (mode-übergreifend): `_rules/stop-conditions.md`.

## Tier-3 Hardstops — Mode-unabhängig

**Tier-3 ist immer aktiv, egal welcher Modus.** Auch im Autonomy-Modus stoppt die KI bei:

- Schreiben von Secrets-Files (`.env`, `~/.claude.json`, API-Keys, Passwörter, SSH-Keys).
- Geld-Operationen (SmartQ, Banking, Rechnungs-Versand).
- Externe Empfänger ohne User-Schleife (Mails an Patienten, GitHub-PR-Merge in fremden Repos).

Was **NICHT mehr Tier-3 ist** (per User-Direktive 2026-05-09 pauschal freigegeben):
- `git push`, `git push --force`, `git reset --hard` auf eigenen Repos.
- Live-Deploys eigener Projekte.
- Telegram-Senden an deinen eigenen Channel.
- WP-Admin auf eigenen Production-Domains.

Volle Liste: **[[04 Tier-3 Hardstops]]**.

## Wann nutze ich was?

| Situation | Empfehlung |
|---|---|
| **Routinearbeit, klare Aufgabe** | Autonomy (Default). |
| **Neue Architektur, größere Refactor-Welle** | Safe. Phase 2 ist deine letzte Stelle „bevor's irreversibel wird". |
| **Sensibles Theme** (Patient-Daten, Geld) | Safe + Tier-3 fängt das meiste sowieso. |
| **„Ich bin müde, mach einfach"** | Autonomy. |
| **„Ich will verstehen was du planst"** | Safe — genau dafür gibt's das Phase-2-Gate. |

Wechsle dynamisch. Es gibt keine Strafe für Modus-Wechsel mitten in der Session.

## Häufige Missverständnisse

**„Autonomy = die KI macht alles allein."**
Nein. Autonomy heißt: bei klaren Aufgaben kein Pre-Op-Block. Aber Tier-3 blockt weiterhin, echte Ambiguität führt weiterhin zu Stop, und am Welle-Ende kommt weiterhin ein strukturierter Debrief.

**„Safe = die KI fragt vor jedem Tastendruck."**
Nein. Safe hat ein Approval-Gate vor **Phase 3** (Umsetzung). Innerhalb von Phase 3 wird durchgezogen wie in Autonomy, mit 1-Zeilen-Begründungen pro Edit.

## Was du mit diesem Modul jetzt kannst

- Du weißt, dass es genau zwei Modi gibt: Autonomy (Default) und Safe (explizit).
- Du kannst zwischen ihnen wechseln (`/autonomy-mode`, `/safe-mode`, `/cortex-mode`).
- Du verstehst, dass der aktuelle Modus bei jedem Prompt aus `~/.claude/state/cortex-mode.json` neu gelesen und der passende Block in den Kontext injiziert wird — **sofern der Hook in `~/.claude/settings.json` registriert ist**.
- Du weißt, dass Tier-3 mode-unabhängig hard blockiert.
- Du kennst die beiden Voraussetzungen (Hook + Slash-Commands) und weißt, wie ein zusätzlicher Rechner darauf gebracht wird.

## Verwandte Tutorials

- **[[04 Tier-3 Hardstops]]** — die mode-unabhängige Schicht
- **[[11 Hooks und Mode-Injection]]** — der technische Mechanismus dahinter
- **[[06 Selbstlernendes System]]** — warum am Welle-Ende der Anker-Check kommt
- **[[14 Notfall und Recovery]]** — was tun bei kaputtem Mode-System
