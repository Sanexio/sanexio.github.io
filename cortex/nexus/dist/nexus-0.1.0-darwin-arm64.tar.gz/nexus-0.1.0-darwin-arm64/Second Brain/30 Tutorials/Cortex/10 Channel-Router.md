---
title: Channel-Router
domain: cortex
modul: 10
level: fortgeschritten
status: kanonisch
---

# 10 — Channel-Router (TypeScript/Bun)

> **Antwort in einem Satz:** Der Channel-Router ist die **TypeScript-Schicht in `gateway/`**, die externe Eingangs-Kanäle (heute Telegram-V3; geplant Slack und Signal) empfängt, authentifiziert, sandboxt und an den Self-Learning-Layer weiterleitet — die Bridge ist primär als **Info-Terminal** definiert (Cortex-Mesh-Status, Permission-Approvals), für die Live-Steuerung laufender Sessions vom Mobilgerät aus übernimmt **`claude remote-control`** als nativer Standard-Pfad.

## Klare Rollenteilung — Info-Terminal vs. Project-Work

Es gibt zwei parallele Mobile-Pfade mit unterschiedlichen Stärken (Detail in `specs/cortex-native-migration/00_KONZEPT.md`):

| Pfad | Wofür | Tooling |
|---|---|---|
| **Info-Terminal** (Telegram-Bridge) | Status aller Macs, Geräte-Aggregat, Permission-Approvals, Tier-3-Notifications, schnelle `/status`-Abfragen | Custom-Bridge in `gateway/` mit `BRIDGE_MODE=poll` auf einem Leader-Mac, `passive` auf den anderen |
| **Project-Work** (Remote-Control) | Live-Session-Mirror, Mobile-Steuerung laufender Sessions, Multi-Mac-Koordination, ad-hoc Spawns | `claude remote-control` + `claude.ai/code` Browser-UI + QR-Code-Mobile |

Diese Trennung ist bewusst: die Bridge bleibt für das, was Standard-Tools nicht in derselben Weise abdecken (native Telegram-App-Push für schnelle Mesh-Status-Abfragen). Remote-Control übernimmt die produktive Projektarbeit.

In diesem Modul lernst du **wie das Routing technisch funktioniert**, **wie die Info-Terminal-Rolle aussieht**, und **wie du parallel Remote-Control nutzt**.

## Wo es lebt

```
gateway/                                  ← Channel-Router (TypeScript, Bun-Runtime)
├── src/
│   ├── gateway.ts                       ← zentrale Router-Klasse
│   ├── types.ts                         ← TypeScript-Interfaces
│   ├── auth.ts                          ← Pairing-Store (Whitelist)
│   └── sandbox.ts                       ← Sandbox-Isolation
├── lib/
│   └── spawn-queue.ts                   ← TypeScript-Mirror der Python-Queue
├── package.json                         ← Bun-Manifest
└── bun.lock

tools/telegram-bridge/                   ← Erster Channel-Implementierung
├── (Node.js + MCP-Server, Long-Polling)
```

**Bun** ist eine schnelle JavaScript-Laufzeit (ähnlich Node.js, aber deutlich performanter beim Starten/Builds). Im Cortex genutzt für den Router-Code, weil er häufige Restarts vertragen muss.

**„OpenClaw-style"** ist der Architektur-Begriff für dieses Pattern: kanalagnostischer Router mit Pairing-Store und Sandbox-Isolation. Vorbild: das OpenClaw-Framework. Im Tutorial nennen wir es konsequent **Channel-Router**.

## Komponente 1 — `gateway.ts` (Router-Klasse)

### Was es macht

Zentral verwaltete Klasse mit drei Verantwortungen:

1. **Command-Registry** — registrierte Befehle (z.B. `/status`, `/spawn`, `/pause`) und deren Handler.
2. **Channel-Verwaltung** — welcher Kanal ist aktiv (Telegram heute; perspektivisch Slack/Signal).
3. **Dispatcher** — eingehende Messages → richtigem Handler zuordnen.

### Pseudo-Code-Struktur

```typescript
class Gateway {
  private commands: Map<string, CommandHandler> = new Map();
  private channels: Map<string, ChannelHandle> = new Map();
  
  registerCommand(name: string, handler: CommandHandler) { ... }
  registerChannel(name: string, channel: ChannelHandle) { ... }
  
  async dispatch(inbound: InboundMessage): Promise<OutboundMessage> {
    // 1. Pairing-Check (auth.ts)
    if (!this.isAuthorized(inbound.sender)) return reject();
    
    // 2. Command-Match
    const cmd = this.parseCommand(inbound.text);
    if (!cmd) return plainTextFallback(inbound);
    
    // 3. Sandbox + Execute
    return await sandbox.run(this.commands.get(cmd.name), inbound);
  }
}
```

### Plain-Text-Fallback

Wenn eine eingehende Nachricht **kein `/`-Befehl** ist:
- Anti-Spam-Schutz: wird heute **nicht interpretiert**.
- Geplant: Sub-Agent-Delegation („interpretiere die Anfrage als Spawn-Request").

## Komponente 2 — `auth.ts` (Pairing-Store)

### Was es macht

**Pairing-Store** = Whitelist eingehender Devices. Persistiert in `~/.config/gateway-pairings.json` (lokal pro Mac, nicht im Repo).

### Struktur

```json
{
  "pairings": [
    {
      "device_id": "telegram-chat-8547497426",
      "label": "Dr. Stracke (Telegram)",
      "added_at": "2026-04-22T10:00:00Z",
      "permissions": ["receive", "reply", "spawn"]
    }
  ]
}
```

### Wer schreibt?

- **`/pair`-Befehl** (geplant) — initiale Verkopplung eines neuen Devices.
- **Manuell** durch Editieren der JSON-Datei.

### Wer liest?

Jeder eingehende Request wird gegen den Pairing-Store geprüft. Unbekanntes Device → Reject.

### Stand

Aktuell **hardcoded** (statt aus JSON gelesen): Telegram-Chat-ID `8547497426` (Stracke) ist als einziger erlaubter Sender im Code. Public-Skeleton-Vorbereitung: dynamisches Pairing.

## Komponente 3 — `sandbox.ts` (Isolations-Schicht)

### Was es macht

Wenn ein Befehl ausgeführt wird, läuft er in einer **Sandbox** — heute eine **Bash-Subshell** mit ChildProcess-Isolation. Idee: ein bösartiger eingehender Input kann nicht direkt auf das Filesystem zugreifen, sondern wird durch eine kontrollierte Schicht abgefangen.

### Aktuelle Implementierung

```typescript
async function runSandboxed(handler: Handler, input: SafeInput): Promise<Output> {
  const proc = Bun.spawn({
    cmd: ["bash", "-c", handler.command],
    stdin: JSON.stringify(input),
    env: filteredEnv(),         // nur benötigte Variablen weitergeben
    cwd: "/tmp/cortex-sandbox", // isolierter Working-Dir
    timeout: 30_000
  });
  return await proc.stdout.text();
}
```

### Geplant

- **Docker-Sandbox** für stärkere Isolation.
- **SSH-Sandbox** zu anderen Macs für distributed execution.

Heute: nur Bash-Subshell. Für die aktuellen Anwendungsfälle (Status, Spawn) ausreichend.

## Komponente 4 — Spawn-Queue (`lib/spawn-queue.ts`)

### Was es macht

Mirror der Python-`spawn_queue.py` (siehe `agent/connexio/spawn_queue.py`). TypeScript-Implementierung, damit der Channel-Router unabhängig vom Python-Stack arbeiten kann.

### Schema

```typescript
interface SpawnRequest {
  id: string;
  channel: "telegram" | "slack" | "signal" | "ipad";
  sender_id: string;
  prompt: string;
  enqueued_at: string;
  processed_at?: string;
  agent_response?: string;
  status: "pending" | "processing" | "done" | "failed";
}
```

### Lifecycle

1. Eingehender `/spawn <prompt>` → Spawn-Request wird enqueued.
2. **Spawn-Watcher** (`agent/connexio/spawn_watcher.py`, Python) pollt alle 5 Sek die Queue.
3. Bei neuem Request: Agent-Run wird gestartet.
4. Ergebnis → `agent_response` Feld → über Channel zurück an Sender.

## Telegram-V3 — der erste implementierte Kanal

### Architektur

```
[Telegram Cloud]
       │
       │ Long-Polling (alle 5 Sek)
       ▼
[tools/telegram-bridge/]                  ← Node.js MCP-Server
       │
       │ MCP-Tool: reply(chat_id, text)
       ▼
[Channel-Router (gateway/)]
       │
       │ Dispatcher
       ▼
[Self-Learning-Layer (agent/)]
       │
       │ Spawn ggf. Agent-Run
       ▼
[LLM (Anthropic) → Antwort]
       │
       ▼
[Bridge: reply() → Telegram]
```

### Configuration

In `.env` (auf jedem Mac mit Telegram-Bridge):

```
TELEGRAM_BOT_TOKEN=12345:abc...           # Bot-Token vom @BotFather
TELEGRAM_ALLOWED_CHAT_IDS=8547497426       # Stracke-Chat-ID, comma-separated
```

### Pattern: Long-Polling statt Webhook

Telegram bietet zwei Update-Mechanismen:
- **Webhook** — Telegram sendet POST-Requests an deinen Server. Braucht öffentliche IP/HTTPS.
- **Long-Polling** — dein Server fragt periodisch bei Telegram nach Updates. Funktioniert von jedem Mac, auch hinter NAT.

Cortex nutzt **Long-Polling**: deine Macs sitzen alle hinter Router-NAT, ein Webhook würde ohne Reverse-Proxy nicht funktionieren. Der Bridge-Prozess pollt alle 5 Sek `getUpdates` bei Telegram.

### MCP-Tools über die Bridge

Die Telegram-Bridge stellt MCP-Tools bereit, die Claude direkt aufrufen kann (via `claude mcp add`):

| Tool | Zweck |
|---|---|
| `reply(chat_id, text, format="markdown")` | Nachricht an User senden. |
| `get_chat_history(chat_id, limit)` | Recent Messages lesen. |

### `/`-Befehle, die der Channel-Router heute unterstützt

| Befehl | Wirkung |
|---|---|
| `/status` | Antwort: aktive Spawns, letzte Sync-Zeiten, Tier-3-Pending, Cron-Failures. |
| `/spawn <prompt>` | Triggert Agent-Run auf einem Mac, sendet Ergebnis zurück. |
| `/pause` | Pausiert aktive Spawns. |
| `/help` | Listet verfügbare Befehle. |

### Freitext ohne `/`-Befehl

Heute: keine Reaktion (Anti-Spam-Schutz). Geplant: Sub-Agent-Delegation („wenn keine command, dann als Spawn-Request interpretieren").

## Wie du Telegram konkret bedienst

### Setup einmalig

1. Im Telegram-Client: Suche `@sanexio_bot` → Chat öffnen.
2. **`/start`** tippen (registriert den Bot bei dir).
3. **`/status`** tippen → sollte Geräte-Stand zurückgeben.

### Tägliche Bedienung

- **Status checken:** `/status` an `@sanexio_bot`.
- **Aufgabe starten:** `/spawn Prüfe ob die praxis-webseite live ist`.
- **Aktive Spawns pausieren:** `/pause`.

Antworten erscheinen direkt im Chat. Format ist Markdown.

### Aktueller Stand — Multi-Device-Lücke

**Heute funktioniert die ausgehende Richtung nur von Cluster-Mini-02.** Andere Macs (M5, SSMD-MBP, Mac-Studio) haben die Bridge installiert, senden aber keine Status-Meldungen.

**Diagnose pro Mac** (Memory: `project_telegram_only_cluster_mini_02.md`):

```bash
# 1. LaunchAgent aktiv?
launchctl list | grep telegram
# Erwartet: com.cortex.telegram-bridge mit pid

# 2. MCP-Bridge registriert?
claude mcp list | grep telegram-bridge
# Erwartet: Server-URL und Status "ready"

# 3. Token vorhanden?
[ -f ~/Cortex/Nexus/.env ] && echo "env file exists" || echo "MISSING"

# 4. Bridge-Logs
tail -20 ~/Cortex/Nexus/_memory/logs/telegram-bridge.log
```

Fix-Plan: separater Bug-Sprint, dokumentiert im Memory `project_telegram_only_cluster_mini_02.md`.

## Geplante weitere Kanäle

Aus dem Spec `specs/cortex-public-skeleton/` und der Phoenix-Roadmap:

| Kanal | Status | Zweck |
|---|---|---|
| Telegram-V3 | ✅ Aktiv (mit Multi-Device-Lücke) | Mobile Kommunikation. |
| Slack | ⛔ Geplant | Team-Kommunikation (Sanexio intern). |
| Signal | ⛔ Geplant | Sichere Patient-bezogene Notizen (mit DSGVO-Audit). |
| iPad-Native | ⛔ Geplant | Native App, statt Telegram-Workaround. |
| macOS-Menubar | ⛔ Geplant | Status-Indicator + Quick-Spawn. |

**Architektur ist kanalagnostisch**, d.h. ein neuer Kanal heißt: neue ChannelHandle-Implementierung registrieren, kein Router-Umbau.

## Public-Skeleton-Perspektive

Im Sanexio-Geschäftsmodell soll jeder Teilnehmer:
- Seinen **eigenen Telegram-Bot** registrieren (eigener Token, eigener Chat).
- Den Channel-Router auf seinem eigenen Mac laufen lassen.
- **Nicht** mit dem Stracke-Bot kommunizieren.

Konsequenz: `auth.ts` muss aus hardcoded Stracke-Chat-ID auf JSON-basierte Pairing-Konfiguration umgestellt werden. Aufwand: niedrig.

Detail: `specs/cortex-public-skeleton/00_KONZEPT.md`, Phase 2.

## Remote-Control — der native Project-Work-Pfad

Aktivierung pro Mac:

```bash
# Pro Session manuell:
claude remote-control --spawn worktree

# Oder dauerhaft (in Claude Code):
/config → "Enable Remote Control for all sessions" = true
```

Mobile-Zugriff:

- **QR-Code:** Spacebar im Terminal drücken → Code mit der Claude-App scannen.
- **Browser:** `claude.ai/code` öffnen, Session aus Liste wählen (Online-Dot pro Mac).
- **Push-Notifications:** Setting `inputNeededNotifEnabled` aktivieren für Permission-Prompts.

Damit hast du **alle laufenden Sessions auf allen Macs in einer Liste**, kannst gezielt eine ansteuern, Prompts schicken, Permission-Approvals direkt in der App geben.

### Wann Bridge, wann Remote-Control?

| Anwendung | Bridge | Remote-Control |
|---|---|---|
| Schneller Mesh-Status (`/status`, `/devices`) | ✅ optimal | umständlicher |
| Sehen was Claude gerade macht | nicht möglich | ✅ Live-Stream |
| Prompt schicken / Session steuern | nicht möglich | ✅ bidirektional |
| Permission-Approval | ✅ via `/verdict` | ✅ via App |
| Multi-Mac-Liste mit Aktivitäts-Status | ✅ aggregat | ✅ pro Session |
| Spawn ad-hoc auf einem Mac | über Bridge `/spawn` (legacy) | ✅ `claude agents --bg` |
| Funktioniert ohne Anthropic-Account auf Handy | ✅ Telegram-Standard | ⛔ braucht Claude-App-Login |

## Aktueller Stand — was läuft, was nicht

| Komponente | Status |
|---|---|
| `gateway.ts` Router | ✅ Implementiert. |
| `auth.ts` Pairing-Store | ⚠️ Hardcoded auf Stracke-Chat-ID. |
| `sandbox.ts` Bash-Subshell | ✅ Aktiv. |
| `spawn-queue.ts` | ✅ Aktiv. |
| Telegram-V3 — eingehend | ✅ Funktioniert (Long-Polling, MCP-Tools). |
| Telegram-V3 — ausgehend | ⚠️ Nur Cluster-Mini-02. |
| `/status`, `/spawn`, `/pause`, `/help` | ✅ Implementiert. |
| Multi-Device-Status-Aggregation | ⚠️ Status-Antwort kommt nur von einem Mac. |
| Weitere Kanäle (Slack, Signal, iPad) | ⛔ Geplant. |
| Docker-Sandbox | ⛔ Geplant. |
| Plain-Text-Fallback (Sub-Agent-Spawn) | ⛔ Geplant. |

## Was du mit diesem Modul jetzt kannst

- Du verstehst, dass „Channel-Router" der allgemeine Vermittlungs-Layer ist, Telegram nur der erste Kanal.
- Du weißt, wie Long-Polling vs. Webhook funktioniert und warum Long-Polling gewählt wurde.
- Du kennst die vier Komponenten (Router, Pairing, Sandbox, Spawn-Queue).
- Du kennst die `/`-Befehle (`/status`, `/spawn`, `/pause`, `/help`) und kannst sie verwenden.
- Du weißt, warum heute nur Cluster-Mini-02 sendet und kannst pro Mac diagnostizieren.
- Du verstehst, wie der Router public-skeleton-tauglich gemacht wird (dynamisches Pairing).

## Verwandte Tutorials

- **[[01 Architektur und Schichten]]** — Channel-Router im Big Picture
- **[[08 Connexio]]** — wie der Router mit Multi-AI verschränkt ist (Spawn-Queue)
- **[[12 Externe Dienste]]** — Tailscale + Telegram + GitHub im Verbund
- **[[14 Notfall und Recovery]]** — was tun bei kaputter Telegram-Bridge
- `tools/telegram-bridge/` — die konkrete Telegram-Implementierung
