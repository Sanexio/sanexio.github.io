---
title: Cortex — Map of Content
domain: cortex
modul: _moc
level: einsteiger
status: kanonisch
---

# Cortex — Map of Content

Zentrale Übersicht für alle Cortex-Tutorials. Hier findest du den Lernpfad, eine Querfrage-Tabelle und die Konventionen, in denen alle Module geschrieben sind.

> **Projekt-spezifische Tutorials** (WordPress, iOS, Shopify, Blender, Gaming, Webdesign) bleiben in ihren eigenen Domain-Ordnern. Was Cortex *nutzt* (Tailscale, Obsidian, GitHub, MCP) wird in **[[12 Externe Dienste]]** behandelt — wie diese Dienste in Cortex eingebettet sind, nicht als generische Tools.

## Wofür Cortex da ist

Cortex ist eine persönliche, KI-gesteuerte Arbeitsumgebung. Sie umfasst:

- **Nexus** — das Steuerwerk (Regeln, Agent, Memory, Vault, Sync).
- **Projects** — Werkprojekte unter `~/Cortex/projects/`.
- **Second Brain** — der Obsidian-Vault innerhalb Nexus.

Multi-Device über mehrere Rechner, Multi-AI (Claude + Codex + Cursor + …), Multi-Channel (Terminal + Telegram-Info-Terminal + Browser-Mobile via Remote-Control). Alles synchron via GitHub, koordiniert via Connexio, geregelt via die `_rules/`-Familie.

Strategisch existiert Cortex in zwei Spielarten — die **Private-Variante** (Voll-Stack mit Patient-Domain, Praxis-Regeln, eigenem Vault) und die **Public-Variante** (abgespeckte Skeleton-Version, die auch andere Mediziner, normale User und Patienten lokal laufen lassen können). Detail: `specs/cortex-public-skeleton/`.

## Lernpfad — drei Stufen

### Stufe 1: Verstehen (00 → 04)

Die Grundlagen. Wenn du nur eine Stunde Zeit hast — diese fünf Module.

| # | Modul | Worum's geht |
|---|---|---|
| 00 | **[[00 Was ist Cortex]]** | 5-Minuten-Übersicht inkl. strategischem Rahmen (Private + Public) |
| 01 | **[[01 Architektur und Schichten]]** | Self-Learning-Layer ↔ Channel-Router ↔ Memory ↔ Hooks ↔ Vault, mit Diagramm |
| 02 | **[[02 Datei-Atlas]]** | Vollständige kommentierte Pfad-Liste (Nachschlagewerk) |
| 03 | **[[03 Autonomy und Safe Mode]]** | Die zwei Modi, Mode-Wechsel, Hook-Mechanismus |
| 04 | **[[04 Tier-3 Hardstops]]** | Was die KI nie ohne Freigabe tut, mit Begriffs-Erklärungen |

### Stufe 2: Tiefenwissen (05 → 11)

| # | Modul | Worum's geht |
|---|---|---|
| 05 | **[[05 Memory in 4 Schichten]]** | Vault, Nexus-Memory, FTS5-DB, Claude-Memory — was wohin, was gitversioniert ist, was lokal |
| 06 | **[[06 Selbstlernendes System]]** | Lesson-Capture, Audit-Hook, Anker-Validierung, Optimierungs-Hebel |
| 07 | **[[07 Multi-Device-Sync]]** | nexus-sync.sh in sieben Phasen, Heartbeat-Race-Avoidance, Recovery |
| 08 | **[[08 Connexio]]** | Read-Only-Surface + MCP-Server + Codex-Handoff + drei Sicherheits-Linien |
| 09 | **[[09 Self-Learning-Layer]]** | cortex-agent CLI, Hermes-Single-Roundtrip-Pattern, Skill-Engine |
| 10 | **[[10 Channel-Router]]** | Telegram-Info-Terminal + Remote-Control-Project-Pfad, MCP-Tools, Pairing-Store |
| 11 | **[[11 Hooks und Mode-Injection]]** | Hook-Konzept, inject.sh-Anatomie, Helper-Skripte, Pro-Mac-Registration |

### Stufe 3: Operativ (12 → 99)

| # | Modul | Worum's geht |
|---|---|---|
| 12 | **[[12 Externe Dienste]]** | GitHub, Tailscale, Obsidian, Anthropic-API + claude.ai/code, Telegram — was Cortex nutzt |
| 13 | **[[13 Slash-Commands und CLI]]** | Befehls-Welten, Cookbook-Sequenzen, Tier-3-Triggertabelle |
| 14 | **[[14 Notfall und Recovery]]** | Notfall-Szenarien mit Diagnose + Recovery, Doctor-Skill als Anlaufpunkt |
| 15 | **[[15 Erweitern und Sichern]]** | Erweiterungs-Achsen + Sicherheits-Themen + priorisierte To-Do-Liste |
| 16 | **[[16 Harness — Wie Claude arbeitet]]** | Allgemeine Harness-Mechanik (Tool-Loop, Hooks, Skills, Permissions) plus Cortex-spezifische Aufsätze (`inject.sh`, Mode-Injection, `cortex-agent`-Mini-Harness) |
| 99 | **[[99 Glossar]]** | Begriffe alphabetisch, mit Beispielen und Querverweisen pro Modul |

## Wenn du eine konkrete Frage hast

| Frage | Antwort findet sich in… |
|---|---|
| „Was ist Nexus eigentlich?" | **[[00 Was ist Cortex]]** |
| „Wie reden die Schichten miteinander?" | **[[01 Architektur und Schichten]]** |
| „Welche Datei macht was?" | **[[02 Datei-Atlas]]** |
| „Wann muss die KI stoppen?" | **[[04 Tier-3 Hardstops]]** |
| „Was ist eine .env-Datei?" | **[[04 Tier-3 Hardstops]]** |
| „Was bedeutet 'Wikilinks brechen'?" | **[[02 Datei-Atlas]]** |
| „Welche Skill-Welten gibt es?" | **[[01 Architektur und Schichten]]** + **[[02 Datei-Atlas]]** |
| „Wo schreibt sich die KI Lessons hin?" | **[[06 Selbstlernendes System]]** |
| „Warum ist mein Mac hinterher?" | **[[07 Multi-Device-Sync]]** |
| „Wie übergibt Claude an Codex?" | **[[08 Connexio]]** |
| „Wie funktioniert Telegram als Info-Terminal?" | **[[10 Channel-Router]]** |
| „Wie steuere ich vom Handy laufende Sessions?" | **[[10 Channel-Router]]** + **[[12 Externe Dienste]]** |
| „Was tippe ich im Terminal?" | **[[13 Slash-Commands und CLI]]** |
| „Wie verarbeitet Claude eigentlich einen Prompt?" | **[[16 Harness — Wie Claude arbeitet]]** |
| „Etwas ist kaputt, was nun?" | **[[14 Notfall und Recovery]]** |
| „Wie wird Cortex zum Sanexio-Geschäftsmodell?" | `specs/cortex-public-skeleton/00_KONZEPT.md` |

## Architekturelle Querreferenzen

- **`~/Cortex/Nexus/_rules/AUTONOMY_CONTRACT.md`** — Vertrag (Index) plus spezialisierte Regel-Files.
- **`~/Cortex/Nexus/_rules/glossary.md`** — Pflicht-Lese-Glossar mit Begriffsdefinitionen.
- **`~/Cortex/Nexus/CLAUDE.md`** — Session-Init-Datei.
- **`~/Cortex/Nexus/SYSTEM_MAP.md`** — Kurz-Pointer-Index zum Repo.
- **`Second Brain/40 Regeln/`** — generelle Praxis-Regeln.
- **`Second Brain/50 Fehler/`** — Fehlerprotokolle.

## Specs zur Architektur

Detailtiefe, die nicht in die Tutorials gehört:

- `specs/cortex-public-skeleton/` — Public-Variante (auch für Patienten/normale User).
- `specs/cortex-native-migration/` — Hybrid-Strategie zwischen Custom-Cortex und nativer Claude-Code-Funktionalität.
- `specs/cortex-lean-v3/` — State-First-Prinzip, Lease-Mechanik, Memory-TTL.
- `specs/lesson-persistence/` — Wie Lessons strukturell verankert werden.

## Konventionen

- **Wikilinks** im Format `[[Modul-Name]]` zeigen auf andere Tutorials in diesem Bündel.
- **Code-Pfade** sind immer absolut (z.B. `~/Cortex/Nexus/_rules/AUTONOMY_CONTRACT.md`).
- **Frontmatter** in jedem Modul: `title`, `domain: cortex`, `modul`, `level`, `status`.
- **Sprache:** Hochdeutsch.
- **Tonalität:** Direkter Erklär-Stil, kein Marketing-Sprech.
- **Ehrlichkeit:** Wenn ein Mechanismus konzipiert aber operativ schwach ist, wird das benannt — als sachliche Aussage zum aktuellen Stand.
- **Fachbegriffe:** Beim ersten Vorkommen kurz erklärt (Inline oder als Sub-Sektion), Detail im Glossar.
