---
title: Erweitern und Sichern
domain: cortex
modul: 15
level: fortgeschritten
status: kanonisch
---

# 15 — Erweitern und Sichern

> **Antwort in einem Satz:** Cortex hat klare Achsen zum Wachsen (neuer Mac aufnehmen, neuen Skill schreiben, neuen Channel einbauen, Sanexio-Public-Skeleton aufbauen) und klare Achsen zum Härten (Backup, Compliance, Drift-Schutz, Memory-Sync, Sicherheits-Audits); dieses Modul listet beide Achsen mit den nächsten konkreten Schritten.

In diesem Modul lernst du **wo die Erweiterungs-Hebel liegen**, **welche offenen Sicherheits-Themen es gibt**, und **wie du einen neuen Mac oder einen Public-Skeleton-Teilnehmer onboardest**.

## Wichtige Querreferenz — Cortex-Native-Migration

Eine eigene **Migration-Spec** beschreibt die schrittweise Reduktion von Custom-Code zugunsten nativer Claude-Code-Funktionalität: `specs/cortex-native-migration/00_KONZEPT.md`. Sechs Wellen R1–R6 mit klarer Rollenteilung:

- **Info-Terminal** (Telegram-Bridge) bleibt — Cortex-Mesh-Status, Permission-Approvals.
- **Project-Work** (Remote-Control) — Live-Sessions, Mobile-Steuerung.
- **Cron + Task + Skill** — schrittweise auf native Tools (`CronCreate`, `TaskCreate`, `~/.claude/skills/`).

Die Erweiterungs-Achsen unten beziehen sich auf die **Cortex-Domäne** (Sanexio-Geschäftsmodell, Cortex-spezifische Funktionen). Standard-Mobile-Setup und Project-Work werden in der Migration-Spec separat behandelt.

## Übersicht — fünf Erweiterungs-Achsen

| Achse | Was wächst | Aufwand |
|---|---|---|
| **A** Neuen Mac aufnehmen | Geräte-Anzahl im Stracke-Verbund | gering (Skript) |
| **B** Neuen Skill bauen | Funktionalität des Self-Learning-Layers | mittel |
| **C** Neuen Channel einbauen | Eingangs-Kanäle (Slack, Signal, iPad-Native) | mittel-hoch |
| **D** Public-Skeleton aufbauen | Sanexio-Geschäftsmodell | groß |
| **E** Memory + Self-Learning aktivieren | Automatisches Lernen wird wirklich aktiv | mittel-hoch |

## Achse A — Neuen Mac aufnehmen

### Voraussetzungen pro Mac

- macOS (Apple Silicon oder Intel).
- Homebrew installiert.
- Apple-ID + iCloud-Login (für gemeinsame Files).
- Tailscale-Account-Zugang.
- GitHub-SSH-Key.

### Onboarding-Skript

```bash
# Auf dem neuen Mac, nach einmaligem Bootstrap:
git clone git@github.com:Sanexio/nexus.git ~/Cortex/Nexus
cd ~/Cortex/Nexus
bash scripts/onboard-device.sh <hostname> <role>
# z.B.: bash scripts/onboard-device.sh SSMD-MacBookPro-M6 praxis-mobile
```

Das Skript macht:

1. Homebrew-Checks (uv, bun, gh, tailscale).
2. `.venv` aufbauen via `uv sync`.
3. Mac in `.config/devices.json` eintragen.
4. Tailscale-Login triggern.
5. LaunchAgent `com.cortex.nexus-sync.plist` kopieren + laden.

### Was das Skript HEUTE nicht macht (ausstehend)

- **Hook-Registration in `~/.claude/settings.json`** — siehe **[[11 Hooks und Mode-Injection]]**. Manuell nachziehen.
- **Telegram-Bridge-LaunchAgent installieren** — ausstehend, daher Multi-Device-Telegram-Lücke.
- **MCP-Server (`claude mcp add telegram-bridge`)** — manuell nachziehen.

Die Lücke ist im Public-Skeleton-Spec als „Phase 2" markiert.

### Verifikations-Checkliste nach Onboarding

```bash
# 1. Sync funktioniert
cd ~/Cortex/Nexus && git pull --ff-only

# 2. LaunchAgent läuft
launchctl list | grep cortex

# 3. Tailscale aktiv
tailscale status

# 4. Hook registriert (siehe Modul 11)
jq -e '.hooks.UserPromptSubmit' ~/.claude/settings.json

# 5. cortex-agent läuft
cortex-agent bootstrap --no-pull

# 6. Doctor grün
cortex-agent skill run doctor
```

## Achse B — Neuen Skill bauen

### Pattern

Skills sind Python-Funktionen mit `@skill`-Decorator in `agent/skills/builtin/`. Minimal-Beispiel:

```python
# agent/skills/builtin/my_new_skill.py
from __future__ import annotations
from typing import Any
from agent.skills.engine import skill


@skill(
    name="my-new-skill",
    version="0.1.0",
    doc="Was dieser Skill macht (One-Liner, landet im INDEX.md).",
)
def my_new_skill(args: dict[str, Any]) -> str:
    target = args.get("target", "default")
    # … Logik …
    return f"OK: bearbeitet {target}"
```

Nach Speichern: `cortex-agent skill list` findet den neuen Skill automatisch (Auto-Discovery via `pkgutil.iter_modules`).

### Empfehlungen

- **Eindeutiger Zweck.** Lieber zwei kleine Skills als einen großen.
- **Stdlib-only wo möglich.** Externe Dependencies via `pyproject.toml`.
- **Args als Dict.** Übergabe via `--args '{"key":"value"}'` auf CLI.
- **Return als String** (Markdown bevorzugt).
- **Exceptions werden geloggt** (skill_runs-Tabelle mit `ok=0`).

### Trigger-Annotationen (geplant)

Aus dem Audit (`specs/architecture-refactor-2026-05/` §E): Skills sollten `triggers=[...]`-Annotationen tragen, damit der Agent sie semantisch finden kann:

```python
@skill(
    name="my-new-skill",
    version="0.1.0",
    triggers=["welle-ende", "session-summary"],   # geplant
    related=["capture-lesson", "session-end"],
    doc="...",
)
```

Heute: nicht implementiert. Aktivierungs-Plan: `engine.py` erweitern, INDEX.md-Generator entsprechend.

### Workflow-Engine (geplant)

Skill-Ketten in `agent/workflows/*.yaml`:

```yaml
# Beispiel (Stub):
name: welle-ende
trigger: ["session beenden", "debrief"]
steps:
  - skill: capture-lesson
    if: pending_lessons > 0
  - skill: doctor
  - skill: session-end
```

Status: konzeptuell. Implementierung: ~150 Zeilen Python in `engine.py`.

## Achse C — Neuen Channel einbauen

### Channel-Pattern

Ein Channel implementiert das `ChannelHandle`-Interface in `gateway/src/types.ts`:

```typescript
interface ChannelHandle {
  name: string;
  start(config: ChannelConfig): Promise<void>;
  stop(): Promise<void>;
  send(target: string, message: OutboundMessage): Promise<void>;
  onIncoming(handler: (msg: InboundMessage) => Promise<OutboundMessage>): void;
}
```

### Geplante Channels (aus Spec / Phoenix-Roadmap)

| Channel | Status | Anmerkung |
|---|---|---|
| Telegram-V3 | ✅ Aktiv (mit Multi-Device-Lücke) | Erster implementierter Channel. |
| Slack | ⛔ Geplant | Team-Kommunikation Sanexio intern. |
| Signal | ⛔ Geplant | Sichere Patient-Kommunikation (mit DSGVO-Audit). |
| iPad-Native | ⛔ Geplant | Native App statt Telegram-Workaround. |
| macOS-Menubar | ⛔ Geplant | Status-Indicator + Quick-Spawn. |

### Implementierungs-Schritte (generisch)

1. **Provider-Bibliothek** (z.B. `@slack/web-api`) installieren.
2. **Channel-Implementierung** in `gateway/src/channels/<name>.ts` schreiben.
3. **In `gateway.ts`** registrieren.
4. **Pairing-Eintrag** in `~/.config/gateway-pairings.json`.
5. **MCP-Tools** (z.B. `reply_slack(channel, text)`) als optionalen Wrapper.
6. **LaunchAgent** für den Channel.
7. **Doku** im Tutorial.

Aufwand pro Channel: 1-2 Tage Implementierung + Testing.

## Achse D — Public-Skeleton aufbauen (Sanexio-Geschäftsmodell)

Volle Spec: `specs/cortex-public-skeleton/00_KONZEPT.md`. Hier nur die Roadmap:

### Phase 1 — Vorarbeit (abgeschlossen)

- ✅ Architektur-Refactor P1-P3 abgeschlossen.
- ✅ User-Layer in eigene Files getrennt (`USER.md`, `_rules/user-directives.md`, `medical-domain.md`, `security.md`).
- ✅ Spec-Stub `specs/cortex-public-skeleton/` angelegt.

### Phase 2 — Generalisierungs-Refactor (nächste Welle)

Was zu erledigen ist:
- **`doctor.py` und `tutorial_curator.py` auf Config-Pfade umstellen** — heute hardcoded auf Stracke-Pfade.
- **`tier3.md` Beispiele anonymisieren** oder via Variable einsetzen („Patientenmails" wird zu „medizinische Kommunikation" oder Template-Variable).
- **`CLAUDE.md` Stracke-Notes entfernen** / als generisches Template formulieren.
- **`onboard-device.sh` erweitern** um Auto-Hook-Registration + Auto-Telegram-Bridge-Setup.
- **`doctor`-Skill** als Health-Check-Punkt für die Hook-Registration ergänzen.

Geschätzter Aufwand: 1 Welle (mehrere Tage).

### Phase 3 — Skeleton-Repo

- **Neues GitHub-Repo `Sanexio/cortex-public`** anlegen.
- **Generisches `Nexus/`-Snapshot** committen — ohne `Second Brain/`, ohne `_memory/USER.md`-Content, mit Template-`devices.json`.
- **README + Setup-Doku** schreiben.
- **Erstem Pilot-Teilnehmer** zur Verfügung stellen.

### Phase 4 — Lizenz + Compliance

- **Lizenz-Wahl** finalisieren (AGPL? Eigene Sanexio-Lizenz mit Compliance-Klauseln?).
- **DSGVO-Hinweise** für Teilnehmer-Macs (sie sind verantwortlich für die Daten, die sie in ihren Vault legen).
- **Telemetrie/Opt-in** für anonymisiertes Crash-Reporting.
- **Update-Policy** (rolling vs. tagged releases).

### Phase 5 — Production Launch

- **Public Launch** an erste Mediziner-Gruppe.
- **Wartungs-Pipeline:** Stracke kuratiert, Public-Repo aktualisiert sich, Teilnehmer pullen Updates.

### Was Teilnehmer-Macs **nicht** bekommen

- Zugang zum Stracke-Privat-Nexus.
- Stracke-Tailnet.
- `Second Brain/`-Vault-Inhalt.
- Praxis-Domain-Wissen (`_rules/medical-domain.md` ist im Public-Skeleton leer/Template).
- SmartQ-Integration.

### Was Teilnehmer **selbst mitbringen müssen**

- Eigener GitHub-Account + Fork des Public-Repos.
- Eigener Anthropic-API-Key.
- Eigener Tailscale-Account (optional, für Multi-Mac-Setup).
- Eigener Telegram-Bot (optional).
- Eigene Vault-Inhalte (Tutorials, Regeln je nach Fachbereich).

## Achse E — Memory + Self-Learning aktivieren

Aus **[[06 Selbstlernendes System]]** §„Konkrete Optimierungs-Hebel":

### Hebel 1 — Auto-Capture am Welle-Ende

`session-end`-Skill triggert automatisch `capture-lesson` für jeden ungeanker'ten Bullet. Aufwand: ~50 Zeilen Python in `session_end.py`.

### Hebel 2 — Cross-Device-Memory-Sync

Drei Varianten (siehe Modul 06):
- Symlink-Ansatz (Risiko: Mac-spezifische Pfade).
- Periodischer Sync-Job (empfohlen: Skript kopiert Memory-Files in Vault → committet).
- Centralized Memory-DB (Connexio-Read-Replicas).

Aufwand: 1 Welle pro Variante.

### Hebel 3 — Semantischer Recall

Embeddings statt Keyword-Match. Anthropic stellt keine Embedding-API; Alternativen: OpenAI text-embedding-3, lokal via Ollama. Speicherung als FTS5-Tabelle + Vektor-Index (sqlite-vss).

Eigene Spec: `specs/memory-semantic-recall/` (anzulegen).

### Hebel 4 — Pattern-Miner produktiv

Wenn Hebel 1+3 stehen: Pattern-Miner als nightly-Cron-Job. Erkennt wiederkehrende Muster → werden im System-Block injiziert.

### Hebel 5 — Skill-Ketten / Workflow-Engine

YAML-Workflows in `agent/workflows/*.yaml`. Drei initiale: welle-ende, session-start, nightly.

### Hebel 6 — Pre-Tool-Use-Pattern-Check

Pre-Tool-Use-Hook könnte vor risikoreichen Operationen (OCR, WP-CLI, Pre-Pull) auf bekannte Bug-Patterns (GF-001..007) prüfen und warnen.

## Sicherheit — die Härtungs-Achse

### Bestehende Schutzschichten

| Schicht | Was sie schützt |
|---|---|
| **Tier-3-Hardstops** (`agent/modes/tier3.md`) | Secrets, Geld, externe Empfänger. |
| **R0-R3-System** (`_rules/risk-levels.md`) | Schreibzugriff-Levels. |
| **Connexio READABLE_ROOTS** (`agent/connexio/kernel.py`) | Was andere KIs lesen dürfen. |
| **Connexio BLOCKED_FILE_PATTERNS** | Niemals erreichbare Pfade. |
| **Connexio BLOCKED_TAGS** | Sensible Tags aus Suche filtern. |
| **`.gitignore`** | Sekrete + Datenbanken niemals in Git. |
| **macOS-Permissions** | Filesystem-Boundary. |
| **Tailscale-ACL** | Wer im Mesh mit wem darf. |

### Offene Sicherheits-Themen

1. **API-Key-Rotation-Politik** — heute kein Rotations-Plan. Empfehlung: alle 90 Tage rotieren, mit Rotation-Audit.
2. **Backup-Strategie** — Phoenix-Snapshot-Branch existiert, aber kein periodisches Off-Site-Backup. Empfehlung: GitHub als Source + zusätzlicher lokaler Tarball alle 30 Tage.
3. **DSGVO-Audit** — vor Sanexio-Public-Launch nötig.
4. **Token-Logging-Audit** — sicherstellen, dass `_memory/logs/` keine Tokens enthält (Sanitizer-Erweiterung).
5. **MCP-Server-Whitelist** — `~/.claude.json` registriert MCP-Server; bei Aktualisierung der MCP-Bibliotheken Vertrauensprüfung.

### Drift-Schutz

- **`doctor`-Skill** läuft täglich? — Nein, manuell. **Aktivierungs-TODO:** nightly-Cron via `doctor --strict` mit Telegram-Alarm bei Failure.
- **`tutorial-curator`** weekly? — Im Repo als Recipe, aber nicht aktiviert.
- **Sanitizer** nightly? — Recipe vorhanden, nicht aktiviert.

Alle drei sind im `agent/cron/recipes/`-Verzeichnis als TOML, aber der LaunchAgent `com.cortex.phoenix-cron.plist` ist nicht installiert. **Aktivierungs-TODO** (Phase-2-Public-Skeleton-Vorbereitung).

## Konkrete nächste Schritte — priorisiert

### Priorität 1 (für M5-eigenen Stracke-Cortex)

| # | Maßnahme | Aufwand |
|---|---|---|
| 1 | **Multi-Device-Telegram-Bug fixen** auf allen Macs | mittel |
| 2 | **Hook-Registration** auf den anderen Macs nachziehen (Cluster-Mini-02, SSMD-MBP, Mac-Studio, Cluster-Mini-04) | gering |
| 3 | **Phoenix-Cron-LaunchAgent installieren** (nightly-sanitizer, tutorial-curator-weekly) | mittel |
| 4 | **Auto-Capture-Lesson am Welle-Ende** implementieren | mittel |

### Priorität 2 (Public-Skeleton Phase 2)

| # | Maßnahme | Aufwand |
|---|---|---|
| 5 | **`onboard-device.sh` erweitern** (Hook-Registration + Telegram-Setup) | mittel |
| 6 | **`doctor`-Skill** um Hook-Check erweitern | gering |
| 7 | **`doctor.py` und `tutorial_curator.py`** auf Config-Pfade | mittel |
| 8 | **`tier3.md` Beispiele anonymisieren** | gering |
| 9 | **`CLAUDE.md` Stracke-Notes raus**, generisch machen | gering |

### Priorität 3 (Self-Learning aktivieren)

| # | Maßnahme | Aufwand |
|---|---|---|
| 10 | **Cross-Device-Memory-Sync** (periodischer Sync-Job) | mittel |
| 11 | **Semantischer Recall** (Embeddings) | groß |
| 12 | **Skill-Trigger-Annotationen + Workflow-Engine** | mittel |
| 13 | **Pattern-Miner produktiv** als nightly-Job | mittel |

### Priorität 4 (Public-Skeleton Phase 3-5)

| # | Maßnahme | Aufwand |
|---|---|---|
| 14 | **`Sanexio/cortex-public`-Repo** anlegen | gering |
| 15 | **README + Setup-Doku** für Teilnehmer | mittel |
| 16 | **Lizenz + DSGVO-Audit** vor Launch | groß |
| 17 | **Pilot-Teilnehmer** onboarden | mittel |
| 18 | **Public Launch** | groß (Marketing + Support) |

## Was du mit diesem Modul jetzt kannst

- Du kennst die 5 Erweiterungs-Achsen (Mac, Skill, Channel, Public-Skeleton, Memory).
- Du verstehst, wie ein neuer Mac via `onboard-device.sh` + manuelle Nachschritte aufgenommen wird.
- Du weißt, wie ein neuer Skill aufgebaut ist (Python-Decorator-Pattern).
- Du kennst die Public-Skeleton-Roadmap (Phasen 1-5).
- Du hast 6 konkrete Hebel zur Aktivierung des Self-Learning-Systems.
- Du kennst die offenen Sicherheits-Themen und die priorisierte To-Do-Liste.

## Verwandte Tutorials

- **[[06 Selbstlernendes System]]** — die Hebel zur Self-Learning-Aktivierung
- **[[09 Self-Learning-Layer]]** — wie Skills gebaut werden
- **[[10 Channel-Router]]** — wie neue Channels eingebaut werden
- **[[12 Externe Dienste]]** — wovon Cortex abhängt
- **[[14 Notfall und Recovery]]** — wenn etwas in der Erweiterung schiefgeht
- `specs/cortex-public-skeleton/00_KONZEPT.md` — autoritative Public-Skeleton-Spec
- `specs/architecture-refactor-2026-05/00_AUDIT.md` — Audit mit Optimierungs-Befunden
