---
title: Datei-Atlas
domain: cortex
modul: 02
level: einsteiger-bis-fortgeschritten
status: kanonisch
---

# 02 — Datei-Atlas

> **Antwort in einem Satz:** Dieses Modul listet jede Datei und jeden Ordner unter `~/Cortex/Nexus/`, der das System steuert oder erinnert — was sie tut, wer sie liest oder schreibt, und was kaputtgeht, wenn sie fehlt.

Behandele dieses Modul **wie ein Nachschlagewerk**. Lies es nicht von vorn nach hinten — komm hierhin zurück, wenn du in einem anderen Tutorial auf einen Pfad stößt und wissen willst, was dahintersteckt. Reihenfolge ist nach Schichten (analog zu **[[01 Architektur und Schichten]]**), nicht alphabetisch.

Reihenfolge und Inhalt spiegeln den Stand nach dem Architektur-Refactor wider (Spec-Wellen unter `specs/architecture-refactor-2026-05/`).

---

## A — Root-Ebene (`~/Cortex/Nexus/`)

Diese Dateien liegen direkt im Nexus-Stamm.

| Datei | Rolle | Wer liest? Wer schreibt? | Wenn fehlt: |
|---|---|---|---|
| `CLAUDE.md` | **Session-Einstieg.** Erste Datei, die jede KI-Session liest. Init-Workflow, Stack-Übersicht, Mode-Switch. | Jede KI bei Session-Start; manuell gepflegt. | KIs starten ohne Kontext, machen Anfänger-Fehler. |
| `SYSTEM_MAP.md` | **Karten-Index.** „Wo finde ich was" — Pointer-Tabelle auf alle Hauptpfade. | KI bei Orientierung; manuell gepflegt. | Suchaufwand vervielfacht sich. |
| `HANDOVER_PHOENIX.md` | **Snapshot-Doku** des Phoenix-Reset 2026-05-08/09. Historisch. | Notfall-Rollback; sonst nicht aktiv. | (Geringer Verlust — historische Doku.) |
| `PHOENIX_RESUME.md` | **Live-Roadmap-Trigger** für „Phoenix fortsetzen". | Bei diesem Standard-Befehl. | Sprint-Stand ist unklar. |
| `nexus-sync.sh` | **Auto-Sync-Skript.** LaunchAgent ruft es alle 5 Min auf. | macOS-launchd via `com.cortex.nexus-sync.plist`. | Macs driften auseinander. Detail: **[[07 Multi-Device-Sync]]**. |
| `com.cortex.nexus-sync.plist` | **LaunchAgent-Vorlage.** Wird einmal nach `~/Library/LaunchAgents/` kopiert. Aktiviert den Auto-Sync alle 5 Min + bei Boot. | macOS-launchd. | Kein Auto-Sync. |
| `pyproject.toml` + `uv.lock` | **Python-Projektmanifest** (Format: TOML = einfache Konfig-Sprache mit Schlüssel-Wert-Paaren). Definiert `cortex-agent`-CLI, Dependencies. | `uv` (Python-Toolchain). | `cortex-agent`-Befehl funktioniert nicht. |

### Erklärung: Phoenix

**Phoenix war eine einmalige Migration am 2026-05-08/09.** Damals wurde das alte Nexus-Steuerwerk komplett zurückgesetzt und durch die aktuelle zweischichtige Architektur (Agent + Gateway) ersetzt. Die Dateien mit „Phoenix" im Namen (`HANDOVER_PHOENIX.md`, `PHOENIX_RESUME.md`) sind die Verbleibsel dieser Migration:

- `HANDOVER_PHOENIX.md` ist die historische Bedienungsanleitung zur Migration selbst.
- `PHOENIX_RESUME.md` ist eine Live-Roadmap, die per Skript aktualisiert wird, und trägt nur noch aus historischen Gründen das Wort „Phoenix" im Namen.

Die Migration ist abgeschlossen, aber der Code lebt damit weiter — daher die Files. Im Public-Skeleton würden sie als historisches Archiv markiert oder entfernt.

---

## B — Regeln (`_rules/`)

Das **gesamte Regelwerk** für KI-Verhalten. Nach dem Architektur-Refactor in fokussierte Files aufgeteilt — schlanker Index plus spezialisierte Detail-Files.

### Pflicht-Lesung

| Datei | Rolle |
|---|---|
| `AUTONOMY_CONTRACT.md` | **Schlanker Index** (rund 70 Zeilen): Grundsatz + Mode-Matrix + Hierarchie + Verweise auf Detail-Files. |
| `glossary.md` | **Begriffsdefinitionen** (~25 Begriffe, ~150 Zeilen). R0–R3, Hook, Lease, FTS5, MCP, Tier-3, Welle, Phoenix, Skill, JSON, Wikilink etc. |

### Spezialisierte Regel-Files (on-demand)

| Datei | Worum's geht |
|---|---|
| `risk-levels.md` | R0–R3 mit Beispielen. |
| `modes.md` | Mode × Risiko-Matrix + Switch-Befehle. |
| `stop-conditions.md` | Alle Stop-Trigger (mode-übergreifend + mode-spezifisch). |
| `tasks.md` | Task-State-Machine + Pflichtfelder + Pre-Flight-Checks. |
| `verification.md` | Was vor `done` laufen muss. |
| `retention.md` | Runtime-Artefakt-Retention (Logs, Queues, Audit-TTL). |
| `ai-cooperation.md` | Claude × Codex Peer-Modell. |
| `multi-ai-boundaries.md` | Andere KIs (Cursor, Cline, …) am Nexus-Kern. |
| `lesson-anchors.md` | Persistenz-Anker für Welle-Ende-Lessons (Single Source). |
| `sync-policy.md` | Runtime-Aggregat aller Multi-Device-Sync-Regeln. |

### Stracke-spezifische Files (private; im Public-Skeleton ausgetauscht)

| Datei | Worum's geht |
|---|---|
| `user-directives.md` | Pauschal-Freigabe innerhalb `~/Cortex/` (User-Direktive 2026-05-09). |
| `security.md` | Token-Handling, Secrets-Hygiene, Logging-Regeln. |
| `medical-domain.md` | Praxisgemeinschaft-Boundary, BLOCKED_TAGS, DSGVO, SmartQ-Bezug. |

### Kompatibilitäts-Pointer

| Datei | Zweck |
|---|---|
| `ai-cooperation.md` | Pointer-Stub. Inhalt in `ai-cooperation.md`. |
| `multi-ai-boundaries.md` | Pointer-Stub. Inhalt in `multi-ai-boundaries.md`. |

---

## C — Memory und State (`_memory/`)

Hier liegt alles, was das System **erinnert**. Detail: **[[05 Memory in 4 Schichten]]**.

### Narrativ (gitversioniert, auf jedem Mac identisch)

| Datei | Rolle |
|---|---|
| `USER.md` | **Dein Profil** (post-Refactor schlank: nur Rolle, Arbeits-Präferenzen, Domänen-Kontext). Geräte-Tabelle, Security und Medical-Domain sind ausgegliedert. |
| `KNOWLEDGE.md` | **Vault-Pointer-Index** zum Second Brain. |
| `golden-rules.md` | **Destillierte Goldene Regeln** (Tier-3-Hardstops + Wiederholungsfehler GF-001..GF-007 + LL→R-Mapping). Single Source für `get_golden_rules()` über Connexio-MCP. |

### Datenbanken (gitignored — pro Mac lokal)

JSON-Erklärung: JSON („JavaScript Object Notation") ist ein textuelles Format für strukturierte Daten mit Schlüssel-Wert-Paaren und Listen. Beispiele: `{"name": "Stracke", "macs": ["M5", "Studio"]}`. Weit verbreitet als Austauschformat.

| Datei | Schema | Funktion |
|---|---|---|
| `memory.db` | SQLite FTS5 (Full-Text-Search v5): sessions, patterns, skill_runs, user_facts | **Volltextsuche** über Lernerinnerungen, Skill-Aufrufe, Fakten. |
| `tasks.db` | SQLite | Lokaler Task-Spiegel zu Connexio. |
| `leases.db` | SQLite | Lokaler Lease-Store (Lease = Schreibsperre auf Repo+Scope mit Ablaufzeit). |

**Warum pro Mac lokal?** Diese Dateien wachsen schnell und unterscheiden sich pro Mac (welche Sessions liefen, welche Skills aufgerufen). Wenn sie via Git synchronisiert würden, würde jeder Sync sie ständig mit-pushen — riesige Diffs, viele Konflikte. Stattdessen: die strukturell relevanten Inhalte (z.B. Task-Status) werden zusätzlich als JSON-Mirror committet (siehe nächste Sektion).

### JSON-Mirrors (gitversioniert!)

| Pfad | Rolle |
|---|---|
| `tasks-mirror/task-<id>.json` | **Cross-Device-Tasks.** Jede Task wird zusätzlich als JSON-Datei committet, damit sie auf allen Macs sichtbar ist. Schema: id, title, assigned_to, repo, scope, risk_level, acceptance_criteria, reviews, status. |
| `leases-mirror/` (vorgesehen) | Analog für Leases. |

### Logs & Audit (gitignored)

| Pfad | Rolle |
|---|---|
| `logs/nexus-sync.log` | Sync-Skript-Log, alle 5 Min ein Eintrag. |
| `connexio-audit.log` | Append-only-Audit aller Connexio-Operationen. |
| `audit/connexio-write.jsonl`, `connexio-lease.jsonl` | JSONL-Audit pro Operationstyp. |
| `health/sync-drift.json` | Maschinenlesbarer Drift-Status. |

### Approval-Marker

| Pfad | Funktion |
|---|---|
| `approvals/.enforce` | Leere Datei. Wenn vorhanden: harter Approval-Modus für R2-Pushes. |
| `approvals/<task-id>.approved` | Freigabe-Marker für eine spezifische Task. |

### Sonstige

| Pfad | Rolle |
|---|---|
| `pending-questions.md` | Whitelisted: Fragen die der Agent hinterlegt hat. |
| `pending-instructions.md` | Whitelisted: Anweisungen für die nächste Session. |

---

## D — Self-Learning-Layer (`agent/`, Python)

Die **Python-Schicht**. Wenn du wissen willst „wer entscheidet was und mit welchem Code", schau hier.

### Core

| Datei | Rolle |
|---|---|
| `cli.py` | Typer-CLI. Entry-Points: `cortex-agent run/bootstrap/mode/skill/memory`. |
| `loop.py` | Die eigentliche Schleife. Baut System-Block, ruft LLM, gibt Antwort zurück. |

### Modes

| Datei | Rolle |
|---|---|
| `modes/autonomy.md` | Mode-Briefing für Autonomy. Vom Hook injiziert. |
| `modes/safe.md` | Mode-Briefing für Safe. Vom Hook injiziert. |
| `modes/tier3.md` | **Single Source der Tier-3-Hardstops.** Vom Hook IMMER injiziert. |

### Skills (`agent/skills/`)

| Datei | Rolle |
|---|---|
| `engine.py` | Skill-Discovery + Execution. Lädt alle `@skill`-dekorierten Python-Funktionen. |
| `INDEX.md` | **Auto-generierter Index** aller 13 builtin-Skills mit Zweck und Aufruf-Beispielen. |

**Builtin-Skills** (alle aufrufbar via `cortex-agent skill run <name>`):

| Skill | Funktion |
|---|---|
| `capture-lesson` | Persistiert eine Lesson als Claude-Memory-Datei. |
| `connexio` | Read-Wrapper um Connexio-Kernel. |
| `cron` | Phoenix-Cron — Recipe-Loader + Tick + Tier-3-Token-Verwaltung. |
| `curator` | Memory-Curation (facts, sessions, pending-Items). |
| `doctor` | **10+-Punkte-Health-Check.** Wichtigster Skill für Sanity-Checks. |
| `outbound` | Connexio Outbound — externe KIs aufrufen. |
| `pattern-miner` | Pattern-Extraktion aus Sessions (experimentell). |
| `sanitizer` | Memory-Wachstumskontrolle, Log-Rotation, TTL-Migration. |
| `scheduler` | LaunchAgent-Status anzeigen. |
| `session-end` | Welle-Ende-Debrief in Memory schreiben. |
| `session-start` | Session-Start-Digest. |
| `spawn` | Spawn-Queue füllen/inspizieren. |
| `tutorial-curator` | Vault-Drift-Audit für 30 Tutorials. |

### Connexio (`agent/connexio/`)

Detail: **[[08 Connexio]]**. Hier nur die Dateien:

| Datei | Rolle |
|---|---|
| `kernel.py` | Zentrale Read-/Write-Logik. |
| `task_store.py` | Task-CRUD (SQLite + JSON-Mirror). |
| `lease_store.py` | Lease-CRUD mit TTL. |
| `http_server.py` | Loopback-REST auf `localhost:7766`. |
| `mcp_server.py` | MCP-Server für andere KIs. |
| `roadmap.py` | Live-Roadmap-Generator für PHOENIX_RESUME.md. |
| `session_digest.py` | Session-Start-Digest. |
| `spawn_queue.py`, `spawn_watcher.py`, `spawn_forward.py` | Inbound-Queue-Stack. |
| `inbox_notify.py` | Notifications an User. |
| `audit.py` | Append-only-Audit, fail-soft. |

### Memory-Subsystem (`agent/memory/`)

| Datei | Rolle |
|---|---|
| `store.py` | SQLite-FTS5-Wrapper. |
| `golden_rules.py` | **Renderer.** Parst `agent/modes/tier3.md` als Single Source für die Tier-3-Liste und fügt die Wiederholungsfehler-Patterns hinzu. |
| `user_profile.py` | Lädt `USER.md` als Python-Objekt. |
| `summarizer.py` | Session-Zusammenfassungen für memory.db. |

### Providers (`agent/providers/`)

| Datei | Rolle |
|---|---|
| `base.py` | Abstract Provider-Schnittstelle. |
| `anthropic.py` | Anthropic-SDK-Wrapper. Nutzt `ANTHROPIC_API_KEY`. |

### Multi-AI-Outbound (`agent/connexio_outbound/`)

| Datei | Rolle |
|---|---|
| `anthropic_adapter.py` | Primary (Claude). |
| `openai_adapter.py` | Fallback (Codex-Expertise). |
| `gemini_adapter.py` | Multi-Modal-Fallback. |
| `ollama_adapter.py` | Offline-LLM. |

### Cron (`agent/cron/`)

| Pfad | Rolle |
|---|---|
| `runner.py` | TOML-Recipe-Runner. |
| `recipes/*.toml` | Einzelne Cron-Jobs (z.B. `nightly-sanitizer.toml`, `tutorial-curator-weekly.toml`). |

---

## E — Channel-Router (`gateway/`, TypeScript/Bun)

| Datei | Rolle |
|---|---|
| `src/gateway.ts` | Router-Klasse. Command-Registry, Channel-Verwaltung, Dispatcher. |
| `src/types.ts` | TypeScript-Interfaces. |
| `src/auth.ts` | Pairing-Store (Whitelisting eingehender Devices). |
| `src/sandbox.ts` | Sandbox-Implementierung (heute Bash-Subshell, später Docker/SSH). |
| `lib/spawn-queue.ts` | TypeScript-Spiegel der Python-Spawn-Queue. |
| `package.json` | Bun-Manifest. `bun run telegram` startet die Telegram-V3-Bridge. |

---

## F — Tools (`tools/`)

Hooks und Helfer-Skripte.

### Mode-Hook (zentral!)

| Datei | Rolle |
|---|---|
| `cortex-mode/bin/inject.sh` | **Der UserPromptSubmit-Hook.** Liest Mode-State, lädt Mode + Tier-3, ruft Helper, kombiniert zu `additionalContext`-JSON. Wird ausgeführt, wenn er in `~/.claude/settings.json` registriert ist. |
| `cortex-mode/bin/local_first_discovery.py` | Helper #1. Trigger: Prompt enthält „clone", „repo", „wordpress" — verhindert dass die KI ein Repo neu klont, wenn es lokal schon liegt. |
| `cortex-mode/bin/lesson_audit.py` | Helper #2. Trigger: Welle-Ende-Phrasen — rendert Persistenz-Audit. |

### Telegram-Brücke

| Pfad | Rolle |
|---|---|
| `telegram-bridge/` | Node.js-MCP-Server für Telegram-V3. |
| `telegram-inbox-hook/` | Hook für Telegram-Inbox-Verarbeitung. |

### Operativ

| Pfad | Rolle |
|---|---|
| `cortex-doctor/bin/` | Helfer für `doctor`-Skill. |
| `cortex-cron/lib/parse-recipe.py` | TOML-Recipe-Parser. |
| `cortex-skills/` | Skill-Discovery-CLI. |
| `session-start-digest/digest.sh` | Digest-Renderer beim Session-Start. |
| `session-search/` | Volltextsuche über Session-Archive (FTS5). |

---

## G — Scripts (`scripts/`)

| Datei | Rolle |
|---|---|
| `onboard-device.sh` | **Neuen Mac in den Cortex-Verbund aufnehmen.** Cloned Nexus, installiert `.venv`, registriert in `devices.json`, startet Tailscale-Login. Aufruf: `scripts/onboard-device.sh <hostname> <role>`. |

---

## H — Skills auf Top-Level (`skills/`)

Top-Level-Skill-Dateien (YAML-Format, `.skill`-Paket-Format für Claude Code). **Nicht** zu verwechseln mit den Python-Skills in `agent/skills/builtin/` — disambiguiert in `Nexus/skills/README.md`.

| Datei | Funktion |
|---|---|
| `21st-dev-magic.skill` | Linting/Formatting-Tooling. |
| `doc-workflow.skill` | Obsidian → Markdown → PDF-Pipeline. |
| `file-renamer.skill` | Batch-Datei-Umbenennung. |
| `frontend-design.skill` | Frontend-Design-Assist. |
| `gdrive-sync.skill` | Google-Drive-Sync + Backup. |
| `smartq-dashboard.skill` | SmartQ-Praxis-Accounting. |
| `ui-ux-pro-max.skill` | UX-Audit + A/B-Test. |

---

## I — Specs (`specs/`)

**Konzepte vor Umsetzung.** Jede Welle/jedes Feature bekommt einen Ordner mit `00_KONZEPT.md`.

| Spec | Worum's geht | Status |
|---|---|---|
| `architecture-refactor-2026-05/` | Audit + Refactor-Plan, der zum aktuellen Stand führte (P1-P3). | Implementiert. |
| `cortex-public-skeleton/` | **Sanexio-Geschäftsmodell-Architektur.** Public vs. Private Trennung. | Stub. |
| `cortex-lean-v3/` | Architektur-Reset gegen Drift (State-First, Lease, Memory-TTL). | Teilimplementiert. |
| `lesson-persistence/` | Lesson-Capturing + Persistierung. | Implementiert. |
| `local-first-discovery/` | Lokale Repos vor SSH/Clone bevorzugen. | Implementiert. |
| `sync-alarm-escalation/` | Re-Alarm + kritischer Telegram-Push bei persistentem Drift. | Stub. |
| `nexus-sync-reliability/` | nexus-sync.sh-Robustheit. | Implementiert. |
| `claude-codex-cooperation/` | Multi-AI-Vertrag. | Implementiert. |
| `multi-device-multi-ai/` | Multi-Device + Multi-AI-Architektur. | Implementiert. |

---

## J — Konfiguration (`.config/`)

| Datei | Rolle |
|---|---|
| `devices.json` | **Single-Source-of-Truth für Geräte.** Pro Mac: hostname, chip, OS, role, projects-Liste, Tailscale-Mesh-Daten. |
| `heartbeats/<host>.heartbeat` | Pro Mac: letzter Sync-Timestamp. Vom nexus-sync.sh gepflegt. |
| `.last_sync_local` | Lokaler Sync-Tracker. |
| `settings-git-deny-snippet.json` | Git-Config-Snippet für andere KIs. |
| `tailscale-acl.json` | Tailscale-ACL-Template. |

---

## K — Vault (`Second Brain/`)

Der Obsidian-Vault. **Liegt innerhalb Nexus**, wird mit dem Git-Sync mitsynchronisiert.

```
Second Brain/
├── _MOC Wissen.md                ← Master-Index
├── 00 Kontext                    ← Dialog mit Claude
├── 10 Projekte                   ← pro Projekt eine Index-Datei
├── 15 Workflows                  ← bewährte Abläufe
├── 30 Tutorials                  ← Wissensbasis (DIESES Tutorial liegt hier)
├── 40 Regeln                     ← Praxis-Regeln (R-001 …)
├── 50 Fehler                     ← Fehlerprotokolle (F-001 …, GF-001 …)
├── 60 Tools                      ← Notizen zu eingesetzten Werkzeugen
├── 70 Glossar                    ← Begriffsdefinitionen
├── 80 Templates                  ← Obsidian-Templates
├── 90 Sessions                   ← Session-Notizen / Lessons-Learned
├── DASHBOARD.md                  ← Live-Status
└── HOME.md                       ← Vault-Startseite
```

### Wikilinks brechen — was bedeutet das?

„Wikilinks" sind die `[[Ziel]]`-Verlinkungen im Obsidian-Vault. Beispiel: `[[03 Autonomy und Safe Mode]]` zeigt im Lesemodus als anklickbarer Link, wenn eine Datei mit diesem Namen existiert. **„Wikilinks brechen"** heißt: das Linkziel existiert nicht (mehr) — die Datei wurde umbenannt, gelöscht, oder der Name war von Anfang an falsch. Der Skill `tutorial-curator` findet solche Broken-Links beim Vault-Audit.

---

## L — Archiv (`_archive/`)

| Pfad | Rolle |
|---|---|
| `phoenix-pre-reset/launchagents-m5/` | LaunchAgent-Snapshots vom M5 vor Phoenix. |
| Vor-Reset-Branch-Backup | Auf GitHub als `pre-phoenix-reset-2026-05-08`. Notfall-Rollback via `git checkout`. |

---

## M — Bibliothek (`_lib/`)

Wiederverwendbare Helfer für Werkprojekte.

| Pfad | Rolle |
|---|---|
| `pdf/` | PDF-Verarbeitung. |
| `ocr/` | OCR-Pipelines. |
| `validate/` | Report-Validierung. |
| `utils/` | Dateioptimierung, Rechnungs-Rename. |
| `steuer/` | Cashflow-Kategorisierung, Buchhaltungs-Regeln. |
| `read_odt.py` | OpenDocument-Reader. |

---

## N — Außerhalb Nexus (`~/Cortex/projects/`)

Werkprojekte. Liegen **neben** Nexus, jeweils als eigene Git-Repos.

| Pfad | Rolle |
|---|---|
| `_ai-cooperation-outbox/` | Übergabe-Inbox für andere KIs. |
| `Cortex-Web/` | z.B. praxis-webseite. |
| `ARCHIV/` | Alte Projekt-Stände. |

---

## O — LaunchAgents

| Datei | Status |
|---|---|
| `~/Library/LaunchAgents/com.cortex.nexus-sync.plist` | **Aktiv.** Sync-Daemon, alle 5 Min, beim Boot. |
| `~/Library/LaunchAgents/com.cortex.phoenix-cron.plist` | Stub (geplant) — Recipe-Runner. |

---

## P — Claude-Konfiguration (`~/.claude/`)

| Pfad | Rolle |
|---|---|
| `settings.json` | Claude-Code-Einstellungen. **Enthält die rechnerlokale Hook-Registration** für `inject.sh` — wird durch `scripts/onboard-device.sh` gesetzt, auf Bestands-Rechnern einmal manuell nachzuziehen. |
| `state/cortex-mode.json` | Mode-State-File. Schema: `{mode, since, host, set_by}`. |
| `projects/<slug>/memory/` | Per-Projekt-Memory (Markdown mit Frontmatter). |
| `projects/<slug>/<session>.jsonl` | Session-Transkripte. |

---

## Wenn du jetzt eine konkrete Datei suchst:

- **„Welche Datei steuert was Claude darf?"** → `_rules/AUTONOMY_CONTRACT.md` (Index) verweist auf die Detail-Files in `_rules/`.
- **„Wo ist die Tier-3-Liste?"** → `agent/modes/tier3.md` (Single Source).
- **„Wo ist der Sync konfiguriert?"** → `nexus-sync.sh` + `com.cortex.nexus-sync.plist`.
- **„Wo schreibt Claude seine Lessons?"** → `~/.claude/projects/<slug>/memory/feedback_*.md`.
- **„Wer kennt meine Geräte?"** → `.config/devices.json`.
- **„Wie heißt mein Telegram-Bot?"** → `@sanexio_bot` (in `tools/telegram-bridge/`).
- **„Wo liegt die FTS5-DB?"** → `_memory/memory.db` (gitignored, pro Mac).
- **„Welche Skills kann ich aufrufen?"** → `cortex-agent skill list` oder `agent/skills/INDEX.md`.
- **„Was ist heute der Sprint-Stand?"** → `PHOENIX_RESUME.md`.
- **„Wie soll der Public-Skeleton aussehen?"** → `specs/cortex-public-skeleton/00_KONZEPT.md`.

## Verwandte Tutorials

- **[[01 Architektur und Schichten]]** — die konzeptuelle Sicht
- **[[05 Memory in 4 Schichten]]** — Tiefenblick auf `_memory/`
- **[[09 Self-Learning-Layer]]** — Tiefenblick auf `agent/`
- **[[10 Channel-Router]]** — Tiefenblick auf `gateway/`
- **[[13 Slash-Commands und CLI]]** — was du am Terminal tippen kannst
