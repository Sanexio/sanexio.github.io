---
title: Hooks und Mode-Injection
domain: cortex
modul: 11
level: fortgeschritten
status: kanonisch
---

# 11 — Hooks und Mode-Injection

> **Antwort in einem Satz:** Hooks sind **Skripte, die Claude Code automatisch bei bestimmten Ereignissen ausführt** — der zentrale Cortex-Hook (`inject.sh`) läuft bei jedem Prompt-Submit und prepended Mode-Block + Tier-3 + Helper-Outputs in den Kontext; ohne registrierten Hook hat die gesamte Mode-Architektur keine Wirkung, weil der Modus zwar gesetzt ist, aber nie in den Kontext gelangt.

In diesem Modul lernst du **was ein Hook ist**, **welche Hook-Events Claude Code kennt**, **wie der `inject.sh` konkret arbeitet** und **wie du auf weiteren Macs den Hook registrierst**.

## Was ein Hook ist

Ein **Hook** ist ein Skript, das Claude Code automatisch bei einem bestimmten **Event** ausführt. Hook-Events sind Punkte im Claude-Code-Lebenszyklus, an denen externer Code eingehakt werden kann.

### Wichtige Hook-Events

| Event | Wann es feuert | Typischer Use-Case |
|---|---|---|
| `UserPromptSubmit` | Du sendest einen Prompt ab. | Kontext injizieren (z.B. aktueller Mode). |
| `PreToolUse` | Bevor ein Tool aufgerufen wird. | Pre-Check, evtl. blockieren. |
| `PostToolUse` | Nach erfolgreichem Tool-Aufruf. | Auto-Format, Log. |
| `SessionStart` | Eine Session startet. | Begrüßung, Health-Check. |
| `Stop` | Claude beendet seine Antwort. | Drift-Check, Auto-Commit. |
| `PreCompact` / `PostCompact` | Vor/nach Conversation-Kompaktierung. | Wichtige Info bewahren. |

Im Cortex nutzen wir heute **nur `UserPromptSubmit`** (für die Mode-Injection). Weitere Hooks (PostToolUse für Auto-Format, Stop für Drift-Audit) sind möglich, aber nicht aktiv.

### Wie Claude Code Hooks aufruft

Eingetragen in `~/.claude/settings.json`:

```json
{
  "hooks": {
    "UserPromptSubmit": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "bash $HOME/Cortex/Nexus/tools/cortex-mode/bin/inject.sh",
            "timeout": 10
          }
        ]
      }
    ]
  }
}
```

Beim Prompt-Submit:
1. Claude Code liefert eine JSON-Eingabe an stdin: `{"hook_event_name": "UserPromptSubmit", "prompt": "...", "session_id": "..."}`.
2. Das Skript liest stdin, verarbeitet, gibt JSON auf stdout zurück.
3. Claude Code parsed die Ausgabe und nutzt das Feld `hookSpecificOutput.additionalContext` als zusätzlichen Prompt-Kontext.

### Token-Budget

Der injizierte Block landet im Conversation-Kontext jedes Prompts. Für `inject.sh` heute: ~3 KB (~750 Tokens). Bei Helper-Triggern: +1-2 KB.

## Die häufigste Fehlerquelle — Hook nicht registriert

**Symptom:** Der Anwender berichtet wiederholt, der Autonomy-Modus sei nicht aktiv — Claude fragt trotz `mode: autonomy` ständig nach.

**Diagnose-Sequenz:**

```bash
cat ~/.claude/state/cortex-mode.json
# → {"mode": "autonomy", ...}  ✓

# Skript existiert?
ls -la ~/Cortex/Nexus/tools/cortex-mode/bin/inject.sh
# → -rwxr-xr-x ✓

# Manueller Skript-Test (Pipe stdin rein, JSON raus erwartet):
echo '{"hook_event_name":"UserPromptSubmit","prompt":"test"}' | bash ~/Cortex/Nexus/tools/cortex-mode/bin/inject.sh
# → 3 KB JSON mit additionalContext ✓

# Hook-Registration in settings.json?
jq -e '.hooks.UserPromptSubmit' ~/.claude/settings.json
# → ERROR: file has no hooks section ✗
```

**Befund-Muster:** `~/.claude/settings.json` enthält keine `hooks`-Sektion. Das Skript ist installiert, aber bei Claude Code nicht angemeldet — wird also nie aufgerufen → Mode-Block nicht injiziert → die Session läuft faktisch ohne Modus-Kontext.

**Fix:** Hook-Eintrag in `~/.claude/settings.json` ergänzen (via `/update-config`-Skill oder manuell). Validierung über `jq -e` muss durchgehen. Verifikation: der erste Prompt nach dem Reload zeigt einen `additionalContext`-Block als `system-reminder` — daran ist sichtbar, dass der Hook ansprang.

**Memory:** `feedback_check_hook_registration.md` dokumentiert die Diagnose-Prozedur und enthält das einzufügende Snippet. Auf jedem Rechner, der noch nicht über `scripts/onboard-device.sh` aufgesetzt wurde, ist diese Registration einmalig nötig.

## `inject.sh` — was er konkret macht

Datei: `~/Cortex/Nexus/tools/cortex-mode/bin/inject.sh`. ~60 Zeilen Bash.

### Ablauf

1. **stdin lesen** — JSON von Claude Code (`HOOK_INPUT="$(cat)"`).
2. **Mode-State auflesen** aus `~/.claude/state/cortex-mode.json`:
   - Wenn File existiert: `mode` via `jq` extrahieren.
   - Wenn File fehlt: **Auto-Init** mit `mode=autonomy`, `set_by=hook-auto-init`, aktueller Hostname, aktueller Timestamp.
3. **Mode-File laden:**
   - `mode=autonomy` → `agent/modes/autonomy.md`
   - `mode=safe` → `agent/modes/safe.md`
4. **Tier-3-File laden** — `agent/modes/tier3.md` (immer, mode-unabhängig).
5. **Optionale Helper** (siehe nächste Sektion).
6. **Alles kombinieren** als `CONTEXT`-Variable, mit `---` als Separator.
7. **JSON ausgeben:**

```bash
jq -n --arg ctx "$CONTEXT" '{
  hookSpecificOutput: {
    hookEventName: "UserPromptSubmit",
    additionalContext: $ctx
  }
}'
```

### Komplette Datei (gekürzt zur Veranschaulichung)

```bash
#!/usr/bin/env bash
set -uo pipefail

NEXUS="$HOME/Cortex/Nexus"
STATE="$HOME/.claude/state/cortex-mode.json"

HOOK_INPUT="$(cat)"

# Auto-Init wenn fehlt
if [[ ! -f "$STATE" ]]; then
  mkdir -p "$(dirname "$STATE")"
  cat > "$STATE" <<EOF
{
  "mode": "autonomy",
  "since": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "host": "$(hostname -s)",
  "set_by": "hook-auto-init"
}
EOF
fi

MODE=$(jq -r .mode "$STATE")

MODE_BLOCK="$(cat "$NEXUS/agent/modes/${MODE}.md")"
TIER3_BLOCK="$(cat "$NEXUS/agent/modes/tier3.md")"

CONTEXT="$MODE_BLOCK"$'\n\n---\n\n'"$TIER3_BLOCK"

# Helper: local-first-discovery
LF_HELPER="$NEXUS/tools/cortex-mode/bin/local_first_discovery.py"
if [[ -f "$LF_HELPER" ]]; then
  LF_OUTPUT="$(printf '%s' "$HOOK_INPUT" | python3 "$LF_HELPER" 2>/dev/null || true)"
  if [[ -n "$LF_OUTPUT" ]]; then
    CONTEXT+=$'\n\n---\n\n'"$LF_OUTPUT"
  fi
fi

# Helper: lesson-audit
LA_HELPER="$NEXUS/tools/cortex-mode/bin/lesson_audit.py"
if [[ -f "$LA_HELPER" ]]; then
  LA_OUTPUT="$(printf '%s' "$HOOK_INPUT" | python3 "$LA_HELPER" 2>/dev/null || true)"
  if [[ -n "$LA_OUTPUT" ]]; then
    CONTEXT+=$'\n\n---\n\n'"$LA_OUTPUT"
  fi
fi

jq -n --arg ctx "$CONTEXT" \
  '{hookSpecificOutput: {hookEventName: "UserPromptSubmit", additionalContext: $ctx}}'
```

### Token-Budget-Konkretisierung

| Block | ~Tokens |
|---|---|
| Mode (autonomy.md oder safe.md) | 480-550 |
| Tier-3 (tier3.md) | 480 |
| local_first_discovery (wenn Trigger) | 200-400 |
| lesson_audit (wenn Trigger) | 200-300 |
| **Gesamt im Normalfall** | **~960** |
| **Mit Helpern** | **bis ~1500** |

## Helper 1 — `local_first_discovery.py`

### Trigger

Skript liest stdin (Hook-JSON), prüft das `prompt`-Feld auf Keywords:

```python
TRIGGER_RE = re.compile(
    r"\b(clone|clonen|repo|repository|wordpress|theme|local|"
    r"praxis-webseite|cortex-web|juvantis|flywheel)\b",
    re.IGNORECASE
)
```

Wenn ein Match: emittiert Markdown-Block. Wenn nicht: leerer Output (Hook fügt dann nichts dazu).

### Was emittiert wird

Eine Liste lokaler Repos + Local-by-Flywheel-WordPress-Sites:

```markdown
## Local-First Discovery

Bevor du `git clone` oder `ssh` machst, prüfe die lokalen Vorkommen:

1. `pwd` und `~/Cortex/projects/`:
   - praxis-webseite: nicht hier
   - cortex-web: ~/Cortex/projects/Cortex-Web
   - …

2. Local-by-Flywheel-Sites (`~/Library/Application Support/Local/sites.json`):
   - gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604.local
     → /Users/ssmd/Local Sites/.../app/public/wp-content/themes/praxiszentrum/
   - …

3. devices.json: welcher Mac hat das Repo lokal?

Quelle: `specs/local-first-discovery/00_KONZEPT.md` §2.
```

### Warum dieser Helper

Häufiger Fehler: KI würde reflexartig `git clone <repo>` machen, obwohl das Repo schon lokal liegt. Mit dem Helper sieht der Agent **zuerst die lokalen Vorkommen** und nutzt sie.

Spec: `specs/local-first-discovery/00_KONZEPT.md`. Anlass: M5-Vorfall 2026-05-13.

## Helper 2 — `lesson_audit.py`

### Trigger

Welle-Ende-Phrasen im Prompt:

```python
TRIGGER_RE = re.compile(
    r"\b(session beenden|welle-?ende|debrief|was gelernt|"
    r"phoenix fortsetzen|fertig fuer heute|welle abschlie)",
    re.IGNORECASE
)
```

### Was emittiert wird

Ein Persistenz-Audit-Block:

```markdown
## Session Persistenz-Audit
- Session-Start: 2026-05-16T08:00:00Z
- Neue Memory-Lessons seit Session-Start: 2 (capture_lesson_xyz, …)
- Neue/geänderte Specs: 1 (architecture-refactor-2026-05)
- CLAUDE.md-Edits: 1
- Skill/Hook/Mode-Erweiterungen: 0
- Pending im Welle-Ende-Debrief: jeder WAS GELERNT-Bullet braucht
  am Zeilen-Ende `-> feedback_<slug>.md`, `-> specs/<slug>/`,
  `-> CLAUDE.md`, `-> hook:<name>` oder `(ephemer)`.
- Autonomy-Mode: warnen und Anker-Check im Debrief sichtbar rendern.
```

### Implementierung

Skript scannt:
- `git log --since=$SESSION_START` (Nexus-Edits seit Session-Anfang).
- `~/.claude/projects/*/memory/*.md` per mtime (neue Memory-Files).
- `specs/*/` (geänderte Konzepte).
- `CLAUDE.md`-Edits.
- `agent/skills/builtin/`, `agent/modes/`, `tools/cortex-mode/` (Skill/Hook/Mode-Änderungen).

### Mode-abhängige Wirkung

- **Autonomy:** Warnt nur (Block sichtbar im Debrief), nicht blockierend.
- **Safe:** Welle-Ende ist **nicht abschließbar** ohne Anker.

Detail: `_rules/lesson-anchors.md`.

## Pro Mac Hook registrieren — Anleitung

### Vorprüfung

```bash
# 1. Skript existiert + ausführbar?
ls -la ~/Cortex/Nexus/tools/cortex-mode/bin/inject.sh
# Erwartet: -rwxr-xr-x

# 2. Skript läuft manuell?
echo '{"hook_event_name":"UserPromptSubmit","prompt":"test"}' \
  | bash ~/Cortex/Nexus/tools/cortex-mode/bin/inject.sh \
  | jq -r '.hookSpecificOutput.additionalContext' \
  | head -10
# Erwartet: Anfang des autonomy.md-Inhalts

# 3. Hook bereits registriert?
jq -e '.hooks.UserPromptSubmit[] | select(.matcher == "") | .hooks[] | select(.type == "command") | .command' \
  ~/.claude/settings.json
# Erwartet wenn vorhanden: "bash $HOME/Cortex/Nexus/tools/cortex-mode/bin/inject.sh"
```

### Wenn Hook fehlt: Eintragen

In `~/.claude/settings.json` die `hooks`-Sektion ergänzen:

```json
{
  "hooks": {
    "UserPromptSubmit": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "bash $HOME/Cortex/Nexus/tools/cortex-mode/bin/inject.sh",
            "timeout": 10
          }
        ]
      }
    ]
  }
}
```

**Wichtig:** existierende Sektionen (`extraKnownMarketplaces`, `theme`, etc.) **nicht überschreiben** — mergen.

### Reload

Claude Code lädt `settings.json` nicht automatisch neu nach Edit. Optionen:

1. **Claude Code neu starten** — sicherste Variante.
2. **`/hooks` öffnen** — UI-Menü, triggert Reload als Nebeneffekt.

Verifikation: der nächste Prompt sollte einen `system-reminder`-Block mit dem Mode-Briefing enthalten — daran ist auch ohne Tooling sichtbar, dass der Hook angesprungen ist.

## Public-Skeleton-Perspektive

Für Teilnehmer-Macs im Sanexio-Geschäftsmodell:

- **`onboard-device.sh`** sollte die Hook-Registration **automatisch** vornehmen. Heute ist das ein manueller Schritt. Erweiterung des Skripts: `~/.claude/settings.json` lesen → `hooks.UserPromptSubmit` ergänzen → schreiben.
- **`doctor`-Skill** sollte den Hook-Registration-Status als Health-Check-Punkt prüfen. Heute fehlt dieser Check; wäre 10 Zeilen Python.

Detail: `specs/cortex-public-skeleton/00_KONZEPT.md`, Phase 2.

## Aktueller Stand — was läuft, was nicht

| Komponente | Status |
|---|---|
| `inject.sh` Skript | ✅ Vorhanden, ausführbar, läuft. |
| `local_first_discovery.py` Helper | ✅ Triggert auf relevante Keywords. |
| `lesson_audit.py` Helper | ✅ Triggert auf Welle-Ende-Phrasen. |
| Hook-Registration auf Anwender-Rechnern | ⚠️ Rechnerabhängig — auf neuen Rechnern automatisch via `onboard-device.sh`, auf älteren Rechnern aktuell noch manuell nachzuziehen. |
| Auto-Registration via `onboard-device.sh` | ⚠️ In Vorbereitung — heute werden Slash-Commands installiert, der Hook-Eintrag in `settings.json` wird parallel ergänzt. |
| Doctor-Check für Hook-Status | ⛔ Ausstehend (etwa zehn Zeilen Python in `agent/skills/builtin/doctor.py`). |
| Weitere Hooks (PostToolUse, Stop) | ⛔ Konzeptuell möglich, nicht aktiv. |

## Was du mit diesem Modul jetzt kannst

- Du verstehst, was ein Hook ist und welche Events Claude Code kennt.
- Du weißt, warum der gesetzte Modus ohne registrierten Hook ins Leere läuft — und wie die Registration aussehen muss.
- Du kannst pro Rechner die Diagnose-Befehle ausführen und den Hook nachregistrieren.
- Du verstehst die beiden Helper (Local-First-Discovery, Lesson-Audit) und wann sie triggern.
- Du kennst den Reload-Trick (`/hooks` öffnen oder Claude Code neu starten).
- Du weißt, dass die Hook-Auto-Registration für die Public-Variante ein offener Härtungs-Punkt ist.

## Verwandte Tutorials

- **[[03 Autonomy und Safe Mode]]** — der Mode-State, den der Hook liest
- **[[04 Tier-3 Hardstops]]** — der Tier-3-Block, der immer injiziert wird
- **[[06 Selbstlernendes System]]** — wie lesson_audit in den Lesson-Persistenz-Flow passt
- **[[14 Notfall und Recovery]]** — was tun bei kaputtem Hook-Skript
- `_rules/glossary.md` — Begriffsdefinitionen (Hook, MCP, etc.)
- `specs/local-first-discovery/00_KONZEPT.md` — Spec für den Local-First-Helper
- `specs/lesson-persistence/00_KONZEPT.md` — Spec für den Lesson-Audit-Helper
