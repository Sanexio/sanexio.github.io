---
title: Architektur und Schichten
domain: cortex
modul: 01
level: einsteiger
status: kanonisch
---

# 01 — Architektur und Schichten

> **Antwort in einem Satz:** Cortex/Nexus ist ein zweischichtiger Stapel — ein **Self-Learning-Layer** (Python, denkt und entscheidet) auf einem **Channel-Router** (TypeScript/Bun, empfängt und sendet Nachrichten) — gestützt durch eine vierschichtige Memory-Architektur, geschützt durch ein fokussiertes Regelwerk, verbunden mit dem Wissens-Vault und kontinuierlich synchronisiert über alle Rechner im Verbund.

In diesem Modul lernst du, **welche Schicht für was zuständig ist** und **wie sie miteinander kommunizieren**.

## Das große Bild

```
                          ┌──────────────────────────────┐
                          │           ANWENDER            │
                          └──────────────┬───────────────┘
                                         │
            ┌────────────────────────────┴───────────────────────────┐
            │                                                        │
       Terminal /                                              Telegram /
       Claude Code                                             claude.ai/code
       (Chat)                                                  (Remote-Control)
            │                                                        │
            ▼                                                        ▼
  ┌──────────────────────┐                            ┌─────────────────────────┐
  │   HOOKS              │                            │   CHANNEL-ROUTER (TS)   │
  │   ~/.claude/…        │                            │   gateway/              │
  │   inject.sh          │   ←———————————————————→    │   • Telegram (Info)     │
  │   tier3-Gates        │     additionalContext      │   • MCP-Server          │
  │   lesson_audit       │                            │   • Channels (geplant)  │
  └──────────┬───────────┘                            └────────────┬────────────┘
             │                                                     │
             ▼                                                     │
  ┌─────────────────────────────────────────────────────────────┐  │
  │   SELF-LEARNING LAYER (Python)                              │◀┘
  │   agent/                                                    │
  │   • cortex-agent CLI       (run, bootstrap, skill, memory)  │
  │   • loop.py                (System-Prompt → LLM → Output)   │
  │   • modes/                 (autonomy.md, safe.md, tier3.md) │
  │   • skills/builtin/        (doctor, capture_lesson, …)      │
  │   • connexio/              (Multi-AI-Bridge)                │
  │   • providers/             (Anthropic, OpenAI, …)           │
  └──────────────┬──────────────────────────────────┬───────────┘
                 │                                  │
                 ▼                                  ▼
  ┌──────────────────────────────┐   ┌──────────────────────────────┐
  │   MEMORY                     │   │   REGELN                     │
  │   _memory/                   │   │   _rules/                    │
  │   • memory.db (SQLite FTS5)  │   │   • AUTONOMY_CONTRACT (Index)│
  │   • USER.md, KNOWLEDGE.md    │   │   • zehn fokussierte Files   │
  │   • golden-rules.md          │   │     (risk-levels, modes,     │
  │   • tasks-mirror/ (JSON)     │   │      stop-conditions, …)     │
  │   • leases.db, logs/, audit/ │   │                              │
  └──────────────────────────────┘   └──────────────────────────────┘
                                          ┌──────────────────────────────┐
                                          │   VAULT                      │
                                          │   Second Brain/              │
                                          │   • 00 Kontext               │
                                          │   • 30 Tutorials             │
                                          │   • 40 Regeln                │
                                          │   • 50 Fehler                │
                                          │   • 80 Templates             │
                                          │   • 90 Sessions              │
                                          └──────────────────────────────┘
            │                                                     │
            └──────────────────────┬──────────────────────────────┘
                                   ▼
                  ┌────────────────────────────────────┐
                  │   SYNC (auf jedem Rechner)         │
                  │   nexus-sync.sh + LaunchAgent      │
                  │   → git pull / push alle 5 Min     │
                  │   → Heartbeat, Drift-Alarm         │
                  └────────────────────────────────────┘
                                   │
                                   ▼
                  ┌────────────────────────────────────┐
                  │   GitHub Sanexio/nexus             │
                  │   (zentrale Sync-Drehscheibe)      │
                  └────────────────────────────────────┘
```

## Begriffsklärung — Self-Learning-Layer und Channel-Router

Die beiden Bezeichnungen orientieren sich an Architektur-Vorbildern, die ähnliche Aufgaben lösen:

- **Self-Learning-Layer** folgt einem minimalen, deterministischen Schleifenmuster (System-Prompt → User-Prompt → LLM-Call → Antwort). Keine verschachtelten Self-Calls. Lernen entsteht durch saubere Skills, nicht durch Rekursion in der Hauptschleife. Der Roundtrip läuft produktiv; die automatische Pattern-Extraktion aus Sessions ist im Aufbau und nicht im Standard-Loop verankert.
- **Channel-Router** ist ein kanalagnostischer Vermittler mit Pairing-Store (welche Endgeräte sich verbinden dürfen) und Sandbox-Isolation (eingehender Code läuft in einer Subshell). Der erste produktive Kanal ist Telegram-V3; Slack und Signal sind als nächste Kanäle skizziert.

Die Schichten erklären sich am besten von außen nach innen.

## Schicht 1 — Was rein- und rausgeht (Hooks + Channel-Router)

Der Anwender kommuniziert nie direkt mit Claude. Es liegt immer eine Vermittlung dazwischen — in zwei Formen.

### Hooks (für Claude Code im Terminal)

Wenn du in Claude Code etwas tippst, läuft beim Absenden ein **UserPromptSubmit-Hook** los. Ein Hook ist ein Skript, das automatisch bei einem definierten Ereignis ausgeführt wird; konfiguriert in `~/.claude/settings.json` unterhalb `hooks.UserPromptSubmit`.

Konkret läuft `~/Cortex/Nexus/tools/cortex-mode/bin/inject.sh`:

1. Liest den aktuellen Modus aus `~/.claude/state/cortex-mode.json` (autonomy oder safe).
2. Lädt das passende Mode-Briefing aus `agent/modes/autonomy.md` beziehungsweise `safe.md` plus die Tier-3-Regeln aus `agent/modes/tier3.md`.
3. Hängt das als zusätzlichen Kontext vor jeden Prompt — unsichtbar für den Anwender.

Dadurch kennt die KI bei jedem Prompt den aktiven Modus, ohne dass der Anwender ihn selbst formulieren müsste. Token-Budget des injizierten Blocks: etwa 3 KB.

Die Hook-Registration in `~/.claude/settings.json` ist Pflicht-Setup pro Rechner. Diagnose- und Install-Pfad in **[[11 Hooks und Mode-Injection]]**.

### Channel-Router (Telegram-Info-Terminal)

Der Channel-Router empfängt Nachrichten aus externen Kanälen — heute Telegram, perspektivisch Slack und Signal — und vermittelt sie an den Self-Learning-Layer.

- `gateway/src/gateway.ts` ist der zentrale Router (TypeScript, läuft mit Bun — einer schlanken JavaScript-Laufzeit ähnlich Node.js).
- `gateway/channels/telegram/channel.ts` ist die Telegram-Implementierung — ein MCP-Server, der per Long-Polling die Telegram-API abfragt.
- Ein Rechner im Verbund ist Leader (`BRIDGE_MODE=poll` in `gateway/.env`); die anderen laufen passiv (kein Polling, nur das `reply()`-MCP-Tool).

Ablauf: Telegram → Router → Self-Learning-Layer → Antwort → Router → Telegram.

Die Bridge ist nach klarer Rollenteilung definiert: **Info-Terminal** für Mesh-Status, `/devices`, `/status <name>`, Permission-Approvals. Für die produktive Arbeit an Sessions vom Handy aus läuft parallel `claude remote-control` (Standard-Pfad). Detail: **[[10 Channel-Router]]**.

## Schicht 2 — Wer denkt (Self-Learning-Layer)

In dieser Schicht fallen Entscheidungen. Code-Pfad: `~/Cortex/Nexus/agent/`.

- **`agent/cli.py`** definiert die Terminal-Kommandos: `cortex-agent run "<prompt>"`, `cortex-agent bootstrap`, `cortex-agent skill list/run`, `cortex-agent memory search`.
- **`agent/loop.py`** ist die eigentliche Agent-Schleife. Sie baut den System-Block (Modus, Tier-3, Goldene Regeln, Skill-Liste), ruft den LLM-Provider auf und sammelt die Antwort.
- **`agent/modes/`** enthält die menschlich lesbaren Mode-Briefings, die der Hook injiziert.
- **`agent/skills/builtin/`** enthält die Werkzeuge, die Agent oder Anwender aufrufen können.
- **`agent/providers/`** abstrahiert die LLM-API — Anthropic produktiv, OpenAI/Gemini/Ollama als Fallback skizziert.
- **`agent/connexio/`** vermittelt zwischen mehreren KIs — siehe **[[08 Connexio]]**.

## Skills — der wichtige Klärungspunkt

Skills liegen **innerhalb Nexus** (`agent/skills/builtin/*.py` und `Nexus/skills/*.skill`) und sind durch den Git-Sync auf jedem Rechner verfügbar. Sie sind nicht rechner-lokal.

Es existieren zwei Skill-Welten parallel:

| Welt | Pfad | Aufruf | Beispiele |
|---|---|---|---|
| **Python-Skills** (Cortex-Agent-Tools) | `agent/skills/builtin/*.py` | `cortex-agent skill run <name>` | doctor, capture-lesson, sanitizer, scheduler |
| **Claude-Code-Skill-Pakete** | `Nexus/skills/*.skill` | von Claude Code automatisch geladen | doc-workflow, smartq-dashboard, frontend-design |

Übersicht aller Python-Skills mit Zweck und Aufruf-Beispiel: `agent/skills/INDEX.md`. Disambiguation in `Nexus/skills/README.md`.

## Schicht 3 — Was das System weiß (Memory)

Memory ist keine monolithische Komponente, sondern eine **vierschichtige Architektur**. Kurzfassung hier; Detail in **[[05 Memory in 4 Schichten]]**:

| Schicht | Ort | Inhalt |
|---|---|---|
| **1. Vault** | `Second Brain/` | Manuell gepflegtes Wissen: Tutorials, Regeln, Sessions, Fehlerprotokolle |
| **2. Nexus-Memory** | `_memory/USER.md`, `KNOWLEDGE.md`, `golden-rules.md` | Anwender-Profil, Vault-Pointer-Index, destillierte Goldene Regeln |
| **3. FTS5-DB** | `_memory/memory.db` (gitignored) | Volltext-Index über Sessions, Patterns, Fakten, Skill-Runs. Pro Rechner lokal. |
| **4. Claude-Memory** | `~/.claude/projects/<projekt>/memory/` | Per Claude-Projekt: Feedback, Project-Notes, References. Pro Rechner und pro Projekt lokal. |

Wichtig: Schichten 1 und 2 sind gitversioniert (über alle Rechner identisch). Schichten 3 und 4 sind pro Rechner lokal. Architektur-Begründung in **[[05 Memory in 4 Schichten]]**.

## Schicht 4 — Was das System darf (Regeln)

Das Regelwerk ist eine fokussierte Familie unter `_rules/`:

- **`AUTONOMY_CONTRACT.md`** — Index (Pflicht-Lesung): Grundsatz, Mode × Risiko-Matrix, Hierarchie bei Regelkollision, Verweis auf Detail-Files.
- **`glossary.md`** — Begriffsdefinitionen (Pflicht-Lesung).
- Zehn spezialisierte Detail-Files: `risk-levels.md`, `modes.md`, `stop-conditions.md`, `tasks.md`, `verification.md`, `retention.md`, `ai-cooperation.md`, `multi-ai-boundaries.md`, `lesson-anchors.md`, `sync-policy.md`.
- Anwender-spezifische Erweiterungen: `user-directives.md`, `security.md`, `medical-domain.md`.

Bei der Frage „darf der Agent das?" ist der Index der Einstieg — er verweist auf das jeweilige Detail-File.

## Schicht 5 — Was beständig ist (Vault + Sync)

Der Vault (`Second Brain/`) ist die Wissensbasis in Obsidian-Markdown-Format. Er liegt innerhalb Nexus und läuft so mit dem Git-Sync mit. Schutzregel: der Sanitizer-Skill tastet den Vault nie automatisch an — er gilt als Single Source of Truth für Domänen-Wissen.

Der Sync läuft auf jedem Rechner als LaunchAgent (`com.cortex.nexus-sync.plist`), der alle fünf Minuten `nexus-sync.sh` ausführt:

- `git pull --ff-only` auf `main`,
- Heartbeat-Check (Zeitstempel-Datei pro Rechner; verhindert Race-Conditions, wenn ein anderer Rechner kürzlich aktiv war),
- gegebenenfalls Auto-Commit für Whitelist-Pfade und Push,
- Alarm-Eskalation bei Konflikt via Telegram-Info-Terminal.

Detail und Recovery-Pfade in **[[07 Multi-Device-Sync]]**.

## Wie die Schichten zusammenspielen — ein Beispiel

Du fragst in Claude Code: **„Welcher Rechner hält gerade die Schreibsperre auf das praxis-webseite-Repo?"**

1. Der Hook (`inject.sh`) injiziert den Modus, die Tier-3-Liste und die Goldenen Regeln.
2. Claude liest den injizierten Kontext und den Prompt, identifiziert eine Status-Frage und ruft das `connexio`-Skill auf.
3. Die Skill-Engine (`agent/skills/engine.py`) führt `connexio.get_active_leases()` aus.
4. Der Connexio-Kernel (`agent/connexio/kernel.py`) liest aus `_memory/leases.db` (Lease = Schreibsperre auf Repo + Scope mit Ablaufzeit).
5. Die Antwort geht zurück über Claude zum Anwender.

Bei einer Anfrage über Telegram-Info-Terminal:

1. Die Telegram-Bridge auf dem Leader-Rechner empfängt die Nachricht.
2. Der Channel-Router routet sie zum passenden Befehls-Handler.
3. Der Handler liest aggregierte Daten aus `.config/devices.json` und den Heartbeats.
4. Die Antwort wird formatiert und über die Bridge zurück an Telegram gesendet.

## Was du nach diesem Modul mitnimmst

- Du unterscheidest sicher zwischen Channel-Router (was ein- und ausgeht), Self-Learning-Layer (wo entschieden wird), Memory (was bekannt ist) und Regeln (was erlaubt ist).
- Bei einem Fehler kannst du gezielt fragen: Channel-Router-Problem, Agent-Problem, Memory-Problem oder Sync-Problem?
- Du weißt, dass `_rules/AUTONOMY_CONTRACT.md` (Index) plus `glossary.md` Pflicht-Lesung sind und die Details in zehn spezialisierten Files liegen.
- Du verstehst, warum Skills innerhalb Nexus liegen und damit über den Git-Sync auf jedem Rechner verfügbar sind.

## Verwandte Tutorials

- **[[02 Datei-Atlas]]** — jede Datei mit Rolle und Bedeutung
- **[[03 Autonomy und Safe Mode]]** — die Modi und ihre Wechsel-Mechanik
- **[[05 Memory in 4 Schichten]]** — Tiefenblick auf die Memory-Architektur
- **[[08 Connexio]]** — Multi-AI-Bridge im Detail
- **[[09 Self-Learning-Layer]]** — Tiefenblick auf `agent/`
- **[[10 Channel-Router]]** — Telegram-Info-Terminal und Remote-Control-Project-Pfad
