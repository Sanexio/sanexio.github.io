---
title: Harness — Wie Claude arbeitet
domain: cortex
modul: 16
level: fortgeschritten
status: kanonisch
---

# 16 — Harness — Wie Claude arbeitet

> **Antwort in einem Satz:** Der **Harness** ist das Programm, das einen Sprachmodell-Provider operativ nutzbar macht — er komponiert den Kontext, ruft das Modell auf, führt Tool-Calls aus, leitet Hooks an und persistiert Sessions; in Cortex bedeutet „Harness" konkret die Claude-Code-Laufzeit, in der jede Anwender-Sitzung läuft.

In diesem Modul lernst du **was ein Harness allgemein ist**, **welche Phasen ein Prompt durchläuft**, und **welche Cortex-spezifischen Erweiterungen oben drauf sitzen**.

Das Modul ist zweiteilig:
- **Teil A — Allgemein**: das Konzept Harness, wie es bei jedem LLM-Tool-Use-System aussieht, und warum es überhaupt eine eigene Schicht ist.
- **Teil B — Cortex-spezifisch**: was Cortex auf den Harness aufpfropft (Mode-Injection, Skills, Memory-Anbindung, Connexio-Boundary).

---

## Teil A — Der Harness allgemein

### Was bedeutet „Harness"

Im Anthropic-Vokabular bezeichnet **Harness** die Software-Schicht, die ein Sprachmodell **operativ nutzbar** macht. Das Modell selbst (z. B. Claude Opus 4.7) ist ein zustandsloser HTTP-Endpunkt, der genau eine Sache kann: einen Prompt entgegennehmen und eine Antwort zurückliefern. Damit daraus ein laufender Agent wird, der Dateien liest, Befehle ausführt, Notizen pflegt und auf Anwender-Anfragen reagiert, braucht es eine Vermittler-Schicht.

Diese Vermittler-Schicht ist der Harness. In anderen Vokabularen heißt sie *agent runtime*, *agent loop* oder schlicht *orchestrator*. Bei Anthropic ist sie als **Claude Code** umgesetzt — als CLI-Programm, das auf dem lokalen Rechner läuft, dort auf Anwender-Eingaben hört und im Hintergrund das Sprachmodell ansteuert.

### Komponenten eines Harness

Jeder produktive Harness, unabhängig vom Anbieter, vereint eine kleine Anzahl wiederkehrender Bauteile:

| Komponente | Aufgabe |
|---|---|
| **Modell-Client** | HTTP-Anbindung an den LLM-Provider, einschließlich Streaming, Retry, Token-Counting. |
| **Kontext-Komposition** | Baut pro Anfrage den vollständigen Modell-Input aus System-Prompt, Conversation-History, Datei-Anhängen, Tool-Definitionen und ggf. injiziertem Zusatzkontext. |
| **Tool-Registry** | Hält die verfügbaren Tools mit Name, Beschreibung und JSON-Schema. Das Modell entscheidet, ob es ein Tool aufruft. |
| **Tool-Loop** | Wenn das Modell einen Tool-Call ausgibt, führt der Harness das Tool aus, fügt das Resultat in die Conversation ein und ruft das Modell erneut. Loop bis text-only-Antwort. |
| **Hook-System** | Skripte oder Funktionen, die der Harness an definierten Punkten der Anfrage-Verarbeitung ausführt (z. B. vor jedem Prompt, nach jedem Tool-Call). |
| **Permission-System** | Entscheidet, ob ein angeforderter Tool-Call automatisch erlaubt ist, eine Anwender-Bestätigung braucht oder grundsätzlich verboten ist. |
| **Skill- / Slash-Command-Registry** | Höhere Abstraktion über reinen Tool-Calls: vordefinierte Aufgaben-Pakete oder Befehle, die der Anwender oder das Modell aufrufen kann. |
| **Persistenz** | Speichert Sessions, Conversation-History und projekt-spezifisches Memory, damit eine neue Session an die alte anknüpfen kann. |
| **Streaming-Pipeline** | Liefert die Modell-Antwort tokenweise an das Terminal oder die UI, damit der Anwender den Fortschritt mitliest, statt auf den Block am Ende zu warten. |

Ohne diese Schicht müsste jede Tool-Use-Anwendung den Roundtrip selbst implementieren: HTTP-Request bauen, Tool-Call parsen, Tool ausführen, Resultat injizieren, neuer HTTP-Request. Der Harness kapselt diese Wiederholung und stellt einen sauberen Anwender-Berührungspunkt bereit (Terminal-Chat, IDE-Plugin, Web-UI).

### Phasen einer Prompt-Verarbeitung

Jede einzelne Anwender-Nachricht durchläuft im Harness eine feste Pipeline. Der genaue Verlauf:

[1] Anwender drückt Enter im Chat
        │
        ▼
[2] Pre-Hook: UserPromptSubmit
    └─ Hooks-Skripte werden ausgeführt, ihr stdout/JSON wird
       als additionalContext mit in die Anfrage gehängt.
        │
        ▼
[3] Kontext-Komposition
    └─ Harness baut:
         System-Prompt
       + additionalContext (aus Pre-Hooks)
       + Tool-Definitionen (für jedes registrierte Tool ein Schema)
       + Conversation-History
       + die neue User-Message
        │
        ▼
[4] HTTP-Request an den LLM-Provider (gestreamt)
        │
        ▼
[5] Modell antwortet
    └─ entweder: reiner Text          (Sprung zu [9])
       oder:    Tool-Call-Block       (weiter zu [6])
        │
        ▼
[6] Pre-Tool-Hook: PreToolUse
    └─ kann den Call abbrechen, modifizieren, loggen.
        │
        ▼
[7] Tool-Ausführung
    └─ Edit liest und schreibt eine Datei, Bash startet einen Prozess,
       Read liefert Datei-Inhalt etc.
        │
        ▼
[8] Post-Tool-Hook: PostToolUse
    └─ Resultat-Validierung, Logging, ggf. Side-Effects.
       Tool-Resultat wird als Assistant-Message in die History
       eingefügt und der Harness springt zurück zu [4].
        │
        ▼
[9] Stop-Hook
    └─ Wird ausgelöst, wenn das Modell endgültig ohne Tool-Call
       antwortet (Welle-Ende). Optionaler Push, Lesson-Audit,
       Telegram-Nachricht.
```

Die Schritte 4–8 bilden den **Tool-Loop**. Er läuft solange, bis das Modell mit reiner Text-Antwort endet. Jede Tool-Iteration verbraucht zusätzliches Token-Budget, weil sowohl der Tool-Call als auch das Resultat in den nächsten Kontext eingehen.

### Tools — die Hände des Modells

Ein **Tool** ist eine vom Harness exponierte Funktion mit:

- einem eindeutigen Namen (z. B. `Read`, `Edit`, `Bash`, `WebFetch`),
- einer Beschreibung in natürlicher Sprache (das Modell wählt anhand der Beschreibung),
- einem JSON-Schema für die Argumente,
- einer Implementierung im Harness selbst.

Das Modell sieht in jeder Anfrage die komplette Liste der verfügbaren Tools und entscheidet je nach Prompt, ob und welches es aufruft. Die Tool-Definition ist Teil des Kontext-Budgets — viele Tools bedeuten mehr Tokens pro Anfrage.

Tools werden grob in drei Klassen geteilt:

| Klasse | Quelle | Beispiel |
|---|---|---|
| **Built-in Tools** | Im Harness selbst implementiert. | `Read`, `Edit`, `Write`, `Bash`, `Grep`, `WebFetch`. |
| **MCP-Tools** | Über das Model Context Protocol von externen Servern bereitgestellt. | `mcp__github__create_issue`, `mcp__figma__get_design_context`. |
| **Sub-Agent-Tools** | Spezialisierte Untermodelle, vom Haupt-Harness via `Agent`-Tool angesprochen. | `Explore`, `Plan`, `claude-code-guide`. |

### Hooks — die Schnittstelle zwischen Harness und externem Skript

Ein **Hook** ist ein vom Anwender oder Projekt definiertes Skript, das der Harness an einem festen Ereignis-Punkt ausführt. Die wichtigsten Events:

| Event | Wann |
|---|---|
| `UserPromptSubmit` | Anwender hat eine Nachricht abgesendet, bevor das Modell sie sieht. |
| `PreToolUse` | Modell hat einen Tool-Call ausgegeben, bevor das Tool läuft. |
| `PostToolUse` | Tool ist fertig, bevor das Resultat dem Modell zurückgegeben wird. |
| `Stop` | Modell hat eine Antwort ohne weiteren Tool-Call abgegeben — Ende der Welle. |
| `SessionStart` / `SessionEnd` | Anfang und Ende einer Claude-Code-Sitzung. |

Hooks werden in der Datei `~/.claude/settings.json` unter dem Schlüssel `hooks` konfiguriert. Pro Event eine Liste, pro Listen-Eintrag ein Matcher (regulärer Ausdruck auf Tool-Name oder Prompt) und eine Befehls-Liste. Der Output eines Hooks ist standardmäßig nichts; gibt er aber valides JSON mit `additionalContext` zurück, wird dieser String in den Modell-Kontext injiziert.

Hooks sind das Werkzeug, mit dem man dem Harness zusätzliche Regeln, Diagnosen oder Sicherheits-Checks beibringt, ohne den Harness selbst zu patchen.


### Skills und Slash-Commands

Beide sind Convenience-Schichten über Tool-Calls:

- **Slash-Command** — ein Markdown-File in `~/.claude/commands/<name>.md` mit Frontmatter (`description`, `allowed-tools`). Im Body steht entweder ein Anweisungs-Text für das Modell oder eine Bash-Direktive (`!`-Prefix), die der Harness sofort ausführt. Anwender schreibt `/<name>` im Chat → der Befehl wird aufgerufen.
- **Skill** — analog ein Markdown-File mit Frontmatter, das das Modell selbst als ausführbare Routine wahrnehmen kann. Skills werden vom Harness als zusätzlich verfügbare Tool-Wahl angeboten und dem Modell als „aufrufbare Lösungs-Schemata" beschrieben. Eine Skill-Beschreibung enthält oft eine Schritt-für-Schritt-Anleitung, an die sich das Modell halten soll, wenn es die Skill aufruft.

Slash-Commands sind anwenderseitig, Skills sind modellseitig. Beide lassen sich pro Projekt oder global einrichten.

### Permission-System

Damit der Harness nicht jeden Tool-Call automatisch ausführt — was bei Tools wie `Bash` oder `WebFetch` riskant wäre — gibt es ein **Permission-System**. Es entscheidet pro Tool-Call zwischen drei Pfaden:

- **allow** — Tool läuft ohne Rückfrage.
- **ask** — Anwender wird in der UI gefragt.
- **deny** — Tool-Call wird blockiert, Modell bekommt einen Fehler zurück.

Konfiguriert wird das in `~/.claude/settings.json` unter `permissions.allow`, `permissions.ask`, `permissions.deny`. Patterns matchen auf den Tool-Namen plus optionalem Argument-Filter (z. B. `Bash(git status)` matcht nur den exakten Befehl).

Der zusätzlich wählbare **Permission-Mode** der Sitzung (`default`, `acceptEdits`, `plan`, …) verschiebt die Defaults: im `acceptEdits`-Mode werden alle File-Edits automatisch erlaubt, im `plan`-Mode wird vor jeder Aktion ein Plan vorgelegt.

### Streaming und Token-Budget

Das Modell liefert seine Antwort **gestreamt** — der Harness erhält Token für Token, leitet sie direkt an die UI weiter und beobachtet parallel den Verlauf nach Tool-Call-Markierungen. Sobald ein Tool-Call auftaucht, kann der Harness den Stream abschließen, das Tool ausführen und einen neuen Stream starten.

Das **Token-Budget** einer Anfrage setzt sich zusammen aus System-Prompt + Tool-Definitionen + History + neuer Input + injiziertem Kontext. Bei längeren Sessions wächst die History stetig, was zwei Konsequenzen hat:

- **Kosten** skalieren linear mit der History-Größe (pro Token wird abgerechnet).
- Das **Context-Window** ist endlich (bei aktuellen Modellen 200k bis 1M Tokens). Naht das Modell der Obergrenze, beginnt der Harness mit Compaction-Strategien: ältere Nachrichten zusammenfassen, redundante Tool-Outputs ausschneiden, ganze Sub-Conversations ablegen.

### Persistenz und Memory

Damit eine neue Session nicht bei Null beginnt, hält der Harness mehrere Persistenz-Schichten:

- **Conversation-History** — die letzten N Nachrichten als JSONL pro Session, üblicherweise in `~/.claude/projects/<slug>/<session>.jsonl`.
- **Projekt-Memory** — kurze Markdown-Files mit Frontmatter, die Claude Code bei Session-Start automatisch in den Systemkontext lädt. Liegen unter `~/.claude/projects/<slug>/memory/`. Vier Konventionen: `feedback`, `user`, `project`, `reference`.
- **Globale Memory-Files** — zentrale `CLAUDE.md` oder vergleichbare Dateien im Projekt-Root, die jede Session liest.

Das Memory-System bleibt unsichtbar für das Modell als „Tool"; es wirkt als zusätzlicher System-Prompt-Anteil bei jedem Sitzungs-Start.

---

## Teil B — Cortex-spezifisch

Der Harness, in dem Cortex läuft, ist ein **unveränderter Claude Code** — Cortex erweitert ihn ausschließlich über die offiziellen Erweiterungspunkte (Hooks, Skills, Slash-Commands, Memory). Dieser Abschnitt zeigt, was Cortex konkret an welcher Stelle aufpfropft.

### Das große Bild — Cortex als Aufsatz auf Claude Code

```
                ┌────────────────────────────────────┐
                │     Claude-Code-Harness            │
                │  (Anthropic, unverändert)          │
                └────────────────┬───────────────────┘
                                 │
        ┌────────────────────────┼───────────────────────────┐
        │                        │                           │
   Hook-Eintrag           Memory-Files                Slash-Commands
   inject.sh              CLAUDE.md, MEMORY.md          /autonomy-mode
        │                        │                     /safe-mode
        ▼                        ▼                     /cortex-mode
   Mode-Block                Vault                          │
   + Tier-3                  Second Brain/                  ▼
   + Helper-Outputs                                  set_mode.sh
        │                        │                       │
        ▼                        ▼                       ▼
              ╔══════════════════════════════════════╗
              ║         additionalContext            ║
              ║         im Modell-Request            ║
              ╚══════════════════════════════════════╝
```

Daneben existiert ein eigener Mini-Harness in Python (`agent/`), der für nicht-interaktive Aufgaben gebraucht wird (Skript-Aufrufe, Cron-Jobs, Connexio). Mehr dazu am Ende des Abschnitts.

### Die Pre-Hook-Pipeline — `inject.sh`

Cortex registriert genau **einen** Hook im Claude-Code-Harness: einen `UserPromptSubmit`-Hook, der `tools/cortex-mode/bin/inject.sh` aufruft. Sein Output landet als `additionalContext` ganz oben im Modell-Request der laufenden Anfrage. Drei Bestandteile:

| Bestandteil | Quelle | Wann |
|---|---|---|
| **Mode-Block** | `agent/modes/autonomy.md` oder `agent/modes/safe.md`, je nach State-File. | Immer. |
| **Tier-3-Block** | `agent/modes/tier3.md`. | Immer. Mode-unabhängig. |
| **Helper-Outputs** | `local_first_discovery.py` (bei Schlüsselwörtern wie „clone", „wordpress"), `lesson_audit.py` (bei Welle-Ende-Phrasen). | Bedingt. |

Das gesamte Paket umfasst rund drei Kilobyte oder rund 750 Tokens. Es prepended jeden Prompt, ohne dass der Anwender etwas tun muss — und ohne dass der Harness selbst geändert wird. Wenn der Hook nicht in `~/.claude/settings.json` registriert ist, läuft der Harness wie ohne Cortex-Aufsatz; siehe **[[11 Hooks und Mode-Injection]]**.

### Mode-Mechanik im Tool-Loop

Der Mode-Block fordert vom Modell unterschiedliches Verhalten:

- **Autonomy-Modus**: das Modell darf den vollen Tool-Loop ohne Rückfragen durchziehen. Phase 1 (Verstehen) und Phase 2 (Plan) laufen intern. Phase 3 (Umsetzen) und Phase 4 (Verifikation) führt es eigenständig aus. Stop nur bei vier definierten Triggern (Tier-3, Ambiguität, Token-Knappheit, Welle-Ende).
- **Safe-Modus**: dasselbe Modell, gleicher Tool-Loop, aber das Modell pausiert nach Phase 2 (Plan) bewusst und wartet auf eine Anwender-Bestätigung, bevor es Phase 3 startet. Plus zwei zusätzliche Stop-Trigger (taktische Wahl, Konsistenz-Fehler in Phase 4).

Der Harness selbst weiß von Modes nichts. Modes sind ein **Inhalt im Kontext**, an den sich das Modell hält, weil der Mode-Block es so vorgibt. Detail: **[[03 Autonomy und Safe Mode]]**.

### Tier-3 — die mode-unabhängige Schutzschicht

Der Tier-3-Block (`agent/modes/tier3.md`) ist ebenfalls Kontext-Inhalt, kein technischer Block im Permission-System. Das Modell ist instruiert, vor jeder Operation einer der drei Tier-3-Kategorien anzuhalten und auf eine ausdrückliche Freigabe zu warten. Das ist die *einzige* harte Stopp-Schicht, die mode-unabhängig wirkt.

Operativ gibt es zusätzlich das Anthropic-Permission-System (allow/ask/deny), das viele tatsächliche Tool-Calls noch einmal vor das Modell stellt — etwa der Bash-Befehl `rm -rf` oder `WebFetch` auf eine unbekannte Domain. Das ist eine *zweite*, harnessseitige Schutzlinie. Beide arbeiten zusammen: das Modell entscheidet selbst (Tier-3), und der Harness kontrolliert das Resultat (Permissions).

Detail: **[[04 Tier-3 Hardstops]]**.

### Cortex-Slash-Commands

Cortex installiert drei Slash-Command-Templates in `~/.claude/commands/`:

- `/autonomy-mode` — setzt das Mode-State-File auf `autonomy`.
- `/safe-mode` — setzt das State-File auf `safe`.
- `/cortex-mode` — zeigt den aktuellen Modus an.

Jeder Slash-Command ruft das Helfer-Skript `tools/cortex-mode/bin/set_mode.sh` auf, mit einem Inline-Fallback im Template selbst (falls das Skript lokal fehlt, schreibt der Template-Body das State-File direkt). Die Installation in `~/.claude/commands/` ist rechnerlokal und wird durch `scripts/onboard-device.sh` oder `bash tools/cortex-mode/bin/install_slash_commands.sh` gesetzt. `nexus-sync.sh` heilt Drift zwischen Repo-Template und lokaler Kopie nach jedem Pull automatisch.

### Cortex-Skills — die `agent/skills/builtin/`-Familie

Cortex stellt eine eigene Skill-Familie über sein Python-Layer bereit. Es sind 13 Builtin-Skills, registriert in `agent/skills/INDEX.md` und ansprechbar über die CLI:

```bash
cortex-agent skill list
cortex-agent skill run <name> [--args '{...}']
```

Diese Skills sind **nicht** identisch mit den Claude-Code-Skills. Sie laufen in einem eigenen Python-Mini-Harness, nicht direkt im Claude-Code-Tool-Loop. Das hat historische Gründe — der Cortex-Agent ist älter als die Claude-Code-Skill-Konvention.

Zentrale Skills (Detail in `agent/skills/INDEX.md`):

| Skill | Zweck |
|---|---|
| `doctor` | Health-Check des gesamten Cortex-Setups inkl. Policy, Drift, Runtime, Sync, Lease-Konsistenz. |
| `capture-lesson` | Persistiert eine Lesson als Claude-Memory-Datei plus Eintrag in `MEMORY.md`. |
| `session-end` | Schreibt einen Welle-Ende-Debrief in das Cortex-Memory mit Größen-Cap. |
| `session-start` | Liefert pending Spawns, Tier-3-Approvals und Cron-Failures als Digest. |
| `sanitizer` | Memory-Wachstumskontrolle: VACUUM, Sessions-Archiv, TTL-Migration. |
| `pattern-miner` | Sucht wiederkehrende Muster aus den letzten Sessions (heuristisch + optional via Anthropic-API). |
| `connexio` | Read-Only-Surface für andere KIs (healthcheck, audit-tail, server-start, mcp-cmd, keygen). |
| `outbound` | Connexio Outbound — explizite Anrufe an andere LLM-Provider. |
| `cron`, `scheduler`, `spawn`, `curator`, `tutorial-curator` | Spezialisierte Workflow-Helfer. |

Ein **Migration-Pfad** zur direkten Integration in den Claude-Code-Skill-Mechanismus ist in `specs/cortex-native-migration/00_KONZEPT.md` skizziert: längerfristig sollen Skills nicht mehr per `cortex-agent`-CLI, sondern direkt als `~/.claude/skills/<name>/SKILL.md` aufrufbar sein.

### Memory-Integration im Cortex-Harness

Claude Code lädt beim Sitzungs-Start automatisch alle Files unter `~/.claude/projects/<slug>/memory/` plus die globale `CLAUDE.md` als Systemkontext. Cortex nutzt das voll aus:

- `~/.claude/projects/-Users-ssmd-Cortex/memory/MEMORY.md` — der Auto-Memory-Index. Wird bei jeder Session vorab geladen.
- Einzelne `feedback_*.md`, `project_*.md`, `reference_*.md`, `user_*.md` — Lesson-Files, die im Verhalten der KI persistieren.
- `~/Cortex/Nexus/CLAUDE.md` — projektweiter Einstieg.

Diese vier Schichten sind das Cortex-Memory-System. Vollständig erklärt in **[[05 Memory in 4 Schichten]]**.

Das Cortex-Memory wirkt also nicht als zusätzliches Tool oder zusätzlicher Hook, sondern wird vom Harness von sich aus eingelesen — Cortex pflegt nur die Inhalte und Dateinamen-Konventionen.

### Connexio — Boundary zu fremden Harnessen

Cortex koordiniert sich mit anderen KIs (Codex, Cursor, Cline, Gemini), die in **eigenen Harnessen** laufen. Damit der Cortex-Nexus nicht von außen verändert wird, gibt es zwei Boundary-Mechanismen:

- **Read-Only-Surface** über HTTP und MCP. Externe KIs dürfen aus dem Nexus lesen, aber nicht schreiben. Implementiert in `gateway/connexio/`.
- **Task-Mirror** als gitversionierte JSON-Files pro Aufgabe. Eine Aufgabe wandert als Task-File von Claude (Cortex-Harness) zu Codex (anderer Harness) und zurück, ohne dass die fremde KI direkten Schreibzugriff bekommt.

Detail: **[[08 Connexio]]**.

### Token-Budget und Welle-Hygiene

Da der Claude-Code-Harness pro Welle ein endliches Token-Budget hat, ist das Cortex-Welle-Ende-Format bewusst kompakt:

- `WAS GEMACHT` — fakten-orientiert, drei bis sieben Punkte.
- `WAS GELERNT` — nur bei substantiellem Lerngewinn, jeder Punkt mit Persistenz-Anker.
- `STRATEGISCHE WAHLEN` — nur bei echten Verzweigungen.

Diese Disziplin hat einen direkten Token-Effekt: weniger Output am Welle-Ende heißt mehr Budget für die nächste Welle. Detail: **[[03 Autonomy und Safe Mode]]** und `_rules/lesson-anchors.md`.

### Der zweite Cortex-Harness — `cortex-agent` (Python)

Neben dem Claude-Code-Harness existiert ein **zweiter, schlanker Harness** in `agent/loop.py`. Er ist nicht interaktiv; er führt eine einzelne Loop-Iteration aus, schreibt das Ergebnis in die Memory-DB und endet.

Zweck:
- Skript-getriebene Aufgaben (Cron-Jobs, LaunchAgent-Trigger, Connexio-Outbound).
- Tests gegen die Anthropic-API ohne UI.
- Skill-Ausführung außerhalb einer Claude-Code-Sitzung.

`cortex-agent run "<prompt>"` schickt einen einzelnen Roundtrip an die Anthropic-API, mit denselben Tier-3-Regeln, demselben Modus-State und demselben Memory-Recall wie der Claude-Code-Harness. Der Unterschied ist die fehlende interaktive Tool-Loop-Schleife: Tools werden in genau einer Iteration ausgeführt und das Ergebnis ist endgültig.

Detail: **[[09 Self-Learning-Layer]]**.

---

## Häufige Missverständnisse

**„Der Harness ist Teil von Cortex."**
Nein. Der Harness ist Claude Code — eine Anthropic-Plattform, die Cortex *nutzt*. Cortex addiert Verhalten ausschließlich über offizielle Erweiterungspunkte.

**„Skills und Tools sind dasselbe."**
Tools sind das Atom des Harness (Read, Edit, Bash, …). Skills sind eine höhere Schicht, die einen oder mehrere Tool-Calls als Lösungs-Schema bündeln und dem Modell als „aufrufbare Routine" beschreiben.

**„Hooks ersetzen das Permission-System."**
Nein. Hooks injizieren Kontext oder reagieren auf Events; sie können einen Tool-Call zwar abbrechen, sind aber nicht für allow/ask/deny gedacht. Beide Schichten ergänzen sich.

**„Wenn der Mode-Block fehlt, ist Cortex kaputt."**
Cortex läuft *technisch* auch ohne Mode-Block — das Modell verhält sich dann wie ein Standard-Claude ohne Cortex-Spezifika. Was fehlt, ist die Anti-Drift-Disziplin, die Tier-3-Schicht und das Welle-Ende-Format. Detail: **[[11 Hooks und Mode-Injection]]**.

## Was du mit diesem Modul jetzt kannst

- Du verstehst, was ein Harness im LLM-Vokabular ist und welche Bausteine er hat.
- Du kannst die Phasen einer Prompt-Verarbeitung von Pre-Hook bis Stop-Hook benennen.
- Du weißt, dass Tools, Hooks, Skills, Slash-Commands und das Permission-System die fünf offiziellen Erweiterungspunkte des Claude-Code-Harness sind.
- Du erkennst Cortex als reinen Aufsatz, der diese Erweiterungspunkte konsequent nutzt.
- Du kannst die Cortex-spezifischen Aufsätze einsortieren: `inject.sh` als Pre-Hook, die drei Slash-Commands, die Cortex-Skill-Familie, die Memory-Schichten, Connexio als Boundary.
- Du weißt, warum es einen zweiten Mini-Harness (`cortex-agent`) gibt und wann er wofür benutzt wird.

## Verwandte Tutorials

- **[[01 Architektur und Schichten]]** — wo der Harness im Big Picture steht
- **[[03 Autonomy und Safe Mode]]** — wie Mode-Inhalt vom Modell interpretiert wird
- **[[04 Tier-3 Hardstops]]** — die mode-unabhängige Schutzschicht im Kontext
- **[[05 Memory in 4 Schichten]]** — wie der Harness Memory einliest
- **[[09 Self-Learning-Layer]]** — der Python-Mini-Harness `cortex-agent`
- **[[11 Hooks und Mode-Injection]]** — der zentrale Pre-Hook im Detail
- **[[13 Slash-Commands und CLI]]** — Slash-Command-Anatomie
- **[[99 Glossar]]** — Begriffsdefinitionen Harness, Tool, Skill, Hook


> [!note] Anmerkung
> Ich möchte, dass du prinzipiell überall im Tutorial die Dateien, die du beschreibst auch direkt verlinkst, so dass ich gleich direkt dort hineinschauen kann - hier in diesem Fall wäre die Datei settings.json interessant. vielleicht ergänzt du direkt eine Art Datei Glossar, wo du die einzelnen Dateien benennst und deren Inhalt dann ausgibst

> [!note] Anmerkung
> Die Grafiken oder Übersichtsschemata, die du hier verwendest sind nicht schön, bzw. 
