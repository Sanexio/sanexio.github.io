---
title: Slash-Commands und CLI
domain: cortex
modul: 13
level: einsteiger
status: kanonisch
---

# 13 — Slash-Commands und CLI

> **Antwort in einem Satz:** Cortex hat zwei Befehls-Welten — die **Slash-Commands** in Claude Code (Chat-Eingabe mit `/`) und die **CLI-Befehle** im Terminal (`cortex-agent ...`) — plus eine kleine Sammlung von **Standard-Befehlen in normaler Sprache** („Phoenix fortsetzen", „Session beenden"); dieses Modul ist der Cheatsheet für alle drei.

In diesem Modul lernst du **wann du was tippst**, **welche Befehle existieren**, und **welche Tier-3-Hardstops bei welchen Befehlen drohen**.

## Übersicht — drei Befehls-Welten

```
                        WO TIPPST DU?
   ┌────────────────────┬───────────────────┬──────────────────┐
   │                    │                   │                  │
   ▼                    ▼                   ▼
┌────────┐         ┌─────────┐         ┌──────────┐
│ Claude │         │ Termin- │         │ Telegram │
│ Code   │         │ al      │         │ Bot      │
│ (Chat) │         │         │         │          │
└───┬────┘         └────┬────┘         └────┬─────┘
    │                   │                   │
    ▼                   ▼                   ▼
 /-Slash             cortex-agent         /-Slash
 Commands            CLI + git +          (an Bot)
                     gh + Skills
```

## Welt 1 — Slash-Commands in Claude Code

Tippst du am Anfang deines Prompts in Claude Code. Werden von Claude Code direkt verarbeitet (nicht ans LLM weitergereicht).

### Mode-Switch

| Befehl | Wirkung |
|---|---|
| `/autonomy-mode` | Setzt Mode auf autonomy. Gilt ab nächstem Prompt. |
| `/safe-mode` | Setzt Mode auf safe. Gilt ab nächstem Prompt. |
| `/cortex-mode` | Zeigt aktuellen Stand an. |

Detail: **[[03 Autonomy und Safe Mode]]**.

### Standard Claude-Code-Befehle

| Befehl | Wirkung |
|---|---|
| `/help` | Liste aller verfügbaren Slash-Commands in dieser Session. |
| `/clear` | Conversation-Kontext zurücksetzen (achtung: alles weg, was noch nicht persistiert ist). |
| `/compact` | Conversation manuell komprimieren. |
| `/model` | Modell auswählen (Opus / Sonnet / Haiku). |
| `/config` | Konfigurations-Menü. |
| `/hooks` | Hooks-Status anzeigen + Reload triggern. |
| `/agents` | Verfügbare Sub-Agents auflisten. |
| `/mcp` | MCP-Server-Status. |
| `/login` / `/logout` | Auth-Status verwalten. |

### Cortex-spezifische (geplant / teilweise via Skills)

| Befehl | Wirkung |
|---|---|
| `/ultrareview` | Multi-Agent-Cloud-Review der aktuellen Branch (separat gebucht). |
| `/review` | PR-Review-Skill. |
| `/security-review` | Security-Review der pending Changes. |
| `/init` | Neues CLAUDE.md-File generieren. |

## Welt 2 — CLI im Terminal

### `cortex-agent` (Self-Learning-Layer CLI)

Entry-Point definiert in `pyproject.toml`. Implementiert in `agent/cli.py`.

#### Loop

```bash
cortex-agent run "<prompt>"
# Eine Single-Roundtrip-Iteration. Braucht ANTHROPIC_API_KEY.

cortex-agent bootstrap [--no-pull]
# Lädt Mode + User + Skills + Memory, gibt System-Block-Größe aus.
# --no-pull überspringt den automatischen git pull --ff-only.
```

#### Mode

```bash
cortex-agent mode get
cortex-agent mode set autonomy
cortex-agent mode set safe
```

#### Skills

```bash
cortex-agent skill list
# Listet alle 13 builtin Skills mit Doc-One-Liner.

cortex-agent skill run <name> [--args '{"key": "value"}']
# Führt einen Skill aus. Argumente als JSON.

# Beispiele:
cortex-agent skill run doctor
cortex-agent skill run doctor --args '{"strict": true}'
cortex-agent skill run sanitizer
cortex-agent skill run capture-lesson --args '{"kind":"feedback","slug":"my_slug","title":"...","description":"...","rule":"...","why":"...","how_to_apply":"..."}'
cortex-agent skill run tutorial-curator
cortex-agent skill run scheduler
```

Detail aller Skills: `agent/skills/INDEX.md`.

#### Memory

```bash
cortex-agent memory search "<query>"
# FTS5-Volltextsuche über sessions + patterns.

cortex-agent memory facts [--kind <kind>]
# User-Facts anzeigen, optional gefiltert (kind=contact, location, …).

cortex-agent memory add-fact <kind> <key> <value>
# Strukturierten Fakt hinzufügen.
```

### `git` (Standard-Befehle für Cortex-Alltag)

```bash
# Status + Diff
git status
git status --short
git diff
git diff --stat
git log --oneline -10

# Sync
cd ~/Cortex/Nexus
git pull --ff-only
git push

# Branch
git branch
git checkout <branch>
git checkout main
git fetch origin
git rev-list --left-right --count HEAD...origin/main   # ahead/behind

# Notfall (Tier-3 nur auf fremden Repos!)
git reset --hard origin/main   # frei auf eigenen Repos
git stash push -u -m "<note>"
git stash pop
```

Detail Sync-Recovery: **[[14 Notfall und Recovery]]** + **[[07 Multi-Device-Sync]]**.

### `gh` (GitHub CLI)

```bash
# PRs
gh pr list
gh pr view <num>
gh pr create --title "..." --body "..."
gh pr checks <num>
gh pr merge <num>

# Issues
gh issue list
gh issue view <num>

# API-Zugriff (Hooks, Workflows)
gh api repos/Sanexio/nexus/branches/main
```

### `launchctl` (LaunchAgents verwalten)

```bash
# Status
launchctl list | grep cortex
# Erwartet: com.cortex.nexus-sync mit PID oder "-" (gerade nicht laufend).

# Laden / Entladen
launchctl load ~/Library/LaunchAgents/com.cortex.nexus-sync.plist
launchctl unload ~/Library/LaunchAgents/com.cortex.nexus-sync.plist

# Manuell triggern (zum Testen)
launchctl kickstart -k gui/$(id -u)/com.cortex.nexus-sync
```

### `tailscale` (Mesh-VPN)

```bash
# Status
tailscale status
tailscale ip --4
tailscale ping <hostname>

# SSH
ssh ssmd@cluster-mini-02       # via Tailscale-SSH
ssh ssmd@100.127.125.48        # direkt via Tailscale-IP

# Wenn Verbindung hängt
tailscale up --reset
tailscale logout && tailscale login
```

### `jq` (JSON-Verarbeitung)

```bash
# Mode-State lesen
jq -r .mode ~/.claude/state/cortex-mode.json

# Hook-Registration prüfen
jq -e '.hooks.UserPromptSubmit' ~/.claude/settings.json

# devices.json: ein Mac
jq '.devices."SSMD-MacBookPro-M5"' ~/Cortex/Nexus/.config/devices.json
```

### `bun` / `uv` (Laufzeiten)

```bash
# Telegram-Bridge starten (im gateway-Verzeichnis)
cd ~/Cortex/Nexus/gateway
bun run telegram

# Python-Setup
cd ~/Cortex/Nexus
uv sync               # Dependencies installieren
uv run cortex-agent … # Sub-Befehl ausführen
```

## Welt 3 — Standard-Befehle in normaler Sprache

Befehle, die du im Chat (an mich, in normaler Sprache) tippst. Werden vom LLM interpretiert.

### Die drei Haupt-Standard-Befehle (in `CLAUDE.md` verankert)

| Befehl | Wirkung |
|---|---|
| **„Phoenix fortsetzen"** | Liest `PHOENIX_RESUME.md`, identifiziert den aktiven Sprint-Punkt, setzt mit ihm fort. Default-Befehl für nächste Sessions. |
| **„Projekt fortsetzen"** | Lädt `<projekt>/SESSION_RESUME.md`, übernimmt den dort dokumentierten Stand. |
| **„Session beenden"** | 6-Schritte-Abschluss: Welle-Ende-Debrief, Lesson-Audit (durch lesson_audit.py Hook), evtl. commit + push, Status-Dashboard, Sanitizer-Check. |

### Weitere informelle Befehle

- **„Welle-Ende"** / **„Debrief"** — triggert den Welle-Ende-Debrief explizit (auch ohne dass die Aufgabe abgeschlossen ist).
- **„Status"** — zeigt aktuellen Stand (kann auch via Telegram-`/status`).
- **„Audit X"** — startet Skill-Aufruf je nach Kontext (z.B. „Audit den Vault" → tutorial-curator).

## Welt 4 — Telegram-Slash-Commands

Tippst du an `@sanexio_bot` im Telegram-Client. Detail in **[[10 Channel-Router]]**.

| Befehl | Wirkung |
|---|---|
| `/start` | Initialisiert Bot-Chat (einmalig). |
| `/status` | Aktive Spawns, letzte Sync-Zeiten, Tier-3-Pending. |
| `/spawn <prompt>` | Agent-Run auf einem Mac, Ergebnis zurück. |
| `/pause` | Aktive Spawns pausieren. |
| `/help` | Verfügbare Befehle. |

**Aktueller Stand:** Eingehende Richtung funktioniert. Ausgehende Antworten kommen nur von Cluster-Mini-02. Diagnose in **[[10 Channel-Router]]**.

## Tier-3-Hardstops — wo sie bei welchem Befehl drohen

Übersicht, wann ein Befehl gestoppt wird:

| Befehl | Tier-3? | Warum |
|---|---|---|
| `cortex-agent run "..."` | Nur wenn die Antwort Tier-3-Tool-Calls verlangt | Der Run selbst ist frei. |
| `cortex-agent skill run sanitizer` | Nein | Memory-DB-VACUUM ist intern. |
| `cortex-agent skill run capture-lesson` | Nein | Memory-File schreiben innerhalb `~/.claude/projects/`. |
| `git push origin main` (eigene Repos) | Nein | User-Direktive 2026-05-09 — eigene Repos sind frei. |
| `git push --force` (eigene Repos) | Nein | Auch frei (eigenen Verlauf umschreiben ist OK). |
| `git push origin main` (fremde Repos) | **Ja** | Externer Empfänger (Kategorie 3). |
| `git reset --hard origin/main` (eigene Repos) | Nein | Repo-Hygiene. |
| `git rebase` (eigene Repos) | Nein | Standardflow. |
| `Write ~/.env` | **Ja** | Secrets (Kategorie 1). |
| `Write ~/.claude.json` | **Ja** | Auth-Tokens (Kategorie 1). |
| `launchctl load <plist>` | Nein | LaunchAgent für eigene Skripte ist OK. |
| `tailscale logout` | Nein | Stracke-eigener Account. |
| `gh pr merge` (eigenes Repo) | Nein | Eigene Repos sind frei. |
| `gh pr merge` (fremdes Repo) | **Ja** | Externer Empfänger. |
| `claude mcp add` (neuer Server) | **Ja** | Schreibt in `~/.claude.json`. |
| Email-Versand an Dritte | **Ja** | Externer Empfänger. |
| SmartQ-Schreibop | **Ja** | Geld-Operation (Kategorie 2). |

Volle Liste: **[[04 Tier-3 Hardstops]]** und `agent/modes/tier3.md`.

## Häufige Befehls-Sequenzen (Cookbook)

### Session starten

```bash
cd ~/Cortex/Nexus
git pull --ff-only
cortex-agent skill run doctor          # Sanity-Check
cortex-agent skill run session-start   # Digest
```

Dann in Claude Code: tippe deine Aufgabe oder „Phoenix fortsetzen".

### Session beenden

In Claude Code: **„Session beenden"** → ich erledige Debrief + commit + push.

Oder manuell:
```bash
git status                # noch was uncommitted?
git add <files>
git commit -m "..."
git push
cortex-agent skill run sanitizer   # Memory aufräumen
```

### Mac-Drift diagnostizieren

```bash
cd ~/Cortex/Nexus
git fetch origin
git rev-list --left-right --count HEAD...origin/main
# "0	N" bedeutet: N Commits behind
git pull --ff-only
```

### Skill-Aufruf vom Output her diagnostizieren

```bash
# Letzte 10 Skill-Aufrufe
sqlite3 ~/Cortex/Nexus/_memory/memory.db \
  "SELECT datetime(ts,'unixepoch') as t, skill, ok, substr(result,1,80) as result \
   FROM skill_runs ORDER BY ts DESC LIMIT 10;"
```

### Hook-Status pro Mac prüfen

```bash
jq -e '.hooks.UserPromptSubmit[] | select(.matcher == "") | .hooks[] | select(.type == "command") | .command' \
  ~/.claude/settings.json
# Erwartet: "bash $HOME/Cortex/Nexus/tools/cortex-mode/bin/inject.sh"
```

Bei leerem/Fehler-Output: Hook nachregistrieren (siehe **[[11 Hooks und Mode-Injection]]**).

### Tailscale-Mac-Liste

```bash
tailscale status | grep cortex
```

### Neues Projekt anlegen

```bash
cd ~/Cortex/projects
mkdir <projekt-name>
cd <projekt-name>
git init
# … Projekt-Setup …
# In .config/devices.json den Mac eintragen, der dieses Projekt hostet.
```

## Was du mit diesem Modul jetzt kannst

- Du kennst die vier Befehls-Welten (Slash in Claude Code, CLI im Terminal, normale Sprache, Telegram).
- Du kannst die wichtigsten `cortex-agent`-Subbefehle (run, bootstrap, mode, skill, memory) tippen.
- Du weißt, welche Befehle Tier-3 triggern.
- Du hast 6 Cookbook-Sequenzen für die häufigsten Tasks.

## Verwandte Tutorials

- **[[03 Autonomy und Safe Mode]]** — Mode-Slash-Commands im Detail
- **[[09 Self-Learning-Layer]]** — was hinter `cortex-agent` steckt
- **[[10 Channel-Router]]** — Telegram-Slash-Commands
- **[[14 Notfall und Recovery]]** — Recovery-Befehls-Sequenzen
- `agent/skills/INDEX.md` — autoritative Skill-Liste mit Aufruf-Beispielen
