---
title: Glossar
domain: cortex
modul: 99
level: einsteiger
status: kanonisch
---

# 99 — Glossar

> **Antwort in einem Satz:** Lerner-orientierter Glossar zu allen Cortex-Begriffen — Definition + Beispiel + Querverweis zum vertiefenden Modul; technisch identisch zu `_rules/glossary.md` (der Pflicht-Lese-Variante), aber didaktisch mit Beispielen und längeren Erklärungen.

Sortierung: alphabetisch. Bei Doppel-Definitionen (z.B. „Skill") sind beide Bedeutungen genannt.

---

## A

### Agent-Loop

Die Python-Schleife in `agent/loop.py`, die einen einzelnen Roundtrip mit dem LLM macht: System-Prompt + User-Prompt → Antwort. Im Cortex bewusst „Hermes-style" (eine Iteration pro Aufruf, kein verschachteltes Self-Calling). Beispiel: `cortex-agent run "Pflege Memory"` löst genau **einen** Loop-Durchgang aus.

→ **[[09 Self-Learning-Layer]]**

### Anthropic-API

Die HTTP-API von Anthropic, über die meine Antworten kommen. Nutzt `ANTHROPIC_API_KEY` aus `.env`. Cortex spricht sie auf zwei Wegen an: über Claude Code (die CLI/IDE) und über `agent/providers/anthropic.py` (der Self-Learning-Layer-CLI).

→ **[[12 Externe Dienste]]**

### Approval-Marker

Eine leere Datei `_memory/approvals/<task-id>.approved`, die einer Task die R2-Schreibfreigabe gibt. Zusätzlich: `_memory/approvals/.enforce` aktiviert den **harten** Approval-Modus (Pushes ohne Marker werden blockiert). Default-Modus ist weich.

→ **[[07 Multi-Device-Sync]]** §Approval-Marker

### Audit-Log

Append-only-Protokoll von Schreib-Operationen. Beispiele: `_memory/audit/connexio-write.jsonl`, `_memory/audit/capture-lesson.jsonl`. Hauptzweck: Compliance-Forensik. Wird vom Sanitizer nach Frist komprimiert, niemals gelöscht.

### Autonomy-Mode

Default-Modus von Claude im Cortex. Bedeutet: Aufgabe → durchziehen, kein Pre-Op-Block, Stop nur bei vier Triggern (Ambiguität, Tier-3, Token-Budget, Aufgabe erledigt). Wechsel: `/autonomy-mode` oder `cortex-agent mode set autonomy`.

→ **[[03 Autonomy und Safe Mode]]**

---

## B

### Bun

JavaScript-Laufzeit, ähnlich Node.js, aber deutlich schneller beim Starten und Builds. Im Cortex genutzt für `gateway/` (Channel-Router) und Telegram-Bridge. Installation: `brew install oven-sh/bun/bun`.

→ **[[10 Channel-Router]]**

---

## C

### Channel-Router

Die TypeScript-Schicht in `gateway/`, die externe Eingangs-Kanäle empfängt, authentifiziert, sandboxt und an den Self-Learning-Layer weiterleitet. Heute ist Telegram-V3 der erste implementierte Channel. Intern auch „OpenClaw-style" genannt (nach dem Vorbild-Framework).

→ **[[10 Channel-Router]]**

### Connexio

Die read-only-Kontextfläche und Task-Bridge für Multi-AI-Kooperation. Drei Komponenten: Kernel, MCP-Server, HTTP-Server. Andere KIs (Codex, Cursor) lesen Nexus ausschließlich über Connexio, schreiben dürfen sie nur in eng definierte Stores (Tasks, Leases, Reviews).

→ **[[08 Connexio]]**

### Cortex

Oberbegriff für das ganze System auf deinen Macs. Container: `~/Cortex/`. Beinhaltet Nexus (Steuerwerk) + Projects (Werkstatt) + Second Brain (Vault, liegt **innerhalb** Nexus). „Mein Cortex" = die Cortex-Installation auf einem deiner Macs.

→ **[[00 Was ist Cortex]]**

### Cron-Recipe

TOML-Datei in `agent/cron/recipes/`, die einen Cortex-Skill periodisch starten lässt. Beispiel: `nightly-sanitizer.toml` → läuft täglich um 3:30 Uhr und ruft `cortex-agent skill run sanitizer` auf. Aktivierung läuft über einen LaunchAgent (`com.cortex.phoenix-cron.plist`, heute noch nicht installiert).

→ **[[09 Self-Learning-Layer]]** §Cron

---

## D

### Daemon

Hintergrundprozess ohne Benutzeroberfläche, der dauerhaft oder periodisch läuft. Im Cortex-Kontext meist als LaunchAgent gestartet. Beispiel: `nexus-sync.sh` läuft alle 5 Min als Daemon.

### devices.json

Single-Source-of-Truth für die Mac-Registry. Liegt in `.config/devices.json`. Pro Mac: hostname, chip, OS, role, projects-Liste, Tailscale-Mesh-Daten. Wird vom Sync-Skript für Heartbeat-Pfade gelesen, von `doctor` für Geräte-Health-Check, von Connexio für Multi-Device-Operations.

→ **[[02 Datei-Atlas]]** §J

### Doctor (Skill)

Health-Check-Skill mit 10+ Punkten: Mode, DB, Git, Policy, Drift, Runtime, Sync, Lease, Skills, Connexio. Wichtigster Skill für Sanity-Checks. Aufruf: `cortex-agent skill run doctor`. Mit `--args '{"strift":true}'` wirft er bei jedem Failure einen System-Exit.

→ **[[14 Notfall und Recovery]]**

---

## E

### .env

Konfigurationsdatei mit umgebungsspezifischen Variablen (API-Keys, Tokens). Per `.gitignore` von Git ausgenommen, **kommt niemals in Git**. Lesen ist erlaubt (R0). Schreiben/Überschreiben/Loggen-im-Plaintext ist **Tier-3**.

→ **[[04 Tier-3 Hardstops]]**

---

## F

### FTS5

„Full-Text-Search v5", die Volltextsuche-Engine von SQLite. Im Cortex genutzt für `_memory/memory.db` — vier Tabellen mit FTS5-Indices: sessions, patterns, skill_runs, user_facts. Tokenizer: `porter unicode61` (mit Deutsch-Stemming).

→ **[[05 Memory in 4 Schichten]]** §Schicht 3

---

## G

### Gateway

Synonym für Channel-Router. Die TypeScript-Schicht in `gateway/`. Heute aktiv: Telegram-V3 als erster Channel.

### gh

GitHub-CLI. Wird im Cortex genutzt für PR-Erstellung, Issue-Lookup, API-Abfragen. Installation: `brew install gh`. Cortex hängt nicht zwingend davon ab, aber viele Workflows nutzen es.

### Glossar

Diese Datei (Modul 99) — lerner-orientiert. Plus `_rules/glossary.md` — Pflicht-Lese-Variante, knapper. Beide enthalten dieselben Begriffe; das Modul 99 hat zusätzlich Beispiele und Querverweise.

### Goldene Regeln

Destillierte Lessons-Learned + Tier-3-Hardstops + Wiederholungsfehler-Patterns (GF-001..GF-007). Single Source: `_memory/golden-rules.md`. Wird vom Agent in den System-Prompt-Block gerendert.

→ **[[02 Datei-Atlas]]** §C

---

## H

### Harness

Programm, das den Modellzugriff orchestriert: System-Prompt-Komposition, Tool-Loop, Hooks, Permission-System, Streaming. Im Anthropic-Vokabular konkret die **Claude-Code-Laufzeit**, in der jede Anwender-Sitzung läuft. Cortex erweitert den Harness ausschließlich über offizielle Erweiterungspunkte (Hooks, Skills, Slash-Commands, Memory) — der Harness selbst wird nicht gepatcht. Daneben existiert in `agent/loop.py` ein zweiter, schlanker Cortex-eigener Mini-Harness für nicht-interaktive Skript-Aufrufe.

→ **[[16 Harness — Wie Claude arbeitet]]**

### Heartbeat

Zeitstempel-Datei pro Mac unter `.config/heartbeats/<host>.heartbeat`, die `nexus-sync.sh` aktualisiert. Andere Macs nutzen den Heartbeat, um zu erkennen ob ein anderer Mac kürzlich aktiv war (Race-Vermeidung beim Sync, 90-Sek-Schwelle).

→ **[[07 Multi-Device-Sync]]**

### Hermes-style

Architektur-Begriff für die Agent-Schicht: minimale, deterministische Schleife (System-Prompt → User-Prompt → LLM-Call → Antwort). Kein verschachteltes Self-Calling. Lernen passiert durch Skills, nicht durch Loop-Rekursion. Vorbild: das Hermes-Agent-Framework. Im Tutorial konsequent **Self-Learning-Layer** genannt.

→ **[[09 Self-Learning-Layer]]**

### Hook

Skript, das automatisch bei einem bestimmten Event ausgeführt wird. Im Claude-Code-Kontext gibt es mehrere Hook-Events (PreToolUse, PostToolUse, UserPromptSubmit, …). Cortex nutzt heute den **UserPromptSubmit**-Hook: bei jeder abgesendeten Nachricht läuft `inject.sh`, das den Mode-Block + Tier-3-Block als zusätzlichen Kontext injiziert.

→ **[[11 Hooks und Mode-Injection]]**

---

## J

### JSON

„JavaScript Object Notation", textuelles Format für strukturierte Daten mit Schlüssel-Wert-Paaren und Listen. Beispiele: `.config/devices.json`, `tasks-mirror/task-*.json`, Hook-Output-Format.

```json
{"name": "Stracke", "macs": ["M5", "Studio"]}
```

### jq

Kommandozeilen-Tool zum Verarbeiten von JSON. Im Cortex unverzichtbar für Diagnose. Beispiel: `jq -r .mode ~/.claude/state/cortex-mode.json`. Installation: `brew install jq`.

---

## L

### LaunchAgent

macOS-Mechanismus (`launchd`) zum Starten von Skripten beim Boot oder in festen Intervallen. Cortex nutzt z.B. `com.cortex.nexus-sync.plist` für den Auto-Sync alle 5 Minuten. Status-Check: `launchctl list | grep cortex`.

→ **[[07 Multi-Device-Sync]]**

### Lean v3

Architektur-Spec (`specs/cortex-lean-v3/`) gegen Drift, Redundanz und Memory-vs-State-Lücke. Drei Säulen: **S1** State First (Live-State abfragen vor Memory-Recall), **S2** One-Mac-At-A-Time per Lease, **S3** Memory mit Verfallsdatum (TTL).

### Lease

Zeitlich begrenzte Schreibsperre auf eine Kombination aus `repo` und `scope`. Verhindert, dass zwei KIs gleichzeitig denselben Bereich bearbeiten. TTL-Default: 1 Stunde. Code: `agent/connexio/lease_store.py`.

→ **[[08 Connexio]]**

### Lesson-Anker

Persistenz-Hinweis am Zeilen-Ende eines „WAS GELERNT"-Bullets im Welle-Ende-Debrief. Erlaubte Anker: `-> feedback_<slug>.md`, `-> specs/<slug>/`, `-> CLAUDE.md`, `-> hook:<name>`, `(ephemer)`.

→ **[[06 Selbstlernendes System]]** und `_rules/lesson-anchors.md`

### Local-by-Flywheel

Lokale WordPress-Entwicklungsumgebung (kostenlose App). Im Cortex relevant für die praxis-webseite, die als Theme-Ordner einer Local-by-Flywheel-Site auf Cluster-Mini-02 lebt. Pfade in `~/Library/Application Support/Local/sites.json`.

### Long-Polling

Pattern, bei dem ein Client periodisch beim Server nach Updates fragt (statt der Server pushgehen würde via Webhook). Cortex nutzt Long-Polling für Telegram, weil deine Macs hinter NAT/Firewall sitzen und Webhooks nicht funktionieren würden.

→ **[[10 Channel-Router]]**

---

## M

### MCP (Model Context Protocol)

Anthropic-Standard für Tool-Brücken zwischen LLM und externen Diensten. Im Cortex stellt z.B. `agent/connexio/mcp_server.py` MCP-Tools für andere KIs bereit (`get_user_profile`, `lease_project`, `handoff_to_agent`, …). MCP-Server werden in `~/.claude.json` registriert (Tier-3-geschützt). Status: `claude mcp list`.

→ **[[08 Connexio]]**

### memory.db

Die SQLite-FTS5-Datenbank in `_memory/memory.db`. Vier Tabellen: sessions, patterns, skill_runs, user_facts. Pro Mac lokal (gitignored). Volltextsuche via `cortex-agent memory search`.

→ **[[05 Memory in 4 Schichten]]** §Schicht 3

### Mode-Block

Markdown-Inhalt aus `agent/modes/autonomy.md` oder `agent/modes/safe.md`. Wird vom Hook beim Prompt-Submit als `additionalContext` in den System-Prompt injiziert. Bestimmt das Verhalten der Session.

→ **[[03 Autonomy und Safe Mode]]**

### MOC

„Map of Content" — Obsidian-Pattern für Master-Indizes. Eine Markdown-Datei (Konvention: Präfix `_MOC`), die Pointer zu allen Dokumenten einer Domain bündelt. Beispiel: `Second Brain/30 Tutorials/Cortex/_MOC Cortex.md`.

### Mosh

„Mobile Shell", robustere SSH-Variante bei wackelnder Verbindung. Im Cortex-Mesh optional verfügbar pro Mac (Feld `mosh_enabled` in devices.json).

---

## N

### Nexus

Das Steuerwerk **innerhalb** Cortex. Liegt in `~/Cortex/Nexus/`. Enthält Regeln (`_rules/`), Memory (`_memory/`), Agent-Code (`agent/`), Gateway-Code (`gateway/`), Vault (`Second Brain/`), Sync-Skripte. Ist ein Git-Repository (`Sanexio/nexus` auf GitHub).

→ **[[00 Was ist Cortex]]**

---

## O

### Obsidian

Markdown-Notizen-App. Im Cortex nicht zwingend nötig — der Vault funktioniert als Ordner aus Markdown-Files mit oder ohne Obsidian. Obsidian bringt nur die Komfort-Schicht (Wikilink-Auto-Completion, Live-Preview, Graph-View, Mobile-Apps).

→ **[[12 Externe Dienste]]** §Obsidian

### OpenClaw-style

Architektur-Begriff für die Gateway-Schicht: kanalagnostischer Router mit Pairing-Store und Sandbox-Isolation. Vorbild: das OpenClaw-Projekt. Im Tutorial konsequent **Channel-Router** genannt.

→ **[[10 Channel-Router]]**

### Outbox

`~/Cortex/projects/_ai-cooperation-outbox/`. Ältere Markdown-basierte Übergabe-Inbox zwischen KIs. Format: `YYYY-MM-DD_<sender>-to-<receiver>_<topic>.md`. Wird ab 2026-06-12 durch Connexio-`handoff_to_agent` ersetzt.

→ **[[08 Connexio]]** §Outbox

---

## P

### Pairing-Store

Whitelist eingehender Devices im Channel-Router. Persistiert in `~/.config/gateway-pairings.json` (lokal pro Mac). Beim Eingang einer Telegram-Nachricht prüft der Router gegen den Pairing-Store, ob die Chat-ID erlaubt ist.

→ **[[10 Channel-Router]]**

### Pflicht-Lesung

Drei Files, die jede KI-Session am Anfang liest: `CLAUDE.md`, `_rules/AUTONOMY_CONTRACT.md`, `_rules/glossary.md`. Nach dem Architektur-Refactor sind die Detail-Themen aus dem AUTONOMY_CONTRACT in eigene Files ausgegliedert; der Vertrag selbst ist ein schlanker Index (rund 70 Zeilen).

### Phoenix

Hard-Reset des Nexus-Steuerwerks am 2026-05-08/09. Alte `_rules/`, `_memory/` und `tools/cortex-*` wurden gelöscht und durch die aktuelle zweischichtige Agent+Gateway-Architektur ersetzt. Backup auf GitHub als Branch `pre-phoenix-reset-2026-05-08`. Files mit „Phoenix" im Namen (`HANDOVER_PHOENIX.md`, `PHOENIX_RESUME.md`) sind die Verbleibsel dieser Migration.

→ **[[02 Datei-Atlas]]** §A

### Phoenix-Welle

Eine abgeschlossene Bearbeitungs-Einheit (z. B. „Welle 5 = Telegram-V3 + Cutover"). Endet mit Welle-Ende-Debrief + Commit + Push.

### plist

„Property List", macOS-XML-Format für Konfigurationsdateien. LaunchAgents werden als `.plist` geschrieben (z.B. `com.cortex.nexus-sync.plist`). Liegt in `~/Library/LaunchAgents/`.

---

## R

### R0 / R1 / R2 / R3

Risikolevel für KI-Operationen.
- **R0** = Read-only, immer frei.
- **R1** = Projekte schreiben (`~/Cortex/projects/`), frei wenn Projekt-Regeln das erlauben.
- **R2** = Nexus-Kern (`~/Cortex/Nexus/`) schreiben, nur mit Freigabe.
- **R3** = Hardstop (Secrets, Geld, externe Empfänger). Detail: `agent/modes/tier3.md`.

→ **[[04 Tier-3 Hardstops]]** und `_rules/risk-levels.md`

---

## S

### Safe-Mode

4-Phasen-Architekten-Workflow mit Approval-Gate vor Phase 3 (Umsetzung). Wechsel: `/safe-mode` oder `cortex-agent mode set safe`. Detail: `agent/modes/safe.md`.

→ **[[03 Autonomy und Safe Mode]]**

### Sanitizer

Skill, der alte Logs rotiert, Memory-DB vakuumiert und stale Spawn-Queue-Einträge archiviert. Aufruf: `cortex-agent skill run sanitizer`. Auch als nightly-Cron-Recipe verfügbar (aber LaunchAgent heute nicht aktiv).

→ **[[09 Self-Learning-Layer]]** §Skills

### Second Brain

Synonym für „Vault". Obsidian-Wissens-Basis innerhalb Nexus (`Nexus/Second Brain/`). Manuell gepflegt, gitversioniert, vom Sanitizer geschützt.

→ **[[05 Memory in 4 Schichten]]** §Schicht 1

### Self-Learning-Layer

Synonym für „Hermes-style Agent-Layer". Die Python-Schicht in `agent/`. Heißt „Self-Learning" weil die Strukturen für strukturelle Persistenz (Lesson-Capture, Pattern-Mining) vorbereitet sind — der automatische Anteil ist allerdings heute nur teilaktiv.

→ **[[06 Selbstlernendes System]]** und **[[09 Self-Learning-Layer]]**

### Skill

Im Cortex zwei Bedeutungen — wichtige Disambiguation:

**Skill (Python)** = `@skill`-dekorierte Funktion in `agent/skills/builtin/*.py`. Aufruf via `cortex-agent skill run <name>`. Beispiele: doctor, capture-lesson, sanitizer. Index: `agent/skills/INDEX.md`.

**Skill (.skill-Paket)** = Claude-Code-Paket-Datei in `Nexus/skills/*.skill`. Wird in `~/.claude/skills/` entpackt. Beispiele: frontend-design.skill, smartq-dashboard.skill.

→ **[[01 Architektur und Schichten]]** §Skills

### Skill-Engine

`agent/skills/engine.py` — Skill-Discovery + Execution. Lädt alle `@skill`-dekorierten Python-Funktionen via `pkgutil.iter_modules`. Loggt jeden Skill-Aufruf in `memory.db.skill_runs`.

### Slash-Command

Befehl in Claude Code, der mit `/` beginnt und vom Harness (nicht vom LLM) verarbeitet wird. Beispiele: `/autonomy-mode`, `/safe-mode`, `/help`, `/clear`, `/hooks`, `/model`, `/config`.

→ **[[13 Slash-Commands und CLI]]**

### Spawn / Spawn-Queue

Mechanismus, mit dem Telegram/iPad-Nachrichten an Cortex zwischengepuffert werden, bis ein Agent verfügbar ist. Code: `agent/connexio/spawn_queue.py`, `spawn_watcher.py`. Bedienung via Telegram: `/spawn <prompt>`.

→ **[[10 Channel-Router]]**

### SSOT

„Single Source of Truth". Prinzip: pro Information existiert genau eine authoritative Quelle. Verhindert Drift und Widersprüche. Beispiele im Cortex:
- `.config/devices.json` ist SSOT für Mac-Registry.
- `agent/modes/tier3.md` ist SSOT für Tier-3-Liste.
- GitHub ist SSOT für Nexus-Repo.

### State-First

Lean-v3-Prinzip: vor Empfehlungen aktiven Status abfragen (`git log`, SSH, DB, curl) statt Memory zu vertrauen. Memory ist nur für Insights/Learnings, nicht für State.

→ Lean v3 §S1 in `specs/cortex-lean-v3/00_KONZEPT.md`

---

## T

### Tailscale

Mesh-VPN-Dienst, der deine Macs in ein privates Netz verbindet (private IPs aus dem 100.x.x.x-Range). Cortex nutzt Tailscale für SSH zwischen Macs (`ssh ssmd@cluster-mini-02` via tailscale-ssh). Dein Tailnet heißt `piranha-marlin.ts.net`.

→ **[[12 Externe Dienste]]** §Tailscale

### Task

Eine Aufgabe im Multi-Agent-Workflow. Pflichtfelder: id, title, created_by, assigned_to, repo, scope, risk_level, allowed_paths, … . State-Machine: proposed → accepted → in_progress → … → done/rejected. Persistenz dreifach: SQLite + JSON-Mirror (gitversioniert) + Audit-Log.

→ `_rules/tasks.md` und **[[08 Connexio]]**

### Task-Mirror

JSON-Datei pro Task unter `_memory/tasks-mirror/task-<id>.json`, gitversioniert. Damit sind Tasks cross-device sichtbar (die lokale `tasks.db` ist nur Cache).

### Tier (Tier-3)

Risiko-Klassifikation für Operationen. **Tier-3** = Hardstop-Operationen, die immer Stop + User-Freigabe brauchen. Drei Kategorien: Secrets, Geld, externe Empfänger. Single Source: `agent/modes/tier3.md`. „Tier-3" und „R3" sind synonym.

→ **[[04 Tier-3 Hardstops]]**

### TOML

„Tom's Obvious, Minimal Language", Konfigurationsformat mit Schlüssel-Wert-Paaren und Sektionen. Beispiele im Cortex: `pyproject.toml`, Cron-Recipes (`agent/cron/recipes/*.toml`), Tailscale-ACL-Vorlage.

### Tool-Loop

Kern-Mechanik jedes Harness: Modell antwortet entweder mit Text oder mit einem Tool-Call. Bei Tool-Call führt der Harness das Tool aus, fügt das Resultat als Assistant-Message in die History ein und ruft das Modell erneut auf. Schleife endet, wenn das Modell mit reinem Text antwortet. Jede Iteration verbraucht zusätzliches Token-Budget.

→ **[[16 Harness — Wie Claude arbeitet]]**

### TTL

„Time-To-Live", Ablaufzeit. Beispiele im Cortex:
- Memory-Facts in `memory.db` mit `expires_at`-Feld (Lean v3 §M3).
- Leases mit `ttl_seconds` (Default 3600s).
- Logs mit Retention-Frist (Sanitizer).

---

## U

### uv

Schneller Python-Paketmanager von Astral. Cortex nutzt `uv` statt `pip`/`poetry` für Dependency-Management. Manifest: `pyproject.toml`, Lock-File: `uv.lock`. Installation: `brew install astral-sh/uv/uv`.

### UserPromptSubmit-Hook

Der Hook-Event, der bei jeder von dir abgesendeten Nachricht in Claude Code feuert. Cortex nutzt ihn für die Mode-Injection via `inject.sh`. Registration in `~/.claude/settings.json`.

→ **[[11 Hooks und Mode-Injection]]**

---

## V

### Vault

Synonym für „Second Brain". Der Obsidian-Markdown-Vault innerhalb Nexus.

---

## W

### Welle

Synonym für „Phoenix-Welle". Eine abgeschlossene Bearbeitungs-Einheit im Sprint, endet mit Welle-Ende-Debrief + Commit + Push.

### Welle-Ende-Debrief

Strukturierter Abschluss-Block am Ende einer Session/Welle. Drei Blöcke:
- **WAS GEMACHT** (Pflicht, 3-7 faktische Bullets).
- **WAS GELERNT** (optional, mit Persistenz-Anker pro Bullet).
- **STRATEGISCHE WAHLEN** (optional, nur bei echten Verzweigungen).

Live-Deploys müssen IMMER erwähnt werden.

→ **[[03 Autonomy und Safe Mode]]** §Welle-Ende-Debrief

### Wikilink

Obsidian-Syntax `[[Ziel]]` für interne Verlinkungen zwischen Markdown-Dateien im Vault. Im Lesemodus klickbar. „Wikilinks brechen" = Linkziel existiert nicht (mehr) — die Datei wurde umbenannt oder gelöscht. Der Skill `tutorial-curator` findet solche Broken-Links beim Vault-Audit.

→ **[[02 Datei-Atlas]]** §K

### Workflow (Skill-Kette)

YAML-Definition einer Skill-Sequenz (z.B. welle-ende → capture-lesson → doctor → session-end). Liegt in `agent/workflows/*.yaml`. **Heute Stub** — die Engine ist noch nicht implementiert.

→ **[[06 Selbstlernendes System]]** §Hebel 5 und **[[09 Self-Learning-Layer]]** §Hebel C

---

## Z

### Zero-Trust

Sicherheits-Prinzip: jede Operation wird gegen Regeln geprüft, auch wenn der Anrufer „vertraut" ist. Im Cortex umgesetzt durch R0-R3-System (Schreibrechte explizit), Tier-3-Hardstops (selbst der User braucht für manche Ops explizite Freigabe), Connexio-Boundaries (andere KIs read-only).

---

## Querverweis — wo finde ich das vertiefende Modul?

| Begriffsgruppe | Vertiefung |
|---|---|
| Cortex, Nexus, Projects, Vault | **[[00 Was ist Cortex]]** |
| Schichten, Self-Learning-Layer, Channel-Router | **[[01 Architektur und Schichten]]** |
| Datei-Pfade, Phoenix, Wikilinks | **[[02 Datei-Atlas]]** |
| Autonomy, Safe, Mode-Switch | **[[03 Autonomy und Safe Mode]]** |
| Tier-3, .env, Hook-Trigger | **[[04 Tier-3 Hardstops]]** |
| Memory-Schichten, FTS5, Vault, Claude-Memory | **[[05 Memory in 4 Schichten]]** |
| Lesson-Capture, Pattern-Mining, Workflows | **[[06 Selbstlernendes System]]** |
| Sync, Heartbeat, LaunchAgent, Recovery | **[[07 Multi-Device-Sync]]** |
| Connexio, MCP, Tasks, Leases | **[[08 Connexio]]** |
| Agent-Loop, CLI, Skills, Providers | **[[09 Self-Learning-Layer]]** |
| Gateway, Telegram, Channel-Pattern | **[[10 Channel-Router]]** |
| Hook, inject.sh, Helper-Skripte | **[[11 Hooks und Mode-Injection]]** |
| GitHub, Tailscale, Obsidian, Anthropic, Telegram | **[[12 Externe Dienste]]** |
| Slash-Commands, CLI, Bash, jq | **[[13 Slash-Commands und CLI]]** |
| Notfall-Diagnose, Recovery-Sequenzen | **[[14 Notfall und Recovery]]** |
| Erweiterungs-Hebel, Public-Skeleton | **[[15 Erweitern und Sichern]]** |

## Querverweis — kanonische Regel-Quellen

Diese Files in `_rules/` sind die authoritative Quellen, falls dieser Glossar einen Begriff vereinfacht darstellt:

- `_rules/glossary.md` — knappere Variante dieses Files (Pflicht-Lesung).
- `_rules/AUTONOMY_CONTRACT.md` — Index der Regel-Familie.
- `_rules/risk-levels.md` — R0-R3 Volldetail.
- `_rules/modes.md` — Mode × Risiko-Matrix.
- `_rules/stop-conditions.md` — alle Stop-Trigger.
- `_rules/tasks.md` — Task-State-Machine + Pflichtfelder.
- `_rules/lesson-anchors.md` — Persistenz-Anker-Regel.
- `_rules/sync-policy.md` — Runtime-Sync-Aggregat.
- `_rules/security.md` — Token + Secrets + Logging.
- `_rules/medical-domain.md` — Stracke-Praxis-Boundary.
- `_rules/user-directives.md` — Pauschal-Freigabe 2026-05-09.
- `_rules/ai-cooperation.md` — Claude × Codex Peer.
- `_rules/multi-ai-boundaries.md` — andere KIs am Nexus.
- `_rules/retention.md` — Anti-Müll.
- `_rules/verification.md` — Pre-done-Checks.
- `agent/modes/tier3.md` — Tier-3 Single Source.
