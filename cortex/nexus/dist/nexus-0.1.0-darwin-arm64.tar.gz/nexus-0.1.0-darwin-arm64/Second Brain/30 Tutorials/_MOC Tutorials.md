---
type: moc
aliases: [Tutorials, Wissensbasis, Knowledge Base]
tags:
  - moc
  - tutorial
---

# Tutorials — Map of Content

Organisch wachsendes Tutorial-System für Dr. Stracke.
Alle Tutorials liegen als Markdown-Dateien in diesem Obsidian-Vault.

> [!tip] Schnelleinstieg
> Wenn du nicht weißt, **wo du anfangen sollst**, ist [[_Basiswissen Schnelleinstieg]]
> die zentrale Karte. Sie zeigt Lernpfade nach Priorität (Sysadmin / Web / iOS),
> einen 30-Minuten-Crashkurs und die offensichtlichen Lücken.

> [!info] Single Source of Truth (seit 2026-04-14)
> Die Tutorial-Dateien leben physisch hier unter `Second Brain/30 Tutorials/<Domäne>/`.
> `Nexus/_tutorials/<slug>/` ist nur noch ein Mac-seitiger Symlink auf den jeweiligen
> Ordner — alte Pfadreferenzen funktionieren weiter, aber es gibt nur EINE Quelle.
>
> - Edit im Obsidian (Mac oder iPad) → Änderung wirkt überall
> - Edit via `_tutorials/...` auf dem Mac → Symlink führt zur gleichen Datei
> - Kein Drift, kein Sync-Script nötig

---

## Tutorial-Domänen

> **Domain-Status — Single Source of Truth.** `_Basiswissen Schnelleinstieg.md`
> referenziert diese Tabelle, repliziert sie nicht.
> **Stand: 2026-05-05 (Sprint F2 Reorg).**

### Operative Domänen (echte Lehrinhalte)

| Status | Domäne | Landing | Module | Beschreibung |
|:-:|---------|--------|:------:|-------------|
| 🟢 | Cortex & Nexus | [[Cortex & Nexus Grundlagen]] | 7 | Architektur & Philosophie, Multi-Device Setup, Memory-Layers, Trust-Tiers, Selbstlernendes System, Autonomy v2/v3 |
| 🟢 | Arbeitsweise & Prozess | [[Arbeitsweise Grundlagen]] | 10 | Architekten-Modus, Memory-Systeme, Adapter-Patterns, Vault-Kommunikation, Content-Triage, Prio-Leiter, Graph-Vernetzung, Lazy-Path |
| 🟢 | Terminal & CLI | [[Terminal Grundlagen]] | 6 + Setup + Git-Konzepte | Grundlagen, Git, npm/Node, GitHub, Shopify+Blender-Workflows, Nexus-Cortex-Setup |
| 🟢 | Netzwerk & Sysadmin | [[Netzwerk Grundlagen]] | 11 + Homelab | IP, DNS, DHCP, Router, CGNAT, Netzwerk-Scan, Tailscale-Mesh, Remote-Zugriff, Homelab-Handbuch |
| 🟢 | Proxmox *(Sub von Sysadmin)* | [[Proxmox Grundlagen]] | 6 + Praxis | Hypervisor, VMs/Container, Storage/Backup, Netzwerk, Sicherheit, Monitoring |
| 🟢 | Webdesign *(Sub von Webentwicklung)* | [[Webdesign Grundlagen]] | 12 | CSS-Spezifität, Design-Tokens (2/4 Schichten), Type-Scale, DSGVO-Fonts, Render-Diagnose (generisch — nicht WP-spezifisch) |
| 🟢 | WordPress | [[WordPress Grundlagen]] | 22 | Bridge-Pages, REST-API-Adapter, Verify-Probes, Theme-Render-Source, Blocksy-Override, Stammdaten-SSoT, Detail-Page-Mirror, Plugin-Lifecycle, DB-Cleanup, manueller Deploy |
| 🟢 | Shopify & Liquid *(Sub von Webentwicklung)* | [[Shopify Grundlagen]] | 7 | Liquid-Syntax, Admin-API, 3D-Avatare, Avatar-Deploy, Custom-App-Token, Product-Sync, Template-Bridge |
| 🟢 | Blender & 3D *(Sub von Design)* | [[Blender Grundlagen]] | 4 | UI-Grundlagen, Python-Scripting (`bpy`), Blender-MCP-Setup, Troubleshooting |
| 🟡 | iOS & Swift | [[iOS Grundlagen]] | 2 | Swift-Grundlagen, SwiftUI |
| 🟠 | Browser-Automatisierung *(Sub von Webentwicklung)* | [[Browser-Automatisierung Grundlagen]] | 1 | web-pilot |
| 🟠 | Gaming | [[Gaming Grundlagen]] | 1 | DOOM im Browser (Emscripten/WebAssembly) |

### Verteiler-Domänen (Dach-Files, kein eigenständiger Status)

| Domäne | Landing | Rolle |
|---|---|---|
| Webentwicklung | [[Webentwicklung Grundlagen]] | Verteiler über Webdesign + WordPress + Shopify + Browser-Automatisierung |
| Design | [[Design Grundlagen]] | Verteiler über Blender & 3D + Design-Skills |

### Konzept-/Landing-Domänen (Übersicht steht, Tiefenmodule folgen bei Bedarf)

| Status | Domäne | Landing | Inhalt |
|:-:|---|---|---|
| 🟠 | KI & Claude | [[KI & Claude Grundlagen]] | LLM-Theorie, Claude-Familie, MCP-Server, Prompt-Engineering, Cortex-Workflow |
| 🟠 | Python | [[Python Grundlagen]] | Syntax-Basics, venv/pip, `_lib/`-Tour |
| 🟠 | Sicherheit & Datenschutz | [[Sicherheit & Datenschutz Grundlagen]] | DSGVO, 2FA, Passwort-Manager, Verschlüsselung, Backup 3-2-1 |

**Legende:** 🟢 solide · 🟡 Basis vorhanden · 🟠 Übersicht/Erweiterung steht aus.

> **Reorganisation 2026-05-05 (Sprint F2):** Webdesign 33→12 (generische Module),
> WordPress 3→22 (Praxis-Lessons aus dem Praxis-Webseiten-Sprint zugewandert).
> Git & GitHub aufgelöst → Konzepte unter `Terminal/Git Konzepte/`.
> KI&Claude-Tools (Memory-Nudge, Pattern-Miner, Session-Search) nach
> `Nexus/tools/<tool>/TUTORIAL.md`. PROJEKT-STAND-Files nach
> `_archive/projekt-stand-snapshots/`.

---

## Drei-Dateien-System ([[TUT-001]])

Jedes Tutorial-Modul hat **mindestens** eine Theorie-Datei. `_claude.md` und
`_manuell.md` sind nur dort sinnvoll, wo eine Workflow-Trennung tatsächlich
existiert (Operativ-Module wie Proxmox, Terminal, Blender, iOS).

| Datei | Inhalt | Pflicht? |
|-------|--------|---------|
| `XX-thema.md` | Konzepte & Theorie (WAS) | **Ja** |
| `XX-thema_claude.md` | Claude-Workflow (WIE automatisiert) | Optional — nur bei operativen Modulen mit echter Workflow-Trennung |
| `XX-thema_manuell.md` | Manueller Workflow (WIE klassisch) | Optional — wie oben |

> **Ergänzung 2026-05-05 (Sprint F2 Reorg):** Bei reinen Konzeptmodulen
> (Cortex-Architektur, Memory-Layers, Trust-Tiers, Webdesign-Theorie) wäre eine
> `_claude`/`_manuell`-Trennung künstlich — diese Module bleiben single-file.
> Frühere TUT-001-Fassung legte „bis zu drei" fest, in der Praxis aber wurde
> die Drei-Dateien-Regel nur in 5 von 10 Domänen konsequent gelebt.

---

## Aktualisierung & Pflege

1. **Single Source of Truth:** Alle Tutorials leben physisch hier, `_tutorials/` ist Symlink
2. **Session-getrieben:** Neue Befehle/Konzepte aus Sessions fließen automatisch ein ([[LL-022]])
3. **Proaktiv:** Claude ergänzt Tutorials auch ohne explizite Aufforderung ([[LL-035]])
4. **Konsistent:** Alle Dateien folgen dem TUT-001-Format
5. **Mobil:** iPad-Obsidian-Sync erreicht alle Tutorials nativ (keine Symlinks im Vault)

---

*Verwandte Notizen:* [[_Basiswissen Schnelleinstieg]], [[_MOC Kontext]], [[_MOC Tools]], [[_MOC Glossar]]

## Letzte Strukturänderungen

- **2026-05-05 (Sprint F2 Reorg, Welle A+B+C):** Audit von 178 Files → 5 Numerierungs-Konflikte aufgelöst, 7 PROJEKT-STAND-Files nach `_archive/projekt-stand-snapshots/` verschoben, 3 Tool-Tutorials aus `KI & Claude/` nach `Nexus/tools/<tool>/TUTORIAL.md`, Domäne `Git & GitHub` aufgelöst → Konzept-File unter `Terminal/Git Konzepte/`. **Webdesign-Aufspaltung:** 33 Module → 12 generisch (Webdesign) + 22 WordPress-Praxis (in WordPress-Domäne). LERNPFAD.md jeweils neu geschrieben. Hierarchie-Drift: Webentwicklung + Design jetzt explizit als Verteiler-Domänen ohne eigenen Status. TUT-001 erweitert: Drei-Dateien-Regel optional bei Konzeptmodulen.
- **2026-04-30:** Domäne Cortex & Nexus angelegt und am selben Tag vervollständigt (5 Module).
- **2026-04-25 (Phase 2):** Vier neue Konzept-Domänen — KI & Claude, Python, WordPress, Sicherheit & Datenschutz.
- **2026-04-25 (initial):** Master-MOC angelegt.
