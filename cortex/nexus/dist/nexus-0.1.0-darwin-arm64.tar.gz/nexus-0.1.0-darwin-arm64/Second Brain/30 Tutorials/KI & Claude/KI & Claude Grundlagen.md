---
type: tutorial
aliases: [KI, AI, Claude, LLM, Large Language Model, Anthropic, Prompt-Engineering, MCP]
tags:
  - tutorial
  - ki
  - llm
  - claude
  - anthropic
source: Second Brain/30 Tutorials/KI & Claude/
---

# KI & Claude — Grundlagen

> Du arbeitest jeden Tag mit Claude. Diese Seite erklärt, **was Claude
> eigentlich ist**, wie sie „denkt", warum sie manchmal versagt, und wie
> du sie steuerst — damit du sie nicht nur benutzt, sondern verstehst.

> [!info] Lesezeit: 15 Minuten · Voraussetzung: keine

---

## 1. Was ist überhaupt eine „KI"?

Im Alltag ist „KI" ein Buzzword für viele unterschiedliche Dinge. Praktisch
sinnvoll ist die Trennung in drei Familien:

| Familie | Was sie tut | Beispiele |
|---|---|---|
| **Klassische Algorithmen** (1950er–heute) | Folgen festen Regeln (if/then). Keine Lernfähigkeit. | Spam-Filter mit Keyword-Listen, Kalender-Erinnerung |
| **Klassisches Machine Learning** (1990er–2010er) | Lernt Muster aus Daten, antwortet auf zahlenartige Fragen. | Bilderkennung „Hund/Katze", Empfehlungssysteme („Wer das kaufte, kaufte auch…") |
| **Generative KI / Large Language Models** (ab ~2020) | Schreibt Text/Code/Bilder als Antwort, hat „Allgemeinwissen", spricht mit dir wie ein Mensch. | **Claude**, ChatGPT, Gemini, Stable Diffusion (Bilder), DALL·E |

Wenn dieses Tutorial „KI" sagt, meint es **Generative KI / LLMs** — die dritte Familie.

---

## 2. Was genau ist ein „LLM"?

LLM = **Large Language Model** = großes Sprach-Modell.

Drei Sätze, die das Wesen erfassen:

1. Ein LLM ist ein **Modell des Schreibens**. Trainiert auf riesigen Textmengen (Bücher, Websites, Code) hat es gelernt: „Was ist das wahrscheinlich nächste Wort?"
2. Es **versteht** im streng biologischen Sinn nichts. Es rechnet Wahrscheinlichkeiten — aber so gut, dass das Ergebnis sich anfühlt wie Verständnis.
3. Es hat **kein Gedächtnis** zwischen Sitzungen, kein eigenes Selbst, keine Echtzeit-Information außerhalb des Trainings.

> **Analogie für deine Praxis:** Ein LLM ist wie ein extrem belesener Kollege, der gerade aus der Bibliothek kommt — das Wissen aller gelesenen Bücher im Kopf. Er kann gut formulieren, kombinieren, erklären. Aber sobald die Sitzung endet, vergisst er alles. Und alles, was nach seinem letzten Bibliotheks-Tag passiert ist, weiß er nicht.

---

## 3. Wie kommt das Verstehen zustande? (in 5 Schritten)

| Schritt | Was passiert |
|---|---|
| **1. Tokenisierung** | Dein Text wird in kleine Stücke zerlegt (Wörter oder Wortteile = „Tokens"). „Praxiszentrum" → vielleicht `Praxis` + `zentrum`. |
| **2. Embedding** | Jedes Token wird in einen Zahlenvektor übersetzt (mehrere tausend Zahlen pro Token). Ähnliche Wörter haben ähnliche Vektoren. |
| **3. Transformer-Schichten** | Das Modell schaut sich alle Tokens gleichzeitig an und gewichtet, welche füreinander relevant sind („Attention"). Genau das macht GPT/Claude so gut. |
| **4. Wahrscheinlichkeitsverteilung** | Ausgabe: für jedes mögliche nächste Token eine Wahrscheinlichkeit. |
| **5. Sampling** | Das Modell wählt ein Token (meist das wahrscheinlichste) und hängt es an die Antwort an. Dann zurück zu Schritt 3. |

Wenn Claude dir antwortet, passiert das **Wort für Wort**, manchmal hundertfach pro Sekunde. Das „Tippen" das du siehst, ist nicht stilisierte Animation — es ist genau diese Schleife.

---

## 4. Die Claude-Familie (Anthropic)

Claude ist von der Firma **Anthropic** (Sitz San Francisco). Die Modelle kommen in Generationen:

| Generation | Stärke | Einsatzgebiet |
|---|---|---|
| **Opus** (gegenwärtig 4.7) | Größtes, klügstes Modell — beste Reasoning-Leistung | Komplexe Aufgaben, Architektur, kniffeliges Refactoring |
| **Sonnet** (4.6) | Ausgewogen — schnell genug, klug genug | Tagesgeschäft, längere Sessions |
| **Haiku** (4.5) | Kleinstes, schnellstes — günstig | Klassifikation, einfache Antworten, hohe Volumen |

Du selbst nutzt vor allem **Claude Code (Terminal-CLI)** und **Cowork (Desktop-App)**. Beide laufen auf Claude-Modellen.

> **Was bei dir gerade läuft:** Diese Antwort kommt aus **Opus 4.7 (1M context)** — siehe Environment in jeder Session.

---

## 5. Drei Eigenschaften, die du im Alltag merkst

### Hallucination (Halluzination)
Wenn das Modell etwas nicht weiß, **erfindet** es manchmal trotzdem eine plausibel klingende Antwort. Beispiele: erfundene API-Endpoints, falsche Versionsnummern, nicht-existente Bibliotheken. Cortex hat dafür eine harte Regel: **„Keine Daten erfinden"** ([[GLOBAL_RULES]]).

### Context-Window
Das Modell „sieht" nur die letzten N Tokens (heute typisch 200 k bis 1 M). Lange Sessions werden irgendwann komprimiert oder vergessen. Deshalb brauchen wir `MEMORY.md` und `SESSION_RESUME.md` — die packen das Wichtigste **vor** jeder Session zurück in den Context.

### Knowledge-Cutoff
Das Modell kennt nur das, was bis zu seinem Trainings-Stichtag im Internet stand. Claude Opus 4.7 hat Knowledge-Cutoff **Januar 2026**. Was danach passiert ist (z. B. neue WordPress-Versionen), muss du dem Modell als Kontext reingeben.

---

## 6. Wie du Claude steuerst — Prompt-Engineering in 3 Stufen

### Stufe 1: Klare Sprache
- Statt: „mach das schöner" → „erhöhe Spacing zwischen den Sections um 50%, ändere Heading-Font auf Poppins"
- Statt: „repariere den Bug" → „beim Klick auf Doctolib-Button passiert nichts, console zeigt `undefined is not a function`"

### Stufe 2: Rolle + Kontext + Aufgabe + Format
```
[Rolle]    Du bist Senior-WordPress-Entwickler.
[Kontext]  Praxis-Webseite, WP 6.5, Theme `praxiszentrum`.
[Aufgabe]  Hero-Sektion mobile-tauglich machen.
[Format]   Diff-Vorschlag in Markdown, ohne weitere Erklärung.
```

### Stufe 3: Architekten-Modus (siehe [[Arbeitsweise & Prozess/01-architekten-modus|01-Architekten-Modus]])
Vier-Phasen-Prozess: **Verständnis → Lösungsdesign → Umsetzung → Selbstprüfung**. Keine Code-Änderung ohne Spec, keine Spec ohne Freigabe.

---

## 7. MCP — Model Context Protocol (deine Brücken zu Claude)

**MCP** ist ein offenes Protokoll, mit dem Claude **externe Werkzeuge** nutzen kann. Aus Claudes Sicht ist ein MCP-Server eine Werkbank, die ihr Werkzeuge (Tools) anbietet — sie kann fragen „rufe Tool X mit diesen Argumenten auf", und der Server antwortet.

**Bei dir aktiv:**

| MCP-Server | Was er tut | Aktiv auf |
|---|---|---|
| **claude.ai Figma** | Liest Designs aus Figma, erzeugt FigJam-Diagramme | beide Macs |
| **claude.ai Google Drive** | Sucht/liest Dateien aus Google Drive | beide Macs |
| **telegram-bridge** | Schickt Push-Nachrichten an dein iPhone (Bot `@sanexio_bot`) | beide Macs |
| **Blender-MCP** | Claude führt Python-Skripte direkt im laufenden Blender aus | nur Cluster-Mini-02 |

**Setup:** MCP-Server werden in `~/.claude/.mcp.json` (Projekt-Scope) oder über `claude mcp add -s user` (User-Scope) registriert. Details in `Nexus/tools/telegram-bridge/SETUP.md` (am Beispiel).

---

## 8. Cortex-Spezifisches: Wie Claude bei dir arbeitet

Cortex ist dein eigenes Regelsystem für Claude. Drei Stützpfeiler:

| Pfeiler | Was es ist | Wo |
|---|---|---|
| **MEMORY.md** | Index aller aktiven Projekte, Top-Fehler, Goldenen Regeln, Pfad-Referenzen | `Nexus/_memory/MEMORY.md` |
| **GLOBAL_RULES.md** | LL-001 bis LL-050, Fehler-Workflow, Delivery-Checkliste | `Nexus/_rules/GLOBAL_RULES.md` |
| **CLAUDE.md** | Pflicht-Init-Reihenfolge, Projekt-Architektur, „die fünf Nie-Vergessen-Regeln" | `Nexus/CLAUDE.md` |

Bei jedem Sessionstart liest Claude diese drei Dateien — daraus folgt das Verhalten, an das du dich gewöhnt hast.

**Wichtige LL-Regeln zum Verhalten:**
- **LL-021** Implementierung = funktionstüchtig
- **LL-024** Transparente Kommunikation (WAS / WARUM / WAS BEDEUTET DAS)
- **LL-034** Optionen statt Empfehlung
- **LL-049** Sync-Hygiene (Pre-Session-Pull)
- **LL-050** Destruktive Git-Operationen — Freigabe-Pflicht

Mehr in [[Arbeitsweise Grundlagen]].

---

## 9. Was Claude NICHT kann (und was das für dich heißt)

| Limitation | Was das praktisch bedeutet |
|---|---|
| Kein Echtzeit-Internet | Wenn du aktuelle WordPress-CVE-Liste brauchst → WebFetch/WebSearch nötig (separate Tools) oder du gibst die URL/den Auszug rein |
| Kein Gedächtnis zwischen Sessions | Eigentliches Gedächtnis liegt in MEMORY.md, SESSION_RESUME.md, `_memory/`-Ordner — Claude lädt das selbst |
| Keine echte Datei-Persistenz auf dem PC | Claude in Cowork/Desktop kann Dateien lesen/schreiben über Tools, aber nicht „im Hintergrund laufen" |
| Limitiertes Mathematik-Verständnis | Beim Rechnen lieber Formel hinschreiben lassen + Python ausführen, als Claude rechnen lassen |
| Keine eigene Meinung | Claude wirkt überzeugt, wenn sie etwas sagt — aber sie kann irren. **Verifizieren bei Risiko-Aktionen.** |

---

## 10. Geplante Module (Roadmap dieser Domäne)

Die Landing-Page steht — Tiefe folgt bei Bedarf:

- **01** — Was ist ein Token, ein Embedding, eine Attention-Schicht (Theorie der Architektur)
- **02** — Prompt-Engineering vertieft (Few-Shot, Chain-of-Thought, Role-Prompting)
- **03** — MCP-Server bauen (eigenen MCP für ein Praxis-Tool, Beispiel: smartq-dashboard)
- **04** — Claude-API direkt nutzen (Python/Bun, Token-Caching, Streaming)
- **05** — Modell-Wahl: wann Opus, wann Sonnet, wann Haiku
- **06** — Halluzination erkennen + Gegenstrategien
- **07** — Memory-Systeme der Zukunft (semantische Caches, RAG-Architekturen, Vektor-Stores)

Sag Bescheid, wenn eines davon dran sein soll.

---

## 11. Begriffe, die dir begegnen

| Begriff | Bedeutung |
|---|---|
| **Token** | Kleinste Texteinheit, mit der das Modell rechnet (~3–4 Buchstaben in deutschem Text) |
| **Context-Window** | Maximale Token-Anzahl, die das Modell in einer Session „sehen" kann |
| **Embedding** | Vektor-Darstellung eines Tokens (~4 000 Zahlen pro Token bei großen Modellen) |
| **Attention** | Mechanismus, mit dem das Modell relevante Teile des Inputs gewichtet |
| **Sampling** | Auswahl-Strategie für das nächste Token (Temperature, Top-K, Top-P) |
| **Temperature** | „Kreativitäts"-Regler — niedrig = präzise, hoch = wild |
| **Prompt** | Dein Input ans Modell |
| **System Prompt** | Verhaltens-Anweisungen, die vor jedem Chat stehen (Cortex packt da MEMORY.md & Co. rein) |
| **Hallucination** | Erfundene aber plausibel klingende Antwort |
| **Knowledge-Cutoff** | Stichtag, bis zu dem das Trainings-Wissen reicht |
| **Fine-Tuning** | Nach-Training eines Basis-Modells auf spezifische Daten |
| **RAG** | Retrieval-Augmented Generation — externe Wissens-DB statt nur Training |
| **MCP** | Model Context Protocol — Standard für Tool-Brücken zu Claude |
| **Tool / Function-Calling** | Claude darf Tools auf deinem System aufrufen, mit Argumenten |
| **Streaming** | Antwort kommt Token-für-Token, nicht erst am Ende komplett |
| **Inference** | Der eigentliche Rechen-Vorgang, der die Antwort produziert |

---

## 12. Lern-Reihenfolge

1. **Diese Seite** (du bist hier) — die Konzepte
2. [[Arbeitsweise Grundlagen]] — wie Claude bei dir arbeitet, Cortex-Regeln
3. [[Arbeitsweise & Prozess/01-architekten-modus|01 — Architekten-Modus]] — der wichtigste Mode-Switch
4. [[Arbeitsweise & Prozess/07-vault-kommunikation|07 — Vault-Kommunikation]] — Claude über Callouts ansprechen
5. **Optional:** Prompt-Engineering vertieft (Modul 02 dieser Domäne, sobald angelegt)

---

## Verwandte Notizen

- [[_MOC Tutorials]] — Dach-MOC aller Tutorials
- [[_Basiswissen Schnelleinstieg]] — Querschnittspfad
- [[Arbeitsweise Grundlagen]] — Cortex-Workflow im Detail
- [[Telegram-Bridge]] — MCP-Server-Beispiel im Praxis-Einsatz (sofern Notiz existiert)
- [[Cortex-Mesh]] — Geräte-Verbindung via Tailscale
- [[GLOBAL_RULES]] — Verhaltens-Regeln LL-001…LL-050


<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

<!-- Tool-Tutorials nach Sprint F2 Reorg (2026-05-05) verschoben:
     Memory-Nudge → tools/memory-nudge/TUTORIAL.md
     Pattern-Miner → tools/pattern-miner/TUTORIAL.md
     Session-Search → tools/session-search/TUTORIAL.md
-->

<!-- /auto-moc-links -->
