---
type: tutorial
aliases: [Python, py, _lib, pip, venv, Python-Skripte, Praxis-Tools]
tags:
  - tutorial
  - python
  - programmierung
source: Second Brain/30 Tutorials/Python/
---

# Python — Grundlagen

> Python ist die Sprache, in der **fast alle deine Praxis-Tools** geschrieben
> sind: PDF-OCR, Datei-Umbenennung, CashFlow-Kategorisierung, Befund-
> Extraktion. Diese Seite gibt dir einen Überblick — danach kannst du die
> Skripte in `_lib/` lesen und kleinere Anpassungen selbst machen.

> [!info] Lesezeit: 12 Minuten · Voraussetzung: Terminal-Grundlagen empfohlen

---

## 1. Warum Python?

Python ist die Standard-Sprache für **Skripte, Daten-Verarbeitung und
Automatisierung**. Drei Gründe, warum sie überall ist:

| Eigenschaft | Bedeutung |
|---|---|
| **Lesbar wie Pseudocode** | `if alter < 18:` statt `if (age < 18) {`. Du verstehst Python-Code, auch ohne ihn je geschrieben zu haben. |
| **Riesige Bibliothek** | Für fast alles gibt es ein Paket — PDF lesen (`pdfplumber`), Excel schreiben (`openpyxl`), Bilder bearbeiten (`Pillow`), KI-API nutzen (`anthropic`). |
| **Standard im Wissenschafts-Umfeld** | Datenanalyse, Statistik, Machine Learning — Pflichtsprache. |

Im **medizinischen Kontext** ist Python deshalb die naheliegende Wahl: Befunde extrahieren, Daten anonymisieren, Auswertungen, KI-Anbindung. Ärzte und Forschungs-Statistiker nutzen es täglich.

---

## 2. Python in 60 Sekunden — Syntax-Spickzettel

Lass uns einen Mini-Code lesen — danach erkennst du 80% von dem, was in `_lib/` steht:

```python
# Variablen — keine Typdeklaration nötig
patient_name = "Max Mustermann"
alter = 67
ist_versichert = True
laborwerte = [4.2, 5.8, 3.1]   # Liste

# Dictionary (Schlüssel-Wert-Paare)
patient = {
    "name": patient_name,
    "alter": alter,
    "diagnosen": ["Diabetes Typ 2", "Hypertonie"]
}

# Bedingung
if alter >= 65:
    print(f"{patient_name} ist Senior")
elif alter >= 18:
    print(f"{patient_name} ist Erwachsen")
else:
    print(f"{patient_name} ist minderjährig")

# Schleife
for diagnose in patient["diagnosen"]:
    print(f"Diagnose: {diagnose}")

# Funktion
def bmi_berechnen(gewicht_kg, groesse_m):
    return gewicht_kg / (groesse_m ** 2)

bmi = bmi_berechnen(80, 1.78)
print(f"BMI: {bmi:.1f}")

# Datei lesen
with open("notizen.txt", "r", encoding="utf-8") as f:
    inhalt = f.read()
```

**Auffälligkeiten:**
- **Einrückung statt `{}`** — Code-Blöcke werden durch Einrückung markiert. Heilig.
- **`f"..."`** — String mit eingebetteten Variablen (f-Strings). Sehr nützlich.
- **`with open(...) as f:`** — sicheres Datei-Öffnen, schließt automatisch.
- **Keine Strichpunkte am Zeilenende.**

---

## 3. Datentypen, die du im Praxis-Code siehst

| Typ | Beispiel | Wofür typisch |
|---|---|---|
| `int` | `42`, `-7` | Zählungen, IDs |
| `float` | `1.78`, `36.5` | Messwerte, Preise |
| `str` | `"Hausarzt"`, `'Diagnose'` | Texte, Pfade |
| `bool` | `True`, `False` | Flags, Schalter |
| `list` | `[1, 2, 3]`, `["A", "B"]` | Sequenzen |
| `tuple` | `(2026, 4, 25)` | Unveränderliche Sequenzen, z. B. Datum |
| `dict` | `{"name": "Max"}` | Schlüssel-Wert-Paare, JSON-artig |
| `set` | `{"BKK", "AOK"}` | Eindeutige Sammlung |
| `None` | `None` | „Nichts/Leer" — wie `null` in anderen Sprachen |

---

## 4. Wie Python auf deinem Mac läuft

### Drei Python-Welten — wichtig zu unterscheiden

| Welt | Was es ist | Wo |
|---|---|---|
| **System-Python** | Vom macOS mitgeliefert (`python3` in `/usr/bin/`) | nicht anfassen, ist „PEP 668 externally-managed" |
| **Homebrew-Python** | Über `brew install python` installiert | Nutzbar, aber für Praxis-Tools meiden |
| **Virtual Environment (`venv`)** | Eigene, isolierte Python-Welt pro Projekt | **Standard für Cortex** — `Nexus/.venv/` |

### Warum Virtual Environments?

Stell dir vor, Tool A braucht `pdfplumber 0.10` und Tool B braucht `pdfplumber 0.11`. Wenn beide global installiert wären, kollidieren sie. Mit `venv` hat jedes Projekt seine eigene Bibliothek-Welt.

### Das venv von Nexus aktivieren

```bash
cd ~/Cortex/Nexus
source .venv/bin/activate     # Aktivieren — Prompt zeigt jetzt "(.venv)"
python --version              # 3.12.x
which python                  # zeigt auf .venv/bin/python
deactivate                    # Wieder raus
```

Mehr in [[Cortex & Nexus/02-multi-device-setup|Cortex & Nexus 02 — Multi-Device Setup]].

### `pip` — der Paket-Manager

```bash
pip install pdfplumber          # Paket installieren (im aktiven venv)
pip list                        # Was ist installiert?
pip freeze > requirements.txt   # Liste in Datei speichern
pip install -r requirements.txt # Aus Datei installieren
```

Cortex hat eine `Nexus/_lib/requirements.txt` mit allen Tool-Abhängigkeiten. Bei einem neuen Gerät führt `Nexus/bootstrap.sh` das automatisch aus.

---

## 5. Touren durch deine Praxis-Tools (`_lib/`)

In `Nexus/_lib/` liegen ~10 Bereiche mit Python-Skripten. Hier die wichtigsten:

| Ordner | Zweck | Hauptdatei |
|---|---|---|
| **`_lib/extract/`** | Universelle Textextraktion (PDF + OCR + Cache) | `universal_extract.py` (ca. 600 Zeilen) |
| **`_lib/medical/`** | Befund-Tools, Diagnosen-Extraktion | mehrere |
| **`_lib/ocr/`** | OCR-Spezialtools (Tesseract, Multi-PSM) | mehrere |
| **`_lib/pdf/`** | PDF-Manipulation: Merge, Split, Größen-Reduktion | mehrere |
| **`_lib/rename/`** | Datei-Umbenennung (Praxis-Dokumente, ~155 PRX-/115 PRV-Keywords) | `file_renamer.py` (1020+ Zeilen), `rename_utils.py` (1370+ Zeilen) |
| **`_lib/steuer/`** | CashFlow-Kategorisierung (apoBank → EÜR-Kategorien) | `cashflow_categorize.py` |
| **`_lib/utils/`** | Hilfsfunktionen (Übersetzung etc.) | mehrere |
| **`_lib/validate/`** | Report-Validierung gegen Templates | mehrere |

**Goldene Cortex-Regel:** *Tools wiederverwenden, nie neu schreiben.* Wenn du PDF-Text extrahieren willst — IMMER `_lib/extract/universal_extract.py`. Niemals neu schreiben.

---

## 6. Wie ein Python-Skript aufgebaut ist (Beispiel: `universal_extract.py`)

Schauen wir auf den Anfang einer typischen Praxis-Skript-Datei:

```python
#!/usr/bin/env python3                    # ← Shebang: macht das File ausführbar
# -*- coding: utf-8 -*-                   # ← Encoding (UTF-8 für Umlaute)
"""
universal_extract.py — Universelle Textextraktion
================================================
EIN Skript, das ...                       # ← Docstring: erklärt Zweck
"""

import hashlib                            # ← Standard-Lib (kommt mit Python)
import json
import os
from pathlib import Path                  # ← Aus Standard-Lib spezifisch importieren
import pdfplumber                         # ← Externe Lib (via pip installiert)


def extract_text(pdf_path: Path) -> str:  # ← Funktion mit Type-Hints
    """Liest Text aus einer PDF-Datei."""
    with pdfplumber.open(pdf_path) as pdf:
        return "\n".join(page.extract_text() for page in pdf.pages)


if __name__ == "__main__":                # ← Wird nur ausgeführt, wenn direkt gestartet
    import sys
    text = extract_text(Path(sys.argv[1]))
    print(text)
```

**Lesart:**
- Oben Imports (was wird gebraucht?)
- Mitte Funktionen (was kann das Skript?)
- Unten `if __name__ == "__main__":` — der Einstieg, wenn du das Skript aus dem Terminal aufrufst.

---

## 7. Typische Fehler, die du am Anfang siehst

| Fehler | Was er bedeutet | Lösung |
|---|---|---|
| `IndentationError: unexpected indent` | Einrückung stimmt nicht | Tabs vs. Spaces vereinheitlichen |
| `ModuleNotFoundError: No module named 'pdfplumber'` | Paket fehlt | `pip install pdfplumber` (im aktiven venv) |
| `UnicodeDecodeError` | Datei hat falsches Encoding | `encoding="utf-8"` beim Öffnen explizit setzen |
| `KeyError: 'name'` | Dictionary hat den Schlüssel nicht | mit `.get("name", "Default")` defensiv lesen |
| `TypeError: ... NoneType` | Variable ist `None` aber wird wie ein Wert benutzt | Vor Nutzung mit `if x is not None:` prüfen |
| `PermissionError: [Errno 13]` | Dateirechte nicht gegeben | `chmod +x skript.py` oder `sudo` (vorsichtig) |
| `FileNotFoundError` | Pfad existiert nicht | `os.path.exists(pfad)` vorher prüfen |

---

## 8. Wann Python für Dr. Stracke direkt nützlich ist

Drei Sterne nach Wahrscheinlichkeit, dass es bei dir vorkommt:

| Aufgabe | Tool | Wahrscheinlichkeit |
|---|---|---|
| Praxis-Dokumente umbenennen | `_lib/rename/file_renamer.py` | ⭐⭐⭐⭐⭐ |
| PDF-Text extrahieren | `_lib/extract/universal_extract.py` | ⭐⭐⭐⭐⭐ |
| CashFlow-Auszug auswerten | `_lib/steuer/cashflow_categorize.py` | ⭐⭐⭐⭐ |
| Befund-Daten extrahieren | `_lib/medical/...` | ⭐⭐⭐⭐ |
| SmartQ-Daten auswerten (Statistik) | eigenes Skript | ⭐⭐⭐ |
| Apple HealthKit-Daten verarbeiten (Juvantis) | iOS-App-Brücke | ⭐⭐⭐ |
| Kleines Mini-Skript für Spezial-Aufgabe | ad-hoc | ⭐⭐ |

---

## 9. Geplante Module (Roadmap dieser Domäne)

- **01** — Erste Schritte: Python aufrufen, einfache Skripte schreiben, Variablen, Bedingungen
- **02** — Listen, Dictionaries und Schleifen — Daten strukturieren
- **03** — Funktionen und Module — Code wiederverwendbar machen
- **04** — Dateien lesen/schreiben — CSV, JSON, Text
- **05** — `_lib/`-Tour: deine Praxis-Tools im Detail lesen lernen
- **06** — Eigenes Skript für eine Praxis-Aufgabe (z. B. „Patientenliste aus CSV → ESB-Format")
- **07** — Pandas — Tabellenverarbeitung für SmartQ-/CashFlow-Auswertungen
- **08** — Anthropic-SDK: Claude-API direkt aus Python ansprechen
- **09** — Web-Scraping mit `requests` + `BeautifulSoup`
- **10** — Tests schreiben mit `pytest`

---

## 10. Begriffe, die du in Python-Code siehst

| Begriff | Bedeutung |
|---|---|
| **Modul** | Eine `.py`-Datei mit Code |
| **Paket / Library** | Sammlung von Modulen (z. B. `pdfplumber`) |
| **`pip`** | Paket-Manager — installiert externe Bibliotheken |
| **`venv` / Virtual Environment** | Isolierte Python-Welt pro Projekt |
| **`requirements.txt`** | Liste der installierten Pakete (für Reproduzierbarkeit) |
| **`__init__.py`** | Markiert Ordner als Python-Paket |
| **f-String** | String mit Variablen-Einbettung: `f"Hallo {name}"` |
| **List-Comprehension** | Kompakte Liste-Erzeugung: `[x*2 for x in liste]` |
| **Lambda** | Anonyme Funktion: `lambda x: x + 1` |
| **Decorator** | Funktion, die andere Funktionen umhüllt: `@property` |
| **Generator** | Funktion mit `yield` — produziert Werte on-demand |
| **Type Hint** | `def f(x: int) -> str:` — keine Pflicht, aber lesbarer |
| **`__main__`** | Einstiegspunkt, wenn Skript direkt aufgerufen wird |
| **REPL** | Interaktive Python-Shell (`python3` ohne Argument) |

---

## 11. Lern-Reihenfolge

1. **Diese Seite** — Konzepte
2. [[Terminal Grundlagen]] — du brauchst die Basics, um Python-Skripte aufzurufen
3. **Modul 01** (sobald angelegt) — eigene erste Skripte
4. **Modul 05** (sobald angelegt) — `_lib/`-Tour, deine Praxis-Tools verstehen
5. **Modul 07** (sobald angelegt) — Pandas für Datenanalyse

Alternativ: Wenn dich ein konkreter Praxis-Tool interessiert, springst du direkt zur jeweiligen `.py`-Datei in `_lib/` und liest sie zusammen mit Claude — ich erkläre dir dann jede Zeile.

---

## 12. Wichtige Cortex-Regeln zu Python

- **Tools wiederverwenden, nie neu schreiben** — `_lib/` ist die einzige Quelle der Wahrheit
- **Verbesserungen gehen in `_lib/`-Tools, nicht in neue Skripte**
- **PDF-Extraktion: IMMER `universal_extract.py`** — siehe [[GLOBAL_RULES]] §3.1
- **Rename-Sessions enden mit Regel-Update** in `_lib/rename/`
- **`bootstrap.sh`** auf neuen Geräten ausführen — legt `.venv/` an + installiert `requirements.txt`

---

## Verwandte Notizen

- [[_MOC Tutorials]] — Dach-MOC aller Tutorials
- [[_Basiswissen Schnelleinstieg]] — Pfad „Sysadmin Praxis" verweist hierher
- [[Terminal Grundlagen]] — Voraussetzung
- [[Cortex & Nexus/02-multi-device-setup|Cortex & Nexus 02 — Multi-Device Setup]] — venv + bootstrap
- [[KI & Claude Grundlagen]] — Claude-API in Python (Modul 08, geplant)
- [[GLOBAL_RULES]] — Regeln zu `_lib/`, Tool-Wiederverwendung
