# 00 — Webdesign-Basics: Begriffe, Bausteine, Sprachen

> Einstiegs-Tutorial für die Kategorie **Webdesign** (vorher „WordPress & CSS").
> Umbenannt 2026-04-24 auf Anweisung von Dr. Stracke, um den Fokus über reines
> WordPress-CSS hinaus auf die **Grundlagen-Ebene** zu erweitern.
>
> Lernziel: Sie kennen die wichtigsten Begriffe, die in jeder Diskussion über
> eine Website fallen, und können grob sagen, **welche Sprache für welche
> Aufgabe** zuständig ist und **aus welchen Bausteinen** eine typische Seite
> besteht. Damit verstehen Sie die darauf aufbauenden Tutorials (01–24)
> deutlich schneller.

---

## 1. Webdesign vs. Webentwicklung — was ist was?

Der Begriff „Website bauen" ist in Wirklichkeit eine Kombination aus zwei
Disziplinen, die in großen Teams getrennt sind, aber bei Ein-Personen-
oder Kleinstprojekten (wie westend-hausarzt.com) dieselbe Person macht.

| Disziplin | Frage | Typische Tätigkeit | Werkzeug |
|---|---|---|---|
| **Webdesign** | *Wie sieht es aus und wie fühlt es sich an?* | Layout skizzieren, Farben wählen, Typografie, Abstände, UX-Flows | Figma, Skizzen, Design-Tokens, Stil-Guide |
| **Webentwicklung** | *Wie bringe ich das zum Laufen?* | Code schreiben, Templates bauen, Daten anbinden, Performance | HTML, CSS, JS, WordPress-PHP, Build-Tools |

Viele Tutorials in diesem Ordner (01, 03, 05, 09 …) liegen **zwischen**
beiden Welten — sie übersetzen Design-Entscheidungen in konkreten Code.
Das ist typisch für moderne Webarbeit: die Grenze ist fließend, und
Ästhetik trifft auf Technik bereits auf der Ebene einer einzigen CSS-Regel.

---

## 2. Die drei Säulen einer Webseite

Jede Webseite im Internet — egal ob Google, Instagram oder unsere Praxis-
Seite — besteht im Browser aus genau drei Arten von Code, die zusammen
„die Seite" ergeben:

### HTML — die Struktur („das Skelett")

**HTML** (Hypertext Markup Language) ist eine **Auszeichnungssprache**, keine
Programmiersprache. Sie markiert Text-Bereiche mit sogenannten **Tags**, damit
der Browser weiß: „Das ist eine Überschrift, das ein Absatz, das ein Bild."

```html
<h1>Praxiszentrum Dr. Stracke</h1>
<p>Wir sind eine internistische Hausarztpraxis in Frankfurt.</p>
<img src="praxis-aussen.jpg" alt="Praxis-Gebäude">
```

- `<h1>` … `<h6>` = Überschriften (h1 die größte, h6 die kleinste)
- `<p>` = Paragraph (Absatz)
- `<a href="…">` = Link (Anker)
- `<img src="…">` = Bild
- `<div>` = „Container" ohne eigene Bedeutung, zum Gruppieren
- `<section>`, `<header>`, `<footer>`, `<nav>` = semantische Container

### CSS — das Aussehen („die Kleidung")

**CSS** (Cascading Style Sheets) sagt dem Browser, **wie** das HTML aussehen
soll: Farben, Schriften, Abstände, Layouts, Animationen.

```css
h1 {
  color: #028090;        /* Teal, Praxis-Primärfarbe */
  font-size: 2.5rem;     /* 40px, wenn Basis 16px */
  margin-bottom: 1rem;   /* Luft nach unten */
}
```

CSS-Regeln werden **per Selektor** (z. B. `h1`, `.cta-section`, `#hero`)
an HTML-Elemente gebunden. Das „Cascading" im Namen bedeutet, dass mehrere
Regeln übereinander fließen können — wenn zwei Regeln widersprechen, gewinnt
die **spezifischere**. Details dazu in Tutorial [[09-css-spezifitaet-und-komponenten-schichten]].

### JavaScript (JS) — das Verhalten („die Muskulatur")

**JavaScript** ist eine echte Programmiersprache. Sie läuft im Browser und
lässt die Seite **auf den Nutzer reagieren**: Menü aufklappen, Formular
validieren, Slider bewegen, Anfragen ans Backend schicken.

```javascript
document.querySelector('.menu-toggle').addEventListener('click', () => {
  document.querySelector('.mobile-drawer').classList.toggle('open');
});
```

Bei der Praxis-Seite ist der JS-Anteil bewusst klein — die meisten
Interaktionen löst CSS (z. B. Hover-Effekte) oder der Server (WordPress)
aus. Siehe Tutorial [[WordPress/16-navigation-restrukturierung-und-mobile-drawer|WordPress 16]].

### Gedankenstütze

> **HTML = Was steht da. CSS = Wie sieht es aus. JS = Was passiert, wenn ich klicke.**

---

## 3. Die Bausteine einer typischen Seite

Wenn Sie eine moderne Website von oben nach unten scrollen, treffen Sie
immer wieder auf dieselben Bausteine. Jeder hat einen Namen, den Designer
und Entwickler im Gespräch verwenden:

| Baustein | Beschreibung | Beispiel auf westend-hausarzt.com |
|---|---|---|
| **Header** | Oberer Streifen mit Logo, Menü, Telefonnummer. Bleibt oft beim Scrollen sichtbar („sticky"). | Logo + Hauptmenü + „Jetzt anrufen"-Button |
| **Hero** | Die erste große Sektion unter dem Header. Enthält die wichtigste Botschaft und meistens einen Call-to-Action. | „Ihr Hausarzt in Frankfurt-Westend" + Termin-Button |
| **Sektion** | Logischer Abschnitt der Seite, durch Abstände und ggf. Hintergrundfarbe getrennt. | „Unsere Schwerpunkte", „Das Team", „Kontakt" |
| **Grid** | Rasterförmige Anordnung mehrerer Elemente, z. B. 3 Karten nebeneinander auf Desktop, untereinander auf Handy. | Leistungs-Übersicht mit Icon-Kacheln |
| **Card** | Einzelner Kasten innerhalb eines Grids, typischerweise mit Bild + Titel + Kurztext + Link. | Arzt-Porträts, Leistungs-Kacheln |
| **CTA** (*Call to Action*) | Aufforderung an den Nutzer, etwas zu tun (Termin buchen, anrufen, Formular ausfüllen). | Recruiting-Sektion für MFA, „Jetzt Termin" |
| **Footer** | Unterer Streifen mit Kontaktdaten, Impressum, Datenschutz, Social-Media-Links. | Kontaktblock + Links zu Impressum/DSGVO |

**Praxis-Tipp:** Wenn Sie in einem Gespräch mit mir (Claude) oder einem
Entwickler unsicher sind, welcher Baustein gemeint ist, machen Sie einen
Screenshot und schreiben Sie den Namen daneben. Das ist die effizienteste
Kommunikation, und 99 % aller Designer/Entwickler weltweit benutzen
genau dieses Vokabular.

---

## 4. CSS-Grundlagen — die vier Konzepte, die man zuerst lernen sollte

### 4.1 Das Box-Modell

Jedes HTML-Element ist im Browser ein **rechteckiger Kasten**. Dieser
Kasten besteht aus 4 Schichten (von innen nach außen):

```
┌──────────────────── margin (Außenabstand) ────────────────────┐
│  ┌────────────── border (Rahmen) ──────────────┐              │
│  │  ┌────────── padding (Innenabstand) ─────┐  │              │
│  │  │                                        │  │              │
│  │  │          Inhalt (Text / Bild)          │  │              │
│  │  │                                        │  │              │
│  │  └────────────────────────────────────────┘  │              │
│  └──────────────────────────────────────────────┘              │
└─────────────────────────────────────────────────────────────────┘
```

- **Inhalt** = der Text oder das Bild selbst
- **Padding** = Luft zwischen Inhalt und Rahmen (z. B. damit Text nicht an der Kante klebt)
- **Border** = Rahmenlinie (optional)
- **Margin** = Luft zwischen diesem und dem nächsten Kasten

Das Box-Modell ist die häufigste Quelle von Layout-Frustration („Warum
stehen die so weit auseinander?"). Antwort: immer zuerst `margin` vs.
`padding` prüfen.

### 4.2 Flex und Grid — die beiden Layout-Systeme

Früher war das Anordnen von Elementen in CSS eine Qual. Heute gibt es zwei
mächtige, moderne Systeme:

- **Flexbox** (`display: flex`) = eindimensionale Anordnung (Zeile ODER Spalte). Perfekt für Navigationsleisten, Button-Gruppen, Cards nebeneinander.
- **Grid** (`display: grid`) = zweidimensional (Zeilen UND Spalten). Perfekt für Seiten-Layouts mit Header/Sidebar/Content/Footer oder komplexe Kartenraster.

Grobe Faustregel: **Flex für eine Achse, Grid für zwei Achsen.**

### 4.3 Responsive Design und Breakpoints

Die Seite muss auf **Handy, Tablet und Desktop** funktionieren. Der Trick:
CSS kann je nach Bildschirmbreite andere Regeln anwenden. Die Übergänge
heißen **Breakpoints**.

```css
/* Mobile (Standard): eine Spalte */
.cards { display: grid; grid-template-columns: 1fr; }

/* Ab 768px (Tablet): zwei Spalten */
@media (min-width: 768px) {
  .cards { grid-template-columns: 1fr 1fr; }
}

/* Ab 1024px (Desktop): drei Spalten */
@media (min-width: 1024px) {
  .cards { grid-template-columns: 1fr 1fr 1fr; }
}
```

Diese Logik nennt sich **Mobile-First**: man schreibt zuerst die Mobile-
Version, dann die Erweiterungen für größere Bildschirme.

### 4.4 Spacing-Skala und Design-Tokens

Gute Webseiten haben **konsistente Abstände**. Dafür legt man am Anfang eine
Skala fest (z. B. 4, 8, 16, 24, 32, 48, 64 Pixel) und benutzt **nur** diese
Werte — nie „mal eben 13px". Das macht die Seite harmonisch.

Wenn zusätzlich alle Farben, Schriftgrößen, Rundungen usw. zentral als
**Design-Tokens** (CSS-Variablen) definiert sind, kann man das gesamte
Aussehen an einer einzigen Stelle ändern. Details in den Tutorials
[[05-design-tokens-und-cascade]] und [[06-vier-schichten-design-tokens]].

---

## 5. Das WordPress-Umfeld — was man als Designer wissen muss

westend-hausarzt.com läuft auf **WordPress**. Das heißt: die Seite wird nicht
als statisches HTML ausgeliefert, sondern **vom Server auf Anfrage
zusammengebaut**. Für Webdesign-Entscheidungen sind vier Begriffe wichtig:

| Begriff | Was es ist | Für Webdesign relevant, weil … |
|---|---|---|
| **Theme** | Ein Ordner mit HTML-Vorlagen, CSS und Funktionen. Unser Theme heißt `praxiszentrum`. | Alle Design-Entscheidungen landen dort, nicht im WordPress-Kern. |
| **Template** | Eine HTML-Vorlage für einen bestimmten Seitentyp (Startseite, Einzelseite, Archiv …). Dateien wie `page.php`, `front-page.php`. | Wenn Sie „mehr Platz auf der Startseite" wollen, bearbeite ich `front-page.php`. |
| **Block** | WordPress' moderner Baustein im Editor (Gutenberg). Ein Absatz, ein Bild, eine Spalten-Gruppe sind je ein Block. | Sie können Inhalte selbst pflegen, ohne Code anzufassen. |
| **Enqueue** | Der formale Weg, CSS- und JS-Dateien in eine WordPress-Seite zu laden (in `functions.php`). | Erklärt, warum unsere CSS-Datei auf *jeder* Seite geladen wird und Änderungen sofort überall wirken. |

**Warum das wichtig ist:** Als Betreiber der Praxis-Seite haben Sie zwei
Ebenen, an denen Sie eingreifen können:

1. **Inhalt im WordPress-Editor** — Text, Bilder, Reihenfolge ändern. Geht sofort, ohne Entwickler.
2. **Design/Struktur im Theme-Code** — Farben, Layout, neue Bausteine. Geht nur via Code-Änderung (Claude oder Entwickler).

Diese Trennung ist bewusst und gut so: sie verhindert, dass ein unglücklicher Klick im Editor das ganze Design zerschießt.

---

## 6. Weiterführende Lektionen in diesem Ordner

Nach diesem Einstiegs-Tutorial haben Sie das Vokabular. Die folgenden Tutorials gehen dann in konkrete Situationen des Praxis-Redesign-Projekts:

> **Hinweis Sprint F2 Reorg (2026-05-05):** Webdesign wurde aufgeteilt — generische
> Module bleiben hier (12 Stück, neu nummeriert 01-12), WordPress-spezifische
> Praxis-Lessons sind nach [[WordPress Grundlagen|WordPress]] gewandert (22 Module).

### Layout und Sektionen (gemischt Webdesign + WordPress)
- [[02-cta-konversion-und-sektions-hoehe]] — Warum eine Recruiting-Sektion kurz sein muss, damit sie konvertiert
- [[WordPress/16-navigation-restrukturierung-und-mobile-drawer|WordPress 16]] — Menü-Architektur und mobile Drawer-Komponente
- [[WordPress/17-detail-pages-mit-cross-navigation|WordPress 17]] — Aufbau von Detailseiten mit Seiten-übergreifender Navigation
- [[WordPress/18-wp-nested-pages-und-old-slug-redirects|WordPress 18]] — Seitenhierarchien in WordPress und sauberes Umleiten alter URLs
- [[WordPress/19-template-parts-mit-is-page-guard|WordPress 19]] — Wiederverwendbare Template-Teile nur auf bestimmten Seiten ausspielen

### CSS und Tokens (Webdesign generisch)
- [[03-inline-css-zu-externer-datei]] — Warum CSS niemals inline gehört und wie man es auslagert
- [[05-design-tokens-und-cascade]] — Einsteiger-Version: zentrale Farbquelle
- [[06-vier-schichten-design-tokens]] — Aufbau-Version: Brand → Semantik → Komponente → Override
- [[09-css-spezifitaet-und-komponenten-schichten]] — Welche CSS-Regel gewinnt und warum

### WordPress-Spezifika
- [[WordPress/04-wp-rest-api-adapter-mit-application-passwords|WordPress 04]] — Inhalte programmatisch aus WordPress holen
- [[WordPress/08-wp-page-templates-und-auto-discovery|WordPress 08]] — Eigene Seitentypen im Theme definieren
- [[WordPress/09-verify-probe-architektur-und-wp-rewrite-grenze|WordPress 09]] — Wie man testet, ob die Seite noch korrekt ist
- [[WordPress/10-wp-plugin-sicher-entfernen|WordPress 10]] — Plugins entfernen, ohne die Seite zu brechen
- [[WordPress/20-blocksy-footer-override|WordPress 20]] — Theme-Footer durch eigenen ersetzen

### Planungs- und Prozess-Tutorials (WordPress-Praxis)
- [[WordPress/07-seiten-inventar-website-relaunch|WordPress 07]] — Vor dem Redesign: alle Seiten systematisch erfassen
- [[WordPress/12-utf8-mojibake-und-trunk-ready-inventar|WordPress 12]] — Zeichensatz-Probleme erkennen und beheben
- [[WordPress/13-content-archive-md5-contract|WordPress 13]] — Wie Inhalte zwischen Alt- und Neu-Seite migriert werden

---

## 7. Mein persönlicher Lernpfad-Vorschlag

Wenn Sie dieses Ordner-Tutorial als Lernweg nutzen wollen, schlage ich diese
Reihenfolge vor:

1. **Dieses Tutorial (01)** — Begriffe verstehen ✅
2. **[[WordPress/03-git-bootstrap-und-page-registry|WordPress 03]]** — Warum Versionskontrolle beim Webdesign wichtig ist
3. **[[03-inline-css-zu-externer-datei]]** — Erste konkrete CSS-Arbeit
4. **[[05-design-tokens-und-cascade]]** — Farben zentralisieren
5. **[[02-cta-konversion-und-sektions-hoehe]]** — Conversion-orientiertes Design
6. **[[09-css-spezifitaet-und-komponenten-schichten]]** — Tieferes CSS-Verständnis
7. Weitere nach Bedarf — die anderen Tutorials sind „bei konkreter Frage nachschlagen".

---

## Verwandte Notizen

- [[_MOC Tutorials]] — Übersicht aller Tutorial-Kategorien
- [[DASHBOARD]] — Projekt-Status + offene Fragen/Anweisungen
- [[07-vault-kommunikation]] — Wie Sie in Obsidian Fragen und Anweisungen platzieren
- [[Vault-Cheatsheet]] — Kurz-Referenz dazu

*Angelegt: 2026-04-24 (Kategorie-Umbenennung WordPress & CSS → Webdesign)*
