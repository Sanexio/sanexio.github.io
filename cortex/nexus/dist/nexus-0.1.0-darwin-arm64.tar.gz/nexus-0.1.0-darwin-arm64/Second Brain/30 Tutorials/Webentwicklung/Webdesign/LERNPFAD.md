---
type: lernpfad
category: webdesign
aliases: [Lernpfad Webdesign, Webdesign-Lernpfad]
tags: [lernpfad, webdesign, index]
---

# Lernpfad — Webdesign (generisch)

> Generische Webdesign-Konzepte, projekt-unabhängig anwendbar.
> WordPress-spezifische Module (Bridge-Pages, Verify-Probe, Theme-Render,
> Blocksy-Override etc.) liegen jetzt in [[WordPress Grundlagen|WordPress]].
>
> Reorganisation 2026-05-05 (Sprint F2): 33 Module aufgeteilt in
> 12 Webdesign-generisch + 21 WordPress-Praxis. Alte Numerierungs-Konflikte
> (09, 10, 24) damit aufgelöst.

---

## Block 1 — Einstieg

| # | Tutorial | Lernziel |
|---:|---|---|
| 01 | [[01-webdesign-basics]] | Webdesign vs. Webentwicklung; HTML/CSS/JS; Bausteine; Box-Modell |

*Pflichtstart für alle Folgekapitel.*

---

## Block 2 — CSS-Grundlagen

| # | Tutorial | Lernziel |
|---:|---|---|
| 03 | [[03-inline-css-zu-externer-datei]] | Inline-CSS-Schmerzen, saubere Extraktion in `.css`-Dateien |
| 09 | [[09-css-spezifitaet-und-komponenten-schichten]] | Welche Regel gewinnt (Specificity-Score), `:where()`, Komponenten-Schichten |

---

## Block 3 — Design-Tokens & Cascade

| # | Tutorial | Lernziel |
|---:|---|---|
| 05 | [[05-design-tokens-und-cascade]] | Design-Tokens als zentrale Farbquelle (zwei-Schichten-Modell) |
| 06 | [[06-vier-schichten-design-tokens]] | Vertiefung: Brand → Semantik → Komponente → Override |

---

## Block 4 — Typografie

| # | Tutorial | Lernziel |
|---:|---|---|
| 08 | [[08-type-scale-referenz-basiert]] | Type-Scale als referenzbasiertes System |
| 12 | [[12-fluid-type-scale-mid-range-coverage]] | Fluid-Type-Scale, Mid-Range-Coverage, Container-Queries |

---

## Block 5 — Sektionen & CTA

| # | Tutorial | Lernziel |
|---:|---|---|
| 02 | [[02-cta-konversion-und-sektions-hoehe]] | CTA-Sektionen kompakt halten, Conversion-Theorie |

---

## Block 6 — Recht & Compliance

| # | Tutorial | Lernziel |
|---:|---|---|
| 04 | [[04-credentials-und-env-dateien]] | Secrets sicher verwalten (`.env`, App-Passwords vs. Admin) |
| 07 | [[07-dsgvo-fonts-self-hosted]] | DSGVO-konformes Self-Hosting von Webfonts |

---

## Block 7 — Diagnose & Tools

| # | Tutorial | Lernziel |
|---:|---|---|
| 10 | [[10-doppelte-render-quellen-aufspueren]] | Stille Doppel-Render diagnostizieren (HEAD-Probes, View-Source-Diff) |
| 11 | [[11-headless-browser-pdf-generierung]] | Puppeteer für PDF-Export aus Webseiten |

---

## Block 8 — Deploy & Pipeline

| # | Tutorial | Lernziel |
|---:|---|---|
| 13 | [[13-local-master-staging-prod-pipeline]] | Drei-Stage-Pipeline (Local=Master, Staging-Verify, Prod), Polish-Loop, lftp-Sync mit Welle-J-Exclusions |
| 14 | [[14-rollback-via-git-tag]] | Rollback live-deployter Sites über Git-Tag-Anker (Snapshot vor Deploy + `git checkout <tag>`) |

---

## Verwandte Notizen

- [[Webdesign Grundlagen]] — Domänen-Landing
- [[WordPress Grundlagen]] — Praxis-Lessons aus dem Praxis-Webseiten-Sprint
- [[_MOC Tutorials]] — Tutorial-Index
- [[01-architekten-modus]] — Vorgehensweise

*Reorganisation 2026-05-05 (Sprint F2): 33 → 12 Module, neu nummeriert 01-12.*
