# 27 — Fluid Type-Scale + Mid-Range-Viewport-Coverage

> **Lernziel:** Verstehen, warum eine Webseite auf einem „großen Bildschirm"
> trotzdem kaputt aussehen kann, und wie man das mit `clamp()`-Tokens und
> Mehr-Viewport-Probes verhindert.
>
> **Eingeführt:** Session 47 (2026-04-27) im Praxis-Theme PXZ 2.7.71.

---

## 1. Das Aha-Erlebnis

Dr. Stracke saß am Mac Studio mit einem Studio-Display und sah die Praxis-
Seite mit einem Header, der über den Bildschirm hinausragte. Texte wirkten
„wuchtig". Wir hatten doch in S38, S40, S41, S46 alles geprüft — und unser
Pre-Flight-Probe (verify.sh) lief grün.

Was war passiert?

**Studio Display ≠ breites Browserfenster.** Der Browser meldete
`innerWidth: 1365 px`. Auf so einem Viewport hatten wir nie geprobt — die
Standard-Probe-Breiten waren **1440 px** (Desktop) und **430 px** (Mobile).
1365 ist genau die Lücke zwischen beiden, und sie ist die häufigste reale
Browserbreite weltweit.

## 2. Was Browser-Breite und Display-Größe nicht miteinander zu tun haben

| Was | Bedeutet |
|---|---|
| **Display-Größe** (z. B. 27"-Studio-Display) | physische Diagonale |
| **Display-Auflösung** (5120 × 2880 nativ) | Anzahl der physischen Pixel |
| **macOS-Skalierung** | wie viele „CSS-Pixel" daraus werden — z. B. 2560 × 1440, 1920 × 1080, 1280 × 720 |
| **Browser-Fensterbreite** | Wieviel davon der Browser nutzt |

Ein 27"-Display kann in der Skalierung „Larger Text" effektiv nur **1280 px
breit** sein. Ein 24"-FullHD-Display ohne Skalierung ist 1920 px breit.

Das heißt: **Display-Größe sagt nichts über Browser-Breite.**

## 3. Drei Arten, font-size zu definieren

| Definition | Verhalten | Beispiel |
|---|---|---|
| **Fix** (`font-size: 34px`) | Nie ändern | bleibt auf jedem Gerät 34 px |
| **Bedingt** (`@media (max-width: 767px)`) | Springt bei einer Schwelle | bis 767 px → 17 px, ab 768 px → 26 px |
| **Fluid** (`clamp(min, vw, max)`) | Fließend mit Browser-Breite | min 17 / max 26 / dazwischen mitwachsend |

Bedingt erscheint logisch, ist aber gefährlich: zwischen den Schwellen
gibt es Sprünge, und außerhalb der getesteten Schwellen sieht es kaputt
aus.

## 4. clamp() im Detail

```css
font-size: clamp(17px, 1.7vw, 26px);
```

Drei Argumente:

- **MIN = 17px** — Untergrenze (z. B. Apple-HIG-Body-Minimum)
- **PREFERRED = 1.7vw** — wenn der Browser breiter wird, wächst die Schrift
  proportional zur Viewport-Breite. `1vw = 1 % der Browser-Breite`.
- **MAX = 26px** — Obergrenze (z. B. Designer-Soll auf 1920er Display)

Ergebnis bei verschiedenen Browser-Breiten:

| Browser-Breite | 1.7vw | clamp gibt |
|---:|---:|---:|
| 768 px | 13 px | **17 px** (MIN gewinnt) |
| 1024 px | 17.4 px | 17 px |
| 1280 px | 21.8 px | 22 px |
| 1365 px | 23.2 px | 23 px |
| 1440 px | 24.5 px | 24 px |
| 1530 px | 26.0 px | **26 px** (MAX greift) |
| 1920 px | 32.6 px | 26 px |

Die Schrift wächst zwischen 1024 und 1530 mit, davor und danach nicht.

## 5. Die Faustregel für den vw-Faktor

`(MAX - MIN) / (BREAKPOINT - MIN_BREAKPOINT)` ergibt eine erste Schätzung
für die Steigung.

Beispiel: T1 Hero, MAX=80, MIN=40, soll bei 1600 px MAX erreichen.
Steigung = (80-40) / (1600-768) = 4.8 % der Viewport-Breite. → `5vw` als
runder Wert.

## 6. Welche Viewports geprobt werden

Mindestens **fünf** Browserbreiten — nicht zwei.

| Viewport | Steht für |
|---:|---|
| 390 / 430 | iPhone-Klasse |
| 768 | iPad-Portrait |
| **1024** | iPad-Landscape, kleines Notebook |
| **1280** | klassisches 13"-Notebook |
| **1365** | weltweit häufigste Laptop-Breite |
| 1440 | Studio-Display in Default-Skalierung |
| 1920 | Full-HD-Monitor |

Die fett markierten 1024 / 1280 / 1365 sind die „Forgotten Mid-Range".
Wenn auf den Probes nur 1440 + 430 stehen, fallen genau die Bugs durchs
Raster, die Dr. Stracke am häufigsten in der Wildnis sieht.

## 7. Wann clamp() **nicht** das richtige Werkzeug ist

- **Buttons / Tappable-Elemente**: hier sind Sprünge an einer Tappable-Min-
  Schwelle (44 px Apple-HIG) gewollt — eine Nachsicht auf 38 px wäre
  WCAG-Verstoß.
- **Logos / Brand-Marken**: Diese folgen oft eigenen Größenstufen, nicht
  einer kontinuierlichen Skala.
- **Container-Max-Width für Lesetext**: Hier ist eine harte Obergrenze
  (~960 px) sinnvoller als fluid — sonst werden Zeilen auf großen Displays
  90+ Zeichen lang und ermüdend.

## 8. Workflow im Praxis-Theme (Erinnerung für Claude / Dr. Stracke)

1. **Token-Datei** (`tokens.css`): T1–T8 mit `clamp()` definiert
2. **Komponenten-CSS**: nutzt `var(--pxz-tN-size)` statt fixer Werte
3. **Pre-Flight-Probe** (`tools/probe-mid-range.mjs`): testet 5 Viewports
4. **Acceptance-Kriterien**: „kein horizontaler Overflow bei 1024 / 1280
   / 1365 / 1440 / 1920" — explizit referenzieren

## 9. Glossar — Fachbegriffe

| Begriff | Bedeutung |
|---|---|
| **Viewport** | Sichtbarer Bereich des Browser-Fensters in CSS-Pixeln |
| **CSS-Pixel** | Einheit, mit der CSS rechnet (≠ physischer Bildschirmpixel auf Retina) |
| **Retina** | Apple-Display mit Geräte-Pixel-Verhältnis 2 (oder höher) — ein CSS-Pixel = 2² physische Pixel |
| **dpr / devicePixelRatio** | Geräte-Pixel-Verhältnis. dpr=2 = Retina |
| **Skalierung** (macOS) | Einstellung, die die Auflösung des Displays in CSS-Pixel umrechnet — „More Space" gibt mehr CSS-Pixel, „Larger Text" gibt weniger |
| **Breakpoint** | CSS-Schwellwert (`@media (min-width: 1100px)`), an dem sich Styles ändern |
| **clamp()** | CSS-Funktion mit drei Argumenten min / preferred / max — gibt einen Wert zwischen min und max, wachsend mit dem preferred-Argument |
| **vw** | Viewport-Width-Einheit. 1vw = 1 % der Browser-Innenbreite |
| **Mid-Range** | Viewport-Bereich zwischen Mobile (≤768) und Desktop (≥1440), typisch 1024–1439 |
| **Stufen-Shift** | Diskreter Sprung von Werten an einer Media-Query-Schwelle |
| **Apple-HIG** | Apple Human Interface Guidelines — Apple's UX-Regelwerk inkl. Type-Scale |

## 10. Verwandte Notizen

- **fluid-type-scale-clamp** und **mid-range-viewport-coverage** — Patterns,
  die ehemals als Markdown unter `Nexus/_memory/patterns/` lagen. Seit
  Phoenix-Reset (2026-05-09) leben Patterns in der SQLite-Memory-DB
  (`_memory/memory.db`, Tabelle `patterns`). Abruf via
  `cortex-agent memory search "fluid type scale"`.
- [[08-type-scale-referenz-basiert]] — S40 Apple-Type-Scale-Grundlage
- [[10-doppelte-render-quellen-aufspueren]] — verwandte Quelle für
  „warum sehen ich's Bug nicht" (CSS-Drift)
- [[WordPress/21-theme-render-source-vor-db-schreiben|WordPress 21]] — S42 Theme-Render-Source-Check
