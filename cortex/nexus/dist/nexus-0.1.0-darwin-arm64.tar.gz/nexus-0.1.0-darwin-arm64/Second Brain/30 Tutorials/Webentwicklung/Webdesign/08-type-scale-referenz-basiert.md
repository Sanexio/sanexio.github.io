---
tags: [webdesign, typografie, css, design-tokens, workflow]
erstellt: 2026-04-25
quelle: Cortex-Web Session 40 (S40 Apple Type-Scale)
---

# Type-Scale aus einer Referenzseite übernehmen

> Wenn Sie eine Webseite sehen, deren Schrift-Größen-Verhältnisse Ihnen
> gefallen, können Sie genau diese Skala in Ihr eigenes Theme übertragen —
> ohne zu raten, ohne Pixel-Schubserei.

## Warum Type-Scale und nicht „einfach Schriftgröße ändern"?

Ein Theme hat typischerweise 20–30 verschiedene Schriftgrößen (Hero,
Headlines, Sub-Titel, Body, Small, Caption, Button, Eyebrow …). Wenn Sie
einzeln an Schriftgrößen schrauben, kippt früher oder später die
**Hierarchie** — ein Sub-Titel wird größer als seine Headline, ein Link
sieht wichtiger aus als ein Absatz.

Die Lösung ist eine **Skala**: statt 30 einzelne px-Werte → 8 definierte
Stufen (T1 = am größten, T8 = am kleinsten), und jedes Element der Seite
zeigt auf eine dieser Stufen.

## Voraussetzungen

- Lokales Dev-Setup (Local Sites / Laravel Valet / DDEV), Theme-CSS
  editierbar.
- `bun` oder `node` für Puppeteer-Scripts (macOS: `brew install bun`).
- Eine Referenzseite, deren Schrift-Verhältnisse Sie gut finden (z. B.
  `apple.com`, eine andere Praxisseite, Stripe, Apple Health …).

## Schritt 1 — Referenz-Seite öffnen und Sektion wählen

Entscheiden Sie, **welche Sektion** der Referenz die Vorlage sein soll:

- Nur **Content-Sektion** (was zwischen Header und Footer steht)?
- Auch Buttons? Auch Eyebrows?
- Headlines davon ausnehmen, weil Sie eigene Charakter behalten wollen?

Der Scope-Klärung entscheidet, was später gemessen wird. Bei mir:
*„Buttons, Schrift und Größen der Content-Sektion, Header + Footer
separat."*

## Schritt 2 — Puppeteer-Probe

Ein Messskript besucht die Referenz-Seite in 3 Viewports (Desktop
1920/1440, Mobile 430) und extrahiert:

- Alle sichtbaren Text-Elemente außerhalb von `<nav>` / `<footer>` /
  `[role="banner"]` / `[role="contentinfo"]`
- Pro Element: `fontSize`, `lineHeight`, `letterSpacing`, `fontWeight`
- Zusätzlich: CTA-Button-Kandidaten (Elemente mit Hintergrund und
  Padding) mit `borderRadius`, `height`, `paddingTop/Right/Bottom/Left`

Wichtig:

- **Cookie-Banner wegklicken** (sonst verdeckt er die Probe-Targets).
  Typische Selektoren: `#onetrust-accept-btn-handler`,
  `button[aria-label*="Akzeptieren"]`.
- **User-Agent setzen** (Apple liefert sonst eine abweichende
  Cookie-Banner-Version).
- Clip-Screenshot von 3000 px Höhe, sodass mehrere Hero-Tiles drin sind.

Das Script clustert die gefundenen Schriftgrößen und zeigt die Top-10
Stufen mit Häufigkeit + Median-`line-height` + Median-`letter-spacing`.

So erkennen Sie: Die Referenz hat tatsächlich z. B. **6 dominante Stufen**
(56 / 40 / 28 / 21 / 17 / 14 px).

## Schritt 3 — Stufen interpretieren, T1–T8 ableiten

Apple hatte in der Messung kein Mega-Hero (nur 56 px als Maximum,
Saison-abhängig). Auf Produkt-Detailseiten gibt es typisch 80–96 px.
Ich ergänze T1 als „Mega-Hero 80 px" und T8 als „Caption 14 px" über /
unter den empirischen Messwerten, sodass ich 8 runde Stufen habe.

| Stufe | Desktop | Mobile | Rolle |
|:--:|---:|---:|---|
| T1 | 80 | 40 | Mega-Hero (Product-Page) |
| T2 | 56 | 32 | Large-Headline |
| T3 | 40 | 28 | Section-Title |
| T4 | 28 | 22 | Sub-Headline / Card-Title |
| T5 | 21 | 19 | Lead / Intro |
| T6 | 17 | 17 | Body + Button-Label |
| T7 | 15 | 15 | Small / Eyebrow |
| T8 | 14 | 14 | Caption |

**Mobile-Stufen-Shift**: Apple shifted T1–T4 auf Mobile um eine Stufe nach
unten, T5–T8 bleiben identisch (Body liest sich auf iPhone sonst zu
klein).

## Schritt 4 — Tokens in `tokens.css`

Zwei Ebenen:

**Schicht 1 — Primitives** (stackspezifische px-Werte):

```css
:root {
  --font-t1-size:   80px;
  --font-t2-size:   56px;
  /* … T3–T8 … */
  --font-t1-line:   1.05;
  --font-t1-track: -0.022em;
  --font-t1-weight: 600;
}
@media (max-width: 767px) {
  :root {
    --font-t1-size: 40px;
    --font-t2-size: 32px;
    /* … T3–T5 Mobile-Shift, T6–T8 bleiben … */
  }
}
```

**Schicht 2 — Semantic** (was Components lesen):

```css
--pxz-t1-size:  var(--font-t1-size);
--pxz-t1-line:  var(--font-t1-line);
--pxz-t1-track: var(--font-t1-track);
--pxz-t1-weight: var(--font-t1-weight);
/* … T2–T8 analog … */
```

**Button-Tokens entkoppeln**: sonst reißt jede spätere Body-Skalierung
auch die Buttons mit (und deren Höhe explodiert). Eigene Primitives:

```css
--btn-font-size-desktop: 17px;
--btn-font-size-mobile:  14px;
--btn-padding-y-desktop: 11px;
--btn-padding-x-desktop: 21px;
--btn-height-desktop:    44px;  /* Apple-HIG-Touch-Target */
```

## Schritt 5 — Selektor-Mapping

Jede `font-size` in den Content-CSS-Dateien auf das nächstpassende Token
verweisen lassen. Beispiel:

Vorher:
```css
.pxz-spec-title { font-size: 1.125rem; }   /* 18px, „ungefähr" */
.pxz-spec-sub   { font-size: 0.9375rem; }  /* 15px, „ungefähr" */
```

Nachher:
```css
.pxz-spec-title { font-size: var(--pxz-t5-size); }  /* 21px = Lead */
.pxz-spec-sub   { font-size: var(--pxz-t6-size); }  /* 17px = Body */
```

**Keine freien px-Werte mehr** in Content-CSS. Ausnahme: UI-Dekorative
Elemente (Avatar-Initials in `aspect-ratio`-Containern) und Nav/Footer,
wenn die separat gestaltet werden sollen.

## Schritt 6 — Phase-4-Probe + Abnahme

Screenshots aller Kern-Pages in 3 Viewports machen, Side-by-Side mit den
Apple-Referenz-Shots vergleichen. Checken:

- Body-Font = T6 auf allen Pages?
- Buttons Pill (`border-radius >= 100`)?
- Hero >= T3?
- Keine Text-Überläufe auf Mobile?
- `verify.sh` / Alignment-Probe grün?

## Fallstricke

1. **`document.body` misst das falsche Element.** Blocksy-Parent-Theme
   setzt Body-Font separat. Auf einem PXZ-Page-Root (`.pxz-home`,
   `.pxz-arzt`, …) messen.
2. **Page-Root muss eigenes `font-size: var(--pxz-t6-size)` setzen**,
   sonst erbt Content die alte Body-Größe.
3. **`textContent` zeigt kein `<br>`.** Zeilenzahl über
   `height / lineHeight` rechnen, nicht über String-Split.
4. **T4 kollidiert bei Body-Skalierung mit T3.** Wenn „Body ×1.5" dazu
   führt, dass T4 größer als T3 wird (Hierarchie-Inversion), die
   Konsequenz vorher klar kommunizieren.

## Commit-Strategie

Bundle-Commit: Theme (Type-Scale-Tokens + Selektor-Mapping) + Docs-Repo
(Spec + Evidence + verify-Assertion-Update). Screenshots sollten in den
Evidence-Ordner (auch wenn PNG = groß, das ist einmalige
Nachvollziehbarkeit).

## Referenz-Dokumente (Session 40)

- Spec: `projects/Cortex-Web/sites/praxis-webseite/specs/sprint-2/S40_type-scale-apple.md`
- Evidence-Probe: `…/S40_evidence/probe-apple.mjs` + `apple-scale.json`
- Phase-4-Probe: `…/S40_evidence/probe-compare.mjs`
- Pattern: `Nexus/_memory/patterns/reference-driven-type-scale.md`
