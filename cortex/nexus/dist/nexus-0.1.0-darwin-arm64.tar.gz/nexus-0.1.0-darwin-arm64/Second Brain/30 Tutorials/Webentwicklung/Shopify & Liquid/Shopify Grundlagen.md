---
type: tutorial
aliases: [Shopify, Liquid, E-Commerce, Theme, Admin API]
tags:
  - tutorial
  - shopify
  - ecommerce
  - liquid
source: Second Brain/30 Tutorials/Shopify & Liquid/
legacy_path: _tutorials/shopify/ (Symlink)
---

# Shopify & Liquid — Tutorial-Übersicht

> Quellpfad: `Second Brain/30 Tutorials/Shopify & Liquid/` (Single Source of Truth)
> Legacy-Pfad: `_tutorials/shopify/` → Symlink

Shopify ist eine E-Commerce-Plattform. Dein Juvantis hat einen Shopify-Shop. Mit Liquid (Shopify's Template-Sprache) kannst du die Website-Struktur anpassen, dynamische Inhalte anzeigen und Custom-Funktionen einbauen.

---

## Dein Juvantis-Shop

- **URL:** https://sanexio.eu
- **Repository:** https://github.com/Sanexio/JUVANTIS (Branch: `shopify-theme`)
- **Zwei Arbeits-Modi:**
  1. **Theme-Dateien** bearbeiten (Sections, Templates, Assets)
  2. **Admin API** nutzen (Produkte, Seiten, Bestellungen)

---

## Was ist ein Shopify Theme?

Ein Theme ist eine Vorlage für deinen Shop. Es besteht aus:

```
Theme/
├── sections/              ← Wiederverwendbare Blöcke
│   ├── header.liquid      (Oben auf jeder Seite)
│   ├── footer.liquid      (Unten auf jeder Seite)
│   ├── product-carousel.liquid
│   └── dht-avatar-compare.liquid  (Für Juvantis)
│
├── templates/             ← Seitenlayouts
│   ├── product.liquid     (Wie sieht eine Produkt-Seite aus?)
│   ├── collection.liquid  (Kategorie-Seite)
│   ├── cart.liquid        (Warenkörb)
│   ├── page.liquid        (Allgemeine Seiten)
│   └── ...
│
├── snippets/              ← Kleine Komponenten
│   ├── product-card.liquid
│   └── rating.liquid
│
├── assets/                ← CSS, JavaScript, Bilder
│   ├── style.css
│   ├── script.js
│   └── images/
│
└── config/
    └── settings_schema.json  ← Theme-Einstellungen
```

---

## Module

### 01 — Liquid-Grundlagen
**Template-Syntax für dynamische Inhalte.**

Liquid ist Shopify's Template-Sprache. Es ist NICHT vollständiges Programmieren — nur Templates mit Variablen und Logik.

Lerninhalte:

**Output (Text anzeigen):**
```liquid
{{ shop.name }} verkauft {{ product.title }}
{{ product.price | money }}
```

**Variablen:**
- `{{ product }}` — Das aktuelle Produkt
- `{{ collection }}` — Aktuelle Kategorie
- `{{ shop }}` — Dein Shop
- `{{ customer }}` — Daten des angeloggten Kunden
- `{{ pages }}` — Alle Seiten

**Filter (Text transformieren):**
```liquid
{{ "hello" | upcase }}        → HELLO
{{ 19.95 | money }}           → $19.95 (oder €19,95)
{{ product.created_at | date: "%Y-%m-%d" }}  → 2025-03-20
```

**Kontroll-Strukturen:**
```liquid
{% if product.available %}
  Produkt ist verfügbar!
{% else %}
  Ausverkauft
{% endif %}

{% for item in collection.products %}
  <p>{{ item.title }}</p>
{% endfor %}
```

**Comments:**
```liquid
{# Das ist ein Kommentar, wird nicht angezeigt #}
```

**Module:**
- Theorie: `01-liquid-basics.md`

---

### 02 — Shopify Admin API
**Dein Code-Schlüssel zum ganzen Shop.**

Mit der Admin API kannst du per Befehl (curl, Python, Node.js) mit deinem Shop kommunizieren. Das ist schneller und zuverlässiger als manuelles Klicken im Admin.

Lerninhalte:

**Was die API kann:**
- **Produkte:** Erstellen, ändern, löschen
- **Seiten:** Blog-Beiträge, statische Seiten verwalten
- **Bestellungen:** Lesen, Status ändern
- **Kunden:** Verwalten
- **Inventar:** Lagerbestand aktualisieren
- **Theme-Dateien:** Programmatisch bearbeiten
- **Metafields:** Zusätzliche Datenfelder speichern

**Setup (wurde bereits gemacht):**
- App "Claude API" im Partners Dashboard erstellt
- Scopes (Berechtigungen) konfiguriert
- OAuth-Flow durchgeführt (Installation auf Shop)
- API-Token und Shop-ID bekannt

**Typen von Anfragen:**
```bash
# GET — Daten auslesen
curl -X GET https://sanexio.myshopify.com/admin/api/2026-04/products.json

# POST — Neue Daten erstellen
curl -X POST https://sanexio.myshopify.com/admin/api/2026-04/products.json

# PUT — Daten ändern
curl -X PUT https://sanexio.myshopify.com/admin/api/2026-04/products/123.json

# DELETE — Löschen
curl -X DELETE https://sanexio.myshopify.com/admin/api/2026-04/products/123.json
```

**Module:**
- Theorie: `02-shopify-admin-api.md`

---

### 03 — 3D-Avatare in Shopify
**Die Juvantis-Besonderheit: Dein Avatar visualisiert.**

Shopify unterstützt 3D-Modelle auf Produkt-Seiten. Für Juvantis nutzen wir das, um den personalisierten Avatar zu zeigen.

Lerninhalte:

**Was ist ein USDZ-Modell?**
- **USDZ** = USD Zip (Pixar's universelles Format)
- **Apple AR Quick Look:** Auf iPhone/iPad kann der Nutzer den Avatar rotieren, zoomen
- **Dateigröße:** Optimiert für schnelles Laden (Shader-Baking, Kompression)
- **Rig:** Skeleton für Animationen

**Die DHT-Avatar-Vergleich Section:**
```liquid
section: dht-avatar-compare.liquid
```

Diese Custom-Section zeigt:
- Avatar des Nutzers (Links)
- Avatar "gesunder Zustand" (Rechts)
- Nebeneinander zum Vergleichen
- Interaktiv: Rotieren, Zoomen (AR Quick Look auf iPhone)

**Integration mit Health-Daten:**
- HealthKit-Daten des Nutzers auslesen (in iOS-App)
- Shape Keys des Avatars morph nach BMI
  - BMI 20 = Schlank
  - BMI 23 = Healthy
  - BMI 28 = Übergewicht
  - BMI 34 = Adipositas
- USDZ wird mit den richtigen Shape-Keys exportiert
- Shopify zeigt den personalisierten Avatar

**Technische Umsetzung:**
- **Blender:** Basis-Avatar + Shape Keys erstellen
- **Export:** USDZ mit eingebetteten Texturen
- **Shopify:** Modell im Product oder auf eigener Seite
- **JavaScript:** Optional für Interaktionen (Zoom, Pan)

**Module:**
- Theorie: `03-3d-avatare-in-shopify.md`

---

### 04 — Avatar anpassen und deployen
**Von Blender zum Live-Shop.**

Lerninhalte:

**Avatar-Pipeline Recap:**
1. **Blender:** Modell mit Shape Keys erstellen
2. **Python-Scripting:** Shape Keys basiert auf BMI morphen
3. **Export:** USDZ mit optimierten Texturen
4. **Shopify Upload:** Modell hochladen
5. **Section:** HTML/Liquid/JavaScript für Anzeige
6. **Live:** Nutzer sieht seinen personalisierten Avatar

**Shape Key Morphing Details:**
- Nicht Volumen, sondern **Taillen-Umfang** (Regel LL-032)
- Lineare BMI→Tailly-Kurve: `Tailly = 25.7 + 2.55 × BMI`
- Hard-Guards: Gesicht NIEMALS deformieren
- Kleidung mitbearbeiten (Hose + Hemd)

**Optimization für Performance:**
- Vertex-Count reduzieren (iPhone Performance!)
- Texture-Größe: 1K oder 2K max
- Materialsimplify: Alle Effekte Baken (kein Shader-Netzwerk in USDZ)
- LOD-Versionen? (Low-Poly für schnelles Laden)

**Deploy-Workflow:**
1. Avatar im Blender finalisieren
2. USDZ exportieren
3. In Google Drive oder GitHub ablegen (für Versionskontrolle)
4. Shopify Admin: Datei hochladen
5. Section referenzieren: `{% asset 'avatar-bmi-28.usdz' %}`
6. Testen auf iPhone im Safari

**Module:**
- Theorie: `04-avatar-anpassen-und-deployen.md`

---

## Lern-Reihenfolge

1. **01 — Liquid-Grundlagen** (Template-Syntax)
2. **02 — Admin API** (Programmatischer Zugriff)
3. **03 — 3D-Avatare** (Avatar-Konzept verstehen)
4. **04 — Avatar deployen** (Praktische Umsetzung)


<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

- [[30 Tutorials/Webentwicklung/Shopify & Liquid/01-liquid-basics|01-liquid-basics]] · [[30 Tutorials/Webentwicklung/Shopify & Liquid/01-liquid-basics_claude|Claude]] · [[30 Tutorials/Webentwicklung/Shopify & Liquid/01-liquid-basics_manuell|Manuell]]
- [[30 Tutorials/Webentwicklung/Shopify & Liquid/02-shopify-admin-api|02-shopify-admin-api]]
- [[30 Tutorials/Webentwicklung/Shopify & Liquid/03-3d-avatare-in-shopify|03-3d-avatare-in-shopify]] · [[30 Tutorials/Webentwicklung/Shopify & Liquid/03-3d-avatare-in-shopify_claude|Claude]] · [[30 Tutorials/Webentwicklung/Shopify & Liquid/03-3d-avatare-in-shopify_manuell|Manuell]]
- [[30 Tutorials/Webentwicklung/Shopify & Liquid/04-avatar-anpassen-und-deployen|04-avatar-anpassen-und-deployen]]
- [[30 Tutorials/Webentwicklung/Shopify & Liquid/05-admin-api-token-custom-app|05-admin-api-token-custom-app]]
- [[30 Tutorials/Webentwicklung/Shopify & Liquid/06-shopify-admin-rest-product-sync|06-shopify-admin-rest-product-sync]]
- [[30 Tutorials/Webentwicklung/Shopify & Liquid/07-shopify-template-bridge|07-shopify-template-bridge]]

<!-- /auto-moc-links -->