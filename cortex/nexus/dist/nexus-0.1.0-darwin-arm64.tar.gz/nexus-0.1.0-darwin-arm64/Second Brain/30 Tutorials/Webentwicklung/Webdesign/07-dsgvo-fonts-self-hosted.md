---
type: tutorial
aliases: [DSGVO Fonts, Self-Hosted Fonts, Google Fonts ablösen, Inter Variable]
tags:
  - tutorial
  - webentwicklung
  - webdesign
  - dsgvo
  - performance
source: Second Brain/30 Tutorials/Webentwicklung/Webdesign/
sequence: 09
---

# 09 · Google Fonts DSGVO-konform ablösen

> Lesezeit: 8 Minuten · Voraussetzung: 03 (Inline-CSS zu externer Datei) · 05 (Design Tokens)
> Praxis-Anker: angewendet bei sanexio-github-io am 2026-05-03 (Phase 4 von Sprint 1)

---

## Warum überhaupt?

Wenn deine Webseite ein `<link>` zu `fonts.googleapis.com` enthält, lädt der Browser jedes Besuchers eine Datei von Google. Dabei wird die **IP-Adresse des Besuchers** an Google übermittelt, bevor er deine Webseite überhaupt zu Gesicht bekommt.

Das ist:
- **DSGVO-relevant** — eine Datenübermittlung an einen US-Konzern, die in Deutschland (LG München, Urteil vom 20.01.2022) als rechtswidrig eingestuft wurde, wenn sie ohne explizite Einwilligung passiert.
- **performance-relevant** — der Browser muss eine zweite Domain auflösen (DNS), eine zweite TLS-Verbindung aufbauen (`fonts.gstatic.com`), und erst dann die Font laden. Drei zusätzliche Round-Trips.
- **vermeidbar** — Google bietet die Fonts unter der SIL Open Font License (OFL) an, du darfst sie selbst hosten.

---

## Die Erkenntnis hinter dem Pattern

Eine kleine technische Pointe macht das Self-Hosting deutlich einfacher als oft beschrieben:

**Google Fonts liefert für moderne Familys (Inter v20, Inter Tight v9, Roboto Flex…) ein einziges „Variable-Font"-File pro Family pro Subset, das ALLE Weights enthält.**

Das heißt konkret: Wenn du Inter in den Weights 400, 500, 600, 700 brauchst, lädst du **nicht 4 Dateien**, sondern **eine einzige Datei** mit Weight-Range 100-900 — die wiegt nicht viel mehr als ein einzelner statischer Cut.

**Bytes-Vergleich für eine deutsche Webseite:**

| Variante | Größe | Round-Trips |
|---|---|---|
| Google Fonts CDN (4 Inter + 3 Inter Tight Cuts) | ~250 KB | 7 + DNS/TLS für `gstatic.com` |
| Statische Cuts self-hosted | ~230 KB | 7 |
| **Latin Variable self-hosted** | **~91 KB** | **2** |

Das vierte Argument: Latin-Subset reicht für Deutsch. Die anderen Subsets (cyrillic, greek, vietnamese) braucht eine deutschsprachige Praxis-/Sanexio-Webseite nicht.

---

## Schritt 1 — CSS von Google Fonts holen (mit Modern-Browser-User-Agent)

Google liefert je nach User-Agent unterschiedliche CSS-Versionen. Mit `curl --user-agent` zwingst du es, die moderne Variable-Font-Variante mit `unicode-range`-Subsets zu liefern:

```bash
curl -s -A "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" \
  "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Inter+Tight:wght@500;600;700&display=swap" \
  -o /tmp/fonts.css
```

Was du bekommst, ist eine Liste von `@font-face`-Blöcken pro Subset:

```css
/* cyrillic-ext */
@font-face { ... unicode-range: U+0460-052F, ... }

/* latin */
@font-face {
  font-family: 'Inter';
  src: url(https://fonts.gstatic.com/s/inter/v20/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1ZL7W0Q5nw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, ...;
}
```

Du brauchst **nur den `latin`-Block pro Family**.

---

## Schritt 2 — woff2 herunterladen

Aus jedem Latin-Block kopierst du die `gstatic.com`-URL und lädst die Datei in deinen Repo:

```bash
mkdir -p public/fonts
curl -o public/fonts/inter-latin-variable.woff2 \
  https://fonts.gstatic.com/s/inter/v20/UcC73FwrK3iLTeHuS_nVMrMxCp50SjIa1ZL7W0Q5nw.woff2
```

**Lizenz-Note:** Inter und Inter Tight stehen unter der SIL Open Font License (OFL-1.1). Self-Hosting ist erlaubt, kommerzielle Nutzung erlaubt, sogar Modifikation erlaubt — du musst nur die Lizenz beilegen, wenn du die Font weitergibst (was du nicht tust, du nutzt sie nur).

---

## Schritt 3 — `@font-face`-Block schreiben

Lege eine `fonts.css` neben deine globale CSS und definiere:

```css
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 100 900;            /* WICHTIG: Range, nicht fester Wert */
  font-display: swap;              /* zeigt Fallback bis Font geladen */
  src: url('/fonts/inter-latin-variable.woff2') format('woff2-variations');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA,
                 U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122,
                 U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
```

**Drei Detail-Lehren:**
- `font-weight: 100 900` (mit Leerzeichen, kein Komma) signalisiert dem Browser: „Ein einziges File bedient alle Weights". Wenn du `400` schreibst, wird der Browser nur 400er-Anfragen bedienen und für 600 nichts finden.
- `format('woff2-variations')` ist der präzise Format-Hint für Variable Fonts. Browser ignorieren falsche Hints, aber präzise Hints helfen ihnen bei Caching-Entscheidungen.
- `unicode-range` bewirkt, dass der Browser die Datei NUR lädt, wenn der Text tatsächlich Zeichen aus diesem Bereich enthält. Bei einer rein deutschen Seite: immer.

---

## Schritt 4 — Im HTML die Google-Fonts-Refs ersetzen

Vorher:
```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" />
```

Nachher:
```html
<link rel="preload" href="/fonts/inter-latin-variable.woff2"
      as="font" type="font/woff2" crossorigin />
```

Das `crossorigin`-Attribut ist auch bei same-origin-Preloads Pflicht — sonst lädt der Browser die Font ZWEIMAL (einmal als Preload, einmal als regulärer Font-Fetch). Das ist ein häufiger Stolperstein.

---

## Schritt 5 — Iframes nicht vergessen

Iframes erben **keine** Fonts vom Parent-Dokument. Wenn du Iframe-Content hast (z. B. einen interaktiven Health-Graph), musst du dort einen eigenen `@font-face`-Block einbauen — derselbe `/fonts/`-Pfad funktioniert, weil der Browser die Font dann aus dem Cache lädt, den der Parent gerade gefüllt hat.

```html
<!DOCTYPE html>
<html>
<head>
  <link rel="preload" href="/fonts/inter-latin-variable.woff2" as="font" type="font/woff2" crossorigin>
  <style>
    @font-face { /* dieselbe Definition wie im Parent */ }
    body { font-family: 'Inter', -apple-system, sans-serif; }
  </style>
</head>
```

---

## Schritt 6 — Verifizieren

Drei Beweise dass es funktioniert:

```bash
# 1. Build hat keine google-Refs mehr
grep -r "fonts.googleapis\|fonts.gstatic" dist/   # → leer

# 2. Live-URL liefert preload-Tags statt Google-Refs
curl -s https://example.com | grep -E '<link[^>]+font'

# 3. Font-Files sind erreichbar
curl -sI https://example.com/fonts/inter-latin-variable.woff2
# → HTTP/2 200, content-type: font/woff2
```

Wenn das alles grün ist, fließen **null** Daten zu Google bei einem Besuch deiner Seite.

---

## Anti-Patterns (was nicht funktioniert)

- **`font-display: block`** — blockiert das gesamte Rendering bis Font da ist. Nutze `swap`, das zeigt System-Font während des Ladens und tauscht weich.
- **Font ohne `crossorigin` preloaden** — doppelter Fetch, weil die Anonymous-Variante nicht im CORS-Cache ankommt.
- **Vollsatz aller Subsets self-hosten** — verschwendet 80% Bytes, wenn du nur Deutsch brauchst.
- **Statische Cuts pro Weight** statt Variable Font — 4× mehr Files, mehr Round-Trips, gleicher visueller Output.

---

## Pattern-Referenz

Detailliertes Pattern (für die nächste Site, die du DSGVO-clean machen willst):
`Nexus/_memory/patterns/self-hosted-google-fonts-latin-variable.md`

Plattform-spezifische Hinweise (WordPress / Shopify / Astro) stehen am Ende des Pattern-Files.

---

*Gelernt am 2026-05-03 bei Sanexio-GitHub-Pages Sprint 1 Phase 4. Inter Latin Variable: 47 KB. Inter Tight Latin Variable: 44 KB. Lighthouse Performance Score nach Umstellung: 90 (Mobile, GitHub-Pages-Hosting).*
