---
title: 13 — Local-Master / Staging / Prod Pipeline (Polish-Phase-Workflow)
sprint: Cortex-Web Welle K · Praxis-Webseite Sprint-2-Ende
created: 2026-05-07
related:
  - 04-credentials-und-env-dateien.md
  - patterns/local-master-staging-prod-pipeline.md (geplant)
  - sites/praxis-webseite/specs/sprint-2/K_com-go-live.md
---

# Tutorial 13 — Local-Master / Staging / Prod Pipeline

> **Wann nutzen?** Wenn ein Web-Projekt eine Polish-Phase zwischen
> „funktional fertig" und „live auf Production" hat, und Inhalt **plus**
> Code parallel poliert werden müssen, ohne dass die Bearbeitungsquelle
> driftet.

## Symptom (woher das Tutorial kam)

Praxis-Webseite stand 2026-05-07 vor dem Punkt: WordPress-Site läuft
auf `.de`-Staging mit Auth (Welle F/J abgeschlossen), Inhalte und Design
müssen vor `.com`-Go-Live nachgeschärft werden. Frage: **„Wo werden die
Polish-Edits gemacht — direkt auf .de oder auf Local?"**

Ohne klare Pipeline-Disziplin entsteht entweder:
- **„.de-direkt-Edit-Falle":** Local läuft drift weg, am Ende muss eine
  einseitige DB-Pull-Migration gefahren werden (URL-Search-Replace, Salts,
  GUIDs) — fragil, fehleranfällig.
- **„Hybrid-Falle":** Theme via Git, Content via .de-Admin → keiner weiß
  später, was wo bearbeitet wurde, Multi-Device-Sync zerfällt.

## Lösung: Drei-Stage-Pipeline mit klarer Master-Rolle

```
┌──────────┐  push     ┌──────────┐  push     ┌──────────┐
│  Local   │ ────────▶ │ Staging  │ ────────▶ │   Prod   │
│ (Master) │  --theme  │  (.de)   │  Welle K  │  (.com)  │
└──────────┘  --db     └──────────┘           └──────────┘
     ▲                       │                     ▲
     │      iterate          │                     │
     └───────────────────────┘                     │
                                  Verify-Stage     │
                                  bleibt erhalten ─┘
```

Drei Rollen, klare Trennung:

| Stage | Rolle | Wer schreibt? | Wer liest? |
|---|---|---|---|
| **Local** | **Master** für Theme-Code (Git) **und** WP-DB-Content | Sie + Claude | Browser-Local |
| **Staging** | **Verify-Stage** | Niemand direkt — nur Sync-Skript | Sie via Auth-geschützte URL |
| **Prod** | **Production** | Niemand direkt nach Welle K | Endbesucher |

**Goldene Regel:** Niemals direkt auf Staging oder Prod editieren während der
Polish-Phase. Jede Änderung beginnt auf Local.

## Loop pro Polish-Iteration

```
1. Local-Edit (Theme via Git, Page-Content via WP-Admin auf Local)
2. (Optional) Theme-Files committen — PXZ-Versions-Bump
3. tools/sync-local-to-de.sh --theme [--db <patch.sql>]
4. tools/pre-launch-verify.sh --target=de    ← muss grün bleiben
5. Browser-Walk auf .de mit Auth              ← Sie
6. → wenn ok: nächste Iteration
   → wenn nicht: zurück zu 1
```

5–15 Minuten pro Iteration ist die Erwartung. Schneller wenn nur ein
CSS-Tweak, langsamer bei Multi-Page-Content-Änderungen.

## Das Sync-Skript

Inkrementeller FTPS-Push mit `lftp mirror -R --only-newer`. Pflicht-
Exclusions, damit nichts Tarball-Müll rausgeht:

```bash
lftp -u "$USER","$PASS" -p "$PORT" "ftp://$HOST" <<EOF 2>&1 | grep -v "^mkdir -p ftp://" || true
set ftp:ssl-force true
set ssl:verify-certificate no
set cmd:trace off
set net:max-retries 3
set mirror:parallel-transfer-count 4
mirror -R \
  --only-newer \
  --delete \
  --exclude-glob .git/ \
  --exclude-glob node_modules/ \
  --exclude-glob _archive/ \
  --exclude-glob _backups/ \
  --exclude-glob specs/ \
  --exclude-glob '*.log' \
  --exclude-glob '*.bak' \
  --exclude-glob '.DS_Store' \
  "$LOCAL" \
  "$REMOTE"
quit
EOF
```

### Drei Sicherheits-Details die leicht vergessen werden

1. **Passwort-Echo-Filter.** Beim ersten Run im Default-Verbose-Modus
   echoed `lftp` den Connection-String inkl. Passwort, wenn ein
   `mkdir -p` triggert. Lösung: `set cmd:trace off` PLUS
   `2>&1 | grep -v "^mkdir -p ftp://"` als Defense-in-Depth.
2. **Welle-J-Exclusions.** Das `.git/`-Verzeichnis im Theme-Repo darf
   NIE auf den Server. Ein einziger versehentlicher Tarball mit `.git/`
   führt zu kompletter Theme-History-Exposure (Standard-Recon-Target
   für Angreifer). `--exclude-glob` ist Pflicht.
3. **`--only-newer` ist Mtime-basiert**, nicht inhalt-basiert. Bei
   Git-Checkout/Reset werden Mtimes neu gesetzt — der erste Sync nach
   Branch-Switch dauert deshalb länger. Kein Bug.

## Was MIT der Pipeline funktioniert + was NICHT

| Funktioniert | Funktioniert NICHT |
|---|---|
| Theme-CSS/PHP-Edits | Direkter `.de`-WP-Admin-Edit (würde drift verursachen) |
| Page-Content via Local-WP-Admin → SQL-Patch | Plugin-Aktivierung/Deaktivierung auf .de (DB-State drift) |
| Image-Uploads via Local-WP-Admin (Pfad-stabil) | Theme-Switch direkt auf Staging |
| WPML-Übersetzungen via Local | Site-URL/Home-URL-Änderungen (gehen nur in DB-Patch) |

## Warum nicht nur „auf Staging editieren und am Ende DB pullen"?

Drei Gründe aus der konkreten Praxis-Webseite-Welle:

1. **Welle F hat 6 388 URL-Replacements gebraucht** (`local → westend-hausarzt.de`).
   Jeder DB-Pull-zurück müsste genauso viele Replacements rückwärts machen.
   Das Tooling ist wp-cli-basiert, aber GUIDs, Salts, Plugin-Cache-Tabellen
   sind Stolpersteine.
2. **Multi-Device-Setup**. Wenn Sie heute auf MacBook und morgen auf
   Mini editieren, ist Local-Master diszipliniert (Git zieht den
   Theme-Stand, WP-Admin-Login auf der lokalen Site). Staging-Master
   würde alle Devices an den FTPS-Login binden.
3. **Theme-Code ist Git-getrieben** (PXZ-Versionierung, Verify-Suite,
   Sanitizer). Ein direkter `.de`-Edit am Theme bricht die Git-Quelle
   sofort.

## Phase-K (Prod-Push) — was ändert sich gegenüber Polish-Loop?

Welle K ist **kein** inkrementeller Sync, sondern ein **One-Shot-Full-Deploy**:

- Tarballs frisch bauen (`wp-core`, `wp-content-code`, `wp-content-uploads`)
- DB-Dump mit Search-Replace `local → .com` (analog Welle F-Phase-B)
- Eigener `.com`-DocRoot (auf cPanel typisch ein zweiter Pfad neben `/public_html/`)
- Welle-J-Hardening-Block direkt mit drauf (`.htaccess` Hostname-scoped)
- Verify via `tools/pre-launch-verify.sh --target=com` (21/21)
- HTTP-Smoke 343 Asset-Refs

Erst nach Welle K dreht sich das Setup um:
- **Local** bleibt Master für künftige Änderungen
- **`.de`** bleibt aktiv als Verify-Stage (Auth bleibt!)
- **`.com`** ist neu und Production

## Anti-Patterns zum Vermeiden

| Anti-Pattern | Symptom | Fix |
|---|---|---|
| „Schnell auf .de fixen, später nach Local sync'en" | Drift, am Ende vergessen | Strikt: niemals direkt auf .de editieren |
| Volltext-Tarball für jede Polish-Iteration | 246 MB Upload pro 1-Zeilen-Fix | `--only-newer` + selektive DB-Patches |
| `.git/` im Tarball | Theme-Repo komplett clonebar nach Server-Extract | `--exclude-glob .git/` + Server-seitiger Verify |
| Auth zu früh entfernen | Polish-Edits sind plötzlich öffentlich sichtbar | Auth bleibt bis Welle K abgeschlossen + Verify grün |
| Local-DB nicht regelmäßig sichern | Bei Local-Crash ist alle Polish-Arbeit weg | Local-by-Flywheel-Snapshot oder `wp db export` als pre-iteration-backup |

## Quick-Reference

```bash
# Polish-Iteration starten (Default: Theme-Sync + Verify)
./tools/sync-local-to-de.sh

# Nur Theme syncen, kein Verify
./tools/sync-local-to-de.sh --theme

# Nur Verify ohne Sync (z. B. nach manueller Server-Action)
./tools/sync-local-to-de.sh --verify

# Dry-Run vorher (was würde übertragen?)
./tools/sync-local-to-de.sh --theme --dry-run

# Mit DB-Patch (v1: nur Pointer, Apply manuell)
./tools/sync-local-to-de.sh --db patches/2026-05-08-team-page-update.sql
```

## Referenzen

- `sites/praxis-webseite/specs/sprint-2/K_com-go-live.md` — vollständige Welle-K-Spec
- `sites/praxis-webseite/tools/sync-local-to-de.sh` — Sync-Skript
- `sites/praxis-webseite/tools/pre-launch-verify.sh` — Verify-Suite (21/21 Checks)
- `Nexus/_memory/patterns/php-tar-extract-permission-fix.md` — Tarball-Permission-Fallen
- `Nexus/_memory/patterns/htaccess-rewrite-deny-trumps-auth.md` — Apache-Auth-Merge-Fallen

---

*Tutorial 13 angelegt 2026-05-07 nach Modell-A-Entscheidung im Cortex-Web-
Sprint Welle K (Pre-`.com`-Go-Live).*
