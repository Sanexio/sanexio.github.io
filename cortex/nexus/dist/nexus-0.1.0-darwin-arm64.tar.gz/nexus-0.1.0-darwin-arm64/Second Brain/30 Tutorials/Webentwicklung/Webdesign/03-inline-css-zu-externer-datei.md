# Inline-CSS aus einem Page-Template in eine externe Datei auslagern

**Kontext:** Sprint 0 / S0.2 im Projekt `praxis-redesign`, abgeschlossen 2026-04-18 (PXZ_VERSION 2.7.3 → 2.7.4).
**Vorgänger-Modul:** `02-git-bootstrap-und-page-registry.md` (warum das Theme ein Git-Repo hat und was `PXZ_VERSION` macht).
**Zielgruppe:** Dr. Stracke, wenn er später ein anderes Theme vom selben Anti-Pattern (Inline-`<style>`-Block im Body) befreien will.

---

## Was in diesem Modul steht

1. Warum **Inline-CSS im Body** ein Anti-Pattern ist und wann es trotzdem legitim bleibt.
2. Wie WordPress Stylesheets über **`wp_enqueue_style`** und deren **Dependency-Kette** lädt.
3. Warum die **Cascade-Position** nach der Extraktion identisch bleiben MUSS und wie man das erzwingt.
4. Warum man den Transfer als **1:1-Transfer** macht und nicht als „schon mal aufräumen"-Refactor.
5. Welche Beweise man führt, dass die Extraktion **visuell identisch** geblieben ist.

---

## 1. Warum Inline-CSS im Body ein Anti-Pattern ist

Ein Page-Template wie `template-homepage.php` wird bei jedem Seiten-Request vollständig neu erzeugt. Wenn 500+ Zeilen CSS direkt als `<style>`-Block in diesen HTML-Output gedruckt werden, entstehen mehrere Probleme:

| Problem | Wirkung |
|---|---|
| **Jede Seitenanfrage überträgt das komplette CSS** | Keine Browser-Cache-Entlastung — Besucher lädt die 40–60 KB CSS bei jedem Klick neu mit. |
| **Keine IDE-Unterstützung** | Das CSS liegt innerhalb einer PHP-Datei, die IDE muss raten. Auto-Complete, Linting, Prettier greifen nicht sauber. |
| **Review-Unfreundlich** | Ein Pull Request mit 500 Zeilen CSS innerhalb eines 900-Zeilen-PHP-Files ist kaum lesbar. |
| **Selektor-Duplikate mit `style.css`** können unentdeckt bleiben | Siehe PXZ-E-001: derselbe Reset wurde versehentlich doppelt gepflegt. |

**Ausnahme — wann Inline legitim bleibt:** kleine seiten- oder komponenten-spezifische Schnipsel (< 20 Zeilen), die nur **einmal** pro Seitentyp gebraucht werden und wo der Extra-HTTP-Request teurer wäre als das Inline-Gewicht. Ab einer gewissen Größenordnung (Faustregel: ≥ 50 Zeilen oder mehrfach wiederverwendbar) → Datei.

---

## 2. WordPress Stylesheet-Laden: das Enqueue-System

WordPress ruft im `<head>` alle Stylesheets auf, die über die Action `wp_enqueue_scripts` registriert wurden. Jedes Stylesheet hat:

- **Handle** — eindeutiger Name, z.B. `'pxz-homepage'`
- **Quelle** — URL, typischerweise `PXZ_URI . '/assets/css/...css'`
- **Dependencies** — Array von Handles, die zuerst geladen werden müssen
- **Version** — Query-String `?ver=2.7.4`, wirkt als Cache-Buster

```php
wp_enqueue_style(
    'pxz-homepage',                                  // handle
    PXZ_URI . '/assets/css/homepage.css',            // src
    [ 'praxiszentrum' ],                             // deps (lädt nach Child-Theme)
    PXZ_VERSION                                      // ver (Cache-Buster)
);
```

**Die Dependency ist das wichtigste Argument in dieser Aufgabe.** Der Browser lädt die CSS-Dateien in der Reihenfolge, in der WordPress sie im `<head>` ausdruckt. WordPress respektiert dabei die Dependency-Kette:

1. `blocksy-parent` (kein `dep`) → zuerst
2. `praxiszentrum` (dep: `blocksy-parent`) → danach
3. `pxz-homepage` (dep: `praxiszentrum`) → zuletzt

Das ist entscheidend für **Punkt 3**.

### Conditional Enqueue: `is_page_template()`

Nicht jedes Stylesheet wird auf jeder Seite gebraucht. `pxz-homepage` ist nur für die Homepage relevant. Der Check:

```php
if ( is_page_template( 'template-homepage.php' ) ) {
    wp_enqueue_style( 'pxz-homepage', ... );
}
```

- Spart auf jeder anderen Seite den HTTP-Request.
- Verhindert, dass homepage-spezifische Selektoren auf Fremdseiten durchblue­ten (auch wenn sie theoretisch via Scoping `body.page-template-template-homepage` abgesichert wären).

---

## 3. Warum die Cascade-Position identisch bleiben MUSS

CSS funktioniert über **Cascade**: wenn zwei Regeln denselben Selektor mit gleicher Spezifität definieren, gewinnt die **zuletzt geladene**. Ein Inline-`<style>`-Block, der im Body (also nach `</head>`) steht, lädt in der Browser-Reihenfolge **nach** allen `<head>`-Stylesheets. Er gewinnt damit bei Spezifitäts-Gleichstand.

Wenn wir dieselben Regeln in eine externe Datei verschieben und diese Datei falsch positionieren, kann sich das Ergebnis ändern — obwohl kein einziger Selektor angefasst wurde. Das wäre eine unsichtbare Regression.

**Sichere Ausgangsposition:** die externe Datei so enqueuen, dass sie **nach** dem Child-Theme-Stylesheet lädt. Dann steht sie im `<head>` ganz am Ende, noch bevor der Body kommt — also in exakt derselben effektiven Cascade-Position wie vorher der Inline-Block. Das erreichst du durch:

```php
wp_enqueue_style( 'pxz-homepage', ..., [ 'praxiszentrum' ], ... );
//                                      ^^^^^^^^^^^^^^^^^^^
//                                      dep = Child-Theme-Handle
```

Wenn du das vergisst, landet `pxz-homepage` potenziell VOR dem Child-Theme. Dann überschreibt das Child-Theme deine Homepage-Regeln — und Spezifitäts-Duelle kippen plötzlich zu Gunsten des Parents.

---

## 4. 1:1-Transfer-Disziplin — nicht refactorn!

Beim Verschieben ist die Versuchung groß, „gleich mal kurz" ein paar Selektoren zu vereinheitlichen, tote Klassen zu entfernen oder `!important` zu reduzieren. **Nicht tun.** Gründe:

- Wenn nach der Extraktion etwas visuell anders aussieht, ist die Ursache nicht eindeutig zu isolieren: lag es am Vehikel-Wechsel oder am Refactor?
- Review wird schwerer: der Reviewer muss simultan zwei Dimensionen verstehen.
- Rollback wird teurer: man kann nicht mehr einfach den Move-Commit revertieren, ohne den Cleanup zu verlieren.

**Regel:** Ein Commit = eine Art von Änderung. Vehikel-Wechsel zuerst (verify grün), Refactoring separat (falls überhaupt, in einem eigenen Sprint).

Die tote `$v`-Variable in `template-karriere.php`, die nur noch das alte Inline-Style-ID-Attribut versorgt hat, durfte entfernt werden — weil sie mit der Extraktion funktional obsolet wurde und kein Refactor, sondern ein direktes Nebenprodukt ist. Faustregel: **Nur Dinge löschen, die durch den Transfer selbst tot werden.**

---

## 5. Beweis der visuellen Identität

Screenshots allein sind ein schwacher Beweis (siehe PXZ-E-003 + PXZ-E-004). Besser ist eine **Computed-Style-Probe**: ein Headless-Chrome-Skript rendert die Seite, liest für eine Liste definierter Selektoren die tatsächlich gerenderten Werte aus (z.B. `paddingTop: "96px"`) und vergleicht sie gegen eine EXPECTED-Tabelle.

In `praxis-redesign` erledigt das `tools/probe-design.mjs` über die Page-Registry (siehe Tutorial 02). Nach S0.2 galten 54 Assertions auf 2 Pages × 3 Viewports als grün — wertvoller Beweis als jedes Auge.

Zusätzlich die **Alignment-Probe** (`tools/alignment-probe.mjs`): bei zentrierten Showpiece-Elementen muss die berechnete Mitte exakt der Viewport-Mitte entsprechen, Delta `0px`. Wenn die Cascade nach der Extraktion kippt, würde hier plötzlich ein Delta auftauchen — sichere Fangleine für PXZ-E-008.

---

## 6. Commit-Muster

Ein Commit pro Template, am Ende ein PXZ_VERSION-Bump. Beispiel aus `praxis-redesign`:

```
c3f7db7  feat(s0.2): extract homepage CSS from inline to assets/css/homepage.css
914af8d  feat(s0.2): extract karriere CSS; bump PXZ_VERSION 2.7.3 → 2.7.4
```

Der zweite Commit enthält den Versionsbump, weil S0.2 als Architektur-Schritt EINEN Patch-Level wert ist — nicht zwei. Die Commit-Message dokumentiert explizit: „1:1-Transfer, keine Selektoren-/Deklarations-Änderung".

---

## 7. Nach der Extraktion: Verify-Pipeline erweitern

Ein Split-Check (siehe `tools/verify.sh` §1) vergleicht, ob derselbe Selektor in zwei verschiedenen Dateien lebt. Vor S0.2 verglich er `style.css` gegen `template-homepage.php`. Nach S0.2 muss er `style.css` gegen `assets/css/homepage.css` und `assets/css/karriere.css` vergleichen. Wenn man das vergisst, wird eine zukünftige versehentliche Doppel-Definition nicht mehr gefangen — der Check wird **rot-blind**.

**Offene Aufgabe im Projekt:** Split-Check in `verify.sh` auf die neuen Dateien ausweiten. (Als Nachzügler-Task in den Sprint-Backlog geschoben.)

---

## 8. Muster-Zusammenfassung

```
1. CSS-Body zwischen <style> und </style> raussägen      →  assets/css/<slug>.css
2. PHP-Echos in CSS-Kommentaren durch statischen Text ersetzen
3. <style>-Block im Template vollständig entfernen
4. Tote $v-Variablen o.ä. mit entfernen
5. wp_enqueue_style(..., ['praxiszentrum'], PXZ_VERSION) in functions.php
6. if ( is_page_template('template-<slug>.php') ) { ... } als Guard
7. verify + probe-design grün
8. PXZ_VERSION + CHANGELOG-Eintrag
9. Split-Check auf neue Datei(en) ausweiten (Nachzügler)
```

Das Ergebnis: identische Optik, halbierte Template-Größe, saubere Review-Diffs, ladbar via Cache.
