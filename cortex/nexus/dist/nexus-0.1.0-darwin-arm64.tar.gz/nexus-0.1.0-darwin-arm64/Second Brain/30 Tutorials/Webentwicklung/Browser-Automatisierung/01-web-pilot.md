---
aliases: [Web-Pilot, Browser-Steuerung Claude]
tags: [tutorial, webentwicklung, browser-automation, cortex-agent, web-pilot]
---

# Web-Pilot — Was ist das?

Web-Pilot ist ein Werkzeug, mit dem Claude (oder du selbst) eine Webseite
**öffnen, lesen und bedienen** kann — entweder in einem unsichtbaren
Hintergrund-Browser oder durch Andocken an deinen laufenden Chrome.

Es ist der **erste Skill** des Cortex-Agent-Hubs (seit 2026-04-28).

## Wofür gibt es Web-Pilot?

Wenn du in einer Web-App (Shopify-Admin, WordPress, Grafana, eine Patienten-
Schulungs-Webseite) feststeckst und fragst „wie ändere ich hier X?", soll
Claude die Seite selbst sehen können — entweder durch Mitfahren in deinem
Chrome oder im eigenen Browser. So kann Claude dir präzise sagen, wo du
klicken musst, oder den Klick gleich selbst ausführen.

## Zwei Modi

| Modus | Wer hat den Browser? | Login |
|---|---|---|
| **C — Headless** | Web-Pilot startet einen eigenen, unsichtbaren Chromium | Du loggst dich einmal pro Profil im Headless-Browser ein, Cookies bleiben dort |
| **D — Chrome-Debug** | Du startest deinen Chrome mit Debug-Modus, Web-Pilot dockt sich an | Du loggst dich wie immer in deinem Chrome ein, Web-Pilot fasst die Logins nie an |

In **beiden** Modi gibt Web-Pilot **niemals** ein Passwort ein. Du tippst,
Web-Pilot klickt nur Buttons und liest Inhalte (Stracke-Sicherheitslinie
2026-04-28).

## Architektur in einer Zeile

```
CLI  ──HTTP──▶  Daemon  ──Playwright──▶  Browser (eigener Headless oder dein Chrome via CDP)
```

- **CLI** (`web-pilot ...`) — du oder Claude tippt hier
- **Daemon** — Hintergrundprozess, hält den Browser offen, hört auf Port 9810
- **Browser** — entweder Headless-Chromium oder dein laufender Chrome

## Wo lebt der Code?

| Was | Pfad |
|---|---|
| Tool (Code, Spec, Logs) | `Nexus/tools/web-pilot/` |
| Manifest (cortex-agent-Anbindung) | `projects/cortex-agent/skills/web-pilot.manifest.json` |
| SPEC | `Nexus/tools/web-pilot/specs/SPEC.md` (v0.1.2) |
| Konfiguration | `Nexus/tools/web-pilot/_config/daemon.json`, `allowed-origins.txt` |
| Logs | `Nexus/tools/web-pilot/logs/daemon-YYYY-MM-DD.log` |

## Sicherheit auf einen Blick

- **Passwortfelder** sind hart geblockt — Web-Pilot weigert sich, sie zu füllen.
- **Cookies, Tokens, Auth-Header** werden nie geloggt (Filter in `logger.ts`).
- **Tokens in URLs** werden in Logs durch `***REDACTED***` ersetzt.
- **Login-Seiten:** wenn ein Passwortfeld sichtbar ist, persistiert ein
  `screenshot --out` die Datei nicht — du bekommst sie nur als stdout-Stream.
- **Origin-Allowlist:** optional in `_config/allowed-origins.txt`. Leer = alles
  erlaubt mit Warnung im Log.

## Bezug zu cortex-agent

Web-Pilot ist Skill 1 des Hubs. Der Hub liest in Zukunft Manifeste aus
`projects/cortex-agent/skills/`, listet Capabilities und routet später
Telegram-Trigger an die passenden Skills. Web-Pilot bleibt aber **autark**
nutzbar — auch ohne den Hub funktioniert das CLI direkt (LL-047, Layout 1b).

## Weiter

- Wie Claude es benutzt → `01-web-pilot_claude.md`
- Wie du es selbst im Terminal benutzt → `01-web-pilot_manuell.md`
