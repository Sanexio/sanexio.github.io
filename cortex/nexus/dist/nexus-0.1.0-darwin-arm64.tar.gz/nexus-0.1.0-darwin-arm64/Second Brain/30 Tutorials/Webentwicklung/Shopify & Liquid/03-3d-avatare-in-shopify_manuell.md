# 3D-Avatare in Shopify — Manueller Workflow

> So bauen Sie selbst Schritt für Schritt einen 3D-Avatar in eine Shopify-
> Section ein. Setzt voraus: Mac mit Blender, Node v22 (via nvm), Shopify
> CLI installiert, lokales Theme-Klon vorhanden.

---

## Schritt 1 — Avatar beschaffen

### Variante A: Mixamo (kostenlos, kommerziell)

1. https://www.mixamo.com im Browser öffnen
2. Mit Adobe-Account einloggen (kostenlos)
3. Im linken Bereich auf "Characters" klicken
4. Einen humanoiden Charakter auswählen (z.B. "X Bot", "Y Bot", "Vanguard")
5. Rechts oben auf "Download" klicken
6. Format: **glTF Binary (.glb)** auswählen
7. Pose: T-Pose
8. Frames: 0
9. Datei speichern als `avatar_base.glb`

### Variante B: three.js examples (kein Login, sofort)

```bash
curl -sSL -o avatar_base.glb \
  https://raw.githubusercontent.com/mrdoob/three.js/master/examples/models/gltf/Soldier.glb
```

→ Das ist der Mixamo "Vanguard"-Charakter, MIT-lizenziert für den Code,
Adobe-Mixamo-Lizenz für das Mesh.

### Variante C: Ready Player Me (Partner-Account erforderlich)

1. https://readyplayer.me/developers — Account anlegen (Sanexio-Mail)
2. https://readyplayer.me/avatar — Avatar konfigurieren
3. Download mit URL-Parameter: `?bodyType=fullbody&morphTargets=ARKit`
4. Datei speichern als `avatar_base.glb`

### Variante D: Avaturn (Pro-Plan ab ~800 USD/Monat)

1. https://avaturn.me — Account anlegen
2. Selfie hochladen, Avatar generieren
3. Export als GLB

---

## Schritt 2 — GLB inspizieren

```bash
source ~/.nvm/nvm.sh
npx --yes @gltf-transform/cli inspect avatar_base.glb
```

Notieren Sie:
- **Anzahl Meshes** (Body, Helm/Visor, Kleidung)
- **Bounding Box** (Höhe = Y-Range, Breite = X-Range)
- **Vertex-Anzahl** des Body-Mesh
- **Hat das Modell ein Skelett?** (JOINTS_0 in Attributes)

---

## Schritt 3 — Blender öffnen

1. Blender starten
2. Menü `File → Import → glTF 2.0 (.glb/.gltf)`
3. `avatar_base.glb` auswählen
4. Im Outliner-Panel die Mesh-Struktur ansehen

### Visor/Helm entfernen (falls vorhanden)

1. Im Outliner das Helm/Visor-Mesh anklicken
2. Taste `X` → "Delete"
3. Im 3D-Viewport das verbleibende Body-Mesh überprüfen

---

## Schritt 4 — Body verformen ("krank" Variante)

1. Body-Mesh auswählen
2. Tab-Taste → Edit Mode
3. Zahl-Taste `2` → Edge Select
4. Im 3D-Viewport die Bauch-Vertices selektieren (Box-Select mit `B`)
5. Sicherstellen, dass NUR Bauch und Flanken selektiert sind — NIEMALS
   das Gesicht oder die Arme
6. Proportional Editing einschalten (`O`-Taste)
7. Falloff auf "Smooth" setzen
8. Vertices nach vorne verschieben:
   - `G Z 0.08` → 8 cm Z-Achse Forward
   - Mausrad → Falloff-Radius anpassen (~30 cm)
9. Vertices zur Seite verschieben:
   - `G X 0.05` (rechte Hälfte)
   - Spiegeln auf linke Hälfte (Symmetrize)
10. Tab → Object Mode

---

## Schritt 5 — Subtilen Yellow-Tint anwenden (optional)

1. Body-Mesh auswählen
2. Im Properties-Panel: Material-Tab
3. Base Color → Mix RGB Node davorschalten
4. Mix-Faktor: 0.15
5. Zweite Farbe: warmes Gelb (R 1.0, G 0.92, B 0.55)
6. Multiply als Blend-Mode

---

## Schritt 6 — Krank-Variante exportieren

1. `File → Export → glTF 2.0 (.glb/.gltf)`
2. Format: **glTF Binary (.glb)**
3. Apply Modifiers: Ja
4. Export Animations: Nein (für statischen Vergleich nicht nötig)
5. Speichern als `avatar_sick.glb`

---

## Schritt 7 — Gesund-Variante erzeugen

1. Edit-Schritt rückgängig machen (`Ctrl Z`) bis zum Original
2. ODER: Erneut `avatar_base.glb` importieren, Visor entfernen, ohne
   Verformung exportieren
3. Speichern als `avatar_healthy.glb`

---

## Schritt 8 — GLBs ins Theme kopieren

```bash
THEME=/Users/ssmd/Library/CloudStorage/GoogleDrive-team@sanexio.de/Meine\ Ablage/Claude-OS/projects/Juvantis/website/theme

cp avatar_healthy.glb "$THEME/assets/avatar_healthy.glb"
cp avatar_sick.glb    "$THEME/assets/avatar_sick.glb"

# Verifizieren (LL-015: GDrive kann 0-Byte-Dateien erzeugen)
ls -lh "$THEME/assets/avatar_*.glb"
md5 avatar_healthy.glb "$THEME/assets/avatar_healthy.glb"
```

Beide Hashes müssen identisch sein. Andernfalls greift der GDrive-Lock
und Sie müssen den Mac-nativen Kopierweg über `osascript` nutzen
(siehe LL-015 in `_rules/GLOBAL_RULES.md`).

---

## Schritt 9 — Section-Datei erstellen

In `sections/dht-avatar-compare.liquid` eine neue Datei anlegen mit
`<model-viewer>`-Komponente. Vorlage: siehe die fertige Section in
`projects/Juvantis/website/theme/sections/dht-avatar-compare.liquid`.

Wichtige Schema-Punkte:
- `"name"` MAX 25 Zeichen — sonst Validation-Fehler beim Push
- `"presets"` ist erforderlich, sonst erscheint die Section nicht im
  Theme Editor
- URL-Override-Felder einbauen, damit die GLBs später per Theme-Editor
  getauscht werden können

---

## Schritt 10 — Template aktualisieren

1. `templates/page.[seite].json` öffnen
2. Im `sections`-Block neue Sektion einfügen:
   ```json
   "dht_compare": {
     "type": "dht-avatar-compare",
     "settings": { ... }
   }
   ```
3. Im `order`-Array die neue Section an die richtige Position einfügen:
   ```json
   "order": ["main", "dht_compare", "dht"]
   ```

---

## Schritt 11 — Push (alles zusammen, R-013)

```bash
cd "$THEME"
source ~/.nvm/nvm.sh

npx shopify theme push --store medzpoint --theme 181128757515 --allow-live \
  --only sections/dht-avatar-compare.liquid \
  --only assets/avatar_healthy.glb \
  --only assets/avatar_sick.glb \
  --only templates/page.digital-health-twin.json
```

Erwartete Ausgabe: `Theme upload complete` und keine Fehler.

---

## Schritt 12 — Live verifizieren

```bash
URL="https://sanexio.eu/pages/digital-health-twin"
curl -s "$URL" | grep -c "dht-compare-section"   # erwartet: 1
curl -s "$URL" | grep -c "model-viewer"          # erwartet: > 0
curl -sI https://sanexio.eu/cdn/shop/t/15/assets/avatar_healthy.glb \
  | grep -E 'HTTP|Content-Type'                  # erwartet: 200, model/gltf-binary
```

---

## Schritt 13 — Visuelle Sichtprüfung im Browser

1. https://sanexio.eu/pages/digital-health-twin öffnen
2. Beide Avatare drehen (Maus, Touch)
3. Toggle "Vorher / Nachher" mehrfach klicken
4. Mobile-Ansicht prüfen (DevTools → Responsive 390 px)
5. Gesicht beider Varianten frontal vergleichen — muss identisch sein

---

## Schritt 14 — Git committen

```bash
git add sections/dht-avatar-compare.liquid \
        assets/avatar_healthy.glb \
        assets/avatar_sick.glb \
        templates/page.digital-health-twin.json
git commit -m "feat(dht): Avatar-Vergleich Hero-Section v0.1"
git push origin shopify-theme
```

Bei `git push` reject: Erst `git fetch origin shopify-theme`, dann
prüfen ob Shopify-Sync die Section bereits gepusht hat (`git show
origin/shopify-theme:sections/dht-avatar-compare.liquid`). Falls ja:
`git reset --mixed origin/shopify-theme`, dann nur die GLBs neu committen.

---

## Häufige Probleme

| Symptom | Ursache | Lösung |
|---|---|---|
| `name ist zu lang (max 25)` | Schema-Name > 25 Zeichen | Kürzen |
| `Abschnittstyp existiert nicht` | Template ohne Section gepusht | Section + Template zusammen pushen (R-013) |
| GLB liefert 404 | Asset nicht im Theme | `--only assets/...glb` zum Push hinzufügen |
| `EDEADLK` beim cp | GDrive-Lock | osascript-Weg nutzen (LL-015) |
| Section nicht im Theme Editor sichtbar | `presets` fehlt im Schema | `"presets": [{ "name": "..." }]` ergänzen |
| Mobile zeigt beide Avatare untereinander | Media Query fehlt | `@media (max-width: 767px)` ergänzen |

---

*Tutorial erstellt: 2026-04-07*
