---
type: tutorial
aliases: [Webentwicklung, Web-Dev, Web-Stack, Webseite, Internet, Frontend, Backend]
tags:
  - tutorial
  - webentwicklung
source: Second Brain/30 Tutorials/Webentwicklung/
legacy_path: _tutorials/webentwicklung/ (Symlink)
---

# Webentwicklung — Verteiler-Domäne

> Quellpfad: `Second Brain/30 Tutorials/Webentwicklung/`
> Diese Seite gibt dir den Überblick über das **Web als Ganzes**, bevor du in
> die Spezial-Domänen (Webdesign, WordPress, Shopify, Browser-Automatisierung)
> abtauchst.
>
> Seit Sprint F2 (2026-05-05) ist Webentwicklung explizit eine **Verteiler-
> Domäne** — der eigene Status entfällt im _MOC, weil die Tiefe vollständig
> in den Sub-Domänen liegt.

> [!info] Lesezeit: 10 Minuten · Voraussetzung: keine

Diese Domäne deckt alles ab, was mit Webseiten zu tun hat. Du hast aktuell
**zwei Webseiten**:

- **Praxis-Webseite** (WordPress, [westend-hausarzt.com](https://westend-hausarzt.com)) — Praxiszentrum Dr. Stracke & Kollegen
- **Juvantis-Webseite** (Shopify, [sanexio.eu](https://sanexio.eu)) — Sanexio GmbH, Digital Health Twin

Beide Webseiten liegen unter dem Dachprojekt **[[Cortex-Web]]** (Common-Trunk-Architektur).

---

## 1. Was ist eigentlich eine Webseite? (in 2 Minuten)

Eine Webseite ist nichts anderes als **Text + Bilder + Layout-Anweisungen**, die ein Browser auf deinem Bildschirm anzeigt. Drei Dinge passieren beim Aufruf:

```
┌─────────────────┐    1. Anfrage    ┌──────────────┐
│  Dein Browser   │ ───────────────▶ │   Server     │
│  (Safari, ...)  │ ◀─────────────── │ (im Internet)│
└─────────────────┘    2. HTML zurück └──────────────┘
        │
        │  3. Browser rendert HTML/CSS/JS
        ▼
   Pixel auf Bildschirm
```

1. Du tippst eine Adresse: `westend-hausarzt.com`
2. Dein Browser fragt einen **Server** im Internet: „Gib mir die Seite zu dieser Adresse"
3. Der Server antwortet mit **HTML** (Struktur), **CSS** (Aussehen), **JavaScript** (Interaktivität) und **Bildern**
4. Dein Browser rendert das Ganze zu der Seite, die du siehst

**Das war's.** Alles weitere im Web ist eine Verfeinerung dieses Prinzips.

---

## 2. Frontend vs. Backend — wo lebt was?

| Begriff | Was ist das? | Wo läuft es? | Sprachen |
|---|---|---|---|
| **Frontend** | Alles, was der Nutzer sieht (Layout, Buttons, Animationen) | Im Browser des Nutzers | HTML, CSS, JavaScript |
| **Backend** | Alles, was der Nutzer NICHT sieht (Datenbank, Login, Bestell-Logik) | Auf dem Server | PHP, Python, Node.js, Ruby, Go, ... |
| **Datenbank** | Wo Inhalte gespeichert werden (Texte, Bilder, Bestellungen, Patientendaten — soweit erlaubt) | Auf dem Server | MySQL, PostgreSQL, MongoDB |

> **Beispiel an deiner Praxis-Webseite:**
> - Du siehst Texte, Bilder, Doctolib-Button → **Frontend**
> - Wenn du im WordPress-Admin einen Text änderst, wird er in die **Datenbank** geschrieben
> - WordPress (PHP) liest beim nächsten Seitenaufruf den Text aus der Datenbank → **Backend**
> - Resultat wird als HTML an den Browser geschickt → **Frontend** wieder

---

## 3. Die drei Frontend-Sprachen — was sie tun

| Sprache | Funktion | Analogie |
|---|---|---|
| **HTML** | Struktur (Überschrift, Absatz, Bild, Liste) | Skelett eines Hauses |
| **CSS** | Aussehen (Farbe, Größe, Position, Schriftart) | Anstrich, Tapete, Möbel |
| **JavaScript** | Interaktivität (Klick reagiert, Slider, Pop-up) | Lichtschalter, Heizung, Türklingel |

**Minimal-Beispiel — alle drei zusammen:**

```html
<!-- HTML: Struktur -->
<h1 id="titel">Praxiszentrum Dr. Stracke</h1>
<button onclick="grüße()">Klick mich</button>

<!-- CSS: Aussehen -->
<style>
  #titel { color: #028090; font-family: Poppins; }
  button { background: #00A896; padding: 10px 20px; }
</style>

<!-- JavaScript: Verhalten -->
<script>
  function grüße() { alert("Guten Tag!"); }
</script>
```

Mehr dazu in [[Webentwicklung/Webdesign/01-webdesign-basics|Webdesign 01 — Webdesign-Basics]].

---

## 4. Der Web-Stack — wer baut womit auf?

Es gibt drei große Wege, eine Webseite zu betreiben. Du betreibst zwei davon parallel:

### Weg 1: CMS (Content Management System)

> **Du nutzt das hier für deine Praxis-Webseite (WordPress).**

| Was | Beispiele | Stärke | Schwäche |
|---|---|---|---|
| Eine Software, die im Browser einen Editor anbietet, mit dem auch Nicht-Programmierer Inhalte pflegen | **WordPress**, Drupal, Joomla, TYPO3 | Riesige Plugin-Welt, Marktstandard, kein Code nötig | Langsam, viel Wartungsaufwand, Sicherheits-Updates |

**Bei dir:** WordPress läuft bei domainfactory (Prod) und in Local by Flywheel (Dev). Theme: `praxiszentrum`. Du hast 27 Hauptseiten + 178 importierte Legacy-Pages, gerade in Sprint 2 in Migration.

### Weg 2: SaaS (Software as a Service)

> **Du nutzt das hier für Juvantis (Shopify).**

| Was | Beispiele | Stärke | Schwäche |
|---|---|---|---|
| Du mietest eine fertige Plattform, machst nur Theme-Anpassungen | **Shopify**, Squarespace, Webflow, Wix | Wenig Wartung, schneller Launch, E-Commerce eingebaut | Plattform-Lock-in, Monatsgebühr, weniger Freiheit |

**Bei dir:** Shopify Advanced bei sanexio.eu, eigenes Theme als GitHub-Repo (`shopify-theme`-Branch), Liquid als Template-Sprache.

### Weg 3: Eigenes Framework

> **Theoretisch denkbar für die Juvantis-iOS-Avatar-Visualisierungs-Pages — aktuell nicht im Einsatz.**

| Was | Beispiele | Stärke | Schwäche |
|---|---|---|---|
| Du baust selbst — modernes JS-Framework + eigener Server | React, Vue, Svelte, Next.js, Nuxt, Astro | Maximale Freiheit, schnellste Performance, beste UX | Hoher Bau-Aufwand, eigene Wartung, eigene Hosting-Kette |

---

## 5. Warum hast du **zwei** unterschiedliche Welten gleichzeitig?

Das ist absichtlich, nicht zufällig:

| Webseite | Plattform | Warum diese Wahl? |
|---|---|---|
| **Praxis-Webseite** | WordPress | Praxis-Inhalte sind klassische Texte (Sprechzeiten, Ärzte, Leistungen). WordPress ist Standard im Gesundheitsbereich, viele Praxen-Plugins, einfach zu pflegen. |
| **Juvantis** | Shopify | Juvantis verkauft ein Produkt (DHT-App / Health-Twin). Shopify hat E-Commerce eingebaut (Checkout, Zahlung, Versand), 3D-USDZ-Support für Avatare. Wäre in WordPress nachgebaut riesiger Aufwand. |

**Rechtlich getrennt:**
- Praxis-Webseite untersteht **HWG** (Heilmittelwerbegesetz) und Berufsordnung — keine Werbung im klassischen Sinn erlaubt
- Juvantis untersteht der **Sanexio GmbH** — kommerziell, Lifestyle-Produkt, später Medizinprodukt
- Trennung verhindert, dass Werbung der einen Seite die andere haftbar macht

Mehr zur Brücken-Architektur: [[Cortex-Web]] und [[WordPress/15-bridge-pages-trunk-rendered|WordPress 15 — Bridge-Pages]].

---

## 5b. Wenn der Redesign auf den Hostserver muss

Sobald die Praxis-Webseite vom **Cluster-Mini-02 (Local by Flywheel)**
zur **domainfactory** wandert, brauchst du das volle Stack-Verständnis:
LAMP (Linux/Apache/MySQL/PHP), wp-config.php, mysqldump + search-replace,
SFTP/rsync, Permalinks, Rollback. Das alles in einem Lehr-Tutorial:

> [[WordPress/02-manueller-deploy-host-server|WP 02 — Manueller Deploy zum Host-Server]]

Es erklärt die zwei Hälften einer WP-Site (Files vs. Datenbank), die
LAMP-Komponenten, den domainfactory-Zugang (SFTP/SSH/phpMyAdmin) und
liefert eine Schritt-für-Schritt-Befehlsabfolge mit Backup und Rollback.

---

## 6. Wo läuft die Seite? — Hosting in 1 Minute

Eine Webseite muss auf einem Server **gehostet** werden, damit sie 24/7 erreichbar ist. Die Vertrags-Beziehung ist:

```
Domain (westend-hausarzt.com)
   │
   └── DNS sagt → Server-IP-Adresse
                     │
                     └── Server hostet → WordPress + Theme + Datenbank
                                           │
                                           └── Liefert HTML an Browser aus
```

| Bestandteil | Bei dir | Verwaltet bei |
|---|---|---|
| **Domain** Praxis | westend-hausarzt.com | (Registrar) |
| **Domain** Juvantis | sanexio.eu | domainfactory |
| **DNS** | A-Record → Server-IP | beim Registrar konfiguriert |
| **Hosting** Praxis | WordPress-Hosting bei domainfactory | domainfactory |
| **Hosting** Juvantis | Shopify (vollverwaltet) | Shopify Inc. |
| **SSL/HTTPS** | Pflicht (Browser warnen sonst) | Beide automatisch |

Wenn dich DNS-Details interessieren: [[Netzwerk & Sysadmin/06-dns|DNS]].

---

## 7. Begriffe, die dir auf Webseiten begegnen

| Begriff | Bedeutung |
|---|---|
| **URL** | Adresse einer Seite, z. B. `https://westend-hausarzt.com/team/` |
| **Domain** | Der Hauptname: `westend-hausarzt.com` |
| **Slug** | Der Teil hinter dem Domain-Slash: `team` (also `westend-hausarzt.com/team/`) |
| **Page** | Eine statische Seite (Über uns, Team, Kontakt) |
| **Post** | Ein Blog-Beitrag (zeitlich sortiert) |
| **Template** | Vorlage für eine ganze Seitenart (z. B. „Standard-Page") |
| **Theme** | Komplettes Design-Paket (Templates + CSS + Logik) |
| **Plugin** | Zusatzfunktion in WordPress (Formular, SEO, Cookies) |
| **Section** (Shopify) | Wiederverwendbarer Block (Header, Hero, Footer) |
| **Snippet** (Shopify) | Kleines Stück Liquid-Code, das mehrfach genutzt wird |
| **REST-API** | Programmatischer Zugriff auf die Webseiten-Inhalte (JSON statt HTML) |
| **CDN** | Content Delivery Network — verteilt Bilder/CSS weltweit auf nahe Server |
| **Cache** | Zwischenspeicher — alte Version der Seite, kann bei Änderungen Probleme machen |
| **Mobile-First** | Layout zuerst für Handy denken, dann für Desktop |
| **Responsive** | Layout passt sich an Bildschirm-Breite an |

---

## 8. Unter-Domänen dieser Tutorial-Domäne

| Sub-Domäne | Module | Worum es geht |
|---|:-:|---|
| [[Webdesign Grundlagen]] | 25+ | Alles aus dem Praxis-Webseiten-Sprint: CSS, Design-Tokens, WP-REST-API, Review-Pipelines, Bridge-Pages, Mobile-Drawer, Footer-Override, Single-Source-of-Truth-Patterns |
| [[Shopify Grundlagen]] | 7 | Liquid-Syntax, Admin-API, 3D-Avatare, Avatar-Deploy, Custom-App-Token, Product-Sync, Template-Bridge |

**Direkte WP-Tutorials:**

| Tutorial | Worum es geht |
|---|---|
| [[WordPress Grundlagen]] | Konzepte, Architektur, Glossar |
| [[WordPress/01-db-cleanup-fallstricke|WP 01 — DB-Cleanup-Fallstricke]] | was bei direkten DB-Edits schiefgeht |
| [[WordPress/02-manueller-deploy-host-server|WP 02 — Manueller Deploy zum Host-Server]] | LAMP-Stack, MySQL/PHP-Tiefe, rsync, search-replace, Rollback |

> **Geplant, falls Bedarf entsteht:**
> - Eigenes HTML/JS-Grundlagen-Modul (heute implizit in Webdesign 00)
> - WordPress-Theme-Entwicklung (PHP, Template-Hierarchie, hooks)
> - Accessibility (Barrierefreiheit, WCAG, Screen-Reader)
> - SEO (Search-Engine-Optimization, Meta-Tags, Sitemap)

---

## 9. Lern-Reihenfolge (wenn du wirklich von 0 anfängst)

1. **Diese Seite (oben)** — du verstehst Frontend/Backend, HTML/CSS/JS, Stack-Wege
2. [[Webentwicklung/Webdesign/01-webdesign-basics|Webdesign 01 — Webdesign-Basics]] — HTML/CSS in der Tiefe
3. [[Webdesign Grundlagen]] — Übersicht der 12 generischen Module · [[WordPress Grundlagen]] für 22 WP-Praxis-Module
4. [[Webentwicklung/Webdesign/05-design-tokens-und-cascade|Webdesign 05 — Design-Tokens]] — wie professionelles Theming funktioniert
5. [[Webentwicklung/Webdesign/09-css-spezifitaet-und-komponenten-schichten|Webdesign 09 — CSS-Spezifität]] — wenn dich das Layout-Verhalten verwirrt
6. [[Shopify Grundlagen]] — wenn Juvantis-Webseite dran ist
7. [[Webentwicklung/Shopify & Liquid/01-liquid-basics|Shopify 01 — Liquid]] — Template-Sprache verstehen

---

## 10. Wichtige Regeln für dich (aus [[_MOC Regeln]])

- **R-013 / R-014:** Shopify Section + Template immer zusammen pushen, Template-Zuweisung ist manuell
- **LL-027:** Lizenz vor Code prüfen (z. B. Avatar-Quellen)
- **LL-030:** Shopify GitHub-Sync syncht keine Binaries (Bilder/GLB lokal extra committen)
- **LL-046:** Inhalte mit Umlauten, Dateinamen ASCII

---

## Verwandte Notizen

- [[_MOC Tutorials]] — Dach-MOC aller Tutorials
- [[_Basiswissen Schnelleinstieg]] — Pfad B („Web-Programmierung von 0 auf 1")
- [[Cortex-Web]] — Common-Trunk-Dachprojekt, das Praxis + Juvantis verbindet
- [[praxis-webseite]] — WordPress-Site
- [[Juvantis Website]] — Shopify-Site
- [[Terminal Grundlagen]] — Voraussetzung für alles Weitere
- [[Git Grundlagen]] — Versionskontrolle für Webprojekte
