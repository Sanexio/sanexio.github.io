---
tags: [tutorial, webentwicklung, manueller-workflow, web-pilot]
---

# Web-Pilot — Manueller Workflow

Wenn du selbst im Terminal mit Web-Pilot arbeiten willst — ohne Claude.

## Voraussetzungen

- Bun installiert (`bun --version` → 1.1+)
- Chromium ist beim ersten Start automatisch heruntergeladen (~150 MB)
- Du bist im Web-Pilot-Verzeichnis: `cd ~/Cortex/Nexus/tools/web-pilot`

## Erstes Mal — Modus C (Headless)

```bash
./bin/web-pilot start                         # Daemon starten
./bin/web-pilot use headless                  # Modus wählen
./bin/web-pilot open https://example.com      # Seite öffnen
./bin/web-pilot dom --text-only --pretty      # Inhalt anzeigen
./bin/web-pilot screenshot --out ~/test.png   # Screenshot speichern
./bin/web-pilot stop                          # Daemon stoppen
```

`open ~/test.png` zeigt dir das Bild im Mac-Vorschau-Programm.

## Erstes Mal — Modus D (mit deinem Chrome)

**Terminal A** — Chrome mit Debug-Port starten:

```bash
cd ~/Cortex/Nexus/tools/web-pilot
./bin/start-chrome-debug.sh
```

Es öffnet sich ein **separater** Chrome mit eigenem Profil (kein Vermischung
mit deinem Alltags-Chrome). Logge dich dort ein, wo du arbeiten willst.

**Terminal B** — Web-Pilot dranhängen:

```bash
cd ~/Cortex/Nexus/tools/web-pilot
./bin/web-pilot start
./bin/web-pilot connect-chrome
./bin/web-pilot tabs --pretty
./bin/web-pilot tab tab-1
./bin/web-pilot dom --text-only --pretty
```

## Befehlsübersicht

```
start | stop | restart | status | health | logs [--tail N]
use <headless|chrome-debug> [--profile NAME]
connect-chrome [--port 9222]

tabs                                    # alle Tabs auflisten
tab <id>                                # aktiven Tab wechseln
open <url> [--new]                      # URL öffnen
close [--tab id]                        # Tab schließen

dom [--selector S] [--text-only]        # HTML / Text auslesen
screenshot [--out PATH] [--full-page]   # PNG erzeugen
click <selector>                        # Klicken
fill <selector> --text "..."            # Feld füllen (NICHT Passwort)
wait <selector> | --timeout MS          # warten
eval "<javascript>"                     # JS in der Seite ausführen

--pretty                                # Mensch-lesbare Ausgabe statt JSON
```

## Sicherheits-Verhalten (was du erwarten musst)

- `fill` auf `<input type="password">` → **Block** mit Hinweis. Nimm das
  Passwort ist deine Sache. Manuell im Browser eingeben.
- URLs mit `?token=...` o. ä. werden in den Logs zu `?token=***REDACTED***`.
- `screenshot --out` auf einer Seite mit sichtbarem Passwortfeld → **Block**.
  Ohne `--out` bekommst du das Bild trotzdem (als Base64 in der Antwort).
- Allowlist in `_config/allowed-origins.txt`. Wenn leer, wird alles erlaubt
  und der Daemon warnt im Log.

## Logs ansehen

```bash
./bin/web-pilot logs --tail 30 --pretty
# oder direkt
tail -f logs/daemon-$(date -u +%F).log | jq .
```

Logs sind JSON-Lines (eine Zeile = ein Ereignis), ideal für `jq`.

## Profil-Verwaltung (Modus C)

Browser-Profile liegen in `runtime/profiles/<name>/`. Standard-Profil ist
`default`. Eigenes Profil:

```bash
./bin/web-pilot use headless --profile testlogins
```

Cookies und LocalStorage bleiben pro Profil persistent zwischen Sessions.
`runtime/` ist gitignored — Profile bleiben lokal auf dem Gerät.

## Aufräumen

```bash
./bin/web-pilot stop
rm -rf runtime/profiles/*    # alle Headless-Profile löschen
rm logs/daemon-*.log         # Logs löschen (nicht zwingend)
```

## Bekannte Stolperstellen

- **„daemon unreachable"** → `web-pilot start` vergessen.
- **Chrome-Debug startet nicht** → Standard-Chrome läuft schon mit dem
  Profil. Beende ihn ODER nutze `--profile` mit anderem Pfad.
- **„element not found"** → Selector falsch. Prüfe mit `dom --text-only`,
  ob der Inhalt geladen ist; ggf. `wait <selector>` davor.
