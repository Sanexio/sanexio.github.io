# 05 · Shopify Admin-API-Token für eigene Integrationen (Custom App, 2026er Dev Dashboard)

## Was lernst du hier?

Du bekommst einen **permanenten Admin-API-Access-Token** für deinen Shopify-Store,
mit dem Server-Programme (z.B. der Cortex-Web-Adapter) ohne UI-Klicks mit dem Shop
sprechen können: Produkte anlegen, Dateien hochladen, Bestellungen lesen, …

Das Tutorial behandelt den **aktuellen Weg seit 2024/25**. Shopify hat den alten
„Custom App" -Button im Shop-Admin abgeschafft. Alle Apps werden jetzt im **Dev
Dashboard** (`dev.shopify.com/dashboard`) angelegt — mit einer Fallstricke-Liste,
die man kennen muss.

---

## Das Kernproblem (warum man dieses Tutorial braucht)

Im Dev Dashboard gibt es einen Button **„App installieren"**. Man klickt ihn,
erwartet einen Token — und bekommt **nichts**. Shopify redirectet zur App-URL
mit `hmac`, `host`, `shop` — aber **ohne `code`**. Ohne `code` kann man keinen
Token tauschen. Das ist kein Bug, sondern Designentscheidung: Der Button führt
keinen OAuth-Authorize aus, sondern einen **App-Open** (als wäre die App bereits
installiert).

Den echten Token-Weg muss man manuell antriggern: über einen direkten
**OAuth-Authorize-Link** an Shopify.

---

## Was du brauchst

- Shopify-Store (Advanced / Basic / Plus — Dev-Store nicht nötig)
- Zugriff aufs Dev Dashboard (`dev.shopify.com/dashboard/<org-id>/apps`)
- Shopify CLI (`npm install -g @shopify/cli`)
- Node ≥ 18 oder Bun ≥ 1.0 auf deinem Mac (für den lokalen Token-Fänger)

---

## Schritt-für-Schritt

### 1. App im Dev Dashboard anlegen

Im Dev Dashboard → deine Organisation → **„App erstellen"**.

Name z.B. `Cortex-Web Adapter`. Danach in der Versionskonfiguration:

- **App-URL:** zunächst `https://example.com` (wird später geändert)
- **„In den Shopify-Adminbereich einbetten":** Haken **entfernen**
- **Zugriff → Bereiche:** kommagetrennt, z.B. `read_products, write_products, read_files, write_files`
- **„Alten Installations-Flow verwenden":** Haken **setzen**
- **„Veröffentlichen"**

### 2. App lokal verlinken (Shopify CLI)

Im Projektordner:

```bash
shopify app config link --client-id=<deine-client-id>
```

Erzeugt `shopify.app.<slug>.toml` im Projekt. Enthält nur öffentliche
Konfiguration (Client-ID, Scopes, App-URL) — Secrets sind dort **nicht** drin.

### 3. Konfiguration für OAuth-Callback vorbereiten

In der generierten `shopify.app.<slug>.toml`:

```toml
application_url = "http://localhost:53682/callback"
embedded = false

[access_scopes]
scopes = "read_files,write_files,read_products,write_products"
use_legacy_install_flow = true

[auth]
redirect_urls = [ "http://localhost:53682/callback" ]
```

Dann hochladen:

```bash
shopify app deploy --force --message "OAuth callback setup"
```

Shopify legt eine neue Version an und aktiviert sie.

### 4. Lokalen Token-Fänger schreiben

Ein kleiner HTTP-Server, der auf `localhost:53682/callback` lauscht, den
OAuth-`code` entgegennimmt, ihn gegen den Token tauscht, und das Ergebnis in
`.env.local` schreibt. Kern-Logik:

```js
const tokenRes = await fetch(`https://${shop}/admin/oauth/access_token`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ client_id, client_secret, code }),
});
const { access_token, scope } = await tokenRes.json();
// → in .env.local schreiben, chmod 600
```

Vollständige Implementierung siehe
`Cortex-Web/tools/shopify-oauth-catcher.mjs`.

### 5. Client-Secret in `.env.local`

`.env.local` mit mindestens:

```env
SHOPIFY_CLIENT_ID=<aus dev dashboard>
SHOPIFY_CLIENT_SECRET=<aus dev dashboard → einstellungen → schlüssel → auge>
```

`.env.local` MUSS git-ignoriert sein. Permission `chmod 600 .env.local`.

### 6. Fänger starten

```bash
bun tools/shopify-oauth-catcher.mjs
# → Shopify OAuth catcher listening on http://localhost:53682/callback
# → Waiting for Shopify redirect…
```

### 7. OAuth-Authorize manuell antriggern

**Nicht** den „App installieren"-Button im Dashboard klicken — der macht nur
einen App-Open (siehe Kernproblem oben).

Stattdessen: die Authorize-URL direkt öffnen. Am besten per Shell-Script, damit
keine Zeilenumbrüche die URL zerschießen:

```bash
#!/usr/bin/env bash
CLIENT_ID="<id>"
SHOP="<handle>.myshopify.com"
SCOPES="read_products,write_products,read_files,write_files"
REDIRECT="http://localhost:53682/callback"
STATE="setup-$(date +%s)"

urlencode() { jq -rn --arg s "$1" '$s|@uri'; }
URL="https://${SHOP}/admin/oauth/authorize"
URL+="?client_id=${CLIENT_ID}"
URL+="&scope=$(urlencode "$SCOPES")"
URL+="&redirect_uri=$(urlencode "$REDIRECT")"
URL+="&state=${STATE}"
open "$URL"
```

Das öffnet die Shopify-Zustimmungsseite im Default-Browser. Du siehst deine
gewählten Scopes, klickst „App installieren" / „Install" / „Zustimmen".
Shopify redirectet zu `http://localhost:53682/callback?code=…&shop=….myshopify.com&…`.

### 8. Fänger tauscht Code gegen Token

Im Terminal:

```
Callback received — shop=<handle>.myshopify.com, code=abc123…
Exchanging authorization code for access token…
✓ Token saved to .env.local
✓ Store : <handle>.myshopify.com
✓ Scopes: write_products,write_files
✓ Token : shpat_…XXXX (last 4 chars only)
```

Dein `.env.local` enthält jetzt `SHOPIFY_STORE` und `SHOPIFY_ADMIN_TOKEN`.

### 9. Verifizieren

```bash
set -a; source .env.local; set +a
curl -sS -H "X-Shopify-Access-Token: $SHOPIFY_ADMIN_TOKEN" \
  "https://$SHOPIFY_STORE/admin/api/2026-04/shop.json" \
  | jq '.shop | {name, domain, plan_name}'
```

Liefert Shop-Metadaten → Token ist produktiv einsatzbereit.

---

## Fallstricke, die Zeit kosten (Lessons Learned)

| Fehler | Symptom | Lösung |
|---|---|---|
| „App installieren" im Dashboard geklickt | Redirect zu callback mit `hmac` + `host` + `shop`, aber **ohne `code`** | Authorize-URL manuell öffnen (Schritt 7) |
| Authorize-URL aus Chat kopiert | Shopify: „Oauth error invalid_request: redirect_uri is missing" | Zeilenumbrüche im Copy-Paste. Shell-Script statt Copy nutzen |
| `shopify app dev` auf Production-Store | „Must be an existing development or Shopify Plus sandbox store" | CLI-Weg geht nicht für reine API-Integrationen mit Production-Stores |
| `use_legacy_install_flow = false` bei `http://localhost` Redirect | Shopify lehnt HTTPS-Anforderung ab | Flag auf `true` |
| Store-Handle ≠ sichtbarer Store-Name | Authorize-URL liefert 404 | Shop-Handle aus Dev-Dashboard-URL ablesen: `admin.shopify.com/store/<HANDLE>` |
| App-URL noch auf `https://example.com` | Shopify redirectet zu example.com mit `hmac`, du bekommst „Example Domain"-Seite | `application_url` und `redirect_urls` auf `localhost:<port>/callback` setzen, per `shopify app deploy` neu veröffentlichen |

---

## Sicherheit

- **Client-Secret und Admin-Token** gehören nur in `.env.local` (git-ignoriert, `chmod 600`).
- **Nie** ins Repo commiten, **nie** ins Chat kopieren, **nie** in Logs schreiben.
- Token-Rotation: bei Verdacht auf Leak → im Dev Dashboard → App → Einstellungen → „Schlüssel rotieren". Danach Schritte 5–8 wiederholen.
- Scopes minimal halten: nur das, was der Adapter braucht. Scopes erweitern erfordert **Neuinstallation** (Schritte 3/5/7–9 wiederholen).

---

## Wo im Cortex-System dokumentiert?

- Pattern (knapp): `Nexus/_memory/patterns/shopify-custom-app-token.md`
- Referenz-Impl: `Cortex-Web/tools/shopify-oauth-catcher.mjs` + `tools/shopify-authorize.sh`
- Dieses Tutorial (ausführlich): `Second Brain/30 Tutorials/Webentwicklung/Shopify & Liquid/05-admin-api-token-custom-app.md`
