# Tutorial 09 — Das 4-Schichten-Design-Token-Modell

**Für:** Dr. Stracke
**Zeit zum Lesen:** ca. 15 Minuten
**Aufbaut auf:** Tutorial 05 (Design-Tokens und Cascade)
**Kontext:** Sprint 2 / S2.0c (Praxis-Webseite, 2026-04-19)
**Praktischer Bezug:** `sites/praxis-webseite/assets/css/tokens.css` v2 +
`DESIGN_GUIDELINES.md` v3.0

---

## 1. Das Problem, das wir lösen

In Tutorial 05 haben wir gelernt: **CSS Custom Properties** (auch „CSS
Variables" genannt) sind der saubere Weg, Design-Werte zentral zu halten.
Eine Farbe ändern? Einmal in `tokens.css` — und die ganze Webseite zieht
nach.

Das funktioniert gut, solange wir nur **eine** Dimension verändern. Aber
die Realität hat mehrere:

- Wir wollen eine **Farbe** tauschen (z. B. Rot intensiver machen).
- Wir wollen eine **Schriftart** probieren (SF Pro → Inter Tight).
- Wir wollen ein **Spacing-System** feiner schneiden (96 px → 80 px).
- Wir wollen den **gesamten Design-Stack** austauschen (Apple HIG → Cortex-DS).

Jede dieser Änderungen soll **einfach** sein und **nur** die gewünschte
Wirkung haben — kein Kollateralschaden auf andere Elemente.

**Beispiel aus der Praxis (Fehler PXZ-E-006):** Es gab zwei
Padding-Tabellen (§3.3 und §13.4), die denselben Wert unterschiedlich
definiert haben — 144 px vs. 96 px. Nach einer Änderung an §13.4 hat
§3.3 still weitergegolten. Ergebnis: die Sektion war zu groß, es wurde
erst nach Dr. Strackes Abnahme-Kritik klar, dass ich einer veralteten
Tabelle gefolgt war.

**Die 4-Schichten-Architektur verhindert das strukturell.**

---

## 2. Die vier Schichten

Stell dir ein Gebäude vor. Vier Stockwerke, jede mit einer anderen Rolle:

```
┌───────────────────────────────────────────────────────┐
│  STOCKWERK 4 — PAGES                                  │
│  "Wo wird was angezeigt?"                             │
│  homepage.css, karriere.css, kontakt.css, …           │
│                                                       │
│  Darf LESEN: Stockwerk 3 (Komponenten)                │
│  Darf NICHT lesen: Stockwerk 1 oder 2 direkt          │
└───────────────────────────────────────────────────────┘
                      ▲
                      │
┌───────────────────────────────────────────────────────┐
│  STOCKWERK 3 — COMPONENTS                             │
│  "Wie sieht eine Card aus? Wie ein Button?"           │
│  components.css                                       │
│  .pxz-card { padding: var(--pxz-space-card-y-lg-…); } │
│                                                       │
│  Darf LESEN: Stockwerk 2 (Semantic)                   │
│  Darf NICHT lesen: Stockwerk 1 (Primitives) direkt    │
└───────────────────────────────────────────────────────┘
                      ▲
                      │
┌───────────────────────────────────────────────────────┐
│  STOCKWERK 2 — SEMANTIC                               │
│  "Welche Bedeutung hat welcher Wert?"                 │
│  tokens.css → :root, Schicht 2                        │
│  --pxz-c-accent: var(--color-red-600);                │
│  --pxz-space-section-y-desktop: var(--space-14);      │
│                                                       │
│  Darf LESEN: Stockwerk 1 (Primitives)                 │
│  Ändert sich: wenn die Bedeutung neu gemappt wird     │
└───────────────────────────────────────────────────────┘
                      ▲
                      │
┌───────────────────────────────────────────────────────┐
│  STOCKWERK 1 — PRIMITIVES                             │
│  "Was sind die harten Werte?"                         │
│  tokens.css → :root, Schicht 1                        │
│  --color-red-600: #C8161D;                            │
│  --space-14: 96px;                                    │
│  --font-display-family: "SF Pro Display", …;          │
│                                                       │
│  Hier stehen die Zahlen, Hex-Codes, Font-Namen        │
│  Ändert sich: bei Stack-Wechsel (Font, Farbthema)     │
└───────────────────────────────────────────────────────┘
```

### Warum die strikte Richtung?

Jede Schicht liest **nur von oben**, nie von unten, nie seitwärts. Das ist
kein Dogmatismus — es ist eine **Garantie**:

- **Wenn ich eine Primitive ändere** (z. B. `--color-red-600` von `#C8161D`
  auf `#D82C2C`), ändert sich der Akzent der ganzen Seite, aber **nichts
  anderes**. Ich weiß das sicher, weil Semantic-Schicht 2 die einzige ist,
  die Schicht 1 liest. Ich muss nicht die ganze Codebase grepen.
- **Wenn ich eine Komponente umbaue** (z. B. Card-Radius 22 → 18 px),
  ändert sich nur diese Komponente. Primitives bleiben, Semantic bleibt,
  andere Komponenten bleiben.
- **Wenn ich eine Page anders layoute** (z. B. Kontakt statt 2-spaltig
  jetzt 3-spaltig), ändern sich nur Page-Werte. Alles darunter bleibt.

Die Schichtung ist **die Versicherung gegen Kollateralschaden.**

---

## 3. Konkret — wie sieht das in `tokens.css` aus?

Ein gekürzter Auszug (die reale Datei ist ca. 180 Zeilen):

```css
:root {
  /* === SCHICHT 1 — PRIMITIVES === */
  --color-red-600:   #C8161D;     /* Hex-Wert: das Praxis-Rot */
  --color-ink-900:   #1D1D1F;     /* Hex-Wert: fast-Schwarz */
  --space-14:        96px;        /* px-Zahl */
  --font-display-family: "SF Pro Display", sans-serif;
  --radius-lg:       22px;
  --shadow-1:        0 2px 8px rgba(0,0,0,0.04);

  /* === SCHICHT 2 — SEMANTIC === */
  --pxz-c-accent:                 var(--color-red-600);
  --pxz-c-ink:                    var(--color-ink-900);
  --pxz-space-section-y-desktop:  var(--space-14);
  --pxz-font-display:             var(--font-display-family);
  --pxz-radius-card:              var(--radius-lg);
  --pxz-shadow-card:              var(--shadow-1);
}
```

**Lesen wie?**

- `--color-red-600: #C8161D` — **Primitive**. Das ist ein Fakt: „Wir
  verwenden dieses bestimmte Rot." Keine Bedeutung, nur ein Wert.
- `--pxz-c-accent: var(--color-red-600)` — **Semantic**. Das ist eine
  Bedeutung: „Der Akzent der Praxis-Seite ist das Rot Nr. 600." Morgen
  könnte der Akzent ein anderes Rot sein — nur diese Zeile würde sich ändern.

**Eine Komponente schreibt dann:**

```css
.pxz-btn--accent {
  background: var(--pxz-c-accent);     /* nicht var(--color-red-600)! */
  padding:    var(--pxz-space-btn);
  border-radius: var(--pxz-radius-btn);
}
```

Die Komponente weiß **nichts** von `#C8161D` oder von Rot als Farbe. Sie
weiß nur: „Ich bin ein Akzent-Button, hol dir den Akzent." Das ist die
**Entkopplung**, die Austauschbarkeit ermöglicht.

---

## 4. Das Austausch-Protokoll (der ganze Sinn des Modells)

### Szenario 1 — Wir wollen eine andere Schrift probieren

Dr. Stracke sagt: „Lass uns Inter Tight statt SF Pro testen."

**Ohne 4-Schichten-Modell:**
- Font-Family in `.pxz-hero-title` ändern
- Font-Family in `.pxz-mfa-headline` ändern
- Font-Family in `.pxz-kar-hero` ändern
- 30 weitere Stellen suchen und ändern
- Irgendwo vergisst man eine. Inkonsistenz.

**Mit 4-Schichten-Modell:**
1. `tokens.css` öffnen
2. **Eine Zeile** in Schicht 1 ändern:
   ```diff
   - --font-display-family: "SF Pro Display", sans-serif;
   + --font-display-family: "Inter Tight", sans-serif;
   ```
3. Seite neu laden. Fertig. Alle Schriften sind umgestellt.

Das ist das **Versprechen** des Modells.

### Szenario 2 — Wir wollen den Akzent-Farbton stress-testen

```diff
- --color-red-600: #C8161D;
+ --color-red-600: #D82C2C;
```

Logo-Border, Buttons, Links, Hover-States, Final-CTA-Shadow — alle ziehen
nach. Ohne Touch an Komponenten oder Pages.

### Szenario 3 — Rollback

Gefällt nicht? `git revert` auf den `tokens.css`-Commit. Eine einzige
Zeile macht das rückgängig. Kein Komponenten-Rollback nötig.

---

## 5. Der eine Test, ob das Modell eingehalten wird

Das Modell ist nur so stark wie seine Disziplin. Einmal schummeln und
eine Hex-Zahl direkt in `homepage.css` schreiben — und die ganze
Versicherung zerfällt genau an dieser Stelle.

Der **Selbsttest** ist ein einzeiliger Grep:

```bash
grep -E "#[0-9A-Fa-f]{3,6}|[0-9]+px" \
  assets/css/homepage.css \
  assets/css/karriere.css
```

**Idealzustand: keine Treffer.** Jeder Treffer ist ein Verstoß gegen
`DESIGN_GUIDELINES.md` §2 und wird in den nächsten Refactor-Commit
übernommen.

(Aktuell gibt es noch Treffer, weil `homepage.css` + `karriere.css` noch
aus v2.7.5 stammen und erst in S2.0b/S2.3 sauber refactored werden. Das
ist bekannt und dokumentiert.)

---

## 6. Der Legacy-Alias-Block (Übergang)

Du siehst in `tokens.css` einen dritten Block namens
**LEGACY-ALIAS-BLOCK**. Er enthält Einträge wie:

```css
--pxz-red:   var(--color-red-600);
--pxz-ink:   var(--color-ink-900);
--pxz-accent: var(--pxz-red);
```

Warum?

Weil die bestehenden Dateien `homepage.css` (30 KB) und `karriere.css`
(11 KB) an **171 Stellen** Tokens wie `var(--pxz-red)` lesen. Die darf
ich nicht kaputt machen — sonst hätten wir eine **visuelle Regression**
auf der bereits abgenommenen v2.7.5.

Also bleibt der Alias-Block bestehen, bis ein geplanter Refactor (S2.0b)
die alten Dateien auf Semantic-Namen wie `var(--pxz-c-accent)` umstellt.
Dann kann der Legacy-Block weg.

**Wichtig:** Die Aliase liefern **byteidentische** Werte wie vorher.
Beweis durch MD5-Vergleich der gerenderten Screenshots (siehe §7).

---

## 7. Beweis: MD5-Null-Delta

Die S2.0c-Umstellung hat massive Änderungen an `tokens.css` vorgenommen
(30 Zeilen → 180 Zeilen, neue Schicht-Struktur, 17 neue Space-Tokens,
Typo-/Radius-/Shadow-Primitives). Aber die **sichtbare Ausgabe** darf
sich nicht ändern — sonst hat der Umbau der Abnahme von Dr. Stracke
widersprochen.

Der härteste Beweis dafür ist nicht ein visuelles „sieht gleich aus",
sondern ein **Byte-für-Byte-Vergleich** der gerenderten Screenshots:

```bash
# Vorher: v2.7.5-Screenshot
md5 -q screenshots/claude/2026-04-18_v2.7.5_home_desktop1440_full.png
# 1011c76b3677b9dbd8d0069cc4c1c680

# Nachher: v2.7.6-Screenshot (gleicher Tag, gleicher Puppeteer-Run)
md5 -q screenshots/claude/2026-04-19_v2.7.6_home_desktop1440_full.png
# 1011c76b3677b9dbd8d0069cc4c1c680  ← identisch
```

Wenn zwei PNG-Dateien denselben MD5-Hash haben, sind sie **bitgenau
gleich**. Kein einzelnes Pixel ist anders. Das ist der stärkste mögliche
Null-Delta-Beweis.

Bei S2.0c waren 5 von 6 Vergleichs-Shots (Home-Desktop, Home-Mobile,
Karriere × 3 Viewports) byteidentisch zur v2.7.5-Baseline vom Vortag.
Der sechste (Home-Tablet) zeigte einen 0,9 % Pixel-Drift — der sich
aber auch **ohne** S2.0c-Änderung reproduzieren ließ (externe WP-/Browser-
Schwankung zwischen Tagen). Unter **gleichen Tagesbedingungen** (neuer
Screenshot des alten CSS vs. neuer Screenshot des neuen CSS) war auch
Home-Tablet byteidentisch. Damit ist **S2.0c selbst Null-Delta**.

Mehr dazu in Tutorial 05 §5 und `DESIGN_GUIDELINES.md` §17.

---

## 8. Zusammenfassung

Der Kerngedanke des Modells ist einfach, hat aber überproportionalen
Nutzen:

| Prinzip | Nutzen |
|---------|--------|
| **Strikte Schichten** | Änderungen haben berechenbare Reichweite |
| **Namens-Entkopplung** (`--c-accent` ≠ `--color-red`) | Austausch möglich ohne Komponenten-Touch |
| **Grep-Testbarkeit** (§2.3) | Disziplinverstöße sind einzeilig erkennbar |
| **Legacy-Alias-Schicht** | Sanfte Migration ohne Regression |
| **MD5-Null-Delta als Beweis** | Sicherheit, dass „nur Struktur" wirklich „nur Struktur" war |

Das Ziel ist: **nie wieder ein Padding-Konflikt wie PXZ-E-006**, **nie
wieder „welche Tabelle gilt jetzt?"**, **nie wieder 30 Stellen ändern,
wenn sich eine Grundentscheidung ändert**.

Das Modell wird ab S2.0c für alle neuen Praxis-Komponenten und -Seiten
verbindlich. Siehe `DESIGN_GUIDELINES.md` v3.0 §2 für die formale Regel
und §17 für das Austausch-Protokoll.

---

*Stand: 2026-04-19 · Autor: Claude (S2.0c-Session) · Review: Dr. Stracke ausstehend*
