# Shopify Admin API -- Einrichtung und Nutzung

## Was lernst du hier?

Bisher konntest du mit Shopify nur zwei Dinge tun:
1. **Theme-Dateien bearbeiten** (ueber Shopify CLI: `npx shopify theme push`)
2. **Manuell im Admin klicken** (Seiten erstellen, Navigation aendern, etc.)

Mit der **Admin API** kommt ein dritter Weg dazu: Du kannst jetzt **per Befehl**
(curl, Python, Node.js) direkt mit deinem Shop kommunizieren -- Produkte anlegen,
Seiten erstellen, Bestellungen lesen, Kunden verwalten und vieles mehr.

**Analogie:** Die Shopify CLI ist wie ein Handwerker, der nur Waende streichen kann
(Theme). Die Admin API ist wie ein Generalschluessel zum ganzen Haus.

---

## Wie wurde die API eingerichtet?

### Schritt 1: App im Partners Dashboard erstellt
Im Shopify Dev Dashboard (dev.shopify.com) wurde eine neue App namens "Claude API"
erstellt. Dabei wurden festgelegt:
- **Name:** Claude API
- **Webhooks-API-Version:** 2026-04
- **Bereiche (Scopes):** Alle relevanten Lese- und Schreibrechte

### Schritt 2: Scopes konfiguriert
"Scopes" sind Berechtigungen -- sie legen fest, was die API darf. Unsere App hat:

| Scope | Bedeutung |
|-------|-----------|
| write_products | Produkte erstellen, aendern, loeschen |
| write_orders | Bestellungen lesen und verwalten |
| write_customers | Kundendaten lesen und verwalten |
| write_inventory | Lagerbestand verwalten |
| write_content | Seiten und Blog-Beitraege verwalten |
| write_themes | Theme-Dateien lesen und bearbeiten |
| write_metaobjects | Metafields und Metaobjekte verwalten |
| write_files | Dateien hochladen und verwalten |
| write_publications | Veroeffentlichungen steuern |
| write_price_rules | Preisregeln erstellen |
| write_discounts | Rabattcodes erstellen |
| write_translations | Uebersetzungen verwalten |
| write_locales | Sprach-Einstellungen verwalten |

Jeder `write_`-Scope beinhaltet automatisch auch `read_`-Rechte.

### Schritt 3: OAuth-Flow durchgefuehrt
Die App musste auf dem Shop "installiert" werden. Dafuer wurde der OAuth-Flow
durchlaufen:

1. **Autorisierungs-URL aufgerufen:**
   `https://medzpoint.myshopify.com/admin/oauth/authorize?client_id=...&scope=...&redirect_uri=...`

2. **Shopify zeigte Berechtigungsseite** -- "Diese App moechte auf folgende Daten zugreifen..."

3. **Nach Klick auf Installieren** wurde zu `sanexio.eu/auth/callback?code=XXXX` weitergeleitet.
   Die Seite zeigte 404 (normal!), aber der `code` Parameter in der URL war das Wichtige.

4. **Code gegen Token getauscht:**
   ```bash
   curl -X POST 'https://medzpoint.myshopify.com/admin/oauth/access_token' \
     -H 'Content-Type: application/json' \
     -d '{"client_id": "...", "client_secret": "...", "code": "..."}'
   ```
   Ergebnis: Ein **permanenter Access Token** (beginnt mit `shpat_...`).

### Warum so kompliziert?
Der OAuth-Flow ist ein Sicherheitsmechanismus. Er stellt sicher, dass:
- Der Shop-Besitzer (du) explizit zustimmt
- Die App nur die angefragten Berechtigungen bekommt
- Der Token nur an die registrierte Redirect-URL gesendet wird

Der Token ist **permanent** -- er laeuft nicht ab, solange die App installiert bleibt.

---

## Wie benutze ich die API?

### Grundstruktur eines API-Aufrufs

Jeder Aufruf besteht aus:
1. **URL:** `https://medzpoint.myshopify.com/admin/api/2026-04/{resource}.json`
2. **Header:** `X-Shopify-Access-Token: shpat_...`
3. **Methode:** GET (lesen), POST (erstellen), PUT (aendern), DELETE (loeschen)
4. **Body:** JSON-Daten (bei POST/PUT)

### Daten lesen (GET)

```bash
# Alle Produkte auflisten
curl -s 'https://medzpoint.myshopify.com/admin/api/2026-04/products.json' \
  -H 'X-Shopify-Access-Token: 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'

# Eine bestimmte Seite lesen (ID angeben)
curl -s 'https://medzpoint.myshopify.com/admin/api/2026-04/pages/123456789.json' \
  -H 'X-Shopify-Access-Token: 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'

# Shop-Informationen
curl -s 'https://medzpoint.myshopify.com/admin/api/2026-04/shop.json' \
  -H 'X-Shopify-Access-Token: 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'
```

### Daten erstellen (POST)

```bash
# Neue Seite erstellen
curl -s -X POST 'https://medzpoint.myshopify.com/admin/api/2026-04/pages.json' \
  -H 'X-Shopify-Access-Token: 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' \
  -H 'Content-Type: application/json' \
  -d '{
    "page": {
      "title": "Ueber uns",
      "body_html": "<p>Willkommen bei Sanexio.</p>",
      "published": true
    }
  }'

# Neues Produkt erstellen
curl -s -X POST 'https://medzpoint.myshopify.com/admin/api/2026-04/products.json' \
  -H 'X-Shopify-Access-Token: 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' \
  -H 'Content-Type: application/json' \
  -d '{
    "product": {
      "title": "Health Check Premium",
      "body_html": "<p>Unser Premium-Gesundheitscheck.</p>",
      "vendor": "Sanexio",
      "product_type": "Untersuchung",
      "status": "active"
    }
  }'
```

### Daten aendern (PUT)

```bash
# Seite aktualisieren (ID benoetigt)
curl -s -X PUT 'https://medzpoint.myshopify.com/admin/api/2026-04/pages/123456789.json' \
  -H 'X-Shopify-Access-Token: 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' \
  -H 'Content-Type: application/json' \
  -d '{
    "page": {
      "id": 123456789,
      "title": "Neuer Titel"
    }
  }'
```

### Daten loeschen (DELETE)

```bash
# Seite loeschen
curl -s -X DELETE 'https://medzpoint.myshopify.com/admin/api/2026-04/pages/123456789.json' \
  -H 'X-Shopify-Access-Token: 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'
```

---

## REST API vs. GraphQL

Shopify bietet zwei APIs:

| | REST API | GraphQL API |
|---|---------|-------------|
| **URL** | `.../api/2026-04/products.json` | `.../api/2026-04/graphql.json` |
| **Stil** | Ein Endpoint pro Ressource | Ein Endpoint fuer alles |
| **Gut fuer** | Einfache CRUD-Operationen | Komplexe Abfragen, verschachtelte Daten |
| **Beispiel** | `GET /products.json` | `{ products(first: 10) { edges { node { title }}}}` |

Fuer die meisten Aufgaben reicht die REST API. GraphQL ist noetig fuer:
- Navigation/Menues bearbeiten
- Komplexe Datenabfragen (z.B. "alle Produkte mit Metafield X")
- Bulk-Operationen

---

## CLI vs. API -- Wann was nutzen?

| Aufgabe | Tool | Warum? |
|---------|------|--------|
| Section-Liquid bearbeiten | Shopify CLI | CLI synchronisiert Theme-Dateien direkt |
| Template-JSON aendern | Shopify CLI | Template-Validierung nur ueber CLI |
| Neue Seite erstellen | Admin API | Frueher manuell, jetzt automatisierbar |
| Produkte verwalten | Admin API | Kein anderer Weg per Kommandozeile |
| Bestellungen auslesen | Admin API | Nur ueber API moeglich |
| Blog-Beitraege erstellen | Admin API | Frueher manuell, jetzt automatisierbar |
| Dateien hochladen | Admin API | Frueher manuell, jetzt automatisierbar |
| Navigation aendern | Admin API (GraphQL) | Komplexer, aber moeglich |
| Template einer Seite zuweisen | Manuell im Admin | Kein API-Endpoint verfuegbar |

---

## Rate Limits (Anfrage-Begrenzung)

Shopify erlaubt nicht unbegrenzt viele Anfragen:
- **REST API:** 40 Anfragen pro App pro Shop, 2 pro Sekunde Regeneration
- **GraphQL:** 50 Punkte pro Sekunde (einfache Queries kosten 1 Punkt)

In der Praxis wirst du diese Limits selten erreichen. Bei Bulk-Importen
(z.B. 100 Produkte anlegen) einfach ein `sleep 0.5` zwischen den Aufrufen einbauen.

---

## Sicherheit

- **Token geheim halten:** Der Access Token gibt vollen Zugriff auf den Shop.
  Niemals in oeffentliche Repos committen oder in E-Mails versenden.
- **Token rotieren:** Im Shopify Admin unter Einstellungen → Apps → Claude API
  kann der Token bei Bedarf rotiert (erneuert) werden.
- **Bei Kompromittierung:** App sofort deinstallieren (Einstellungen → Apps →
  Claude API → Deinstallieren). Dadurch wird der Token ungueltig.

---

## Zusammenfassung

| Was | Wert |
|-----|------|
| Shop-Name (intern) | medzpoint |
| Custom Domain | sanexio.eu |
| API-Basis-URL | `https://medzpoint.myshopify.com/admin/api/2026-04/` |
| Auth-Header | `X-Shopify-Access-Token: shpat_...` |
| Client-ID | `4e0490d1a394d5151f38e5115bf05b66` |
| App-Name | Claude API |
| Erstellt am | 4. April 2026 |

**Naechste Schritte:**
- In Claude Code den Prompt aus `_config/SHOPIFY_API_PROMPT.md` einfuegen
- Ausstehende Seiten (Labortests, FAQ, etc.) per API erstellen statt manuell
- Produkte fuer Health Checks per API anlegen
