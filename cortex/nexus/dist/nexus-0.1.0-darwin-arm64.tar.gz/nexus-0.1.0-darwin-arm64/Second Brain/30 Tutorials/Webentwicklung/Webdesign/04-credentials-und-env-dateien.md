# 04 — Credentials und `.env`-Dateien

> Wofür: Damit Zugangsdaten (Passwörter, API-Schlüssel, SFTP-Login) NIEMALS ins Git-Repo gelangen und dort versehentlich an Kollegen, Hoster oder die halbe Welt weitergereicht werden.

---

## Worum es geht

Jedes Web-Projekt braucht irgendwann:
- Zugang zum Hoster (SFTP-Passwort bei Domainfactory)
- Mail-Versand-Konfiguration (SMTP-Host, App-Passwort)
- API-Tokens (z. B. Google Maps, Mailjet)

Diese Daten dürfen **NIE** im Git-Repo landen, aus drei Gründen:
1. Git merkt sich alles — selbst ein gelöschter Commit bleibt im Verlauf.
2. Wenn das Repo jemals auf GitHub/Bitbucket landet, sind die Daten öffentlich.
3. Wenn ein Kollege das Repo klont, hat er deine Passwörter.

## Die `.env`-Datei als sichere Ablage

Konvention: Credentials leben in einer lokalen Datei namens `.env` (oder `.env.<zweck>.local`). Der Dateiname beginnt mit einem Punkt → sie ist „versteckt" und auf dem Mac im Finder nur mit `Cmd+Shift+.` sichtbar.

**Aufbau der Datei** — reines Text-Format, eine Zeile pro Wert:

```
SFTP_HOST=sftp.domainfactory.de
SFTP_USERNAME=dein-kundennr
SFTP_PASSWORD=SuperGeheim123
SMTP_HOST=smtp.office365.com
SMTP_APP_PASSWORD=App-Passwort-von-Microsoft
```

Keine Anführungszeichen nötig (außer bei Werten mit Leerzeichen), kein Semikolon am Ende.

## `.gitignore` — die Türsteher-Datei

Im Git-Repo liegt eine Datei `.gitignore`. Sie listet auf, was Git **nicht** beachten soll. Einmal dort eingetragen, ignoriert Git die Datei komplett — `git status` zeigt sie nicht mal mehr an.

**Standard-Einträge für `.env`-Dateien:**

```
# Credentials — never commit
.env
.env.*
!.env.*.template
```

Das bedeutet:
- Zeile 1: die Datei `.env` wird ignoriert.
- Zeile 2: alle `.env.irgendwas`-Dateien werden ignoriert (z. B. `.env.prod`, `.env.local`, `.env.sprint1.local`).
- Zeile 3: **Ausnahme von Zeile 2** — Dateien, die auf `.template` enden, dürfen ins Repo. Das Ausrufezeichen `!` ist eine Negation.

Der Trick mit der Negation erlaubt ein **Template-File** im Repo (z. B. `.env.sprint1.local.template`), das die erwarteten Feld-Namen zeigt, aber OHNE die echten Werte. Ein neuer Entwickler/Mitarbeiter kopiert das Template, füllt seine eigenen Werte ein — und die gefüllte Datei ist durch Zeile 2 wieder geschützt.

## Kontroll-Befehl

Vor dem ersten Commit einer neuen `.env`-Datei immer prüfen, ob `.gitignore` greift:

```bash
git check-ignore -v .env.sprint1.local
```

Erwartete Ausgabe:
```
.gitignore:12:.env.*    .env.sprint1.local
```
→ „Datei wird durch Zeile 12 der `.gitignore` ausgeschlossen." Kein Risiko.

Wenn stattdessen **keine** Ausgabe kommt, ist der Schutz NICHT aktiv — dann nicht committen, `.gitignore` korrigieren.

## Drei Wege, Credentials zu liefern (für Claude-Sessions)

Wenn Claude für eine Aufgabe Zugangsdaten braucht (z. B. SFTP-Login für Staging), gibt es drei Varianten:

| Variante | WAS | Sicherheit | Aufwand |
|---|---|---|---|
| **A. Chat** | Direkt in die Chat-Nachricht tippen | Landet im Session-Log (Cortex-lokal, aber existent) | Minimal |
| **B. `.env`-Datei** | In die gitignore-geschützte Datei eintragen; Claude liest sie zur Laufzeit | Bleibt auf dem eigenen Mac | Kurze Tipparbeit |
| **C. macOS Keychain** | Über `security add-generic-password` ablegen; Claude holt per Namen ab | Von macOS verschlüsselt, vom System verwaltet | Einmalige Einrichtung, technischer |

Für Einzelprojekte auf einem Entwickler-Mac ist **Variante B** meist der beste Kompromiss: sicherer als A, unkomplizierter als C.

## Merksatz

> **Credentials gehören nicht in Code, Code gehört nicht neben Credentials.**
> `.env` + `.gitignore` sind die zwei Werkzeuge, die das sauber trennen.
