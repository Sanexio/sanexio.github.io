# 12 — CSS-Spezifität & Komponenten-Schichten

> **Quelle:** Praxis-Webseite Sprint 2 / S2.0b (2026-04-19) — Komponenten-Layer
> aus `homepage.css` hochgezogen; Spezifitäts-Falle gefangen und gefixt.
>
> **Voraussetzung:** Tutorial 05 (Design-Tokens & Cascade), Tutorial 09
> (4-Schichten-Design-Tokens).

---

## Worum es geht

Wenn zwei CSS-Regeln auf dasselbe Element zeigen, muss der Browser
entscheiden: **Welche gewinnt?** Das Spiel heißt **Cascade** und hat drei
Hauptachsen, in dieser Reihenfolge:

1. **`!important`-Flag** (schlägt alles, wenn vorhanden)
2. **Spezifität** (höher = gewinnt)
3. **Quelltext-Reihenfolge** (später deklariert = gewinnt, bei gleicher Spezifität)

In der Praxis ist fast immer **Spezifität** und bei Gleichstand **Reihenfolge**
ausschlaggebend. Das klingt einfach, ist aber der Ursprung der meisten
„Warum greift meine Regel nicht?"-Bugs.

---

## 1. Spezifität berechnen (in 30 Sekunden)

Ein Selektor hat einen Wert aus drei Zahlen: **`(A, B, C)`**. Man liest das von
links nach rechts wie eine Zahl: `(1,0,0) > (0,99,0) > (0,0,99)`.

| Zähler | Zählt | Beispiele |
|---|---|---|
| **A** | IDs | `#hero`, `#fachrichtungen` |
| **B** | Klassen, Attribute, Pseudo-Klassen | `.pxz-eyebrow`, `[type=text]`, `:hover`, `:not(.foo)` |
| **C** | Element-Tags, Pseudo-Elemente | `p`, `h2`, `::before` |

### Beispiele

| Selektor | A | B | C | Summe |
|---|---|---|---|---|
| `p` | 0 | 0 | 1 | (0,0,1) |
| `.pxz-eyebrow` | 0 | 1 | 0 | (0,1,0) |
| `.pxz-home p` | 0 | 1 | 1 | (0,1,1) |
| `.pxz-home :where(p)` | 0 | 1 | 0 | (0,1,0) |
| `:where(.pxz-home) :where(p)` | 0 | 0 | 0 | (0,0,0) |
| `.pxz-home .pxz-eyebrow` | 0 | 2 | 0 | (0,2,0) |
| `#hero .pxz-eyebrow` | 1 | 1 | 0 | (1,1,0) |

**Merkregel:** Klassen zählen als 1, Tags als 1 (niedriger Rang), IDs als 1
(höchster Rang). Pseudo-Klassen (`:hover`, `:first-child`) zählen wie Klassen.

### Die beiden Sonderfälle: `:where()` und `:is()`

- **`:where(...)`** hat **immer Spezifität 0**, **egal was drinsteht**. Der Inhalt
  matcht normal, aber für die Kaskade zählt der `:where()`-Block nicht.
- **`:is(...)`** matcht gleich wie `:where()`, hat aber die **höchste Spezifität
  des stärksten Arguments**. Beispiel: `:is(#hero, .foo)` hat Spez. `(1,0,0)`.

Warum das wichtig ist: In `homepage.css` steht bewusst
```css
.pxz-home :where(p) { margin: 0; }
```
Das ist ein **Spezifitäts-neutraler Reset** — die `:where(p)` fügt keine
Spezifität hinzu. Der ganze Selektor hat also **nur die Spez der `.pxz-home`**
= `(0,1,0)`. Dahinter steht die Absicht: „klassen-basierte Regeln wie
`.pxz-eyebrow { margin-bottom: 1.25rem; }` sollen gewinnen, weil sie dieselbe
Spezifität `(0,1,0)` haben und **später** in der Datei kommen."

---

## 2. Die Reihenfolge-Regel: bei Gleichstand gewinnt der Spätere

Wenn zwei Regeln **gleiche Spezifität** haben, gewinnt die Regel, die **später**
im zusammengebauten Stylesheet erscheint. „Später" heißt hier:

1. Später im **selben File**.
2. In einem **später-geladenen File** (→ `<link>`-Reihenfolge im `<head>`).

In WordPress ist das die `wp_enqueue_style()`-Reihenfolge:

```
pxz-tokens (no deps)
blocksy-parent [pxz-tokens]
praxiszentrum [blocksy-parent]
pxz-components [praxiszentrum]          ← seit S2.0b
pxz-homepage [pxz-components]            ← lädt später
```

Dieses Modell macht aus der Regel „später gewinnt" eine
**Kaskaden-Disziplin**: Was ich in einer später-geladenen Datei schreibe,
überschreibt gleichspezifische Regeln in früher-geladenen Dateien.

---

## 3. Das Praxis-Problem aus S2.0b (Cliffhanger)

Vor S2.0b standen **beide** Regeln in derselben Datei (`homepage.css`):

```css
/* Zeile 51 */  .pxz-home :where(p) { margin: 0; }         /* Spez (0,1,0) */
/* Zeile 70 */  .pxz-eyebrow { margin-bottom: 1.25rem; }   /* Spez (0,1,0) */
```

Gleiche Spez, `.pxz-eyebrow` kommt später in der Datei → **`.pxz-eyebrow`
gewinnt** → Eyebrow bekommt `margin-bottom: 20px`. Alles in Ordnung.

In S2.0b haben wir `.pxz-eyebrow` nach `components.css` hochgezogen, weil es
eine generische Komponente ist, die auch auf Karriere und den Skelett-Templates
funktionieren soll. Die Enqueue-Reihenfolge sieht dann so aus:

```
pxz-components    ← hier lebt jetzt .pxz-eyebrow { margin-bottom: 1.25rem; }
↓ lädt vor
pxz-homepage      ← hier lebt weiterhin .pxz-home :where(p) { margin: 0; }
```

**Oh nein.** Beide Regeln haben immer noch Spez `(0,1,0)`, aber jetzt ist der
Reset aus `homepage.css` die **später geladene** — **der Reset gewinnt**.
Eyebrow bekommt `margin-bottom: 0` (nicht 20px) — Dokument wird 20 px kürzer.

Puppeteer-Screenshots zeigten das als MD5-Delta und 108 px Höhen-Verlust auf
der Homepage (weil das Problem mehrfach vorkommt: `.pxz-eyebrow` und
`.pxz-sect-intro` sind beide betroffen).

Das ist **FK-3 Plausible Scheinlösung:** die `computed-style`-Probe für die
tatsächlich geprüften Selektoren sah richtig aus. Der Bug saß in **nicht
gemessenen Selektoren** (`.pxz-eyebrow` stand nicht in der `verify.sh`-Probe).

---

## 4. Zwei saubere Fixes (und warum wir den einen gewählt haben)

### Fix A (empfohlen) — Page-scoped Override mit erhöhter Spezifität

In `homepage.css` nach der Reset-Regel eine spezifitäts-erhöhte Override-Regel
ergänzen:

```css
.pxz-home :where(p) { margin: 0; }              /* Spez (0,1,0), Reset */
.pxz-home .pxz-eyebrow { margin-bottom: 1.25rem; }   /* Spez (0,2,0), gewinnt */
.pxz-home .pxz-sect-intro { margin-top: 1.75rem; }   /* Spez (0,2,0), gewinnt */
```

**Warum gut:**
- Spez `(0,2,0)` schlägt Reset `(0,1,0)` zuverlässig, unabhängig von
  Ladereihenfolge.
- Die Regel ist **page-spezifisch** (`.pxz-home`), matcht also nur auf Home
  und stört Karriere / Skelett-Templates nicht.
- Off-Home-Pages nutzen die generische `components.css`-Version direkt —
  dort ist der Reset nicht aktiv (Karriere hat keinen `.pxz-home`-Wrapper).

### Fix B (nicht gewählt) — Reset vollständig auf Spez `(0,0,0)`

```css
:where(.pxz-home) :where(p) { margin: 0; }  /* Spez (0,0,0) */
```

**Warum nicht gewählt:** Nebenwirkung. Alle `<p>`-Elemente in `.pxz-home` ohne
eigenen Class-Override bekommen jetzt **Browser-Default-Margin (ca. 17 px top
+ 17 px bottom)**. Die Seite wird länger. Das haben wir in der Debug-Phase
empirisch beobachtet: Home war nach Fix B **+138 px hoch**.

Fix B ist unelegant, weil er Defaults für Elemente freischaltet, die nicht das
eigentliche Problem sind.

### Die Regel, die sich aus S2.0b ableitet

**Wenn du eine generische Klassen-Regel in eine früher-geladene Kaskaden-Datei
hochziehst, prüfe alle gleich-spezifischen Resets in der aufrufenden Datei.**
Ergänze bei Bedarf einen **page-scope Override mit erhöhter Spezifität**.

---

## 5. Das 4-Schichten-Modell und seine Kaskaden-Logik

Wir nutzen seit S2.0c ein **4-Schichten-Design-Token-Modell** (siehe
Tutorial 09). Seit S2.0b steht Schicht 3 scharfgestellt. Die Schichten sind
**keine Spezifitäts-Schichten**, sondern **Lade-Schichten**:

| Schicht | Datei | Rolle | Typisches Regel-Niveau |
|---|---|---|---|
| 1 Primitives | `tokens.css` | Harte Werte (Hex, px) unter `:root` | custom properties |
| 2 Semantic | `tokens.css` | Bedeutungs-Aliase unter `:root` | custom properties |
| 3 Components | `components.css` | `.pxz-btn`, `.pxz-card`, `.pxz-eyebrow` | Spez (0,1,0) |
| 4 Pages | `homepage.css`, `karriere.css` | page-spezifisch, komponiert | Spez (0,1,0) bis (0,2,0) |

Schicht 3 lädt **vor** Schicht 4. Das bedeutet: **Page-CSS kann Komponenten-CSS
überschreiben** (Erweiterung/Anpassung pro Seite), aber **Komponenten-CSS kann
Page-CSS nicht überschreiben**.

Die Folge: Page-CSS braucht manchmal einen expliziten Page-scope-Override
(Fix A oben), um gleich-spezifische Kämpfe zu gewinnen. Das ist **keine
Architektur-Hässlichkeit**, sondern die **absichtliche Richtung der Kaskade**:
spezifischere Seite > generische Komponente.

---

## 6. Wann schreibe ich `.pxz-foo` vs `.pxz-home .pxz-foo`?

Richtwert für das Tageskundenspiel beim Refactor:

- **`.pxz-foo`** — generische Komponenten-Regel in `components.css`.
  Gilt überall. Spez (0,1,0).
- **`.pxz-home .pxz-foo`** — page-spezifische Override in `homepage.css`.
  Gilt nur auf Home. Spez (0,2,0). Benutze nur wenn:
  1. Der Wert sich bewusst nur auf Home unterscheiden soll (z. B. weil Home
     eine Showpiece-Sektion hat, die größeres Padding braucht), **oder**
  2. Ein Reset in derselben Datei die generische Regel sonst überschreibt
     (der Fall aus S2.0b-LL-1).
- **`#irgendeine-id .pxz-foo`** — IDs sind zu hoch spezifiziert (1,1,0) und
  schlecht wiederverwendbar. **Vermeide IDs in CSS-Selektoren**.
- **`!important`** — letztes Mittel. Benutze es nur, wenn eine externe
  Library (Blocksy, Plugin-CSS) sonst nicht besiegbar ist, und dokumentiere
  den Grund in einem Kommentar.

---

## 7. Debug-Werkzeuge

Wenn du wissen willst, welche Regel **tatsächlich** gewonnen hat:

### Chrome DevTools (sichtbarer)
- F12 → Element inspizieren → Rechts **„Styles"**-Panel
- Durchgestrichene Regeln = von stärkeren geschlagen
- Filter-Feld am oberen Rand: zeigt nur Regeln mit einem Property

### Puppeteer-Probe (automatisiert, für CI / verify.sh)
```js
page.evaluate(sel => {
  const el = document.querySelector(sel);
  return el ? getComputedStyle(el).marginBottom : null;
}, '.pxz-eyebrow');
```

### Nur die Spezifität wissen wollen?
[https://specificity.keegan.st/](https://specificity.keegan.st/) — eintragen,
fertig.

---

## 8. Take-Aways

1. **Spezifität ist eine Zahl (A, B, C).** IDs > Klassen/Attribute/Pseudo-Klassen
   > Tags.
2. **`:where()` hat Spez (0,0,0).** Nutze es für Resets, die von Class-Regeln
   geschlagen werden sollen. Aber: nur innerhalb derselben Datei verlässlich.
3. **Bei Gleichstand gewinnt der Spätere** (in Datei oder Ladereihenfolge).
   Wenn du class-Regeln in eine früher-geladene Datei verschiebst, kann eine
   gleich-spezifische Reset-Regel in der später-geladenen Datei plötzlich
   gewinnen.
4. **Page-scope Overrides** (Spez +1 Klasse, z. B. `.pxz-home .pxz-eyebrow`)
   sind der saubere Ausweg — page-spezifisch, vorhersehbar, minimal-invasiv.
5. **`computed-style`-Proben alleine reichen nicht**, um Refactors zu
   verifizieren. Ergänze Dimensions-Diff (`scrollHeight`, `offsetHeight` pro
   Section), um Spezifitäts-Kollisionen zu entdecken, die nur wenige Pixel
   pro Element kosten.

---

## Querverweise

- Tutorial 05 — Design-Tokens & Cascade
- Tutorial 09 — 4-Schichten-Design-Tokens
- Pattern `css-layer3-promotion.md` — 6-Schritte-Protokoll für Komponenten-
  Extraktion mit Kaskaden-Disziplin
- Pattern `design-token-ssot.md` — Token-Quelle, aus dem Schicht 1+2 leben
- Spec `S2.0b_component-library.md` — der konkrete Refactor, der dieses
  Tutorial veranlasst hat

---

*Angelegt 2026-04-19 (Cortex-Web Session 11, praxis-webseite S2.0b). Eingebettet
als Lektion aus S2.0b-LL-1 (In-Session-Fix) und S2.0b-LL-3 (Cross-Page-
Contamination bei Klassen-Promotion).*
