# 3D-Avatare in Shopify — Claude-Workflow

> So bitten Sie Claude, einen rotierbaren 3D-Avatar in Ihre Shopify-Seite
> einzubauen. Claude erledigt Avatar-Beschaffung, Blender-Pipeline,
> Section-Bau, Push und Verifikation in einem Rutsch.

---

## Was Sie sagen

> "Bau mir auf der Seite [SEITE] eine Hero-Section mit zwei rotierbaren
> 3D-Avataren — einer krank, einer gesund, identisches Gesicht, mit
> diesen Diagnosen: [Liste]. Mixamo als Quelle, später migrierbar zu Avaturn."

Das reicht. Claude macht den Rest.

---

## Was Claude automatisch tut

### Phase 1 — Voraussetzungen prüfen
1. Liest `_memory/MEMORY.md`, `_rules/GLOBAL_RULES.md`,
   `projects/Juvantis/_config/RULES.md`
2. Prüft, ob Blender installiert ist (`/Applications/Blender.app`)
3. Prüft, ob Node + npm + curl verfügbar sind
4. Prüft, ob das Theme-Verzeichnis existiert (`website/theme/`)

### Phase 2 — Lizenz klären
1. Recherchiert die Quelle (Mixamo / RPM / Avaturn) und deren Lizenz
2. Bei kommerzieller Unsicherheit: STOPPT und fragt
3. Bei freier Lizenz (z.B. Mixamo via three.js examples): macht weiter

### Phase 3 — Avatar beschaffen
1. Lädt eine GLB-Basis per `curl` aus einem öffentlichen Repository
   (z.B. `Soldier.glb` aus dem mrdoob/three.js Repo)
2. Verifiziert Größe + glTF-Header
3. Inspiziert die Mesh-Struktur mit `npx @gltf-transform/cli inspect`
4. Identifiziert: welches Mesh ist Body, welches ist Helm/Visor

### Phase 4 — Blender-Pipeline (headless)
1. Schreibt ein Python-Script
   (`projects/Juvantis/DHT/juvantis-ios/Blender/scripts/build_avatar_variants.py`)
2. Das Script:
   - Lädt das Basis-GLB
   - Entfernt das Visor/Helm-Mesh
   - Berechnet den Hals-Y-Wert (Hard-Guard für das Gesicht)
   - Verformt Bauch- und Flanken-Vertices via Gauß-Falloff
   - Wendet einen subtilen Yellow-Skin-Tint auf die Materialien an
   - Exportiert zwei separate GLBs (`avatar_healthy.glb`, `avatar_sick.glb`)
3. Führt Blender im Hintergrund aus:
   ```
   /Applications/Blender.app/Contents/MacOS/Blender \
     --background --python build_avatar_variants.py -- \
     --base /pfad/zu/avatar_base.glb \
     --out  /pfad/zu/exports
   ```
4. Verifiziert via MD5, dass beide GLBs unterschiedliche Inhalte haben

### Phase 5 — Section bauen
1. Schreibt `sections/dht-avatar-compare.liquid` mit:
   - `<model-viewer>`-Komponente von Google (Apache 2.0)
   - Apple-Style passend zur bestehenden DHT-Page
   - Brand-Farben Teal (#028090, #00A896, #02C39A)
   - Desktop: zwei Viewer nebeneinander
   - Mobile (< 768 px): ein Viewer mit Toggle
   - Diagnose- und Normwert-Badges
   - Disclaimer + Avatar-Credit
   - Schema mit URL-Override-Feldern für spätere Migration
2. Schema-Name max 25 Zeichen (Shopify-Limit beachten)

### Phase 6 — Template integrieren
1. Aktualisiert `templates/page.[seite].json`
2. Fügt die neue Section als ERSTE sichtbare Section ein
3. Erweitert das `order`-Array in der korrekten Reihenfolge

### Phase 7 — Push (R-013: Section + Template + Assets zusammen)
1. Manueller CLI-Push (kein Hook, weil Hook nur Edits triggert):
   ```
   npx shopify theme push --store [store] --theme [id] --allow-live \
     --only sections/dht-avatar-compare.liquid \
     --only assets/avatar_healthy.glb \
     --only assets/avatar_sick.glb \
     --only templates/page.[seite].json
   ```
2. Bei Fehler "name ist zu lang": Schema-Name kürzen, retry

### Phase 8 — Git
1. `git add` der vier Dateien (Section, Template, beide GLBs)
2. `git commit` mit klarer Message
3. `git push origin shopify-theme`
4. Bei Push-Reject (Shopify Auto-Sync hat schon Section + Template auf
   GitHub gepusht): rebase, dann nur die GLBs committen

### Phase 9 — Funktionstest (LL-021)
1. `curl https://[domain]/pages/[seite]` und prüft:
   - HTTP 200
   - Section-CSS-Klassen rendern
   - Beide `<model-viewer>`-Tags vorhanden
   - Alle Texte (Headline, Toggle, Badges, Disclaimer)
   - Section-Position korrekt (`shopify-section-template-...__dht_compare`)
2. `curl -I https://[cdn]/avatar_*.glb` und prüft:
   - HTTP 200
   - `Content-Type: model/gltf-binary`
3. Verbleibende visuelle Tests dokumentiert für Sie zur Sichtprüfung

### Phase 10 — Doku
1. `_tutorials/shopify/03-3d-avatare-in-shopify*.md` (Drei-Dateien-Regel)
2. `projects/Juvantis/DHT/AVATAR_SOURCES.md` mit Lizenzdetails
3. `projects/Juvantis/DHT/KONZEPT_AVATAR_PIPELINE.md` ergänzt
4. `_memory/logs/YYYY-MM-DD_dht-avatar-prototyp.md` Session-Log

---

## Was Sie danach noch machen müssen

1. **Visuelle Sichtprüfung im Browser** (Desktop + Mobile)
2. Optional: Avatar später durch Avaturn-Version austauschen (Theme-Editor)
3. Falls Sie eine andere Quelle wollen (z.B. Ready Player Me Partner):
   Account anlegen, dann Claude Bescheid geben

Claude kann jeden dieser Schritte später automatisieren — der Code ist
modular aufgebaut.

---

## Voraussetzungen, die Claude automatisch prüft

| Tool | Wofür | Pflicht |
|---|---|---|
| Blender 4.x | Headless Mesh-Verformung | Ja |
| Node v22 | npx, gltf-transform, shopify CLI | Ja |
| curl | Avatar-Download, Live-Verifikation | Ja |
| nvm | Node-Version-Switch | Ja |
| git | Versionierung | Ja |
| `~/.nvm/nvm.sh` | Vor jedem `npx shopify` (R-008) | Ja |

Fehlt etwas, sagt Claude Bescheid und schlägt die Installation vor.

---

## Beispielhafte Begriffe für die Anfrage an Claude

> "Bau auf der Seite Digital Health Twin oben eine Hero-Section mit zwei
> rotierbaren 3D-Avataren. Der kranke hat Adipositas (BMI 34), Steatosis
> hepatis und Diabetes Typ 2 (HbA1c 8,4 %). Der gesunde ist normalgewichtig
> (BMI 23), unauffällige Leber, HbA1c 5,4 %. Brand-Teal, Disclaimer
> 'kein Medizinprodukt', Migration zu Avaturn vorbereitet."

Das ist alles.

---

*Tutorial erstellt: 2026-04-07*
