---
type: tutorial
category: webdesign
order: 34
prerequisites: [30, 32]
scope: hybrid
projects: [praxis-webseite]
goal: "Verstehen, warum Design-Tokens das Cascade-Drift-Problem lösen, und wie zwei Token-Schichten Farb-Wechsel pro Kontext erlauben."
---

# 05 — Design-Tokens und Cascade: eine zentrale Farbquelle

## Allgemeiner Teil

### Das Drift-Problem

Farben tauchen auf einer Website an vielen Stellen auf: in Logos, Buttons,
Borderlines, Texten. Ohne Disziplin schreibt jede CSS-Datei ihre eigenen
Farbwerte:

```css
/* style.css — erstellt in Woche 1 */
.foo { color: #C8161D; }

/* homepage.css — erstellt in Woche 3 */
.bar { background: #C8161D; }

/* karriere.css — erstellt in Woche 5 */
.baz { border: 1px solid #C8161D; }
```

**Der Ärger kommt später.** Wenn Sie das Rot in Woche 10 minimal dunkler
setzen wollen, müssen Sie alle drei Dateien gleichzeitig ändern. Wird eine
vergessen, sieht eine Seite minimal anders aus — und niemand merkt es,
bis es ein Kunde reklamiert. Dieser Drift ist die häufigste Quelle für
unsichtbare Design-Inkonsistenzen.

### Die Lösung: CSS Custom Properties als „Design-Tokens"

Browser verstehen seit langem **Custom Properties** (`--name: wert;`), die
sich wie Variablen verhalten. Auf `:root` deklariert, sind sie überall
verfügbar:

```css
:root {
  --brand-red: #C8161D;
}

.foo { color: var(--brand-red); }
.bar { background: var(--brand-red); }
.baz { border: 1px solid var(--brand-red); }
```

Eine Änderung an `:root` wirkt überall. Das ist der Kern-Sinn von Design-
Tokens: **eine einzige Quelle der Wahrheit (SSoT)** für jeden Designwert
(Farbe, Schriftgröße, Rundung, Spacing).

### Zwei Schichten statt einer

In der Praxis reicht eine Schicht nicht. Die Homepage nutzt Rot als Akzent,
eine Karriere-Sektion vielleicht Gelb. Lösung: **zwei Schichten.**

**Schicht 1 — Primitives** (neutrale Namen, keine Rolle):

```css
:root {
  --c-red:   #C8161D;
  --c-amber: #F5B800;
  --c-ink:   #1D1D1F;
  --c-white: #FFFFFF;
}
```

**Schicht 2 — Semantic** (rollenbasiert, referenziert Schicht 1):

```css
:root {
  --bg:     var(--c-white);
  --text:   var(--c-ink);
  --accent: var(--c-red);
}
```

Wird `--c-red` jemals geändert, ziehen alle Stellen mit `--accent` automatisch nach. Designer denken in Rollen (`accent`, `bg`), nicht in Hex-Werten — und die Rolle steckt in einer einzigen Zeile.

### Scope-Override: Sektion-Theming ohne Extra-Datei

Eine Karriere-Sektion soll dunkel sein und Gelb als Akzent nutzen. Statt
eine neue CSS-Datei anzulegen, überschreiben wir Schicht 2 lokal:

```css
.karriere {
  --bg:     var(--c-ink);
  --text:   #FFFFFF;
  --accent: var(--c-amber);
}
```

**Trick:** Custom Properties **vererben durch den DOM-Subtree**. Ein
`<button class="accent-btn">` innerhalb von `.karriere` liest automatisch
das gelbe `--accent`. In `.homepage` wäre derselbe Button rot — derselbe
HTML-Code, unterschiedlicher Scope. Keine doppelten Button-Regeln.

### Die Cascade-Falle: Lade-Reihenfolge

Damit `:root`-Tokens wirklich „zuerst da" sind, muss die `tokens.css`
**vor** allen Consumer-Stylesheets geladen werden. Das ist nicht egal —
wenn `style.css` zuerst lädt, stehen `var(--accent)`-Werte beim ersten
Berechnen noch nicht zur Verfügung, und der Browser muss sie nachziehen
(was sichtbares Flackern oder schlicht falsche Farben bedeuten kann).

Drei Optionen, das zu garantieren:
1. `<link rel="stylesheet">` in der gewünschten Reihenfolge im HTML.
2. CMS- oder Build-Tool-Dependency-Mechanismen (z. B. WordPress Enqueue, Webpack-Imports, Vite-Manifest).
3. Ein `@import "tokens.css";` als allererste Zeile aller anderen CSS-Dateien — funktioniert, ist aber ein Performance-Anti-Pattern (zusätzliche Roundtrips).

### Verifikation: Beweisbar identisch nach Refactor

Wenn Sie ein Design-System neu strukturieren, müssen Sie beweisen, dass das Ergebnis pixelgleich aussieht. Zwei Methoden:

- **Visueller Diff** mit Tools wie BackstopJS oder Percy. Toleranz-Schwelle nötig — das Auge übersieht 1-px-Drift, das Tool diskutierbar.
- **Byte-Vergleich** der Headless-Browser-Screenshots (Puppeteer, Playwright, identischer DOM/Viewport): MD5-Summe identisch = jede Pixelposition identisch. Stärkster Beweis, weil keine Toleranz.

### Zusammenfassung der Allgemein-Lehre

1. **Eine Quelle pro Designwert** — `:root` mit Custom Properties.
2. **Zwei Schichten** — Primitives (Hex-Werte) + Semantic (Rollen, referenzieren Primitives).
3. **Scope-Overrides** statt Extra-Dateien — DOM-Vererbung macht den Rest.
4. **Lade-Reihenfolge absichern** — Tokens vor Consumer-Stylesheets.
5. **Byte-Vergleich** als Null-Delta-Beweis nach Refactor.

---

## Projektspezifisch: praxis-webseite

> Erstanwendung dieses Patterns: Sprint 2 / S2.0 des Praxis-Redesign,
> Theme-Version 2.7.4 → 2.7.5, 18.04.2026.

### Konkreter Namespace und Dateistruktur

Das Praxis-Theme nutzt das Präfix `--pxz-*`, um Kollisionen mit dem
Blocksy-Parent-Theme zu vermeiden:

```css
/* themes/praxiszentrum/assets/css/tokens.css */
:root {
  --pxz-red:   #C8161D;
  --pxz-amber: #F5B800;
  --pxz-ink:   #1D1D1F;
  --pxz-white: #FFFFFF;
}

:root {
  --pxz-bg:     var(--pxz-white);
  --pxz-text:   var(--pxz-ink);
  --pxz-accent: var(--pxz-red);
}
```

Sektion-Overrides leben in der jeweiligen Sektions-CSS, **nicht** in
`tokens.css`:

```css
/* themes/praxiszentrum/assets/css/karriere.css */
.pxz-kar {
  --pxz-bg:     var(--pxz-ink);
  --pxz-text:   #FFFFFF;
  --pxz-accent: var(--pxz-amber);
}
```

### WordPress Enqueue-Dependency-Kette

Lade-Reihenfolge per `wp_enqueue_style` mit Dependency-Array:

```php
wp_enqueue_style(
    'pxz-tokens',
    PXZ_URI . '/assets/css/tokens.css',
    [],                           /* keine Abhängigkeiten */
    PXZ_VERSION
);
wp_enqueue_style(
    'blocksy-parent',
    get_template_directory_uri() . '/style.css',
    [ 'pxz-tokens' ],             /* hängt an pxz-tokens */
    PXZ_VERSION
);
wp_enqueue_style(
    'praxiszentrum',
    get_stylesheet_uri(),
    [ 'blocksy-parent' ],
    PXZ_VERSION
);
if ( is_page_template( 'template-homepage.php' ) ) {
    wp_enqueue_style(
        'pxz-homepage',
        PXZ_URI . '/assets/css/homepage.css',
        [ 'praxiszentrum' ],
        PXZ_VERSION
    );
}
```

Der dritte Parameter sagt WordPress: „Lade erst die Abhängigkeit, dann
diese Datei." WordPress sortiert die `<link>`-Tags entsprechend.

### Verifikation in unserer Pipeline

Die Praxis-Seite nutzt **Puppeteer im Headless-Inkognito-Modus** für
byte-stabile Screenshots:

```bash
md5 screenshots/2026-04-18_v2.7.5_home_desktop1440_full.png
md5 screenshots/2026-04-18_v2.7.3_home_desktop1440_full.png
```

Identische MD5 → mathematischer Null-Delta-Beweis. Das ist die
Standard-Verifikation für jede CSS-Refactor-Aktion am Theme.

### Lerneffekt aus dem Sprint

- **PXZ-E-001** (Split-Location-CSS) wurde durch genau dieses Tokens-Pattern eliminiert: bevor die Konsolidierung kam, lag das `--pxz-red` an drei verschiedenen Orten und drifftete.
- **PXZ-E-008** (Spezifitäts-Konflikt globaler Resets) trat auf, als ein `.pxz-home p { … }`-Reset Token-Werte auf Paragrahphen überschrieb. Lösung: `.pxz-home :where(p) { … }` (siehe Tutorial [[09-css-spezifitaet-und-komponenten-schichten]]).
- **MD5-Verify-Pflicht** seit S2.0: keine CSS-Änderung gilt als „fertig", bevor der Byte-Vergleich grün ist.

### Verweise im Projekt

- **Spec:** `projects/Cortex-Web/sites/praxis-webseite/specs/sprint-2/S2.0_tokens.md` (v2.7.5)
- **Folge-Spec:** `S2.0c_design-system-consolidation.md` (v2.7.6, 4-Schicht-Erweiterung — siehe Tutorial [[06-vier-schichten-design-tokens]])
- **Pattern:** `Nexus/_memory/patterns/design-token-ssot.md`
- **Design-Guidelines:** `projects/Cortex-Web/sites/praxis-webseite/DESIGN_GUIDELINES.md` v3.0 §2, §17
- **Fehlerprotokoll:** `_rules/FEHLERPROTOKOLL.md` PXZ-E-001, PXZ-E-008

---

## Verwandte Tutorials

- Voraussetzung: [[03-inline-css-zu-externer-datei]] (`order: 30`) — ohne Extraktion kein sinnvoller SSoT
- Voraussetzung: [[09-css-spezifitaet-und-komponenten-schichten]] (`order: 32`) — verstehen, welche Regel gewinnt
- Aufbau: [[06-vier-schichten-design-tokens]] (`order: 36`) — Skalierung auf vier Schichten
- Lernpfad: [[LERNPFAD]]

*Angelegt: 2026-04-18 nach Abschluss S2.0 v2.7.5. Refaktoriert: 2026-04-25 (Pilot-Phase 2-Sektionen-Format).*
