---
title: Rollback via Git-Tag — Live-Site sicher zurücksetzen
domain: Webdesign
created: 2026-05-08
context: Praxis-Webseite (Cortex-Web), Modell A (Local = Master)
related:
  - 13-local-master-staging-prod-pipeline.md
  - 04-credentials-und-env-dateien.md
---

# Rollback via Git-Tag — Live-Site sicher zurücksetzen

> **Wann brauche ich das?** Wenn nach einem Deploy auf
> `westend-hausarzt.de` (Staging) oder später `westend-hausarzt.com`
> (Production) ein Bug auftritt, den ich schnell rückgängig machen will,
> ohne im Chaos zu suchen, was ich geändert habe.

## Was ist ein Git-Tag?

Ein Git-Tag ist ein **fester Zeiger** auf genau einen Commit. Während
ein Branch wandert (jeder neue Commit verschiebt ihn), bleibt ein Tag
auf seinem Commit kleben. Damit ist er ideal als „Hier war alles in
Ordnung"-Marker.

In unserem Setup nutzen wir Tags so:

| Tag-Name | Bedeutung |
|---|---|
| `live-de-2026-05-08-01` | Stand, der am 08. Mai 2026 als 1. Push grün auf `.de` ging |
| `live-de-2026-05-08-02` | 2. Push am gleichen Tag, ebenfalls grün verifiziert |
| `live-com-2026-06-15-01` | (geplant) 1. Stand auf `.com` nach Cutover |
| `live-de-2026-05-09-rollback` | Stand, auf den nach einem Bug zurückgesetzt wurde |

## Schritt für Schritt — Rollback Theme

**Annahme:** Auf `.de` ist nach dem letzten Sync ein Layout-Bug aufgetreten.
Letzter grüner Tag: `live-de-2026-05-08-01`.

### 1. Letzten grünen Tag finden

```bash
cd "/Users/cluster-mini-02/Local Sites/gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604/app/public/wp-content/themes/praxiszentrum"
git tag --list 'live-de-*' | sort | tail -5
```

Beispiel-Ausgabe:
```
live-de-2026-05-07-01
live-de-2026-05-07-02
live-de-2026-05-08-01     ← der will ich zurück
live-de-2026-05-08-02     ← hier kam der Bug rein
```

### 2. Theme lokal auf den grünen Stand setzen

**Wichtig:** Niemals direkt auf dem Server zurücksetzen. Immer den Umweg
über Local nehmen, damit der Stand reproduzierbar bleibt.

```bash
git checkout live-de-2026-05-08-01 -- .
```

Der Punkt am Ende ist wichtig: er sagt „setze alle Dateien aus dem
gegebenen Tag in mein Working-Directory". `HEAD` bleibt auf
`main` — wir machen keinen detached-checkout, wir holen nur Inhalte.

### 3. PXZ_VERSION bumpen (Cache-Buster)

Browser cachen CSS/JS hart. Damit der Rollback-Stand auch wirklich
sichtbar wird, `functions.php` öffnen und die `PXZ_VERSION` hochzählen:

```php
// vorher: define('PXZ_VERSION', '2.7.180');  ← der Bug-Stand
define('PXZ_VERSION', '2.7.181');             // ← +1 trotz Rollback
```

### 4. Verify auf Local

```bash
# WP-CLI mit Socket-Override (siehe Theme-README)
"$PHP" -d mysqli.default_socket="$SOCK" "$PHAR" --path="$SITE" cache flush

# In LocalWP-Browser: Homepage + 2-3 Detail-Pages anschauen
open "https://gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604.local/"
```

### 5. Sync auf `.de`

```bash
cd ~/Cortex/projects/Cortex-Web/sites/praxis-webseite
bash tools/sync-local-to-de.sh --theme --verify
```

Das Skript pusht das Theme auf `.de` und führt die Pre-Launch-Verify-Suite
aus (21 Checks). Wenn alle 21 grün sind, ist der Rollback erfolgreich.

### 6. Forward-Tag setzen — Rollback dokumentieren

```bash
cd "/Users/cluster-mini-02/Local Sites/gpmedicalcenterwestend-.../wp-content/themes/praxiszentrum"
git add -A
git commit -m "rollback(theme): zurück auf live-de-2026-05-08-01 wegen Layout-Bug auf $(date +%F)"
git tag "live-de-$(date +%Y-%m-%d)-rollback"
git push origin main --tags
```

Jetzt steht in der Tag-Historie sichtbar: hier war ein Rollback. Das
ist wichtig, damit beim nächsten Stand-Vergleich klar ist, dass der
Sprung von `2.7.180` zurück auf `2.7.181`-mit-altem-Inhalt **kein**
Versionsfehler ist, sondern ein bewusster Reset.

## Rollback inklusive Datenbank

Wenn nicht nur das Theme defekt ist, sondern auch DB-Inhalt verändert
wurde (z. B. eine WPML-Migration ist schiefgelaufen), brauchst du
zusätzlich einen DB-Snapshot. Diese liegen unter
`~/Cortex/projects/Cortex-Web/sites/praxis-webseite/_backups/` (lokal,
git-ignoriert) und werden vor jeder destruktiven DB-Op manuell
angelegt.

```bash
# DB-Snapshot finden (sortiert nach Datum)
ls -lt ~/Cortex/projects/Cortex-Web/sites/praxis-webseite/_backups/ | head

# Snapshot lokal in LocalWP zurückspielen
"$PHP" -d mysqli.default_socket="$SOCK" "$PHAR" --path="$SITE" \
       db import _backups/snapshot-2026-05-08.sql

# Auf .de via import-db.php (Welle-F-Tooling) oder phpMyAdmin
```

## Was Rollback NICHT abdeckt

- **Plugin-Updates** mit Datenmigration (z. B. WPML 5 → 6): hier
  schreibt das Plugin eigene DB-Tabellen um, ein Code-Rollback alleine
  reicht nicht. Lösung: Plugin-Versionen mitloggen,
  Plugin-Downgrade + DB-Restore aus Snapshot.
- **WP-Core-Updates**: nicht im Theme-Repo. Bei kritischen Core-Updates
  vorher manuellen Tarball auf dem Server speichern.
- **Uploads** (Mediathek-Bilder): nicht im Repo. Wenn ein Bild
  überschrieben wurde, braucht es ein Server-Backup oder ein neues
  Upload.

## Pattern hinter dem Tutorial

**Disziplin > Tooling.** Tags sind nur dann ein Rollback-Anker, wenn sie
zuverlässig gesetzt werden. Die Reihenfolge ist:

```
Local-Edit → Git-Push → lftp-Sync → Verify → Tag (nur wenn verify=grün)
```

Wer den Tag vor dem Verify setzt, hat keinen Anker, sondern ein
falsches Sicherheits-Gefühl. Wer den Tag erst gar nicht setzt, hat
keinen Anker, sondern hofft, dass nichts schiefgeht. Beides ist
in diesem Setup nicht akzeptabel.

## Verwandte Tutorials

- [13 — Local-Master / Staging / Prod Pipeline](13-local-master-staging-prod-pipeline.md) — Modell A im Detail
- [04 — Credentials und .env-Dateien](04-credentials-und-env-dateien.md) — wie Push-Credentials sicher liegen
