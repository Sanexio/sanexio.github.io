---
tags: [tutorial, webentwicklung, claude-workflow, web-pilot]
---

# Web-Pilot — Claude-Workflow

So benutzt Claude den Web-Pilot in einer Session, wenn du eine Web-App-Frage hast.

## Was du Claude sagst

Sätze wie:
- „Schau dir mal die Shopify-Section X an — wo ändere ich Y?"
- „Auf der Praxis-Webseite live ist da ein Layout-Problem — guck mal nach"
- „Hilf mir auf der Grafana-Oberfläche, ich finde den Filter nicht"

## Was Claude dann tut

Je nach Modus:

### Modus C (Headless, ohne deinen Chrome)

```bash
cd ~/Cortex/Nexus/tools/web-pilot
./bin/web-pilot start
./bin/web-pilot use headless
./bin/web-pilot open https://westend-hausarzt.com
./bin/web-pilot dom --text-only          # Claude liest den Inhalt
./bin/web-pilot screenshot --out /tmp/page.png   # Claude sieht das Bild
```

### Modus D (auf deinem Chrome mitfahren)

Voraussetzung: du hast den Web-Pilot-Chrome mit `bin/start-chrome-debug.sh`
gestartet und bist eingeloggt, wo du es brauchst.

```bash
./bin/web-pilot start
./bin/web-pilot connect-chrome
./bin/web-pilot tabs --pretty            # Claude sieht alle deine Tabs
./bin/web-pilot tab tab-3                # auf den richtigen wechseln
./bin/web-pilot dom --text-only          # liest das, was du siehst
```

## Wenn ein Login-Schritt nötig ist

Web-Pilot stoppt mit klarer Meldung:

```
FAIL: fill blocked: selector targets a password field — Web-Pilot never enters passwords
hint: log in manually in the browser, then re-issue the next command
```

Du loggst dich im Chrome-Tab manuell ein. Claude wartet, du sagst „weiter",
Claude führt den nächsten Befehl aus.

## Was Claude dir liefert

Drei typische Antworten:

1. **„Klick hier":** Claude beschreibt dir präzise, wo der Button ist (Selector + Lage).
2. **„Ich klicke das jetzt":** Claude führt `./bin/web-pilot click "<selector>"` aus.
3. **„Hier ist ein Screenshot":** Claude legt dir das Bild ab (`/tmp/page.png`) oder beschreibt es.

## Was Claude NICHT tut

- Passwörter eingeben (hartes No-Go, beide Modi).
- Snapshots von Login-Seiten persistieren.
- Tokens, Cookies oder Auth-Header in Logs schreiben.
- Auf Origins gehen, die deine Allowlist sperrt (wenn gesetzt).

## Wann Claude welchen Modus wählt

| Situation | Modus |
|---|---|
| Öffentliche Seite, kein Login | C (Headless) |
| Du bist gerade auf einer Web-App eingeloggt und willst Hilfe | D (mitfahren) |
| Test-Login auf Wegwerf-Account | C mit eigenem Profil |
| Praxis-Webseiten-Live-Check | C oder D, je nach Bedarf |

## Beispiel-Dialog

> Du: „Auf der Live-Praxisseite sehe ich im Footer noch das alte Logo — wo
> ändere ich das im WordPress-Backend?"
>
> Claude: „Ich öffne dein WordPress. Du musst schon eingeloggt sein."
>
> ```
> ./bin/web-pilot start
> ./bin/web-pilot connect-chrome
> ./bin/web-pilot tabs --pretty
> ```
>
> Claude: „Der WordPress-Tab ist `tab-2`. Wechsle dahin und gib mir den DOM:"
>
> ```
> ./bin/web-pilot tab tab-2
> ./bin/web-pilot dom --selector "#adminmenu" --text-only --pretty
> ```
>
> Claude: „Im Menü findest du **Design → Theme-Editor → footer.php** Zeile
> 23. Soll ich draufklicken?"
