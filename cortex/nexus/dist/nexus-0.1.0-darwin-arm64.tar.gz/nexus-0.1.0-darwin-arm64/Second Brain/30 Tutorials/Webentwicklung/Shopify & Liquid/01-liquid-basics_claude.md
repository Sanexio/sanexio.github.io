# Shopify: Liquid-Grundlagen — Claude-Workflow

## Wann nutzt du diesen Workflow?

Du nutzt diesen Workflow **fast immer**. Wenn du Claude sagst: "Erstelle eine neue Section für die Preise-Seite" oder "Passe das Product-Layout an", macht Claude automatisch alles für dich. Du brauchst nicht selbst in Dateien rumzutippen.

**Vorteil:** Schnell, fehlerfrei, dokumentiert (Git-History).
**Nachteil:** Du brauchst Claude im gleichen Session.

---

## Der Workflow: Vier Schritte

### Schritt 1: Sag Claude was du willst

Du öffnest Claude Code (oder Cowork) und schreibst:

```
Erstelle eine Abschnitt (Section) für unsere Produktgalerie.
Sie soll 4 Produkte in einem Grid zeigen, mit Bildern und Preisen.
Nutze unser Teal-Farbschema (#028090).
```

Claude versteht das und weiß:
- Welche Datei zu erstellen ist (z.B. `sections/product-gallery.liquid`)
- Welche Struktur sie braucht
- Welche CSS-Klassen zu nutzen sind

---

### Schritt 2: Claude schreibt den Code

Claude erstellt die Liquid-Datei mit:
- **HTML/Liquid:** Die Struktur (For-Schleifen, If-Bedingungen, Variablen)
- **CSS:** Styling mit deinen Farben
- **JavaScript:** Falls nötig, Interaktionen
- **JSON Schema:** Damit der Admin die Section konfigurieren kann

Beispiel: Claude erstellt `sections/product-gallery.liquid`:

```liquid
{% section 'product-gallery' %}

<div class="product-gallery">
  {% for product in collection.products limit: 4 %}
    <div class="product-card">
      <img src="{{ product.featured_image | image_url: width: 300 }}" alt="">
      <h3>{{ product.title }}</h3>
      <p class="price">{{ product.price | money }}</p>
    </div>
  {% endfor %}
</div>

<style>
  .product-gallery {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.5rem;
  }
  .product-card {
    border: 1px solid #028090;
    padding: 1rem;
  }
</style>

{% schema %}
{
  "name": "Produktgalerie",
  "settings": [...]
}
{% endschema %}
```

---

### Schritt 3: PostToolUse Hook — Automatischer Push zu Shopify

**Das Wichtigste:** Du musst NICHTS tun. Ein sogenannter "PostToolUse Hook" erkennt automatisch, dass eine Theme-Datei erstellt/geändert wurde.

Der Hook arbeitet im Hintergrund:

```bash
# Hinter den Kulissen:
npx shopify theme push --store medzpoint --theme 181128757515 \
  --only sections/product-gallery.liquid --allow-live
```

Das bedeutet:
1. Claude speichert die Datei
2. Der Hook erkennt: "Das ist eine Shopify-Theme-Datei"
3. Der Hook pusht sie automatisch zum Live-Store
4. Die Änderung ist sofort auf sanexio.eu sichtbar

**Du merkst davon nichts — es passiert einfach.**

---

### Schritt 4: Claude verifiziert die Änderung

Claude prüft mit `curl`, ob die Änderung live ist:

```bash
curl -s 'https://sanexio.eu/pages/galerie' | grep -c 'product-gallery'
```

Das ist wichtig, weil Shopify einen 15-Minuten-Cache hat. `curl` umgeht diesen Cache und zeigt den aktuellen Live-Status.

Claude gibt dir Bescheid: "✅ Die Section ist live auf sanexio.eu"

---

## Was Claude nicht tun kann (das machst du manuell)

Einige Schritte kann Claude nicht automatisieren, weil das Shopify CLI keine Berechtigung dafür hat:

| Aktion | Wo | Schritte |
|--------|-----|----------|
| **Neue Seite erstellen** | Shopify Admin → Seiten | Auf "Seite hinzufügen" klicken, Titel eingeben |
| **Template zuweisen** | Auf der Seite → rechte Spalte → "Vorlage" | Aus Dropdown wählen |
| **Menü aktualisieren** | Onlineshop → Navigation | Neuen Eintrag hinzufügen |
| **Bilder hochladen** | Einstellungen → Dateien | Drag & Drop |

Claude gibt dir eine **exakte, Schritt-für-Schritt-Anleitung** für diese Dinge.

---

## Häufige Szenarios

### Szenario 1: "Ich will die Farben ändern"

**Du:** "Ändere die Produktkarten-Farbe von Teal zu einem hellen Grau (#F0F0F0)"

**Claude:**
1. Öffnet `sections/product-gallery.liquid`
2. Ändert `.product-card { border-color: #F0F0F0 }`
3. Hook pusht automatisch
4. Verifiziert mit curl
5. Gibt dir Bescheid ✅

---

### Szenario 2: "Ich will eine ganz neue Section"

**Du:** "Erstelle eine FAQ-Section mit zusammenklappbaren Fragen"

**Claude:**
1. Erstellt `sections/faq.liquid` mit HTML + Liquid
2. Erstellt JavaScript für die Accordion-Interaktion
3. Erstellt CSS mit deinem Farbschema
4. Erstellt Schema für den Admin
5. Hook pusht automatisch
6. Verifiziert ✅

---

### Szenario 3: "Es funktioniert nicht — rollback!"

**Du:** "Die neue Section sieht komisch aus, mache es rückgängig"

**Claude:**
1. Schaut sich `git log` an
2. Findet die letzte funktionierende Version
3. Führt `git revert` aus
4. Hook pusht die alte Version
5. Verifiziert ✅

Alles ist in Git gespeichert — nichts geht verloren.

---

## Git Commits (auf Anfrage)

Wenn du willst, dass Claude die Änderung auch in der Git-History speichert:

**Du:** "Committe die neue Section"

**Claude:**
```bash
cd projects/Juvantis/website/theme
git add sections/product-gallery.liquid
git commit -m "Add product gallery section with grid layout"
git push origin shopify-theme
```

Das speichert alles auf GitHub, damit du später die ganze Geschichte nachvollziehen kannst.

---

## Was du im Code verstehen solltest

Du brauchst nicht jede Zeile Liquid zu verstehen, aber diese Konzepte sind hilfreich:

- `{{ product.title }}` = einen Wert ausgeben
- `{% for product in collection.products %}` = eine Schleife
- `{% if ... %}` = eine Bedingung
- `| money` = einen Filter (wandelt 2999 in "€29.99" um)

Wenn Claude etwas schreibt, das du nicht verstehst, frag einfach: "Erkläre mir diese drei Zeilen" — Claude erklärt es gerne.

---

## Zusammenfassung: Der Claude-Workflow

1. **Du sagst was du willst** ("Erstelle eine Preise-Section")
2. **Claude schreibt den Code** (HTML + Liquid + CSS + JavaScript)
3. **Hook pusht automatisch zu Shopify** (du brauchst nichts tun)
4. **Claude verifiziert** (prüft ob es live ist)
5. **Optional: Git Commit** (speichert die History auf GitHub)

**Ergebnis:** Deine Shopify-Website wird live aktualisiert, alles ist dokumentiert, und wenn etwas schiefgeht, kannst du einfach zurückgehen.

---

*Dieser Workflow macht dich produktiv. Du fokussierst dich auf WAS du willst, Claude kümmert sich um WIE.*
