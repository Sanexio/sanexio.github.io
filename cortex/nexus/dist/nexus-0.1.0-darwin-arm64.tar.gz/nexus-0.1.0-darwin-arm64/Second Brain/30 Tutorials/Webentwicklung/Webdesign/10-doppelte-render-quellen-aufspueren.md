# 24 — Doppelte Render-Quellen aufspüren (CSS-Cascade & Template-Doppelungen)

**Bezug:** Pattern `single-source-ui-region` (`Nexus/_memory/patterns/single-source-ui-region.md`).
**Anlass:** Cortex-Web Session 38 (2026-04-24) — auf der Praxis-Homepage erschienen
zwei Footer untereinander, das Header-Menü brach nicht in 4+3 Items um (auf allen
anderen Seiten schon). Beide Symptome hatten denselben Ursprung: die UI-Region
existierte in zwei Quellen gleichzeitig.

---

## 1. Warum das wichtig ist

Wenn dieselbe sichtbare Region (Header, Footer, Brand-Streifen) im Code an
**zwei Stellen gerendert** wird, passiert eines von zwei Dingen:

1. Die zwei Stellen sind sichtbar parallel → **doppelt gerenderte Region** (z. B. zwei Footer).
2. Eine Stelle überschreibt die andere unsichtbar → **„nur auf einer Seite"-Bug** (z. B. neue
   Schriftgröße greift überall, außer auf der Startseite).

Die Diagnose ist immer die gleiche: **finde alle Render-/Definitions-Quellen
und reduziere auf eine**.

---

## 2. Vier typische Doppelungsmuster

| Muster | Beispiel aus Cortex-Web S38 |
|---|---|
| **Inline-Markup + Komponente** | `template-homepage.php` rendert Inline-`<footer>` UND ruft `get_footer()` auf |
| **Page-CSS überschreibt Komponenten-CSS** | `homepage.css` definierte `.pxz-nav-list { display: flex }`, das `nav.css` `display: grid` überschrieb (homepage.css wird nach nav.css geladen) |
| **Tag-Doppelung über Wrapper** | Zwei `<footer>` ineinander oder nebeneinander durch Mehrfach-Includes |
| **JS rendert + PHP rendert** | Hydration-Stil-Probleme im Headless-Setup (kommt später bei Cross-Site-Bridges) |

---

## 3. Diagnose-Workflow (3 Schritte, 5 Min)

### Schritt 1 — Volltextsuche im Theme
```bash
# Footer-Doppelung suchen
grep -rn "<footer" /pfad/zum/theme/

# CSS-Selektor-Doppelung suchen
grep -rn "\.pxz-nav-list" /pfad/zum/theme/assets/css/
```
Wenn dieselbe Klasse / dasselbe Tag mehrfach auftaucht: **rote Flagge**, weiter
zu Schritt 2.

### Schritt 2 — DOM live messen (Puppeteer / DevTools-Console)
```javascript
// Zähle <footer>-Elemente live
document.querySelectorAll('footer').length;
// → erwartet 1; bei >1 ist es eine Doppelung

// Computed-Style einer kritischen Property auslesen
getComputedStyle(document.querySelector('.pxz-nav-list')).display;
// → erwartet "grid"; bei "flex" überschreibt eine andere Quelle
```

### Schritt 3 — Cascade-Quelle identifizieren (DevTools)
Im Browser-Devtools auf das Element klicken → „Computed"-Tab → ausklappen,
welche Datei die Property setzt. WP-Dateien lassen sich an der Datei-URL
erkennen (`themes/<name>/assets/css/...`).

---

## 4. Auflösung — die EINE Wahrheit

### Fall A: Inline-Footer + `get_footer()`
```php
// template-homepage.php (Vorher — zwei Footer)
<footer class="pxz-footer">
  <!-- … Inline-Inhalt … -->
</footer>
<?php get_footer(); ?>
```
```php
// template-homepage.php (Nachher — ein Footer)
<!-- Inline-Footer entfernt; footer.php ist Single-Source -->
<?php get_footer(); ?>
```
Inline-Block muss raus, sobald die globale Komponente steht.

### Fall B: Page-CSS überschreibt Komponenten-CSS
```css
/* homepage.css (Vorher — überschreibt nav.css) */
.pxz-nav-list { display: flex; font-size: 0.9375rem; }
```
```css
/* homepage.css (Nachher — Verweis statt Code) */
/* Nav-Regeln leben in nav.css als Single-Source. */
```
Wenn die Page wirklich eine Sonderform braucht, **scopen** mit Body-Klasse:
```css
body.pxz-home .pxz-nav-list { /* sonderfall */ }
```

---

## 5. Praktischer Live-Probe-Helper (Bun + Puppeteer)

Lebt unter `sites/praxis-webseite/specs/sprint-2/S38_evidence/probe-double-footer.mjs`.
Im Kern:

```javascript
import { launch } from "puppeteer-core";
const browser = await launch({ /* … */ });
const page = await browser.newPage();
await page.goto(URL);
const data = await page.evaluate(() => {
  return [...document.querySelectorAll("footer")].map(f => ({
    tag: f.tagName,
    cls: f.className,
    h: Math.round(f.getBoundingClientRect().height)
  }));
});
console.log(data); // muss Länge 1 haben
```

Pflicht-Run nach jedem Footer-/Header-Refactor.

---

## 6. Wann Doppelung KEINE Doppelung ist

- Mobile-Sticky-Bottom-Bar parallel zum Footer (z. B. `pxz-mobile-cta`):
  unterschiedliche Region, unterschiedliche Funktion → **kein** Konflikt.
- Sub-Footer im Drawer (Mobile-Drawer mit Lang-Switcher, Footer separat):
  unterschiedliche Sicht (Drawer ist eigenes Overlay) → **kein** Konflikt.

Die Faustregel: Es ist erst dann eine Doppelung, wenn beide Render-Quellen
**dieselbe Position im normalen Document-Flow** beanspruchen.

---

## 7. Folge-Disziplin: Theme-Refactor-Checkliste

Wenn du eine globale Komponente extrahierst (`template-parts/site-footer.php`,
`template-parts/header-nav.php`, etc.):

1. Alle Inline-Vorkommen aus den Templates entfernen, die jetzt die Komponente
   nutzen sollen.
2. Komponenten-CSS in **eine** Datei verschieben (`assets/css/footer.css`,
   `assets/css/nav.css`).
3. Page-spezifische CSS-Dateien (`homepage.css`, `karriere.css`) auf
   Komponenten-Selektor-Duplikate prüfen — alle entfernen oder mit Body-Klasse
   scopen.
4. Live-Probe mit Puppeteer: Region kommt **genau einmal** vor.
5. `verify.sh` grün halten.

---

*Tutorial geboren aus echtem Bug — die Doppelung war monatelang unsichtbar,
weil Header und Footer auf den meisten Seiten korrekt aussahen, nur die
Homepage war betroffen. Pattern + Tutorial sind die langfristige Versicherung,
dass derselbe Bug nicht in die Juvantis-Site oder andere Trunk-Adapter wandert.*
