# 06 — Shopify Admin REST: Produkt-Sync (idempotent, draft-only)

> Anschluss an `05-admin-api-token-custom-app.md` (Token-Setup). Hier geht es darum,
> mit dem Token einen Bun- oder Node-Sync-Job zu schreiben, der Produkte aus einer
> externen Quelle (z.B. YAML-Trunk) ins Shopify-Admin pusht — wiederholbar, ohne
> Duplikate, mit Sicherheits-Schalter gegen versehentliches Live-Push.
>
> **Praxis-Beispiel:** Cortex-Web Phase 2, `projects/Cortex-Web/adapters/shopify/`.
> 12/12 Akzeptanzkriterien grün gegen Produktiv-Store `juvantis.myshopify.com`.

---

## Was lernt man hier?

1. Wie strukturiert man eine Sync-Pipeline (`validate → build → push`)
2. Wie macht man REST-Calls idempotent (Lookup vor Create/Update)
3. Wie schützt man sich vor versehentlichen Live-Pushes (`status="draft"` + Safeguard)
4. Welche Fallstricke es bei der Shopify-REST-API gibt
5. Wie man eine zentrale Wahrheit („Trunk") gegen Admin-Edits durchsetzt

---

## 1. Die Pipeline auf einen Blick

```
sync.sh
 ├─ validate.sh                                  Schema-Check + optional Token-Check
 ├─ bun build.mjs <yaml>                         YAML → JSON-Payload (auf stdout)
 └─ bun push.mjs                                 GET ?handle → POST oder PUT
```

Drei Stufen, jede mit klarer Verantwortung. `build.mjs` macht keine Netzwerk-Calls
(nur Datenformung). `push.mjs` macht keine Validierung (nur HTTP). Das macht
beide unabhängig testbar.

---

## 2. Authentifizierung

Shopify Admin REST verlangt den Token im Request-Header — niemals in der URL:

```
X-Shopify-Access-Token: shpat_…
```

Plus `Content-Type: application/json` für POST/PUT. Token aus `.env.local`,
nie im Repo, nie auf stdout. Im Code:

```js
const baseUrl = `https://${store}/admin/api/2026-04`;
const headers = {
  "X-Shopify-Access-Token": token,
  "Accept": "application/json"
};
```

API-Version (hier `2026-04`) IMMER explizit pinnen. Shopify führt vierteljährlich
neue Versionen ein und veraltete werden nach ~12 Monaten abgeschaltet — ohne Pin
bekommt man schleichende Verhaltensänderungen.

---

## 3. Idempotenz mit `handle`

Idempotenz heißt: zweiter Lauf ändert nichts oder aktualisiert das gleiche
Produkt — er legt KEIN zweites Produkt an.

Die billigste Strategie ist Lookup über `handle` (URL-Slug):

```js
const lookup = await client.get(`/products.json?handle=${enc(handle)}&fields=id,handle,status,published_at,updated_at`);
const products = lookup.products;

if (products.length === 0) {
  // create
  await client.post(`/products.json`, { product: payload.product });
} else if (products.length === 1) {
  // update — id MUSS auch im Body stehen, nicht nur in der URL
  const existing = products[0];
  await client.put(`/products/${existing.id}.json`, { product: { id: existing.id, ...payload.product } });
} else {
  // ≥2 Treffer → Abbruch (ambiguous handle, manuell aufräumen)
  throw new Error(`ambiguous handle "${handle}"`);
}
```

**Wichtig — Fallstrick #1:** `handle` MUSS innerhalb des `product`-Objekts stehen,
nicht nur außen drumherum. Wenn man `handle` weglässt oder nur als Wrapper-Feld
führt, ignoriert Shopify das und derived selber einen Handle aus dem `title`
(Slugify-Logik). Folge: Beim 2. Lauf findet `?handle=basic-check` nichts, der
Adapter legt ein zweites Produkt an. Aua.

**Korrekt:**
```json
{ "product": { "handle": "basic-check", "title": "Basis-Bluttest", … } }
```

**Falsch:**
```json
{ "handle": "basic-check", "product": { "title": "Basis-Bluttest", … } }
```

---

## 4. `status` hartcodiert auf `draft`

Während Entwicklung und POC darf der Adapter NIE ein `status="active"` an die
API schicken. Ein Tippfehler in einer ENV-Variable könnte sonst ein halb-fertiges
Produkt ins öffentliche Storefront pushen.

Lösung: `status: "draft"` direkt im Renderer hardcoden:

```js
return {
  product: {
    handle: product.id,
    title: product.title.de,
    status: "draft",       // C-1: hardcoded, never overridable via env
    published_scope: "web",
    …
  }
};
```

Plus: Pre-Push-Check im Push-Skript, der das Payload nochmal verifiziert:

```js
if (payload.product.status !== "draft") {
  die(1, `payload.product.status must be "draft" (got "${payload.product.status}") — C-1 violation`);
}
```

Defense-in-Depth — beide Schichten müssten kaputt sein, damit ein Live-Push passiert.

---

## 5. Safeguard für published Produkte (`ALLOW_OVERWRITE`-Flag)

Was, wenn jemand das Produkt im Admin manuell auf `active` gesetzt hat (z.B.
um eine Korrektur zu testen) und der Adapter es jetzt überschreiben würde?
Der Adapter würde es zurück auf `draft` setzen — unter Umständen während eines
Live-Demos.

Lösung: vor dem PUT prüfen, und nur überschreiben, wenn der Aufrufer das
explizit will:

```js
const isPublished = existing.status === "active" || existing.published_at !== null;
if (isPublished && process.env.ALLOW_OVERWRITE !== "1") {
  die(2, `target product handle="${handle}" is published — set ALLOW_OVERWRITE=1 to proceed`);
}
```

Aufruf:
```bash
bash sync.sh                       # bricht ab, wenn published
ALLOW_OVERWRITE=1 bash sync.sh     # läuft durch, setzt status zurück auf draft
```

Das ist gleichzeitig der **Beweis für „Trunk-Master"** (CW-001 in Cortex-Web):
das System setzt unilaterale Admin-Edits zurück, sobald der Trunk-Sync läuft.
Das ist nicht Theorie — das ist verifiziert per Roundtrip-Test.

---

## 6. Token-Mask im Stderr

Auch wenn Shopify den Token nicht in seinen Antworten spiegelt: niemals
einen Pfad bauen, in dem der Token im Stderr landet. Pattern:

```js
function maskToken(str, token) {
  if (!token) return str;
  return str.split(token).join("***");
}

// In Fehler-Output:
throw new Error(`HTTP ${res.status} on ${method} ${url}: ${maskToken(text, token)}`);
```

Defense-in-Depth — falls eine API-Library oder ein Bug irgendwo den Token in
einen Logging-Pfad schiebt, neutralisiert die Mask sofort.

---

## 7. Connectivity-Smoke-Test als Pre-Flight

Vor dem ersten Push einmal manuell den Token gegen `/shop.json` validieren:

```bash
set -a; source .env.local; set +a
curl -sS -H "X-Shopify-Access-Token: $SHOPIFY_ADMIN_TOKEN" \
  "https://${SHOPIFY_STORE}/admin/api/2026-04/shop.json" | jq '.shop.myshopify_domain'
# Erwartet: "juvantis.myshopify.com"
```

In `validate.sh` als optionaler Pfad einbauen, hinter ENV-Flag:

```bash
if [ "${CHECK_SHOPIFY:-0}" = "1" ]; then
  http_code="$(curl -sS -o /tmp/shop.json -w '%{http_code}' \
    -H "X-Shopify-Access-Token: $SHOPIFY_ADMIN_TOKEN" \
    "https://${SHOPIFY_STORE}/admin/api/2026-04/shop.json")"
  [ "$http_code" = "200" ] || { echo "shopify check FAILED" >&2; exit 2; }
fi
```

Damit kann das Sync-Skript den Connectivity-Check immer mitausführen
(`CHECK_SHOPIFY=1 bash validate.sh`), ohne dass `validate.sh` zwingend einen
Token braucht.

---

## 8. Verifikation: Lookup nach dem Push

Nach jedem Push einmal von Hand prüfen, dass das angekommen ist, was man
erwartet hat — speziell für `handle`, `status`, `published_at`:

```bash
curl -sS -H "X-Shopify-Access-Token: $SHOPIFY_ADMIN_TOKEN" \
  "https://${SHOPIFY_STORE}/admin/api/2026-04/products.json?handle=basic-check&fields=id,handle,status,published_at,updated_at" \
  | jq '.products[0]'
```

Wenn `handle` von dem abweicht, was man gesendet hat → Punkt 3 nochmal
durchgehen (war `handle` im Wrapper statt im Product?).

---

## 9. Storefront-Schutz prüfen

Selbst wenn alles korrekt ist, einmal vom öffentlichen Web aus die Storefront-URL
des neuen Produkts antippen:

```bash
curl -sS -o /dev/null -w "HTTP %{http_code} -> %{redirect_url}\n" \
  "https://sanexio.eu/products/basic-check"
# Erwartet: HTTP 302 → /password   (Store passwortgeschützt) ODER
#           HTTP 404                 (Store offen, aber Draft-Produkt)
```

Beides ist ein erfolgreicher Negativ-Test. Wenn man stattdessen `HTTP 200` mit
dem Produkt-Inhalt bekommt → Adapter hat fälschlich `status="active"` oder
`published_at` gesetzt, sofort prüfen.

---

## 10. Tags werden alphabetisch normalisiert

Shopify sortiert Tags. Adapter sendet `"cortex-web, bluttests"`, Shopify
speichert `"bluttests, cortex-web"`. Bei Diff-Reports und visuellen Audits
darauf gefasst sein. Idempotenz ist davon nicht betroffen (Set-Vergleich).

---

## 11. Out-of-Scope und Phase-2b-Hooks

Folgende Bausteine sind in einer Sync-Pipeline meist NICHT in Phase 1:

- **Bilder/Medien-Upload** — separates Modul (Hash-Dedupe, lokale Originale, `stagedUploadsCreate`)
- **Variants** — wenn der Trunk Variants kennt, eigener Renderer-Pfad
- **Metafields** — stabilerer Idempotenz-Marker als `handle`, aber separater POST
- **Smart Collections** — Admin-UX-Frage, nicht Adapter-Frage; via Tags abgreifen

---

## Verwandte Tutorials

- `02-shopify-admin-api.md` — Allgemeine Admin-API-Übersicht
- `05-admin-api-token-custom-app.md` — Token-Setup (Vorgänger dieses Tutorials)

## Referenz-Implementation

`projects/Cortex-Web/adapters/shopify/` (Cluster-Mini-02).

## Nexus-Pattern

`Nexus/_memory/patterns/shopify-rest-product-sync.md` — kompakte Variante
dieses Tutorials für Schnell-Lookup.
