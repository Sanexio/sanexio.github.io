# Shopify: Liquid-Grundlagen — Manueller Workflow

## Wann nutzt du diesen Workflow?

Du nutzt diesen Workflow, wenn:
- Claude gerade nicht verfügbar ist
- Du schnell eine kleine Änderung machen musst (z.B. Text anpassen)
- Du selbst lernen willst wie Liquid funktioniert
- Du eine Datei direkt in Cursor öffnen möchtest

**Vorteil:** Kein Claude nötig, du hast volle Kontrolle.
**Nachteil:** Du musst die Terminal-Befehle selbst tippen.

---

## Vorbereitung: Repository klonen (einmalig)

Wenn du noch nicht das Juvantis-Theme geklont hast:

```bash
cd ~/projects/Juvantis
git clone https://github.com/Sanexio/JUVANTIS.git website
cd website
git checkout shopify-theme
```

Das lädt den aktuellen Stand des Themes herunter.

---

## Der manuelle Workflow: Fünf Schritte

### Schritt 1: Datei öffnen und bearbeiten (in Cursor)

Öffne Cursor und navigiere zu deinem Theme:

```
projects/Juvantis/website/theme/sections/
```

Öffne dann die Datei, die du ändern willst (z.B. `product-gallery.liquid`).

**Beispiel: Eine Farbe ändern**

Finde die Zeile:
```liquid
border-color: #028090;
```

Ändere sie zu:
```liquid
border-color: #F0F0F0;
```

Speichern mit `Cmd+S`.

---

### Schritt 2: Terminal öffnen und zum Theme navigieren

```bash
cd ~/projects/Juvantis/website/theme
pwd    # Prüfen dass du im richtigen Ordner bist
```

Du solltest sehen:
```
/Users/ssmd/projects/Juvantis/website/theme
```

---

### Schritt 3: Status prüfen (was hat sich geändert?)

```bash
git status
```

Output:
```
On branch shopify-theme

Changes not staged for commit:
  modified:   sections/product-gallery.liquid
```

Das bedeutet: Die Datei wurde geändert, aber noch nicht "committed".

---

### Schritt 4: Push zu Shopify

```bash
npx shopify theme push --store medzpoint --theme 181128757515 \
  --only sections/product-gallery.liquid --allow-live
```

Das lädt die Datei zu Shopify hoch:

```
✓ Uploaded sections/product-gallery.liquid
```

**Die Änderung ist jetzt live auf sanexio.eu!**

---

### Schritt 5: Verifizieren (curl-Test)

```bash
curl -s 'https://sanexio.eu/pages/galerie' | grep -c 'product-gallery'
```

Wenn die Antwort `1` oder höher ist, ist die Datei live.

---

## Liquid schnell anpassen — Häufige Änderungen

### Text in einer Section ändern

**Datei:** `sections/header.liquid`

Finde:
```liquid
<h1>{{ shop.name }}</h1>
```

Ändere zu:
```liquid
<h1>Willkommen zu {{ shop.name }}</h1>
```

---

### Farben ändern

**In der `<style>`-Section eine Farbe finden und ändern:**

```liquid
<style>
  .header {
    background-color: #028090;  ← Alte Farbe
  }
</style>
```

Ändere zu:

```liquid
<style>
  .header {
    background-color: #00A896;  ← Neue Farbe
  }
</style>
```

---

### Bilder anpassen

Finde:
```liquid
{% image_url: width: 500 %}
```

Ändere die Breite:
```liquid
{% image_url: width: 800 %}  ← Größeres Bild
```

---

## Mit Git arbeiten (optional, aber empfohlen)

Nach dem Pushen zu Shopify solltest du auch einen Git Commit machen (damit die History gespeichert wird):

```bash
# 1. Änderungen "zum Commit vorbereiten"
git add sections/product-gallery.liquid

# 2. Commit erstellen
git commit -m "Change product card border to light gray"

# 3. Zu GitHub pushen
git push origin shopify-theme
```

---

## Fehler beheben

### Problem: "Command not found: npx"

**Grund:** Node.js/npm ist nicht installiert.

**Lösung:** NVM aktivieren:
```bash
source ~/.nvm/nvm.sh
nvm use 18
npx shopify theme push ...
```

---

### Problem: "Theme push funktioniert nicht"

**Grund:** Möglicherweise ein Authentifizierungsfehler.

**Lösung:** Authentifizierung neu einrichten:
```bash
npx shopify auth logout
npx shopify auth login --store medzpoint
```

---

### Problem: "Die Änderung ist nicht live"

**Grund:** Wahrscheinlich noch im Shopify-Cache (bis 15 Minuten).

**Lösung:** Warte eine Minute und versuche `curl` erneut:
```bash
sleep 60
curl -s 'https://sanexio.eu' | grep 'product-gallery'
```

---

## Cheat Sheet: Wichtigste Terminal-Befehle

| Befehl | Was es tut |
|--------|-----------|
| `pwd` | Zeig mir wo ich bin |
| `cd ~/projects/Juvantis/website/theme` | Wechsle zum Theme |
| `git status` | Was wurde geändert? |
| `git add .` | Alle Änderungen vorbereiten |
| `git commit -m "..."` | Änderungen speichern (mit Beschreibung) |
| `npx shopify theme push ...` | Zu Shopify hochladen |
| `curl -s https://... | grep ...` | Prüfen ob live |

---

## Liquid Cheat Sheet

| Code | Was es macht |
|------|------------|
| `{{ variable }}` | Einen Wert ausgeben |
| `{{ variable | filter }}` | Einen Filter anwenden |
| `{% if ... %} ... {% endif %}` | Eine Bedingung |
| `{% for x in y %} ... {% endfor %}` | Eine Schleife |
| `{% assign x = y %}` | Eine Variable erstellen |

**Häufige Filter:**
- `| money` — Geld formatieren (2999 → €29.99)
- `| image_url: width: 500` — Bild-URL mit Größe
- `| capitalize` — Erstes Zeichen groß
- `| downcase` — Kleinbuchstaben
- `| upcase` — Großbuchstaben
- `| date: "%d.%m.%Y"` — Datum formatieren (15.01.2024)

---

## Zusammenfassung: Manuelle Schritte

1. **Öffne die Datei in Cursor**
2. **Mach deine Änderung und speichere (`Cmd+S`)**
3. **Terminal: `npx shopify theme push`** — Upload zu Shopify
4. **Terminal: `curl` Befehl** — Verifiziere dass es live ist
5. **Optional: `git commit` + `git push`** — Speichere die History

**Zeit für eine kleine Änderung:** 2-5 Minuten.

---

*Dieser Workflow ist für schnelle, manuelle Änderungen. Für größere Features: Claude nutzen.*
