[!anweisung] Struktur des Tutorials
Ich möchte, dass das Tutorial einen Schwerpunkt auf die Basics der Webprogrammierung und der Bezeichnungen spezifischer Parts des Webdesigns beinhaltet und ich möchte, dass das Tutorial auch entsprechend gegliedert wird. Hauptpunkte sind Skriptsprachen und Programmierung die benötigt werden sowie das Design - ich möchte dass du das Tutorial WordPress & CSS als Webdesign umbenennst und das Tutorial selbst nach den oben genanten Kriterien nur aufbaust. 
# 01 — CTA-Conversion und Sektions-Höhe

> Lernziel: Verstehen, warum eine Recruiting- oder CTA-Sektion auf einer
> Webseite **kompakt** sein muss, um zu konvertieren — und wie man eine
> bestehende, zu große Sektion strukturell verkleinert, ohne Spacing-Sprache
> oder Lesbarkeit zu opfern.

> Quelle: Praxis-Redesign 2026-04-18, MFA-Sektion v2.7.2 → v2.7.3.

---

## 1. Warum eine kurze CTA-Sektion besser konvertiert

Conversion-Theorie sagt: **Mentale Last × Klick-Wahrscheinlichkeit ist
inverse korreliert.** Je länger ein Bewerber/Patient/Kunde scrollen und
lesen muss, bevor der CTA-Button kommt, desto höher ist die Abbruchrate.

Klassischer Recruiting-Fehler auf Praxis-/Klinik-Websites:

> Eyebrow → Titel → Subtitle → **Benefit-Liste mit 5–10 Punkten** →
> **Aufgaben-Liste mit 5–10 Punkten** → Button.

Was scheinbar „transparent und vollständig" ist, ist in Wirklichkeit eine
**Vorab-Filterung gegen den Bewerber**: Er soll vor dem Klick alle
Informationen lesen. Aber der Bewerber ist auf der Seite, weil er **wissen
will, ob er sich bewerben SOLL**, nicht weil er die ganze Stellenanzeige
lesen will. Die Detail-Infos gehören auf die Karriere-Detail-Seite, nicht
auf die Homepage-CTA-Sektion.

### Conversion-Pattern „Pull-Faktor statt Stellenanzeige"

| Stellenanzeigen-Sprache (zu lang) | Pull-Faktor-Sprache (kompakt) |
|---|---|
| „Wir suchen eine Medizinische Fachangestellte für Allgemein- und Innere Medizin. Vollzeit, ab sofort, unbefristet." | „MFA-Sein ist mehr als Termine vergeben. Bei uns gehörst du zum Team." |
| Listet Anforderungen | Beschreibt das Erlebnis |
| Sie-Form / passiv | Du-Form / aktiv |
| Sucht eine objektive Beschreibung | Spricht ein Bedürfnis an |

**Faustregel:** Subtitle der CTA-Sektion sollte 2–4 Sätze haben, max.
~60 Wörter. Alle weiteren Details auf die Detail-Seite.

---

## 2. Höhe einer Sektion: was sie wirklich treibt

Die sichtbare Höhe einer Webseiten-Sektion setzt sich aus drei Schichten
zusammen:

```
┌───────────────────────────────────────┐
│ Section-Padding (oben)            ~96px│ ← Layout-Rhythmus
│ ┌───────────────────────────────────┐ │
│ │ Card-Padding (oben)         ~112px│ │ ← Visueller Abstand
│ │ ┌───────────────────────────────┐ │ │
│ │ │                               │ │ │
│ │ │       INHALTS-BLOCK           │ │ │ ← 70-90% der Höhe
│ │ │       (Text + Liste + CTAs)   │ │ │
│ │ │                               │ │ │
│ │ └───────────────────────────────┘ │ │
│ │ Card-Padding (unten)         ~96px│ │
│ └───────────────────────────────────┘ │
│ Section-Padding (unten)           ~96px│
└───────────────────────────────────────┘
```

Wer eine Sektion verkleinern will, **darf nicht zuerst am Padding drehen** —
das bringt typisch 10–20 % Höhenreduktion. Die richtigen Hebel sind:

1. **Inhalt strukturell streichen** (50–60 % möglich)
2. **Inhalt vertikal komprimieren** (z. B. 2-spaltig statt 1-spaltig: ~30 %)
3. **Padding nachjustieren** (5–15 %, als Feinjustage zum Schluss)

---

## 3. Werkzeug: Headless-Chrome-Höhen-Probe

Vor jeder Höhen-Änderung den IST-Zustand messen. Ohne Messung ist jede
„diese Sektion ist zu hoch" eine Behauptung.

### Mini-Skript-Pattern (Bun + puppeteer-core)

```js
import { launch } from "puppeteer-core";
const URL = "https://example.local/?cb=" + Date.now();
const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const browser = await launch({
  executablePath: CHROME,
  headless: true,
  args: ["--ignore-certificate-errors", "--no-sandbox", "--incognito"],
});

async function measure(vp, label) {
  const page = await browser.newPage();
  await page.setCacheEnabled(false);
  await page.setViewport(vp);
  await page.goto(URL, { waitUntil: "networkidle0" });
  const r = await page.evaluate(() => ({
    section: document.querySelector("section.target")?.getBoundingClientRect().height,
    card: document.querySelector(".target-card")?.getBoundingClientRect().height,
    grid: document.querySelector(".target-grid")?.getBoundingClientRect().height,
  }));
  console.log(label, r);
  await page.close();
}
await measure({ width: 1440, height: 900 }, "Desktop");
await measure({ width: 430,  height: 900 }, "Mobile");
await browser.close();
```

**Wichtige Flags:**
- `incognito` + `setCacheEnabled(false)` + `?cb=<timestamp>` — sonst zeigt
  der Browser den Cache-Stand und die Messung ist falsch.
- `waitUntil: "networkidle0"` — Wartet, bis alle Assets geladen sind, sonst
  ist das Layout noch nicht final.

---

## 4. CSS-Spezifitäts-Falle: `:where()` für globale Resets

Eine zweite Lehre aus dieser Session, die jede Webentwicklung betrifft:

### Problem
Eine globale Reset-Regel in einem Theme-Container überschreibt **lautlos**
alle nachfolgenden Klassen-Margin-Regeln.

```css
/* Reset, Spezifität 0,1,1 — KLASSE + TAG */
.theme-home p { margin: 0; }

/* Klassen-Regel, Spezifität 0,1,0 — verliert das Cascade-Duell */
.theme-home .hero-subtitle { margin: 1.25rem auto 0; max-width: 36rem; }
```

Effekt: `.hero-subtitle` hat `margin-left: 0` statt `auto` → das Element
sitzt links, nicht zentriert, obwohl `max-width + margin: auto` korrekt
gesetzt sind.

### Lösung
Globale Element-Resets in Theme-Containern **immer mit `:where()`** schreiben,
um sie spezifitätsneutral zu machen:

```css
.theme-home :where(p, h1, h2, h3, h4, ul, ol) { margin: 0; }
```

`:where()` liefert Spezifität **0**. Damit gewinnt jede Klassen-Regel das
Cascade-Duell, ohne `!important` oder Spezifitäts-Trick.

### Diagnostik
Wenn ein Block mit `max-width + margin: auto` trotzdem links sitzt, **immer
zuerst** `getComputedStyle(el).marginLeft / marginRight` prüfen. Ist es
`0px` statt eines auto-kalkulierten Werts → Spezifitäts-Konflikt.

---

## 5. AB-Diff vs. numerischer Beweis

Wenn man eine CSS-Änderung macht, ist die Pflicht: **Vorher/Nachher beweisen**,
nicht behaupten. Es gibt zwei Beweisformen, die unterschiedlich gut zu
unterschiedlichen Änderungen passen:

| Änderungsart | Beweisform |
|---|---|
| Reines CSS-Tweak (Padding, Color, Font) | Visueller AB-Diff via `setUserStyleSheet()` oder Override-CSS |
| **Strukturelle Inhaltslöschung** (DOM-Knoten weg) | **Numerisches Höhen-Delta** + Nachher-Section-Crop |
| Versionsbump ohne Layoutwirkung | nur Probe (Computed Style) |

**Falsche Erwartung** (war eine Lehre dieser Session): „AB-Diff macht alles."
Stimmt nicht — wenn man Inhalt aus dem DOM entfernt hat, kann ein
CSS-Override den Vorher-Zustand nicht rekonstruieren. Dann ist die
**numerische Höhenmessung** der primäre Beweis, der visuelle Crop nur die
Veranschaulichung.

---

## 6. WordPress-spezifische Cache-Buster-Strategie

Bei WordPress-Themes mit Inline-`<style>`-Blöcken oder mit
`wp_enqueue_style()`:

```php
// functions.php
define( 'PXZ_VERSION', '2.7.3' );
wp_enqueue_style( 'theme', get_stylesheet_uri(), [], PXZ_VERSION );
```

Bei jeder CSS-Änderung muss `PXZ_VERSION` (oder das projektspezifische
Pendant) **hochgezählt** werden, sonst lädt der Browser den alten Stand.
Bei Local by Flywheel ist das doppelt wichtig, weil der lokale Server
aggressiv cached.

### Inline vs. externe Datei

In dieser Session: Das Theme nutzt **beide**:
- `style.css` extern (geladen via `wp_enqueue_style`)
- `<style>` inline in `template-homepage.php` (für homepage-spezifische Styles)

**Falle:** Eine Reset-Regel darf nur an **einer** Stelle leben (PXZ-E-001).
Wenn die gleiche Regel inline UND extern existiert, kämpft die externe gegen
die inline — und es ist nicht offensichtlich, welche gewinnt (hängt vom
Render-Zeitpunkt ab).

**Pflicht-Check vor Deploy:**

```bash
grep -nE "<problematische-Regel>" \
  wp-content/themes/<theme>/style.css \
  wp-content/themes/<theme>/template-homepage.php
```

Findet `grep` zwei Treffer mit demselben Selektor → eine Stelle löschen.

---

## 7. Zusammenfassung — Checkliste für CTA-Conversion-Sektionen

- [ ] Subtitle ≤ 60 Wörter, Pull-Faktor statt Anforderungs-Liste
- [ ] Du-Form, aktive Sprache, ein einzelnes Versprechen
- [ ] EIN primärer CTA, max. ein sekundärer Link
- [ ] Detail-Listen (Benefits/Tasks) auf Detail-Seite, nicht auf Homepage
- [ ] Höhen-Inventar via Headless-Chrome vor und nach Änderung
- [ ] Reset-Regeln immer `:where()`-spezifitätsneutral
- [ ] Cache-Buster hochzählen bei jeder CSS-Änderung
- [ ] Numerischer Beweis (Delta) bei strukturellen Änderungen, AB-Diff bei reinen Stil-Tweaks

---

## Verwandte Patterns
- `Nexus/_memory/patterns/web-section-shrink.md` — Sektion strukturell verkleinern
- `Nexus/_memory/patterns/shopify-workflow.md` — Theme-Workflow allgemein

## Verwandte Tutorials
- `Webentwicklung/Shopify & Liquid/` — Liquid-spezifische Pendants
- `Arbeitsweise & Prozess/01-architekten-modus.md` — 4-Phasen-Prozess

---

*Stand: 2026-04-18, Session-Lehre praxis-redesign v2.7.3.*
