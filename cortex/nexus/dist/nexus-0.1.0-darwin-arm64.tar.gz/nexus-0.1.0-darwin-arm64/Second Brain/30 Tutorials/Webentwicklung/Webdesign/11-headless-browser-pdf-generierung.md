# 26 — Headless-Browser für PDF-Generierung der Webseite

> Wie aus einer Live-Webseite eine PDF wird, die genauso aussieht wie im
> Browser — und die typischen Fallstricke, wenn man's naiv macht.

## 1. Wofür ist das gut?

Manchmal will man die Webseite nicht „live anschauen", sondern als **PDF
verschicken** — z. B.:

- **Mitarbeiter-Beurteilung:** „Hier ist der aktuelle Entwurf, was sagt ihr?"
- **Stakeholder-Update:** „Stand zum 26. April"
- **Print-Archiv:** Snapshot der Seite zu einem Zeitpunkt

Statt von Hand jede Section zu screenshotten und in Word/Pages zu kleben,
**rendert ein „Headless"-Browser die Seite und exportiert sie direkt als PDF**.

Das geht im Praxis-Webseite-Projekt mit dem Skript
`tools/make-staff-presentation.mjs`. Aufruf:

```bash
cd ~/Cortex/projects/Cortex-Web/sites/praxis-webseite
bun run tools/make-staff-presentation.mjs
```

Output landet unter `~/Downloads/Praxis-Webseite-Homepage-Beurteilung-<DATUM>.pdf`.

## 2. Wie es funktioniert (vereinfacht)

1. **Headless Chrome** (Chrome ohne Fenster, läuft im Hintergrund) wird
   gestartet.
2. **Puppeteer** (Steuerungs-Bibliothek) lädt die Webseite, als ob sie
   ein Mensch im Browser öffnen würde.
3. Sobald die Seite fertig geladen ist, ruft Puppeteer den
   PDF-Print-Befehl auf — Chrome rendert die Seite in eine PDF-Datei.
4. Mehrere PDFs (Cover + Inhalt) werden mit `pdfunite` zu einer Datei
   zusammengeführt.

## 3. Zwei Fallstricke, die wir gelernt haben

### Fallstrick 1: Große Bilder werden auf Mini-Größe gestaucht

Wenn man die Screenshots erst aufnimmt und dann in ein Composer-HTML als
**inline base64-Bild** einbettet (`<img src="data:image/png;base64,...">`)
und das HTML dann zu PDF rendert, **staucht Chromes PDF-Renderer große
Bilder auf 14×16 Pixel** — die PDF ist dann unbrauchbar.

**Lösung:** Statt Composer-HTML mit eingebetteten Bildern, jede Sektion
**als eigene PDF** rendern und am Ende mit `pdfunite` mergen.

Details: `Nexus/_memory/patterns/chrome-pdf-base64-image-shrink.md`.

### Fallstrick 2: Lazy-geladene Bilder fehlen

Moderne Webseiten laden Bilder **erst, wenn man sie sieht** („lazy loading").
Wenn der Headless-Browser die PDF erstellt, **scrollt er nicht durch die
Seite** — also bleiben Bilder weiter unten leer.

**Beispiel aus dem Projekt:** Die Ärzte-Fotos auf der Praxis-Homepage
fehlten in der ersten PDF-Version, weil die Team-Section weiter unten
sitzt und nicht im initialen Viewport war.

**Lösung in 4 Schritten** (alles im Skript bereits umgesetzt):

1. Lazy-Loading per JavaScript abschalten (`img.loading = "eager"`)
2. Programmatisch durch die ganze Seite scrollen
3. Auf vollständigen Bild-Decode warten
4. Eine Sekunde Settle-Frame, dann PDF rendern

Details: `Nexus/_memory/patterns/puppeteer-pdf-lazy-load-fix.md`.

## 4. Verifikation — wie weiß ich, dass die PDF gut ist?

Nach jeder Generierung:

```bash
PDF="/Users/cluster-mini-02/Downloads/<dateiname>.pdf"

ls -lh "$PDF"             # Größe muss plausibel sein (MB-Bereich)
pdfinfo "$PDF"            # Anzahl Seiten + A4-Format
pdfimages -list "$PDF"    # Bildgrößen pro Seite — KEINE 14×16-Bilder!
```

Wenn alle Bilder plausible Größen haben (z. B. 800×800 für Profil-Fotos),
ist die PDF gut.

## 5. Wie weit verändere ich das?

Das Skript ist **bewusst nur für die Homepage** geschrieben. Für andere
Seiten (z. B. eine Service-Page oder eine Ärzte-Profilseite) gibt's zwei
Wege:

| Variante | Wie |
|---|---|
| **Schnell** | URL im Skript ändern, Skript einmal ausführen — fertige PDF mit dieser Page |
| **Sauber** | Eine kleine CLI-Erweiterung mit `--url=...`-Argument, dann ist's wiederverwendbar |

Wenn Dr. Stracke regelmäßig PDFs verschiedener Seiten braucht, baut Claude
die saubere CLI-Variante.

## 6. Glossar — Fachbegriffe

| Begriff | Bedeutung |
|---|---|
| **Headless Browser** | Browser ohne sichtbares Fenster — läuft im Hintergrund, gesteuert per Skript. Chrome kann das nativ über `--headless`. Wird benutzt für Tests, Screenshots, PDFs, Web-Scraping. |
| **Puppeteer** | JavaScript-/Bun-Bibliothek (von Google), die Headless Chrome steuert: „Öffne Seite X, klicke Y, mache Screenshot, drucke PDF". Variante `puppeteer-core` lädt nicht selbst Chrome runter, sondern nutzt das schon installierte. |
| **PDF (Portable Document Format)** | Datei-Format, das Layout, Schriften und Bilder „eingefroren" mitnimmt — sieht überall gleich aus. Adobe-Standard, heute frei. |
| **Lazy Loading** | „Bild wird erst geladen, wenn der Nutzer dorthin scrollt." Spart Bandbreite bei Seitenstart. HTML-Standard: `<img loading="lazy">`. Browser nutzen oft zusätzlich JavaScript-Loader. |
| **base64** | Methode, Binärdaten (Bilder, PDFs) als Text darzustellen — z. B. `data:image/png;base64,iVBORw0KG...`. Ein Bild als base64 ist ca. 33 % größer als das Original. |
| **Skia** | Grafik-Engine von Google (auch Chromes PDF-Renderer). Macht das eigentliche Zeichnen — Pixel auf Screen, Vektoren in PDF. |
| **IntersectionObserver** | Browser-API, die meldet „Element X ist gerade in den sichtbaren Bereich gescrollt". Wird von Lazy-Loadern benutzt, um Bilder zur richtigen Zeit nachzuladen. |
| **pdfunite** | CLI-Tool aus dem `poppler-utils`-Paket, das mehrere PDFs zu einer zusammenfügt. Auf macOS via `brew install poppler`. Alternative: `qpdf`, `pdftk`. |
| **viewport** | Sichtbarer Bereich der Webseite im Browser. Bei Headless: meist 1440×900 Pixel für Desktop, 430×900 für Mobile. |
| **deviceScaleFactor** | Pixel-pro-CSS-Pixel-Verhältnis. Retina/Mobile = 2 (doppelt so viele Pixel pro Punkt). Bei Screenshots wichtig für gestochene Schärfe. |
| **emulateMediaType** | Sagt dem Browser „so tun als wärst du gerade beim Drucken (`print`) oder am Bildschirm (`screen`)". Beeinflusst, welche CSS-Regeln greifen. Für „PDF wie Browser" → `screen`. |

## 7. Verwandte Notizen

- `Nexus/_memory/patterns/chrome-pdf-base64-image-shrink.md` — Pattern „split & merge"
- `Nexus/_memory/patterns/puppeteer-pdf-lazy-load-fix.md` — Pattern „force-eager + scroll-prime"
- `Cortex-Web/sites/praxis-webseite/tools/make-staff-presentation.mjs` — Konkrete Implementierung
- `Cortex-Web/sites/praxis-webseite/tools/shoot.mjs` — Generischer Screenshot-Runner (Vorgänger, nur PNG)
