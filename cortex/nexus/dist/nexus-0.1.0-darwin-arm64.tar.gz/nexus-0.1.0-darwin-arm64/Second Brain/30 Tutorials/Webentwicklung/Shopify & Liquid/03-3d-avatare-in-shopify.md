# 3D-Avatare in Shopify einbinden — Was, Warum, Wie

> **Worum geht es?** Auf der Seite "Digital Health Twin" zeigen wir einen
> rotierbaren 3D-Avatar in zwei Zuständen (krank/gesund). Diese Einführung
> erklärt, wie 3D-Modelle in Shopify funktionieren — ohne Code-Details.
>
> **Workflows:**
> - `03-3d-avatare-in-shopify_claude.md` — Wie Claude die Pipeline automatisch baut
> - `03-3d-avatare-in-shopify_manuell.md` — Wie Sie es selbst Schritt für Schritt machen

---

## 1. Was ist ein 3D-Modell in Shopify?

Ein 3D-Modell ist eine Datei, die einen Körper im dreidimensionalen Raum
beschreibt — mit Punkten (Vertices), Flächen (Faces), Texturen (Materialien)
und einem Skelett (Rig). Der Browser kann diese Datei laden, in Echtzeit
rendern und der Nutzer kann sie drehen, zoomen und betrachten.

In unserem Fall ist das eine **GLB-Datei** (Binary glTF, Endung `.glb`):

- Kompaktes Standardformat, vom 3D-Gremium Khronos definiert
- Enthält Mesh, Texturen, Materialien und Animationen in einer einzigen Datei
- Kann von allen modernen Browsern direkt angezeigt werden (über WebGL)
- Apple unterstützt zusätzlich USDZ — wir nutzen GLB für Web, USDZ später
  für die iOS-App

Eine GLB-Datei ist also wie ein "PDF für 3D-Modelle": ein in sich
geschlossenes Format, das überall funktioniert.

---

## 2. Wie zeigt man ein GLB im Browser?

Wir nutzen **`<model-viewer>`** — eine Web-Komponente von Google.
Sie kapselt die komplette WebGL-Komplexität in einen einzigen HTML-Tag:

```html
<script type="module"
        src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js">
</script>

<model-viewer src="avatar.glb"
              alt="Mein 3D-Avatar"
              camera-controls
              auto-rotate>
</model-viewer>
```

Das ist alles. Drei Zeilen HTML, und der Avatar dreht sich.

**Was `<model-viewer>` automatisch kann:**
- Drehen mit Maus + Touch (Drag/Pinch)
- Auto-Rotation
- Schatten + Beleuchtung (HDR Environment Maps)
- Lazy Loading (lädt erst, wenn sichtbar)
- Accessibility (alt-Text, keyboard navigation)
- AR-Modus (auf iOS und Android)

**Vorteil gegenüber three.js:** Wir müssen keine eigene Render-Schleife,
keine Lichtquellen, keine Kamera-Steuerung programmieren. Google pflegt das
seit Jahren — wir nutzen es nur.

---

## 3. Wo liegen die GLB-Dateien im Shopify-Theme?

Shopify hat zwei Wege, Mediendateien im Theme zu speichern:

### Variante A: Theme-Assets (`assets/`)
GLB-Dateien werden direkt ins Theme-Verzeichnis gelegt. Sie werden über
`{{ 'datei.glb' | asset_url }}` referenziert. Vorteil: versioniert mit
dem Theme, deploybar via CLI/Git. Nachteil: Bei großen Files wird der
Theme-Push langsam.

**→ Diesen Weg nutzen wir für den Prototyp.**

### Variante B: Shopify Files (Admin → Content → Files)
GLB-Dateien werden im Shopify Files-Bereich hochgeladen. Sie bekommen
eine CDN-URL, die in einer URL-Setting im Section-Schema hinterlegt
werden kann. Vorteil: Theme bleibt schlank, Designer können Assets
ohne Code-Push tauschen. Nachteil: Nicht versioniert mit dem Theme.

**→ Diesen Weg nutzen wir später, wenn wir Avaturn-Avatare einbauen.**

In unserer Section gibt es zwei URL-Override-Felder im Schema. Ist
keine URL gesetzt, wird der Theme-Asset als Default genutzt. So können
Sie die GLBs später per Theme-Editor durch Avaturn-Versionen ersetzen,
**ohne eine Zeile Code anzufassen.**

---

## 4. Woher kommen die Avatare?

Es gibt mehrere Quellen für rigged Humanoid-Charaktere:

| Quelle | Lizenz | Realistisch? | Login? |
|---|---|---|---|
| **Mixamo** (Adobe) | Frei, kommerziell, keine Attribution | Standard (X-Bot, Y-Bot, Vanguard) | Account empfohlen, aber nicht zwingend |
| **Ready Player Me** | CC BY-NC-SA (frei) / Partner-Lizenz (kommerziell) | Sehr realistisch, fotobasiert | Pflicht für Partner |
| **Avaturn** | Proprietär, Pro-Plan ab ~800 USD/Monat | Foto-realistisch | Pflicht |
| **Khronos Sample Models** | CC BY 4.0 / Public Domain | Basic / abstrakt | Nein |
| **MakeHuman** | CC0 | Realistisch, Open Source | Nein |
| **Quaternius** | CC0 | Stilisiert / Low-Poly | Nein |

**Für den Prototyp v0.1 nutzen wir Mixamo "Vanguard"** (heruntergeladen
über das three.js examples Repo, MIT-Lizenz für den Code, Adobe-Mixamo-
Lizenz für das Mesh). Diese Wahl bedeutet:

- Keine Login-Frage
- Eindeutige kommerzielle Lizenz
- Bewährter humanoider Body, sofort gerigt
- Sci-Fi-Look — für ein Marketing-Demo akzeptabel

**Für den Prototyp v0.2** (geplant) wechseln wir auf **Avaturn**, weil
dort fotorealistische Avatare aus einem Selfie generiert werden können.
Der Code in der Section bleibt **unverändert** — nur die GLB-URL wird
über das Theme-Editor-Feld getauscht.

---

## 5. Wie macht man "krank" und "gesund" aus EINEM Avatar?

Das ist der Kern der Aufgabe. Beide Avatare müssen denselben Kopf
haben — nur der Körper ändert sich. Das geht über drei Wege:

### Weg 1: Shape Keys / Morph Targets (im GLB enthalten)
Der Avatar enthält interne "Verformungs-Schalter". Per JavaScript wird
ein Slider von 0 (gesund) auf 1 (krank) gefahren. Vorteil: nur EINE
GLB-Datei, fließende Übergänge möglich. Nachteil: Komplexe Vorbereitung
in Blender, JS muss die Morph-Werte setzen.

### Weg 2: Zwei separate GLB-Dateien (unser Weg)
Der Avatar wird in Blender geladen, **modifiziert und exportiert**.
Beim Export sind die Vertices bereits dauerhaft verschoben. Es entstehen
zwei Dateien: `avatar_healthy.glb` und `avatar_sick.glb`. Der Toggle
auf der Webseite tauscht einfach das angezeigte GLB.

**Vorteil:** Einfach, robust, kein JS-Aufwand, jeder Browser kann es.
**Nachteil:** Keine fließenden Übergänge — aber für den Vergleich nicht nötig.

### Weg 3: Live-Deformation per JavaScript
Der Browser modifiziert das Mesh in Echtzeit. Sehr aufwändig, hoher
GPU-Verbrauch — für ein Marketing-Demo absoluter Overkill.

→ **Wir nutzen Weg 2.**

---

## 6. Was sind "Shape Keys" in Blender?

Shape Keys (auch "Morph Targets" genannt) sind benannte Verformungen
eines Meshes, die als Offset zur Basis-Pose gespeichert werden:

```
Basis ────────────►  Vertex an Position (0, 1.2, 0.1)
                        │
"Adipositas" ─────►  Vertex an Position (0, 1.2, 0.18)
                        │
                        ▼
Im Slider 50%:       Vertex an Position (0, 1.2, 0.14)
```

Wir nutzen sie in unserem Blender-Script **nicht** als exportierte
Morph Targets, sondern wir schreiben die Verschiebung **direkt** in
die Vertex-Positionen und exportieren das Ergebnis. Das ist der
einfachste Weg, um zwei separate GLBs zu erzeugen.

---

## 7. Kritische Regel: Das Gesicht NIEMALS anfassen

Der Vergleich funktioniert nur, wenn der Betrachter erkennt, dass es
**derselbe Mensch** ist. Daher gilt im Blender-Script:

```python
# Hard guard: Nie Vertices oberhalb des Halses verformen
if vertex.co.y >= NECK_Y:
    continue  # Skip — face vertex
```

In unserem Vanguard-Modell liegt der Hals bei Y ≈ 1.5. Alle Vertices
darüber bleiben in beiden Varianten exakt gleich. Damit ist garantiert,
dass das Gesicht identisch ist.

Zusätzlich werden die Arme geschützt, indem wir nur Vertices mit
|X| ≤ 0.3 verformen — der Body, nicht die ausgestreckten T-Pose-Arme.

---

## 8. Performance — wie groß darf eine GLB sein?

| Datei | Ladezeit (4G mobil) | Empfehlung |
|---|---|---|
| < 1 MB | < 1 s | Ideal |
| 1 – 4 MB | 1 – 4 s | OK für Hero-Section |
| 4 – 10 MB | 4 – 10 s | Nur mit Lazy Loading |
| > 10 MB | > 10 s | Komprimieren! |

**Unsere GLBs liegen bei 1.4 MB pro Stück** — perfekt für den Hero-Bereich.
Falls eine Datei zu groß wird, kann sie mit dem Tool **`gltf-transform`**
komprimiert werden:

```bash
npx @gltf-transform/cli draco input.glb output.glb
```

Draco-Kompression reduziert Mesh-Daten oft auf 30 % der Originalgröße.
Texturen werden separat optimiert (`webp`, `etc1s`).

---

## 9. Brand-Konsistenz und Disclaimer

Jede medizinische Visualisierung in einer kommerziellen Praxis-/Startup-
Website **muss** klarstellen, dass es sich nicht um ein zugelassenes
Medizinprodukt handelt. Daher ist im unteren Rand der Section folgender
Hinweis fest verankert:

> Beispielhafte Visualisierung — kein Medizinprodukt, keine Diagnose.

Das ist kein "Nice-to-have", sondern **Pflicht** unter dem Medizin-
produkterecht (MDR Article 7) und der EU-Health-Claims-Verordnung.

---

## Weitere Lektüre

- [Google model-viewer Dokumentation](https://modelviewer.dev) — alle
  Attribute, Slots, Events
- [Khronos glTF Spezifikation](https://www.khronos.org/gltf/) — das
  Dateiformat
- [Mixamo Auto-Rigger](https://www.mixamo.com) — Adobe-Plattform für
  rigged Charaktere
- [Avaturn Docs](https://docs.avaturn.me) — fotobasierte Avatare

---

*Tutorial erstellt: 2026-04-07 · Juvantis DHT-Avatar-Prototyp v0.1*
