# Shopify Template-Bridge — Trunk-Daten in Custom-Sections

> **Zuletzt aktualisiert:** 2026-04-22 (Erstanlage nach content-bridge-v1 Option B)
> **Vorläufer:** `06-shopify-admin-rest-product-sync.md` (Produkt-Push)
> **Pattern-Referenz:** `Nexus/_memory/patterns/shopify-template-bridge.md`

---

## Warum dieses Tutorial?

Produkt-Push über die Admin-REST-API ist bekannt (Tutorial 06). Für **Pages mit
komplexem Design** reicht das nicht — weil eine Shopify-Page als `body_html`
in eine generische `.rte`-Container-Section gerendert wird. Das Theme-Layout
geht verloren.

Lösung: statt `body_html` wird das **Theme-Template-JSON**
(`templates/page.<slug>.json`) gepushst. Darin liegen Section-Settings und
Block-Daten, die die Custom-Section im Theme rendert.

## Drei Bausteine

Die Template-Bridge besteht aus drei Teilen, die zusammenspielen:

1. **Custom-Section im Theme** — Liquid-Datei mit `{% schema %}`, die Blocks
   (z.B. `team_member`, `value`) akzeptiert und rendert.
2. **Template-JSON** — `templates/page.<slug>.json`, das der Page zugeordnet wird
   und die Section mit Settings+Blocks füttert.
3. **Admin-API-Push** — `PUT /admin/api/<v>/themes/<theme-id>/assets.json` mit
   `{ asset: { key, value } }` schreibt die JSON-Datei ins Theme.

## Mini-Beispiel

### 1. Section im Theme (existiert schon, hier nur zur Referenz)

```liquid
{# sections/juvantis-ueber-uns.liquid #}
<section id="UeberUns-{{ section.id }}">
  <h1>{{ section.settings.heading }}</h1>
  {%- for block in section.blocks -%}
    {%- if block.type == 'team_member' -%}
      <div>{{ block.settings.name }} — {{ block.settings.role }}</div>
    {%- endif -%}
  {%- endfor -%}
</section>

{% schema %}
{
  "name": "Juvantis: Über uns",
  "settings": [
    { "type": "text", "id": "heading" }
  ],
  "blocks": [
    { "type": "team_member", "settings": [
        { "type": "text", "id": "name" },
        { "type": "text", "id": "role" }
    ]}
  ]
}
{% endschema %}
```

### 2. Template-JSON (wird durch den Push erzeugt)

```json
{
  "sections": {
    "about": {
      "type": "juvantis-ueber-uns",
      "settings": { "heading": "Die Menschen hinter Sanexio" },
      "blocks": {
        "team_stracke": {
          "type": "team_member",
          "settings": { "name": "Dr. Stracke", "role": "Praxisinhaber" }
        }
      },
      "block_order": ["team_stracke"]
    }
  },
  "order": ["about"]
}
```

### 3. Page-Settings ergänzen

```
PUT /admin/api/<v>/pages/<id>.json
{ "page": { "id": <id>, "template_suffix": "<slug>", "body_html": "" } }
```

Damit Shopify beim Rendern der Page das neue Template wählt.

## In Cortex-Web komplett integriert

```bash
# 1. Trunk-YAML pflegen
vim trunk/content/pages/_shared/ueber-uns.yaml   # views.juvantis.* + team[]

# 2. Push
cw-transfer push shopify:template trunk/content/pages/_shared/ueber-uns.yaml
#    → build-template.mjs (lädt YAML, validiert, rendert template JSON)
#    → template-to-shopify.mjs (backup existierender Asset, dann PUT)

# 3. template_suffix + body_html leer (nur beim Erst-Setup pro Page)
curl -s -X PUT -H "X-Shopify-Access-Token: $SHOPIFY_ADMIN_TOKEN" \
  -d '{"page":{"id":<id>,"template_suffix":"<slug>","body_html":""}}' \
  "https://${SHOPIFY_STORE}/admin/api/2026-04/pages/<id>.json"
```

## Scope-Voraussetzung

Die Shopify-Custom-App muss `read_themes` + `write_themes` erlauben. Standard-
Produkt-Scope reicht nicht. Re-Auth-Workflow siehe
`Nexus/_memory/patterns/shopify-oauth-scope-iteration.md`.

## Wann dieses Pattern passt

**Ja:** Eine Page braucht ein spezifisches, wiederkehrendes Layout (Team-Seite,
Über-uns, Leistungen-Hub, Partnerpraxis).

**Nein:** Reine Textseiten (Impressum, DSGVO) — da reicht der einfachere
Content-Push (`sync-page-shopify.sh`).

**Nein:** Seiten, die nur im Admin editiert werden sollen — der nächste Push
überschreibt alles (CW-001).

## Stolpersteine aus eigener Erfahrung

| Fehler | Symptom | Ursache | Fix |
|--------|---------|---------|-----|
| 403 bei Theme-Asset-API | „requires merchant approval for read_themes scope" | App hat Scope nicht | authorize.sh erweitern, re-auth |
| Page zeigt weiterhin altes Layout | template_suffix nicht gesetzt | Page nutzt `page.json` default | `template_suffix: "<slug>"` setzen |
| Duplikat-Content (oben nackt, unten schön) | body_html nicht geleert | Default main-page section rendert body_html | `body_html: ""` via PUT setzen |
| Icons falsch / Default-Stern | Value-Title trifft Case-Statement nicht | Liquid-Section hat hartcodierte Icons | Trunk-Titel an Theme anpassen oder Section erweitern |

## Weiterführend

- Pattern-Dok: `Nexus/_memory/patterns/shopify-template-bridge.md`
- Architektur (wann dieses Pattern, wann andere): `Cortex-Web/specs/cross-site-transfer/PATTERNS.md`
- Orchestrator-Reference: `Cortex-Web/tools/cw-transfer help`
