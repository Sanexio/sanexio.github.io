# Shopify: Liquid-Grundlagen

## Was lernst du hier?

Shopify ist eine E-Commerce-Plattform. Dein Juvantis hat einen Shopify-Shop (für Merchandise, Health-Tracker, etc.). Mit Liquid (Shopify's Template-Sprache) kannst du:

- Die Website-Struktur anpassen
- Dynamische Inhalte anzeigen (Produkte, Preise, Kundeninfo)
- Custom-Funktionen einbauen
- Auf Shopify-Daten zugreifen

**Liquid ist einfach:** Es ist eine Template-Sprache, nicht vollständiges Programmieren. Du brauchst nur die Basics.

---

## Was ist ein Shopify Theme?

Ein Shopify Theme ist eine Vorlage für deinen Shop. Es besteht aus:

```
Theme/
├── sections/
│   ├── header.liquid
│   ├── footer.liquid
│   ├── product-carousel.liquid
│   └── ...
├── templates/
│   ├── product.liquid         ← Wie sieht eine Produkt-Seite aus?
│   ├── collection.liquid      ← Wie sieht eine Kategorie-Seite aus?
│   ├── cart.liquid            ← Warenkörb
│   └── ...
├── snippets/
│   ├── product-card.liquid    ← Kleine Komponenten (wiederverwendbar)
│   └── ...
├── assets/
│   ├── style.css
│   └── script.js
└── config/
    └── settings_schema.json   ← Theme-Einstellungen
```

---

## Liquid: Die Syntax

### Text ausgeben (Output)

```liquid
{{ shop.name }} verkauft {{ product.title }}
```

Wenn der Shop "Juvantis" heißt und das Produkt "Health Tracker":
```
Juvantis verkauft Health Tracker
```

Das `{{ }}` bedeutet: "Gib den Wert der Variable aus."

**Wichtig:** `{{ customer.first_name }}` gibt nur den **Vornamen** aus, nicht den vollen Namen.
Wenn ein Kunde als Vorname "Maria" und Nachname "Müller" registriert ist:
- `{{ customer.first_name }}` → `Maria`
- `{{ customer.last_name }}` → `Müller`
- `{{ customer.name }}` → `Maria Müller` (Vor- und Nachname)

---

### Variablen

```liquid
{{ product.title }}            ← Produkt-Name
{{ product.price }}            ← Preis (in Cents, z.B. 2999 = 29.99)
{{ product.featured_image }}   ← Produktbild
{{ shop.name }}                ← Dein Shop-Name
{{ customer.email }}           ← E-Mail des angemeldeten Kunden
```

---

### Filter: Werte ändern

Filter verändern Werte mit `|`:

```liquid
{{ "hello" | upcase }}
→ HELLO

{{ 2999 | divided_by: 100 }}
→ 29.99

{{ product.title | downcase }}
→ (Titel in Kleinbuchstaben)

{{ "2024-01-15" | date: "%d.%m.%Y" }}
→ 15.01.2024
```

**Häufige Filter:**
```liquid
| upcase              ← Großbuchstaben
| downcase           ← Kleinbuchstaben
| capitalize         ← Erstes Zeichen groß
| size               ← Länge (Zeichen oder Array-Größe)
| date: "%d.%m.%Y"   ← Datum formatieren
| money              ← Geld formatieren (mit €, $, etc.)
| divided_by: 100    ← Mathematik
| plus: 10           ← Addieren
| minus: 5           ← Subtrahieren
```

---

### if/else — Bedingungen

```liquid
{% if customer %}
  <p>Hallo {{ customer.first_name }}!</p>
{% else %}
  <p>Bitte melden Sie sich an.</p>
{% endif %}
```

Das `{% %}` bedeutet: "Führe einen Befehl aus" (nicht: "Gib aus").

**Vergleiche:**
```liquid
{% if product.price > 10000 %}
  Teuer!
{% elsif product.price > 5000 %}
  Mittleres Preis-Segment
{% else %}
  Preiswert
{% endif %}
```

---

### for — Schleifen

```liquid
<ul>
  {% for product in collection.products %}
    <li>{{ product.title }} - {{ product.price | money }}</li>
  {% endfor %}
</ul>
```

Das gibt aus:
```
<ul>
  <li>Avatar Pro - €99.99</li>
  <li>Health Tracker - €49.99</li>
  <li>T-Shirt - €24.99</li>
</ul>
```

**Mit Limit (nur die ersten 5):**
```liquid
{% for product in collection.products limit: 5 %}
  ...
{% endfor %}
```

**Mit offset (überspringe die ersten 2):**
```liquid
{% for product in collection.products offset: 2 limit: 5 %}
  ...
{% endfor %}
```

---

### assign — Variablen erstellen

```liquid
{% assign product_name = product.title %}
{% assign price_in_euros = product.price | divided_by: 100 | money %}

<h1>{{ product_name }}</h1>
<p>Preis: {{ price_in_euros }}</p>
```

Das ist hilfreich für komplexe Werte.

---

## Sections: Wiederverwendbare Bausteine

Eine Section ist ein Baustein, den du überall einbauen kannst. Sie hat:

1. **HTML/Liquid** (die Struktur)
2. **CSS** (das Aussehen)
3. **JavaScript** (die Interaktion)
4. **JSON Schema** (die Einstellungen)

### Einfache Section: Featured Product

```liquid
<!-- sections/featured-product.liquid -->

<div class="featured-product">
  {% if section.settings.product != blank %}
    {% assign product = section.settings.product %}

    <div class="product-image">
      <img src="{{ product.featured_image | image_url: width: 500 }}" alt="{{ product.title }}">
    </div>

    <div class="product-info">
      <h2>{{ product.title }}</h2>
      <p class="price">{{ product.price | money }}</p>
      <p class="description">{{ product.description | strip_html }}</p>

      <button class="btn-add-to-cart">
        In den Warenkorb
      </button>
    </div>
  {% endif %}
</div>

<style>
  .featured-product {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
    padding: 2rem;
  }

  .product-image img {
    max-width: 100%;
    height: auto;
  }

  .price {
    font-size: 1.5rem;
    font-weight: bold;
    color: #028090;
  }
</style>

<script>
  document.querySelector('.btn-add-to-cart').addEventListener('click', function() {
    alert('Product added to cart!');
  });
</script>

{% schema %}
{
  "name": "Featured Product",
  "settings": [
    {
      "type": "product",
      "id": "product",
      "label": "Produkt wählen"
    }
  ]
}
{% endschema %}
```

**Das Schema** ermöglicht es Shopify-Admin, Inhalte zu bearbeiten (ohne Code zu schreiben).

---

## Templates: Seiten-Strukturen

Templates definieren, wie bestimmte Seiten aussehen:

### product.liquid — Produkt-Seite

```liquid
<!-- templates/product.liquid -->

<div class="product-page">
  <div class="product-gallery">
    <img src="{{ product.featured_image | image_url: width: 800 }}" alt="{{ product.title }}">

    {% if product.images.size > 1 %}
      <div class="thumbnails">
        {% for image in product.images limit: 5 %}
          <img src="{{ image | image_url: width: 100 }}" alt="">
        {% endfor %}
      </div>
    {% endif %}
  </div>

  <div class="product-details">
    <h1>{{ product.title }}</h1>

    <div class="price">
      {% if product.compare_at_price > product.price %}
        <span class="original">{{ product.compare_at_price | money }}</span>
        <span class="current">{{ product.price | money }}</span>
      {% else %}
        {{ product.price | money }}
      {% endif %}
    </div>

    <p class="description">{{ product.description }}</p>

    <form method="post" action="/cart/add">
      <input type="hidden" name="id" value="{{ product.variants.first.id }}">
      <input type="number" name="quantity" value="1" min="1">
      <button type="submit" class="btn-buy">Kaufen</button>
    </form>
  </div>
</div>
```

---

### collection.liquid — Kategorie-Seite

```liquid
<!-- templates/collection.liquid -->

<h1>{{ collection.title }}</h1>
<p>{{ collection.description }}</p>

<div class="filters">
  {{ collection | default_pagination_per_page: 12 }}
</div>

<div class="products-grid">
  {% for product in collection.products %}
    <div class="product-card">
      <a href="{{ product.url }}">
        <img src="{{ product.featured_image | image_url: width: 300 }}" alt="">
        <h3>{{ product.title }}</h3>
        <p class="price">{{ product.price | money }}</p>
      </a>
    </div>
  {% endfor %}
</div>

{% if collection.products.size == 0 %}
  <p>Keine Produkte in dieser Kategorie.</p>
{% endif %}
```

---

## Snippets: Kleine wiederverwendbare Komponenten

Ein Snippet ist ein kleines Code-Fragment, das du überall einbauen kannst:

```liquid
<!-- snippets/product-card.liquid -->

<div class="product-card">
  <a href="{{ product.url }}">
    <img src="{{ product.featured_image | image_url: width: 300 }}" alt="{{ product.title }}">
    <h3>{{ product.title }}</h3>
    <p class="price">{{ product.price | money }}</p>

    {% if product.available %}
      <span class="badge-available">Verfügbar</span>
    {% else %}
      <span class="badge-sold-out">Ausverkauft</span>
    {% endif %}
  </a>
</div>
```

Und dann in einer Collection oder Homepage nutzen:

```liquid
{% for product in collection.products %}
  {% include 'product-card', product: product %}
{% endfor %}
```

Das ist viel sauberer als den Code zu duplizieren!

---

## Der Juvantis-Shopify-Workflow

### Wie arbeiten wir zusammen?

Bei Juvantis arbeiten Du und Claude als Team. Du sagst, was geändert werden soll, Claude setzt es um. Hier ist der Ablauf:

```
Du (in Cowork oder Claude Code):     Claude:
"Erstelle eine Preise-Seite"    →    Erstellt sections/juvantis-pricing.liquid
                                      Erstellt templates/page.preise.json
                                      Pusht beides zum Shopify Store
                                      Verifiziert mit curl
                                 →    Gibt Dir Anleitung für manuelle Schritte
Du (im Shopify Admin):
  Seite erstellen, Template zuweisen, Navigation ergänzen
```

### Der automatisierte Prozess (was Claude im Hintergrund tut)

**Schritt 1: Datei erstellen/bearbeiten**
Claude bearbeitet die Liquid-Datei direkt im Ordner `website/theme/`.

**Schritt 2: Automatischer Push zu Shopify**
Ein sogenannter "PostToolUse-Hook" erkennt jede Änderung an Dateien in `website/theme/`
und pusht sie automatisch zum Shopify Store. Das passiert im Hintergrund — du musst
nichts tun. Der Hook funktioniert so:

1. Claude speichert eine Datei (z.B. `sections/juvantis-pricing.liquid`)
2. Der Hook erkennt: "Das ist eine Theme-Datei"
3. Er führt automatisch aus:
   ```bash
   npx shopify theme push --store medzpoint --theme 181128757515 \
     --only sections/juvantis-pricing.liquid --allow-live
   ```
4. Die Änderung ist sofort auf sanexio.eu live

**Schritt 3: Verifizierung**
Claude prüft mit `curl` ob die Änderung live ist:
```bash
curl -s 'https://sanexio.eu/pages/preise' | grep -c 'juvantis-pricing'
```
Warum `curl` und nicht den Browser? Weil Shopify einen 15-Minuten-Cache hat.
`curl` umgeht diesen Cache und zeigt immer den aktuellen Stand.

**Schritt 4: Git Commit (auf Anfrage)**
Wenn du sagst "Committe das", macht Claude:
```bash
cd website/theme
git add sections/juvantis-pricing.liquid templates/page.preise.json
git commit -m "Add pricing page with Juvantis pricing section"
git push origin shopify-theme
```
Das speichert die Änderung in der Versionshistorie auf GitHub, so dass nichts verloren geht.

### Was Du manuell im Shopify Admin machst

Einige Dinge kann Claude NICHT automatisieren, weil das Shopify CLI dafür keine
Berechtigung hat. Diese Schritte führst du im Browser durch:

| Aktion | Wo im Admin | Anleitung |
|--------|-------------|-----------|
| Neue Seite erstellen | Seiten → "Seite hinzufügen" | Titel eingeben, Inhalt leer lassen |
| Template zuweisen | Auf der Seite → rechte Spalte → "Vorlage" | Custom Template aus Dropdown wählen |
| Navigation bearbeiten | Onlineshop → Navigation → Hauptmenü | Menüeintrag hinzufügen |
| Bilder hochladen | Einstellungen → Dateien | Drag & Drop |
| Blog-Beiträge | Blogbeiträge → Erstellen | Titel, Text, Bild |

Claude gibt dir für jeden dieser Schritte eine **exakte, nummerierte Anleitung**,
damit du genau weißt, wo du klicken musst.

### Wenn Du selbst Code bearbeiten willst (in Cursor)

Falls du mal selbst eine Liquid-Datei anpassen willst:

1. Öffne Cursor und navigiere zu `projects/Juvantis/website/theme/`
2. Öffne die gewünschte Section (z.B. `sections/juvantis-pricing.liquid`)
3. Mach deine Änderung und speichere (`Cmd+S`)
4. Der PostToolUse-Hook pusht automatisch zu Shopify
5. Prüfe auf sanexio.eu ob es passt

Wenn etwas schiefgeht, kannst du jederzeit den letzten Stand zurückholen:
```bash
# Letzten Push rückgängig machen (Git)
git checkout -- sections/juvantis-pricing.liquid

# Oder den aktuellen Live-Stand vom Store holen
source ~/.nvm/nvm.sh
npx shopify theme pull --store medzpoint --theme 181128757515 \
  --only sections/juvantis-pricing.liquid
```

---

## Tipps und Tricks

### Global Available Objekte in Liquid

Du kannst diese überall nutzen:

```liquid
{{ shop.name }}               ← Dein Shop-Name
{{ shop.currency }}           ← Währung (EUR, USD, etc.)
{{ customer.first_name }}     ← Angemeldeter Kunde
{{ product }}                 ← Aktuelles Produkt (in product.liquid)
{{ collection }}              ← Aktuelle Kategorie (in collection.liquid)
{{ cart }}                    ← Aktueller Warenkorb
```

---

### HTML ausgeben (ohne Escaping)

Manchmal musst du HTML-Tags ausgeben:

```liquid
{% assign html = "<strong>Wichtig!</strong>" %}
{{ html }}              ← Gib <strong>...</strong> aus (escaped)
{{ html | raw }}        ← Gib <strong>...</strong> aus (nicht escaped)
```

---

### Debugging: Werte anschauen

```liquid
{{ product | json }}
```

Das gibt alle Eigenschaften des Produkts in JSON-Form aus. Hilfreich um zu sehen, was du nutzen kannst!

---

## Häufige Fehler

### Fehler: "Unerwartete Ausgabe oder Bilder"

**Grund:** Wahrscheinlich ein Syntax-Fehler im Liquid-Code.

**Lösung:**
1. Shopify Admin öffnen
2. Online Store → Themes
3. Auf deinen Theme klicken
4. "Edit Code"
5. Schau die Console (unten) auf Fehler

---

### Fehler: "Bild wird nicht angezeigt"

**Grund:** Falsche `image_url` oder `image_img_url` Filter.

**Lösung:**
```liquid
<!-- Falsch -->
<img src="{{ product.featured_image }}">

<!-- Richtig -->
<img src="{{ product.featured_image | image_url: width: 500 }}" alt="">
```

---

## Zusammenfassung: Liquid Cheat Sheet

| Code | Beispiel |
|------|----------|
| `{{ var }}` | `{{ product.title }}` |
| `{{ var \| filter }}` | `{{ price \| money }}` |
| `{% if ... %}` | `{% if product.available %}` |
| `{% for x in y %}` | `{% for product in collection.products %}` |
| `{% assign x = y %}` | `{% assign name = product.title %}` |
| `{% include 'snippet' %}` | `{% include 'product-card', product: p %}` |
| `{{ var \| json }}` | Debug: alle Eigenschaften anzeigen |

---

## Zusammenfassung: Was du wissen musst

1. **Liquid ist die Template-Sprache** von Shopify — `{{ }}` gibt Werte aus, `{% %}` führt Befehle aus
2. **Sections** sind die Bausteine deiner Seiten — jede hat HTML, CSS und ein Schema
3. **Templates** bestimmen welche Sections auf welcher Seite erscheinen
4. **Snippets** sind kleine wiederverwendbare Code-Fragmente
5. **Claude macht den Code** — du gibst die Richtung vor und prüfst das Ergebnis
6. **Der PostToolUse-Hook** pusht jede Änderung automatisch live
7. **Manuelle Schritte** (Seiten erstellen, Navigation, Templates zuweisen) machst du im Shopify Admin

### Häufige Fragen

**Muss ich Liquid selbst schreiben können?**
Nein. Claude schreibt den Code. Aber es hilft, die Grundlagen zu verstehen, damit du
weißt was passiert und gezielter sagen kannst was du willst.

**Was passiert wenn etwas kaputt geht?**
Alles ist in Git versioniert. Claude kann jede Änderung rückgängig machen.
Im schlimmsten Fall: `git checkout` auf die letzte funktionierende Version.

**Kann ich im Shopify Admin direkt editieren?**
Ja, über "Customize Theme" kannst du Texte und Bilder ändern. Aber Struktur-Änderungen
(neue Sections, Layouts) macht Claude im Code — das ist sauberer und nachvollziehbar.

---

*Dieses Tutorial wächst mit dem Projekt. Neue Liquid-Konzepte werden ergänzt, sobald
wir sie in der Praxis brauchen.*
