# 04 — DHT-Avatar anpassen und deployen (Lessons Learned 2026-04-08/09)

> Dieses Tutorial dokumentiert die echte Pipeline, die wir am 8./9. April 2026
> für den Juvantis Digital Health Twin auf sanexio.eu aufgebaut haben — inklusive
> aller Fehler, die ich (Claude) dabei gemacht habe, und wie wir sie gefunden
> und behoben haben. Lesen Sie das, bevor Sie eine ähnliche Pipeline anstoßen,
> oder wenn Sie nachvollziehen wollen, was in einer früheren Session passiert ist.

---

## Was wir am Ende erreicht haben

- **Quelle:** Avaturn-GLB (`~/Downloads/model.glb`, 4.4 MB) mit Multi-Mesh-Aufbau
  (`avaturn_body`, `avaturn_hair_0`, `avaturn_shoes_0`, `avaturn_look_0`,
  `avaturn_look_1`)
- **Zwei Varianten** auf der Live-Seite `sanexio.eu/pages/digital-health-twin`:
  - `avatar_healthy.glb` — Original, unverändert
  - `avatar_sick.glb` — körperlich verformter Geschäftsmann (Bauch/Flanken),
    Texturen identisch, Skelett unverändert
- **Performance:** Beide Files unter 1 MB nach gltf-transform-Optimierung
  (von 4.4 MB → 988 KB / 4.0 MB → 942 KB, ~77 % Reduktion)
- **Loading-Strategie:**
  - `<link rel="preload">` für die initial sichtbare sick-Variante
  - `loading="lazy"` auf beiden `<model-viewer>` (zweite Karte lädt erst beim Toggle)
  - Mobile: ein Modell sichtbar, durch Toggle wechselbar (60 % weniger Initial-Load)

---

## Die Pipeline in einem Bild

```
~/Downloads/model.glb (Avaturn, 4.4 MB)
        │
        │   cp (unverändert)
        ├─────────────────────────► theme/assets/avatar_healthy.glb (4.4 MB)
        │
        │   blender --background --python
        │   build_avaturn_sick.py
        │   (verformt body + look_0 + look_1 in World-Space)
        ▼
   exports/avatar_sick.glb (4.0 MB, 1193 Vertices verformt)
        │
        │   gltf-transform optimize (Texturen → 512 px, KEIN meshopt)
        ▼
   theme/assets/avatar_healthy.glb (988 KB)
   theme/assets/avatar_sick.glb    (942 KB)
        │
        │   shopify-sync.sh assets/avatar_*.glb
        ▼
   Shopify Theme Storage  (Theme-ID 181128757515)
        │
        │   CDN-Propagierung + neuer ?v=...-Hash
        ▼
   sanexio.eu/cdn/shop/t/15/assets/avatar_*.glb?v=...
```

---

## Die kritischen Fehler — und was wir daraus gelernt haben

### Fehler 1: `shopify-sync.sh` ignorierte Binärdateien still

**Was passiert ist:** Im Auto-Modus (`./shopify-sync.sh push` ohne Argumente)
filtert das Skript geänderte Dateien per `git diff` durch eine Whitelist:

```bash
# ALT (gebrochen):
grep -E '\.(liquid|json|css|js)$'
```

`.glb` war nicht in der Liste — Binärassets wurden **ohne Fehlermeldung
übersprungen**. Mehrere Pushes meldeten "Theme upload complete", aber nur
die Liquid-/JSON-Dateien gingen wirklich raus. Auf dem CDN lagen weiterhin
die alten GLBs.

**Fix (commited):**
```bash
grep -E '\.(liquid|json|css|js|glb|gltf|png|jpe?g|webp|svg|mp4|webm|woff2?|ttf|otf)$'
```

**Notlösung, falls es wieder auftritt:** Pfad explizit übergeben — der Path-Modus
(`shopify-sync.sh assets/avatar_sick.glb`) hat die Whitelist nie benutzt:

```bash
bash website/shopify-sync.sh assets/avatar_sick.glb assets/avatar_healthy.glb
```

**Erkenntnis:** Verifikation darf nicht "Tool sagte success" sein. Immer
Hash lokal vs CDN vergleichen.

---

### Fehler 2: Vertex-Verformung im falschen Koordinatensystem

**Was passiert ist:** Mein erstes Verformungs-Skript verwendete fest verdrahtete
Werte wie `belly_center_y=1.10` (in Metern, mit Y nach oben gedacht). Tatsächlich
ist das Mixamo-Vanguard-Mesh im Object-Space:

- in **cm**, nicht m
- mit **Y als vertikaler Achse, INVERTIERT** (Kopf bei y=−183, Boden bei y=0)
- die Skalierung auf m passiert über die Parent-Armature (`scale=0.01`)

Mein Filter schloss damit **jeden einzelnen Vertex** aus → null Veränderung,
aber das Skript meldete "fertig". Hätte ich die Vertex-Anzahl der modifizierten
Punkte mitloggen lassen, wäre der Bug in 5 Sekunden sichtbar gewesen.

**Lösung:** Verformung im **World-Space** (gltf-Konvention: Z up, −Y vorne).
Pro Vertex:

```python
M = mesh_obj.matrix_world
M_inv_3 = M.to_3x3().inverted()
world_co = M @ v.co              # Object → World
# ... Filter und Push-Vektor in World-Koordinaten ...
local_d = M_inv_3 @ wd            # World-Push → Object-Push
v.co += local_d                   # in Object-Space anwenden
```

Das ist robust gegen cm/m, Y-up/Z-up, Parent-Skalierung — egal wie das Mesh
exportiert wurde.

**Erkenntnis:** Bei jeder geometrischen Operation: Vertex-Anzahl modifizierter
Punkte und Bounds vor/nach loggen, nie blind vertrauen.

---

### Fehler 3: Falscher Source-Avatar verwendet

**Was passiert ist:** Es lag ein altes `DHT/juvantis-ios/Blender/models/avatar_base.glb`
herum (Mixamo Vanguard Soldier in Tarnung). Mein Build-Skript benutzte **das**
als Source und produzierte einen verformten Soldier mit Helm und Tactical-Vest
für die DHT-Section — was inhaltlich völliger Unsinn für eine Arzt-Marke ist.
Der echte Avaturn-Avatar lag die ganze Zeit in `~/Downloads/model.glb` und
ich hatte ihn schlicht nicht gefunden, weil ich nur in `Blender/models/`
geschaut hatte.

**Lösung:** Filesystem-weite Suche statt nur Standard-Pfade:
```bash
find ~/Downloads ~/Desktop ~/Documents \
     "~/Library/CloudStorage/GoogleDrive-team@sanexio.de/Meine Ablage" \
     -name "*.glb" -type f 2>/dev/null \
  | while read f; do
      echo "$(stat -f%z "$f")  $(md5 -q "$f")  $f"
    done | sort -n
```

Avaturn-Modelle erkennt man an den Material-Namen: `avaturn_body_material`,
`avaturn_hair_*_material`, `avaturn_look_*_material`, `avaturn_shoes_*_material`.

**Erkenntnis:** Bevor man eine Pipeline auf eine Source-Datei loslässt, **immer**
verifizieren, ob das wirklich die richtige Datei ist (Material-Namen +
Mesh-Aufbau prüfen).

---

### Fehler 4: Eevee-Render und Texture-Extraktion gelogen

**Was passiert ist:** Mein Eevee-NEXT-Render headless auf macOS und mein
Python-Texture-Extractor zeigten beide übereinstimmend "Soldier mit Tarnung"
für eine Datei, die im Browser eindeutig als angezogener Mann angezeigt wurde.
Daraufhin habe ich behauptet, der Geschäftsmann existiere "nirgends im Theme"
— obwohl er die ganze Zeit korrekt unter `avatar_healthy.glb` lag.

**Wahrscheinliche Ursachen:**
- GLBs können mehrere Image-Slots enthalten, von denen nur ein Teil
  tatsächlich vom verwendeten Material referenziert wird. Mein Extractor
  zog alle Image-Buffer raus, ohne die Material-Pipeline zu folgen.
- Eevee NEXT auf macOS headless hat bekannte Material-Loading-Issues.

**Erkenntnis:** Wenn die User-Browser-Beobachtung und die Tool-Diagnose
widersprechen, gewinnt **immer** die User-Beobachtung. Nie dem User
"erklären", dass seine Beobachtung falsch ist.

---

### Fehler 5: Default-Icosphere im Avaturn-File verzerrte Bounds

**Was passiert ist:** Der erste Avaturn-Build hatte `foot_z = -1.000` und
`belly_z = 0.574` — also Bauch im **Schritt-Bereich**, nicht am Bauch.
Folge: alle 1072 Schuh-Vertices wurden verformt, nur 22 Body-Vertices.

**Ursache:** Im GLB war ein `Icokugel`-Mesh (Default-Blender-Sphere von -1
bis +1) als Helper enthalten. Mein "World-Bounds aus allen Meshes"-Loop hat
die Kugel mitgezählt → falscher Boden bei Z=−1.

**Fix:** Helper-Meshes ausfiltern und Bounds nur aus dem **Body-Mesh** berechnen:

```python
def is_avatar_mesh(o):
    n = o.name.lower()
    if "icokugel" in n or "icosphere" in n: return False
    return True

meshes = [o for o in bpy.data.objects
          if o.type == "MESH" and o.data.vertices and is_avatar_mesh(o)]
body_mesh = next((o for o in meshes if "body" in o.name.lower()), meshes[0])
```

**Erkenntnis:** Bounds immer aus dem **anatomisch korrekten** Mesh berechnen,
nicht aus "alle Meshes zusammen".

---

## So machen Sie es selbst (oder lassen es Claude machen)

### Voraussetzungen
- `/Applications/Blender.app/Contents/MacOS/Blender` (Blender 4.5+)
- Node.js + npm (`shopify` CLI für Theme-Push)
- Eine Avaturn-GLB in `~/Downloads/` oder anderswo lokal

### Schritt 1 — Source vorbereiten
```bash
ls -la ~/Downloads/model.glb       # Existenz prüfen
md5 -q ~/Downloads/model.glb       # Hash merken
```

### Schritt 2 — Healthy = unveränderte Kopie
```bash
cp ~/Downloads/model.glb \
   "~/Library/CloudStorage/GoogleDrive-team@sanexio.de/Meine Ablage/Claude-OS/projects/Juvantis/website/theme/assets/avatar_healthy.glb"
```

### Schritt 3 — Sick = verformte Variante (headless Blender)
Skript: `Juvantis/DHT/juvantis-ios/Blender/scripts/build_avatar_variants.py`
(World-Space, axis-agnostisch, multi-mesh-fähig)

```bash
/Applications/Blender.app/Contents/MacOS/Blender --background \
  --python scripts/build_avatar_variants.py -- \
    --base ~/Downloads/model.glb \
    --out  /tmp/avatar_out/
```

Das Skript loggt:
- Welche Meshes erkannt wurden
- World-Bounds (foot_z, head_z, height)
- Wie viele Vertices verformt wurden (pro Mesh)
- Maximale Verschiebung in Metern

**Wenn `touched 0/...`:** Bounds-Berechnung schief, prüfen ob ein Helper-Mesh
durchgerutscht ist.

### Schritt 4 — Optimieren (4 MB → ~1 MB)
```bash
bash _lib/glb/optimize_glb.sh \
  /tmp/avatar_out/avatar_sick.glb \
  Juvantis/website/theme/assets/avatar_sick.glb \
  512
```

Texture-Resize auf 512 px, **kein** meshopt (laut Memory bricht das den
unpkg-model-viewer).

### Schritt 5 — Push zum Shopify-Theme
```bash
cd Juvantis/website
bash shopify-sync.sh assets/avatar_healthy.glb assets/avatar_sick.glb
```

### Schritt 6 — VERIFIKATION (Pflicht!)
```bash
# 1. Lokale Hashes
md5 -q theme/assets/avatar_healthy.glb theme/assets/avatar_sick.glb

# 2. Live-CDN-URL aus aktueller Page-Version holen
PAGE=$(curl -s "https://sanexio.eu/pages/digital-health-twin?$(date +%s)$(uuidgen)")
SU=$(echo "$PAGE" | grep -oE '//[^"]*avatar_sick\.glb\?v=[0-9]*' | head -1)
HU=$(echo "$PAGE" | grep -oE '//[^"]*avatar_healthy\.glb\?v=[0-9]*' | head -1)

# 3. Live-Files holen und hashen
curl -sL "https:$HU" -o /tmp/live_h.glb && md5 -q /tmp/live_h.glb
curl -sL "https:$SU" -o /tmp/live_s.glb && md5 -q /tmp/live_s.glb

# 4. Vergleich: Live-Hash MUSS identisch sein zum lokalen Hash
```

Wenn Mismatch: vermutlich noch CDN-Cache-Lag → 30 Sekunden warten,
Page mit neuem Cache-Bust holen, nochmal Hash holen.

---

## Kontroll-Stellen für die Adipose-Stärke

In `build_avatar_variants.py` (oder `/tmp/build_avaturn_sick.py`):

| Parameter | Wert (akt.) | Wirkung |
|---|---|---|
| `BELLY_FRAC` | 0.55 | Höhe des Bauchschwerpunkts (0=Boden, 1=Kopf) |
| `NECK_FRAC` | 0.78 | Über dieser Höhe wird **nichts** angefasst (Hals/Kopf-Schutz) |
| `RADIUS_FRAC` | 0.22 | Vertikale Halbweite des Gauss-Bereichs |
| `ARMS_X_FRAC` | 0.25 | `|x| > arms_x_frac * height` → Arm, nicht anfassen |
| `BELLY_BULGE` | 0.18 m | Vorne-Wölbung am Maximum |
| `BACK_BULGE` | 0.07 m | Rücken-Rundung |
| `SIDE_BULGE` | 0.13 m | Flanken-Verbreiterung pro Seite |

**"Soll noch dicker"** → `BELLY_BULGE 0.18 → 0.28`, `SIDE_BULGE 0.13 → 0.18`
**"Zu dick / Kleidung clipped"** → `BELLY_BULGE 0.18 → 0.12`, `SIDE_BULGE 0.13 → 0.08`

Danach Schritte 3–6 wiederholen.

---

## Was Sie Claude sagen können

Wenn Sie möchten, dass Claude eine erneute Avatar-Anpassung macht:

> "Mach den Avatar im DHT-Vergleich noch dicker (BELLY_BULGE 0.25). Source ist
> `~/Downloads/model.glb`. Push, optimieren, Hash-Verifikation, fertig."

Claude weiß dann:
1. Build-Skript steht in `Juvantis/DHT/juvantis-ios/Blender/scripts/`
2. World-Space-Verformung, Helper-Mesh-Filter, Multi-Mesh-Loop
3. Optimizer in `_lib/glb/optimize_glb.sh` mit 512 px
4. Push via `shopify-sync.sh assets/avatar_*.glb` (Path-Modus)
5. Hash-Verifikation lokal vs CDN-`?v=`-URL
6. Bei Mismatch: Cache-Lag abwarten, nochmal prüfen

---

## Verwandte Dateien

- `_lib/glb/optimize_glb.sh` — gltf-transform-Wrapper für Texture-Reduktion
- `projects/Juvantis/DHT/juvantis-ios/Blender/scripts/build_avatar_variants.py` —
  Build-Skript (axis-agnostisch, multi-mesh-fähig)
- `projects/Juvantis/website/shopify-sync.sh` — Theme-Push mit erweiterter
  Whitelist (jetzt inkl. .glb)
- `projects/Juvantis/website/theme/sections/dht-avatar-compare.liquid` —
  model-viewer-Section mit Lazy-Loading + Preload
- `_memory/feedback_verify_endtoend.md` — Memory-Regel zur End-to-End-Verifikation
- `_memory/feedback_dont_trust_my_renders.md` — Memory-Regel: User-Beobachtung
  schlägt Tool-Diagnose
- `_memory/reference_shopify_sync_glb.md` — Doku zum Whitelist-Bug-Fix
