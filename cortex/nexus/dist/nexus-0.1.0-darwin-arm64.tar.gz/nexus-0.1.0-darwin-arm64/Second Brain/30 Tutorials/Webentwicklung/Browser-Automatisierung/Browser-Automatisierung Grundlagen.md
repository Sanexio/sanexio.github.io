---
type: tutorial
aliases: [Browser-Automation, Web-Pilot Tutorial-Übersicht, Headless-Browser]
tags:
  - tutorial
  - webentwicklung
  - browser-automation
  - web-pilot
  - cortex-agent
source: Second Brain/30 Tutorials/Webentwicklung/Browser-Automatisierung/
---

# Browser-Automatisierung — Tutorial-Übersicht

> Quellpfad: `Second Brain/30 Tutorials/Webentwicklung/Browser-Automatisierung/`
> Werkzeug: **Web-Pilot** — der erste Skill des [[Cortex-Agent]]-Hubs (seit 2026-04-28).

Browser-Automatisierung heißt: Eine Webseite **öffnen, lesen und bedienen lassen** —
entweder durch einen unsichtbaren Hintergrund-Browser (Headless) oder durch Andocken
an deinen laufenden Chrome (Debug-Modus). Der Anwendungsfall ist Webseiten-Recherche,
Admin-Panel-Bedienung und Patienten-Schulungs-Websites — überall dort, wo Claude
nicht nur Code lesen, sondern „die Seite sehen" muss.

---

## Sicherheitslinie (Stracke-Konvention)

Web-Pilot tippt **nie Passwörter ein**. Du loggst dich einmal pro Profil ein
(Headless: im Web-Pilot-Browser, Debug-Modus: in deinem Chrome). Web-Pilot klickt
nur Buttons und liest Inhalte. Cookies/Sessions liegen außerhalb der Claude-Session.

---

## Zwei Modi im Vergleich

| Modus | Wer hat den Browser? | Login |
|---|---|---|
| **C — Headless** | Web-Pilot startet eigenen, unsichtbaren Chromium | Du loggst dich einmal pro Profil im Headless-Browser ein, Cookies bleiben dort |
| **D — Chrome-Debug** | Du startest deinen Chrome mit Debug-Modus, Web-Pilot dockt sich an | Du loggst dich wie immer in deinem Chrome ein, Web-Pilot fasst die Logins nie an |

---

## Verwandte Notizen

- [[Cortex-Agent]] — Hub, der Web-Pilot als Skill anbietet
- [[Webentwicklung Grundlagen]] — übergeordnete Domain
- [[_MOC Wissen]] — Vault-Index

<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

- [[30 Tutorials/Webentwicklung/Browser-Automatisierung/01-web-pilot|01-web-pilot]] · [[30 Tutorials/Webentwicklung/Browser-Automatisierung/01-web-pilot_claude|Claude]] · [[30 Tutorials/Webentwicklung/Browser-Automatisierung/01-web-pilot_manuell|Manuell]]

<!-- /auto-moc-links -->
