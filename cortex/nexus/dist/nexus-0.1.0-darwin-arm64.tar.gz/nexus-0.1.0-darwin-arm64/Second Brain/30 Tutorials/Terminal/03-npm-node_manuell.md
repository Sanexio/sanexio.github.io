# Terminal-Befehle: npm/Node.js — Manueller Workflow

## Wann nutzt du diesen Cheat Sheet?

Wenn Claude nicht verfügbar ist oder du selbst lernen willst, wie npm/Node.js funktioniert. Hier sind die wichtigsten Befehle zum Selbst-Tippen.

---

## Voraussetzungen: Node.js installieren (einmalig)

### Prüfe ob Node.js installiert ist

```bash
node --version
npm --version
```

Sollte etwas wie `v18.19.0` und `9.8.1` zeigen.

---

### Node.js installieren (mit nvm)

Falls nicht installiert, nutze nvm (Node Version Manager):

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.nvm/nvm.sh
nvm install 18
```

Nach Installation Terminal neustarten.

---

## Projekt initialisieren

### Neues npm-Projekt starten

```bash
mkdir my-project
cd my-project
npm init
```

Das erstellt eine `package.json`:
```json
{
  "name": "my-project",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "",
  "license": "ISC"
}
```

---

### Projekt von GitHub klonen (mit Dependencies)

```bash
git clone https://github.com/Sanexio/JUVANTIS.git
cd JUVANTIS
npm install
```

Das lädt alle Dependencies runter, die in `package.json` definiert sind.

---

## Dependencies verwalten

### `npm install` — Alle Dependencies installieren

```bash
npm install
```

Das liest `package.json` und installiert alle Pakete in `node_modules/`.

Mit verbose Output (mehr Details):
```bash
npm install --verbose
```

---

### `npm install paket-name` — Ein Paket installieren

```bash
npm install tailwindcss
```

Installiert Tailwind CSS und fügt es zu `package.json` hinzu.

Nur als "Development Dependency" (nicht für Production):
```bash
npm install --save-dev tailwindcss
npm install -D tailwindcss    # Shorthand
```

Development Dependencies sind nur für die Entwicklung (z.B. Test-Tools).

---

### `npm uninstall paket-name` — Ein Paket entfernen

```bash
npm uninstall tailwindcss
```

Entfernt das Paket und aktualisiert `package.json`.

---

### `npm list` — Installierte Pakete anzeigen

```bash
npm list
```

Zeigt alle installierten Pakete:
```
├── tailwindcss@3.3.0
├── autoprefixer@10.4.14
├── postcss@8.4.24
└── ...
```

Nur Top-Level (nicht die Unterpakete):
```bash
npm list --depth=0
```

---

### `npm update` — Pakete aktualisieren

```bash
npm update
```

Aktualisiert alle Pakete auf die neueste Version.

Ein spezifisches Paket:
```bash
npm update tailwindcss
```

---

## Scripts ausführen

Die `package.json` kann "Scripts" definieren:

```json
{
  "scripts": {
    "dev": "shopify theme develop",
    "build": "tailwindcss build",
    "test": "jest"
  }
}
```

### `npm run dev` — Entwicklungsserver starten

```bash
npm run dev
```

Führt den "dev"-Script aus:
```
> shopify theme develop

Syncing theme...
✓ Synced 340 files
...
```

Mit `Ctrl+C` beenden.

---

### `npm run build` — Production-Build

```bash
npm run build
```

Erstellt optimierte Dateien für Production.

---

### `npm test` — Tests laufen

```bash
npm test
```

Führt alle Tests durch (wenn definiert).

---

## Informationen anzeigen

### `npm info paket-name` — Paket-Infos

```bash
npm info tailwindcss
```

Zeigt Infos über das Paket:
```
tailwindcss@3.3.0

npm notice
npm notice name:                tailwindcss
npm notice version:             3.3.0
npm notice description:         ...
```

---

### `npm outdated` — Veraltete Pakete

```bash
npm outdated
```

Zeigt welche Pakete veraltet sind:
```
Package        Current Wanted Latest
tailwindcss    3.2.0   3.3.0  3.3.0
autoprefixer   10.4.0  10.4.1 10.4.1
```

---

## Cache und Problembehebung

### `npm cache clean` — Cache löschen

```bash
npm cache clean --force
```

Löscht den npm-Cache (wenn etwas schief läuft):

---

### `npm ci` — Exakte Versionen installieren

```bash
npm ci
```

Installiert **genau** die Versionen aus `package-lock.json` (nicht die neuesten).

**Unterschied:**
- `npm install` = neueste Versionen (kann Breaking Changes verursachen)
- `npm ci` = exakte Versionen (konsistent und sicher)

Nutze `npm ci` auf Servern / Production!

---

### `npm audit` — Sicherheitsprobleme checken

```bash
npm audit
```

Zeigt veraltete oder unsichere Pakete:
```
42 vulnerabilities found

critical: 2
high: 5
moderate: 8
low: 27
```

Automatisch fixen (wenn möglich):
```bash
npm audit fix
```

---

## Cheat Sheet: Häufigste npm-Befehle

| Befehl | Was es macht |
|--------|------------|
| `npm init` | Neues Projekt starten |
| `npm install` | Alle Dependencies installieren |
| `npm install pkg` | Ein Paket installieren |
| `npm uninstall pkg` | Ein Paket entfernen |
| `npm list` | Installierten Pakete anzeigen |
| `npm run dev` | Entwicklungsserver starten |
| `npm run build` | Production-Build |
| `npm test` | Tests laufen |
| `npm update` | Alle Pakete aktualisieren |
| `npm audit` | Sicherheit checken |

---

## Juvantis-Workflow (manuell)

```bash
# 1. Zum Theme navigieren
cd ~/projects/Juvantis/website/theme

# 2. Node.js aktivieren (wenn nötig)
source ~/.nvm/nvm.sh
nvm use 18

# 3. Dependencies installieren
npm install

# 4. Entwicklungsserver starten
npm run dev
  ↓
  URL: http://localhost:3000

# 5. Öffne Browser und teste Änderungen
# 6. Browser aktualisiert automatisch bei Dateiänderungen

# 7. Server stoppen (Ctrl+C)

# 8. Production-Build
npm run build

# 9. Zum Shopify pushen
npx shopify theme push --store medzpoint --theme 181128757515
```

---

## Häufige Fehler

### Problem: "npm: command not found"

Node.js/npm ist nicht installiert oder nicht aktiviert:

```bash
source ~/.nvm/nvm.sh    # NVM aktivieren
nvm use 18               # Node 18 aktivieren
npm --version            # Prüfen
```

---

### Problem: "Module not found"

Dependencies fehlen oder sind nicht installiert:

```bash
npm install              # Alle Dependencies neu installieren
```

---

### Problem: "Port bereits in Benutzung"

Der Entwicklungsserver läuft schon oder ein anderer Prozess nutzt denselben Port:

```bash
# Prozesse anzeigen
ps aux | grep node

# Prozess killen
kill 1234    # Ersetze 1234 mit der PID
```

---

### Problem: "EACCES: permission denied"

Berechtigungsfehler (seltener):

```bash
sudo npm install     # Mit sudo (nicht ideal, aber funktioniert)
```

Besser: npm neu installieren ohne sudo.

---

## package.json verstehen

```json
{
  "name": "juvantis-website",           // Projektname
  "version": "1.0.0",                   // Aktuelle Version
  "description": "Juvantis Shopify Theme",

  "scripts": {                          // Befehle: npm run X
    "dev": "shopify theme develop",
    "build": "tailwindcss build",
    "test": "jest"
  },

  "dependencies": {                     // Produktions-Abhängigkeiten
    "axios": "^1.4.0"
  },

  "devDependencies": {                  // Entwicklungs-Abhängigkeiten
    "tailwindcss": "^3.3.0",
    "jest": "^29.0.0"
  },

  "engines": {                          // Node-Version Anforderung
    "node": ">=18.0.0"
  }
}
```

---

*npm ist dein Paket-Manager. Dependencies sind wie Zutaten für dein Projekt.*
