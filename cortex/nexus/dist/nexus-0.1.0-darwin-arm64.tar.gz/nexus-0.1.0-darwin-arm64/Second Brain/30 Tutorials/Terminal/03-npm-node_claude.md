# Terminal-Befehle: npm/Node.js — Claude-Workflow

## Wann nutzt du diesen Workflow?

Du nutzt diesen Workflow wenn du Node.js/npm-Aufgaben brauchst:

- "Installiere die Dependencies für das Juvantis-Theme"
- "Starte den Shopify Theme Entwicklungsserver"
- "Installiere eine neue npm-Bibliothek (z.B. tailwindcss)"
- "Lauf die Tests für die iOS-App"
- "Build das Juvantis-Theme für Production"

**Vorteil:** Claude kennt die exakten npm-Befehle und Flags. Keine Fehler.
**Nachteil:** Claude muss verfügbar sein.

---

## Der Workflow: Vier Schritte

### Schritt 1: Du beschreibst die Node-Aufgabe

Du sagst Claude:

```
Installiere alle npm-Dependencies für das Shopify-Theme
```

oder:

```
Starte den Shopify-Theme-Entwicklungsserver und zeig mir die URL
```

oder:

```
Installiere Tailwind CSS im Juvantis-Projekt
```

Claude weiß, welche npm-Befehle du brauchst.

---

### Schritt 2: Claude prüft Voraussetzungen

Bevor Claude `npm` nutzt, prüft sie:

1. **Ist Node.js installiert?** (mit `node --version`)
2. **Ist npm verfügbar?** (mit `npm --version`)
3. **Gibt es eine `package.json`?** (ist das ein npm-Projekt?)
4. **Welche Node-Version brauchst du?** (manche Projekte brauchen spezifische Versionen)

Claude warnt dich, wenn etwas fehlt.

---

### Schritt 3: Claude führt die npm-Befehle aus

**Beispiel 1: Dependencies installieren**

Claude macht:
```bash
cd ~/projects/Juvantis/website/theme
npm install
```

**Beispiel 2: Entwicklungsserver starten**

Claude macht:
```bash
npm run dev
```

**Beispiel 3: Neue Bibliothek installieren**

Claude macht:
```bash
npm install tailwindcss --save-dev
```

---

### Schritt 4: Claude erklärt das Ergebnis

Claude zeigt dir:

```
✓ Dependencies installiert
  - 42 Pakete installiert
  - node_modules/ erstellt

✓ Shopify Theme Server starten
  - URL: http://localhost:3000
  - Watching for changes...
```

---

## Häufige Szenarien

### Szenario 1: "Installiere Dependencies"

**Du:** "Installiere alle npm-Packages für das Juvantis-Theme"

**Claude:**
```bash
cd ~/projects/Juvantis/website/theme
npm install
```

**Output:**
```
added 142 packages, and audited 150 packages
up to date in 15.3s
```

**Claude erklärt:** "Fertig! Alle Dependencies sind installiert. Du kannst jetzt `npm run dev` starten."

---

### Szenario 2: "Starte den Entwicklungsserver"

**Du:** "Starte den Shopify Theme Entwicklungsserver"

**Claude:**
```bash
npm run dev
```

**Output:**
```
> shopify theme develop

Syncing theme...
✓ Synced 340 files
✓ Your theme is now syncing with the live store

Tunnel URL: https://abcd-1234-efgh-5678.trycloudflare.com

Open your theme to view changes:
https://medzpoint.myshopify.com/?preview_theme_id=181128757515
```

**Claude erklärt:** "Der Entwicklungsserver läuft! Du kannst Dateien ändern und die Website wird live aktualisiert. Die URL ist oben. Mit `Ctrl+C` stoppen."

---

### Szenario 3: "Installiere eine neue Bibliothek"

**Du:** "Installiere Tailwind CSS"

**Claude:**
```bash
npm install -D tailwindcss
```

**Output:**
```
added 52 packages
updated package.json
```

**Claude erklärt:** "Tailwind ist installiert und in `package.json` eingetragen. Du kannst jetzt im Code `import 'tailwindcss'` nutzen."

---

### Szenario 4: "Build für Production"

**Du:** "Erstelle einen Production-Build"

**Claude:**
```bash
npm run build
```

**Output:**
```
> build script...
✓ Assets compiled
✓ Theme ready for deployment
  Size: 245KB (gzipped)
```

---

## Was ist npm?

npm ist der "App Store" für JavaScript. Es speichert:

```
package.json           ← Deine Abhängigkeiten (wie Rezept)
node_modules/          ← Installierte Bibliotheken (wie Zutaten)
package-lock.json      ← Exakte Versionen (für Reproduzierbarkeit)
```

Claude weiß, wie man diese verwaltet.

---

## Was ist Node.js?

Node.js ist JavaScript für deinen Computer (nicht im Browser):

```
Browser:           Node.js:
- Websites         - Server
- Interaktionen    - CLI-Tools
                   - Shopify CLI
                   - npm selbst
```

Du brauchst Node.js um `npm` zu nutzen.

---

## Sicherheit: Was Claude prüft

Bevor Claude npm-Befehle ausführt:

1. **Ist das der richtige Ordner?** (mit `pwd`)
2. **Gibt es eine `package.json`?** (ist das ein npm-Projekt?)
3. **Was wird installiert?** (Claude zeigt welche Pakete)
4. **Gibt es Sicherheitsprobleme?** (warnt vor veralteten Paketen)

Claude wird dich warnen, bevor etwas problematisches passiert.

---

## Häufige npm-Befehle (die Claude nutzt)

| Befehl | Was es macht |
|--------|------------|
| `npm install` | Dependencies installieren |
| `npm install paket-name` | Ein neues Paket installieren |
| `npm run dev` | Entwicklungsserver starten |
| `npm run build` | Production-Build erstellen |
| `npm test` | Tests laufen |
| `npm update` | Alle Pakete aktualisieren |
| `npm list` | Installierte Pakete anzeigen |
| `npm remove paket-name` | Ein Paket deinstallieren |

---

## Der Juvantis-Workflow (mit Claude)

```bash
# 1. Projekt klonen
git clone https://github.com/Sanexio/JUVANTIS.git
cd JUVANTIS/website/theme

# 2. Claude: "Installiere Dependencies"
npm install

# 3. Claude: "Starte Entwicklungsserver"
npm run dev
  ↓
  URL: http://localhost:3000

# 4. Du: Öffne die URL im Browser
# 5. Du: Bearbeite Dateien in Cursor
# 6. Browser: Automatisch aktualisiert (Hot Reload)

# 7. Du: "Stoppe den Server" (Ctrl+C im Terminal)

# 8. Claude: "Build für Production"
npm run build

# 9. Claude: "Pushe den Build"
npx shopify theme push ...
```

**Ergebnis:** Dein Theme ist lokal getestet, gebaut und live on sanexio.eu

---

## Zusammenfassung: Der Claude-Workflow

1. **Du sagst was du brauchst** ("Installiere Dependencies")
2. **Claude prüft Voraussetzungen** (Node, npm, etc.)
3. **Claude führt npm-Befehle aus** (kennt alle Flags)
4. **Claude erklärt das Ergebnis** (was jetzt läuft)

**Ergebnis:** Dein Node.js-Projekt ist installiert, läuft und bereit.

---

*Dieser Workflow macht Node.js/npm einfach. Du fokussierst auf Code, Claude kümmert sich um Dependencies und Build-Prozesse.*
