# Terminal-Befehle: Node.js und npm

## Was lernst du hier?

Node.js ist JavaScript außerhalb des Browsers — du kannst damit Server, CLI-Tools, und sogar Desktop-Apps bauen. npm ist der "App Store" für JavaScript-Code: es lädt Bibliotheken runter und verwaltet dein Projekt.

**Warum ist das für dich relevant?**
- Juvantis (Shopify-Theme) braucht Node.js und npm
- Viele moderne Web-Tools laufen auf Node
- Du brauchst nur 5 Befehle für tägliche Arbeit

---

## Was ist Node.js?

Node.js ist JavaScript für deinen Computer (statt im Browser):

```
Browser:          Node.js:
┌──────────┐      ┌──────────┐
│ HTML     │      │ Server   │
│ CSS      │      │ CLI Tool │
│ JS Code  │      │ JS Code  │
└──────────┘      └──────────┘
```

**Beispiel:** Du könntest einen Webserver schreiben:
```javascript
// server.js
const http = require('http');
const server = http.createServer((req, res) => {
  res.end('Hello from Node!');
});
server.listen(3000);
```

Und dann ausführen:
```bash
node server.js
```

---

## Was ist npm?

npm ist der "Package Manager" für JavaScript. Es ist wie der App Store — du kannst Code-Bibliotheken installieren und nutzen.

```
npm Registry (npmjs.com)
  ↓
dein Projekt
  ├── node_modules/  ← Installierte Pakete
  └── package.json   ← Deine Dependencies
```

---

## nvm: Node Version Manager — Mehrere Node-Versionen

Verschiedene Projekte brauchen unterschiedliche Node-Versionen. Deshalb gibt es nvm.

### nvm installieren

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
```

**Nach Installation:** Terminal neustarten und checken:
```bash
nvm --version
```

---

### `nvm install` — Node-Version installieren

```bash
nvm install 18
```

Installiert Node.js Version 18:
```
Downloading and installing node v18.19.0...
```

**Neueste LTS (Long Term Support) Version:**
```bash
nvm install --lts
```

**Aktuelle Entwicklungsversion:**
```bash
nvm install node
```

---

### `nvm use` — Zwischen Versionen wechseln

```bash
nvm use 18
```

Wechselt zu Node 18:
```
Now using node v18.19.0
```

**Automatisch für dieses Projekt (mit `.nvmrc`):**

Erstelle eine Datei `.nvmrc` im Projektroot:
```
18
```

Dann:
```bash
nvm use
```

Git liest die `.nvmrc` und wechselt automatisch.

---

### `nvm list` — Installierte Versionen

```bash
nvm list
```

```
     v18.19.0
     v20.10.0
->   v18.19.0  (currently using 18)
```

Das `->` zeigt die aktuelle Version.

---

## npm: Pakete installieren und verwalten

### `package.json` — Das Herz deines Projekts

Jedes Node-Projekt hat eine `package.json`. Sie ist wie ein "Rezept":

```json
{
  "name": "juvantis-shopify",
  "version": "1.0.0",
  "description": "Shopify theme for Juvantis",
  "scripts": {
    "dev": "shopify theme dev",
    "build": "webpack",
    "test": "jest"
  },
  "dependencies": {
    "axios": "^1.4.0",
    "lodash": "^4.17.21"
  },
  "devDependencies": {
    "@shopify/cli": "^3.0.0",
    "webpack": "^5.0.0"
  }
}
```

**Was das bedeutet:**
- `scripts` = Befehle, die du mit `npm run` ausführen kannst
- `dependencies` = Code-Bibliotheken, die dein Projekt braucht (für Production)
- `devDependencies` = Tools für die Entwicklung (nicht im finalen Produkt)

---

### `npm init` — Neues Projekt starten

```bash
npm init
```

Das fragt dich ein paar Fragen und erstellt `package.json`:

```
package name: (folder name) juvantis-shopify
version: (1.0.0) 1.0.0
description: Shopify theme for Juvantis
entry point: (index.js)
test command:
```

**Schneller (alle Defaults):**
```bash
npm init -y
```

---

### `npm install` — Pakete installieren

```bash
npm install axios
```

Das installiert die Bibliothek `axios` und speichert sie in `node_modules/`:

```
node_modules/
  ├── axios/
  ├── ...
package.json     (aktualisiert: axios hinzugefügt)
package-lock.json (Lock-Datei erstellt)
```

**Installation für Entwicklung (devDependencies):**
```bash
npm install --save-dev webpack
```

Das `-D` ist die Kurzform:
```bash
npm install -D webpack
```

**Alle Dependencies installieren (z.B. nach `git clone`):**
```bash
npm install
```

Das liest `package.json` und installiert alles, was drin steht.

---

### `npm uninstall` — Paket entfernen

```bash
npm uninstall axios
```

Entfernt `axios` aus `node_modules/` und aus `package.json`.

---

### `npm list` — Installierte Pakete anschauen

```bash
npm list
```

Zeigt alle installierten Pakete:
```
juvantis-shopify@1.0.0
├── axios@1.4.0
├── lodash@4.17.21
└── @shopify/cli@3.0.0
```

**Nur top-level Pakete:**
```bash
npm list --depth=0
```

---

## npm scripts: Befehle ausführen

In deiner `package.json` kannst du Scripts definieren:

```json
{
  "scripts": {
    "dev": "shopify theme dev",
    "build": "webpack",
    "test": "jest",
    "start": "node server.js"
  }
}
```

### `npm run` — Script ausführen

```bash
npm run dev
```

Das führt `shopify theme dev` aus (den dev-Befehl aus der package.json).

**Wichtige Scripts:**
```bash
npm start       # Kurzform für npm run start
npm test        # Kurzform für npm run test
npm run build   # Vollform für beliebige Scripts
```

---

## npx: Pakete ohne Installation ausführen

Manchmal willst du ein Tool einmal nutzen, ohne es zu installieren.

### `npx` — "npm execute"

```bash
npx create-react-app my-app
```

Das:
1. Downloaded `create-react-app`
2. Führt es aus
3. Löscht es danach (wird nicht installt)

**Shopify CLI (wichtig für Juvantis!):**
```bash
npx @shopify/cli@latest theme dev
```

Das ist wie `npm install -g @shopify/cli`, aber ohne global zu installieren.

---

## Der Juvantis-Shopify-Workflow

Dein Juvantis-Projekt hat einen Shopify-Theme. Hier ist der typische Workflow:

### 1. Projekt klonen und Dependencies installieren

```bash
git clone git@github.com:sanexio/juvantis.git
cd juvantis/shopify-theme
nvm use              # Richtige Node-Version nutzen
npm install          # Alle Pakete installieren
```

### 2. Entwicklungs-Server starten

```bash
npm run dev
```

Das startet den Shopify-Entwicklungs-Server. Jede Änderung wird live synchronisiert.

```
✓ Watching theme files
✓ Connected to store
✓ Serving at http://localhost:3000
```

### 3. Deine Änderungen machen

Editiere die Liquid-Dateien (`.liquid`), CSS, JavaScript. Der Server aktualisiert automatisch.

### 4. Commit und Push

```bash
git add .
git commit -m "Add product carousel"
git push
```

### 5. Build für Production

```bash
npm run build
```

Das erstellt optimierte, minimierte Dateien.

---

## Häufige Probleme

### Problem: "npm: command not found"

**Grund:** Node.js / npm ist nicht installiert.

**Lösung:**
```bash
# Mit nvm installieren
nvm install --lts
nvm use --lts
```

---

### Problem: "npm install" wird nicht fertig

**Grund:** npm lädt große Pakete runter, braucht Internet-Zeit.

**Lösung:** Warten. Bei langsamer Verbindung 5-10 Minuten.

---

### Problem: "Module not found: axios"

**Grund:** Das Paket ist in `package.json`, aber nicht installiert (z.B. nach `git clone`).

**Lösung:**
```bash
npm install
```

---

### Problem: "Falsche Node-Version"

**Grund:** Dein Projekt braucht Node 18, du hast 20 installiert.

**Lösung:**
```bash
nvm use 18
```

Oder `.nvmrc` erstellen mit `18` drin.

---

## Zusammenfassung: Die 10 wichtigsten npm-Befehle

| Befehl | Was es macht |
|--------|--------------|
| `npm init` | Neues Projekt starten |
| `npm install` | Alle Dependencies installieren |
| `npm install axios` | Paket installieren |
| `npm install -D webpack` | Dev-Dependency installieren |
| `npm uninstall axios` | Paket entfernen |
| `npm list` | Alle Pakete anzeigen |
| `npm run dev` | Entwicklungs-Server starten |
| `npm run build` | Production-Version bauen |
| `npm start` | Hauptprogramm starten |
| `npx create-react-app` | Tool ohne Installation nutzen |

---

## Cheat Sheet: nvm

| Befehl | Was es macht |
|--------|--------------|
| `nvm install 18` | Node 18 installieren |
| `nvm install --lts` | Neueste LTS installieren |
| `nvm use 18` | Zu Node 18 wechseln |
| `nvm list` | Installierte Versionen |
| `nvm current` | Aktuelle Version |

---

## Nächste Schritte

1. **Installiere nvm und Node.js:**
   ```bash
   nvm install --lts
   node --version    # Sollte v18.x oder neuer sein
   npm --version     # Sollte 9.x oder neuer sein
   ```

2. **Erkunde ein bestehendes Projekt:**
   ```bash
   cd projects/Juvantis/shopify-theme
   cat package.json
   npm list --depth=0
   ```

3. **Starte einen Dev-Server (wenn du bereit bist):**
   ```bash
   npm run dev
   ```

4. **Lern Shopify-Liquid:** _tutorials/shopify/01-liquid-basics.md

---

**💡 Tipp:** `npm` aktualisiert sich selbst. Wenn du seltsame Fehler hast, probier:
```bash
npm install -g npm@latest
```
