# Terminal-Befehle: Grundlagen

## Was lernst du hier?

Das Terminal (auch "Kommandozeile" genannt) ist wie ein Textfeld, in das du Befehle tippst, um deinen Computer zu steuern. Es ist nicht schwer — du brauchst nur die wichtigsten Befehle zu kennen. Diese Lektion zeigt dir die 30 Befehle, die du 90% der Zeit brauchst.

**Warum brauche ich das?** Weil du damit:
- Dateien schneller verwalten kannst als mit der Maus
- Projekte (Git, Node.js, Blender) von der Kommandozeile steuern kannst
- Logs und Fehler einfacher diagnostizieren kannst

---

## Navigation: Wo bin ich, wo will ich hin?

### `pwd` — Print Working Directory (Wo bin ich?)

```bash
pwd
```

Gibt deinen aktuellen Pfad aus:
```
/Users/ssmd/Desktop/Juvantis
```

**Was das bedeutet:** Du befindest dich im Ordner `Juvantis` auf dem Desktop.

**Wann brauchst du das:** Wenn du dich orientieren möchtest oder den exakten Pfad wissen musst.

---

### `ls` — List (Was ist hier?)

```bash
ls
```

Zeigt alle Dateien und Ordner im aktuellen Verzeichnis:
```
Desktop        Documents      Downloads      Library
applications   code           music          projects
```

**Mit Details:**
```bash
ls -la
```

Zeigt auch versteckte Dateien (mit `.` am Anfang) und Berechtigungen:
```
drwxr-xr-x  10 ssmd  staff  320  2 Apr 10:42 Desktop
-rw-r--r--   1 ssmd  staff   15K 1 Apr 09:15 README.md
```

**Was das bedeutet:**
- `d` = das ist ein Ordner (directory)
- `-` = das ist eine normale Datei
- `rwxr-xr-x` = wer kann was machen (Berechtigungen)
- `ssmd` = der Besitzer
- `320` = Größe in Bytes
- `2 Apr 10:42` = Änderungsdatum

**Wann brauchst du das:** Praktisch immer — um zu sehen, wo du bist.

---

### `cd` — Change Directory (Wohin gehen?)

```bash
cd Desktop
```

Wechselt in den Ordner `Desktop`:
```
~/Desktop $
```

**Zurück zum vorherigen Ordner:**
```bash
cd ..
```

Der doppelte Punkt `..` bedeutet "eine Ebene nach oben".

**Zum Home-Verzeichnis springen:**
```bash
cd ~
```

oder einfach:
```bash
cd
```

**Mit Leerzeichen in Namen:**
Wenn ein Ordner ein Leerzeichen im Namen hat:
```bash
cd "My Documents"
```

oder mit Backslash:
```bash
cd My\ Documents
```

**Wann brauchst du das:** Dutzende Male pro Tag.

---

## Dateien erstellen und bearbeiten

### `touch` — Neue leere Datei erstellen

```bash
touch notes.txt
```

Erstellt eine leere Datei namens `notes.txt`.

**Praktisch für:** Schnell eine neue Datei für später vorbereiten.

---

### `mkdir` — Ordner erstellen

```bash
mkdir my-project
```

Erstellt einen neuen Ordner.

**Mit verschachtelten Ordnern:**
```bash
mkdir -p projects/juvantis/prototypes
```

Das `-p` bedeutet "erstelle auch die Ordner dazwischen, wenn sie nicht existieren".

**Wann brauchst du das:** Wenn du ein neues Projekt startest.

---

### `cat` — Dateiinhalt anzeigen

```bash
cat README.md
```

Zeigt den kompletten Inhalt der Datei:
```
# Mein Projekt
Dies ist mein erstes Projekt.
```

**Mit Zeilennummern:**
```bash
cat -n README.md
```

```
     1  # Mein Projekt
     2  Dies ist mein erstes Projekt.
```

**Mehrere Dateien kombinieren:**
```bash
cat file1.txt file2.txt
```

Zeigt erst `file1.txt`, dann `file2.txt` untereinander.

**Wann brauchst du das:** Schnell den Inhalt einer Datei checken.

---

### `less` — Datei blättern (für lange Dateien)

```bash
less logfile.txt
```

Öffnet die Datei zum Blättern. Tasten:
- `Leertaste` = eine Seite nach unten
- `b` = eine Seite nach oben
- `/suchtext` = Text suchen
- `q` = beenden

**Warum nicht `cat`?** Bei großen Dateien (10.000 Zeilen) scrollt `cat` alles auf einmal — mit `less` kannst du blättern.

---

## Dateien kopieren, verschieben, löschen

### `cp` — Copy (Kopieren)

```bash
cp document.txt backup.txt
```

Kopiert `document.txt` nach `backup.txt`.

**Ordner kopieren (rekursiv):**
```bash
cp -r my-project my-project-backup
```

Das `-r` bedeutet "recursive" — kopiere auch alle Dateien darin.

**Wann brauchst du das:** Bevor du etwas Großes änderst — erst kopieren, dann ändern.

---

### `mv` — Move (Verschieben/Umbenennen)

```bash
mv old-name.txt new-name.txt
```

Benennt die Datei um (oder "verschiebt" sie mit neuem Namen).

**In einen anderen Ordner:**
```bash
mv document.txt ~/Documents/
```

Verschiebt `document.txt` in den Ordner `Documents`.

**Mehrere Dateien:**
```bash
mv *.txt archive/
```

Alle Dateien mit Endung `.txt` in den Ordner `archive` verschieben.

**Wann brauchst du das:** Dateien organisieren, umbennen nach Ablauf des file-renamer-Prozesses.

---

### `rm` — Remove (LÖSCHEN — Achtung!)

```bash
rm document.txt
```

**LÖSCHT** die Datei permanent. Es gibt keinen "Papierkorb" wie am Mac — gelöscht ist gelöscht.

**Ordner löschen (mit allem drin):**
```bash
rm -r my-old-project
```

Das `-r` bedeutet "recursive" — lösche alles rekursiv drin.

**"Sicher löschen" mit Bestätigung:**
```bash
rm -i document.txt
```

Das `-i` fragt dich: "Really remove document.txt?" — Antworte mit `y` (ja) oder `n` (nein).

**⚠️ ACHTUNG:**
- `rm` ist irreversibel!
- Nutze immer `-i`, wenn du nicht 100% sicher bist.
- Besser: Erst mit `ls` checken, was gelöscht wird.

**Wann brauchst du das:** Alte Backups, Test-Dateien löschen.

---

## Dateien anschauen und filtern

### `head` — Ersten 10 Zeilen anzeigen

```bash
head logfile.txt
```

Zeigt die ersten 10 Zeilen:
```
[INFO] Starting service...
[INFO] Loaded config
[INFO] Connected to DB
...
```

**Erste 20 Zeilen:**
```bash
head -n 20 logfile.txt
```

---

### `tail` — Letzten 10 Zeilen anzeigen

```bash
tail logfile.txt
```

Zeigt die letzten 10 Zeilen.

**Letzten 50 Zeilen, live aktualisieren (für Logs!):**
```bash
tail -f logfile.txt
```

Das `-f` bedeutet "follow" — die Datei wird live aktualisiert, wenn neue Zeilen hinzukommen. Mit `Ctrl+C` beenden.

**Wann brauchst du das:** Logs in Echtzeit anschauen, z.B. bei der Juvantis-App-Entwicklung.

---

### `grep` — Text suchen/filtern

```bash
grep "error" logfile.txt
```

Zeigt alle Zeilen, die "error" enthalten:
```
[ERROR] Connection failed
[ERROR] Timeout after 30s
```

**Ohne Unterscheidung Groß/Kleinschreibung:**
```bash
grep -i "error" logfile.txt
```

Das `-i` bedeutet "case-insensitive".

**Zeilennummern anzeigen:**
```bash
grep -n "error" logfile.txt
```

```
5:  [ERROR] Connection failed
12: [ERROR] Timeout after 30s
```

**Nur Dateien listen, nicht den Inhalt:**
```bash
grep -l "error" *.txt
```

Zeigt nur die Dateinamen, die "error" enthalten.

**Wann brauchst du das:** Fehler in Logs finden, eine bestimmte Konfiguration suchen.

---

## Pipes und Umleitung: Befehle kombinieren

### `|` — Pipe (Ausgabe von Befehl A zu Befehl B)

```bash
cat logfile.txt | grep "error"
```

Das bedeutet:
1. Zeige den Inhalt von `logfile.txt`
2. Filtere daraus nur die Zeilen mit "error"

**Mehrere Pipes hintereinander:**
```bash
cat logfile.txt | grep "error" | head -5
```

Das bedeutet:
1. Zeige `logfile.txt`
2. Filtere nur Zeilen mit "error"
3. Zeige davon nur die ersten 5

**Wann brauchst du das:** Praktisch immer, um große Ausgaben zu filtern.

---

### `>` — Umleitung: Speichern in Datei

```bash
ls > file-list.txt
```

Speichert die Ausgabe von `ls` in eine **neue** Datei namens `file-list.txt`. Wenn die Datei existiert, wird sie **überschrieben**.

**Beispiel:**
```bash
cat logfile.txt | grep "error" > errors-only.txt
```

Speichert nur die Error-Zeilen in `errors-only.txt`.

**Wann brauchst du das:** Ausgabe speichern für später.

---

### `>>` — Anhängen an Datei

```bash
echo "Neue Zeile" >> notes.txt
```

Hängt "Neue Zeile" am Ende von `notes.txt` **an**. Die Datei wird nicht überschrieben.

**Unterschied:**
- `>` = überschreiben (dangerous!)
- `>>` = anhängen (safe)

**Wann brauchst du das:** Logs zusammenfassen, Notizen nachträglich ergänzen.

---

## Berechtigungen: Wer darf was?

### `chmod` — Change Mode (Berechtigungen ändern)

```bash
chmod +x script.sh
```

Das `+x` bedeutet "mache diese Datei ausführbar".

**Verständnis der Berechtigungen:**
```
rwxrwxrwx
│││││││││
│││││││└─ Andere: ausführbar
│││││││── Andere: schreiben
│││││││── Andere: lesen
│││││
│││└──── Gruppe: ausführbar
│││───── Gruppe: schreiben
│││────── Gruppe: lesen
│
└──────── Besitzer: ausführbar
└─────── Besitzer: schreiben
└────── Besitzer: lesen
```

**Praktische Beispiele:**
```bash
chmod +x script.sh           # Mache script.sh ausführbar
chmod 755 script.sh          # Standard: Besitzer=rwx, Andere=rx
chmod 644 document.txt       # Standard: Besitzer=rw, Andere=r
```

**Wann brauchst du das:** Wenn du ein Shell-Skript selbst ausführen willst.

---

### `chown` — Change Owner (Besitzer ändern)

```bash
chown ssmd document.txt
```

Ändert den Besitzer auf `ssmd`.

**Mit Gruppe:**
```bash
chown ssmd:staff document.txt
```

Besitzer = `ssmd`, Gruppe = `staff`.

**Wann brauchst du das:** Seltener — wenn du Berechtigungsprobleme hast.

---

## Prozesse: Was läuft gerade?

### `ps` — Process Status (laufende Programme)

```bash
ps
```

Zeigt die Prozesse, die du gestartet hast:
```
PID  TTY  TIME     CMD
1234 s000 0:01.23  /bin/bash
5678 s000 0:00.45  npm run dev
```

**Was das bedeutet:**
- `PID` = Prozess-ID (wichtig zum Stoppen)
- `TTY` = Terminal, in dem er läuft
- `TIME` = wie lange er läuft
- `CMD` = der Befehl

**Alle Prozesse anzeigen:**
```bash
ps aux
```

Zeigt alle Prozesse (vom ganzen System). Die Ausgabe ist lang!

**Einen bestimmten Prozess suchen:**
```bash
ps aux | grep npm
```

Zeigt alle Prozesse, die "npm" enthalten.

---

### `kill` — Prozess beenden

```bash
kill 5678
```

Beendet den Prozess mit ID 5678 (z.B. dein `npm run dev`).

**Erzwungenes Beenden (wenn `kill` nicht funktioniert):**
```bash
kill -9 5678
```

Das `-9` ist deutlich aggressiver und funktioniert fast immer.

**Nach PID suchen und beenden (in einem Schritt):**
```bash
kill $(lsof -t -i:3000)
```

Das bedeutet: "Beende den Prozess, der auf Port 3000 läuft" (z.B. dein Entwicklungsserver).

**Wann brauchst du das:** Wenn ein Prozess hängen bleibt oder ständig Fehler macht.

---

### `top` — Prozessüberwacht (wie Task Manager)

```bash
top
```

Zeigt alle laufenden Prozesse mit CPU- und Memory-Auslastung. Aktualisiert sich live.

```
Processes: 123 total, 2 running, 121 sleeping
CPU:  8.2% user  2.1% sys  89.7% idle
MEM:  8GB used  8GB free
...
PID    COMMAND    %CPU %MEM
1234   node       12.3 4.5
5678   Safari      8.1 2.2
```

**Taste `q` zum Beenden.**

**Wann brauchst du das:** Wenn dein Computer langsam wird — sehen, welcher Prozess Ressourcen frisst.

---

## Netzwerk: Internet und verbundene Geräte

### `ping` — Ist dieser Server erreichbar?

```bash
ping google.com
```

Sendet ein "Hallo, bist du da?"-Signal an google.com. Wenn du Antworten siehst, ist die Verbindung gut.

```
PING google.com (172.217.31.142): 56 data bytes
64 bytes from 172.217.31.142: icmp_seq=0 ttl=119 time=25.3ms
64 bytes from 172.217.31.142: icmp_seq=1 ttl=119 time=22.1ms
```

**Mit `Ctrl+C` beenden.**

**Wann brauchst du das:** Wenn du Internet-Probleme hast oder einen Server testierst.

---

### `curl` — Daten von Webseite abrufen

```bash
curl https://sf01.smart-q.io/api/health
```

Abrufen von Daten direkt aus einer URL (z.B. API-Antwort):

```json
{"status": "healthy", "uptime": "7d 3h"}
```

**Mit Headers anschauen:**
```bash
curl -i https://sf01.smart-q.io/api/health
```

Zeigt auch die HTTP-Header (200 OK, etc.).

**Daten speichern:**
```bash
curl https://sf01.smart-q.io/api/data > data.json
```

**Wann brauchst du das:** API testen, schnell Daten von einer Webseite abrufen.

---

### `ssh` — Fernverbindung zu anderem Computer

```bash
ssh user@server.com
```

Verbindet sich mit dem Computer `server.com` als Benutzer `user`.

```
user@server:~$
```

Du bist jetzt auf dem ferngesteuerten Computer!

**Befehl auf ferngesteuerten Computer ausführen (ohne dich zu verbinden):**
```bash
ssh user@server.com "ls /home"
```

Zeigt die Dateien in `/home` auf `server.com`.

**Datei hochladen (SCP = Secure Copy):**
```bash
scp document.txt user@server.com:/home/
```

**Wann brauchst du das:** Auf deinen Homelab-Computer zugreifen, auf Servern Befehle ausführen.

---

## Zusammenfassung: Die 10 wichtigsten Befehle

| Befehl | Was es macht | Beispiel |
|--------|--------------|----------|
| `pwd` | Zeigt, wo ich bin | `pwd` |
| `ls` | Dateien anzeigen | `ls -la` |
| `cd` | Ordner wechseln | `cd projects` |
| `mkdir` | Ordner erstellen | `mkdir my-app` |
| `cp` | Kopieren | `cp file.txt file-backup.txt` |
| `mv` | Verschieben/Umbenennen | `mv old.txt new.txt` |
| `rm` | Löschen | `rm old.txt` |
| `cat` | Datei anzeigen | `cat README.md` |
| `grep` | Text suchen | `grep "error" logfile.txt` |
| `kill` | Prozess stoppen | `kill 1234` |

---

## Nächste Schritte

1. **Übe die Navigation:** `cd`, `ls`, `pwd` ein paar Mal
2. **Spiele mit Dateien:** `touch`, `cp`, `mv`, `rm -i` (mit Bestätigung!)
3. **Filtere Output:** Nutze `grep` und Pipes (`|`) um große Ausgaben zu filtern
4. **Schau dir Git an:** Terminal-Befehle > Git — das ist wo's interesting wird!

---

**💡 Tipp:** Viele Befehle haben auch Online-Manuals. Tippe `man ls` um die vollständige Dokumentation zu sehen. Mit `q` beenden.
