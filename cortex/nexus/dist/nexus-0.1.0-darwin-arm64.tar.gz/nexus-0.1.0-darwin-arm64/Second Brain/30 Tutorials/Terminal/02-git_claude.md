# Terminal-Befehle: Git — Claude-Workflow

## Wann nutzt du diesen Workflow?

Du nutzt diesen Workflow **immer** wenn es um Git geht:

- "Committe meine Änderungen an der iOS-App"
- "Erstelle einen neuen Branch für die Preise-Section"
- "Merge den feature/avatar-Branch mit master"
- "Push meine Commits zu GitHub"
- "Zeig mir die letzte Git-History"
- "Rollback zu der funktionierenden Version"

**Vorteil:** Claude macht alle Git-Operationen fehlerfrei, dokumentiert jeden Schritt.
**Nachteil:** Claude muss verfügbar sein.

---

## Der Workflow: Vier Schritte

### Schritt 1: Du beschreibst die Git-Aktion

Du öffnest Claude Code und schreibst:

```
Committe alle meine Änderungen mit der Nachricht:
"Add avatar customization feature with color picker"
```

oder:

```
Erstelle einen neuen Branch für die neue Produktgalerie-Section
```

oder:

```
Merge den feature/pricing-page Branch mit master
```

Claude versteht das und weiß, welche Git-Befehle du brauchst.

---

### Schritt 2: Claude führt Git-Befehle aus

**Beispiel 1: Commit**

Claude macht:
```bash
cd ~/projects/Juvantis
git status              # Was hat sich geändert?
git add .               # Alle Änderungen vorbereiten
git commit -m "Add avatar customization feature with color picker"
```

**Beispiel 2: Neuer Branch**

Claude macht:
```bash
git checkout -b feature/product-gallery
```

**Beispiel 3: Merge**

Claude macht:
```bash
git checkout master
git pull                # Neueste Version holen
git merge feature/pricing-page
```

---

### Schritt 3: Claude erklärt das Ergebnis

Claude zeigt dir, was passiert ist:

```
✓ Commit erstellt: "Add avatar customization..."
  - 3 Dateien geändert
  - 42 Zeilen hinzugefügt
  - 8 Zeilen gelöscht

Commit Hash: abc123def456
Auf Branch: master
```

---

### Schritt 4: Optional: Push zu GitHub

Du fragst Claude:

```
Push das zu GitHub
```

Claude macht:
```bash
git push origin master
```

Und zeigt:
```
✓ Zu GitHub gepusht
  Commits: 1
  Remote: origin/master
```

---

## Häufige Szenarien

### Szenario 1: "Committe meine Arbeit des Tages"

**Du:** "Committe alle Änderungen an der Shopify-Section"

**Claude:**
1. Prüft mit `git status` was geändert wurde
2. Staged alle Änderungen mit `git add .`
3. Erstellt einen Commit mit aussagekräftiger Nachricht
4. Zeigt dir Confirmation

**Output:**
```
✓ Commit erstellt: "Update Shopify pricing section with new styles"
  sections/pricing.liquid | 42 +++++++++++
  1 file changed, 42 insertions(+)
```

---

### Szenario 2: "Erstelle einen neuen Branch für eine Feature"

**Du:** "Erstelle einen Branch für die neue Benutzer-Dashboard"

**Claude:**
```bash
git checkout -b feature/user-dashboard
```

**Output:**
```
✓ Branch erstellt: feature/user-dashboard
  Du bist jetzt auf diesem Branch
  Alle deine Änderungen gehen in diesen Branch
```

---

### Szenario 3: "Merge die Feature in den master"

**Du:** "Feature ist fertig — merge feature/user-dashboard in master"

**Claude:**
1. Wechselt zu `master`
2. Holt neueste Version mit `git pull`
3. Merged den Feature-Branch
4. Löscht den Feature-Branch (optional)

**Output:**
```
✓ Feature gemergt
  50 commits integriert
  Branch feature/user-dashboard gelöscht
```

---

### Szenario 4: "Zeig mir die Git-History"

**Du:** "Zeig mir die letzten 10 Commits"

**Claude:**
```bash
git log --oneline -10
```

**Output:**
```
abc123d Add avatar customization
def456e Fix animation bug
ghi789a Update header styling
...
```

---

### Szenario 5: "Rollback zu einer älteren Version"

**Du:** "Die letzte Änderung war Müll — rollback zur vorherigen Version"

**Claude:**
```bash
git revert abc123d
```

**Output:**
```
✓ Rollback erstellt
  Ein neuer Commit wurde erstellt, der die Änderungen rückgängig macht
  Commit: xyz789abc123 "Revert Add avatar..."
  Die alte Version ist noch in der History
```

---

## Wichtige Konzepte (die Claude für dich verwaltet)

### Was ist ein Commit?

Ein Commit ist eine "Speicherung" mit einer Beschreibung:

```
Commit: abc123d
Message: "Add avatar customization feature"
Author: Dr. Stracke
Date: 2 Apr 2026 10:42
Files: avatar.swift (42 lines added)
```

Die Beschreibung ist wichtig, damit du später weißt WAS sich geändert hat.

---

### Was ist ein Branch?

Ein Branch ist wie eine parallele Arbeitslinie:

```
master              (die funktionierende Version)
  ├─ feature/avatar     (deine neue Feature)
  └─ feature/pricing    (eine andere Feature)
```

Du kannst an mehreren Features gleichzeitig arbeiten, ohne die funktionierende Version zu zerstören.

---

### Was ist ein Merge?

Ein Merge verbindet zwei Branches:

```
feature/avatar ist fertig
  ↓
merge in master
  ↓
master hat jetzt auch die avatar-Feature
```

---

## Sicherheit: Was Claude prüft

Bevor Claude Git-Operationen macht, prüft sie:

1. **Gibt es ungespeicherte Änderungen?** (mit `git status`)
2. **Bin ich auf dem richtigen Branch?** (mit `git branch`)
3. **Ist die Nachricht aussagekräftig?** (z.B. nicht "fix")
4. **Gibt es Merge-Konflikte?** (warnt dich bevor es schiefgeht)

Claude wird dich immer warnen, bevor etwas irreversibles passiert.

---

## Der Juvantis-Workflow (mit Claude)

Du arbeitest an der Shopify-Seite:

```bash
# 1. Claude: "Erstelle einen neuen Branch"
git checkout -b feature/product-gallery

# 2. Du: Edits Dateien in Cursor
# 3. Claude: "Committe die Änderungen"
git add .
git commit -m "Add product gallery with 4-column grid"

# 4. Claude: "Push zu GitHub"
git push origin feature/product-gallery

# 5. Du testierst, alles funktioniert

# 6. Claude: "Merge in master"
git checkout master
git pull
git merge feature/product-gallery
git push

# 7. Claude: "Cleanup"
git branch -d feature/product-gallery
```

**Alles ist dokumentiert, alles ist zurückholbar, alles ist sauber.**

---

## Zusammenfassung: Der Claude-Workflow

1. **Du sagst was du willst** ("Committe meine Änderungen")
2. **Claude führt Git-Befehle aus** (kennt alle Befehle)
3. **Claude prüft Sicherheit** (warnt vor Fehlern)
4. **Claude zeigt das Ergebnis** (Confirmation + Details)

**Ergebnis:** Deine gesamte Projekthistorie ist dokumentiert, nichts geht verloren, und du kannst jederzeit zurückgehen.

---

*Dieser Workflow macht Git einfach. Du fokussierst auf deine Arbeit, Claude managt die Versionskontrolle.*
