# 05 — Shopify & Blender — Manueller Workflow

> Schritt-für-Schritt-Anleitung zum Selber-Machen im Terminal. Setzt voraus,
> dass Sie `05-shopify-blender-workflows.md` gelesen haben — dort stehen die
> Erklärungen zum *Warum*.

---

## Vorbereitung (einmalig, danach nie wieder)

### 1. nvm-Nachladen in Ihre `~/.zshrc` eintragen

Öffnen Sie `~/.zshrc`:

```bash
nano ~/.zshrc
```

Prüfen Sie, ob folgende Zeilen schon da sind. Wenn nicht, ans Ende anhängen:

```bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
```

Speichern (`Ctrl+O`, Enter, `Ctrl+X`), dann einmal neu laden:

```bash
source ~/.zshrc
nvm --version
```

Kommt eine Versionsnummer → passt. Kommt „command not found" → nvm ist noch
nicht installiert, dann bitte erst `curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash`
und von vorne.

### 2. Blender-Alias

```bash
echo "alias blender='/Applications/Blender.app/Contents/MacOS/Blender'" >> ~/.zshrc
source ~/.zshrc
blender --version
```

Kommt eine Version raus (z.B. `Blender 4.0.2`) → perfekt.

---

## Workflow A: Shopify-Section live pushen

Sie haben gerade `sections/dht-avatar-compare.liquid` bearbeitet und wollen die
Änderung im Live-Store sehen.

1. Ins Theme-Verzeichnis wechseln (**Pflicht**, sonst Fehler):

   ```bash
   cd "/Users/ssmd/Library/CloudStorage/GoogleDrive-team@sanexio.de/Meine Ablage/Claude-OS/projects/Juvantis/website/theme"
   ```

2. Kurz prüfen, dass Sie im richtigen Ordner sind:

   ```bash
   ls config/settings_data.json && echo "OK"
   ```

   Zeigt es `OK` → perfekt. Fehlermeldung → Sie sind im falschen Ordner.

3. Push abfeuern — mit nvm-Nachladen und `--only`-Filter:

   ```bash
   source ~/.nvm/nvm.sh && npx shopify theme push \
     --store medzpoint \
     --theme 181128757515 \
     --allow-live \
     --only sections/dht-avatar-compare.liquid \
     --only templates/page.digital-health-twin.json
   ```

4. Auf die Ausgabe warten. Gesund aussieht so:

   ```
   ✔ Theme files synced
   ```

5. Verifikation mit `curl` (KEIN Browser):

   ```bash
   curl -s https://sanexio.eu/pages/digital-health-twin | grep -c 'dht-avatar-compare'
   ```

   Kommt eine Zahl ≥ 1 → Section ist live. Kommt 0 → etwas ist schiefgelaufen,
   dann Ausgabe des Push-Befehls prüfen.

### Wenn der Push mit „Abschnittstyp existiert nicht" scheitert

Sie haben nur die Section gepusht, nicht das Template. Holen Sie das Template
nach:

```bash
source ~/.nvm/nvm.sh && npx shopify theme push \
  --store medzpoint --theme 181128757515 --allow-live \
  --only templates/page.digital-health-twin.json
```

Danach ist die Section-Referenz aufgelöst und die Seite funktioniert.

---

## Workflow B: Avatar-Varianten in Blender neu bauen

Sie haben `scripts/build_avatar_variants.py` geändert (z.B. den Falloff-Radius)
und wollen beide GLB-Exporte neu erzeugen.

1. In den Blender-Ordner wechseln:

   ```bash
   cd "/Users/ssmd/Library/CloudStorage/GoogleDrive-team@sanexio.de/Meine Ablage/Claude-OS/projects/Juvantis/DHT/juvantis-ios/Blender"
   ```

2. Avatar „gesund" bauen:

   ```bash
   blender --background \
     --python scripts/build_avatar_variants.py \
     -- \
     --base models/avatar_base.glb \
     --out exports/avatar_healthy.glb \
     --state healthy
   ```

   Laufzeit: ~2 Sekunden. Wenn `exports/avatar_healthy.glb` danach existiert
   und einigermaßen gleich groß ist wie vorher (~1.4 MB) → passt.

3. Avatar „krank" bauen:

   ```bash
   blender --background \
     --python scripts/build_avatar_variants.py \
     -- \
     --base models/avatar_base.glb \
     --out exports/avatar_sick.glb \
     --state sick
   ```

4. Beide Exporte auf die Shopify-Seite hochladen (**per Browser**, NICHT per CLI —
   die CLI syncht keine Binär-Assets, siehe LL-030). Shopify-Admin → `Content → Files`
   → Upload → die beiden GLB-Dateien.

5. URLs im Theme-Editor in der Section `dht-avatar-compare.liquid` eintragen.

6. Push mit nur der geänderten Section (siehe Workflow A).

### Wenn Blender „unknown argument" meckert

Sie haben das `--` vergessen. Prüfen Sie: **Zwischen** `--python script.py`
und Ihren eigenen Flags muss ein freistehendes `--` stehen.

**Falsch:**
```bash
blender --background --python build.py --base models/... --out ...
```

**Richtig:**
```bash
blender --background --python build.py -- --base models/... --out ...
```

---

## Workflow C: Telegram-Bridge starten (Claude-Code-Session mit iPhone-Bridge)

1. Wichtig: **NICHT** aus dem Claude-OS-Root starten (LL-025 — Ressourcen-Exhaustion):

   ```bash
   cd ~
   ```

2. Bridge starten:

   ```bash
   claude --dangerously-load-development-channels server:telegram-bridge
   ```

3. Auf dem iPhone sollte in Telegram eine Nachricht kommen:

   ```
   🟢 Claude Code Telegram-Bridge gestartet
   ```

4. Falls nicht → `projects/telegram-bridge/_config/WORKFLOW_CHECKLIST.md` WF-5
   (Diagnose) durchgehen.

---

## Typische Abbruchstellen, wenn man müde ist

| Fehler | Schnellfix |
|---|---|
| `npx shopify` sagt „not a theme directory" | `cd` ins `theme/`-Unterverzeichnis vergessen |
| `command not found: npx` | `source ~/.nvm/nvm.sh` vergessen |
| Push scheitert mit „Abschnittstyp" | Section ohne Template gepusht → auch Template mitgeben |
| Avatar-GLB wird nicht neu gebaut | Blender-Alias im neuen Terminal nicht aktiv (`source ~/.zshrc`) |
| Cursor öffnet parallel und die Load-Avg explodiert | LL-025: Cursor NIE auf Claude-OS-Root öffnen, nur auf `projects/Juvantis/` |

---

*Manuell-Workflow, 2026-04-08*
