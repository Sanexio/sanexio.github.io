# 05 — Shopify- und Blender-Workflows im Terminal

> **Stand 2026-04-08** — Dieses Modul sammelt die Terminal-Befehle, die beim
> täglichen Arbeiten an der Juvantis-Website (`projects/Juvantis/website/theme/`)
> und der Blender-Avatar-Pipeline (`projects/Juvantis/DHT/juvantis-ios/Blender/`)
> wirklich benutzt werden. Es erweitert die früheren Module 01–04 um Befehle,
> die in den Session-Logs regelmäßig auftauchen, aber bisher nicht erklärt waren.

---

## Warum dieses Modul?

In den ersten vier Terminal-Modulen haben Sie `cd`, `ls`, `git commit` und
`npm install` kennengelernt. Das reicht, um den Rechner zu bedienen. Was
aber fehlt, sind die **projektspezifischen Befehlsketten**, die in Ihrer
täglichen Arbeit an Juvantis ständig vorkommen:

- **`source ~/.nvm/nvm.sh`** — warum vor jedem Shopify-Befehl?
- **`npx shopify theme push --only sections/X --only templates/Y`** — was macht `--only`?
- **`curl -s https://sanexio.eu/…`** — warum statt "WebFetch"?
- **`blender --background --python script.py -- …`** — was bedeutet das `--`?

Jede dieser Zeilen steht in einer unserer globalen Regeln (R-008, R-016, R-017,
LL-029). Hier erklären wir, **warum** sie so aussieht, wie sie aussieht.

---

## Kapitel 1 — Warum `source ~/.nvm/nvm.sh`?

### Das Problem
`nvm` ist der **Node Version Manager**. Er erlaubt Ihnen, parallel mehrere
Node.js-Versionen auf demselben Mac installiert zu haben. Das ist wichtig,
weil unterschiedliche Projekte unterschiedliche Node-Versionen brauchen.

`nvm` ist aber **keine normale Unix-Anwendung**. Es ist eine Shell-Funktion,
die sich beim Öffnen eines Terminal-Fensters registriert — und zwar nur,
wenn die Zeile `. ~/.nvm/nvm.sh` in Ihrer `~/.zshrc` steht (oder manuell
ausgeführt wird).

In älteren Terminal-Sessions oder in non-login-shells (z.B. wenn Cursor
oder ein Hook-Script ein Terminal aufmacht) ist nvm oft **nicht geladen**.
Dann scheitert der Aufruf `npx shopify theme push` mit `command not found: npx`
oder findet eine völlig falsche Node-Version.

### Die Lösung — Regel R-008
Vor **jedem** `npx shopify`-Befehl explizit nvm nachladen:

```bash
source ~/.nvm/nvm.sh && npx shopify theme push --store medzpoint --theme 181128757515
```

Das `source` (gleichbedeutend mit dem Punkt-Operator `.`) führt die Datei
im **aktuellen** Shell-Kontext aus — nicht in einer Unter-Shell. Nur so
wird `nvm_use`, `npm_prefix` etc. in dieser Sitzung bekannt.

### Was `source` tatsächlich macht

Normalerweise, wenn Sie ein Shell-Script ausführen (`./start.sh`), startet
der Mac eine **neue Shell**, führt die Befehle dort aus und wirft sie weg.
Änderungen an Umgebungsvariablen bleiben in der Unter-Shell. Deshalb kann
ein Shell-Script Sie nie in ein anderes Verzeichnis versetzen — der `cd`
endet mit der Unter-Shell.

`source` umgeht das: Es führt die Befehle **im eigenen Prozess** aus. Alles,
was das Script an Variablen oder Funktionen setzt, landet in Ihrer laufenden
Shell.

Das ist bei `nvm` zwingend nötig, weil nvm keine ausführbare Datei ist,
sondern nur eine Sammlung von Shell-Funktionen. Ohne `source` würden diese
Funktionen in einer Unter-Shell erzeugt und sofort wieder verfallen.

---

## Kapitel 2 — `npx shopify theme push` und die `--only`-Filter

### Der ganze Befehl im Kontext

```bash
source ~/.nvm/nvm.sh && npx shopify theme push \
  --store medzpoint \
  --theme 181128757515 \
  --allow-live \
  --only sections/dht-avatar-compare.liquid \
  --only templates/page.digital-health-twin.json
```

Schauen wir uns jeden Teil an:

**`npx shopify`** — `npx` startet ein Node-Package, ohne es global
installieren zu müssen. Shopify CLI existiert als `@shopify/cli` in der
npm-Registry. `npx` lädt es im Hintergrund, führt es aus und wirft es
nach Ende der Session weg. Das ist praktisch, weil es immer die neueste
Version holt — aber auch langsamer als eine globale Installation.

**`theme push`** — der Befehl, der lokale Theme-Dateien auf den Shopify-Store
hochlädt. Das Gegenstück ist `theme pull` (Download), und `theme dev`
startet einen Entwicklungs-Server mit Live-Reload.

**`--store medzpoint`** — der Kurzname Ihres Shopify-Stores. Steht in der
URL: `medzpoint.myshopify.com`. Sie brauchen das, damit die CLI weiß,
mit welchem Store sie reden soll (ein Mac kann mehrere Stores haben).

**`--theme 181128757515`** — die Theme-ID innerhalb des Stores. Ein Store
kann mehrere Themes gleichzeitig haben (live, draft, test). Die ID finden
Sie im Shopify Admin unter `Online Store → Themes → Customize` in der URL.

**`--allow-live`** — Sicherheitsschranke. Shopify hindert Sie standardmäßig
daran, direkt ins Live-Theme zu pushen, damit Sie nicht aus Versehen die
Kunden-Site zerbrechen. `--allow-live` sagt „ich weiß was ich tue". In
Dr. Strackes Setup pushen wir direkt ins Live-Theme, weil der `shopify-theme`-Branch
via GitHub-Sync ohnehin permanent dort landet — siehe CLAUDE.md.

**`--only`** — **das ist der wichtigste Teil des Befehls**.

### Warum `--only` fast immer benutzt werden muss

Ohne `--only` pusht die Shopify-CLI **alle** Dateien im Theme-Ordner
(mehrere hundert MB, mehrere tausend Dateien). Das dauert 2–5 Minuten
und kann zu Rate-Limit-Fehlern führen.

Mit `--only` pushen Sie genau die Dateien, die Sie geändert haben. Die
Syntax ist beliebig oft wiederholbar:

```bash
--only sections/header.liquid \
--only sections/footer.liquid \
--only templates/index.json
```

Das pusht exakt drei Dateien. Dauert 5 Sekunden.

**Regel R-013 (aus `_memory/MEMORY.md`):** Wenn eine Section und das
dazugehörige Template geändert wurden, **immer beide zusammen pushen**.
Sonst meckert Shopify mit „Abschnittstyp existiert nicht", weil das
Template eine Section referenziert, die im Store-Theme noch nicht da ist.

### Wildcard-Filter

`--only` versteht auch `*`:

```bash
--only 'sections/dht-*.liquid'
```

Das pusht `dht-avatar-compare.liquid`, `dht-hero.liquid`, `dht-pricing.liquid`
auf einmal. Achten Sie auf die **Anführungszeichen** — sonst expandiert Ihre
Shell (zsh/bash) das Wildcard schon vor der Übergabe an `npx`, und Shopify
sieht nur die erste Datei.

### Aus welchem Ordner darf der Befehl laufen?

**Regel R-017:** Nur aus dem **Theme-Root**. Das ist der Ordner, in dem
`config/settings_data.json` und `layout/theme.liquid` liegen. Bei Juvantis:

```
projects/Juvantis/website/theme/
```

Wenn Sie den Befehl aus einem Unterordner wie `sections/` ausführen, sucht
die CLI die Theme-Struktur ab dem aktuellen Ordner und findet nichts. Fehler:
"not a theme directory".

**Merksatz:** „Erst `cd theme`, dann `npx shopify`."

---

## Kapitel 3 — `curl -s` statt Browser-Refresh (Regel R-016)

### Das Problem
Nach einem `theme push` wollen Sie natürlich prüfen, ob Ihre Änderungen
live sind. Intuitiv öffnet man dafür den Browser und lädt die Seite neu.

Das funktioniert aber **schlecht**, weil der Browser aggressiv cached
(Service Worker, Shopify-CDN, Cloudflare). Sie sehen oft 15 Minuten lang
die alte Version, obwohl der neue Code längst online ist.

### Die Lösung
Verwenden Sie `curl -s` im Terminal, um den HTML-Code direkt abzuholen,
ohne Browser-Cache:

```bash
curl -s https://sanexio.eu/pages/digital-health-twin | grep -A 2 'dht-avatar-compare'
```

**Was die Flags bedeuten:**
- `-s` (silent) — unterdrückt den Fortschrittsbalken. Nur die Antwort kommt.
- `| grep -A 2 '…'` — durchsucht die Ausgabe nach einem Suchtext und gibt
  2 Zeilen danach aus. So sehen Sie direkt, ob Ihr neues Markup drin ist.

### Warum auch nicht WebFetch (Claude-Tool)?
Das Claude-Tool WebFetch cached Antworten 15 Minuten. Für eine einmalige
Recherche ist das praktisch, für eine Verifikation nach dem Push ist es
fatal — Sie bekommen die veraltete Version und halten sie für den neuen
Stand.

**Merksatz:** „Browser zum Ansehen, `curl` zum Verifizieren."

---

## Kapitel 4 — Blender headless aufrufen

### Der typische Befehl

```bash
blender --background \
  --python build_avatar_variants.py \
  -- \
  --base models/avatar_base.glb \
  --out exports/avatar_sick.glb \
  --state sick
```

### Was jeder Teil macht

**`blender`** — das Blender-Executable. Auf macOS liegt es in
`/Applications/Blender.app/Contents/MacOS/Blender` — wenn Sie es nicht
direkt aus dem Terminal starten können, fehlt der Eintrag in Ihrem `PATH`.

Ein Alias in `~/.zshrc` hilft:

```bash
alias blender='/Applications/Blender.app/Contents/MacOS/Blender'
```

**`--background`** — Blender startet im **Headless-Modus**, also ohne UI.
Das ist entscheidend, weil Blender sonst ein Fenster öffnen würde, das
über einen Terminal-SSH-Zugang gar nicht darstellbar wäre. In unseren
Avatar-Pipelines läuft alles headless.

**`--python build_avatar_variants.py`** — das Python-Script, das Blender
ausführen soll. Blender hat eine eingebettete Python-Interpreter-Instanz,
über die man mit dem API `bpy` auf die 3D-Szene zugreift.

**`--`** — das ist der **wichtigste und am meisten missverstandene Teil**.

### Warum das einsame `--` in der Mitte steht

Blender hat seine eigenen Kommandozeilen-Optionen (`--background`,
`--python`, `--render-output`, …). Wenn Sie nach `--python script.py`
weitere Flags schreiben, denkt Blender, **es seien seine eigenen Flags**,
und meldet „unknown argument: --base".

Mit dem einsamen `--` sagen Sie zu Blender: „Ab hier kommen keine Blender-Flags
mehr, alles Weitere sind Argumente für das Python-Script." Im Python-Script
können Sie diese mit `sys.argv` abgreifen. Konvention in unserer Avatar-Pipeline:

```python
import sys
import argparse

# Blender legt alles NACH -- in sys.argv ab
# Alles VOR -- sind Blender-eigene Flags, die uns nicht interessieren
argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []

parser = argparse.ArgumentParser()
parser.add_argument("--base", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--state", choices=["healthy", "sick"], required=True)
args = parser.parse_args(argv)
```

**Merksatz:** „Vor dem `--` ist Blender, nach dem `--` sind wir."

### Warum headless und nicht in der Blender-GUI?

Drei Gründe:

1. **Automatisierung.** Ein Shell-Script kann den Befehl beliebig oft
   ausführen, z.B. alle 15 Minuten oder nach jedem Commit im Juvantis-Repo.
   Eine GUI-Sitzung braucht einen Menschen vor dem Bildschirm.
2. **Reproduzierbarkeit.** Headless-Runs hängen nur von der Python-Datei ab.
   Wenn Sie das Script in 6 Monaten wieder laufen lassen, kommt exakt derselbe
   Avatar heraus. Eine GUI-Sitzung ist immer ein bisschen unterschiedlich.
3. **Geschwindigkeit.** Keine Render-Preview, keine UI-Updates. Der Avatar-Build
   für Juvantis dauert headless 2–3 Sekunden, in der GUI 15–20 Sekunden.

### Warum wird das GLB so klein?

Beobachtung: Unsere exportierten `avatar_healthy.glb` und `avatar_sick.glb`
sind jeweils nur 1,4 MB groß. Das liegt am GLB-Format:

- **GLB** ist die **binäre** Version von glTF (JSON + Binärdaten).
- Es wird standardmäßig mit **Draco-Kompression** exportiert, wenn der
  Blender-Exporter das anbietet.
- Textur-Kanäle werden in einer einzigen Datei zusammengefasst.

Das ist gut für Web-Viewer (`<model-viewer>` auf sanexio.eu) und für die
iOS-App, wo jedes MB extra Datenvolumen, Download-Zeit und Speicher bedeutet.

---

## Kapitel 5 — Mini-Cheat-Sheet

Alles in einem Überblick, zum Ausdrucken oder neben den Monitor pinnen:

### Shopify-Push
```bash
# Ein Standard-Push für eine Section + ihr Template:
cd projects/Juvantis/website/theme
source ~/.nvm/nvm.sh && npx shopify theme push \
  --store medzpoint --theme 181128757515 --allow-live \
  --only sections/dht-avatar-compare.liquid \
  --only templates/page.digital-health-twin.json

# Verifikation nach dem Push:
curl -s https://sanexio.eu/pages/digital-health-twin | grep -A 2 'dht-avatar-compare'
```

### Blender-Avatar-Build
```bash
cd projects/Juvantis/DHT/juvantis-ios/Blender
blender --background \
  --python scripts/build_avatar_variants.py \
  -- \
  --base models/avatar_base.glb \
  --out exports/avatar_sick.glb \
  --state sick
```

### Telegram-Bridge starten
```bash
cd ~  # wichtig: nicht im Claude-OS-Root (LL-025)
claude --dangerously-load-development-channels server:telegram-bridge
```

---

## Fehlerbilder, die aus diesen Befehlen entstehen können

| Symptom | Ursache | Lösung |
|---|---|---|
| `command not found: npx` | nvm nicht geladen | `source ~/.nvm/nvm.sh` |
| `not a theme directory` | Falscher Ordner | In `theme/` wechseln |
| `Abschnittstyp existiert nicht` | Section ohne Template gepusht | Beide zusammen mit `--only` |
| `unknown argument: --base` (Blender) | `--` vergessen | `--` vor Script-Flags einfügen |
| Push klappt, Seite sieht alt aus | Browser-Cache | `curl -s` prüft |
| Blender öffnet die UI trotz `--background` | `--background` hinter `--` gestellt | `--background` MUSS vor `--` stehen |

---

## Was Sie nach diesem Modul wissen

1. Warum nvm per `source` nachgeladen werden muss (Shell-Funktionen vs. Executables)
2. Wie `npx shopify theme push --only` funktioniert und warum `--only` fast immer nötig ist
3. Warum `curl -s` für Post-Push-Verifikation besser ist als der Browser
4. Was `blender --background --python … --` mit dem einsamen Doppelstrich erreicht
5. Wie Sie alle drei Workflows (Shopify, Blender, Telegram-Bridge) eigenständig starten

---

## Nächste Schritte

- **`02-swiftui.md`** in `_tutorials/ios-programmierung/` — wenn Sie mit der iOS-App weitermachen
- **`03-avatar-pipeline.md`** in `_tutorials/blender/` — tiefer in die Blender-Python-API
- **`04-cli-workflow.md`** in `_tutorials/shopify/` — der kompletten Shopify-Deployment-Workflow

---

*Initial-Erstellung: 2026-04-08. Teil des Tutorial-Refresh im Rahmen des Konsistenz-Audits.*
