# Terminal-Befehle: Git — Manueller Workflow

## Wann nutzt du diesen Cheat Sheet?

Wenn Claude nicht verfügbar ist oder du Git selbst verstehen willst. Hier sind die Git-Befehle, die du selbst tippen kannst.

---

## Initialisierung (einmalig)

### Projekt von GitHub klonen

```bash
git clone https://github.com/Sanexio/JUVANTIS.git
cd JUVANTIS
```

Das lädt das ganze Projekt mit kompletter Historia runter.

---

### Neues Git-Projekt starten

```bash
git init
```

Erstellt einen unsichtbaren `.git/` Ordner. Danach kannst du Commits machen.

---

## Status prüfen

### `git status` — Was hat sich geändert?

```bash
git status
```

Zeigt:
```
On branch master
Changes not staged for commit:
  modified:   avatar.swift
  deleted:    old-config.txt

Untracked files:
  new-feature.js
```

Das bedeutet:
- `avatar.swift` wurde geändert
- `old-config.txt` wurde gelöscht
- `new-feature.js` ist neu (Git kennt es noch nicht)

---

### `git log` — Alle Commits anzeigen

```bash
git log
```

Zeigt alle Commits (neueste zuerst):
```
commit abc123def456
Author: Dr. Stracke
Date:   2 Apr 2026 10:42

    Add avatar customization feature

commit xyz789abc123
Author: Dr. Stracke
Date:   1 Apr 2026 15:30

    Fix animation bug
```

**Einzeilig (übersichtlicher):**
```bash
git log --oneline
```

```
abc123d Add avatar customization
xyz789a Fix animation bug
def456e Update header
```

---

### `git diff` — Was genau hat sich geändert?

```bash
git diff
```

Zeigt alle Änderungen:
```
diff --git a/avatar.swift b/avatar.swift
@@ -5,3 +5,4 @@
 func rotate() {
   // Code
+  animate()    ← Diese Zeile wurde hinzugefügt
 }
```

---

## Commits erstellen (speichern)

### `git add` — Änderungen vorbereiten

```bash
git add avatar.swift
```

Adds nur diese Datei zum nächsten Commit.

**Alle Änderungen auf einmal:**
```bash
git add .
```

Der Punkt `.` bedeutet "alles im aktuellen Ordner".

---

### `git commit` — Änderungen speichern

```bash
git commit -m "Add avatar customization feature"
```

Speichert die Änderungen mit einer Beschreibung.

**Wichtig: Die Nachricht muss aussagekräftig sein!**
- ✅ Gut: `"Add avatar customization feature"`
- ✅ Gut: `"Fix animation bug in rotation"`
- ❌ Schlecht: `"fix"`
- ❌ Schlecht: `"update"`

---

## Mit Remote (GitHub) arbeiten

### `git push` — Zu GitHub hochladen

```bash
git push
```

oder explizit:
```bash
git push origin master
```

Lädt alle lokalen Commits zu GitHub hoch.

---

### `git pull` — Von GitHub abholen

```bash
git pull
```

oder explizit:
```bash
git pull origin master
```

Holt die neueste Version vom Remote (GitHub).

---

## Branches (parallele Arbeit)

### `git branch` — Branches verwalten

```bash
git branch
```

Zeigt deine lokalen Branches:
```
* master
  feature/avatar
  feature/pricing
```

Der `*` zeigt wo du gerade bist.

**Neuen Branch erstellen:**
```bash
git branch feature/new-animation
```

**Branch löschen:**
```bash
git branch -d feature/new-animation
```

---

### `git checkout` — Zwischen Branches wechseln

```bash
git checkout feature/avatar
```

Wechselt zum Branch `feature/avatar`.

**Branch erstellen UND sofort wechseln:**
```bash
git checkout -b feature/new-feature
```

Das ist dasselbe wie:
```bash
git branch feature/new-feature
git checkout feature/new-feature
```

---

### `git merge` — Branches zusammenführen

```bash
git checkout master
git merge feature/avatar
```

Das bedeutet:
1. Wechsle zu `master`
2. Merge alle Änderungen von `feature/avatar` hinein

---

## Fehler beheben

### `git revert` — Commit rückgängig machen (sicher)

```bash
git revert abc123d
```

Erstellt einen **neuen Commit**, der die Änderungen von `abc123d` rückgängig macht.

**Wichtig:** Die alte Version ist noch in der History.

---

### `git reset` — Zurück zu einem Commit (⚠️ vorsicht!)

```bash
git reset --soft abc123d
```

Setzt dich zu Commit `abc123d` zurück, aber deine lokalen Änderungen bleiben.

```bash
git reset --hard abc123d
```

Setzt ALLES zurück — lokale Änderungen sind weg. ⚠️ Irreversibel!

---

## Cheat Sheet: Täglicher Git-Workflow

```bash
# Morgens: Neueste Version holen
git pull

# Tagsüber: Deine Arbeit speichern (mehrmals)
git status
git add .
git commit -m "Deine Änderung"

# Abends: Zu GitHub hochladen
git push
```

**Mit Branches (für größere Features):**
```bash
# Feature starten
git checkout -b feature/my-feature

# Arbeit speichern (mehrmals)
git add .
git commit -m "..."
git push origin feature/my-feature

# Später: Feature ist fertig
git checkout master
git pull
git merge feature/my-feature
git push
```

---

## Wichtige Befehle im Überblick

| Befehl | Was es macht |
|--------|------------|
| `git clone URL` | Projekt von GitHub abholen |
| `git status` | Was hat sich geändert? |
| `git add .` | Alle Änderungen vorbereiten |
| `git commit -m "..."` | Änderungen speichern |
| `git push` | Zu GitHub hochladen |
| `git pull` | Von GitHub abholen |
| `git log --oneline` | Letzte Commits anzeigen |
| `git branch -b name` | Neuen Branch erstellen |
| `git checkout name` | Zum Branch wechseln |
| `git merge name` | Branch zusammenführen |
| `git revert abc123d` | Commit rückgängig machen |

---

## Häufige Probleme

### Problem: "Merge Konflikt"

```
<<<<<<< HEAD
meine Version
=======
ihre Version
>>>>>>>
```

**Lösung:**
1. Öffne die Datei
2. Entscheide welche Version du behalten willst
3. Lösche die Konflikt-Marker
4. Commit die Lösung

---

### Problem: "Ich habe auf dem falschen Branch gearbeitet"

```bash
git stash               # Änderungen temporär speichern
git checkout feature/my-feature
git stash pop           # Änderungen wiederherstellen
```

---

### Problem: "Ich kann nicht pushen"

Wahrscheinlich gibt es neuere Commits auf GitHub:

```bash
git pull
git push
```

---

## Git am Beispiel: Juvantis-Workflow

```bash
# 1. Projekt klonen
git clone https://github.com/Sanexio/JUVANTIS.git
cd JUVANTIS

# 2. Neuer Branch für Shopify-Arbeit
git checkout -b feature/product-gallery

# 3. Du änderst sections/product-gallery.liquid in Cursor

# 4. Changes speichern
git status
git add sections/product-gallery.liquid
git commit -m "Add 4-column product gallery with sorting"

# 5. Zu GitHub pushen
git push origin feature/product-gallery

# 6. Feature ist fertig, merge zu master
git checkout master
git pull
git merge feature/product-gallery
git push

# 7. Aufräumen
git branch -d feature/product-gallery
```

---

*Git ist dein Sicherheitsnetz. Jeder Commit ist eine Rettungsleine.*
