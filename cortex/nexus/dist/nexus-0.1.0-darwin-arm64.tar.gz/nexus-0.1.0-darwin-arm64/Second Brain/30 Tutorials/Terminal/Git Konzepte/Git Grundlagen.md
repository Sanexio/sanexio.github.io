---
type: tutorial
aliases: [Git, GitHub, Versionskontrolle, VCS, Repository, Repo]
tags:
  - tutorial
  - git
  - github
  - versionskontrolle
source: Second Brain/30 Tutorials/Git & GitHub/
---

# Git & GitHub — Grundlagen

> Diese Seite gibt dir den **konzeptuellen Überblick** über Git und GitHub.
> Die konkreten Befehle und Workflows sind als eigene Module im Terminal-Tutorial:
> [[Terminal/02-git|Terminal 02 — Git]] und [[Terminal/04-github|Terminal 04 — GitHub]].

> [!info] Lesezeit: 10 Minuten · Voraussetzung: keine

---

## 1. Warum brauchst du Versionskontrolle?

Stell dir vor, du arbeitest an einem Word-Dokument. Du speicherst es unterschiedlich:

```
Praxis-Konzept.docx
Praxis-Konzept_v2.docx
Praxis-Konzept_v2_final.docx
Praxis-Konzept_v2_final_korrigiert.docx
Praxis-Konzept_v3_DAS_IST_DAS_FINALE.docx
```

Jeder kennt das. Bei Code passiert das tausendfach — eine Praxis-Webseite hat
hunderte Dateien, hunderte Änderungen pro Tag.

**Versionskontrolle** ist die professionelle Antwort darauf:

- Jede Änderung wird mit Datum, Autor und Beschreibung gespeichert
- Du kannst zu jedem früheren Zustand zurückspringen — sekundenschnell
- Mehrere Personen (oder du + Claude) können parallel arbeiten, ohne sich zu überschreiben
- Du siehst genau, **wer was wann warum** geändert hat

Das System, das wir nutzen, heißt **Git**. Es ist kostenlos, läuft lokal auf deinem Mac und ist das Standard-Tool für so ziemlich jedes Software-Projekt der Welt.

---

## 2. Git vs. GitHub — was ist der Unterschied?

| Begriff | Was es ist | Wo es lebt |
|---|---|---|
| **Git** | Das Programm für Versionskontrolle. Speichert die Geschichte deiner Dateien. | Lokal auf deinem Mac (auch ohne Internet) |
| **GitHub** | Eine Webseite, die Git-Repositories online hostet. | In der Cloud, [github.com](https://github.com) |

Analogie:
- **Git** ist wie ein **Notizbuch** in deiner Tasche
- **GitHub** ist wie eine **Bibliothek** im Internet, in der dein Notizbuch eine Kopie hat

Du kannst Git auch komplett ohne GitHub nutzen. Die meisten nutzen beides zusammen, weil GitHub als Backup, Backup-Synchronisation zwischen Geräten und Kollaborations-Plattform dient.

> **Alternative zu GitHub:** GitLab, Bitbucket, Codeberg, dein eigener Server. Funktional sehr ähnlich. Du nutzt GitHub.

---

## 3. Die Kern-Konzepte (auf 1 DIN A4 erklärt)

### Repository (kurz: Repo)
Ein Ordner, in dem Git die Geschichte verfolgt. Du erkennst ihn am versteckten `.git/`-Unterordner, in dem Git all seine Notizen speichert.

```
~/Cortex/Nexus/             ← Repository
├── .git/                    ← Versteckter Git-Speicher (Geschichte)
├── _memory/
├── _rules/
└── ...
```

### Commit
Ein **Schnappschuss** deines Projekts zu einem bestimmten Zeitpunkt — mit Beschreibung. Wie ein „Speichern unter…" mit Notiz, was sich geändert hat.

```
2026-04-25 09:14  Header zurück 1-Zeile (PXZ 2.7.35)
2026-04-25 08:47  9 DE-Slug-Stubs angelegt
2026-04-24 22:03  Doctolib-CTA in Footer-Spalte 1
```

Jeder Commit bekommt einen eindeutigen Hash (z. B. `5e9bb22`). Mit dem kannst du jederzeit zu diesem genauen Stand zurückspringen.

### Branch (Zweig)
Eine **parallele Linie** in der Geschichte. Du arbeitest meistens auf `main` (Hauptlinie). Wenn du etwas Neues ausprobieren willst, erstellst du einen Branch — und kannst ihn später entweder einarbeiten (mergen) oder verwerfen.

```
main:           ●───●───●───●───●───●───●  (heute)
                          │
feature-test:             ●───●───●        (Versuch, der parallel läuft)
```

### Remote
Ein **Spiegel deines Repos im Internet** (z. B. auf GitHub). Standard-Name: `origin`. Mit `git push` schickst du deine Commits dorthin, mit `git pull` holst du dir Änderungen.

### Working Tree, Staging, History
- **Working Tree:** der Stand der Dateien, wie du sie gerade siehst und bearbeitest
- **Staging Area:** ein Zwischenkorb für Änderungen, die du gleich committen willst (mit `git add`)
- **History (Commits):** die abgeschlossenen Schnappschüsse

```
Working Tree   ─ git add ─▶   Staging Area   ─ git commit ─▶   History
(Bearbeitung)                  (Vorbereitung)                   (Schnappschuss)
                                                                       │
                                                                  git push
                                                                       ▼
                                                                 GitHub-Remote
```

---

## 4. Der typische Workflow (95 % deiner Zeit)

Egal ob Praxis-Webseite, Juvantis-Theme oder Nexus — der Ablauf ist meistens:

```bash
# 1. Stand holen, bevor du anfängst (sehr wichtig!)
git pull

# 2. Datei ändern, speichern (in Cursor/VSCode/Editor)
# (kein Git-Befehl nötig)

# 3. Schauen, was geändert wurde
git status
git diff

# 4. Änderung als Commit festhalten
git add <datei>            # oder git add -A für alles
git commit -m "Was du geändert hast"

# 5. Nach GitHub schicken (Backup + Sync)
git push
```

Mit Claude Code im Terminal läuft das oft so, dass Claude die Befehle für dich vorschlägt — du musst sie nur freigeben.

**Mehr in der Tiefe:** [[Terminal/02-git|Terminal 02 — Git]] (sieben Befehle für 95 % der Arbeit) und [[Terminal/04-github|Terminal 04 — GitHub]].

---

## 5. Was passiert, wenn etwas schiefgeht?

Ein paar typische Probleme — und was du tun kannst:

| Problem | Was tun? |
|---|---|
| **„Ich habe versehentlich gelöscht, was ich brauche"** | `git checkout -- <datei>` (verwirft Änderung, holt letzte Commit-Version) |
| **„Mein letzter Commit war Mist"** | `git commit --amend` (überschreibt letzten Commit) — nur wenn noch nicht gepusht |
| **„Ich brauche den Stand von gestern Mittag"** | `git log` → Hash kopieren → `git checkout <hash>` |
| **„Konflikt — beide haben die gleiche Zeile geändert"** | Konflikt-Marker in Datei manuell auflösen, dann `git add` + `git commit` |
| **„Ich habe in den falschen Branch committet"** | `git reset HEAD~1` + auf richtigen Branch wechseln + neu committen |

> [!warning] Vorsicht bei destruktiven Befehlen
> `git reset --hard`, `git push --force`, `git rebase` können **Commits löschen oder überschreiben**. Frag im Zweifel Claude erst, bevor du diese Befehle ausführst — Claude warnt dich nach den Cortex-Regeln vorher.

---

## 6. GitHub-spezifische Konzepte

GitHub ergänzt Git um eine ganze Plattform:

| Feature | Wofür? |
|---|---|
| **Pull Request (PR)** | Vorschlag „diese Branch in main mergen" — mit Diskussion, Review, Tests |
| **Issue** | Aufgaben- oder Bug-Tracking, direkt im Repo |
| **Actions** | Automatik (CI/CD): Bei Push wird Code getestet/deployed |
| **Releases** | Versionierte Pakete (z. B. `v1.0.0`) mit Changelog |
| **Wiki** | Dokumentation neben dem Code |
| **GitHub Pages** | Kostenloses Static-Hosting direkt aus dem Repo |

---

## 7. Deine konkreten Repos

| Projekt | Repo / Branch | Was liegt drin? |
|---|---|---|
| **Nexus** (dieser Vault) | privates Repo, Branch `main` | Tutorials, Regeln, Memory, Tools — synct zwischen deinen Geräten |
| **Juvantis Theme** | [github.com/Sanexio/JUVANTIS](https://github.com/Sanexio/JUVANTIS), Branch `shopify-theme` | Shopify-Theme-Klon. Pushes triggern automatisch Shopify-Sync. |
| **Praxis-Webseite Theme** | lokales Git im Theme-Ordner (kein Remote) | WordPress-Theme `praxiszentrum`. Aktuell nur lokal versioniert. |
| **Cortex-Web** | lokales Git, Cluster-Mini-02 | Common-Trunk-Dachprojekt mit Adapter-Suite |

---

## 8. Wichtige Regeln & Lessons Learned

- **LL-049 (Sync-Hygiene):** Vor jedem Session-Start in Nexus zuerst `git pull --ff-only`. Hintergrund: Branch-Split 2026-04-24/25 mit 140 divergenten Commits. **Wird nie wieder passieren.**
- **LL-030:** Shopify-GitHub-Sync syncht **keine Binärdateien** (GLB-Avatare, Bilder). Müssen lokal separat committet werden.
- **LL-038:** iCloud-Snapshots sind Git-Zeitbomben — nach Copy `git fetch` + `git reset --hard origin/<branch>`.
- **WV-001 (offen):** Git-Divergenz Nexus / Auto-Sync defekt — siehe [[Wiedervorlagen]].

---

## 9. Lern-Reihenfolge

Wenn du wirklich von Null anfängst:

1. **Diese Seite** — die Konzepte
2. [[Terminal/02-git|Terminal 02 — Git (Theorie)]] — die 7 Befehle in der Tiefe
3. [[Terminal/02-git_manuell|Terminal 02 — Manuell]] — selbst im Terminal nachvollziehen
4. [[Terminal/02-git_claude|Terminal 02 — Claude]] — wie Claude Git für dich nutzt
5. [[Terminal/04-github|Terminal 04 — GitHub]] — Cloud-Synchronisation, PRs, SSH-Keys

**Wenn dich „Branches und Merging in der Praxis" interessiert:**
[[WordPress/03-git-bootstrap-und-page-registry|WordPress 03 — Git-Bootstrap]] zeigt einen echten Use-Case aus deinem Praxis-Webseiten-Projekt.

---

## 10. Spickzettel — die wichtigsten Befehle

```bash
git status              # Was hat sich geändert?
git diff                # Welche Zeilen genau?
git log --oneline -10   # Die letzten 10 Commits

git pull                # Stand vom Server holen
git add <datei>         # Datei für Commit vormerken
git add -A              # Alle Änderungen vormerken
git commit -m "Text"    # Schnappschuss erstellen
git push                # An Server schicken

git branch              # Welche Branches gibt es?
git checkout <branch>   # In Branch wechseln
git checkout -b <neu>   # Neuen Branch erstellen
git merge <branch>      # Branch in aktuellen einarbeiten

git checkout -- <datei> # Lokale Änderungen verwerfen (Vorsicht)
```

---

## Verwandte Notizen

- [[_MOC Tutorials]] — Dach-MOC aller Tutorials
- [[_Basiswissen Schnelleinstieg]] — Pfad B nutzt Git
- [[Terminal Grundlagen]] — Übergeordnete Tutorial-Domäne
- [[Terminal/02-git|Terminal 02 — Git]] — Praxis-Modul
- [[Terminal/04-github|Terminal 04 — GitHub]] — Cloud-Modul
- [[Git-Begriffe]] — Glossar (falls vorhanden)
- [[LL-049]] — Sync-Hygiene-Regel
