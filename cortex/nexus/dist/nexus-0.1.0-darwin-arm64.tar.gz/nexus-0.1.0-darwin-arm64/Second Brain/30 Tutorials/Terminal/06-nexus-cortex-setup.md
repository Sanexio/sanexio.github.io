---
type: tutorial
aliases: [Nexus-Cortex-Setup, Multi-Device Setup, Geräte-Setup]
tags:
  - tutorial
  - terminal
  - cortex
  - nexus
  - setup
  - stub
moved_to: Second Brain/30 Tutorials/Cortex & Nexus/
status: redirect
---

# 06 — Nexus + Cortex Setup (umgezogen)

> [!info] Diese Seite ist ein Verweis (Stub)
> Der Inhalt wurde am 2026-04-30 in die eigene Domäne **Cortex & Nexus**
> verschoben und dort vertieft. Die alten Wiki-Links bleiben funktional —
> sie führen jetzt hierher und von hier aus weiter.

## Wo finde ich die Inhalte heute?

| Thema | Neue Position |
|---|---|
| **Was ist Nexus, was ist Cortex** (Architektur, Container-Modell, Designgrundsätze) | [[Cortex & Nexus/01-architektur-und-philosophie]] |
| **Drei-Befehle-Setup, Auto-Sync, iPad/iPhone, Geräte-Registry** | [[Cortex & Nexus/02-multi-device-setup]] |
| **Domänen-Landing** | [[Cortex & Nexus Grundlagen]] |

## Warum der Umzug?

Cortex/Nexus ist **das Substrat** des gesamten Ökosystems — keine Terminal-
Übung. Eine eigene Domäne erlaubt organisches Wachstum: Architektur-Detail,
Memory-Layers, Trust-Tiers, Selbstlernender-System-Loop. Diese Punkte sprengen
den Rahmen eines Terminal-Moduls.

---

*Symlink-Pfad (Mac): `_tutorials/cortex-nexus/` → führt zur neuen Domäne.*
