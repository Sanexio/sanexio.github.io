# Terminal-Befehle: Git — Versionskontrolle für deine Projekte

## Was lernst du hier?

Git ist ein System, das deine Projektdateien speichert **und ihre ganze Geschichte bewahrt**. Wenn du einen Fehler machst, kannst du einfach zurückgehen. Wenn mehrere Leute an einem Projekt arbeiten, kümmert sich Git um die Koordination.

**Warum ist das wichtig?**
- Du kannst jederzeit zu einer früheren Version zurück
- Du kannst mehrere Versionen gleichzeitig entwickeln (Branches)
- Jede Änderung hat einen Namen und eine Beschreibung
- Dein Juvantis-Projekt nutzt Git — du brauchst die Basics

**Nicht zu kompliziert?** Nein. Du brauchst nur 7 Befehle für 95% deiner Arbeit.

---

## Wo führst du Git-Befehle aus?

**Die wichtigste Regel zuerst:** Git-Befehle werden **immer im Projekt-Ordner** ausgeführt. Der Ordner muss ein Git-Repository sein (entweder weil du `git init` darin gemacht hast oder weil du ihn mit `git clone` heruntergeladen hast).

### Drei Wege, im richtigen Ordner zu landen

**Weg 1: `cd` in den Ordner, dann Befehl** (Standard)
```bash
cd ~/Cortex/Nexus
git status
```
Du wechselst zuerst in den Ordner, danach laufen alle Git-Befehle „in" diesem Ordner.

**Weg 2: `git -C <pfad> <befehl>`** (ohne vorher zu wechseln)
```bash
git -C ~/Cortex/Nexus status
```
`-C` heißt „run as if you were in this directory". Praktisch, wenn du Git-Befehle aus Skripten oder einer anderen Shell-Position absetzen willst.

**Weg 3: Bei `git init` und `git clone`** kannst du den Ziel-Pfad direkt mitgeben:
```bash
git init ~/Cortex/projects/mein-neues-projekt
git clone git@github.com:Sanexio/nexus.git ~/Cortex/Nexus
```
Diese beiden Befehle erstellen den Ordner *für* dich, alle anderen Befehle setzen voraus, dass du schon drin bist.

### Wie weißt du, ob du im richtigen Ordner bist?

```bash
pwd                  # zeigt deinen aktuellen Pfad
git rev-parse --show-toplevel   # zeigt den Repo-Wurzelpfad
```

Wenn der zweite Befehl mit `fatal: not a git repository` antwortet, bist du nicht in einem Git-Repo — entweder `cd` rein oder `git init` machen.

---

## Was ist Git und GitHub?

### Git vs. GitHub

**Git** = das Programm auf deinem Computer, das deine Dateien speichert
**GitHub** = eine Website, auf der dein Git-Projekt online gespeichert wird (Backup + Zusammenarbeit)

```
Dein Computer              GitHub.com
    │                          │
    ├─ .git/ (Datenbank)       │
    ├─ code/                   │
    └─ push ──────────────────>
         <──── pull ────────
            (neueste Version abholen)
```

---

## Git initialisieren: Ein neues Projekt starten

### `git init` — Git-Projekt starten

```bash
cd my-project
git init
```

Das erstellt einen unsichtbaren Ordner `.git` (die Git-Datenbank):

```
my-project/
├── .git/         ← Git's Speicher (unsichtbar)
├── README.md
├── script.js
└── ...
```

**Wann brauchst du das:** Wenn du ein lokales Projekt neu startest.

#### Praktisches Beispiel — neues Cortex-Projekt anlegen

Du willst ein neues Mini-Projekt unter `~/Cortex/projects/lab-rechner/` anlegen und es von Anfang an unter Versionskontrolle stellen:

```bash
mkdir -p ~/Cortex/projects/lab-rechner
cd ~/Cortex/projects/lab-rechner
git init
echo "# Lab-Rechner" > README.md
git add README.md
git commit -m "Initial commit"
```

Was passiert Schritt für Schritt:
1. `mkdir` legt den Projektordner an.
2. `cd` wechselt in den Ordner.
3. `git init` macht den Ordner zum Git-Repository (legt `.git/` an).
4. `echo … > README.md` erzeugt eine erste Datei.
5. `git add` + `git commit` machen den ersten Commit.

**Alternative ohne `cd`** (legt Ordner und Repo in einem Schwung an):
```bash
git init ~/Cortex/projects/lab-rechner
```
Du musst trotzdem irgendwann mit `cd` reingehen, um Files zu erstellen — aber den Init-Schritt selbst erledigt Git inklusive Ordneranlage.

---

### `git clone` — Ein Projekt von GitHub herunterladen

```bash
git clone https://github.com/sanexio/juvantis.git
```

Das lädt das ganze Projekt herunter, inklusive aller Git-Geschichte:

```
./juvantis/
├── .git/
├── README.md
├── prototypes/
└── ...
```

**Für SSH-Keys (schneller, wenn eingerichtet):**
```bash
git clone git@github.com:sanexio/juvantis.git
```

**Wann brauchst du das:** Wenn du ein bestehendes Projekt von GitHub auf deinen Computer ziehen willst.

#### Praktisches Beispiel — Nexus auf einem neuen Mac einrichten

Du sitzt am Mac-Studio in der Praxis und willst dort die Nexus-Wissensbasis einrichten, die schon auf `Sanexio/nexus` liegt:

```bash
mkdir -p ~/Cortex
cd ~/Cortex
git clone git@github.com:Sanexio/nexus.git Nexus
```

Was passiert:
- Du landest mit `cd` im Cortex-Hauptordner.
- `git clone` lädt das ganze Repo runter und legt es im Unterordner `Nexus` ab (das letzte Argument ist der Ziel-Ordnername — ohne dieses Argument würde Git den Ordner `nexus` kleinschreiben).
- Danach kannst du mit `cd Nexus` reingehen und arbeiten.

**Wenn der Ziel-Ordner schon existiert und voll ist**, weigert sich `clone`. Dann musst du den Ordner erst leeren oder einen anderen Namen wählen.

---

## Änderungen speichern: Das Herzstück von Git

### `git status` — Was hat sich geändert?

```bash
git status
```

Zeigt:
- Welche Dateien du geändert hast
- Welche Dateien noch nicht "gestaged" sind
- Welche Dateien neu sind

```
On branch master

Changes not staged for commit:
  modified:   juvantis.js
  deleted:    old-config.txt

Untracked files:
  new-feature.js
  test.txt
```

**Was das bedeutet:**
- `modified` = Datei wurde geändert (noch nicht gespeichert in Git)
- `deleted` = Datei wurde gelöscht
- `Untracked files` = neue Dateien, die Git noch nicht kennt

**Wann brauchst du das:** Vor jedem Commit — checken, was sich geändert hat.

#### Praktisches Beispiel — Status nach einer Tutorial-Bearbeitung in Nexus

Du hast gerade ein Tutorial in Obsidian angepasst und willst sehen, was Git mitbekommen hat:

```bash
cd ~/Cortex/Nexus
git status
```

Typische Ausgabe nach einer kleinen Tutorial-Änderung:
```
On branch main
Your branch is up to date with 'origin/main'.

Changes not staged for commit:
  modified:   Second Brain/30 Tutorials/Terminal/02-git.md

no changes added to commit (use "git add" and/or "git commit -a")
```

Heißt: Du hast die Datei `02-git.md` geändert, aber Git wartet darauf, dass du `git add` machst.

---

### `git add` — Änderungen "inszenieren"

Bevor du änderungen speicherst, musst du sie "inszenieren" — d.h. Git sagen: "Diese Änderungen sollen im nächsten Speichervorgang dabei sein."

```bash
git add juvantis.js
```

Adds nur diese eine Datei.

**Alle Änderungen auf einmal:**
```bash
git add .
```

Der Punkt `.` bedeutet "alles im aktuellen Verzeichnis".

**Nach `git add` sieht `git status` anders aus:**
```
On branch master

Changes to be committed:
  modified:   juvantis.js
```

**Wann brauchst du das:** Immer vor `git commit`.

#### Praktisches Beispiel — gezielt nur Tutorial-Edits stagen

Du hast in Nexus zwei Sachen geändert: ein Tutorial UND eine `.obsidian/workspace.json` (die du *nicht* committen willst, weil sie gerätespezifisch ist):

```bash
cd ~/Cortex/Nexus
git status
# zeigt zwei modifizierte Files

git add "Second Brain/30 Tutorials/Terminal/02-git.md"
# stagt nur die Tutorial-Datei

git status
# zeigt: ein File zum Commit bereit, das andere noch ungestaged
```

**Hinweis zu Pfaden mit Leerzeichen:** Pfade in Anführungszeichen setzen, sonst nimmt Git nur das erste Wort.

---

### `git commit` — Änderungen speichern mit Beschreibung

```bash
git commit -m "Fix avatar rotation bug"
```

Das speichert alle addierten Änderungen mit einer Beschreibung ("Fix avatar rotation bug").

**Was passiert:**
```
[master abc123d] Fix avatar rotation bug
 1 file changed, 25 insertions(+), 2 deletions(-)
```

Das bedeutet: Du hast ein "Commit" erstellt (eine Speicherung mit Historie).

**Die Beschreibung ist wichtig!** Sie hilft dir später, die Änderungen zu verstehen:
- ✅ Gut: `git commit -m "Add SwiftUI state management for health data"`
- ❌ Schlecht: `git commit -m "fix"`

**Mit längerer Beschreibung (öffnet Editor):**
```bash
git commit
```

Öffnet deinen Editor (Vi, Nano, VS Code, etc.), damit du eine längere Nachricht schreiben kannst.

**Wann brauchst du das:** Nach jeder Änderungsgruppe, mehrmals pro Tag.

#### Praktisches Beispiel — Commit-Konvention im Cortex-/Nexus-Workflow

In Nexus benutzen wir Conventional-Commit-Präfixe (`docs:`, `feat:`, `fix:`, `chore:`), damit man im Log auf einen Blick erkennt, was passiert ist:

```bash
cd ~/Cortex/Nexus
git add "Second Brain/30 Tutorials/Terminal/02-git.md"
git commit -m "docs(tutorial): Git — praktische Cortex/Nexus-Beispiele ergänzt"
```

Andere typische Commit-Messages aus dem letzten Sprint:
- `docs(vault): Tutorial 10 — iPad Remote Desktop auf Cluster-Mini-02`
- `feat(bootstrap): HTTPS-Fallback + praxis-studio Cortex-Web-Klon`
- `chore(gitignore): _memory/last-digest.json (session-start-digest dedup-marker)`

Schau dir mit `git log --oneline -10` an, wie die letzten Commits formuliert sind, und folge demselben Stil.

---

## Ferngespeicherte Versionen (Remote): GitHub nutzen

### `git remote` — Remote-Verbindung verwalten

```bash
git remote
```

Zeigt, welche remotes es gibt (normalerweise `origin`):
```
origin
```

**Detail anschauen:**
```bash
git remote -v
```

```
origin  git@github.com:sanexio/juvantis.git (fetch)
origin  git@github.com:sanexio/juvantis.git (push)
```

**Neues remote hinzufügen (selten nötig):**
```bash
git remote add backup git@github.com:sanexio/juvantis-backup.git
```

**Wann brauchst du das:** Normalerweise nicht — `clone` setzt das automatisch auf.

---

### `git push` — Änderungen zu GitHub hochladen

```bash
git push
```

oder explizit:
```bash
git push origin master
```

Das lädt alle deine Commits zu GitHub hoch:

```
Enumerating objects: 3, done.
Counting objects: 100% (3/3), done.
Writing objects: 100% (2/2), 250 bytes | 250.00 KiB/s, done.
To github.com:sanexio/juvantis.git
   abc123d..xyz789e  master -> master
```

**Wann brauchst du das:** Nach mehreren Commits, oder täglich am Ende der Arbeit.

**⚠️ Wichtig:** Nur push, wenn deine Commits lokal funktionieren!

#### Praktisches Beispiel — Nexus-Push nach einer Tutorial-Welle

```bash
cd ~/Cortex/Nexus
git push
```

Typische Ausgabe:
```
Enumerating objects: 7, done.
Counting objects: 100% (7/7), done.
Writing objects: 100% (4/4), 1.23 KiB | 1.23 MiB/s, done.
To github.com:Sanexio/nexus.git
   1ab18ba..f5ed5b4  main -> main
```

Nach diesem Push sehen alle anderen Geräte (SSMD-MacBookPro, Mac-Studio, iPad mit Working Copy) die neuen Commits, sobald sie selbst ein `git pull` machen. So funktioniert das Multi-Device-Setup von Cortex.

---

### `git pull` — Neueste Version von GitHub abholen

```bash
git pull
```

oder explizit:
```bash
git pull origin master
```

Holt die neueste Version vom Remote (GitHub):

```
From github.com:sanexio/juvantis
   xyz789e..abc456f  master -> origin/master
Updating xyz789e..abc456f
Fast-forward
 juvantis.js | 10 +++++
 1 file changed, 10 insertions(+)
```

**Wann brauchst du das:**
- Bevor du deine Arbeit startest (um die neueste Version zu haben)
- Wenn jemand anderes Änderungen gepusht hat
- Wenn du an mehreren Computern arbeiten

#### Praktisches Beispiel — Nexus-Pull als Standard-Sessionstart

In Cortex steht in `Nexus/CLAUDE.md` als Pflicht-Schritt 1 jeder Session:

```bash
cd ~/Cortex/Nexus
git pull --ff-only
```

Das `--ff-only` heißt: „Nur fast-forward erlauben". Falls lokal Änderungen liegen, die mit dem Remote kollidieren, bricht Git ab statt einen Merge-Commit zu machen. So bleibt die Historie sauber.

Wenn `git pull --ff-only` mit „Not possible to fast-forward, aborting" abbricht, hast du lokale Commits, die noch nicht gepusht sind — entweder erst pushen oder mit `git stash` zwischenparken.

---

## Branches: Mehrere Versionen gleichzeitig entwickeln

Stell dir vor, du willst eine neue Funktion ausprobieren, ohne die funktionierende Version (master) kaputtzumachen. Dafür gibt es Branches.

### `git branch` — Branches verwalten

```bash
git branch
```

Zeigt deine lokalen Branches (der mit `*` ist der aktuelle):

```
* master
  feature/avatar-customization
  shopify-theme
```

**Neuen Branch erstellen:**
```bash
git branch feature/new-animation
```

**Branch löschen:**
```bash
git branch -d feature/new-animation
```

#### Praktisches Beispiel — experimenteller Tutorial-Refactor in Nexus

Du willst alle Tutorials einmal umgliedern, weißt aber nicht, ob das gut wird. Statt direkt auf `main` zu arbeiten, machst du einen Branch:

```bash
cd ~/Cortex/Nexus
git checkout -b experiment/tutorial-restruktur
# … alle Refactor-Edits …
git add .
git commit -m "experiment(vault): Tutorials nach Domäne gruppiert"
```

Wenn dir das Ergebnis nicht gefällt, wirfst du den Branch einfach weg:
```bash
git checkout main
git branch -D experiment/tutorial-restruktur   # -D = force delete
```

`main` bleibt dabei unverändert — null Risiko für deinen produktiven Stand.

---

### `git checkout` — Zwischen Branches wechseln

```bash
git checkout feature/avatar-customization
```

Wechselt zum Branch `feature/avatar-customization`:

```
Switched to branch 'feature/avatar-customization'
```

**Branch erstellen UND sofort wechseln (shortcut):**
```bash
git checkout -b feature/new-animation
```

Das ist dasselbe wie:
```bash
git branch feature/new-animation
git checkout feature/new-animation
```

**Wann brauchst du das:** Wenn du an mehreren Features parallel arbeitest.

---

### `git merge` — Branch zusammenführen

Wenn deine neue Feature fertig ist, merkst du sie mit dem master:

```bash
git checkout master
git merge feature/avatar-customization
```

Das bedeutet:
1. Wechsle zu `master`
2. Merge alle Änderungen von `feature/avatar-customization` in `master`

```
Merge made by the 'recursive' strategy.
 avatar.swift | 50 +++++++++++++++++++++++
 1 file changed, 50 insertions(+)
```

**Wenn es Konflikte gibt:**
Git sagt: "Es gibt Änderungen an derselben Stelle in zwei Branches. Ich weiß nicht, welche behalten."

Du musst dann die konfliktiven Dateien manuell editieren und die Konflikte auflösen.

**Wann brauchst du das:** Wenn eine Feature fertig ist.

---

## Der Juvantis-Workflow: Master + Shopify-Theme

Dein Juvantis-Projekt hat zwei Hauptbranches:

```
master                    ← Die Hauptentwicklung (iOS-App, Geschäftsplan)
  ├── feature/avatar-customization  ← Neue Features
  ├── feature/health-tracking        ← Weitere Features
  └── ...

shopify-theme             ← Parallele Entwicklung (Shopify-Theme)
  ├── feature/product-carousel       ← Shopify-spezifische Features
  └── ...
```

**Ein typischer Workflow:**

```bash
# 1. Neue Feature starten
git checkout -b feature/my-new-feature

# 2. Code schreiben, mehrere Commits
git add .
git commit -m "Start new animation system"
git add .
git commit -m "Add rotation to avatar"

# 3. Regelmäßig pushen
git push origin feature/my-new-feature

# 4. Feature ist fertig → Merge zu master
git checkout master
git pull                    # Neueste Version holen
git merge feature/my-new-feature
git push

# 5. Lokalen Branch aufräumen
git branch -d feature/my-new-feature
```

---

## Git History anschauen

### `git log` — Alle Commits auflisten

```bash
git log
```

Zeigt alle Commits (neueste zuerst):

```
commit abc123def456 (HEAD -> master)
Author: Dr. Stracke <stracke@praxis.de>
Date:   2 Apr 2026 10:42:00 +0100

    Fix avatar rotation bug

commit xyz789abc123
Author: Dr. Stracke <stracke@praxis.de>
Date:   1 Apr 2026 15:30:00 +0100

    Add SwiftUI state management
```

**Einzeilig (übersichtlicher):**
```bash
git log --oneline
```

```
abc123d Fix avatar rotation bug
xyz789a Add SwiftUI state management
def456e Initial commit
```

**Mit Grafik (Branches anzeigen):**
```bash
git log --graph --oneline --all
```

**Wann brauchst du das:** Um die Geschichte deines Projekts zu verstehen, Fehler zu tracken.

#### Praktisches Beispiel — Welle-Historie in Nexus rekapitulieren

Wenn du nach einem Sprint sehen willst, was alles passiert ist:

```bash
cd ~/Cortex/Nexus
git log --oneline -20
```

Beispiel-Ausgabe (echte Commits aus 2026-05-10):
```
1ab18ba docs(tutorial): 11 — Codex-Mac-Onboarding (OpenAI Codex + OpenClaw)
6ef7ad8 feat(bootstrap): HTTPS-Fallback + praxis-studio Cortex-Web-Klon
6112aa1 feat(multi-ai): Multi-Device-Multi-AI-Architektur
dff7be9 docs(vault): Netzwerk & Sysadmin / 11 — VPN-Grundlagen
```

Mit `--graph --all` siehst du auch parallele Branches:
```bash
git log --graph --oneline --all -20
```

---

### `git diff` — Was hat sich geändert?

```bash
git diff
```

Zeigt alle Änderungen seit dem letzten Commit (noch nicht committed):

```
diff --git a/juvantis.js b/juvantis.js
index 1234567..abcdefg 100644
--- a/juvantis.js
+++ b/juvantis.js
@@ -5,3 +5,4 @@ function avatar() {
   rotate();
+  animate();    ← Diese Zeile wurde hinzugefügt
}
```

**Unterschied zu einem anderen Commit:**
```bash
git diff abc123d
```

Zeigt, was sich seit Commit `abc123d` geändert hat.

**Nur Namen der geänderten Dateien:**
```bash
git diff --name-only
```

---

## Fehler beheben: Zeit zurück spulen

### `git revert` — Einen Commit rückgängig machen (sicher)

```bash
git revert abc123d
```

Das erstellt einen **neuen Commit**, der die Änderungen des Commits `abc123d` rückgängig macht. Die alte Geschichte bleibt erhalten.

```
[master 999eeee] Revert "Fix avatar rotation bug"
 1 file changed, 25 deletions(-)
```

**Wann brauchst du das:** Wenn ein Commit kaputt ist und du es sauber rückgängig machen willst.

---

### `git reset` — Zurück zu einem früheren Commit (⚠️ vorsicht!)

```bash
git reset --soft abc123d
```

Setzt deinen Branch zu Commit `abc123d` zurück, aber deine lokalen Änderungen bleiben.

```bash
git reset --hard abc123d
```

Setzt ALLES zurück — lokale Änderungen sind weg. ⚠️ Irreversibel!

**Wann brauchst du das:** Selten. Besser `git revert` nutzen, das ist sicherer.

---

## Zusammenfassung: Der tägliche Git-Workflow

```bash
# Morgens: Neueste Version holen
git pull

# Tagsüber: Deine Arbeit speichern (mehrmals)
git status              # Was hat sich geändert?
git add .               # Alles zum Commit vorbereiten
git commit -m "Meine Änderung"

# Abends: Zu GitHub hochladen
git push
```

**Mit Branches (für größere Features):**
```bash
git checkout -b feature/my-feature
# ...deine Arbeit...
git add .
git commit -m "..."
git push origin feature/my-feature
# Später: merge zu master
git checkout master
git pull
git merge feature/my-feature
git push
```

---

## Cheat Sheet: Die 10 wichtigsten Git-Befehle

| Befehl | Was es macht |
|--------|--------------|
| `git init` | Git-Projekt starten |
| `git clone URL` | Projekt von GitHub abholen |
| `git status` | Was hat sich geändert? |
| `git add .` | Alle Änderungen vorbereiten |
| `git commit -m "..."` | Änderungen speichern |
| `git push` | Zu GitHub hochladen |
| `git pull` | Von GitHub abholen |
| `git branch` | Branches verwalten |
| `git checkout -b name` | Neuen Branch erstellen |
| `git merge name` | Branch zusammenführen |

---

## Häufige Probleme und Lösungen

### Problem: "Ich habe Änderungen, aber kann nicht pushen"

**Grund:** Wahrscheinlich gibt es neuere Änderungen auf GitHub, die du noch nicht hast.

**Lösung:**
```bash
git pull
git push
```

---

### Problem: "Ich habe den falschen Branch geändert"

**Grund:** Du warst auf `master`, wolltest aber auf `feature/my-thing` sein.

**Lösung:**
```bash
git stash               # Änderungen temporär speichern
git checkout feature/my-thing
git stash pop           # Änderungen wiederherstellen
```

---

### Problem: "Merge-Konflikt: Ich weiß nicht, welche Version ich will"

**Grund:** Du und jemand anderes haben die gleiche Zeile geändert.

**Datei öffnen und suchen nach:**
```
<<<<<<< HEAD
meine Version
=======
ihre Version
>>>>>>>
```

**Lösung:** Entscheide, welche Version du behalten willst, löschen den Rest, und:
```bash
git add .
git commit -m "Merge konflikt gelöst"
git push
```

---

## Nächste Schritte

1. **Übe mit Nexus** (sicherer Spielplatz, weil Markdown-only):
   ```bash
   cd ~/Cortex/Nexus
   git status
   git log --oneline -5
   ```

2. **Übe mit deinem Juvantis-Projekt:**
   ```bash
   cd ~/Cortex/projects/Juvantis
   git status
   git log --oneline
   ```

3. **Starte einen Test-Branch in Nexus** (gefahrlos, weil du ihn jederzeit löschen kannst):
   ```bash
   cd ~/Cortex/Nexus
   git checkout -b test/git-tutorial-uebung
   # Mache eine kleine Änderung an einem Tutorial
   git add .
   git commit -m "test: kleine Tutorial-Bearbeitung"
   git checkout main           # Zurück zu main
   git branch -D test/git-tutorial-uebung   # Test wieder weg
   ```

4. **Lies mehr:** `git help` (oder `man git` für die volle Dokumentation)

---

## Cortex/Nexus-Cheat-Sheet — der tägliche Workflow

Der typische Sessionstart-/Sessionende-Workflow in Cortex/Nexus, alles in `~/Cortex/Nexus`:

```bash
# === Sessionstart ===
cd ~/Cortex/Nexus
git pull --ff-only          # Pflicht-Schritt 1 laut CLAUDE.md

# === Während der Arbeit ===
git status                  # Was hat sich geändert?
git diff                    # Detail-Diff
git add <pfad/zur/datei>    # Stagen
git commit -m "docs(vault): <kurze beschreibung>"

# === Sessionende ===
git log --oneline origin/main..HEAD   # Was haben wir lokal gemacht?
git push                              # Hoch zu Sanexio/nexus
```

Wichtig: In Nexus committen wir **nicht** mit `git add .` — sondern gezielt einzelne Files, weil sonst `.obsidian/workspace.json`, `.venv/`, `_memory/` und andere lokale Dateien aus Versehen mitlaufen. Die `.gitignore` fängt das meiste, aber `git add .` ist trotzdem ein Trigger für Unfälle.

---

**💡 Tipp:** GitHub hat eine gute Web-Oberfläche. Wenn du deine Commits auf GitHub siehst (Push funktioniert), wunderbar! Das Terminal ist schneller, aber GitHub ist hilfreich um zu visualisieren.
