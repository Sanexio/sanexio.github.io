# GitHub: Dein Code-Tresor in der Cloud

## Was lernst du hier?

Git speichert Versionen deiner Dateien lokal auf deinem Computer. GitHub ist der
Ort im Internet, wo diese Versionen sicher gespeichert und mit anderen geteilt werden.
Stell dir vor: Git ist dein lokaler Aktenschrank, GitHub ist der Tresor bei der Bank.

In dieser Lektion lernst du:
- Was GitHub ist und warum wir es nutzen
- Wie Repositories funktionieren
- Was Branches sind (am Beispiel Juvantis)
- Wie Claude mit GitHub arbeitet
- Wie du den Status deiner Projekte prüfst
- Was du tun kannst wenn etwas schiefgeht

---

## Was ist GitHub?

GitHub ist eine Plattform im Internet, die Git-Repositories hostet. Ein Repository
(kurz: "Repo") ist wie ein Projektordner mit eingebauter Zeitmaschine — jede
Änderung wird gespeichert und kann jederzeit rückgängig gemacht werden.

### Warum nutzen wir GitHub?

1. **Sicherheit:** Dein Code ist nicht nur auf deinem Mac, sondern auch in der Cloud
2. **Versionshistorie:** Du kannst jede Änderung nachvollziehen (wer, wann, was)
3. **Shopify-Integration:** Dein Shopify-Theme synchronisiert sich mit GitHub
4. **Zusammenarbeit:** Claude und du arbeiten am selben Repository

### Dein Juvantis-Repository

- **URL:** https://github.com/Sanexio/JUVANTIS
- **Organisation:** Sanexio (deine GmbH)
- **Zwei Branches:**
  - `master` — Projektdateien (Docs, iOS-App, Prototypen)
  - `shopify-theme` — Shopify-Theme (synchronisiert mit dem Store)

---

## Repositories verstehen

Ein Repository enthält:

```
JUVANTIS/                    ← Das Repository
├── .git/                    ← Git-Datenbank (unsichtbar, nicht anfassen)
├── sections/                ← Deine Dateien
├── templates/
├── assets/
└── ...
```

### Repository klonen (eine Kopie herunterladen)

```bash
git clone https://github.com/Sanexio/JUVANTIS.git
```

Das erstellt einen Ordner `JUVANTIS/` mit allen Dateien und der gesamten Historie.

### Repository-Status prüfen

```bash
cd JUVANTIS
git status
```

Zeigt dir:
- Auf welchem Branch du bist
- Welche Dateien geändert wurden
- Welche Dateien noch nicht "committed" sind

---

## Branches: Parallele Arbeitslinien

Ein Branch ist wie eine Kopie deines Projekts, an der du unabhängig arbeiten kannst.

### Das Juvantis-Branch-Modell

```
master (Hauptbranch)
├── _docs/BSNP_Juvantis.pdf         ← Businessplan
├── prototypes/juvantis-ios/         ← iOS-App
├── social-media/                     ← Kampagnen
└── _config/                          ← Projektregeln

shopify-theme (separater Branch)
├── sections/                         ← Shopify Liquid Sections
├── templates/                        ← Seiten-Templates
├── assets/                           ← CSS, JS, Bilder
└── config/                           ← Theme-Einstellungen
```

**Warum zwei Branches?**
- Das Shopify-Theme hat eine eigene Git-Verbindung zum Shopify Store
- Wenn du ein Theme-Push machst, werden NUR die Theme-Dateien hochgeladen
- Die Projektdateien (Businessplan, iOS-App) sollen NICHT zum Shopify Store

### Branch wechseln

```bash
# Zum shopify-theme Branch wechseln
git checkout shopify-theme

# Zurück zum master
git checkout master
```

### Aktuellen Branch sehen

```bash
git branch
```

Ausgabe:
```
* master                 ← Du bist hier (Stern = aktueller Branch)
  shopify-theme
```

---

## Wie Claude mit GitHub arbeitet

Claude führt Git-Befehle automatisch aus. Hier ist, was im Hintergrund passiert:

### Beim Bearbeiten der Shopify-Website

```
Du sagst: "Erstelle eine neue Preisseite"
    │
    ↓
Claude erstellt die Datei
    │ (sections/juvantis-pricing.liquid)
    ↓
PostToolUse-Hook pusht automatisch zu Shopify
    │ (npx shopify theme push --only ...)
    ↓
Claude verifiziert mit curl
    │ (curl -s 'https://sanexio.eu/...')
    ↓
Du sagst: "Sieht gut aus, committe das"
    │
    ↓
Claude führt aus:
    git add sections/juvantis-pricing.liquid
    git commit -m "Add pricing page section"
    git push origin shopify-theme
    │
    ↓
Änderung ist auf GitHub gespeichert
```

### Beim iOS-App-Entwickeln

```
Du sagst: "Füge HealthKit hinzu"
    │
    ↓
Claude schreibt Swift-Code
    │
    ↓
Du testest in Xcode (Simulator)
    │
    ↓
Du sagst: "Funktioniert, committe"
    │
    ↓
Claude:
    git add .
    git commit -m "Add HealthKit integration"
    git push origin master
```

---

## Die wichtigsten GitHub-Aktionen

### 1. Status prüfen

```bash
git status
```

Mögliche Ausgaben:
- `nothing to commit, working tree clean` — Alles gespeichert, keine Änderungen
- `Changes not staged for commit` — Dateien wurden geändert, aber noch nicht committed
- `Untracked files` — Neue Dateien, die Git noch nicht kennt

### 2. Änderungen ansehen

```bash
# Was wurde geändert? (Zeile für Zeile)
git diff

# Nur Dateinamen der Änderungen
git diff --name-only

# Letzte Commits ansehen
git log --oneline -10
```

### 3. Änderungen rückgängig machen

```bash
# Eine einzelne Datei auf den letzten Commit zurücksetzen
git checkout -- sections/juvantis-pricing.liquid

# ALLE lokalen Änderungen verwerfen (VORSICHT!)
git checkout .
```

### 4. Vom Server holen (Pull)

```bash
# Neueste Version vom GitHub holen
git pull origin shopify-theme

# Oder vom Shopify Store direkt
source ~/.nvm/nvm.sh
npx shopify theme pull --store medzpoint --theme 181128757515
```

---

## GitHub im Browser

Du kannst dein Repository auch im Browser ansehen:

1. Öffne https://github.com/Sanexio/JUVANTIS
2. Oben links siehst du den Branch-Wähler (dropdown: `master` oder `shopify-theme`)
3. Du siehst alle Dateien und ihre letzte Änderung
4. Klick auf eine Datei um den Inhalt zu sehen
5. Klick auf "History" um alle Änderungen an dieser Datei zu sehen

### Commit-Historie ansehen

Jeder Commit hat:
- Eine **Nachricht** (was wurde gemacht)
- Ein **Datum** (wann)
- Einen **Autor** (wer — Claude oder du)
- Eine **ID** (einzigartiger Hash, z.B. `a1b2c3d`)

---

## Problemlösungen (FAQ)

### "Ich habe etwas kaputt gemacht"

**Lösung:** Git hat alles gespeichert. Claude kann jede Änderung rückgängig machen:
```bash
# Letzte Änderung rückgängig
git checkout -- dateiname.liquid

# Auf einen bestimmten Commit zurück
git checkout a1b2c3d -- dateiname.liquid
```

### "Die Shopify-Seite sieht anders aus als in meinen Dateien"

**Ursache:** Jemand hat im Shopify Admin etwas geändert (z.B. über "Customize Theme").
**Lösung:** Vom Store pullen:
```bash
source ~/.nvm/nvm.sh
npx shopify theme pull --store medzpoint --theme 181128757515
```
Dann in Git vergleichen was sich geändert hat: `git diff`

### "git push wird abgelehnt"

**Ursache:** Auf GitHub gibt es neuere Änderungen als auf deinem Mac.
**Lösung:** Erst pullen, dann pushen:
```bash
git pull origin shopify-theme
# Eventuell Konflikte lösen
git push origin shopify-theme
```

### "Ich bin auf dem falschen Branch"

**Prüfen:**
```bash
git branch
```
**Wechseln:**
```bash
git checkout shopify-theme
```

### "Was bedeutet 'merge conflict'?"

Das passiert wenn zwei Änderungen an der gleichen Stelle einer Datei gemacht wurden
(z.B. du im Shopify Admin und Claude im Code). Claude kann diese Konflikte lösen —
sag einfach Bescheid.

---

## Zusammenfassung

| Konzept | Erklärung |
|---------|-----------|
| Repository | Projektordner mit Versionshistorie |
| Branch | Parallele Arbeitslinie (master, shopify-theme) |
| Commit | Ein Speicherpunkt ("Snapshot") deiner Dateien |
| Push | Änderungen von deinem Mac zu GitHub hochladen |
| Pull | Änderungen von GitHub auf deinen Mac herunterladen |
| Clone | Eine Kopie eines Repositories herunterladen |
| Diff | Unterschiede zwischen Versionen anzeigen |

**Das Wichtigste:** Du musst diese Befehle nicht selbst ausführen. Claude macht das.
Aber wenn du verstehst was passiert, kannst du bessere Entscheidungen treffen und
weißt was zu tun ist wenn etwas unerwartet läuft.

---

*Dieses Tutorial wird erweitert wenn wir auf neue Git/GitHub-Situationen stoßen.
Jedes Problem das wir lösen wird hier als FAQ-Eintrag dokumentiert.*
