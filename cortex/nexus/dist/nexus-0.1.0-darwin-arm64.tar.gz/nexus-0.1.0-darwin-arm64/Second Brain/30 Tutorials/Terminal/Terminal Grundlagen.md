---
type: tutorial
aliases: [Terminal, CLI, Kommandozeile, Shell, Bash]
tags:
  - tutorial
  - terminal
  - cli
source: Second Brain/30 Tutorials/Terminal/
legacy_path: _tutorials/terminal-befehle/ (Symlink)
---

# Terminal & CLI — Tutorial-Übersicht

> Quellpfad: `Second Brain/30 Tutorials/Terminal/` (Single Source of Truth)
> Legacy-Pfad: `_tutorials/terminal-befehle/` → Symlink

Das Terminal (Kommandozeile) ist dein direkter Zugang zum Computer. Mit Text-Befehlen statt Maus-Klicks kannst du schneller arbeiten, Projekte steuern und Fehler beheben.

---

## Warum Terminal lernen?

- Dateien schneller verwalten als mit der Maus
- Projekte (Git, Node.js, Blender) von der Kommandozeile steuern
- Logs und Fehler einfacher diagnostizieren
- Automatisierung über Shell-Skripte
- Dein Juvantis-Projekt nutzt Git und npm — beides Terminal-Tools

---

## Module

### 01 — Grundlagen
**Einfuehrung in die Kommandozeile, Dateisystem-Navigation, wichtige Befehle.**

Du lernst die 30 Befehle, die du 90% der Zeit brauchst:
- **Navigation:** `pwd`, `ls`, `cd`
- **Dateiverwaltung:** `mkdir`, `cp`, `mv`, `rm`, `touch`
- **Textbearbeitung:** `cat`, `echo`, `grep`
- **Systeminformationen:** `man`, `which`, `find`, `du`, `df`
- **Fortgeschrittenes:** `pipe |`, `redirect >`, `append >>`

**Module:**
- Theorie: `01-grundlagen.md`
- Claude-Workflow: `01-grundlagen_claude.md`
- Manuell: `01-grundlagen_manuell.md`

---

### 02 — Git
**Versionskontrolle fuer deine Projekte.**

Git speichert deine Dateien UND ihre ganze Geschichte. Wichtig fuer:
- Rueckkehr zu frueheren Versionen
- Mehrere Branches (parallel arbeiten)
- Zusammenarbeit mit anderen
- Dein Juvantis-Projekt nutzt Git

Du brauchst nur 7 Befehle fuer 95% deiner Arbeit:
- `git init`, `git add`, `git commit`, `git push`, `git pull`, `git branch`, `git merge`

**Module:**
- Theorie: `02-git.md`
- Claude-Workflow: `02-git_claude.md`
- Manuell: `02-git_manuell.md`

---

### 03 — Node.js und npm
**JavaScript außerhalb des Browsers.**

Node.js laeuft auf deinem Computer (nicht im Browser). npm ist der "App Store" fuer JavaScript:
- Bibliotheken runterladeb
- Dein Projekt verwalten
- Juvantis-Website braucht Node.js und npm
- Du brauchst 5 Befehle fuer tägliche Arbeit

Befehle:
- `node`, `npm init`, `npm install`, `npm start`, `npm run`

**Module:**
- Theorie: `03-npm-node.md`
- Claude-Workflow: `03-npm-node_claude.md`
- Manuell: `03-npm-node_manuell.md`

---

### 04 — GitHub
**Dein Code-Tresor in der Cloud.**

Git speichert lokal auf deinem Mac. GitHub ist der Ort im Internet:
- Sicherheit: Code nicht nur auf deinem Mac
- Versionshistorie: Jede Aenderung nachvollziehen
- Shopify-Integration: Theme syncht mit GitHub
- Zusammenarbeit: Claude und du arbeiten am selben Repo

Dein Juvantis-Repository:
- **URL:** https://github.com/Sanexio/JUVANTIS
- **Branches:** `master` (Projekt) + `shopify-theme` (Website)

**Module:**
- Theorie: `04-github.md`
- Claude-Workflow: `04-github_claude.md`
- Manuell: `04-github_manuell.md`

---

### 05 — Shopify & Blender Workflows
**Projektspezifische Befehle fuer deinen Alltag.**

Diese Module erklaert die Terminal-Befehle, die du bei Juvantis regelmaessig nutzt:
- **`source ~/.nvm/nvm.sh`** — warum vor jedem Shopify-Befehl?
- **`npx shopify theme push --only sections/X`** — was macht `--only`?
- **`curl -s https://sanexio.eu/...`** — warum statt WebFetch?
- **`blender --background --python script.py`** — Blender-Automation

Diese Befehle stecken in globalen Regeln (R-008, R-016, R-017). Hier erklären wir das **WARUM**.

**Module:**
- Theorie: `05-shopify-blender-workflows.md`
- Claude-Workflow: `05-shopify-blender-workflows_claude.md`
- Manuell: `05-shopify-blender-workflows_manuell.md`

---

## Lern-Reihenfolge

1. **01 — Grundlagen** (Basis)
2. **02 — Git** (für Projekte)
3. **03 — Node.js & npm** (für Juvantis-Website)
4. **04 — GitHub** (für Cloud-Sync)
5. **05 — Shopify & Blender** (für tägliche Arbeit)

Jedes Modul hat drei Dateien:
- **Theorie** (`XX-thema.md`) — Erklaert das Warum und wie es funktioniert
- **Claude-Workflow** (`XX_claude.md`) — Wie Claude diese Befehle in Sessions nutzt
- **Manuell** (`XX_manuell.md`) — Schritt-fuer-Schritt Anleitung zum Selbermachen


<!-- auto-moc-links -->
## Wiki-Link-Index (Graph-Vernetzung)

> Auto-generiert von `Nexus/tools/vault-audit/inject_moc_links.py` — verbindet alle Kapitel mit der Landing-Page, damit der Obsidian-Graph die Domäne als einen Cluster zeigt. Nicht manuell bearbeiten.

- [[30 Tutorials/Terminal/01-grundlagen|01-grundlagen]] · [[30 Tutorials/Terminal/01-grundlagen_claude|Claude]] · [[30 Tutorials/Terminal/01-grundlagen_manuell|Manuell]]
- [[30 Tutorials/Terminal/02-git|02-git]] · [[30 Tutorials/Terminal/02-git_claude|Claude]] · [[30 Tutorials/Terminal/02-git_manuell|Manuell]]
- [[30 Tutorials/Terminal/03-npm-node|03-npm-node]] · [[30 Tutorials/Terminal/03-npm-node_claude|Claude]] · [[30 Tutorials/Terminal/03-npm-node_manuell|Manuell]]
- [[30 Tutorials/Terminal/04-github|04-github]] · [[30 Tutorials/Terminal/04-github_claude|Claude]] · [[30 Tutorials/Terminal/04-github_manuell|Manuell]]
- [[30 Tutorials/Terminal/05-shopify-blender-workflows|05-shopify-blender-workflows]] · [[30 Tutorials/Terminal/05-shopify-blender-workflows_manuell|Manuell]]
- [[30 Tutorials/Terminal/06-nexus-cortex-setup|06-nexus-cortex-setup]]

<!-- /auto-moc-links -->
