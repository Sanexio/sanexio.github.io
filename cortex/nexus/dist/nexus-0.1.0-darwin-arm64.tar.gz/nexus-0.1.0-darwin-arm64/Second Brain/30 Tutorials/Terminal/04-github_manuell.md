# GitHub: Cloud-Speicher für dein Projekt — Manueller Workflow

## Wann nutzt du diesen Cheat Sheet?

Wenn Claude nicht verfügbar ist oder du GitHub selbst verstehen willst. Hier sind die wichtigsten GitHub-Operationen im Browser und Terminal.

---

## Im Browser (GitHub.com)

Die meisten GitHub-Operationen kannst du im Browser machen. Das ist oft am einfachsten.

### Repository öffnen

```
https://github.com/Sanexio/JUVANTIS
```

Du siehst:
- Alle Dateien (Master-Branch)
- Commits
- Pull Requests
- Issues
- Releases

---

### Datei bearbeiten (im Browser)

1. Öffne die Datei (z.B. `README.md`)
2. Klick auf den Bleistift-Icon (Edit)
3. Mach deine Änderung
4. "Commit changes" → Gib eine Nachricht ein

**Vorteil:** Keine Terminal-Befehle nötig.
**Nachteil:** Nur für kleine Änderungen geeignet.

---

### Pull Requests anschauen

```
https://github.com/Sanexio/JUVANTIS/pulls
```

Du siehst alle offenen Pull Requests. Klick auf einen um:
- Commits zu sehen
- Code-Changes zu reviewen
- Zu diskutieren

---

### Issues anschauen / erstellen

```
https://github.com/Sanexio/JUVANTIS/issues
```

Klick auf "New Issue" um einen Bug/Feature zu dokumentieren.

---

### Releases anschauen / erstellen

```
https://github.com/Sanexio/JUVANTIS/releases
```

Klick auf "Create a new release" um eine neue Version zu dokumentieren.

---

## Im Terminal (GitHub CLI)

Für schnellere Operationen nutze die **GitHub CLI** (`gh`).

### Installation prüfen

```bash
gh --version
```

Sollte etwas wie `gh version 2.30.0` zeigen.

---

### Authentifizierung

Falls du nicht angemeldet bist:

```bash
gh auth login
```

Folge den Anweisungen. Du brauchst einen GitHub Personal Access Token (PAT).

---

### Status prüfen

```bash
gh auth status
```

Zeigt ob du angemeldet bist und welche Permissions du hast.

---

## Pull Requests (im Terminal)

### Pull Requests auflisten

```bash
gh pr list --repo Sanexio/JUVANTIS
```

Zeigt alle offenen PRs:
```
#5   Update product gallery styling
#3   Add avatar customization
```

Nur geschlossene:
```bash
gh pr list --repo Sanexio/JUVANTIS --state closed
```

---

### Pull Request anzeigen

```bash
gh pr view 5
```

Zeigt Details von PR #5:
```
title: Update product gallery styling
state: OPEN
author: Dr. Stracke
created: 2 days ago
```

---

### Pull Request mergen

```bash
gh pr merge 5 --merge
```

Merged PR #5 in den Master-Branch.

---

### Meinen lokalen Branch als PR pushen

Wenn du einen Branch hast und ihn auf GitHub pushen willst:

```bash
git push origin feature/avatar-customization
gh pr create --title "Add avatar customization" \
  --body "Adds color picker for avatar"
```

Das erstellt automatisch einen Pull Request.

---

## Issues (im Terminal)

### Issues auflisten

```bash
gh issue list --repo Sanexio/JUVANTIS
```

Zeigt alle offenen Issues.

---

### Issue anzeigen

```bash
gh issue view 42
```

Zeigt Details von Issue #42.

---

### Issue erstellen

```bash
gh issue create --repo Sanexio/JUVANTIS \
  --title "Avatar rotation bug" \
  --body "Avatar doesn't rotate when selected in customization menu"
```

Erstellt eine neue Issue.

---

### Issue schließen

```bash
gh issue close 42
```

Schließt Issue #42.

---

## Releases (im Terminal)

### Releases auflisten

```bash
gh release list --repo Sanexio/JUVANTIS
```

Zeigt alle Releases:
```
v2.0.0  2 days ago
v1.5.0  1 week ago
v1.0.0  1 month ago
```

---

### Release erstellen

```bash
gh release create v2.0.0 \
  --title "Juvantis 2.0 — Avatar Customization" \
  --notes "Major release with avatar color picker and health tracking integration"
```

Erstellt Release v2.0.0 auf GitHub.

---

### Release-Assets hochladen

Wenn du eine Datei zum Release hinzufügen willst:

```bash
gh release create v2.0.0 \
  --title "Juvantis 2.0" \
  app-binary.zip README.pdf
```

Die Dateien werden als Downloads verfügbar.

---

## Collaborators verwalten (nur im Browser)

GitHub CLI kann Collaborators nicht verwalten. Das geht nur im Browser:

1. Repository öffnen
2. Settings → Collaborators
3. "Add people" → GitHub-Username eingeben

---

## Branches (im Terminal)

### Remote-Branches anzeigen

```bash
gh api repos/Sanexio/JUVANTIS/branches
```

Zeigt alle Branches auf GitHub.

---

### Einen Branch löschen

```bash
git push origin --delete feature/avatar-customization
```

Löscht den Branch auf GitHub.

---

## Cheat Sheet: GitHub CLI Befehle

| Befehl | Was es macht |
|--------|------------|
| `gh auth login` | Authentifizierung |
| `gh pr list` | PRs auflisten |
| `gh pr view 5` | PR #5 anzeigen |
| `gh pr merge 5` | PR #5 mergen |
| `gh pr create` | Neuen PR erstellen |
| `gh issue list` | Issues auflisten |
| `gh issue view 42` | Issue #42 anzeigen |
| `gh issue create` | Neue Issue erstellen |
| `gh issue close 42` | Issue #42 schließen |
| `gh release list` | Releases auflisten |
| `gh release create` | Neuen Release erstellen |

---

## Juvantis-Workflow (manuell)

### Feature entwickeln und PR erstellen

```bash
# 1. Feature-Branch erstellen
git checkout -b feature/product-gallery

# 2. Arbeit machen und committen
git add .
git commit -m "Add product gallery with sorting"

# 3. Zu GitHub pushen
git push origin feature/product-gallery

# 4. GitHub öffnen → "Create Pull Request" klicken
# oder Terminal:
gh pr create --title "Add product gallery" \
  --body "Adds 4-column product grid with sorting options"

# 5. Code-Review: Andere kommentieren
# Du kannst weitere Commits machen:
git add .
git commit -m "Fix gallery responsiveness"
git push origin feature/product-gallery

# 6. PR mergen (im Browser oder Terminal)
gh pr merge --merge
```

---

## GitHub Web-Interface: Wichtige Buttons

| Button | Was es tut |
|--------|-----------|
| **Edit** (Bleistift-Icon) | Datei bearbeiten |
| **Create Pull Request** | Neuer PR |
| **New Issue** | Neue Issue |
| **Releases** | Releases verwalten |
| **Settings** | Repository-Einstellungen |
| **Actions** | CI/CD Workflows |

---

## Häufige Fragen

### Frage: Sollte ich im Browser oder Terminal arbeiten?

**Browser** = Einfach, intuitiv, gut für:
- Kleine Änderungen (1-2 Dateien)
- Issues/Releases erstellen
- Code reviewen
- Diskussionen

**Terminal** = Schneller, gut für:
- Große Änderungen (viele Commits)
- Automatisierung
- Scripts

**Empfehlung:** Mix. Nutze Git/Terminal für große Arbeit, Browser für kleine Dinge.

---

### Frage: Was ist der Unterschied zwischen Merge und Squash?

**Merge:** Alle Commits bleiben erhalten (größere History)
```
--merge: alle Commits bleiben sichtbar
```

**Squash:** Alle Commits werden in einen zusammengefasst (saubere History)
```
--squash: nur ein Commit für die komplette Feature
```

**Empfehlung:** `--merge` für Juvantis (gute Dokumentation der Arbeit).

---

*GitHub ist dein Cloud-Backup und Zusammenarbeits-Plattform.*
