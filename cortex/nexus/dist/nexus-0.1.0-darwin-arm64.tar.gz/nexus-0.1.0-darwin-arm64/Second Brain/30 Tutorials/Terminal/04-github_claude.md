# GitHub: Cloud-Speicher für dein Projekt — Claude-Workflow

## Wann nutzt du diesen Workflow?

Du nutzt diesen Workflow wenn du GitHub-Operationen brauchst:

- "Erstelle einen neuen GitHub Release"
- "Zeig mir die offenen Pull Requests"
- "Erstelle eine GitHub Issue für diesen Bug"
- "Merge einen Pull Request"
- "Zeig mir die Collaborators des Juvantis-Repos"

**Vorteil:** Claude kennt die GitHub CLI und weiß wie man Repositories verwaltet.
**Nachteil:** Claude muss verfügbar sein.

---

## Der Workflow: Drei Schritte

### Schritt 1: Du beschreibst die GitHub-Aktion

Du sagst Claude:

```
Erstelle einen GitHub Release für Version 1.0.0
```

oder:

```
Schau mir die offenen Pull Requests für das Juvantis-Repo
```

oder:

```
Erstelle eine GitHub Issue für den Avatar-Bug
```

Claude weiß, welche GitHub-Befehle du brauchst.

---

### Schritt 2: Claude führt GitHub-Befehle aus

Claude nutzt die **GitHub CLI** (`gh`) um mit GitHub zu kommunizieren:

**Beispiel 1: Einen Release erstellen**

Claude macht:
```bash
gh release create v1.0.0 --title "Version 1.0.0" --notes "First release"
```

**Beispiel 2: Pull Requests anzeigen**

Claude macht:
```bash
gh pr list --repo Sanexio/JUVANTIS
```

**Beispiel 3: Eine Issue erstellen**

Claude macht:
```bash
gh issue create --repo Sanexio/JUVANTIS \
  --title "Avatar rotation bug" \
  --body "The avatar doesn't rotate correctly..."
```

---

### Schritt 3: Claude zeigt dir das Ergebnis

Claude zeigt dir:

```
✓ Release erstellt
  URL: https://github.com/Sanexio/JUVANTIS/releases/tag/v1.0.0
```

oder:

```
✓ Issue erstellt
  Number: #42
  URL: https://github.com/Sanexio/JUVANTIS/issues/42
```

---

## Häufige Szenarien

### Szenario 1: "Zeig mir offene Pull Requests"

**Du:** "Zeig mir alle offenen Pull Requests für Juvantis"

**Claude:**
```bash
gh pr list --repo Sanexio/JUVANTIS --state open
```

**Output:**
```
#5   Update product gallery styling
#3   Add avatar customization
#2   Fix header animation

Showing 3 of 3 open pull requests
```

---

### Szenario 2: "Erstelle einen Release"

**Du:** "Erstelle einen Release für Version 2.0.0"

**Claude:**
```bash
gh release create v2.0.0 \
  --title "Juvantis 2.0" \
  --notes "Major release with new avatar system and health tracking"
```

**Output:**
```
✓ Release created on GitHub
https://github.com/Sanexio/JUVANTIS/releases/tag/v2.0.0
```

---

### Szenario 3: "Merge einen Pull Request"

**Du:** "Merge Pull Request #5"

**Claude:**
```bash
gh pr merge 5 --merge
```

**Output:**
```
✓ Pull request #5 merged into master
```

---

### Szenario 4: "Erstelle eine Bug-Issue"

**Du:** "Erstelle eine Issue für den Avatar-Rotations-Bug"

**Claude:**
```bash
gh issue create \
  --repo Sanexio/JUVANTIS \
  --title "Avatar rotation bug in customization menu" \
  --body "When users select rotation speed in avatar customization, the rotation doesn't happen. Might be a SceneKit issue."
```

**Output:**
```
✓ Issue created
#47 Avatar rotation bug in customization menu
https://github.com/Sanexio/JUVANTIS/issues/47
```

---

## GitHub vs. Git vs. GitHub Desktop

**Git** = Versionskontrolle (lokal auf deinem Computer)
**GitHub** = Cloud-Hosting für Git-Repositories
**GitHub CLI** (`gh`) = Terminal-Tool um GitHub zu steuern (keine GUI nötig)

Claude nutzt die **GitHub CLI**, weil es schneller und scriptbar ist.

---

## Was ist ein Release?

Ein Release ist eine "offizielle Version" deines Projekts:

```
v1.0.0  ← Release (mit Versionsnummer)
  ├─ Code-Snapshot von diesem Moment
  ├─ Release Notes (was ist neu)
  ├─ Downloads (z.B. Binary, ZIP, etc.)
  └─ Tag im Git-Repository
```

Du erstellt Releases wenn:
- Eine neue Version live geht
- Du ein stabiles "Meilenstein" erreicht hast
- Du Code teilen willst (z.B. zum Download)

---

## Was ist eine Issue?

Eine Issue ist ein Platz um Bugs und Features zu diskutieren:

```
Issue #42: "Avatar rotation bug"
  ├─ Beschreibung: Was ist das Problem?
  ├─ Assignee: Wer arbeitet daran?
  ├─ Labels: Bug, Feature, Urgent, etc.
  ├─ Comments: Diskussion / Lösungsvorschläge
  └─ Status: Open / Closed
```

Du erstellst Issues um:
- Bugs zu dokumentieren
- Features zu planen
- Zu diskutieren bevor der Code geschrieben wird

---

## Was ist ein Pull Request (PR)?

Ein Pull Request ist eine Anfrage zum Merge:

```
PR #5: "Add avatar customization"
  ├─ From: feature/avatar-customization
  ├─ To: master
  ├─ Changes: 3 commits, 120 lines added
  ├─ Code Review: Comments von anderen
  └─ Status: Open / Merged / Closed
```

Der Workflow:
1. Du erstellst einen Branch (`feature/avatar-customization`)
2. Du machst Commits darauf
3. Du pushst zu GitHub
4. Du erstellst einen Pull Request
5. Andere reviewen deinen Code
6. Claude oder du mergst es zu master

---

## Sicherheit: Authentifizierung

Bevor Claude GitHub-Befehle ausführt, prüft sie:

1. **Ist die GitHub CLI installiert?** (`gh --version`)
2. **Bin ich authentifiziert?** (`gh auth status`)
3. **Habe ich Zugriff auf das Repo?** (Berechtigungen)

Claude wird dich warnen, wenn Authentifizierung fehlt.

---

## Zusammenfassung: Der Claude-Workflow

1. **Du sagst was du willst** ("Erstelle einen Release")
2. **Claude nutzt GitHub CLI** (kennt alle GitHub-Befehle)
3. **Claude macht die Operation** (Release, Issue, PR, etc.)
4. **Claude zeigt die Confirmation** (mit URL)

**Ergebnis:** Dein GitHub-Repo ist aktualisiert, Issues/PRs sind organisiert, Releases sind dokumentiert.

---

*Dieser Workflow macht GitHub-Management einfach. Releases, Issues und PRs sind schnell erstellt und verwaltet.*
