# Terminal-Befehle: Grundlagen — Claude-Workflow

## Wann nutzt du diesen Workflow?

Du nutzt diesen Workflow **fast immer**, wenn du Terminal-Aufgaben brauchst:

- "Zeig mir alle Dateien in diesem Ordner"
- "Navigiere zum Juvantis-Projekt und prüfe den Git-Status"
- "Erstelle einen Backup dieses Ordners"
- "Suche nach der Datei, die 'config' heißt"

**Vorteil:** Du brauchst keine Terminal-Befehle zu kennen. Claude macht es für dich.
**Nachteil:** Claude muss verfügbar sein.

---

## Der Workflow: Vier Schritte

### Schritt 1: Du beschreibst die Aufgabe

Du öffnest Claude Code Terminal und schreibst:

```
Zeig mir alle Dateien in ~/projects/Juvantis/website/theme/sections
```

oder:

```
Navigiere zu ~/projects/Juvantis und zeig mir den aktuellen Git-Status
```

oder:

```
Erstelle einen Backup vom Ordner ~/projects/Juvantis/website
```

**Du brauchst nicht zu wissen, welcher Befehl das ist.** Claude weiß das.

---

### Schritt 2: Claude interpretiert deine Anfrage

Claude liest deine Beschreibung und überlegt:

- Was willst du sehen/machen?
- Welche Befehle sind dafür nötig?
- Welche Flags brauchen die Befehle?

**Beispiel:** "Zeig mir alle Dateien"
- Claude denkt: Das ist `ls` oder `ls -la` (mit Details)

**Beispiel:** "Erstelle einen Backup"
- Claude denkt: Das ist `cp -r` (rekursiv kopieren)

---

### Schritt 3: Claude führt den Befehl aus

Claude öffnet ein Terminal und tippt den Befehl:

```bash
ls -la ~/projects/Juvantis/website/theme/sections
```

**Wichtig:** Claude tippt — du brauchst nichts einzugeben. Du sitzt nur da und siehst, was passiert.

---

### Schritt 4: Claude erklärt das Ergebnis

Claude zeigt dir das Ergebnis:

```
-rw-r--r--   1 ssmd  staff   2.4K  product-gallery.liquid
-rw-r--r--   1 ssmd  staff   1.8K  header.liquid
-rw-r--r--   1 ssmd  staff   3.1K  footer.liquid
```

Und erklärt, was das bedeutet:

```
Das bedeutet: Du hast 3 Sections.
- product-gallery.liquid ist 2.4K groß
- Alle wurden zuletzt von dir (ssmd) geändert
- Sie sind lesbar und schreibbar
```

---

## Häufige Szenarien

### Szenario 1: "Wo bin ich gerade?"

**Du:** "Wo bin ich gerade? Zeig mir den aktuellen Pfad"

**Claude:**
```bash
pwd
```

**Output:**
```
/Users/ssmd/projects/Juvantis/website/theme
```

**Claude erklärt:** "Du befindest dich im Juvantis-Theme-Verzeichnis."

---

### Szenario 2: "Erstelle einen Backup"

**Du:** "Erstelle einen Backup von ~/projects/Juvantis"

**Claude:**
```bash
cp -r ~/projects/Juvantis ~/projects/Juvantis-backup
```

**Output:**
```
✓ Backup erstellt: ~/projects/Juvantis-backup
```

**Claude erklärt:** "Das komplette Juvantis-Projekt wurde kopiert. Wenn etwas schiefgeht, hast du eine Kopie."

---

### Szenario 3: "Suche nach einer Datei"

**Du:** "Finde alle JavaScript-Dateien im Juvantis-Projekt"

**Claude:**
```bash
find ~/projects/Juvantis -name "*.js" -type f
```

**Output:**
```
~/projects/Juvantis/website/theme/assets/script.js
~/projects/Juvantis/prototypes/juvantis-ios/script.js
```

**Claude erklärt:** "Gefunden: 2 JavaScript-Dateien. Eine im Theme, eine in der iOS-App."

---

### Szenario 4: "Zeige mir Fehler in einem Log"

**Du:** "Zeige mir alle Fehler in der datei /var/log/system.log"

**Claude:**
```bash
grep -i "error" /var/log/system.log | head -10
```

**Output:**
```
[ERROR] Connection timeout after 30s
[ERROR] Failed to load resource
...
```

**Claude erklärt:** "Es gibt mehrere Fehler. Die ersten 10 sind oben zu sehen."

---

## Wichtige Konzepte

### Was ist ein Terminal-Befehl?

Ein Terminal-Befehl ist ein Befehl, den du dem Computer gibst, z.B.:

```
ls       = Liste die Dateien auf
cd home  = Gehe zum home-Verzeichnis
pwd      = Zeige meinen aktuellen Pfad
```

Claude kennt hunderte von Befehlen. Du brauchst nur zu sagen, **WAS** du willst — Claude weiß **WIE**.

---

### Was ist ein Flag?

Ein Flag ändert, wie ein Befehl funktioniert. Beispiel:

```bash
ls              # Zeige Dateien (einfach)
ls -la          # Zeige Dateien MIT Details (Flag: -la)
```

Das `-la` sind Flags. Sie sagen: "Bitte auch Versteckte Dateien und detaillierte Infos".

Claude weiß, welche Flags du brauchst.

---

### Was ist eine Pipe?

Eine Pipe kombiniert zwei Befehle:

```bash
grep "error" logfile.txt | head -5
```

Das bedeutet:
1. Finde alle Zeilen mit "error"
2. Zeige davon nur die ersten 5

Claude nutzt Pipes um komplexe Aufgaben zu lösen.

---

## Sicherheit: Was Claude NICHT tut

Claude wird dich immer fragen, bevor sie:

- **Dateien löscht** (`rm`, `rm -r`)
- **Berechtigungen ändert** (`chmod`)
- **Systemdateien modifiziert**
- **Irreversible Operationen** durchführt

**Beispiel:**

**Du:** "Lösche alle Backup-Dateien in ~/Downloads"

**Claude:** "Warte — ich würde folgende Dateien löschen: [...]. Bestätigst du?"

---

## Zusammenfassung: Der Claude-Workflow

1. **Du beschreibst die Aufgabe** ("Erstelle einen Backup")
2. **Claude übersetzt zu Terminal-Befehlen** (weiß welcher Befehl passt)
3. **Claude führt aus** (tippt die Befehle)
4. **Claude erklärt das Ergebnis** (was es bedeutet)

**Ergebnis:** Du bekommst das was du brauchst, ohne Terminal-Befehle kennen zu müssen.

---

*Dieser Workflow macht dich produktiv. Du fokussierst auf WAS du brauchst, Claude kümmert sich um WIE.*
