# Terminal-Befehle: Grundlagen — Manueller Workflow

## Wann nutzt du diesen Cheat Sheet?

Wenn Claude nicht verfügbar ist oder du selbst lernen willst, wie Terminal-Befehle funktionieren. Hier sind die 20 wichtigsten Befehle, die du selbst tippen kannst.

---

## Navigation (Wo bin ich? Wohin gehe ich?)

### `pwd` — Print Working Directory

```bash
pwd
```

Zeigt deinen aktuellen Pfad:
```
/Users/ssmd/projects/Juvantis
```

---

### `ls` — List (Dateien anzeigen)

```bash
ls
```

Einfache Liste:
```
Desktop  Documents  projects  Downloads
```

Mit Details:
```bash
ls -la
```

Mit allen Infos (Größe, Änderungsdatum, Besitzer).

---

### `cd` — Change Directory (Ordner wechseln)

```bash
cd projects/Juvantis
```

Wechselt in den Ordner `Juvantis`.

Zurück nach oben:
```bash
cd ..
```

Zum Home-Verzeichnis:
```bash
cd
```

---

## Dateien erstellen und anschauen

### `touch` — Leere Datei erstellen

```bash
touch notes.txt
```

Erstellt eine neue, leere Datei.

---

### `mkdir` — Ordner erstellen

```bash
mkdir my-project
```

Erstellt einen neuen Ordner.

Mit verschachtelten Ordnern:
```bash
mkdir -p projects/juvantis/prototypes
```

Das `-p` erstellt auch die Ordner dazwischen.

---

### `cat` — Datei-Inhalt anzeigen

```bash
cat README.md
```

Zeigt den kompletten Inhalt einer Datei.

Mit Zeilennummern:
```bash
cat -n README.md
```

---

## Dateien kopieren, verschieben, löschen

### `cp` — Copy (Kopieren)

```bash
cp document.txt backup.txt
```

Kopiert `document.txt` zu `backup.txt`.

Ordner kopieren (mit allem drin):
```bash
cp -r my-project my-project-backup
```

Das `-r` bedeutet "rekursiv" (alles kopieren).

---

### `mv` — Move (Verschieben/Umbenennen)

```bash
mv old-name.txt new-name.txt
```

Benennt eine Datei um.

In einen anderen Ordner verschieben:
```bash
mv document.txt ~/Documents/
```

---

### `rm` — Remove (LÖSCHEN)

```bash
rm document.txt
```

⚠️ LÖSCHT die Datei permanent! Kein Papierkorb.

Mit Bestätigung (sicherer):
```bash
rm -i document.txt
```

Fragt: "Wirklich löschen? (y/n)"

Ordner löschen (mit allem drin):
```bash
rm -r my-old-folder
```

---

## Suchen und Filtern

### `grep` — Text suchen

```bash
grep "error" logfile.txt
```

Zeigt alle Zeilen, die "error" enthalten.

Ohne Unterscheidung Groß/Kleinschreibung:
```bash
grep -i "error" logfile.txt
```

Mit Zeilennummern:
```bash
grep -n "error" logfile.txt
```

---

### `find` — Datei suchen

```bash
find ~/projects -name "*.js"
```

Findet alle `.js`-Dateien im `projects`-Ordner.

Nur Dateien (keine Ordner):
```bash
find ~/projects -name "*.js" -type f
```

---

## Befehle kombinieren (Pipes)

### `|` — Pipe (zwei Befehle kombinieren)

```bash
cat logfile.txt | grep "error"
```

Bedeutet:
1. Zeige Logdatei
2. Filtere nur Zeilen mit "error"

Mit mehreren Pipes:
```bash
cat logfile.txt | grep "error" | head -5
```

1. Zeige Logdatei
2. Filtere "error"
3. Zeige nur erste 5 Zeilen

---

### `>` — Speichern in Datei

```bash
ls > file-list.txt
```

Speichert die Ausgabe von `ls` in eine Datei.

⚠️ Wenn die Datei existiert, wird sie **überschrieben**.

---

### `>>` — An Datei anhängen

```bash
echo "Neue Zeile" >> notes.txt
```

Hängt den Text am Ende an (überschreibt nicht).

---

## Prozesse und Systeminfo

### `ps` — Laufende Prozesse

```bash
ps
```

Zeigt deine laufenden Prozesse:
```
PID  TTY  TIME  CMD
1234 s000 0:01  /bin/bash
5678 s000 0:00  npm run dev
```

Alle Prozesse anzeigen:
```bash
ps aux | grep npm
```

---

### `kill` — Prozess stoppen

```bash
kill 5678
```

Stoppt den Prozess mit ID 5678 (z.B. dein `npm run dev`).

Mit Kraft (wenn `kill` nicht funktioniert):
```bash
kill -9 5678
```

---

## Netzwerk-Tests

### `ping` — Server erreichbar?

```bash
ping google.com
```

Sendet ein "Hallo, bist du da?"-Signal. Mit `Ctrl+C` beenden.

---

### `curl` — Daten von Website abrufen

```bash
curl https://sanexio.eu
```

Holt die Webseite als HTML.

Mit HTTP-Headers:
```bash
curl -i https://sanexio.eu
```

---

## Wichtige Terminal-Shortkeys

| Shortcut | Was es macht |
|----------|------------|
| `Ctrl+C` | Befehl abbrechen |
| `Ctrl+D` | Terminal schließen |
| `Ctrl+A` | Zum Anfang der Zeile |
| `Ctrl+E` | Zum Ende der Zeile |
| `Cmd+K` (Mac) | Terminal löschen |
| `Tab` | Autovervollständigung |
| `↑` / `↓` | Alte Befehle suchen |

---

## Fehler beheben

### Problem: "Command not found"

```bash
$ ls
zsh: command not found: ls
```

Das sollte nicht passieren — `ls` ist immer installiert. Wahrscheinlich Tippfehler?

---

### Problem: "Permission denied"

```bash
$ rm document.txt
rm: remove write-protected regular file 'document.txt'?
```

Die Datei ist geschützt. Lösung:

```bash
rm -f document.txt    # Force löschen (erzwingen)
```

---

### Problem: "No such file or directory"

```bash
$ cat missing.txt
cat: missing.txt: No such file or directory
```

Die Datei existiert nicht. Prüfe mit `ls` ob sie da ist.

---

## Cheat Sheet: Die 20 wichtigsten Befehle

| Befehl | Was es macht |
|--------|------------|
| `pwd` | Zeig meinen aktuellen Pfad |
| `ls` | Dateien anzeigen |
| `cd folder` | In einen Ordner gehen |
| `mkdir folder` | Ordner erstellen |
| `touch file.txt` | Leere Datei erstellen |
| `cat file.txt` | Datei-Inhalt anzeigen |
| `cp file1 file2` | Datei kopieren |
| `mv old new` | Datei umbenennen/verschieben |
| `rm file.txt` | Datei löschen |
| `grep "text" file` | Nach Text suchen |
| `find . -name "*.js"` | Datei suchen |
| `\| head` | Nur erste 10 Zeilen |
| `\| tail` | Nur letzte 10 Zeilen |
| `> file.txt` | In Datei speichern |
| `>> file.txt` | An Datei anhängen |
| `ps` | Prozesse anzeigen |
| `kill 1234` | Prozess stoppen |
| `ping google.com` | Server testen |
| `curl https://...` | Website-Daten abrufen |
| `chmod +x script.sh` | Datei ausführbar machen |

---

## Tipps für Anfänger

1. **Nutze Tab-Vervollständigung:** Tippe `cd pro` + Tab → wird zu `cd projects`
2. **Prüfe mit `ls` bevor du löscht:** `ls -la` zeigt was du löscht
3. **Nutze `-i` beim Löschen:** `rm -i file.txt` fragt immer nach
4. **Nutze `man` für Hilfe:** `man ls` zeigt alle Optionen für `ls`
5. **Alt+Links/Rechts Pfeil:** Schnell zwischen Wörtern springen

---

*Fang klein an. Lerne 5 Befehle, dann 5 mehr. In einer Woche brauchst du 80% der Arbeit.*
