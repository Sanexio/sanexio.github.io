---
type: tutorial
aliases: [Cortex-Nexus Architektur, Nexus-Philosophie, Was ist Nexus, Was ist Cortex]
tags:
  - tutorial
  - cortex
  - nexus
  - architektur
  - philosophie
source: Second Brain/30 Tutorials/Cortex & Nexus/01-architektur-und-philosophie.md
---

# 01 — Architektur & Philosophie

> Voraussetzung: keine. Lesezeit: ~15 Min.
> Ziel: Du verstehst, warum Cortex und Nexus zwei verschiedene Dinge sind,
> warum die Trennung portabel/lokal der entscheidende Designgrundsatz ist,
> und warum Projekte als Container modelliert werden.

---

## 1. Die zwei Begriffe — kurz

| Begriff | Was es ist | Wo es lebt |
|---|---|---|
| **Nexus** | Der **portable Wissenskern** — alles, was über Geräte hinweg gleich sein muss | `~/Cortex/Nexus/` — Git-Repo, gesynct via GitHub |
| **Cortex** | Der **lokale Arbeitsordner** auf einem konkreten Gerät | `~/Cortex/` — Container für Nexus + lokale Projekte |

**Merksatz:** Nexus ist das Buch, Cortex ist der Schreibtisch. Du kannst das
Buch auf jeden Schreibtisch legen, aber jeder Schreibtisch hat seine eigenen
Notizzettel.

---

## 2. Was steckt im Nexus?

Nexus enthält alles, was geräteübergreifend identisch sein muss:

- **Gedächtnis** (`_memory/`) — `MEMORY.md`, `USER.md`, Patterns, Session-Logs
- **Regeln** (`_rules/`) — globale Lehren (`GLOBAL_RULES.md`), Session-Lifecycle, Fehlerprotokoll
- **Tutorials** (`Second Brain/30 Tutorials/`) — Single Source aller Tutorials
- **Tools** (`_lib/`) — Python-Skripte für OCR, PDF, Rename, Steuern, Medizin
- **Standalone-Tools** (`tools/`) — Cortex-Sanitizer, Vault-Audit, Telegram-Bridge, Web-Pilot, Memory-Nudge
- **Skills** (`skills/`) — Skill-Pakete (.skill) für Claude
- **Specs** (`specs/`) — Architektur-Specs (Cortex-Mesh, Hermes)
- **Steuerungsdateien** — `CLAUDE.md`, `SYSTEM_MAP.md`, `_projects/INDEX.md`

Nexus ist **ein privates GitHub-Repository** und damit auf jedem Gerät verfügbar,
das den Klon hat.

---

## 3. Was ist Cortex?

Cortex ist der **lokale Arbeitsordner** auf einem bestimmten Gerät. Er enthält
den Nexus (als Git-Klon) und die Projekte, an denen auf **diesem** Gerät
gearbeitet wird.

```
~/Cortex/                       ← lokaler Arbeitsordner (pro Gerät)
├── CLAUDE.md                   ← Onboarding-Pointer für Claude
├── Nexus/                      ← Git-Repo (portabler Wissenskern)
│   ├── CLAUDE.md               ← Haupt-Steuerung
│   ├── _memory/MEMORY.md
│   ├── _rules/GLOBAL_RULES.md
│   ├── _lib/                   ← geteilte Python-Bibliothek
│   ├── tools/                  ← Standalone-Tools
│   ├── skills/                 ← Skill-Pakete
│   └── Second Brain/           ← Obsidian-Vault (Tutorials + Wissen)
│
└── projects/                   ← gerätespezifische Projekte
    ├── Juvantis/               ← nur auf Cluster-Mini-02
    ├── Cortex-Web/             ← nur auf bestimmten Geräten
    ├── doc-workflow/           ← nur auf SSMD-MacBookPro
    └── ...
```

---

## 4. Warum die Trennung „portabel vs. lokal"?

Die zentrale Designentscheidung des Ökosystems lautet:

> **Wissen, Regeln und Werkzeuge gehören in den Nexus.
> Daten, Geräte-Konfiguration und projektspezifische Arbeitsstände bleiben lokal.**

Daraus folgen drei Konsequenzen:

1. **Geräte sind austauschbar.** Geht ein Mac kaputt, klonst Du Nexus auf
   einem neuen Gerät und hast sofort alle Tools, Tutorials und Regeln zurück.
2. **Projekte sind transportierbar.** Ein Projekt mit gutem `PROJECT.md` /
   `CLAUDE.md` kann von einem Cortex auf einen anderen kopiert werden — und
   funktioniert dort weiter, weil Tools im Nexus liegen.
3. **Sync-Konflikte sind selten.** Nur Nexus-Inhalt geht durchs Git, nicht die
   Projekte. Geräte-Drift bleibt lokal.

---

## 5. Projekte als Container

Jedes Projekt ist ein **Container** mit eigenem Manifest:

| Datei | Zweck |
|---|---|
| `PROJECT.md` oder `CLAUDE.md` | Was braucht das Projekt? Welche Nexus-Tools? Wie wird es eingerichtet? |
| `SESSION_RESUME.md` | Hot-Memory: was war der letzte Stand, was kommt als Nächstes? |
| `_archive/sessions/` | Warm-Memory: Session-Logs der letzten ~7 Tage |
| `_config/RULES.md` | projekt-spezifische Regeln (zusätzlich zu globalen) |

Dieses Container-Modell ist der Grund, warum man ein Projekt einfach auf einen
anderen Cortex kopieren kann: alles, was es braucht, ist entweder im Container
oder im Nexus.

---

## 6. Memory-Layers (Kurzfassung)

Nexus organisiert Erinnerung in drei Schichten (LL-053):

| Schicht | Wo | Cap | Zweck |
|---|---|---|---|
| **Hot** | `<projekt>/SESSION_RESUME.md` | 12 k Tokens | aktive Session, sofort verfügbar |
| **Warm** | `<projekt>/_archive/sessions/YYYY-MM/session-NN.md` | — | letzte ~7 Tage, Sliding-Window |
| **Cold** | `Nexus/_archive/claude-md/YYYY-MM.md` | — | Bibliothek, lazy-load |

**Warum Schichten?** Wenn alles im Hot-Layer läge, würde der Sessionstart
mehrfach Tokens lesen, die kaum relevant sind. Schichten halten den Hot-Layer
schmal — nur N und N-1 detailliert, alles ältere als 1-Zeile-Index mit
Cold-Link.

Detail-Tutorial: [[Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme]].

---

## 7. Selbstlernendes System

Nach jeder Session, die einen Fehler aufdeckt oder neue Erkenntnisse bringt,
durchläuft das System einen festen Loop:

1. **Fehler** → `_rules/FEHLERPROTOKOLL.md` (global) oder projekt-spezifisch
2. **Regel** → `_rules/GLOBAL_RULES.md` (`LL-XYZ` neu) oder projekt-`RULES.md`
3. **Tool-Verbesserung** → in `_lib/`
4. **Tutorial-Update** → `Second Brain/30 Tutorials/<Domäne>/`
5. **Pattern** → `_memory/patterns/<name>.md`

Damit verhindert das System, dass dieselben Fehler zweimal Reibung erzeugen.
Die Goldenen Regeln (`MEMORY.md`) machen es zur **harten Pflicht**, diesen
Loop nach Sessions auszuführen.

---

## 8. Designgrundsätze (zusammengefasst)

- **Single Source of Truth.** Tutorials, Patterns, Tools — jeweils ein Ort.
  Symlinks sind erlaubt, Duplikate verboten.
- **Tools wiederverwenden, nie neu schreiben.** Alles liegt in `_lib/`.
  PDF-Extraktion immer `_lib/extract/universal_extract.py`.
- **Geräte sind austauschbar, Wissen ist es nicht.** Was Du einmal lernst,
  bleibt im Nexus.
- **Projekte sind Container.** Sie wandern zwischen Geräten, ohne dass Du
  die Tools neu installieren musst.
- **Selbstlernend.** Fehler → Regel → Tool → Tutorial.

---

## 9. Wichtige Regeln (Auszug)

- **LL-023:** MEMORY.md + GLOBAL_RULES.md bei JEDEM Sessionstart lesen.
- **LL-021:** Implementierung = funktionstüchtig, nicht Datei abgelegt.
- **LL-049:** Sync-Hygiene — bei Divergenz: STOPP, manuell auflösen.
- **LL-053:** Memory-Layers (Hot 12 k, Warm 7 Tage, Cold Bibliothek).
- **LL-055:** Trust-Tiers — Tier 1 (`~/Cortex/**`) volle Autonomie, Tier 3 (Push, Geld, Drittsystem) immer Freigabe.

Vollständiges Verzeichnis: `Nexus/_rules/INDEX.md`.

---

## 10. Wo geht's weiter?

- **Setup auf neuem Gerät:** [[Cortex & Nexus/02-multi-device-setup]]
- **Memory-Disziplin im Detail:** [[Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme]]
- **Architekten-Modus:** [[Arbeitsweise & Prozess/01-architekten-modus]]
- **Geräte-Mesh:** [[Netzwerk & Sysadmin/09-cortex-mesh-tailscale]]
