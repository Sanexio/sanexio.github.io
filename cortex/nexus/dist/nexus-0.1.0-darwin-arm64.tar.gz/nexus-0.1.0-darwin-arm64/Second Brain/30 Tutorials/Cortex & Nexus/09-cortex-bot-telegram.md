---
title: Cortex-Bot — Befehle und Architektur
domain: Cortex & Nexus
created: 2026-05-10
context: Tutorial nach Sprint-2-C1 — Telegram-Bot als bidirektionaler Steuerkanal zwischen iPhone und den Macs. Konsolidiert Befehlsreferenz + Architektur-Übersicht.
related:
  - 08-phoenix-stack.md
  - 04-trust-tiers-und-autonomie.md
  - 02-multi-device-setup.md
---

# Cortex-Bot — Befehle und Architektur

> Modul 09 — der Telegram-Bot ist die bidirektionale Schnittstelle
> zwischen Dr. Stracke (iPhone) und seinen Macs. Dieses Tutorial
> erklärt, was er kann, wie er aufgebaut ist, und wann man welchen
> Befehl benutzt.

> [!info] Lesezeit: 12 Min · Voraussetzung: Modul 08 (Phoenix-Stack)

---

## 1. Was der Bot ist — und was er nicht ist

Der Cortex-Bot heißt offiziell `@sanexio_bot`. Er ist **kein**
eigenständiger AI-Agent. Er ist die **Brücke** zwischen Telegram
und den Claude-Sessions, die auf den Macs laufen.

Drei Rollen in einer Person:

| Rolle | Beispiel |
|---|---|
| **Briefkasten** (Push) | Welle-Ende-Debrief auf iPhone empfangen |
| **Fernsteuerung** (Pull) | Vom iPhone aus eine neue Claude-Session auf einem Mac starten |
| **Freigabe-Schalter** | Tier-3-Permission per `/verdict` aus der Hosentasche bestätigen |

Der Bot ersetzt nicht den Mac vor dir. Er macht ihn nur erreichbar,
wenn du nicht davor sitzt.

---

## 2. Architektur in einer Skizze

```
┌─────────────────┐   HTTPS Long-Polling    ┌──────────────────────────┐
│  iPhone /       │ ◀──────────────────────▶│  Telegram-API (Cloud)    │
│  Telegram-App   │                         └──────────────────────────┘
└─────────────────┘                                    ▲
                                                       │ getUpdates / sendMessage
                                                       │
                                       ┌───────────────┴────────────────┐
                                       │  gateway/  (Bun + TypeScript)  │
                                       │  ───────────────────────────   │
                                       │  • channels/telegram/channel.ts│
                                       │  • channels/telegram/handlers/ │
                                       │      ├ index.ts  (core cmds)   │
                                       │      ├ spawn.ts                │
                                       │      └ verdict.ts              │
                                       │  • src/gateway.ts  (Pairings)  │
                                       └───────┬────────────────────────┘
                                               │  spawn-queue.db (SQLite)
                                               │  permission events
                                               ▼
                                     ┌──────────────────────────────┐
                                     │  agent/  (Python 3.14)       │
                                     │  ──────────────────────────  │
                                     │  • cli.py     (cortex-agent) │
                                     │  • skills/builtin/spawn.py   │
                                     │  • connexio/spawn_watcher.py │
                                     │  • memory/    (FTS5 SQLite)  │
                                     └──────┬───────────────────────┘
                                            │  startet
                                            ▼
                                  ┌─────────────────────────────┐
                                  │  claude (Claude Code CLI)   │
                                  │  → eigene Session pro Spawn │
                                  └─────────────────────────────┘
```

**Ein Satz dazu:** Telegram → Gateway empfängt → schreibt in
Spawn-Queue → Agent-Watcher nimmt heraus → startet eine
`claude`-Session auf dem adressierten Mac.

---

## 3. Setup-Status (was läuft wo)

| Mac                 | Gateway-Daemon  | Spawn-Watcher | Wann nötig             |
|---------------------|-----------------|---------------|-------------------------|
| Cluster-Mini-02     | aktiv 24/7      | aktiv 24/7    | Hauptknoten (Home)      |
| SSMD-MacBookPro-M5  | bei Login aktiv | bei Login     | Praxis-Mobile-Sessions  |
| Mac-Studio          | bei Login aktiv | bei Login     | Praxis-Studio-Sessions  |

LaunchAgent-Pfade liegen in `~/Library/LaunchAgents/com.cortex.*.plist`.
Status: `launchctl list | grep com.cortex`.

---

## 4. Die Befehle — vollständige Referenz

### 4.1 Setup & Identität

| Befehl       | Wirkung                                                           |
|--------------|-------------------------------------------------------------------|
| `/help`      | Zeigt die komplette Befehlsliste direkt im Chat.                  |
| `/start`     | Alias zu `/help`.                                                 |
| `/whoami`    | Eigene Sender-ID, Channel und Zeitstempel — gut für Debug.        |
| `/ping`      | Antwort `🏓 pong` — testet ob der Bot überhaupt erreichbar ist.   |
| `/pair`      | Registriert den aktuellen Chat als gepaartes Steuergerät. **Ohne `/pair` werden Plain-Text-Nachrichten ignoriert.** |
| `/unpair`    | Entfernt die Paarung wieder.                                      |
| `/status`    | Zeigt Hostname des antwortenden Macs, Pairing-Zustand, Stack-Info.|

> [!warning] Pairing-Sicherheit
> Nur Sender-IDs aus der Pairing-Tabelle dürfen `/spawn` und
> `/verdict` ausführen. Ohne Pairing läuft nichts schreibend.

### 4.2 Plain-Text-Eingabe

Nach `/pair` fließt **jede Nicht-Slash-Nachricht** direkt in die
zuletzt aktive Claude-Session auf demselben Mac. Das fühlt sich an
wie eine Terminal-Eingabe: Tippst du auf dem iPhone „warum ist der
Build noch rot?", landet das genau so im Claude-Prompt deiner
Cluster-Mini-02-Session.

### 4.3 Spawn — neue Session auf einem Mac starten

```
/spawn <projekt> "<auftrag>" [host=<hostname>] [tier=1|2|3]
```

| Parameter | Pflicht | Beispiel                              |
|-----------|---------|----------------------------------------|
| projekt   | ja      | `praxis-webseite`                     |
| auftrag   | ja      | `"Hero-Cards Kontrast prüfen"`         |
| host      | nein    | `host=mac-studio` (Default: aktueller) |
| tier      | nein    | `tier=2` (Default: 1, Vollautonomie)   |

**Beispiel:**
```
/spawn praxis-webseite "Lighthouse-Score auf Homepage messen" host=cluster-mini-02
```

Antwort: `✓ Spawn #14 angelegt. Watcher startet Session in ≤ 5 s.`
Sobald die Session läuft, wird ihr Welle-Ende-Debrief automatisch
zurück in den Chat gepusht.

| Hilfsbefehl       | Wirkung                                  |
|-------------------|------------------------------------------|
| `/spawn-list`     | Letzte 10 Spawns mit Status (queued / running / done / failed). |
| `/spawn-cancel <id>` | Bricht einen noch wartenden Spawn ab.|

### 4.4 Verdict — Tier-3-Freigabe per Daumen

Wenn eine Claude-Session eine Tier-3-Operation erreicht (z. B.
`git push --force`, `.env`-Schreiben), pausiert sie und schickt eine
Permission-Anfrage an den Bot:

```
🛑 Permission #023 — Cluster-Mini-02
Operation: git push --force origin main
Branch:    feature/hero-redesign
Reason:    Force-Push auf eigenes Repo, History-Rewrite.

Antworte mit:  /verdict 023 yes      oder   /verdict 023 no
```

Der Befehl:
```
/verdict <id> yes|no
```

`yes` setzt die Session fort, `no` bricht die Operation ab und gibt
das Veto an die wartende Session weiter. Beide Antworten sind
**zeitlich gebunden** — nach 10 Min ohne Antwort verfällt die
Anfrage und die Operation wird automatisch verworfen.

---

## 5. Welche CLI-Befehle der Mac dazu kann

Die Bot-Befehle haben CLI-Pendants, die du auch direkt im Terminal
nutzen kannst (nützlich beim Debugging):

```bash
# Mode-Check / -Switch (lokal, ohne Bot)
cortex-agent mode get
cortex-agent mode set autonomy   # oder: safe

# Skills
cortex-agent skill list
cortex-agent skill run doctor
cortex-agent skill run spawn --args '{"project":"praxis","task":"Smoke-Test"}'

# Memory
cortex-agent memory search "praxis-webseite"
cortex-agent memory facts --kind contact
cortex-agent memory add-fact contact phone "+49 1234"

# Manuelles Starten des Telegram-Gateways (sonst LaunchAgent-Job)
cd ~/Cortex/Nexus/gateway && bun run telegram
```

---

## 6. Typische Use-Cases

### 6.1 „Ich bin unterwegs und will eine Aufgabe absetzen"

```
/spawn praxis-webseite "Reviews-Section auf 6 Sprachen prüfen" host=mac-studio
```
→ Mac-Studio startet eine neue Session, du bekommst das Ergebnis
in den Chat gepusht, sobald die Welle endet.

### 6.2 „Eine laufende Session fragt nach Freigabe"

Push: `🛑 Permission #017 — git push origin main`
Antwort: `/verdict 017 yes`
→ Session fährt fort und merged.

### 6.3 „Ich will mit einer laufenden Session weiterreden"

`/pair` einmal pro Chat ausführen (sticky), dann einfach Plain-Text
schicken: „mach den Cache-Bust noch dazu" → landet als nächste
User-Nachricht in der Session.

### 6.4 „Ist der Mac überhaupt online?"

```
/status
```
→ Antwort enthält `Host: cluster-mini-02` (der antwortende Daemon).
Wenn zwei Macs gepaart sind, antwortet derjenige zuerst, dessen
Gateway-Daemon online ist.

---

## 7. Was passiert intern (eine Spawn-Reise)

1. Du tippst `/spawn …` in Telegram.
2. Telegram-API leitet das Update via Long-Polling an
   `gateway/channels/telegram/channel.ts`.
3. Der Handler `handlers/spawn.ts` validiert: Pairing? Projekt-Pfad?
   Tier-Level? — schreibt einen Eintrag in
   `_memory/spawn-queue.db` (SQLite, Tabelle `spawns`).
4. Der Daemon `agent/connexio/spawn_watcher.py` pollt die Queue
   alle 2 s, sieht den neuen Eintrag und ruft `claude` mit dem
   passenden Working-Directory + Initialprompt auf.
5. Claude-Session startet, schreibt während der Arbeit Updates
   nach `_memory/logs/<datum>_<thema>.md`.
6. Am Welle-Ende ruft das Skill `outbound.send_telegram` an —
   das hängt einen Push-Eintrag in den Outbound-Channel des
   Gateways, der ihn an Telegram zustellt.

---

## 8. Troubleshooting

| Symptom                              | Erste Diagnose                                                                  |
|--------------------------------------|---------------------------------------------------------------------------------|
| `/ping` antwortet nicht              | Gateway-Daemon ist down. `launchctl list \| grep cortex.gateway` prüfen.         |
| `/spawn` sagt „Pairing fehlt"        | `/pair` zuerst senden.                                                          |
| Spawn-Queue läuft voll               | `cortex-agent skill run cron-doctor` — repariert hängende Watcher.              |
| Keine Welle-Ende-Pushes mehr         | `outbound.py`-Skill checken: `tail -f _memory/logs/outbound.log`.               |
| Verdict-Anfragen kommen nicht        | Tier-3-Hardstop ist im Mode-Hook konfiguriert; ohne den Hook laufen Tier-3-Ops still durch — `cat ~/.claude/state/cortex-mode.json`. |

---

## 9. Sicherheitsmodell in 4 Sätzen

1. **Nur gepaarte Sender** dürfen schreibend kommandieren.
2. **`spawn-queue.db`** kennt pro Spawn ein **Tier-Level**; Tier ≥ 3
   pausiert und braucht `/verdict`.
3. **Bot-Token** liegt in `gateway/.env`, nie im Git.
4. **Outbound** sendet nur an Chat-IDs, die in `pairings` stehen —
   ein kompromittierter Pairing-Eintrag würde nur den eigenen Chat
   spammen, nicht fremde.

---

## 10. Wo welche Datei liegt

| Was                          | Pfad                                                  |
|------------------------------|-------------------------------------------------------|
| Bot-Code (Channel-Layer)     | `gateway/channels/telegram/channel.ts`                |
| Bot-Befehle (Handler)        | `gateway/channels/telegram/handlers/*.ts`             |
| Spawn-Queue                  | `_memory/spawn-queue.db`                              |
| Spawn-Watcher                | `agent/connexio/spawn_watcher.py`                     |
| Outbound-Skill               | `agent/skills/builtin/outbound.py`                    |
| Bot-Token                    | `gateway/.env`  (Variable `TELEGRAM_BOT_TOKEN`)       |
| Pairings                     | `gateway/data/pairings.json`                          |
| LaunchAgent-Plists           | `~/Library/LaunchAgents/com.cortex.*.plist`           |

---

*Modul 09 — Stand 2026-05-10. Folgemodul 10 wird die Connexio-MCP-
Surface beschreiben, sobald Sprint C2 abgeschlossen ist.*
