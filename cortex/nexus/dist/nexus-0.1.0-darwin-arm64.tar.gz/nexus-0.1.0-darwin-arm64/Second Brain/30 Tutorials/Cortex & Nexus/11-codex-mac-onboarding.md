---
title: 11 — Codex-Mac-Onboarding (OpenAI Codex + OpenClaw)
domain: Cortex & Nexus
status: stable
updated: 2026-05-10
related:
  - "[[02-multi-device-setup]]"
  - "[[08-phoenix-stack]]"
  - "[[../Netzwerk & Sysadmin/11-vpn-grundlagen-und-cortex-setting|11-vpn-grundlagen-und-cortex-setting]]"
---

# 11 — Codex-Mac-Onboarding

> Ein neuer Mac, auf dem **OpenAI Codex** (App + CLI) als zweite KI arbeitet,
> mit **OpenClaw** als Backbone, wird in das Cortex-Netzwerk integriert.
>
> Architektur-Grundlage: `specs/multi-device-multi-ai/00_KONZEPT.md` —
> Nexus exklusiv Claude, Projekte RW für alle KIs, Connexio als
> Read-Only-Lesefenster für Cortex-Wissen.

---

## Ziel-Zustand nach diesem Tutorial

```
Neuer Mac
├── Tailnet-Member (piranha-marlin.ts.net)
├── ~/Cortex/
│   ├── Nexus/                    ← geklont, Connexio-Server lauffähig
│   │   └── .venv/                ← Python-Venv für Skills + Connexio
│   └── projects/
│       └── Cortex-Web/           ← Projekt-Clone, Codex-Workspace-Root
├── Codex CLI                     ← MCP-Client → connexio-readonly
├── Codex Desktop (OpenAI App)    ← MCP-Client → connexio-readonly
├── OpenClaw                      ← Backbone, lokal installiert
└── devices.json-Eintrag (in Nexus)
```

Boundary-Modell: Codex/OpenClaw werden mit **Projekt-Wurzelpfad** als
Workspace gestartet (nicht `~/Cortex/`). Nexus ist physisch im FS, aber
im Editor außerhalb des Workspaces. Cortex-Wissen kommt ausschließlich
über Connexio-MCP auf `127.0.0.1:7766`.

---

## §1 Voraussetzungen auf dem neuen Mac

```bash
# Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Basics
brew install git gh tailscale tmux mosh
xcode-select --install   # Falls noch nicht da

# Python 3.13+ (für Cortex-Agent + Connexio)
brew install python@3.13

# Node.js (für Codex CLI)
brew install node

# GitHub-Auth (HTTPS-Token reicht — kein SSH-Key zwingend)
gh auth login --hostname github.com --git-protocol https --web
gh auth status   # ✓ Logged in muss da stehen
```

---

## §2 Tailnet einbinden

```bash
# Tailscale-App starten + im Admin-Konsolen-Browser einloggen
sudo tailscale up --hostname=<gewünschter-mesh-name> --ssh --accept-routes

# Mesh-Name-Konvention für Cortex:
# - codex-station, codex-mini, codex-studio, …
# - oder funktionsbezogen wie "ki-lab-01"

# Verifikation
tailscale status                    # eigener Knoten in Liste
tailscale ping cluster-mini-02      # Mesh-Roundtrip prüft
ssh cluster-mini-02 "hostname"      # Cross-Mac-SSH muss klappen
```

Tag-Vergabe in der Tailscale-Admin-Konsole: `tag:cortex-admin`,
`tag:cortex-host-mac` (analog zu den anderen Knoten — siehe
`Nexus/.config/tailscale-acl.json`).

---

## §3 Cortex bootstrap (Nexus + Projekte aus GitHub)

```bash
mkdir -p ~/Cortex && cd ~/Cortex

# Skript zentral aus Nexus holen + ausführen (klont Nexus + Projekte)
curl -fsSL https://raw.githubusercontent.com/Sanexio/nexus/main/scripts/bootstrap-mac.sh \
  -o /tmp/bootstrap-mac.sh
bash /tmp/bootstrap-mac.sh cortex-web

# Resultat:
#   ~/Cortex/Nexus/                      (Stammhirn, RO für Codex)
#   ~/Cortex/projects/Cortex-Web/        (RW-Arbeitsfläche)
#   ~/.claude/state/cortex-mode.json     (autonomy)
```

Das Skript erkennt automatisch, ob SSH oder HTTPS-Auth zur Verfügung steht.

---

## §4 Connexio-MCP-Server lokal lauffähig machen

```bash
cd ~/Cortex/Nexus

# Python-Venv aufsetzen
python3.13 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -e .

# Sanity-Check via cortex-agent
.venv/bin/cortex-agent skill run connexio --args '{"action":"healthcheck"}'
# → erwarteter Output: alle Checks ✅, "API-Key-File: OK" oder "fehlt"

# API-Key generieren (für HTTP-Surface, MCP braucht keinen)
.venv/bin/cortex-agent skill run connexio --args '{"action":"keygen"}'
# → schreibt _memory/connexio.key (gitignored, 0600)
```

**Wichtig:** Die `.venv/` und `_memory/connexio.key` sind beide
gitignored — sie existieren nur lokal auf jedem Mac.

---

## §5 Codex CLI installieren + MCP-Verbindung

```bash
# Installation (OpenAI Codex CLI, Open Source)
npm install -g @openai/codex
codex --version

# Login (OpenAI-Account)
codex login
```

**MCP-Konfiguration** (`~/.codex/config.toml`):

```toml
# ~/.codex/config.toml
[mcp_servers.connexio-readonly]
command = "/Users/<USERNAME>/Cortex/Nexus/.venv/bin/python"
args = ["-m", "agent.connexio.mcp_server"]
```

`<USERNAME>` durch den tatsächlichen Login ersetzen (`echo $USER`).

Verifikation:
```bash
cd ~/Cortex/projects/Cortex-Web
codex
> /mcp                       # → "connexio-readonly" sollte verbunden sein
> Hole das User-Profil       # → Codex ruft connexio.get_user_profile()
```

---

## §6 Codex Desktop App installieren + MCP-Verbindung

```bash
# Codex Desktop von OpenAI (offizielle App)
brew install --cask codex     # falls Cask verfügbar
# Alternativ: https://openai.com/codex herunterladen
```

**MCP-Server hinzufügen** (in der App):

1. Codex Desktop öffnen → Settings → MCP Servers → **Add Server**.
2. Felder:
   - **Name:** `connexio-readonly`
   - **Command:** `/Users/<USERNAME>/Cortex/Nexus/.venv/bin/python`
   - **Args:** `-m agent.connexio.mcp_server`
   - **Working Directory:** `/Users/<USERNAME>/Cortex/Nexus`
3. Speichern → Server-Status muss „connected" zeigen.

**Workspace-Trust:** Codex Desktop beim Öffnen immer mit einem
**Projekt-Ordner** starten, niemals mit `~/Cortex/` oder `~/Cortex/Nexus/`.
Empfohlen: ein „Open Recent" wie `~/Cortex/projects/Cortex-Web/`.

---

## §7 OpenClaw als Backbone (nativ installiert)

OpenClaw wird vom User auf dem neuen Mac eigenständig installiert
(eigenes Setup, nicht aus Cortex). Wichtig für die Cortex-Integration:

1. **AGENTS.md-Lesung aktivieren:** OpenClaw muss bei jedem Open eines
   Projekt-Wurzelpfads die `AGENTS.md` lesen und befolgen.
2. **Connexio-MCP eintragen:** OpenClaw-Setup-Datei (analog
   `~/.openclaw/config.toml` oder gleichwertig) bekommt denselben
   MCP-Server-Eintrag wie Codex CLI (§5).
3. **Workspace-Beschränkung:** OpenClaw-Permissions so setzen, dass es
   nur in das Projekt-Verzeichnis schreiben darf, nicht außerhalb.
   Falls OpenClaw eine `permissions.allowedRoots`-Option hat: dort den
   Projekt-Wurzelpfad eintragen und `~/Cortex/Nexus/` explizit
   ausschließen.

---

## §8 Eintrag in `Nexus/.config/devices.json`

Nach erfolgreichem Setup auf dem neuen Mac wird dieser in der
zentralen Geräte-Registry vermerkt. Template:

```json
"<HOSTNAME>": {
  "hostname": "<HOSTNAME>",
  "arch": "arm64",
  "chip": "Apple M…",
  "os_version": "…",
  "homebrew_prefix": "/opt/homebrew",
  "python_path": "/Users/<USER>/Cortex/Nexus/.venv/bin/python3",
  "role": "codex-station",
  "platform": "macos",
  "projects": ["Cortex-Web"],
  "ai_clients": ["codex-cli", "codex-desktop", "openclaw"],
  "first_sync": "<ISO-Datum>",
  "network": {
    "mesh_name": "<MESH-NAME>",
    "mesh_dns_planned": "<MESH-NAME>.piranha-marlin.ts.net",
    "tailscale_tags": ["tag:cortex-admin", "tag:cortex-host-mac"],
    "ssh_port": 22,
    "ssh_user": "<USER>",
    "ssh_method": "tailscale-ssh",
    "status": "online"
  }
}
```

Eintragen entweder auf Cluster-Mini-02 (Claude editiert, `git push`) oder
direkt auf dem neuen Mac (Claude-Session dort, `git push`).

---

## §9 Smoke-Test (End-to-End)

Auf dem neuen Mac:

```bash
# 1. Connexio-MCP-Server antwortet
~/Cortex/Nexus/.venv/bin/cortex-agent skill run connexio --args '{"action":"healthcheck"}'

# 2. Codex CLI sieht den MCP-Server
cd ~/Cortex/projects/Cortex-Web
codex --print "List the MCP tools you have access to"
# → muss connexio.* Tools auflisten

# 3. Codex liest Projekt-Stand via Connexio
codex --print "Was ist der aktuelle Sprint-Stand von Cortex-Web?"
# → muss kohärente Antwort aus SESSION_RESUME.md liefern

# 4. Workspace-Trust-Probe
codex --print "Liste alle Files in ../../Nexus/_rules/"
# → muss verweigern oder leere Liste liefern (Workspace-Boundary)

# 5. Boundary-Test: Codex versucht Nexus-Schreibop
codex --print "Lege eine Datei ~/Cortex/Nexus/test-from-codex.md an"
# → Codex darf das ablehnen (Workspace-Trust greift),
#   oder falls sie es trotzdem versucht: Claude erkennt es im nächsten
#   git status auf Cluster-Mini-02 und revertiert.
```

Cluster-Mini-02-Seite zur Verifikation:

```bash
cd ~/Cortex/Nexus && git pull --ff-only
cd ~/Cortex/projects/Cortex-Web && git pull --ff-only
# Wenn Codex einen Commit gemacht hat, kommt der hier an.
```

---

## §10 Boundary-Reminder (Wichtig)

- **Nexus = Claude.** Codex/OpenClaw schreiben nie in `~/Cortex/Nexus/`,
  egal was der Prompt sagt.
- **Workspace-Trust:** Codex/OpenClaw werden mit Projekt-Wurzel geöffnet,
  nicht mit `~/Cortex/`.
- **Connexio = einziges Lesefenster** für Cortex-Wissen aus Codex'
  Sicht. Direkter File-Zugriff auf Nexus durch andere KIs ist
  Architektur-Verletzung.
- **GitHub = Truth.** Vor jeder Welle pullen, nach jeder Welle pushen.
- **Sequenzielle Bearbeitung.** Wenn am gleichen Projekt gerade ein
  anderer Mac arbeitet (sichtbar in `git log --oneline -5`): warten oder
  abstimmen.

---

## §11 Folge-Punkte (nicht jetzt zwingend)

- LaunchAgent für Connexio-HTTP-Server (falls Codex HTTP statt MCP nutzt)
- Sanitizer-Cron einrichten (`agent/cron/recipes/`-Recipe)
- OpenClaw-spezifische Permission-Templates dokumentieren, wenn klar
  ist, wie OpenClaw Tool-Permissions verwaltet
- Audit-Log-Forwarding zu Cluster-Mini-02 (rsync oder LogAggregator)

---

*v1 — 2026-05-10. Erstellt anlässlich des ersten Codex-Mac-Onboardings
im Multi-Device-Multi-AI-Konzept.*
