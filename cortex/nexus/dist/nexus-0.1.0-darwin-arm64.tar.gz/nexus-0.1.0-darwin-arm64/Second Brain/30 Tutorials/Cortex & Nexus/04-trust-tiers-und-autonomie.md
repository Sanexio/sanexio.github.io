---
type: tutorial
aliases: [Trust-Tiers, Autonomie, LL-055, Vollautonomie, Tier 1, Tier 2, Tier 3]
tags:
  - tutorial
  - cortex
  - nexus
  - autonomie
  - ll-055
  - trust-tiers
source: Second Brain/30 Tutorials/Cortex & Nexus/04-trust-tiers-und-autonomie.md
---

# 04 — Trust-Tiers & Autonomie

> Voraussetzung: [[Cortex & Nexus/01-architektur-und-philosophie]] gelesen.
> Lesezeit: ~15 Min.
> Ziel: Du verstehst, warum Claude nicht mehr bei jedem Cortex-Edit nachfragt,
> wo die Grenze zwischen „einfach machen" und „erst Freigabe holen" liegt
> und welche Regeln davon **ausgenommen** sind.

---

## 1. Warum es LL-055 gibt

Bis 2026-04-29 galten zwei Pflicht-Regeln strikt:

- **LL-024** — bei jedem Schritt WAS / WARUM / WAS BEDEUTET DAS erklären.
- **LL-034** — bei Entscheidungen alle Optionen mit Vor-/Nachteilen, keine Empfehlung.

Beide Regeln sind didaktisch wertvoll — sie machen Sessions zu Lernanlässen.
**Aber:** Bei Routine-Arbeit erzeugten sie chronische Rückfragen. Sessions
wurden langsam, jeder Datei-Move dauerte zwei Nachrichten.

Der Cortex-Effizienz-Re-Design-Sprint D1 (2026-04-29) hat das umsortiert.
Ergebnis: **LL-055 — drei Vertrauens-Tiers**, nach openclaw-Vorbild.

---

## 2. Die drei Tiers

| Tier | Bereich | Default-Verhalten |
|---|---|---|
| **1 — Cortex-Inland** | `~/Cortex/**` und Auto-Memory unter `~/.claude/projects/-Users-cluster-mini-02-Cortex/**` | **Vollautonomie** — Edit/Write/Read/Bash ohne Freigabe |
| **2 — Lokal extern, unkritisch** | restlicher Mac (`/Users/cluster-mini-02/**`, `/tmp/**`), Local Sites, Tutorials | Read frei, Write in Nutzer-Bereichen frei, Write in System-Pfaden weiter mit Freigabe |
| **3 — Kritisch** | Push-zu-Remote (außer Auto-Whitelist §26.5), Geld-Ops, Nachrichten-Versand an Dritte, Drittsystem-Schreibops, destruktive Git-Ops | Freigabe weiter Pflicht, technisch via `deny`/`ask` durchgesetzt |

**Merksatz:** Tier 1 ist „Dein Schreibtisch", Tier 2 ist „Dein Haus", Tier 3
ist „die Außenwelt". Im eigenen Schreibtisch räumt Claude ohne zu fragen, im
Haus mit Augenmaß, draußen nur mit Erlaubnis.

---

## 3. Was unverändert bleibt (auch in Tier 1)

LL-055 ist **kein Freibrief**. Folgende Regeln gelten in allen Tiers:

- **LL-050** (destruktive Git-Ops, §27) — `git rebase --skip/--abort`,
  `git reset --hard`, `git push --force`, `git clean -fd`, `git checkout -- .`,
  `git branch -D`, `git stash drop/clear`, `git filter-branch`, `rm -rf .git*` —
  **immer** mit expliziter Freigabe, auch in `~/Cortex/`.
- **§26.5** (Auto-Add-Whitelist für `nexus-sync.sh`) — Phantom-Modifications
  bleiben strukturell unmöglich.
- **Secrets-Handhabung** — Tokens, App-Passwords, `.env`-Inhalte werden nie
  automatisch committed/gepusht/geloggt. Admin-Passwörter werden im Chat
  ausgeschlossen.
- **LL-049** (Sync-Pull vor Edit in Nexus) — bleibt.
- **§27.5 Hard-Stop-Liste** (`deny`) — bleibt.

---

## 4. Lockerung von LL-024 (Transparenz-Pflicht)

LL-024 bleibt **als Lern-Werkzeug** verfügbar, ist aber **nicht mehr Default**.

| Anlass | Ausführung |
|---|---|
| **Routine** (Refactoring, Bug-Fix, Datei-Move) | 1-Satz-Status, weiter |
| **Lern-Sessions** (Themenfeld aus `_memory/USER.md` Lernprioritäten) | WAS / WARUM / WAS BEDEUTET DAS |
| **Explizite Bitte** („erklär das genauer", „warum so?") | volle Erklärung |
| **Neues Konzept oder Tool**, das Du noch nicht kennst | volle Erklärung |
| **Code-Sessions, Auto-Maintenance** | keine Lehr-Texte |

**Lernprioritäten** sind in `_memory/USER.md` gepflegt: 1) Sysadmin Praxis,
2) Web-Programmierung, 3) iOS DHT. Bei Themen aus dieser Liste schaltet
Claude automatisch in den Lehr-Modus.

---

## 5. Lockerung von LL-034 (Optionen ohne Empfehlung)

LL-034 bleibt **für strategische Entscheidungen** in Kraft, **nicht für taktische**.

| Kategorie | LL-034-Status | Beispiele |
|---|---|---|
| **Strategisch** (LL-034 voll aktiv) | Optionen + Vor-/Nachteile + Vergleichstabelle, **keine Empfehlung**, Du wählst | Architektur-Wahlen, neue Projekte, Vorgehen-Reset, größere Refactorings, Tool-Wahl, Tech-Stack-Wechsel |
| **Taktisch** (LL-034 nicht erforderlich) | einfach machen, in einem Satz erwähnen | Datei umbenennen, Funktion refaktorieren, Bug fixen, Whitespace, kleine Patches, Logfile rotieren |

**Im Zweifel:** Wenn die Aktion reversibel ist und ≤ 5 Min Aufwand → taktisch.
Sonst → kurz Optionen vorlegen.

---

## 6. Technische Durchsetzung

LL-055 ist nicht nur eine Etikette — sie ist in der Claude-Code-Konfiguration
hart kodiert:

- **Tier-1-Allow-Patterns** in `~/Cortex/.claude/settings.local.json`
  (Edit/Write/Read auf `~/Cortex/**` und Memory-Ordner, breite
  Standard-Bash-Patterns für Routine-Befehle).
- **Tier-3-Deny/Ask-Patterns** unverändert aus §27.
- **Vorrang:** `deny` > `ask` > `allow`. Tier-3-Befehle bleiben gesperrt,
  auch wenn ein breites Tier-1-Pattern sie versehentlich miteinschließen würde.

> [!tip] Routine-Bash-Befehle ohne Freigabe (Tier 1)
> `ls`, `mkdir`, `touch`, `cat`, `head`, `tail`, `wc`, `stat`, `file`, `diff`,
> `grep`, `rg`, `sed`, `awk`, `jq`, `cp`, `mv`, `ln -s`, `chmod +x`, `node`,
> `npm run`, `npx`, `bun`, `bunx`, `pip`, `pip3`, alles unter `~/Cortex/**`.
> WebFetch + WebSearch frei.

---

## 7. Anti-Patterns

❌ Bei jedem Cortex-Edit Optionen vorlegen und auf Freigabe warten — Bremse, Tier 1.
❌ Drei-Absatz-Erklärung für `mv foo.md bar.md` — bürokratisch.
❌ Tier 1 als Freibrief für destruktive Git-Ops — LL-050 hat **immer** Vorrang.

✅ Edit machen, kurze Statusmeldung („Habe `inc/nav-data.php` um Punkt X
ergänzt."), weiter.
✅ Bei strategischer Wahl (z.B. „WordPress vs. Static Site") → LL-034 voll,
Optionen mit Vor-/Nachteilen.

---

## 8. Bezug zu anderen Regeln

| Regel | Verhältnis zu LL-055 |
|---|---|
| **LL-024** | Gelockert (siehe §4 oben), bleibt für Lern-Anlässe verfügbar |
| **LL-034** | Gelockert (siehe §5 oben), bleibt für strategische Wahlen |
| **LL-050** | Unberührt — Vorrang in allen Tiers |
| **§26.5** | Unberührt (Auto-Add-Whitelist) |
| **LL-049** | Unberührt (Sync-Pull vor Edit in Nexus) |

---

## 9. Wo geht's weiter?

- **Pflicht-Spec (Vollform):** `Nexus/_rules/GLOBAL_RULES.md §31`
- **Architekten-Modus** (4 Phasen, eingebettet in Trust-Tiers):
  [[Arbeitsweise & Prozess/01-architekten-modus]]
- **Quick-Reference:** `Nexus/_rules/INDEX.md`
- **Settings-Datei** (technische Durchsetzung): `~/Cortex/.claude/settings.local.json`
