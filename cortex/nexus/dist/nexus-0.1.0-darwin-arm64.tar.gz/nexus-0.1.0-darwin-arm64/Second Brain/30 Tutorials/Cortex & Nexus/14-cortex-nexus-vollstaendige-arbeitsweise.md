# 14 — Cortex & Nexus: Vollständige Arbeitsweise

> **Zweck:** Erklärt, was Cortex und Nexus sind, wie sie zusammenarbeiten,
> welche Files wofür existieren und in welcher Reihenfolge sie geladen,
> gelesen oder ausgeführt werden. Geschrieben am 2026-05-31 als Re-Baseline
> nach Drift-Beschwerde („System ist überladen, du hast den Überblick verloren").
>
> Tutorial-Explain-Mode: jedes File bekommt Pfad, Zweck, Lebenszyklus.
>
> **Stand 2026-05-31 abends — Wesentliche Änderungen seit Initialfassung:**
> Tier-3 von 3 Kategorien auf 1 reduziert (nur Bank/Bezahl). Distribution-
> Guards (Git-Hooks) hart erzwingen Distribution-Block bei sensitiven
> Files. nexus-sync.sh hat Post-Pull-Bootstrap-Hook (Self-Heal-Verteilung,
> ≤10 Min Latenz). Multi-Mac-Health-Dashboard pingt täglich 07:00 nach
> Telegram. Volle Details in Abschnitt 13.

---

## 1. Begriffe — Cortex vs. Nexus

**Cortex** ist der **Oberbegriff** für Dr. Strackes gesamte digitale
Arbeitsumgebung. Konkret: alles unter `~/Cortex/` auf jedem seiner Macs.
Cortex ist **kein** einzelnes Repo, sondern ein Konzept: „die Welt, in der
ich mit KIs arbeite". Cortex enthält:

- `~/Cortex/Nexus/` — der gemeinsame, geteilte Steuerungs-Kern.
- `~/Cortex/projects/<projekt>/` — die individuellen Projekte (Code, Daten).
- `~/Cortex/Desk/` — Arbeitsplatz/Eingangskorb für Dokumente.
- `~/Cortex/outputs/`, `~/Cortex/_archive/` — Output- und Archiv-Buckets.

**Nexus** ist ein **konkretes Git-Repo** (`Sanexio/nexus` auf GitHub),
ausgecheckt auf jedem Mac unter `~/Cortex/Nexus/`. Nexus enthält die
**Steuerungsschicht** — also Regeln, Skills, Agent-Code, Memory-Index,
Tutorials. Nexus ist auf **jedem Mac identisch** (modulo Pull-Lag) und
synchronisiert sich automatisch via `nexus-sync.sh`.

**Faustregel:** *„Nexus ist Claude-exklusiv (Schreibrechte), andere KIs
arbeiten in `projects/`."* — siehe `_rules/multi-ai-boundaries.md`.

---

## 2. Die Geräte (Cortex-Mesh)

Cortex lebt auf mehreren Macs. Die **Single Source of Truth** für Geräte
ist `Nexus/.config/devices.json`. Stand 2026-05-31:

| Hostname | Rolle | Hardware | Mesh-Name |
|---|---|---|---|
| `Cluster-Mini-02` | home | Mac Mini M2 | `cluster-mini-02` |
| `Cluster-Mini-04` | home | Mac Mini M2 | `cluster-mini-04` |
| `Mac-Studio` | praxis-studio | Mac Studio | `praxis-studio` |
| `SSMD-MacBookPro-M5` | praxis-mobile | MacBook Pro M5 | `macbookpro-silicon` |
| `SSMD-MacBookPro` | praxis (alt) | MacBook Pro Intel | `macbookpro-intel` |

Vernetzung via **Tailscale-Mesh** (`piranha-marlin.ts.net`). SSH von jedem
Mac zu jedem anderen ohne Portfreigabe. Tailscale ist KEIN Sync-Mechanismus,
sondern nur ein Verbindungslayer für SSH/Mosh.

**Sync läuft ausschließlich über GitHub.** Tailscale dient für Live-Debug
(Logs ziehen, anderen Mac aus der Ferne anstoßen), nicht für Datentransport.

---

## 3. Die zentralen Files (mit Pfad, Zweck, Lebenszyklus)

### 3.1 Einstiegs- und Steuerungs-Files

| Datei | Zweck | Wann gelesen |
|---|---|---|
| `~/Cortex/Nexus/CLAUDE.md` | Session-Einstieg für Claude. Listet Pflicht-Lesungen, Init-Workflow, Stack. | Bei jedem Session-Start automatisch in den Kontext geladen. |
| `~/Cortex/Nexus/SYSTEM_MAP.md` | Pointer-Index — „wo finde ich was?". Tabelle aller relevanten Pfade. | Manuell, wenn man Architektur-Orientierung braucht. |
| `~/Cortex/Nexus/PHOENIX_RESUME.md` | Fortsetzungspunkt nach dem Phoenix-Hard-Reset (2026-05-08/09). | Bei „Phoenix fortsetzen". |
| `~/Cortex/Nexus/HANDOVER_PHOENIX.md` | Übergabe-Dokument der Phoenix-Welle. | Bei tiefem Onboarding. |

### 3.2 Regelwerk (`_rules/`)

Dieses Verzeichnis ist die **Policy-Schicht**. Alle Files hier sind
geräteübergreifend gültig (GitHub-synced). Wichtig in Reihenfolge ihrer
Tragweite:

| Datei | Zweck |
|---|---|
| `AUTONOMY_CONTRACT.md` | Index der Regeln. R0–R3-Risiko-Level, State-First-Prinzip, Lease-Mechanik, AI-Cooperation in Kurzform. **Pflicht-Lesung.** |
| `glossary.md` | Knappe Definitionen aller Fachbegriffe (R0–R3, Hook, Lease, FTS5, MCP, Connexio, Tier-3, Welle, Phoenix, Skill, …). **Pflicht-Lesung.** |
| `user-directives.md` | Stracke-spezifische pauschale Freigaben und vorrangige Regeln (Tutorial-Explain-Mode, Pauschal-Freigabe in `~/Cortex/`). **Pflicht-Lesung.** |
| `risk-levels.md` | Detail-Definitionen R0 (read-only frei) bis R3 (immer Stop). |
| `modes.md` | Mode × Risiko-Matrix und Switch-Befehle. |
| `stop-conditions.md` | Vollständige Liste aller Trigger, bei denen sofort gestoppt werden muss. Mode-unabhängig. |
| `tasks.md` | Task-Manifest-Pflichtfelder (`allowed_paths`, `risk_level`, `machine`, `base_commit`, …). Pre-Flight-Checks. |
| `verification.md` | Was vor `done` geprüft werden muss. |
| `retention.md` | Anti-Müll-Regeln. Was wird wie lange behalten? |
| `ai-cooperation.md` | Claude × Codex Peer-Modell. Wer darf wo schreiben, Outbox-Konvention. |
| `multi-ai-boundaries.md` | Grenzen für **andere** KIs (Cursor, Cline, Continue, Gemini-CLI) am Nexus. |
| `lesson-anchors.md` | Wie Lessons in `WAS GELERNT`-Bullets persistent verankert werden müssen. |
| `security.md` | Token, Secrets, Logging — was nie ins Repo darf. |
| `medical-domain.md` | DSGVO, Patient-Tags, SmartQ-spezifische Regeln. |
| `sync-policy.md` | Runtime-Aggregat: wer pullt, wer pusht, wann. |

### 3.3 Mode-Definitionen (`agent/modes/`)

| Datei | Zweck |
|---|---|
| `agent/modes/autonomy.md` | Vollständiger Autonomy-Mode-Briefing. **Wird per Hook in den Kontext jedes Prompts injiziert.** Default-Mode. |
| `agent/modes/safe.md` | Safe-Mode mit 4-Phasen-Workflow und Phase-2-Approval-Gate. |
| `agent/modes/tier3.md` | **Single Source of Truth für Tier-3-Hardstops** (Secrets, Geld, externe Empfänger). Mode-unabhängig. **Wird per Hook injiziert.** |

### 3.4 Memory-Schicht (`_memory/`)

Memory ist mehrschichtig — das verwirrt am Anfang. Drei Layer:

| Datei | Zweck | Gitignored? |
|---|---|---|
| `_memory/USER.md` | Dr.-Stracke-Profil (Rolle, Goals, Spezifika). | nein |
| `_memory/KNOWLEDGE.md` | Pointer-Index zum Vault (`Second Brain/`). | nein |
| `_memory/golden-rules.md` | Aggregat-Snapshot der wichtigsten Regeln (LL→R-Mapping, Tier-3, Wiederholungsfehler-Patterns GF-001..GF-007). | nein |
| `_memory/memory.db` | SQLite-FTS5-DB für volltextindizierte Facts und Notes. | **ja** (lokal pro Mac) |
| `_memory/spawn-queue.db` | SQLite-Queue für Spawn-Jobs (Codex/Claude-Aufgaben übergeben). | **ja** |
| `_memory/logs/` | Session-Logs, Telegram-Bridge-Logs. | **ja** |

**Zusätzlich Claude-eigener Memory-Layer** außerhalb von Nexus:
`~/.claude/projects/-Users-ssmd-Cortex/memory/` — das sind die auto-Memory-Files,
die Claude selbst über Sessions hinweg pflegt. Geräte-lokal, nicht synchronisiert.

### 3.5 Skills-Schicht

Zwei Skill-Typen, leicht verwechselbar:

| Pfad | Typ | Zweck |
|---|---|---|
| `Nexus/agent/skills/builtin/*.py` | **Python-Agent-Skills** | Funktionen, die der Hermes-style cortex-agent in seinem Loop aufrufen kann (`@skill`-Dekorator). |
| `Nexus/skills/*.skill` | **Claude-Code-Skill-Pakete** | ZIPs, die per `/<skill-name>` aufrufbar werden. Sind nicht synchronisiert mit Python-Skills. |

Plus die **Anthropic-system-skills** (`safe-mode`, `autonomy-mode`,
`cortex-mode`, `update-config`, …) — siehe „Available skills"-Block in
jedem System-Reminder.

### 3.6 Agent-Code (`agent/`)

Der **cortex-agent** ist ein Hermes-style Python-Loop, der lokal läuft
und Skills/Tools nutzen kann.

| Pfad | Zweck |
|---|---|
| `agent/cli.py` | Entry-Point für `cortex-agent`-Befehle. |
| `agent/loop.py` | Haupt-Loop (Iteration: Tool-Call → Result → Next-Step). |
| `agent/modes/` | Mode-Briefings (s.o.). |
| `agent/skills/builtin/` | Skills (Python-Funktionen). |
| `agent/cron/recipes/*.toml` | Cron-Job-Definitionen (Schedule, Befehl, Tier-3-Tokens). |
| `agent/cron/runner.py` | Cron-Executor. |
| `agent/connexio/` | Read-only-Kontextfläche (`task_store.py`, `inbox_notify.py`, `spawn_*.py`, `session_digest.py`, `lease_store.py`). |
| `agent/connexio_outbound/` | Outbound-Variante (Push-Pfad). |

### 3.7 Gateway (`gateway/`)

TypeScript/Bun-Server für externe Kanäle (Telegram, MCP).

| Pfad | Zweck |
|---|---|
| `gateway/src/` | Server-Source (Bun-Runtime). |
| `gateway/channels/telegram/channel.ts` | Telegram-Bridge V3 (passive/poll-Modus). |
| `gateway/channels/telegram/handlers/spawn.ts` | Verarbeitet eingehende `/spawn`-Befehle aus Telegram. |
| `gateway/lib/spawn-queue.ts` | TS-Anbindung an die Spawn-Queue-DB. |
| `gateway/.env` | Token-Datei (gitignored). Quelle für `TELEGRAM_BOT_TOKEN`, `TELEGRAM_ALLOWED_CHAT_IDS`. |
| `gateway/launchagents/` | Plist-Templates für den Bridge-Service. |

### 3.8 Mode-Hook (`tools/cortex-mode/`)

Das ist der **Kern der Mode-Steuerung**.

| Datei | Zweck |
|---|---|
| `tools/cortex-mode/bin/inject.sh` | Bash-Hook, der bei jedem `UserPromptSubmit` läuft. Liest State-File, kombiniert Mode-Datei + Tier-3-Datei, gibt JSON mit `additionalContext` aus. |
| `tools/cortex-mode/bin/local_first_discovery.py` | Ergänzt Kontext um Discovery-Hinweise, wenn Prompt nach Repos/Pfaden fragt. |
| `tools/cortex-mode/bin/lesson_audit.py` | Prüft am Welle-Ende, ob `WAS GELERNT`-Bullets Persistenz-Anker haben. |
| `tools/cortex-mode/bin/install_slash_commands.sh` | Installiert `/autonomy-mode`, `/safe-mode`, `/cortex-mode` lokal pro Mac. **Muss auf jedem Mac einmalig laufen.** |
| `tools/cortex-mode/commands-template/*.md` | Quellen für die Slash-Commands. |

Hook-Registration im User-Setting:
```json
"hooks": {
  "UserPromptSubmit": [{
    "matcher": "",
    "hooks": [{ "type": "command",
                "command": "bash $HOME/Cortex/Nexus/tools/cortex-mode/bin/inject.sh",
                "timeout": 10 }]
  }]
}
```

### 3.9 Sync-Layer (`nexus-sync.sh` + LaunchAgents)

| Datei | Zweck |
|---|---|
| `Nexus/nexus-sync.sh` | Auto-Sync-Skript. Pullt von GitHub, committed lokale Änderungen, pusht. Läuft alle 5 Min via LaunchAgent. |
| `Nexus/com.cortex.nexus-sync.plist` | LaunchAgent-Template (muss nach `~/Library/LaunchAgents/` kopiert werden). |
| `Nexus/com.cortex.nexus-sync-healthcheck.plist` | Healthcheck-Variante. |

### 3.10 Vault (Wissensbasis)

`~/Cortex/Nexus/Second Brain/` ist ein **Obsidian-Vault** mit dem
Stracke-Wissensgraph. Wichtig:

| Pfad | Zweck |
|---|---|
| `Second Brain/30 Tutorials/` | Single Source für Tutorials. Nach Domänen sortiert (Cortex & Nexus, Terminal, WordPress, Netzwerk & Sysadmin, …). |
| `Second Brain/30 Tutorials/Cortex & Nexus/` | Die Cortex-Selbst-Tutorials. Du liest gerade Nr. 14. |
| `Second Brain/30 Tutorials/_Basiswissen Schnelleinstieg.md` | Schnell-Einstieg. |
| `Second Brain/30 Tutorials/_MOC Tutorials.md` | Map of Content. |

### 3.11 Projekte (`Nexus/_projects/`)

| Datei | Zweck |
|---|---|
| `Nexus/_projects/INDEX.md` | Projekt-Tabelle (welche Projekte gibt es, Status, Owner). |

Die **Projekte selbst** liegen nicht in Nexus, sondern unter
`~/Cortex/projects/<projekt>/` (außer `Desk` und `Nexus`, die top-level
liegen).

### 3.12 Specs (`Nexus/specs/`)

Architektur-Specs für größere Entwürfe.

| Pfad | Inhalt |
|---|---|
| `specs/claude-codex-cooperation/00_KONZEPT.md` | Claude×Codex-Kooperation. |
| `specs/multi-device-multi-ai/00_KONZEPT.md` | Multi-Device + Multi-AI. |
| `specs/cortex-mesh/` | Tailscale-Mesh. |
| `specs/cortex-public-skeleton/00_KONZEPT.md` | Public-Slim-Variante für Sanexio-Ärztenetz. |
| `specs/local-first-discovery/00_KONZEPT.md` | Pflicht-Discovery vor Pfad-Annahmen. |
| `specs/architecture-refactor-2026-05/00_AUDIT.md` | Audit des aktuellen Phoenix-Stacks. |
| `specs/cortex-lean-v3/` | Lean-v3 (State-First, Connexio-Write-Surface). |

---

## 4. Mode-System (Autonomy vs. Safe)

### 4.1 Wie der Mode gesetzt wird

State-File: `~/.claude/state/cortex-mode.json`. JSON:
```json
{ "mode": "autonomy", "since": "2026-05-31T06:09:58Z",
  "host": "SSMD-MacBookPro-M5", "set_by": "slash-command" }
```

Geräte-lokal. **Nicht** synchronisiert über GitHub — jeder Mac entscheidet
für sich.

Setzen über Slash-Commands:
- `/autonomy-mode` → setzt auf `autonomy`.
- `/safe-mode` → setzt auf `safe`.
- `/cortex-mode` → zeigt aktuellen Mode.

Effekt greift ab dem **nächsten** Prompt, weil der Hook `inject.sh` erst
beim nächsten `UserPromptSubmit` liest.

### 4.2 Was die Modes konkret bewirken

**Autonomy (Default):**
- Aufgabe durchziehen, keine Pre-Op-Rückfragen.
- Welle-Ende: Debrief in den Blöcken `WAS GEMACHT` / `WAS GELERNT` / `STRATEGISCHE WAHLEN`.
- Stop nur bei: echter Ambiguität, Tier-3-Op, Token-Budget kritisch, Aufgabe erledigt.

**Safe:**
- 4-Phasen-Workflow: Verstehen → Plan → Approval-Gate → Umsetzen → Verifizieren.
- Phase-2-Gate erzwingt Stracke-OK vor jeder Phase-3-Umsetzung.
- Optionen-Listen erlaubt.

**Tier-3-Hardstops gelten in BEIDEN Modes** — siehe `agent/modes/tier3.md`.

### 4.3 Tier-3-Definition (extrem eng, Rev 2026-05-31)

**NUR EINE Kategorie**: Bank- und Bezahlinformationen mit
Echtgeld-Wirkung. Konkret:

- Schreibops in Accounting (SmartQ invoice/charge, Steuer-Submit,
  Banking-Transfer).
- Rechnungs-PDF-Versand an Patienten/Kunden (real money out).
- Preisänderungen in Live-Shops.
- Bank-API-Calls (Transfer, Lastschrift, Kreditkartenbelastung).
- Bezahl-CLI-Aufrufe (Stripe, PayPal, SEPA) mit Schreib-Effekt.

**Lesen** von Banking-Daten ist nicht Tier-3.

**Was zuvor Tier-3 war und jetzt FREI ist** (User-Direktive 2026-05-31):
- `.env`-Files (lesen/schreiben/überschreiben)
- `~/.claude.json`, API-Keys, Bot-Tokens
- SSH/GPG-Keys generieren/rotieren
- Keychain-Einträge
- E-Mail/Slack/SMS auch an Dritte (wenn Aufgabenkontext es vorsieht)
- PR-Merge auch in fremden Repos
- Alle Git-Operationen (push --force, reset --hard, rebase, branch -D)
- Live-Deploys eigener Projekte
- WP-Admin auf Stracke-Domains, Figma-Edits, Google-Drive-Ops

**Patient-Datenexport** ist nicht Tier-3, aber unterliegt der separaten
**DSGVO/Medical-Domain-Regel** in `_rules/medical-domain.md`.

Authoritative Datei: `agent/modes/tier3.md` (Rev 2026-05-31).

---

## 5. Memory-Layer (alle Stellen, an denen „Gedächtnis" lebt)

| Layer | Pfad | Persistenz | Wer schreibt? |
|---|---|---|---|
| **Claude Auto-Memory** | `~/.claude/projects/-Users-ssmd-Cortex/memory/*.md` | Geräte-lokal, session-übergreifend | Claude (von sich aus, regelbasiert). |
| **MEMORY.md Index** | `~/.claude/projects/-Users-ssmd-Cortex/memory/MEMORY.md` | s.o. | Claude. |
| **Nexus USER.md** | `Nexus/_memory/USER.md` | GitHub-synced | Stracke / Claude (manuell). |
| **Nexus KNOWLEDGE.md** | `Nexus/_memory/KNOWLEDGE.md` | GitHub-synced | s.o. |
| **Nexus golden-rules.md** | `Nexus/_memory/golden-rules.md` | GitHub-synced | s.o. |
| **memory.db** | `Nexus/_memory/memory.db` | Geräte-lokal (SQLite FTS5) | cortex-agent. |
| **spawn-queue.db** | `Nexus/_memory/spawn-queue.db` | Geräte-lokal | Gateway + cortex-agent. |
| **Connexio task store** | `Nexus/agent/connexio/tasks.db` (via `task_store.py`) | Geräte-lokal | cortex-agent + andere KIs. |
| **CLAUDE.md** | `Nexus/CLAUDE.md` | GitHub-synced, automatisch in Session | Stracke / Claude (R2, mit Freigabe). |
| **Hook-Injection** | nicht persistent — wird pro Prompt frisch erzeugt | — | `inject.sh`. |

**Faustregel:** Wenn etwas geräteübergreifend gelten soll, gehört es in
Nexus (GitHub-synced). Wenn nur lokal, in Claude-Auto-Memory oder eine
lokale DB.

---

## 6. Telegram-Bridge

Drei Pfade unterscheiden — das ist die Quelle der Mini-02-only-Drift:

**Pfad A — Outbound-Push** (Claude → Stracke):
- Code: `agent/connexio/session_digest.py:send_telegram()`.
- Voraussetzung: `TELEGRAM_BOT_TOKEN` und `TELEGRAM_ALLOWED_CHAT_IDS` in env oder `gateway/.env`.
- Trigger: muss **jemand** aufrufen — z.B. ein Cron-Job, ein Welle-Ende-Hook, oder das `connexio-inbox-notify`-Skript.
- **Status auf den meisten Macs:** Code da, aber niemand triggert.

**Pfad B — Bridge-Server (Inbound-Polling)** (Stracke → Claude via Telegram-Befehle):
- Code: `gateway/channels/telegram/channel.ts`.
- LaunchAgent: `com.cortex.telegram-bridge`.
- Modi: `passive` (nur MCP-Server, kein Polling) oder `poll` (aktives Polling auf Telegram-Updates).
- **Status auf M5:** Plist geladen, aber im `BRIDGE_MODE=passive`. Kein Inbound.

**Pfad C — Welle-Ende-Push (Claude-Code-Stop-Hook)**:
- Müsste in `~/.claude/settings.json` als `Stop`-Hook registriert sein, der `send_telegram()` aufruft.
- **Status:** Nirgendwo registriert — auch nicht auf Mini-02 (Vermutung).

**Mini-02-Sonderfall (Hypothese, lässt sich nur dort verifizieren):** Auf
Mini-02 läuft entweder die Bridge im non-passive-Mode, oder es gibt einen
zusätzlichen Cron-Job (`connexio-inbox-notify`-LaunchAgent), oder Stracke
hat dort einen Stop-Hook angelegt.

---

## 7. Sync-Mechanik

### 7.1 Automatischer Sync

`nexus-sync.sh` läuft alle 5 Min via LaunchAgent `com.cortex.nexus-sync`.
Was es tut:

1. **Pull** `git fetch origin main` + ff-merge auf main.
2. **Post-Pull-Bootstrap** (seit 2026-05-31, Block § 0.45): checkt, ob
   distribution-sensitive Files seit dem lokalen Bootstrap-Marker geändert
   wurden — wenn ja, ruft automatisch `install_bootstrap.sh` auf und
   publisht `refs/bootstrap-applied/<host>` (für das Health-Dashboard).
3. **Heartbeat** publisht `refs/heartbeats/<host>` (Last-Seen-Signal
   für andere Macs zur Sync-Koordination).
4. **Whitelist-Commit**: NUR Heartbeats, Sanitizer-Reports, Cron-Logs.
   **Inhaltliche Änderungen müssen IMMER manuell** `git add` + `commit`
   + `push` — `nexus-sync.sh` lässt sie ausdrücklich in Ruhe.
5. **Push** der eigenen Commits auf main.
6. **Bei Konflikt**: Auto-Rebase, bei echtem Konflikt → Stop + Telegram-
   Divergenz-Alarm.

Healthcheck via `com.cortex.nexus-sync-healthcheck.plist`. Drift-Warnung
via `check-nexus-drift.sh`-Stop-Hook (wenn ungetrackte inhaltliche Files
liegenbleiben).

### 7.2 Manueller Pre-Pull vor jedem Edit

Lean-v3-Regel **State-First**: vor jedem Schreib-Op:
```bash
cd ~/Cortex/Nexus && git pull --ff-only
```
und im Projekt analog. Bei Divergenz: **STOPP, melden, kein Edit**.

### 7.3 Sync für Projekte

Pro Projekt eigener Mechanismus. Die meisten Projekte haben einen eigenen
`*-sync.sh`-Konvergenz-Step. Pattern: `( cd "$target" && bash "$tool" )` —
nicht nackter Aufruf (Memory `feedback_converge_step_cwd_pattern`).

---

## 8. Multi-AI-Boundaries

**Wer darf wo schreiben?**

| Agent | `~/Cortex/Nexus/` | `~/Cortex/projects/<x>/` | Konkret |
|---|---|---|---|
| Stracke | frei | frei | Source of all authority. |
| Claude | R2 (mit Freigabe) | R1 (frei sofern Git sauber) | Schreibrecht auf Nexus, aber Tier-3 stoppt. |
| Codex | R2 (Vorschlag only) | R1 (frei) | Nexus nur über `_ai-cooperation-outbox/` oder Connexio-`handoff_to_agent`. |
| Cursor/Cline/Continue/Gemini-CLI | **verboten** | R1 (frei) | Workspace muss mit Projekt-Wurzel öffnen, nie mit `~/Cortex/`. |

Boundary v2 seit 2026-05-12, autoritativ in `_rules/multi-ai-boundaries.md`.

---

## 9. Wichtige Standard-Befehle

```bash
# Mode anzeigen / setzen
cortex-agent mode get
cortex-agent mode set autonomy
cortex-agent mode set safe

# Skills
cortex-agent skill list
cortex-agent skill run <name> [--args '{}']

# Memory
cortex-agent memory search "<query>"
cortex-agent memory facts
cortex-agent memory add-fact <kind> <key> <value>

# Bootstrap (zeigt Mode + User + Skills + Block-Größe)
cortex-agent bootstrap

# Cortex-Agent eine Loop-Iteration
cortex-agent run "<prompt>"     # braucht ANTHROPIC_API_KEY

# Telegram-V3 standalone
cd ~/Cortex/Nexus/gateway && bun run telegram
```

Slash-Commands (in Claude Code):
- `/autonomy-mode` `/safe-mode` `/cortex-mode`
- `/spawn` (Codex/Claude-Aufgabe absetzen)
- `/init`, `/review`, `/security-review`, `/loop`, `/schedule`

---

## 10. Was beim Mac-Onboarding zu tun ist

Wenn ein neuer Mac dazukommt:

1. Tailscale installieren, auth, in Tailnet aufnehmen.
2. `git clone Sanexio/nexus ~/Cortex/Nexus`.
3. `~/Cortex/Nexus/tools/cortex-mode/bin/install_slash_commands.sh` ausführen (Slash-Commands lokal anlegen).
4. `~/.claude/settings.json` Hook-Block hinzufügen (s. Abschnitt 3.8).
5. `nexus-sync.sh`-LaunchAgent kopieren: `cp ~/Cortex/Nexus/com.cortex.nexus-sync*.plist ~/Library/LaunchAgents/ && launchctl load …`.
6. `gateway/.env` mit Telegram-Tokens befüllen.
7. Telegram-Bridge-Plist (siehe `gateway/launchagents/`) lokal aktivieren.
8. `devices.json` um den neuen Mac ergänzen.
9. `cortex-agent bootstrap` testen.
10. `/autonomy-mode` und einen Test-Prompt absetzen, prüfen ob der Hook injiziert.

**Aktuelle Lücke:** Schritt 4 und 5+6 sind nicht in einem
`install_bootstrap.sh` automatisiert. Sollte gebaut werden.

---

## 11. Häufige Drift-Quellen (aus Erfahrung)

| Symptom | Ursache | Fix |
|---|---|---|
| „Autonomy greift nicht" | Hook nicht in `~/.claude/settings.json` registriert | Hook-Block einfügen (s. 3.8). |
| „Unknown command: /autonomy-mode" | Slash-Commands nicht lokal installiert | `install_slash_commands.sh` laufen lassen. |
| „Mode-File fehlt" | State-File ist nicht da | Hook erzeugt es bei nächstem Prompt automatisch (Auto-Init). |
| „Telegram-Push kommt nicht" | Kein aktiver Trigger auf diesem Mac | LaunchAgent für `connexio-inbox-notify` registrieren ODER Bridge in poll-Mode. |
| „Anderer Mac sieht meinen Commit nicht" | `nexus-sync.sh`-LaunchAgent läuft nicht | `launchctl list \| grep nexus-sync` prüfen. |
| „Codex sieht meinen Task nicht" | `inbox_notify`-Cron läuft nicht | Plist registrieren. |
| Repo-Pfad falsch angenommen | Local-First-Discovery übersprungen | `specs/local-first-discovery/00_KONZEPT.md` § 2 — Stufen 1–6 abarbeiten. |
| BSD-sed-Treffer leer | macOS-`sed` kennt `\b` nicht | Python-Skript statt sed, oder lange Patterns ohne Wortgrenzen. |
| `git pull` schlägt fehl | `/etc/hosts` enthält alten Hostnamen als `127.0.0.1` (nach Apple-Migration) | `/etc/hosts` säubern. |

---

## 13. Updates 2026-05-31 — Distribution-Guards + Self-Heal-Verteilung

Diese Welle hat die Multi-Mac-Drift strukturell gefixt. Vorher musste
Stracke nach jeder Skript-Änderung auf jedem Mac manuell `bootstrap`
anstoßen — jetzt selbstheilend.

### 13.1 Mode-Hooks in Claude Code (live auf jedem Mac)

| Hook | Skript | Zweck |
|---|---|---|
| `UserPromptSubmit` | `tools/cortex-mode/bin/inject.sh` | Injiziert Mode-Briefing + Tier-3 in jeden Prompt. |
| `PreToolUse` | `tools/cortex-mode/bin/auto_allow.py` | Auto-Allow für Tier-1, „ask" nur bei Tier-3-Bash-Pattern. |
| `Stop` | `tools/cortex-mode/bin/wave_end_push.py` | Telegram-Push am Welle-Ende + WARN wenn Distribution-Files berührt ohne Plan. |

Registriert in `~/.claude/settings.json` pro Mac via `install_w1_hooks.sh`
(idempotenter Backup-Updater).

### 13.2 Distribution-Guards (Git-Hooks in `tools/cortex-mode/git-hooks/`)

Erzwingen, dass keine distribution-sensitive Änderung unbemerkt durchrutscht.

| Hook | Skript | Wirkung |
|---|---|---|
| `pre-commit` | `pre-commit-distribution.sh` | Soft-Warnung wenn distribution-Files staged. |
| `commit-msg` | `commit-msg-distribution.sh` | **HARD REJECT** wenn Commit-Msg keinen `Distribution: auto|manual:<reason>|n/a`-Block hat. |
| `pre-push` | `pre-push-distribution.sh` | **HARD REJECT** wenn distribution-Files gepusht werden ohne aktuellen Test-Marker (= `bash tools/cortex-mode/bin/test-bootstrap.sh` wurde gegen aktuelle Working-Tree-Files gelaufen). |

Single-Source der Pfade: `tools/cortex-mode/git-hooks/_distribution_paths.{sh,py}`.
Distribution-Block-Bedeutung:
- `Distribution: auto` — Verteilung läuft automatisch via `nexus-sync.sh` Post-Pull-Hook.
- `Distribution: manual: <Begründung>` — Andere Macs brauchen manuellen Eingriff.
- `Distribution: n/a` — Datei wirkt nur lokal.

Installation pro Mac via `install_bootstrap.sh` Schritt 7 (Wrapper in `.git/hooks/`).

### 13.3 Self-Heal-Verteilung (`nexus-sync.sh` § 0.45)

Nach jedem Pull checkt `nexus-sync.sh` per `git log -1 --format=%H -- <distribution-paths>`,
ob bootstrap-relevante Files sich seit dem letzten Lauf geändert haben.
Wenn ja: ruft `install_bootstrap.sh` mit `BOOTSTRAP_SKIP_NEXUS_SYNC=1`
(Self-Reload-Schutz), schreibt lokalen Marker `_memory/.bootstrap-state.json`
und publisht `refs/bootstrap-applied/<host>` (für Dashboard).

**Verteilungs-Latenz nach `git push` von M5:** 0–5 Min Pull auf jedem Mac,
0–5 Min nächster Tick mit neuem Skript, bootstrap automatisch. Worst-case
10 Min — ohne menschliche Intervention.

### 13.4 Health-Dashboard

`agent/skills/builtin/bootstrap_health_dashboard.py` (Skill):
- Liest `refs/bootstrap-applied/*` aller Macs + `refs/heartbeats/*`.
- Vergleicht jeden Mac gegen aktuellen distribution-commit.
- Telegram-Push bei Drift > 1 h.
- Cron: `agent/cron/recipes/bootstrap-health-dashboard.toml`, daily 07:00.
- Singleton via `host_filter` (cluster-mini-02).
- Manuell: `cortex-agent skill run bootstrap-health-dashboard --args '{"dry_run":true}'`.

Plus: `doctor.py` hat neuen Check `_check_bootstrap_drift` (RED-Status
+ Marker-Hash vs. distribution-commit-Hash).

### 13.5 Tier-3-Reduktion (siehe Abschnitt 4.3)

3 Kategorien → 1 Kategorie. Nur noch Bank/Bezahl mit Echtgeld-Wirkung
bleibt Hardstop. Live im `auto_allow.py`-Pattern reduziert.

### 13.6 Wichtige Pfade — Update der Tabelle in Abschnitt 1

Zusätzlich zu den Pfaden in Abschnitt 1 jetzt relevant:

| Was | Pfad |
|---|---|
| **PreToolUse-Auto-Allow-Hook** | `Nexus/tools/cortex-mode/bin/auto_allow.py` |
| **Stop-Telegram-Push-Hook** | `Nexus/tools/cortex-mode/bin/wave_end_push.py` |
| **W1-Hook-Installer** | `Nexus/tools/cortex-mode/bin/install_w1_hooks.sh` |
| **Bootstrap-Single-Shot-Setup** | `Nexus/tools/cortex-mode/bin/install_bootstrap.sh` |
| **Bootstrap-Test (für Pre-Push)** | `Nexus/tools/cortex-mode/bin/test-bootstrap.sh` |
| **Distribution-Hook-Skripte** | `Nexus/tools/cortex-mode/git-hooks/` |
| **Distribution-Paths Single-Source** | `Nexus/tools/cortex-mode/git-hooks/_distribution_paths.{sh,py}` |
| **Bootstrap-Health-Skill** | `Nexus/agent/skills/builtin/bootstrap_health_dashboard.py` |
| **Bootstrap-Marker (pro Mac)** | `Nexus/_memory/.bootstrap-state.json` (gitignored) |
| **Bootstrap-Test-Marker (pro Mac)** | `Nexus/_memory/.last-bootstrap-test.json` (gitignored) |
| **Bootstrap-Applied-Refs (multi-mac)** | `refs/bootstrap-applied/<host>` (ephemerer Git-Ref) |
| **Health-Dashboard-Plist** | `Nexus/com.cortex.bootstrap-health-dashboard.plist` |
| **Health-Dashboard-Recipe** | `Nexus/agent/cron/recipes/bootstrap-health-dashboard.toml` |
| **Konzept Auto-Execution** | `Nexus/specs/claude-codex-autonomous-execution/00_KONZEPT.md` |
| **Manifest-Schema** | `Nexus/specs/claude-codex-autonomous-execution/01_MANIFEST_SCHEMA.md` |
| **Decomposer-Skill** | `Nexus/agent/skills/builtin/decompose_project.py` |

### 13.7 Onboarding-Diff zu Abschnitt 10

Schritte 4–6 (Hook-Eintrag, LaunchAgents kopieren, Bridge-Plist anlegen)
sind alle in `install_bootstrap.sh` konsolidiert. Neuer Mac → einmal:

```bash
git clone git@github.com:Sanexio/nexus.git ~/Cortex/Nexus
bash ~/Cortex/Nexus/tools/cortex-mode/bin/install_bootstrap.sh
```

Danach: self-heal-Modus aktiv, Stracke muss nie wieder pro Mac etwas tun.

---

## 14. Wo dieses Tutorial endet

Dieses Tutorial ist **deskriptiv**, kein normatives Dokument. Wenn etwas
zwischen diesem Tutorial und `_rules/*.md` widerspricht, **gewinnen die
`_rules/`** (single source of truth). Dieses Tutorial wird bei größeren
Architektur-Änderungen aktualisiert.

**Querverweise:**
- Architektur: `01-architektur-und-philosophie.md`
- Multi-Device-Setup: `02-multi-device-setup.md`
- Memory-Layer Detail: `03-memory-layers.md`
- Trust-Tiers: `04-trust-tiers-und-autonomie.md`
- Phoenix-Stack: `08-phoenix-stack.md`
- Telegram-Bot: `09-cortex-bot-telegram.md`
- Sync Detail: `13-verbindungen-und-synchronisation.md`
