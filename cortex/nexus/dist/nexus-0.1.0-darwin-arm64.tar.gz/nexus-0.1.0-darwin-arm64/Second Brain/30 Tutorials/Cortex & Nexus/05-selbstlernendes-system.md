---
type: tutorial
aliases: [Selbstlernendes System, Fehler-Loop, Lernen aus Fehlern, Pattern-Loop, FEHLERPROTOKOLL]
tags:
  - tutorial
  - cortex
  - nexus
  - lernen
  - patterns
  - regeln
source: Second Brain/30 Tutorials/Cortex & Nexus/05-selbstlernendes-system.md
---

# 05 — Selbstlernendes System

> Voraussetzung: [[Cortex & Nexus/01-architektur-und-philosophie]] gelesen.
> Lesezeit: ~15 Min.
> Ziel: Du verstehst, warum jeder Fehler im System einen festen Loop durchläuft,
> wie aus einer einmaligen Erfahrung eine dauerhafte Regel wird und warum
> Tutorials Teil dieses Loops sind, nicht nur Lehrmaterial.

---

## 1. Warum überhaupt ein Lern-Loop?

Ohne Mechanismus verschwindet jede Erkenntnis: Heute lernt man, dass apoBank
keine GKV-Erlöse enthält (LL-017). Drei Monate später hat man's vergessen, baut
die CashFlow-Analyse falsch, sucht stundenlang den Fehler.

Der Lern-Loop ist die Antwort: **jeder Fehler wird zu einem Eintrag, der in
zukünftigen Sessions automatisch gelesen wird.** Damit verhindert das System,
dass dieselben Fehler zweimal Reibung erzeugen.

Die Goldenen Regeln in `MEMORY.md` machen es zur **harten Pflicht**, diesen
Loop nach Sessions auszuführen.

---

## 2. Der 5-Schritte-Loop

Nach jeder Session, die einen Fehler aufdeckt oder neue Erkenntnisse bringt:

| # | Schritt | Wo | Wer |
|:---:|---|---|---|
| 1 | **Fehler dokumentieren** | `_rules/FEHLERPROTOKOLL.md` (global) oder `<projekt>/_config/FEHLERPROTOKOLL.md` | Claude in „Session beenden" |
| 2 | **Regel ableiten** | `_rules/GLOBAL_RULES.md` (`LL-XYZ`) oder projekt-`RULES.md` | Claude — neue LL-Nummer |
| 3 | **Tool verbessern** | `_lib/<bereich>/` | Claude — Code-Update |
| 4 | **Tutorial aktualisieren** | `Second Brain/30 Tutorials/<Domäne>/` | Claude proaktiv (LL-022) |
| 5 | **Pattern extrahieren** | `_memory/patterns/<name>.md` | Claude — wenn Pattern wiederholbar |

**Merksatz:** Ein guter Loop deckt alle fünf ab. Ein schlechter Loop endet bei
Schritt 1 — der Fehler steht im Protokoll, aber nichts ändert sich.

---

## 3. Die fünf Schritte im Detail

### 3.1 Fehler dokumentieren

Das `FEHLERPROTOKOLL.md` enthält pro Eintrag:
- **Kurztitel** + ID (z.B. `LL-017`)
- **Was war der Fehler?** (Symptom + Diagnose)
- **Wie wurde er gefunden?**
- **Welche Regel folgt daraus?**
- **Welcher Code/Tool wurde angepasst?**

Die ID wird zur **Referenz** in MEMORY.md, in Tutorials und in Pattern-Files.
Damit ist jeder Eintrag rückwärts auffindbar.

### 3.2 Regel ableiten

Aus dem Fehler wird eine Regel in `GLOBAL_RULES.md`:

```markdown
## LL-017 — apoBank-Auszüge enthalten keine GKV-Erlöse

KV Hessen zahlt separat (separate Banking-Auszüge). Wenn apoBank-CashFlow
ohne KV-Daten kategorisiert wird, fehlen ~70% der Praxis-Einnahmen.

**Regel:** Bei jeder CashFlow-Analyse explizit prüfen, ob KV-Hessen-Daten
ergänzt werden müssen. Im Tool: Warnung, wenn ein Quartal komplett ohne
GKV-Erlöse erscheint.
```

LL-Nummern werden fortlaufend vergeben (aktuell bis LL-055). Sie sind
**stabile** Anker — keine Umbenennung, kein Renumbering.

### 3.3 Tool verbessern

Wenn der Fehler durch ein Tool besser verhindert werden könnte, gehört der
Code-Fix in `_lib/`. Beispiele:

- LL-013 (Absender-Dopplung) → `_lib/rename/rename_utils.py` extrahiert Vendor
  und prüft auf Doppel-Match.
- LL-020 (Vendor-Kategorien) → `_lib/steuer/cashflow_categorize.py` persistiert
  Vendor-Mapping in JSON, lernt mit jeder Session.
- LL-029 (Avatar-Body-Hard-Guards) → Blender-Script enforced `Y >= NECK_Y` und
  `|X| > BODY_X_MAX` als Code-Garantie.

**Grundsatz:** Tools wiederverwenden, nie neu schreiben. Wenn ein Tool fehlt,
liegt es in `_lib/<bereich>/`. Wenn es nicht da ist, anlegen — nicht inline
duplizieren.

### 3.4 Tutorial aktualisieren

LL-022: **Tutorials proaktiv ergänzen.** Wenn ein neuer Befehl, ein neues
Konzept oder ein neuer Workflow auftaucht, fließt es in die passende
Tutorial-Domäne ein, ohne dass Du danach fragen musst.

Single Source: `Second Brain/30 Tutorials/<Domäne>/`. Die Domänen wachsen
**organisch** (LL-035) — neue Hierarchien werden eigenständig gewählt
(LL-041), wenn der Bedarf da ist.

### 3.5 Pattern extrahieren

Ein **Pattern** ist eine wiederholbare Lösung, die in mehr als einem Projekt
nützlich wird. Beispiele:

| Pattern | Wo es greift |
|---|---|
| `session-archive-sliding-window` | LL-053-Memory-Layers, in jedem Projekt |
| `self-regulating-token-budget` | Cortex-Sanitizer-Mechanismus |
| `holistic-system-priority` | CW-PRIO-001, P1–P5 Prio-Leiter |
| `sub-agent-delegation` | Sprint D3 — wann Sub-Agents nutzen |
| `auto-related-page-grid` | Cortex-Web S50, automatische Detail-Page-Verlinkung |

Patterns leben in `Nexus/_memory/patterns/<name>.md`. Sie ergänzen Regeln um
**Implementierungs-Anleitungen**.

---

## 4. Wann läuft der Loop?

Der Standard-Befehl **„Session beenden"** triggert den Loop:

| Schritt | Aktion |
|:---:|---|
| 1 | Projekt-Audit (offene Punkte, Lessons Learned) |
| 2 | Nexus-Audit (FEHLERPROTOKOLL, GLOBAL_RULES Updates) |
| 3a | Sanitizer-Probe (LL-053b) |
| 3b | Pattern-Extraktion (falls wiederholbar) |
| 3c | Sliding-Window-Rotation (LL-053a) |
| 4 | Tutorial-Update |
| 5 | `SESSION_RESUME.md` finalisieren |
| 6 | Dashboard-Ausgabe |

**Wichtig:** Bei jeder Hauptaufgabe wird Claude proaktiv „Session beenden"
anbieten. Das ist nicht Höflichkeit, sondern Mechanik — ohne den Workflow
verrottet die Memory-Disziplin.

---

## 5. Das Selbstlern-Layer der Tools

Manche Tools haben einen eigenen Selbstlern-Modus, der **innerhalb** des
großen Loops läuft:

### Cortex-Sanitizer (`Nexus/tools/cortex-sanitizer/`)

- `--probe` → Routinecheck (Soft-Warn)
- `--apply` → Auto-Rotation (V4)
- `--enforce` → Hardgate (V5.3, LL-053b)
- `--learn` → Trend-Logging in `logs/growth.jsonl`

Der `--learn`-Modus appended pro überwachter Datei eine Zeile mit Zeitstempel,
Bytes, Tokens, Status. Über Wochen sichtbar: welche Datei wächst wie schnell —
ein Frühwarnsystem für strukturelle Probleme.

### Memory-Nudge (`Nexus/tools/memory-nudge/`)

Ein stündlicher Cron prüft, ob neue Lessons in den Sessions auftauchen, die
noch nicht ins Protokoll gewandert sind. Offene Nudges landen in
`tools/memory-nudge/trigger.md` und werden bei jedem Sessionstart
gegengelesen (LL-054).

### Vault-Audit (`Nexus/tools/vault-audit/`)

`vault_audit.py` prüft den Obsidian-Vault auf Inkonsistenzen (tote Links,
fehlende MOC-Anker, Stale-Refs). `inject_moc_links.py` erneuert die
Wiki-Link-Indizes der Domänen, damit der Obsidian-Graph alle Tutorials einer
Domäne als einen Cluster zeigt.

### Tutorial-Curator (`Nexus/tools/tutorial-curator/`) — seit Sprint F2 Welle D, 2026-05-06

Deterministischer Drift-Detektor speziell für `Second Brain/30 Tutorials/`.
Komplementär zu Cortex-Curator (LLM-getrieben, oben) — Tutorial-Curator ist
regelbasiert und braucht **keinen API-Key**:

- **`check-numbering.py`** — Numerierungs-Konflikte (zwei Files mit gleichem
  `XX-`-Präfix in derselben Domain).
- **`check-moc-drift.py`** — `_MOC Tutorials.md` Modul-Counts vs.
  Filesystem-Realität.
- **`check-orphans.py`** — Tutorial-Files ohne Verweis aus
  `_MOC`/`Grundlagen`/`LERNPFAD`.
- **`check-broken-links.py`** — Wikilink-Targets ohne existierendes File
  (mit Härtung gegen POSIX-Char-Klassen `[[:space:]]`, Code-Fences,
  Tabellen-Pipe-Escapes).
- **`mark-sprint-specific.py`** — Heuristische Domain-Misfit-Erkennung
  über konfigurierbare Keyword-Liste (`blocksy`, `wpml`, `praxiszentrum`
  etc. → WordPress-Domain).

Output landet als idempotenter Marker-Block in `_memory/curator-queue.md`
neben Cortex-Curator-Vorschlägen. Stable-IDs (`TUT-<sha1-12>`) sorgen dafür,
dass derselbe Befund zweimal nicht doppelt in der Queue landet.

**Anlass:** Sprint F2 Welle A+B+C (Tutorial-Reorg, 33→12+22 Module) wurde
manuell als „clean" deklariert. Tutorial-Curator fand danach trotzdem 2
Orphans + 25 Broken Wikilinks — alle echte Drift, vom manuellen Audit
übersehen. Lernsatz für künftige Reorgs: **Manuelles Auditing übersieht
~50 % der Drift-Stellen, deterministische Tools sind unverzichtbar.**

Cron: `tools/cortex-cron/recipes/tutorial-drift.md` + LaunchAgent
`com.cortex.tutorial-drift.plist` (täglich 04:00).
Pattern: `_memory/patterns/deterministic-vs-llm-curator-coexistence.md`
(Trennung der Zuständigkeiten + Marker-Block-Idempotenz).

---

## 6. Konkretes Beispiel — von Fehler zu Regel

**Anlass (2026-04-25):** Auf SSMD-MacBookPro hat Claude eigenmächtig
`git rebase --skip` ausgeführt, um einen Konflikt zu umgehen. Folge: Commit
verloren, manuelle Rekonstruktion nötig.

**Loop:**

1. **Fehler** → `FEHLERPROTOKOLL.md`: „Destruktive Git-Op ohne Freigabe."
2. **Regel** → `GLOBAL_RULES.md §27` als **LL-050**: alle destruktiven Git-Ops
   (`rebase --skip/--abort`, `reset --hard`, `push --force`, `clean -fd`,
   `branch -D`, `stash drop/clear`, `filter-branch`, `rm -rf .git*`) brauchen
   Freigabe — auch in Tier 1.
3. **Tool** → `~/Cortex/.claude/settings.local.json` bekommt `deny`+`ask`-Patterns;
   Vorlage in `Nexus/.config/settings-git-deny-snippet.json` für andere Geräte.
4. **Tutorial** — kein eigenes Modul nötig; Verweis in
   [[Cortex & Nexus/04-trust-tiers-und-autonomie]] und [[Git Grundlagen]].
5. **Pattern** — kein eigenständiges Pattern (Regel reicht).

**Ergebnis:** Vier Tage später (2026-04-29) wird LL-055 (Trust-Tiers)
eingeführt; LL-050 wird explizit als „Vorrang in allen Tiers" markiert. Der
ursprüngliche Vorfall ist Teil der Begründung, warum die Tier-1-Vollautonomie
**nicht** zum Freibrief wird.

---

## 7. Designgrundsätze

- **Eine Erkenntnis = ein Eintrag, eine ID, eine Stelle.** Single Source of
  Truth gilt auch für Lehren.
- **Tutorials sind Teil des Loops, nicht Lehrmaterial nebenher.**
  LL-022 macht das proaktiv.
- **Tools-Verbesserung schlägt manuelle Disziplin.** Wo möglich, automatisieren.
- **Patterns sind die Brücke zwischen Regel und Praxis.** Eine Regel sagt was
  zu tun ist; ein Pattern zeigt **wie**.

---

## 8. Wo geht's weiter?

- **FEHLERPROTOKOLL:** `Nexus/_rules/FEHLERPROTOKOLL.md`
- **Globale Regeln:** `Nexus/_rules/GLOBAL_RULES.md` (LL-001 bis LL-055+)
- **Pattern-Katalog:** `Nexus/_memory/patterns/` (50+ Patterns)
- **Memory-Layers** (Schicht-für-Schicht-Cap): [[Cortex & Nexus/03-memory-layers]]
- **Trust-Tiers** (Autonomie-Stufen): [[Cortex & Nexus/04-trust-tiers-und-autonomie]]
- **Architekten-Modus** (4 Phasen, in dem der Loop eingebettet ist):
  [[Arbeitsweise & Prozess/01-architekten-modus]]
- **Memory-Disziplin im Detail:** [[Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme]]
