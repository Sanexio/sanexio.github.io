---
type: tutorial
aliases: [Memory-Layers, Hot Warm Cold, Token-Budgets, Sliding-Window, LL-053]
tags:
  - tutorial
  - cortex
  - nexus
  - memory
  - ll-053
source: Second Brain/30 Tutorials/Cortex & Nexus/03-memory-layers.md
---

# 03 — Memory-Layers (Hot/Warm/Cold)

> Voraussetzung: [[Cortex & Nexus/01-architektur-und-philosophie]] gelesen.
> Lesezeit: ~20 Min · Detail-Bezug: [[Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme]].
> Ziel: Du verstehst, warum `SESSION_RESUME.md` ein Hardcap hat, was Sliding-Window
> bedeutet und warum „Cold-Archiv" der entscheidende Schutz vor Memory-Bloat ist.

---

## 1. Das Problem, das LL-053 löst

Memory-Dateien wachsen linear mit jeder Session. Niemand löscht proaktiv. Drei
Wachstumsmechanismen kommen zusammen:

1. **Session-Logs in Indices** — jede Session hängt einen „Vorher: Session X …"-Absatz
   an die Aktive-Projekte-Tabelle. Nach 15 Sessions ist eine Tabellenzelle 15 KB groß.
2. **§3-legacy-Stapel in `SESSION_RESUME.md`** — jeder Session-Ende-Workflow
   hinterlässt einen Legacy-Block. Sie stapeln sich.
3. **Sprint-Logs in `CLAUDE.md`** — Projekt-Abschnitte wachsen mit jeder Sprint-Session.

**Reale Folge:** Cortex-Web-`SESSION_RESUME` wuchs trotz V5-Sanitizer auf
**27 k Read-Tokens** (Session 50, 2026-04-28). Das übersteigt das Read-Limit;
Claude konnte den eigenen Init-Kontext nicht mehr vollständig einlesen.

LL-044 (Token-Budgets, 2026-04-22) war eine Soll-Regel ohne Mechanismus.
**LL-053 (2026-04-28) liefert den Mechanismus** — und genau diesen erklärt
dieses Modul.

---

## 2. Drei Schichten, drei Fragen

| Schicht | Beantwortet die Frage… | Typischer Ort | Cap | Lade-Regel |
|---|---|---|:---:|---|
| **HOT** | „Was tue ich gerade?" | `SESSION_RESUME.md` · `MEMORY.md` · `GLOBAL_RULES.md` · `CLAUDE.md` | siehe §4 | **immer** beim Sessionstart |
| **WARM** | „Welche Sessions gab es?" | `<projekt>/SESSION_INDEX.md` (eine Tabelle) | ≤ 5 k | beim Sessionstart, kompakt |
| **COLD** | „Was passierte konkret in Session X?" | `_archive/sessions/YYYY-MM/session-XX-<slug>.md` | unbegrenzt | **nur on-demand** |

**Merksatz:** HOT ist Arbeitstisch, WARM ist Inhaltsverzeichnis, COLD ist
Archivkeller. Du gehst nur in den Keller, wenn Du eine konkrete alte Akte
brauchst.

---

## 3. Die vier Mechanismen von LL-053

### 3.1 Sliding-Window-Auto-Archive (LL-053a)

Bei „Session beenden" rollt die **vorletzte** Session (`N-2`) automatisch ins
Cold-Archive. Im `SESSION_RESUME.md §3` bleiben **immer nur** die aktuelle
Session (`N`) und die vorherige (`N-1`) als Detail-Block. Alles ältere wird
zu **einer Zeile** im `§1.0`-Index.

> [!info] Warum N-2 und nicht N-3?
> N-1 wird häufig konsultiert für „was hatten wir gestern?". Sliding bei N-2
> hält das Resume schlank, ohne den Vortag-Kontext zu verlieren.

**Bündel-Ausnahme:** Wenn `N-2` zu einem Sprint zusammen mit `N-3`, `N-4` etc.
gehört (gleicher Tag), gehen sie als Bündel ins Cold (z.B.
`sessions-43-46-catch-up.md` für vier Sessions an einem Sonntag).

### 3.2 Sanitizer-Hardgate (LL-053b)

`Nexus/tools/cortex-sanitizer/rotate.sh --enforce` ist Pflicht-Schritt vor
jedem Commit einer überwachten Datei. Bei Cap-Verletzung: **Exit 1** —
nicht nur Warnung. Der „Session beenden"-Workflow stoppt, bis die Verletzung
behoben ist.

| Modus | Zweck | Exit-Verhalten |
|---|---|---|
| `--probe` | interaktive Inspektion (Soft-Warn) | Exit 0 auch bei Verletzung |
| `--enforce` | Commit-Vorbedingung (Hardgate) | **Exit 1** bei jeder roten Zelle |
| `--learn` | Logging für Trend-Daten | Exit 0 immer |

### 3.3 Lazy-Read-Marker (LL-053c)

Hot-Files dürfen Cold-Inhalte **niemals duplizieren**, nur referenzieren:

```
S45 (PXZ 2.7.52/53, Room-Slider Zweigpraxis) → [archiv:2026-04/session-45]
```

Claude liest das Cold-Archiv **nur**, wenn die aktuelle Aufgabe sich konkret
auf diese Session bezieht (Begründungs-Frage, Diff-Vergleich, Regression-
Investigation). Default: Lazy.

**Anti-Pattern:** Detail-Chronik halb in `§3-legacy-XX` (Hot) und halb in
Cold-File. Eine Quelle, ein Pfad.

### 3.4 Single-Source-Pflicht (LL-053d)

Jede Information lebt an genau **einer** Stelle. `SESSION_RESUME.md` ist
Index + aktueller Stand + Pre-Flight-Befehle + harte Regeln, **nicht** Geschichte.
Geschichte gehört ins Cold-Archiv.

---

## 4. Token-Caps (LL-053-Update zu LL-044)

| Datei | Cap (Tokens) | Schicht | Begründung |
|---|:---:|:---:|---|
| `Nexus/CLAUDE.md` | 12 k | HOT | jeder Sessionstart → primärer Init-Kontext |
| `Nexus/_memory/MEMORY.md` | 10 k | HOT | Projekt-Index + Top-Fehler + Goldene Regeln |
| `Nexus/_rules/GLOBAL_RULES.md` | 12 k | HOT | LL-001 bis LL-055+ |
| `Nexus/_rules/SESSION_LIFECYCLE.md` | 8 k | HOT | Standard-Befehle |
| `Nexus/_rules/MEMORY_LAYERS.md` | 6 k | HOT | diese Spec |
| `<projekt>/SESSION_RESUME.md` | **12 k** (von 15 k reduziert) | HOT | nur Index + N + N-1 detailliert |
| `<projekt>/SESSION_INDEX.md` | 5 k | WARM | reine Tabelle, eine Zeile pro Session |
| `<projekt>/_archive/sessions/YYYY-MM/*.md` | unbegrenzt | COLD | Detail-Chroniken |

**Verschärfung gegen LL-044:**
- Resume-Cap **15 k → 12 k** (war zu großzügig — hat zum 27 k-Vorfall geführt)
- Neue HOT-Caps für `_rules`-Files
- Neuer WARM-Cap für `SESSION_INDEX.md`

---

## 5. SESSION_INDEX.md — die Warm-Schicht

Pro Projekt eine Datei `<projekt>/SESSION_INDEX.md` mit folgender Struktur:

```markdown
# SESSION_INDEX — <Projekt>

> Auto-generiert von `Nexus/tools/session-index/build.sh`.

| ID | Datum | PXZ | Slug | Theme-Commit | Archiv |
|:---:|:---:|:---:|---|:---:|---|
| S50 | 2026-04-28 | 2.7.73 | Sanexio-Detail-Page-Mirror | `52cc942` | [→](_archive/sessions/2026-04/session-50-sanexio-detail-mirror.md) |
| S49 | 2026-04-27 | 2.7.72 | Sanexio-Spiegel-Umbau | `90fc4db` | [→](_archive/sessions/2026-04/session-49-sanexio-spiegel.md) |
```

**Felder:** `ID` · `Datum` · `PXZ` (Theme-Version) · `Slug` (≤ 60 Zeichen) ·
`Theme-Commit` · `Archiv` (Markdown-Link ins Cold-File).

**Generator:** `Nexus/tools/session-index/build.sh <projekt-pfad>` durchsucht
`_archive/sessions/`, extrahiert Frontmatter, schreibt die Tabelle. Wird im
„Session beenden"-Workflow (Schritt 3c) automatisch aufgerufen.

---

## 6. Der Git-Trick mit `_archive/`

Wenn der Parent-Ordner in `.gitignore` steht, können Kinder **nicht** per
`!`-Exception re-included werden. Lösung: Parent als Wildcard ignorieren,
dann greifen Exceptions:

```gitignore
# Vorher (falsch):
_archive/
!_archive/sessions/      ← greift NICHT

# Nachher (richtig):
/_archive/*
!/_archive/sessions/
!/_archive/sessions/**
sites/*/_archive/        ← Sub-Projekt-Archive bleiben ignoriert
```

---

## 7. Warum nicht einfach LL-044 verschärfen?

LL-044 sagt nur „Budget einhalten" — eine Soll-Regel ohne Mechanismus.
LL-053 liefert vier Mechanismen, die einander ergänzen:

- **Auto-Archive** löst das Problem ohne Aufwand pro Session (Sliding-Window)
- **Hardgate** macht Verletzung unmöglich (nicht nur unangenehm)
- **Lazy-Read** hält den Init-Speicher klein (Cold ist nie geladen)
- **Single-Source** verhindert Drift, durch die `§1.0`-Index und `§3-legacy`
  heute teilweise dieselbe Information halten

LL-053 ersetzt LL-044 nicht, sondern **operationalisiert** es.

---

## 8. Pilot-Effekt (Session 51, Cortex-Web)

Erste Anwendung am 2026-04-28:
- `SESSION_RESUME` −16,5 % Tokens
- `GLOBAL_RULES.md` −2,9 %
- Drei Cold-Archives mit ~32 KB Detail-Chronik ausgelagert
- `--enforce` Exit 0 nach Sweep

---

## 9. Wo geht's weiter?

- **Pflicht-Spec (Vollform):** `Nexus/_rules/MEMORY_LAYERS.md`
- **Pattern (Implementierung):** `Nexus/_memory/patterns/session-archive-sliding-window.md`
- **Detail-Tutorial:** [[Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme]]
- **Selbstlern-Loop, der Memory-Grenzen erst hervorgebracht hat:** [[Cortex & Nexus/05-selbstlernendes-system]]
- **Token-Budget-Regel:** `GLOBAL_RULES.md §21` (LL-044) + `§28` (LL-053)
