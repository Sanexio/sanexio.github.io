---
type: tutorial
aliases: [Multi-Device, Geräte-Setup, Nexus-Setup, Cortex-Setup, Auto-Sync, iPad-Sync]
tags:
  - tutorial
  - cortex
  - nexus
  - setup
  - multi-device
  - sync
source: Second Brain/30 Tutorials/Cortex & Nexus/02-multi-device-setup.md
---

# 02 — Multi-Device Setup

> Voraussetzung: Terminal-Grundlagen, GitHub-Account verfügbar.
> Lesezeit: ~15 Min · Praktische Umsetzung: 20–30 Min pro neuem Gerät.
> Ziel: Du kannst auf einem neuen Mac, iPad oder iPhone den Nexus klonen,
> Auto-Sync aktivieren und die Geräte-Registry pflegen.

---

## 1. Drei-Befehle-Setup für einen neuen Mac

```bash
# 1. Cortex-Struktur anlegen
mkdir -p ~/Cortex/projects

# 2. Nexus klonen
cd ~/Cortex && git clone git@github.com:DEIN-USER/nexus.git Nexus

# 3. Dependencies prüfen und installieren
cd Nexus && ./bootstrap.sh
```

Danach Projekte nach Bedarf in `~/Cortex/projects/` kopieren. `bootstrap.sh`
ist auch ein **Gesundheitscheck** und kann jederzeit erneut ausgeführt werden.

> [!warning] macOS Python ist PEP 668 (LL-037)
> `bootstrap.sh` legt automatisch eine `.venv` an, weil das System-Python
> seit macOS 14 externally-managed ist. Pip-Installs außerhalb der venv
> schlagen fehl.

---

## 2. Auto-Sync via launchd

Ein launchd-Job synct den Nexus alle 5 Minuten mit GitHub:

```bash
# Einmalig aktivieren:
cp ~/Cortex/Nexus/com.cortex.nexus-sync.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.cortex.nexus-sync.plist
```

Der Sync arbeitet wie folgt:

1. Committet lokale Änderungen automatisch (mit isolierter Pathspec, damit
   parallele User-Adds nicht vereinnahmt werden — Fix von 2026-04-29).
2. Pullt Änderungen von GitHub (Rebase).
3. Pusht lokale Commits.
4. Bei Konflikten: **stoppt und zeigt macOS-Benachrichtigung** + Telegram-Alarm.

> [!danger] Bei Konflikten: STOPPEN — nicht überschreiben (LL-049)
> Sync-Hygiene ist eine harte Regel. Wenn der lokale Stand vom Remote
> divergiert: keine weiteren Edits, manuell mergen. Hintergrund: 140-Commit-
> Split am 2026-04-24/25.

---

## 3. iPad / iPhone

Für iOS-Geräte funktioniert der Sync etwas anders, weil kein nativer Git-Client
verfügbar ist:

1. **Working Copy** installieren (Git-Client, einmalig ca. 20 €)
2. Nexus-Repo dort klonen
3. **Obsidian** installieren und den Working-Copy-Ordner als Vault öffnen
4. **Vor** dem Arbeiten: Pull in Working Copy
5. **Nach** dem Arbeiten: Commit + Push in Working Copy

> [!info] Warum Working Copy?
> Obsidian alleine kann nicht mit Git sprechen. Working Copy übernimmt das
> Git-Handling und stellt den Vault-Ordner Obsidian zur Verfügung.

---

## 4. Geräte-Registry pflegen

Jedes Gerät ist im Nexus registriert:

```
Nexus/.config/devices.json
```

Schema (LL-036 — beachte: **Dict, kein Array**):

```json
{
  "version": 1,
  "devices": {
    "SSMD-MacBookPro": {
      "role": "praxis",
      "chip": "Intel Core i7",
      "tailscale": "100.115.230.94"
    },
    "Cluster-Mini-02": {
      "role": "home",
      "chip": "Apple M2",
      "tailscale": "100.127.125.48"
    }
  }
}
```

Bei jedem neuen Gerät:

1. Eintrag in `devices.json` ergänzen
2. Tailscale installieren und ins Mesh aufnehmen ([[Netzwerk & Sysadmin/09-cortex-mesh-tailscale]])
3. Gerät in `MEMORY.md` Tabelle „Aktive Cortex-Geräte" eintragen

---

## 5. Welche Projekte gehören auf welches Gerät?

Projekte sind **gerätespezifisch** — sie liegen in `~/Cortex/projects/` und
sind **nicht** im Nexus-Git. Die Zuordnung wird in `MEMORY.md` und
`_projects/INDEX.md` dokumentiert.

| Hostname | Rolle | Typische Projekte |
|----------|-------|-------------------|
| SSMD-MacBookPro | praxis (Intel) | doc-workflow, Praxis-QM, file-renamer, smartq-dashboard |
| Cluster-Mini-02 | home (M2) | Juvantis, telegram-bridge, Cortex-Web, Gaming |
| Mac-Studio-von-MacStudioZi2 | praxis-studio | (noch in Aufbau) |

---

## 6. Bootstrap-Skript — was macht es konkret?

`bootstrap.sh` ist der **Gesundheitscheck** und kann jederzeit neu laufen:

- Legt `.venv` für Python-Tools an (PEP 668 / LL-037)
- Installiert Dependencies aus `requirements.txt`
- Prüft `git config` (Name, Email, gpg-sign falls eingerichtet)
- Verifiziert `devices.json`-Schema
- Setzt Symlinks in `_tutorials/<slug>/` neu, falls fehlend
- Meldet fehlende Tools (z.B. `bun`, `tailscale`, `osascript`)

> [!tip] Nach iCloud-Snapshot oder Time-Machine-Restore (LL-038)
> iCloud kann alte Git-Stände in den Nexus zurückspielen.
> Nach Restore: `git fetch && git reset --hard origin/main` —
> sonst riskierst Du Sync-Drift, der später schwer zu finden ist.

---

## 7. Wichtige Regeln

- **Nexus = Git-Repo.** Änderungen synchronisieren sich automatisch.
- **`projects/` = lokal.** Liegt nicht im Git, ist gerätespezifisch.
- **`PROJECT.md` / `CLAUDE.md` = Beipackzettel.** Jedes Projekt beschreibt
  sich selbst, damit es auf einen anderen Cortex umziehen kann.
- **`bootstrap.sh` = Gesundheitscheck.** Jederzeit wiederholbar.
- **Bei Konflikten: STOPPEN** (LL-049). Nicht blind überschreiben.
- **iCloud-Snapshots sind Git-Zeitbomben** (LL-038). Nach Restore
  `git fetch && git reset --hard origin/<branch>`.

---

## 8. Wo geht's weiter?

- **Architektur dahinter:** [[Cortex & Nexus/01-architektur-und-philosophie]]
- **Tailscale-Mesh:** [[Netzwerk & Sysadmin/09-cortex-mesh-tailscale]]
- **Remote-Zugriff auf andere Geräte:** [[Netzwerk & Sysadmin/10-remote-zugriff-local-dev]]
- **Memory-Schichten verstehen:** [[Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme]]
