---
type: tutorial
aliases: [Konvergenz, Self-Applying, cortex-converge, Drift-Heilung, Kollektivgedächtnis]
tags: [tutorial, cortex, nexus, konvergenz, multi-device, automatisierung]
---

# 12 — Self-Applying-Konvergenz

> Voraussetzung: Multi-Device-Setup ([Modul 02](02-multi-device-setup.md)),
> Memory-Layers ([Modul 03](03-memory-layers.md)).
> Lesezeit: ~10 Min · Praktische Erweiterung: 5–20 Min pro neuem Schritt.
> Ziel: Du verstehst, wie das Nexus-Repo Wissen über „so soll jeder Mac
> aussehen" verteilt, ohne dass du jeden Mac einzeln anlernen musst.

---

## 1. Die Grundidee in einem Satz

> **Was der Cortex als Kollektiv weiß, muss jeder Mac selbsttätig auf sich
> anwenden — nicht der Mensch klickt sich durch jede Maschine.**

Konkrete Auswirkung: Wenn in einer Welle entschieden wird, dass auf
**jedem** Mac der Cortex-Web-Mirror laufen soll, dann steht das in
**einem** Manifest (Bash-Funktion in `scripts/cortex-converge.sh`),
und beim nächsten Sync zieht jeder Mac das Manifest und richtet sich
selbst entsprechend ein. Keine Anleitung „bitte auch auf dem Intel-MBP
folgendes ausführen…".

## 2. Das Begriffspaar Drift vs. Konvergenz

| Begriff | Bedeutung |
|---------|-----------|
| **Soll-Zustand** | Was im Repo als „so soll dieser Mac aussehen" hinterlegt ist |
| **Ist-Zustand** | Was tatsächlich auf diesem Mac vorhanden/aktiv ist |
| **Drift** | Differenz zwischen Soll und Ist |
| **Konvergenz** | Aktion, die Ist an Soll angleicht |
| **Idempotent** | Funktion, die mehrfach aufgerufen denselben Effekt hat wie einmal |

Beispiele:

- **Drift:** Cortex-Web sollte auf jedem Mac geklont sein, ist aber auf
  Intel-MBP noch nicht vorhanden → Drift.
- **Konvergenz:** `cortex-converge.sh` erkennt den fehlenden Klon und
  führt `git clone` aus → Drift behoben, Ist = Soll.
- **Idempotent:** Beim nächsten Lauf erkennt es, dass Cortex-Web jetzt
  da ist → NOOP, keine zweite Klone-Operation.

## 3. Das Skript

**Pfad:** `~/Cortex/Nexus/scripts/cortex-converge.sh`

**Aufruf-Modi:**

```bash
bash scripts/cortex-converge.sh                # leise (nur Drift/Fehler logged)
bash scripts/cortex-converge.sh --verbose      # alles auf stdout
bash scripts/cortex-converge.sh --dry-run      # nur zeigen, was wäre
bash scripts/cortex-converge.sh --step <name>  # nur ein Schritt
bash scripts/cortex-converge.sh --list         # alle Schritte zeigen
```

**Auto-Trigger:** `nexus-sync.sh` ruft `cortex-converge.sh` am Ende
jedes erfolgreichen Sync-Laufs auf. Da Sync alle 5 Min läuft und
Konvergenz-Schritte idempotent sind, läuft Drift-Heilung quasi
automatisch — ohne Extra-launchd-Job.

## 4. Aktuelle Konvergenz-Schritte (Stand 2026-05-24)

| Schritt | Was tut er? | Soll-Zustand |
|---------|------------|--------------|
| `cortex_web_clone` | Klont `Sanexio/cortex-web` nach `~/Cortex/projects/Cortex-Web/`, falls fehlt | Cortex-Web auf jedem Mac vorhanden |
| `cortex_web_mirror_launchd` | Installiert + lädt `com.cortex.cw-mirror.plist` in `~/Library/LaunchAgents/`, falls fehlt | Mirror-Sync läuft alle 5 Min auf jedem Mac |
| `cortex_web_devices_known` | Read-only-Check: warnt, falls dieser Mac in `devices.json` keinen Cortex-Web-Eintrag hat | Konfigurations-Vollständigkeit |

Aktuelle Liste jederzeit über `--list` abfragen.

## 5. Rückgabe-Codes pro Schritt

| Code | Label | Bedeutung |
|:----:|:------|-----------|
| 0 | APPLIED | Drift erkannt + Konvergenz ausgeführt |
| 10 | NOOP | Mac war schon im Soll-Zustand |
| 20 | SKIP | Schritt gilt nicht für diesen Mac (z.B. Linux-only-Action auf macOS) |
| 1 | FAIL | Konvergenz misslungen — manueller Eingriff nötig |

## 6. Wie ich einen neuen Schritt ergänze

Drei Stellen in `cortex-converge.sh` anfassen:

**6.1 Funktion definieren** (idempotent — Check zuerst, Aktion nur bei Drift):

```bash
step_meine_neue_konvergenz() {
    # Plattform-Filter (falls nötig):
    [ "$PLATFORM" = "Darwin" ] || return 20

    # Ist-Zustand prüfen:
    if condition_already_met; then
        return 10   # NOOP
    fi

    # Dry-run respektieren:
    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde X tun"; return 0; }

    # Konvergenz ausführen:
    if do_the_thing; then
        log "APPLIED: X jetzt eingerichtet"
        return 0    # APPLIED
    fi
    log "FAIL: X konnte nicht eingerichtet werden"
    return 1
}
```

**6.2 In `CONVERGE_STEPS` aufnehmen** (Reihenfolge = Ausführungs-Reihenfolge):

```bash
CONVERGE_STEPS=(
    "cortex_web_clone"
    "cortex_web_mirror_launchd"
    "cortex_web_devices_known"
    "meine_neue_konvergenz"     # ← neu
)
```

**6.3 Schritt-Doku** im Tutorial-Abschnitt 4 oben ergänzen.

**Commit + Push.** Beim nächsten Sync läuft der Schritt auf allen Macs
und stellt den neuen Soll-Zustand her.

## 7. Was Konvergenz NICHT macht

- ❌ **Schreibt nicht in `devices.json`** — nur Read-only-Check, weil
  Auto-Schreiben in eine geteilte JSON-Datei Konflikt-anfällig ist.
  Drift dort wird gemeldet, nicht behoben.
- ❌ **Macht keine Auth-Setups** — `bootstrap-mac.sh` ist dafür da.
  Wenn `gh auth` fehlt, loggt Konvergenz nur und springt weiter.
- ❌ **Macht keine Tier-3-Operationen** — Secrets, `.env`, Geld-Pfade
  sind tabu. Konvergenz arbeitet ausschließlich mit nicht-sensitiven
  Soll-Zuständen (Repo geklont, launchd-Job aktiv).
- ❌ **Stoppt nie den Sync** — bei FAIL wird nur geloggt, Sync läuft
  weiter. Konvergenz ist ein Selbstheilungs-Werkzeug, keine Bremse.

## 8. Logs + Inspektion

```bash
# Alle Konvergenz-Läufe
tail ~/Cortex/Nexus/_memory/logs/cortex-converge.log

# Letztes Sync-Log inkl. CONVERGE-Status
tail ~/Cortex/Nexus/_memory/logs/nexus-sync.log
```

Beispiel-Log-Zeile:
```
[2026-05-24T14:39:30Z] STEP cortex_web_clone → NOOP
[2026-05-24T14:39:30Z] STEP cortex_web_mirror_launchd → APPLIED
[2026-05-24T14:39:30Z] APPLIED: cw-mirror launchd-Job installiert + geladen
```

## 9. Anti-Pattern + Stolperfallen

- ❌ **Schritt nicht idempotent** — beim zweiten Lauf wird der Job neu
  installiert, alte Konfiguration überschrieben. Lösung: Ist-Zustand
  zuerst prüfen, NOOP wenn schon erledigt.
- ❌ **Schritt mit Pipe + `set -o pipefail` + `grep -q`** — grep schließt
  die Pipe früh, der vorherige Befehl bekommt SIGPIPE, Pipeline-RC wird
  non-zero, Konvergenz denkt fälschlich „Drift". Lösung: Output
  zwischen-capturen statt direkter Pipeline (siehe `launchctl_out=$(launchctl list 2>/dev/null || true)`).
- ❌ **Konvergenz für etwas Sicherheitskritisches** (z.B. SSH-Keys
  generieren) — gehört nach `bootstrap-mac.sh` mit User-Schleife, nicht
  in den automatischen Sync-Hook.

## 10. Beziehung zu anderen Konzepten

- **Memory-Layers** ([Modul 03](03-memory-layers.md)): Konvergenz ist die
  „warm/cold"-Schicht für Mac-Konfiguration. Was im Repo steht, ist die
  Wahrheit; was lokal abweicht, wird auf den Repo-Stand gezogen.
- **Trust-Tiers** ([Modul 04](04-trust-tiers-und-autonomie.md)):
  Konvergenz-Schritte sind Tier-1 (automatisch erlaubt). Tier-3-Ops
  bleiben User-Aktion.
- **Cortex-Web-Multi-Device-Mirror** (`_tutorials/cortex-web/02`):
  Mirror-Setup ist heute der erste größere Anwendungsfall für Konvergenz.
