---
created: 2026-05-05
updated: 2026-05-05
type: tutorial
domain: Cortex & Nexus
chapter: 07
tags: [cortex, autonomy, sprint-f, openclaw, hermes, modes, skills, sandbox, multi-channel]
related:
  - "[[01-architektur-und-philosophie]]"
  - "[[03-memory-layers]]"
  - "[[04-trust-tiers-und-autonomie]]"
  - "[[06-cortex-autonomy-v2]]"
---

# 07 — Cortex Autonomy v3: OpenClaw-Equivalent + Hermes-Self-Learning

> **Ziel:** Du verstehst, was Sprint F (2026-05-05) gebaut hat — den
> harten Mode-Switch zwischen Safe und Autonomy Mode, die OpenClaw-
> äquivalente Multi-Channel + Sandbox-Fundamente, und die Hermes-Self-
> Learning-Schichten (Skills, Skills-Evolver, Cross-Session-Recall).
>
> **Reihenfolge:** Wenn 06 (Sprint E) gelesen wurde, ist das die direkte
> Fortsetzung. 04 (Trust-Tiers) als Prerequisite.

---

## 1. Worum es geht

In Sprint E gab es den **Autonomy Mode** schon als Konzept (LL-062), aber
er war nur ein Stück Text in `MODES.md`. In der Praxis driftete Claude
zurück in Safe-Verhalten (immer Optionen-Listen, immer Erklärung-Vor-Op),
weil:

1. Die globale `~/.claude/CLAUDE.md` predigte das Gegenteil von `MODES.md`.
2. Auto-Memory-Einträge wie *„Optionen auflisten, keine Vorauswahl"*
   waren als Universal-Regeln getaggt.
3. Slash-Commands `/safe-mode`, `/autonomy-mode`, `/mode` existierten nicht.
4. Es gab keine technische Persistenz — der Modus „lebte nur im Kontext".

**Sprint F (2026-05-05)** fixed das mit drei Bausteinen:

```
F2  Mode-Hard-Persistence    — Slash + Hook + State-File + globale CLAUDE.md
F3  Hermes-Layer             — Skills, Skills-Evolver, Cross-Session-Recall
F4  OpenClaw-Layer           — Multi-Channel-Bridge, Sandbox-Backends
F5  Cron-V2                  — NL-Tasks → Recipe → Plist
```

---

## 2. Die zwei Modi und ihr Switch

### Safe Mode (= „Normaler Modus", wie bisher)
- Architekten-Phasen 1–4 explizit gemarkert, Phase 2 = Approval-Gate.
- Pre-Edit-Confirm bei nicht-trivialen Schreibvorgängen.
- Optionen-Listen bei taktischen Wahl-Punkten erlaubt (LL-034 voll).
- Erklärungen vor jedem Schritt: WAS / WARUM / WAS BEDEUTET DAS (LL-024 voll).

### Autonomy Mode (= „OpenClaw-Equivalent + Hermes immer aktiv")
- Aufgabe verstanden → durchziehen, keine Zwischen-Confirms.
- Status = 1-Zeilen-Phasenmarker, niemals als Frage.
- Welle-Ende-Debrief: WAS gemacht / WAS GELERNT / STRATEGISCHE WAHLEN.
- Stop nur bei: echter Ambiguität, Tier-3-Op, Token-Limit, fertig.
- `git push` zum Nexus-Remote ist Tier 1 (nicht mehr Tier 3).
- OpenClaw-Layer-Tools verfügbar (multi-channel, sandbox, NL-Cron).
- Hermes-Layer immer aktiv (Skills, Recall, Self-Learning).

### Switch — vier harte Schichten

**1. Slash-Command** schreibt State-File:
```
/safe-mode       → ~/.claude/state/cortex-mode.json mit "safe"
/autonomy-mode   → dito mit "autonomy"
/cortex-mode     → zeigt aktuellen Modus (nicht /mode — /model-Konflikt)
```

**2. State-File** persistent (über Sessions hinweg):
```json
{
  "mode": "autonomy",
  "since": "2026-05-05T19:39:08+02:00",
  "host": "Cluster-Mini-02",
  "set_by": "/autonomy-mode"
}
```

**3. UserPromptSubmit-Hook** in `~/.claude/settings.json` injiziert
bei jedem Prompt eine Modus-Marke in den Claude-Kontext:
> *„**CORTEX-MODUS: AUTONOMY** (LL-062, since=...) — durchziehen ohne Confirms..."*

**4. Auto-Memory-Tagging** mit `applies_in: safe-mode|autonomy-mode|always`.
Memory-Einträge ohne Tag = `always`.

Die vier Schichten zusammen halten den Modus drift-resistent. Selbst wenn
der Kontext kompaktiert wird, weiß Claude beim nächsten Prompt sofort,
welcher Modus aktiv ist.

---

## 3. Hermes-Layer (immer aktiv)

### 3.1 Procedural Skills

Wiederverwendbare Lösungsmuster. Liegen in `Nexus/skills/procedural/<slug>/SKILL.md`.

```yaml
---
name: Projekt fortsetzen
slug: session-resume
version: 1.2.0
runs: 47
success_rate: 0.91
description: Strukturierter Sessionstart für ein Projekt
trigger_pattern: |
  Wenn Dr. Stracke sagt "Projekt fortsetzen <slug>"
required_tools: [Read, Glob, Bash]
applies_in: both
---

# Projekt fortsetzen

## Schritte
1. ...
```

**Wie Skills entstehen:**
- Manuell: Datei aus `_template/SKILL.md` kopieren, ausfüllen.
- Automatisch: `cortex-curator` Detector `skill-from-task` erkennt
  wiederkehrende Workflows in Welle-Logs → Vorschlag in Queue.

### 3.2 Skills-Evolver

`tools/cortex-skills-evolver/` analysiert Run-Logs und schlägt
Skill-Diffs vor, wenn:
- Ein Skill ≥ 5 Runs hat UND
- `last_evolved` ist > 7 Tage her ODER `success_rate < 0.7`.

Vorschläge landen in `_memory/skill-evolution-queue.md` mit
`[ ] approve`-Callouts. Approval → `evolve-apply.sh` patched die
Skill-Datei und bumpt `version`.

### 3.3 Cross-Session-Recall

`tools/cortex-recall/` liefert kondensierte Top-K-Recall + 3-Satz-
Summary über alle alten Session-Logs.

```bash
bash tools/cortex-recall/bin/recall.sh --summary "Welle H Praxis"
```

Hermes-Pattern: bei Sessionstart automatisch alte verwandte Sessions
zusammenfassen, statt durch 50 Logs blättern. Geplant als
Session-Start-Hook (F6.1).

### 3.4 User-Trait-Extract

Detector im Curator (`prompts/user-trait-extract.md`). Erkennt aus
Welle-Trajektorien neue User-Eigenschaften und schlägt USER.md-
Patches vor (Hermes Honcho-Dialectic-Pattern).

---

## 4. OpenClaw-Layer (im Autonomy Mode aktiv)

### 4.1 Multi-Channel-Bridge

Foundation in `tools/multi-channel-bridge/`. Telegram läuft weiter
in `tools/telegram-bridge/` und wird in F4.1 hierhin migriert.

**Channel-Plugin-Interface** (`lib/channels/_interface.ts`):
```typescript
export interface ChannelPlugin {
  id: string;
  pairScopes: string[];
  capabilities: ChannelCapability[];
  start(ctx: BridgeContext): Promise<void>;
  send(chatId: string, content: string, opts?: SendOpts): Promise<SendResult>;
  parseInbound(raw: unknown): InboundMessage | null;
}
```

**Channel-Status:**
| Channel | Status | Welle |
|---|---|---|
| telegram | ✅ produktiv (in telegram-bridge) | F4.1 migriert |
| slack | Stub mit Implementierungs-Plan | F4.2 |
| discord | Stub | F4.2 |
| imessage | Stub (macOS chat.db + AppleScript) | F4.3 |
| signal | Stub (signal-cli) | F4.3 |
| matrix | Stub (matrix-bot-sdk) | F4.4 |

### 4.2 Sandbox-Backends

`tools/cortex-sandbox/` mit drei Backends:

```bash
# Local (default, identisch zu Sprint-E)
bash bin/run-in-sandbox.sh --backend local -- claude --print "hi"

# Docker (isoliert, Image cortex-base)
bash bin/run-in-sandbox.sh --backend docker -- claude --print "hi"

# SSH (Stub für F4.3, Cross-Mac via Tailscale)
bash bin/run-in-sandbox.sh --backend ssh --recipe x
```

Recipe-Frontmatter steuert:
```yaml
sandbox: docker
sandbox_image: cortex-base
```

### 4.3 Cron-V2: Natural-Language-Tasks

```bash
python3 tools/cortex-cron/bin/nl-to-recipe.py \
  "Schick mir jeden Werktag 17 Uhr eine Tageszusammenfassung"
# → schreibt tools/cortex-cron/recipes/auto/<slug>.md

python3 tools/cortex-cron/bin/recipe-to-plist.py --recipe <slug>
# → schreibt _skripte/cortex-cron/com.cortex.<slug>.plist

bash _skripte/cortex-cron/install-launchagents.sh
# → registriert via launchctl
```

Ein NL-Prompt — und du hast einen aktiven Cron-Job.

---

## 5. Bedienung im Alltag

### Modus wechseln
```
/autonomy-mode    # ab jetzt durchziehen
/safe-mode        # ab jetzt Approval-Gates
/cortex-mode      # zeigt aktuellen Modus (NICHT /mode — /model-Konflikt)
```

### Skill anlegen (manuell)
```bash
cp -r ~/Cortex/Nexus/skills/procedural/_template ~/Cortex/Nexus/skills/procedural/<slug>
# Frontmatter + Schritte ausfüllen
```

### Recall ausführen
```bash
bash ~/Cortex/Nexus/tools/cortex-recall/bin/recall.sh --summary "<query>"
```

### Cron-Job aus NL anlegen
```bash
python3 ~/Cortex/Nexus/tools/cortex-cron/bin/nl-to-recipe.py "<NL-Spec>"
```

### Skills-Evolver manuell anwerfen
```bash
bash ~/Cortex/Nexus/tools/cortex-skills-evolver/bin/evolve.sh
```

---

## 6. Was in v3 (noch) NICHT enthalten ist

Aufgeschoben auf v3.x (Spec § 8):

| Feature | Welle | Begründung |
|---|---|---|
| Live Canvas (A2UI) | v3.5 | Eigenes UI-Framework |
| Voice Wake / TTS | v3.6 | Audio-Subsystem |
| iOS/Android Nodes | v3.7 | Mobile-Apps notwendig |
| Multi-Provider (OpenRouter etc.) | v3.8 | Andere SDKs nötig |
| Daytona/Modal/Singularity Backends | v3.9 | Cloud-Accounts erforderlich |

---

## 7. Sicherheit, Idempotenz, Auditierbarkeit

Identisch zu v2 (Spec § 10). Neu:

- **State-File-Robustheit:** Hook-Fehler → Fallback auf Default
  „autonomy" (kein Safe-Mode-Lock-in durch Skript-Crash).
- **Sandbox-Modell:** docker-Backend = isoliertes File-Mount nur für
  Nexus + /tmp.
- **Tier-3-Stop bleibt hart** — auch im Autonomy Mode.

---

## 8. Migration v2 → v3

**Was bleibt erhalten** (rückwärtskompatibel):
- Alle Recipes, Pairings, State-Files.
- `cortex-curator`, `cortex-cron`, `telegram-bridge`.
- `MODES.md` (erweitert um §4.3–4.6).
- Sprint-E-Tutorial (06).

**Was neu kommt:**
- `tools/cortex-mode/`, `cortex-skills/`, `cortex-skills-evolver/`,
  `cortex-recall/`, `multi-channel-bridge/`, `cortex-sandbox/`.
- `~/.claude/{commands/, state/, settings.json}` mit Hook.
- `Nexus/skills/procedural/` mit Skill-Format.

**Was geändert wurde:**
- `~/.claude/CLAUDE.md` komplett neu (kohärent zu MODES.md).
- 2 Auto-Memory-Einträge mit `applies_in: safe-mode` getaggt.
- `_rules/MODES.md` um Hard-Persistence-Mechanik erweitert.
- `cortex-cron/recipes/_template.md` um sandbox+delivery-Felder.

---

## 9. Goldene Lehrsätze aus Sprint F

1. **„Autonomy" muss hart sein** — eine Zeile in einem Spec-Dokument
   reicht nicht. Vier Schichten (State, Slash, Hook, Memory-Tag) sind
   das Minimum gegen Drift.
2. **Hermes-Pattern lassen sich auf Claude-Code-Runtime mappen** —
   wir laufen nicht auf Python wie Hermes selbst, aber Procedural
   Memory + Skills self-improve + FTS5-Recall sind Format-agnostisch.
3. **OpenClaw-Pattern brauchen Plugin-Interface zuerst** — bevor man
   den dritten Channel implementiert, muss das Interface stabil sein.
   Stubs zwingen zur Disziplin.
4. **NL-zu-Cron ist überraschend banal** — Sonnet 4.6 + 60-Zeilen-
   Prompt + 200-Zeilen-Python. Komplexität liegt im Recipe-Format,
   nicht im Parsing.

---

## 10. Architektur-Referenz

| Was | Pfad |
|---|---|
| Master-Spec | `Nexus/specs/cortex-autonomy-v3/SPEC.md` |
| Mode-Tool | `Nexus/tools/cortex-mode/` |
| Skills-Format | `Nexus/skills/procedural/_template/SKILL.md` |
| Skills-Registry | `Nexus/tools/cortex-skills/registry.json` |
| Skills-Evolver | `Nexus/tools/cortex-skills-evolver/` |
| Recall | `Nexus/tools/cortex-recall/` |
| Multi-Channel | `Nexus/tools/multi-channel-bridge/` |
| Sandbox | `Nexus/tools/cortex-sandbox/` |
| Cron-V2 | `Nexus/tools/cortex-cron/bin/{nl-to-recipe,recipe-to-plist}.py` |
| Slash-Commands | `~/.claude/commands/{safe-mode,autonomy-mode,mode}.md` |
| State-File | `~/.claude/state/cortex-mode.json` |
| Hook | `~/.claude/settings.json` |
| MODES.md (Single Source of Truth) | `Nexus/_rules/MODES.md` |

---

> Wenn etwas nicht funktioniert wie beschrieben: melde es als
> `[!frage]`-Callout in `Second Brain/00 Kontext/Dialog.md` (LL-045).
> Tutorial wird gepflegt.
