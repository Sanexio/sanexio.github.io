---
type: tutorial
aliases: [Cortex, Nexus, Cortex & Nexus, Cortex-Nexus, Ökosystem, Wissenskern]
tags:
  - tutorial
  - cortex
  - nexus
  - architektur
source: Second Brain/30 Tutorials/Cortex & Nexus/
legacy_path: _tutorials/cortex-nexus/ (Symlink)
---

# Cortex & Nexus — Grundlagen

> Quellpfad: `Second Brain/30 Tutorials/Cortex & Nexus/`
> Diese Domäne erklärt **das Ökosystem selbst** — den portablen Wissenskern
> (Nexus) und den lokalen Arbeitsordner (Cortex), in dem Du jeden Tag arbeitest.
> Sie ist kein Setup-Cookbook, sondern die **Architektur-Begründung**: warum
> Nexus genau so aufgebaut ist, was Memory-Layers leisten, wie sich das System
> selbst lernt und wie mehrere Geräte zusammenspielen.

> [!info] Lesezeit: 5 Min Übersicht · jede Detail-Seite ~10–20 Min · Voraussetzung: Terminal-Grundlagen hilfreich, aber nicht zwingend

---

## 1. Warum gibt es diese Domäne?

Cortex und Nexus sind **kein Werkzeug**, das Du gelegentlich öffnest, sondern
das Substrat, auf dem alle Projekte laufen. Wenn Du verstehst, **warum** der
Wissenskern in `_memory/`, `_rules/`, `_lib/`, `tools/`, `Second Brain/`
zerlegt ist und **warum** Memory in Hot/Warm/Cold-Schichten gegliedert wird,
kannst Du das System weiterentwickeln, statt nur darin zu arbeiten.

| Was passiert ohne dieses Verständnis? | Welches Modul greift? |
|---|---|
| Geräte-Setup wird zur Bastelei, weil unklar ist, was lokal vs. portabel gehört | **01 — Architektur & Philosophie** |
| Neues Gerät dauert Stunden, Sync-Konflikte sind unverständlich | **02 — Multi-Device Setup** |
| MEMORY.md wächst unkontrolliert, Sessionstart bricht ab (Token-Overflow) | **03 — Memory-Layers** ↗ Arbeitsweise/02 |
| Claude fragt bei jedem Commit nach Freigabe, Routine wird zur Reibung | **04 — Trust-Tiers & Autonomie** ↗ Arbeitsweise/01 |
| Fehler wiederholen sich, weil Lernen nicht persistiert wird | **05 — Selbstlernendes System** ↗ Arbeitsweise/02 |
| Du sitzt nicht am Mac, brauchst aber Status / willst einen Lauf anstoßen | **06 — Cortex Autonomy v2** (Telegram + Curator + Cron) |

---

## 2. Module dieser Domäne

| # | Modul | Inhalt | Status |
|:-:|------|--------|:------:|
| 01 | [[Cortex & Nexus/01-architektur-und-philosophie\|Architektur & Philosophie]] | Was ist Nexus, was ist Cortex, Container-Modell, Trennung portabel/lokal | 🟢 |
| 02 | [[Cortex & Nexus/02-multi-device-setup\|Multi-Device Setup]] | Neues Gerät einrichten, Auto-Sync, iPad/iPhone, Geräte-Registry | 🟢 |
| 03 | [[Cortex & Nexus/03-memory-layers\|Memory-Layers]] | Hot/Warm/Cold, Token-Caps, Sliding-Window, Sanitizer-Hardgate (LL-053) | 🟢 |
| 04 | [[Cortex & Nexus/04-trust-tiers-und-autonomie\|Trust-Tiers & Autonomie]] | LL-055 — drei Vertrauens-Tiers, Lockerung von LL-024/LL-034, was unverändert bleibt | 🟢 |
| 05 | [[Cortex & Nexus/05-selbstlernendes-system\|Selbstlernendes System]] | 5-Schritte-Loop Fehler → Regel → Tool → Tutorial → Pattern | 🟢 |
| 06 | [[Cortex & Nexus/06-cortex-autonomy-v2\|Cortex Autonomy v2]] | Sprint E — Telegram bidirektional + Curator + Cortex-Cron + Apply (OpenClaw + Hermes-Patterns) | 🟢 |
| 07 | [[Cortex & Nexus/07-cortex-autonomy-v3\|Cortex Autonomy v3]] | Sprint F — Mode-Hard-Persistence (Slash + Hook + State), Hermes-Layer (Skills, Skills-Evolver, Recall), OpenClaw-Layer Foundation, Cron-V2 mit NL-Tasks | 🟢 |
| 08 | [[Cortex & Nexus/08-phoenix-stack\|Phoenix-Stack]] | Architektur nach dem Hard-Reset 2026-05-09 — agent/Python + gateway/Bun + Connexio Read-Only-Surface + Phoenix-Cron mit Tier-3-Token-Mechanik + 10 Skills + Memory-DB-Schema | 🟢 |
| 09 | [[Cortex & Nexus/09-cortex-bot-telegram\|Cortex-Bot — Befehle und Architektur]] | Telegram-Bot `@sanexio_bot` als bidirektionaler Steuerkanal: Plain-Text-Routing via [tag], `/spawn` mit Host-Aliasen, AsyncRewake-Hook, /verdict, Setup-Voraussetzungen, Anti-Patterns | 🟢 |
| 10 | [[Cortex & Nexus/10-ipad-remote-desktop\|iPad Remote Desktop]] | Vom iPad aus den Cluster-Mini-02-Bildschirm steuern: Tailscale-Tunnel + macOS-Bildschirmfreigabe (VNC) + iPad-Client (VNC Viewer / Jump Desktop), Setup-Cheatsheet, Smoke-Test, Troubleshooting | 🟢 |
| 11 | [[Cortex & Nexus/11-codex-mac-onboarding\|Codex-Mac-Onboarding]] | Neuen Mac mit OpenAI Codex (App + CLI) und OpenClaw als Backbone in das Cortex-Netzwerk integrieren: Tailscale-Beitritt, Bootstrap, Connexio-MCP-Server lokal, Codex-MCP-Konfiguration, Workspace-Trust, Boundary-Reminder | 🟢 |

**Legende:** 🟢 Modul vorhanden.

> [!tip] Organisches Wachstum (LL-035)
> Die Domäne ist mit Modul 08 (Phoenix-Stack, 2026-05-09) auf den aktuellen
> Stand gebracht. Module 06/07 bleiben als historischer Pfad (Cortex Autonomy
> v2 / v3) — der Reset ersetzt sie nicht, sondern erklärt, was nach dem
> Hard-Cut stehengeblieben ist.

---

## 3. Verwandte Themen

- [[Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme]] — wie MEMORY.md, SESSION_RESUME und Patterns als Schichten zusammenspielen
- [[Arbeitsweise & Prozess/01-architekten-modus]] — der 4-Phasen-Prozess, in dem Cortex/Nexus eingebettet ist
- [[Netzwerk & Sysadmin/09-cortex-mesh-tailscale]] — wie die Geräte über Tailscale-Mesh verbunden werden
- [[Terminal Grundlagen]] — Voraussetzung für die Setup-Schritte in Modul 02

---

## 4. Konventionen

- **Sprache:** Deutsch im Inhalt, Englisch in Code-Kommentaren.
- **Single Source of Truth:** Dateien leben physisch hier; `_tutorials/cortex-nexus/` ist Symlink für Legacy-Pfade.
- **Drei-Dateien-Regel ([[TUT-001]]):** Pro Modul bis zu drei Dateien (`XX-thema.md`, `XX-thema_claude.md`, `XX-thema_manuell.md`).

---

*Letzte Aktualisierung: 2026-05-03 — Modul 06 (Cortex Autonomy v2 / Sprint E)
ergänzt: Telegram bidirektional + Pairing, Cortex-Curator (Anthropic-API,
selbstlernende Pattern-Vorschläge), Cortex-Cron (ephemere Spawns via
LaunchAgent + Watcher), Apply für Pattern-Typ. Vorbild: OpenClaw + Hermes.
Vorher (2026-04-30): Domäne neu angelegt mit Modulen 01–05.*
