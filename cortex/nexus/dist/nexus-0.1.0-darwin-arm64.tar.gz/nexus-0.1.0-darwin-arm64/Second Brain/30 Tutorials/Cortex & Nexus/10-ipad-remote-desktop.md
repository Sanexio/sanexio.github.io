---
title: "Cortex & Nexus / 10 — iPad Remote Desktop auf Cluster-Mini-02"
created: 2026-05-10
verified: 2026-05-12 (Jump iPad → Cluster-Mini-02 + macbookpro-silicon/M5 beide live; Mesh komplett)
domain: cortex-nexus
status: live-verified
tags: [tutorial, cortex, ipad, remote-desktop, vnc, tailscale, screen-sharing]
---

# 10 — iPad Remote Desktop auf Cluster-Mini-02

> Vom iPad aus den Bildschirm des Home-Macs (`Cluster-Mini-02`,
> Apple M2, macOS 15.5) steuern. Funktioniert von überall, ohne
> Portfreigabe im Heimrouter — der Tailscale-Mesh-Tunnel macht
> das Gerät weltweit erreichbar, als wäre es im selben WLAN.

---

## §1 Voraussetzungen — Stand 2026-05-10 alle erfüllt

| Komponente | Status | Befund |
|---|---|---|
| Tailscale-Mesh aktiv | ✅ | `cluster-mini-02` IP `100.127.125.48`, iPad IP `100.105.151.95` |
| MagicDNS | ✅ | Suffix `piranha-marlin.ts.net`, Self-DNS `cluster-mini-02.piranha-marlin.ts.net` |
| Screen-Sharing-Daemon | ✅ | `screensharingd` (PID 300) + `ARDAgent` (PID 609) laufen |
| VNC-Port 5900 erreichbar | ✅ | `nc -zv 100.127.125.48 5900` → succeeded |
| Apple Remote Desktop Port 3283 | ✅ | ARDAgent listened |
| VNC-Legacy-Mode aktiv | ✅ | `VNCLegacyConnectionsEnabled = 1` (3rd-Party-Clients erlaubt) |
| Lokale-User-Auth | ✅ | `ARD_AllLocalUsers = 1`, `ARD_AllLocalUsersPrivs = 255` |
| Power-Sleep deaktiviert | ✅ | `pmset sleep 0` (Daemon hält Mac wach) |
| Wake-on-Magic-Packet | ✅ | `womp 1`, `tcpkeepalive 1` |

→ **Mac-seitig nichts mehr zu tun.**

---

## §2 iPad — Einmal-Setup

### Schritt 1: VNC-Client installieren

> **Account-frei!** RealVNC erfordert seit 2024 einen RealVNC-Account
> (nur Firmen-Registrierung im DACH-Raum) und ist daher als
> Privat-Tool unbrauchbar geworden. Diese Empfehlungs-Liste enthält
> ausschließlich Apps, die **ohne Cloud-Account** lokal funktionieren.

| App | Preis | Account nötig? | Vertrauen | Bewertung |
|---|---|---|---|---|
| **Jump Desktop** *(klare Empfehlung)* | ca. 10 € einmalig | nein — App-Store-Kauf reicht | >50.000 Bewertungen ~4.9★, seit 2010 am Markt | Beste Performance dank Fluid-Protokoll (laut MacRumors-Foren glatter als rohes VNC), hardware-decodiert, MagicDNS + Bonjour-Auto-Discovery, Trackpad/Tastatur-Pass-through perfekt. De-facto-Goldstandard für iPad→Mac-Remote-Desktop. |
| **Screens 5** | einmaliger Kauf ~30 € | nein für reine VNC-Funktion | Edovia, etabliert seit ~2010 | Polierte iOS-UI, einmaliger Kauf (kein Abo nötig fürs reine VNC), guter Apple-Look. Closest competitor zu Jump Desktop. |
| ~~**Mocha VNC**~~ | ~~5–6 €~~ | nein | <10 Reviews, unklarer Audit-Status | **NICHT empfohlen** — zu wenige Reviews, kein Sicherheits-Backing für eine App, die ein Login-Passwort übermittelt. |
| ~~**RealVNC Viewer**~~ | ~~kostenlos~~ | RealVNC-Cloud-Account (DACH nur Firma) | etabliert, aber Account-Zwang | **NICHT empfohlen** — Account-Zwang seit 2024. |

→ **Eindeutige Empfehlung: Jump Desktop** (App Store: „Jump Desktop —
RDP, VNC, Fluid", Anbieter Phase Five Software). Die einmaligen 10 €
sind die mit Abstand sicherste und schnellste Lösung — kein Abo,
kein Account, jahrelang auditiert, riesige Review-Basis. Alternativen
mit weniger als ein paar tausend Reviews sind bei Apps, die
Authentifizierung gegenüber dem Mac vornehmen, ein Sicherheits-Risiko
und werden nicht empfohlen.

### Schritt 2: Tailscale-App auf iPad sicherstellen

Tailscale-iOS-App muss installiert + eingeloggt sein (unter
`7vwcqsnty6@privaterelay.appleid.com`-Tailnet). MagicDNS muss
**aktiviert** sein in den Tailscale-iOS-Settings — sonst muss man
mit der reinen IP arbeiten.

Verifizieren am iPad: Tailscale-App öffnen → Status muss
„Connected" zeigen, Cluster-Mini-02 muss in der Geräteliste stehen.

### Schritt 3: VNC-Verbindung anlegen

In **Jump Desktop** (oder Mocha VNC) auf dem iPad eine neue VNC-Verbindung
anlegen — die Felder heißen je nach App leicht unterschiedlich, der Inhalt
ist identisch:

```
Address / Host:  100.127.125.48
                 (oder bei aktivem MagicDNS: cluster-mini-02.piranha-marlin.ts.net)
Protocol:        VNC
Port:            5900   (Standard, meist nicht eingeben nötig)
Name / Label:    Cluster-Mini-02 (Home)
```

In Jump Desktop zusätzlich: **Type = „Mac (Screen Sharing)"** wählen,
dann werden macOS-Tastenkürzel (Cmd-Tab, Cmd-Space) automatisch
korrekt übersetzt.

Beim ersten Connect:
1. Auth-Dialog → `Username: cluster-mini-02` + Login-Passwort des
   macOS-Users (gleiches Passwort wie beim Mac-Login).
2. **Permission-Prompt am Mac:** beim allerersten Login erscheint auf
   dem Mac-Bildschirm ein „Bildschirmfreigabe anfordern"-Dialog. Einmal
   physisch am Mac auf „Erlauben" klicken — danach merkt macOS sich die
   Freigabe für den User.

---

## §3 Bedienung am iPad

| Geste | Effekt |
|---|---|
| Ein-Finger-Tap | Linksklick |
| Zwei-Finger-Tap | Rechtsklick |
| Pinch | Zoom (lokales Zoom, nicht Mac-Zoom) |
| Drei-Finger-Drag | Bildschirm-Pan beim Zoom |
| Magic-Keyboard / externe Tastatur | direkter Tastatur-Pass-through |

Bei **Jump Desktop** zusätzlich: Trackpad-Cursor, F-Keys, Cmd-Tab,
Cmd-Space (Spotlight) — alles native.

---

## §4 Smoke-Test-Checklist

Nach Setup einmal verifizieren:

1. iPad mit Mobilfunk (nicht Heim-WLAN), Tailscale „Connected".
2. VNC Viewer → Verbindung zu `cluster-mini-02` aufbauen.
3. Login → Mac-Desktop erscheint im Vollbild.
4. Cmd-Space → Spotlight öffnet sich am Mac → Tippe „Terminal" → Enter.
5. Im Terminal `whoami` ausführen → muss `cluster-mini-02` zeigen.
6. Disconnect → Mac-Sitzung läuft weiter, kein User-Logout.

---

## §5 Troubleshooting

| Symptom | Ursache | Fix |
|---|---|---|
| „Connection refused" auf Port 5900 | screensharingd nicht aktiv | `launchctl list \| grep screensharing` am Mac; ggf. System Settings → General → Sharing → Screen Sharing einschalten |
| „Authentication failed" | falsches Passwort | macOS-Login-Passwort, nicht App-Password |
| Mac-Bildschirm bleibt schwarz | Display schläft | normal — sobald Cursor bewegt wird, weckt VNC-Server den Bildschirm |
| Verbindung bricht nach Schlafphase ab | System-Sleep aktiv | `pmset -g \| grep sleep` muss `sleep 0` zeigen (durch screensharingd schon gewährleistet) |
| Keine MagicDNS-Auflösung am iPad | Tailscale-MagicDNS-Toggle aus | Tailscale-iOS-App → Use Tailscale DNS = on |
| Permission-Prompt blockt Remote-Login (User nicht physisch am Mac) | `ScreenSharingReqPermEnabled = 1` für anonyme Anfragen | Bei Login mit echtem User-Konto irrelevant — der Prompt erscheint nur einmal beim allerersten Login pro User |
| **„VNC-Fehler — Management Application open"** | Apple Remote Desktop.app läuft auf dem Ziel-Mac (als Client zu einem anderen Mac) | App quitten (Cmd-Q), durch macOS-Bildschirmfreigabe.app ersetzen — siehe §9 |

---

## §6 Sicherheits-Hinweise

- VNC-Verkehr läuft **innerhalb des Tailscale-WireGuard-Tunnels** —
  also Ende-zu-Ende verschlüsselt. Auch wenn das VNC-Protokoll selbst
  legacy ist, sieht ein Angreifer im offenen WLAN nur WireGuard-UDP.
- **Niemals** den Port 5900 in einem Heimrouter freigeben — nur via
  Tailscale-Mesh erreichbar lassen.
- macOS-Login-Passwort ist gleichzeitig die VNC-Auth — bei Wechsel
  des Login-Passworts ändert sich auch der VNC-Login automatisch.
- Tailscale-Tailnet-Owner ist `7vwcqsnty6@privaterelay.appleid.com`
  (Dr. Stracke, Apple-ID-Login). Verlust dieses Apple-IDs → kompletter
  Mesh-Zugriff weg.

---

## §7 Wenn auch Praxis-Mac/Studio/M5 vom iPad aus erreichbar sein sollen

Selbes Vorgehen, aber pro Mac einzeln:

1. **Am Ziel-Mac**: System Settings → General → Sharing → Screen Sharing
   einschalten. Unter „Allow access for" mindestens den eigenen User
   freigeben. Optional in „Computer Settings…" → „VNC viewers may control
   screen with password" → eigenes VNC-Passwort setzen (entkoppelt VNC-Auth
   vom macOS-Login-Passwort).
2. **Am iPad in Jump Desktop**: neue Connection mit der jeweiligen
   Tailscale-IP anlegen (Modus = **Manual / VNC**, nicht Automatic):

| Knoten | Tailnet-Hostname | IPv4 | SSH-User / VNC-User | Status |
|---|---|---|---|---|
| `praxis-studio` (Studio) | `praxis-studio.piranha-marlin.ts.net` | `100.119.241.21` | `zimmer2` | online |
| `macbookpro-intel` (Praxis-Intel-MBP) | `macbookpro-intel.piranha-marlin.ts.net` | `100.115.230.94` | `ssmd` | offline (Migrations-Erbe — Knoten von M5 übernommen) |
| `macbookpro-silicon` (M5, Praxis-Mobile) | `macbookpro-silicon.piranha-marlin.ts.net` | `100.93.193.44` | `ssmd` | online + tagged + iPad-Jump live (verifiziert 2026-05-12) |

---

## §9 Spezial-Troubleshooting: „VNC-Fehler — Management Application open"

> **Verifiziert am M5 (Praxis-Mobile, macOS 26.4.1) 2026-05-11/12**, nach
> stundenlanger Fehlersuche entdeckt. Diese Sektion bewahrt zukünftige
> Sessions vor genau diesem Rabbit-Hole. Folge-Welle 2026-05-12: nach
> ARD-Quit + Bildschirmfreigabe-Aktivierung lief iPad-Jump → M5 sofort.

### Symptom

Jump Desktop am iPad meldet beim Connect zum Ziel-Mac eine VNC-Fehlermeldung
mit dem Wortlaut „VNC error: Management Application open" (oder ähnlich).
Die Verbindung wird sofort abgewiesen, noch bevor der Auth-Dialog erscheint.

### Falsche Spuren (NICHT ohne Not gehen)

- **screensharingd / ARDAgent / kickstart-Deaktivierung**: ergeben kurzzeitige
  Effekte, lösen das Problem aber nicht. Der ARD-Daemon-Stack ist nicht der
  Schuldige.
- **remotemanagementd (UID `_rmd`)**: ist in macOS 26 ein normaler System-
  Daemon für Declarative Device Management, hat **nichts** mit VNC zu tun —
  irreführender Name. Auch ohne MDM-Enrollment immer da, ist nicht der
  Übeltäter.
- **Configuration-Profile / MDM-Enrollment**: bei Privat-Macs typischerweise
  leer (`profiles list -all` → „no configuration profiles installed",
  `profiles status -type enrollment` → beide „No"). Nicht hier suchen.
- **VNCLegacyConnectionsEnabled-Pref**: ist nur ein passives Flag, triggert
  selbst nichts.

### Echte Ursache

**`Apple Remote Desktop.app`** (das $79-Programm aus dem Mac App Store)
läuft auf dem Ziel-Mac. Dr. Stracke verwendet sie als **Client** zum
Fernsteuern eines anderen Macs (z. B. Cluster-Mini-02). Die App ist
historisch Dual-Use: Client UND lokaler ARD-Server in einem Bundle.
Sobald sie geöffnet ist, sperrt sie **eingehende** VNC-Verbindungen auf den
eigenen Mac mit dem Schutz-Lock „Management Application open" — eine
Sicherheitsmaßnahme aus der ARD-2.x-Ära, die verhindern soll dass jemand
einen ARD-Admin währen aktiver Sitzung umgeht.

Im Praxis-Setup tritt das auf, wenn Apple Remote Desktop.app per
Migrations-Assistent vom Intel-MBP mitgewandert ist und entweder beim
Login auto-startet oder als „Resume after Quit" wiederkommt.

### Praxis-Szenario (verifiziert 2026-05-12)

Häufiger Trigger im realen Workflow: Dr. Stracke sitzt am M5, hat
**Apple Remote Desktop.app** offen und steuert darüber Cluster-Mini-02.
In genau diesem Moment versucht er, vom iPad per Jump auf den M5 zu
verbinden → Fehler „Management Application open". Solange ARD.app am
M5 läuft (auch nur als Client zu Home), bleibt der M5 für eingehende
VNC-Verbindungen gesperrt. Nach Cmd-Q am M5 → iPad-Jump verbindet
sofort.

### Diagnose-Befehl

Am Ziel-Mac ausführen:

```bash
ps -ef | grep -iE "Remote Desktop|ARDAgent" | grep -v grep
```

Wenn `/Applications/Remote Desktop.app/Contents/MacOS/Remote Desktop`
in der Liste auftaucht → das ist die Ursache. ARDAgent als parallel
laufender Helper ist nur ein Symptom.

Zusätzlich verrät `launchctl list | grep -iE "RemoteDesktop|ARD"` einen
Eintrag der Form `application.com.apple.RemoteDesktop.<numbers>` — auch
das ist die laufende Admin-App, nicht ein Daemon.

### Lösung

**Variante A — App ersetzen** (empfohlen):

Apple Remote Desktop.app durch die kostenlose, in macOS eingebaute
**Bildschirmfreigabe.app** ersetzen. Diese ist reiner Client und hat
das Konflikt-Problem nicht.

- Spotlight (Cmd-Space) → „Bildschirmfreigabe" → Enter
- Im Fenster: `vnc://cluster-mini-02.piranha-marlin.ts.net` oder
  `vnc://100.127.125.48` eintippen → Verbinden
- Login `<user>` + macOS-Passwort

Anschließend `Apple Remote Desktop.app` mit **Cmd-Q quitten**. Damit ist
auch ARDAgent weg, und Jump iPad → Ziel-Mac kann verbinden.

**Variante B — App temporär deaktivieren**:

```bash
sudo mv "/Applications/Remote Desktop.app" "/Applications/Remote Desktop.app.DISABLED"
sudo killall "Remote Desktop" ARDAgent
```

Reversibel via:

```bash
sudo mv "/Applications/Remote Desktop.app.DISABLED" "/Applications/Remote Desktop.app"
```

### Warum die teure Admin-App nicht gebraucht wird

Apple Remote Desktop ist eine **Mass-Management-Konsole** (Software-Push
auf 100+ Macs gleichzeitig, Inventar, Reports, Skripte parallel). Für
1:1-Remote-Desktop reicht die in macOS eingebaute Bildschirmfreigabe
komplett — sie nutzt dasselbe VNC-Protokoll, hat aber keinen Server-Anteil.
Für eine 1–4-Mac-Praxis ist die kostenlose Variante immer die richtige
Wahl.

**Empfehlung für Dr.-Stracke-Setup**: ARD.app auf allen Macs durch
**Bildschirmfreigabe.app** ersetzen. Konkret pro Mac einmal:

1. ARD.app via Cmd-Q quitten.
2. Auto-Start prüfen: System Settings → General → Login Items → eventuelle
   ARD-Einträge entfernen.
3. Optional: `Applications/Remote Desktop.app` nach `Applications/_Deprecated/`
   verschieben, damit Spotlight sie nicht mehr vorschlägt.
4. Stattdessen Bildschirmfreigabe.app als Standard nutzen
   (Spotlight: „Bildschirmfreigabe" → `vnc://<tailnet-ip>`).

Funktional verliert man **nichts** — alle 1:1-Remote-Operationen
(Tippen, Klicken, Drag & Drop, Cmd-Tab, Spotlight) gehen über
Bildschirmfreigabe identisch, oft mit besserer Bild-Rate, weil keine
ARD-Overlays mitgeschleppt werden. Und der „Management Application open"-
Lock entfällt ein für alle Mal — iPad-Jump und parallele Mac-zu-Mac-
Sessions koexistieren konfliktfrei.

### Verifikations-Checkliste nach Fix

1. `ps -ef | grep -iE "Remote Desktop|ARDAgent" | grep -v grep` → leer.
2. `sudo lsof -nP -iTCP:5900 -sTCP:LISTEN` → `launchd` (root) hört auf 5900.
3. Jump iPad → Ziel-Mac-Tailnet-IP → Login → Mac-Desktop erscheint.
4. Bildschirmfreigabe.app vom Ziel-Mac aus → anderer Mac → verbindet
   parallel ohne Konflikt.

---

## §8 Referenzen

- Tailscale-iOS-App: <https://tailscale.com/download/ios>
- Jump Desktop iOS: <https://apps.apple.com/de/app/jump-desktop/id362811897>
- Screens 5 iOS: <https://apps.apple.com/de/app/screens-5-vnc-remote-desktop/id1663047912>
- Apple-Doku „Bildschirmfreigabe": macOS System Settings →
  General → Sharing → Screen Sharing
