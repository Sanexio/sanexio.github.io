---
created: 2026-05-03
updated: 2026-05-03
type: tutorial
domain: Cortex & Nexus
chapter: 06
tags: [cortex, nexus, autonomy, sprint-e, telegram, curator, cron, agent]
related:
  - "[[01-architektur-und-philosophie]]"
  - "[[03-memory-layers]]"
  - "[[04-trust-tiers-und-autonomie]]"
  - "[[05-selbstlernendes-system]]"
---

# 06 — Cortex Autonomy v2: Selbstlernender Agent mit Telegram-Steuerung

> **Ziel dieses Tutorials:** Du verstehst, was Sprint E (2026-05-03) gebaut hat,
> wie Cortex jetzt **eigenständig nachts arbeitet**, wie du ihn vom **iPhone aus
> per Telegram** steuerst, und wie der **Curator** dem System beibringt,
> sich selbst zu verbessern.
>
> **Vorlesungs-Reihenfolge:** wenn du Tutorials 01–05 schon gelesen hast, ist
> dieses hier die Krönung. Falls nicht: 01 (Architektur) und 04 (Trust-Tiers)
> reichen als Vorbereitung.

---

## 1. Worum es geht — und warum

Bis Sprint D war Cortex/Nexus ein **interaktives Werkzeug**: du sitzt am Mac,
Claude antwortet, ihr arbeitet zusammen. Funktioniert gut, hat aber drei
Reibungspunkte:

1. **Du musst am Computer sein.** Unterwegs ohne Laptop = kein Cortex.
2. **Lernen passiert manuell.** Nach jedem Sprint musst du selbst entscheiden,
   was als Pattern, Regel oder Memory-Eintrag persistiert wird.
3. **Wiederkehrende Aufgaben** (Status-Reports, Drift-Audits, Pattern-Mining)
   brauchen einen Menschen, der „los" sagt.

Sprint E hebt das auf drei Ebenen:

| Ebene | Vorher | Nachher (Sprint E) |
|---|---|---|
| **Steuerung** | nur Mac-CLI | Mac-CLI **+ Telegram bidirektional** |
| **Lernen** | manuell beim „Session beenden" | **Curator** liest Welle-Diff, schlägt Patterns vor |
| **Zeit** | nur live | **Cron-Spawns** nachts/morgens, ephemere Claude-Sessions |

Vorbild waren zwei GitHub-Projekte: **OpenClaw** (Channel-Plattform für Agenten)
und **NousResearch/hermes-agent** (Selbstlern-Runtime). Wir haben deren Patterns
übernommen — nicht den Code, weil unsere Runtime Claude Code ist.

> *Fachbegriff (LL-057): „Pattern" hier = wiederkehrendes Lösungsmuster, das
> in `Nexus/_memory/patterns/<slug>.md` als eigenständige Datei dokumentiert
> wird, damit es bei zukünftigen Aufgaben gefunden werden kann.*

---

## 2. Die vier Bausteine im Überblick

```
                    ┌─────────────────────────────────────────────┐
                    │       Cortex Autonomy v2 (Sprint E)         │
                    └─────────────────────────────────────────────┘
                                        │
       ┌────────────────┬────────────────┼────────────────┬────────────────┐
       ▼                ▼                ▼                ▼                ▼
  ┌─────────┐     ┌─────────┐     ┌─────────────┐  ┌──────────────┐  ┌──────────┐
  │  D      │     │  A      │     │  B          │  │  C           │  │  Querschn│
  │  Init-  │     │  Cortex-│     │  Telegram   │  │  Cortex-Cron │  │  itt     │
  │  Slim   │     │  Curator│     │  bidirek-   │  │  (ephemere   │  │  Sec/Idem│
  │         │     │         │     │  tional+    │  │  Spawns)     │  │  Logs    │
  │  QUICK. │     │  liest, │     │  Pairing    │  │              │  │          │
  │  md     │     │  schlägt│     │             │  │              │  │          │
  │  als    │     │  vor,   │     │  iPhone     │  │  LaunchAgent │  │          │
  │  Tier-0 │     │  appliedt│    │  → Mac      │  │  → Spawn     │  │          │
  └─────────┘     └─────────┘     └─────────────┘  └──────────────┘  └──────────┘
```

| Baustein | Was er tut | Ort im Repo |
|---|---|---|
| **D — Init-Slim** | Pflicht-Init halbiert auf `QUICK.md` + `INDEX.md` (vorher 5 Reads, jetzt 2). | `_memory/QUICK.md`, `CLAUDE.md` |
| **A — Cortex-Curator** | Liest Welle-Diff seit letztem Lauf, ruft Anthropic-API mit Pattern-Detector-Prompt, schreibt Vorschläge in `_memory/curator-queue.md`. Approval-Pump appliziert genehmigte Pattern-Vorschläge automatisch. | `tools/cortex-curator/` |
| **B — Telegram bidirektional** | Bot `@sanexio_bot` empfängt Slash-Befehle (`/help`, `/status`, `/spawn`, `/curator list`, `/pause`, `/pair`). Pairing-Mechanik bindet Mac an Chat. | `tools/telegram-bridge/` (V1 + neue lib/) |
| **C — Cortex-Cron** | macOS-LaunchAgents triggern zeitgesteuerte Spawns. Spawn-Watcher pollt Queue alle 30 s. spawn.sh kennt zwei Runner-Typen: `shell-script` (z. B. Curator) und `claude-headless` (Anthropic-API direkt). | `tools/cortex-cron/`, `_skripte/cortex-cron/` |

---

## 3. End-zu-End — was passiert, wenn du `/spawn` tippst

Ein konkretes Beispiel: du sitzt im Wartezimmer, willst wissen, ob über Nacht
neue Patterns aufgetaucht sind.

```
1. iPhone Telegram → @sanexio_bot:
       /spawn curator-nightly

2. Bridge V2 (lib/router.ts)
   - parsed `/spawn` als Slash-Befehl
   - prüft: ist Chat-ID gepaired für scope `spawn`?  → ja
   - dispatcht an handlers/spawn.ts

3. handlers/spawn.ts
   - validiert: existiert Recipe `curator-nightly.md`?  → ja
   - schreibt Spawn-Request in tools/cortex-cron/state/spawn-queue.json
   - antwortet im Telegram: „📥 Spawn eingereiht: SPAWN-...„

4. Cortex-Cron Watcher (Hintergrund-LaunchAgent, pollt 30 s)
   - findet pending entry → setzt status=running
   - ruft tools/cortex-cron/bin/spawn.sh --recipe curator-nightly

5. spawn.sh
   - acquired /tmp/cortex-autonomy.lock (verhindert Konflikt mit Live-Session)
   - mkdir _archive/autonomy/spawns/2026-05/SPAWN-.../
   - schreibt manifest.json
   - exec: tools/cortex-curator/bin/curator.sh --trigger cron

6. Curator-Pipeline
   - collect:   git diff seit last_git_sha   (Welle-Delta)
   - analyze:   POST api.anthropic.com/v1/messages mit pattern-detector-Prompt
                claude-sonnet-4-6, ~$0,05 pro Lauf
   - queue-write: schreibt 0–5 Vorschläge als [!vorschlag]-Callouts in
                _memory/curator-queue.md
   - aktualisiert state/last-run.json + state/queue-index.json

7. spawn.sh
   - schreibt summary.md
   - finished + exit_code in manifest.json
   - released Lock

8. Watcher
   - markiert spawn-queue.json: status=done, exit_code=0
```

Aktuelle Lücke (P6): Telegram-Push am Ende der Pipeline ist noch nicht
verdrahtet — du musst aktuell `/status` schicken um zu sehen, dass es fertig
ist.

---

## 4. Bedienung — die wichtigsten Telegram-Befehle

> Pairing einmalig nötig (siehe §5). Danach:

| Befehl | Was er macht |
|---|---|
| `/help` | Liste aller Befehle |
| `/status` | aktueller Stand: Lock-Status, Pause-State, Queue-Größen, gepairte Geräte |
| `/pause 2h` | Curator + alle Cron-Spawns für 2 Stunden aussetzen (Beispiel: `30m`, `1h`, `1d`) |
| `/resume` | Pause aufheben |
| `/curator list` | offene Lern-Vorschläge anzeigen (max 10) |
| `/spawn curator-nightly` | manuell den nächtlichen Curator-Lauf jetzt starten |
| `/spawn praxis-webseite "Cluster 7 prüfen"` | ad-hoc Headless-Claude-Session in einem Projekt anstoßen |
| `/pair 123456` | 6-stelligen Code aus `pair-init.sh` einlösen |

Plus die alten V1-Befehle:
- `yes <code>` / `no <code>` für Permission-Verdicts (wie bisher)
- `/start` als Begrüßung

---

## 5. Erstinbetriebnahme — was du **einmal** tun musst

### 5.1 LaunchAgents installieren (Cron-Jobs aktivieren)

```bash
cd ~/Cortex/Nexus
bash _skripte/cortex-cron/install-launchagents.sh
```

Das installiert drei Hintergrund-Jobs:
- `com.cortex.spawn-watcher` — läuft dauerhaft, pollt Queue alle 30 s
- `com.cortex.curator-nightly` — täglich 03:30
- `com.cortex.tagesbriefing` — täglich 09:00

Verify:
```bash
launchctl list | grep cortex
```

### 5.2 Pairing für dieses Mac-Gerät

Pro Mac einmalig — bindet die Telegram-Chat-ID an den Hostnamen.

```bash
cd ~/Cortex/Nexus
bash tools/telegram-bridge/bin/pair-init.sh
```

Output zeigt einen 6-stelligen Code (TTL 5 min). Den schickst du in Telegram an
`@sanexio_bot`:

```
/pair 823291
```

Bot antwortet mit „✅ Pairing erfolgreich. Mac: cluster-mini-02. Scopes:
spawn, curator, status, pause."

Auf dem zweiten Mac (MacPro Intel) wiederholst du die zwei Schritte —
denselben Telegram-Chat, anderer Hostname.

### 5.3 Optional: macOS coreutils

Für Hard-Limit-Schutz bei Spawns (sonst kein Timeout):
```bash
brew install coreutils
```
Damit ist `gtimeout` verfügbar, das spawn.sh automatisch nutzt.

### 5.4 Optional: API-Key prüfen

Liegt in `~/.cortex/secrets/anthropic-cron.env` (chmod 600). Spending-Cap
$20/Monat in console.anthropic.com.

---

## 6. Was der Curator selbstlernend tut

### 6.1 Trigger-Quellen

- **Cron 03:30 nachts** (Standard via LaunchAgent)
- **`/spawn curator-nightly` von Telegram** (manuell)
- **Direkt am Mac:** `tools/cortex-curator/bin/curator.sh`

### 6.2 Pipeline

```
collect → analyze → queue-write
```

- **collect** sammelt: `git diff` seit letztem Curator-Lauf, neue
  Session-Logs, aktueller QUICK.md + INDEX.md.
- **analyze** schickt das alles an Anthropic-API mit dem System-Prompt aus
  `tools/cortex-curator/prompts/pattern-detector.md`. Modell ist
  `claude-sonnet-4-6`. Antwort enthält 0–5 Vorschläge als JSON.
- **queue-write** rendert jeden Vorschlag als `[!vorschlag]`-Callout in
  `_memory/curator-queue.md` und aktualisiert `state/queue-index.json`.

### 6.3 Vorschlags-Typen

| Typ | Bedeutung | Auto-Apply? |
|---|---|---|
| **pattern** | Neues Lösungsmuster für `_memory/patterns/<slug>.md` | ✅ ja, sobald approved |
| **rule** | Vorschlag für eine neue LL-Regel in `GLOBAL_RULES.md` | ❌ Sicherheits-Stop, manuell |
| **memory_index** | Update an `MEMORY.md` oder `QUICK.md` | ❌ Sicherheits-Stop, manuell |
| **fehlerprotokoll** | Eintrag in `_rules/FEHLERPROTOKOLL.md` | ❌ TODO P6 |

### 6.4 Approval

Du hast zwei Wege:

**Im Vault (Obsidian):**
1. Öffne `_memory/curator-queue.md`
2. Finde den `[!vorschlag] PROP-...`-Block
3. Ändere `[ ] approve` zu `[x] approve`
4. Speichern

**Per Telegram (kommt P5b):**
```
/curator approve PROP-2026-05-03-02
```

Dann am Mac:
```bash
cd ~/Cortex/Nexus
bash tools/cortex-curator/bin/curator-apply.sh
```

Apply liest die Approve-Markierungen, schreibt Pattern-Dateien, macht
**pro Vorschlag einen separaten Git-Commit** mit Co-Author
`cortex-curator <noreply@autonomy.local>`. Sicherheits-Stop bei
`rule`/`memory_index`/`fehlerprotokoll` — die siehst du im Output und
entscheidest manuell.

### 6.5 Erstlauf-Beispiel (real, 2026-05-03)

In der Sprint-E-Session hat der Curator bei seinem ersten Echt-Lauf 5
Vorschläge generiert — und einen davon war: *„queue-index-felder-nicht-befuellt"*
— ein Bug, den der Curator in seiner eigenen Bootstrap-Pipeline entdeckt hat.

Selbstreferenzielle Lern-Schleife funktioniert.

---

## 7. Sicherheit und Grenzen

### 7.1 Trust-Tiers (siehe Tutorial 04)

- **Tier 1** (`~/Cortex/**`): vollautonom — Sprint E baut hier.
- **Tier 2** (lokal extern): unverändert.
- **Tier 3** (Push, Geld, Drittsystem, Live-Deploy): **bleibt** Strategie-Stop.

Cortex Autonomy v2 ist **vollständig Tier 1** — keine destruktiven Git-Ops,
keine Pushes, keine Live-Deploys. Der API-Verbrauch (Anthropic) ist via
Spending-Cap $20/Monat hard begrenzt.

### 7.2 Pairing schützt vor fremden DMs

- 6-stelliger Code, TTL 5 min, Single-Use
- Lockout: 3 Fehlversuche in 10 min → Chat-ID 10 min gesperrt
- Codes nur in `state/pending_codes.json` (chmod 0600), nie in Logs

### 7.3 Lock-File

`/tmp/cortex-autonomy.lock` schützt vor:
- doppeltem Curator-Lauf parallel
- Spawn während du live arbeitest

Sub-Prozesse (z. B. Curator innerhalb eines Spawn) erkennen den Parent-Lock
über die Env-Variable `CORTEX_SPAWN_PARENT_LOCK` und überspringen ihre
eigene Lock-Prüfung.

### 7.4 API-Key

`~/.cortex/secrets/anthropic-cron.env`:
- `chmod 600` (nur dein User-Account lesbar)
- Niemals in Git (kein Verzeichnis-Symlink in `~/Cortex/`)
- Bei Verdacht: `console.anthropic.com` → API Keys → Revoke

---

## 8. Troubleshooting

| Symptom | Ursache | Fix |
|---|---|---|
| `/spawn` antwortet „❌ Nicht autorisiert" | Chat-ID nicht gepaired oder Scope fehlt | Pairing wiederholen (§5.2) |
| Spawn-Run mit `exit 127` und `timeout: command not found` | macOS hat kein `timeout` | `brew install coreutils` |
| Curator-Lauf produziert 0 Vorschläge | `last_git_sha` == HEAD, kein Diff | Normal nach frischem Lauf. Mit `--force` erzwingen. |
| Curator-Lauf produziert 0 Vorschläge bei großem Diff | `output_tokens=8192` erschöpft | Diff war zu groß. `DIFF_LIMIT_BYTES=30000 ...curator.sh` setzen. |
| Apply meldet „Pattern-Datei existiert bereits" | Vorschlag schon mal applied | Status auf `applied` ist korrekt. Vault-Markierung `[x] approve` kann manuell entfernt werden. |
| Bridge polled doppelt von zwei Macs | Telegram-Polling-Konflikt (F9 in Spec) | Default F9b: nur cluster-mini-02 als Master. Andere Bridges bleiben aus oder pullen über Mesh. |
| Lock bleibt nach Crash stehen | `spawn.sh`-Prozess hart beendet | Manuell: `rm /tmp/cortex-autonomy.lock`. Lock-Datei enthält Expiry-TS, sollte sich selbst regenerieren — wenn nicht, Bug-Report. |

---

## 9. Cron-Recipes — was wann läuft

`tools/cortex-cron/recipes/`:

| Recipe | Schedule | Runner | Was |
|---|---|---|---|
| `curator-nightly.md` | täglich 03:30 | shell-script | Curator-Pipeline einmal komplett |
| `tagesbriefing.md` | täglich 09:00 | claude-headless | kompaktes Briefing zum Tagesstart, Push an Telegram |
| `drift-audit.md` | sonntags 04:00 | claude-headless | Sync-Health, Cap-Verletzungen, stale-Bridges |
| `_template.md` | — | — | Vorlage für neue Recipes |

Eigenes Recipe anlegen:
1. Kopiere `_template.md` → `<dein-name>.md`
2. Setze Frontmatter: `runner`, `schedule` (cron-Format), `tier`, `max_runtime_sec`
3. Bei `runner: claude-headless`: schreibe System-Prompt im Body
4. Bei `runner: shell-script`: setze `command:`-Feld
5. Plist anlegen in `_skripte/cortex-cron/com.cortex.<name>.plist`
6. `bash _skripte/cortex-cron/install-launchagents.sh`

---

## 10. Multi-Device — wie sich das auf SSMD-MacBookPro verhält

Sprint E ist primär auf **Cluster-Mini-02** lauffähig. Für die anderen Macs:

| Komponente | Cluster-Mini-02 | SSMD-MacBookPro | Mac-Studio |
|---|---|---|---|
| **Nexus-Repo (Code + Specs + Tools)** | aktuell | aktuell (auto-sync via Cron alle 5 min) | aktuell |
| **`~/.cortex/secrets/anthropic-cron.env`** | gesetzt | ⚠️ noch zu kopieren (manuell, nie syncen) | wie SSMD |
| **LaunchAgents** | nach `install-launchagents.sh` aktiv | muss separat ausgeführt werden | dito |
| **Telegram-Pairing** | gepaired | muss separat pairen (eigener Code) | dito |
| **Bridge-Polling** | Master (Default F9b) | empfangs-only über Mesh (kommt v3) | dito |

Heißt: Wenn du den MacPro Intel jetzt einschaltest, hast du **das Tutorial und
den Code**, aber für Aktivierung der Cron + Telegram dort brauchst du:
1. `bash _skripte/cortex-cron/install-launchagents.sh`
2. API-Key-Datei kopieren (über Tailscale-`scp` o. ä., **nie über Git**)
3. `bash tools/telegram-bridge/bin/pair-init.sh` + `/pair <code>` auf iPhone

---

## 11. Was kommt als nächstes (P6 — Härtung)

Offene Punkte aus der Übergabe in
`Nexus/_memory/logs/2026-05-03_sprint-e-p1-bis-p5.md`:

1. **Vault-Lifecycle nach Apply** — `[x] approve` zu `[v] applied` ändern, sonst
   re-Apply jedes Mal
2. **ID-Eindeutigkeit über Curator-Läufe** — `PROP-YYYY-MM-DD-NN` ist nur pro
   Lauf eindeutig, sollte global sein
3. **Telegram-Push am Spawn-Ende** — spawn.sh schreibt Summary, sendet sie aber
   nicht
4. **Tier-2-Recipe-Eskalation** (F7a) — pro Lauf Telegram-Approval
5. **Cross-Host-Spawn via Mesh** (F6/F9b) — ad-hoc Spawn von iPhone auf
   spezifischen Mac

Diese Punkte können einzeln als kleine Sprints E2.x gemacht werden.

---

## 12. Architektur-Referenz

| Was | Pfad |
|---|---|
| Master-Spec | `Nexus/specs/cortex-autonomy-v2/SPEC.md` (~840 Zeilen) |
| Spec-Übersicht | `Nexus/specs/cortex-autonomy-v2/README.md` |
| Curator-Tool | `Nexus/tools/cortex-curator/` |
| Cron-Tool | `Nexus/tools/cortex-cron/` |
| Bridge-Erweiterung | `Nexus/tools/telegram-bridge/lib/` (handlers, router, pairing, store, audit) |
| LaunchAgent-plists | `Nexus/_skripte/cortex-cron/com.cortex.*.plist` |
| Curator-Queue (Vault) | `Nexus/_memory/curator-queue.md` |
| Session-Logs | `Nexus/_memory/logs/2026-05-03_sprint-e*.md` |
| Tier-0-Memory | `Nexus/_memory/QUICK.md` |
| Top-Regeln | `Nexus/_rules/INDEX.md` (LL-061 = Init-Slim) |
| API-Key | `~/.cortex/secrets/anthropic-cron.env` (chmod 600, **nie syncen**) |

---

## 13. Goldene Lehrsätze aus Sprint E

1. **„Selbstlernen" heißt nicht „selbst entscheiden".** Curator schlägt vor,
   du approvest. Kein Vorschlag wird ohne menschliche Markierung appliziert.
2. **Pattern vor Code.** Wir haben OpenClaw + Hermes Patterns übernommen, nicht
   Code — weil Claude Code unsere Runtime ist, nicht Python.
3. **Idempotenz ist Pflicht.** Jeder Curator-Lauf trägt seinen `last_git_sha`,
   jeder Spawn seine `id`, jede Apply einen `status: applied`. Doppel-Läufe
   sind no-ops.
4. **Lock vor Edit.** `/tmp/cortex-autonomy.lock` schützt MEMORY/RULES vor
   gleichzeitigen Schreibern.
5. **Sicherheits-Stop ist gut.** Apply schreibt Patterns automatisch, aber
   Regeln und MEMORY-Edits bleiben manuell — bewusste Verzögerung statt
   schnelle Fehler.

---

> **Wenn du dieses Tutorial liest und etwas funktioniert nicht wie beschrieben:**
> melde es per `[!frage]`-Callout in `Second Brain/00 Kontext/Dialog.md` (LL-045)
> oder direkt im nächsten Cortex-Chat. Tutorial wird gepflegt.
