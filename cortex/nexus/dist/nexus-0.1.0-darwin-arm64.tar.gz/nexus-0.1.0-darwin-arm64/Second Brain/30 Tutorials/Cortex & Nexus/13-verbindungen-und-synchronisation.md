---
type: tutorial
aliases: [Verbindungen, Synchronisation, GitHub-Sync, Tailscale-Mesh, Sync-Architektur, Multi-Device-Sync]
tags: [tutorial, cortex, nexus, cortex-web, sync, multi-device, network, github, tailscale, deep-dive]
---

# 13 — Verbindungen und Synchronisation (Cortex-Web + Nexus, vollumfänglich)

> Voraussetzung: Modul 01 (Architektur), Modul 02 (Multi-Device-Setup),
> Terminal-Grundlagen, Git-Grundbegriffe.
> Lesezeit: 35–45 Min. Praktischer Wert: einmal hier durchgehen, dann
> verstehst du jeden Sync-Vorfall ohne Rückfrage.
> Ziel: Du kennst jede Schicht der Sync-Architektur (Hardware → Netzwerk
> → Git → Automation), weißt wo welche Daten fließen, kannst Bugs
> diagnostizieren, und kennst die strukturellen Gründe für jede
> Designentscheidung.

---

## 0. Das Big Picture in einem Satz

> **GitHub ist der Sync-Hub. Tailscale ist das Backbone für Direct-Access.
> Beide sind getrennte Welten — Synchronisation passiert **ausschließlich**
> über GitHub, niemals direkt zwischen den Macs.**

Wenn du dir das einprägst, fällt 90 % der Architektur-Verwirrung weg.

---

## 1. Drei Schichten — wer macht was?

Die Multi-Device-Maschinerie besteht aus drei klar getrennten Schichten:

| Schicht | Komponente | Aufgabe | Beispiel |
|---|---|---|---|
| **1. Netzwerk** | Tailscale Mesh (`piranha-marlin.ts.net`) | Macs erreichen sich gegenseitig per IP, auch hinter NAT/Router | `ssh ssmd@100.127.125.48` |
| **2. Storage** | Git + GitHub (`Sanexio/nexus`, `Sanexio/cortex-web`) | Single Source of Truth für Files. Versioniert, konfliktbewusst. | `git pull --ff-only` |
| **3. Automation** | launchd-Jobs (`nexus-sync.sh`, `cw-mirror-sync.sh`) | Halten lokale Repos automatisch mit GitHub synchron | alle 5 Minuten Cron-like |

**Wichtig:** Synchronisation läuft **immer durch Schicht 2 (Git/GitHub)**.
Schicht 1 (Tailscale) wird **nur für SSH/Direct-Access** genutzt — z.B.
„ich logge mich auf Cluster-Mini-02 ein und schaue dort manuell nach".
**Es gibt keinen direkten File-Sync zwischen zwei Macs** (kein
rsync-Cron, kein syncthing). Das ist eine bewusste Architektur-
Entscheidung: GitHub erzwingt Konflikt-Bewusstsein (Pull-Rebase oder
explizites Merge), während Direkt-Sync schleichende Drift produzieren
würde.

---

## 2. Die zwei Repos — wer hält was?

### 2.1 `Sanexio/nexus` (privates GitHub-Repo)

Pfad lokal: `~/Cortex/Nexus/`

Inhalt:

- `CLAUDE.md`, `_rules/`, `_memory/`, `_projects/`, `_tutorials/` —
  das ganze Kontext- und Wissens-Backbone für Claude
- `agent/` (Hermes-style Loop, Python 3.14), `gateway/`
  (OpenClaw-style TypeScript/Bun, Telegram-V3)
- `tools/cortex-mode/`, `nexus-sync.sh`, `scripts/cortex-converge.sh`
- `.config/devices.json` — **Single Source of Truth** für „welche Macs
  gibt es, welche Rolle, welche Tailscale-IP, welche Projekte"
- `Second Brain/` (Obsidian-Vault, Wissens-Anker)

Was **nicht** im Nexus-Repo ist:

- `~/Cortex/projects/` — diese sind **gerätespezifisch** und liegen je
  Projekt in **eigenen** Repos (siehe nächster Abschnitt).
- `~/.claude/` (CLI-Konfig), `~/Library/LaunchAgents/`, Lokale Secrets.
- `_memory/memory.db` — SQLite-FTS5-DB (`.gitignore`'d).

### 2.2 `Sanexio/cortex-web` (privates GitHub-Repo)

Pfad lokal: `~/Cortex/projects/Cortex-Web/`

Inhalt:

- `trunk/` — gemeinsame Substanz: Produktdaten, Team-Infos, Design-Tokens
- `sites/praxis-webseite/` — WordPress + Blocksy-Child-Theme
  „praxiszentrum" für `westend-hausarzt.com`
- `sites/juvantis-webseite/` — Shopify-Theme-Quelle für `sanexio.eu`
- `tools/` — u.a. `cw-mirror-sync.sh`, Promotion-Skripte
- `_rules/`, `_config/RULES.md` (CW-001…CW-009)

Cortex-Web ist also **kein** Sub-Verzeichnis von Nexus, sondern ein
**Schwester-Projekt**. Beide leben nebeneinander unter `~/Cortex/`,
beide sind unabhängige GitHub-Repos.

### 2.3 Weitere Projekt-Repos

Geräte-spezifische Projekte (z.B. `Desk`, `Praxis-QM`, `file-renamer`,
`smartq-dashboard`, Juvantis-iOS-App, telegram-bridge) liegen **nicht**
in Nexus oder Cortex-Web — jedes hat sein eigenes Repo oder ist nur
lokal. Welcher Mac welches Projekt hostet, steht in `devices.json`.

---

## 3. GitHub als Sync-Hub — was bedeutet das konkret?

Stell dir GitHub als **zentrales Postamt** vor. Jeder Mac:

1. holt Pakete (Commits) ab → `git pull` / `git fetch`
2. liefert Pakete ab → `git push`

Die Macs reden **nie direkt miteinander** über die Repo-Inhalte. Wenn
Cluster-Mini-02 etwas im Nexus ändert und SSMD-MacBookPro-M5 es sehen
soll, ist der Weg:

```
Cluster-Mini-02
   │
   │ git push origin main   (lokaler Commit nach GitHub)
   ▼
┌──────────────────────────┐
│  GitHub: Sanexio/nexus    │   ← Single Source of Truth
└──────────────────────────┘
   ▲
   │ git pull --ff-only     (Mac holt Update ab)
   │
SSMD-MacBookPro-M5
```

**Konsequenz:** Wenn GitHub kurz weg ist, kann nichts synchronisieren —
selbst wenn beide Macs im selben WLAN stehen. Das ist okay, weil
GitHub praktisch nie down ist und das System „eventual consistency"
liefert: spätestens wenn GitHub wieder da ist, gleichen sich die Macs
ab.

---

## 4. Tailscale-Mesh — wofür ist das gut?

### 4.1 Was Tailscale **nicht** ist

- **Kein File-Sync.** Tailscale überträgt keine Datei automatisch
  zwischen Macs.
- **Kein Replacement für GitHub.** Wenn Tailscale aus ist, läuft der
  GitHub-Sync trotzdem (solange das Internet steht).

### 4.2 Was Tailscale **ist**

- Ein **WireGuard-basiertes Overlay-Netz** (kommerzielles Produkt),
  das jedem Mac eine private IP im `100.x.x.x`-Bereich gibt
  (CGNAT-Range, nur intern routbar).
- Macs sind füreinander erreichbar, **auch wenn sie hinter
  unterschiedlichen NATs/Routern sitzen** (z.B. Praxis-Mac im
  Praxis-LAN, Cluster-Mini im Home-WLAN). Tailscale baut bei Bedarf
  einen direkten verschlüsselten Tunnel auf; wenn das NAT-Traversal
  scheitert, läuft der Traffic über einen Tailscale-„DERP"-Relay-Server.
- Tailnet-Name dieser Installation: **`piranha-marlin.ts.net`**
  (Personal-Plan vergibt Random-Namen; „cortex" war nicht wählbar).

### 4.3 Wofür wir Tailscale **tatsächlich** brauchen

- **SSH zu anderen Macs** für manuelle Eingriffe, Statuschecks,
  Debugging:
  ```bash
  ssh ssmd@100.127.125.48        # Cluster-Mini-02
  ssh ssmd@100.121.230.9         # SSMD-MacBookPro (Intel)
  ssh ssmd@100.93.193.44         # SSMD-MacBookPro-M5
  ssh ssmd@100.119.241.21        # Mac-Studio (praxis-studio)
  ssh ssmd@100.80.43.49          # Cluster-Mini-04
  ```
- **Remote-Desktop** zu Macs in der Praxis vom iPad aus
  (siehe Modul 10 „iPad Remote Desktop").
- **`localhost:`-Dienste eines Macs auf einem anderen erreichen**
  (Local-Flywheel, lokale Dev-Server, Connexio-HTTP).

### 4.4 Mac-Mesh-Übersicht (aus `devices.json`, Stand 2026-05-26)

| Hostname | Tailscale-Hostname | Tailscale-IP | Rolle |
|---|---|---|---|
| `Cluster-Mini-02` | `cluster-mini-02` | `100.127.125.48` | home (M2, primary für Cortex-Web) |
| `Cluster-Mini-04` | `cluster-mini-04` | `100.80.43.49` | home (M2) |
| `SSMD-MacBookPro` | `ssmd-macbookpro-intel` | `100.121.230.9` | praxis (Intel i7) |
| `SSMD-MacBookPro-M5` | `ssmd-macbookpro-m5` | `100.93.193.44` | praxis-mobile (M5 Pro) |
| `Mac-Studio-von-MacStudioZi2` | `praxis-studio` | `100.119.241.21` | praxis-studio (Apple Silicon) |

### 4.5 Magic-DNS — funktioniert hier oft nicht

In Theorie sollten Tailscale-Hostnamen direkt als FQDN auflösen:

```
ssh ssmd@cluster-mini-02.piranha-marlin.ts.net
```

In der Praxis funktioniert das auf einigen Macs nicht — der lokale
macOS-Resolver kennt die Tailnet-Suchdomain nicht oder Magic-DNS ist
aus. Workaround: **immer Tailscale-IPs direkt nutzen** (`100.x.x.x`),
die sind unabhängig von DNS. Wenn auch das scheitert, helfen `tailscale
ping <host>` (Diagnose) und `tailscale status` (Mesh-Übersicht).

### 4.6 Wichtige Tailscale-Befehle

```bash
# Mesh-Übersicht: wer ist da, wer online?
tailscale status

# Latenz zu einem Peer messen (direkt oder via Relay?)
tailscale ping cluster-mini-02

# Meine eigene Tailscale-IP
tailscale ip -4

# Wer bin ich im Tailnet?
tailscale whois 100.93.193.44
```

**Erklärung der Tailscale-Befehle:**

- `tailscale status` — Befehl `tailscale`, Subcommand `status`. Gibt
  pro Peer eine Zeile: `IP Hostname Tags OS Connection`.
- `tailscale ping <host>` — wie ICMP-Ping, aber **innerhalb des Mesh**.
  Zeigt, ob die Verbindung **direkt** läuft (`direct: 12ms via
  192.168.x.x:41641`) oder über einen DERP-Relay (`via DERP(fra)`).
  Direkt ist schneller, DERP ist Fallback bei NAT-Problemen.
- `tailscale ip -4` — `-4` = IPv4-Adresse. (Auch IPv6 möglich mit `-6`.)
- `tailscale whois <ip>` — gibt Hostname und Tags zur IP zurück, nützlich
  zum Aufdröseln eines Verbindungs-Logs.

---

## 5. Auto-Sync für Nexus — `nexus-sync.sh` im Detail

### 5.1 Wer triggert das Skript?

`launchd` (macOS-Service-System) startet `nexus-sync.sh` alle **300
Sekunden** (= 5 Minuten) auf jedem Mac. Die plist-Datei sitzt unter:

```
~/Library/LaunchAgents/com.cortex.nexus-sync.plist
```

Inhalt (Kern):

```xml
<key>ProgramArguments</key>
<array>
    <string>/bin/bash</string>
    <string>-c</string>
    <string>"$HOME/Cortex/Nexus/nexus-sync.sh"</string>
</array>
<key>StartInterval</key>
<integer>300</integer>
<key>RunAtLoad</key>
<true/>
```

**Erklärung der plist-Felder:**

- **`Label`** — eindeutiger Job-Name, hier `com.cortex.nexus-sync`. Mit dem
  Label spricht man den Job per `launchctl` an.
- **`ProgramArguments`** — was wird ausgeführt. Hier `/bin/bash -c "..."`
  statt das Skript direkt, damit `$HOME` und andere Shell-Variablen
  expandiert werden.
- **`StartInterval` 300** — alle 300 Sekunden ausführen. Alternative
  wäre `StartCalendarInterval` mit festen Zeiten oder `WatchPaths` mit
  File-Trigger.
- **`RunAtLoad true`** — beim Laden des Jobs (oder Mac-Start) direkt
  einmal ausführen, nicht erst nach 5 Minuten warten.
- **`StandardOutPath`/`StandardErrorPath` /dev/null** — Fallback. Das
  Skript leitet seine eigene Ausgabe nach `_memory/logs/nexus-sync.log`.

### 5.2 Was tut `nexus-sync.sh` Schritt für Schritt?

Das Skript ist 700+ Zeilen Bash und macht in jedem Lauf folgendes:

**Phase 0.1 — Initialisierung:** Prüfe ob `~/Cortex/Nexus` ein Git-Repo
ist, ob GitHub erreichbar ist (`git ls-remote --exit-code origin`).
Wenn offline → still abbrechen (kein Drama, beim nächsten Lauf nochmal).

**Phase 0.2 — Heartbeat-Check (siehe Abschnitt 6):** Frage über
ephemere Refs, ob ein anderer Mac in den letzten 90 Sekunden aktiv
war. Wenn ja → diesen Lauf skippen (verhindert Multi-Writer-Konflikte).

**Phase 0.3 — Slash-Command-Self-Heal:** Kopiere
`tools/cortex-mode/commands-template/*.md` nach `~/.claude/commands/`,
falls Drift. Stellt sicher, dass `/autonomy-mode`, `/safe-mode`,
`/cortex-mode` immer funktionieren.

**Phase 0.4 — Divergenz-Check + Aktive Konvergenz:**

```bash
git fetch origin main
LOCAL_HEAD=$(git rev-parse HEAD)
REMOTE_HEAD=$(git rev-parse origin/main)
MERGE_BASE=$(git merge-base HEAD origin/main)
```

Drei Fälle, drei Befehle. **Erklärung:**

- `git fetch origin main` — holt den aktuellen `main`-Stand vom Remote
  in `origin/main`, **ohne** ihn lokal zu mergen. Reine Read-Op.
- `git rev-parse HEAD` — was ist der lokale aktuelle Commit (SHA)?
- `git rev-parse origin/main` — was ist der Stand des Remote-Branches?
- `git merge-base HEAD origin/main` — was ist der **letzte gemeinsame
  Vorfahre** beider Branches?

Daraus ergeben sich drei mögliche Zustände:

| Zustand | Bedingung | Bedeutung |
|---|---|---|
| **In-sync** | `LOCAL == REMOTE` | Alles gleich, nichts zu tun |
| **Lokal hinter** | `LOCAL == MERGE_BASE && REMOTE != MERGE_BASE` | Remote hat Commits, die lokal fehlen → `pull` kann fast-forwarden |
| **Lokal voraus** | `REMOTE == MERGE_BASE && LOCAL != MERGE_BASE` | Lokal hat eigene Commits, die Remote nicht hat → später `push` |
| **Divergent** | beide haben eigene Commits nach `MERGE_BASE` | Konflikt-Potential → Auto-Konvergenz versuchen |

Wenn divergent: Das Skript versucht `git pull --rebase --autostash
origin main`. **Auseinandergenommen:**

- `--rebase` — statt Merge-Commit zu erzeugen, „spult" Git deine lokalen
  Commits auf den Remote-Stand drauf.
- `--autostash` — eventuelle uncommittete Änderungen werden **vor**
  dem Rebase weg-gestashed, danach automatisch wieder eingespielt.
  Wichtig, weil zwischen Heartbeat-Write (Phase 0.2) und Commit (Phase
  1) das Heartbeat-File „dirty" sein könnte. **Ohne `--autostash`
  bricht der Rebase mit „unstaged changes" ab** (Vorfall M5 2026-05-19,
  9 h Stillstand → Anker für die Regel).

Bei Konflikt im Rebase prüft das Skript, ob alle Konflikt-Dateien
**auto-generiert** sind (DASHBOARD, Logs, Drift-Reports, …). Falls ja
→ `git checkout --ours <file>` + `git add` + `git rebase --continue`
(„Auto-Resolve"). Falls **echter** Inhaltskonflikt → `git rebase
--abort` und Alarm (siehe Phase 5.7).

**Phase 0.5 — Second-Brain-Sync:** Ein Python-Skript hält den
Obsidian-Vault `Second Brain/` mit den Tutorials/Projekt-Markdowns
synchron.

**Phase 0.6 — Task-Lock-Hinweis:** Wenn aktive R2-Tasks (Architektur-
Änderungen) laufen, ins Log schreiben. Soft-Info.

**Phase 1 — Auto-Commit (Whitelist-gefiltert):**

```bash
git status --porcelain  # nimmt jede geänderte Datei
# für jede Datei: ist sie in der AUTO_ADD_WHITELIST?
# wenn ja → committen, wenn nein → ignorieren (User muss manuell)
```

Die Whitelist umfasst (Stand 2026-05-26):

- `_memory/logs/*.log` / `*.err`
- `_memory/pending-questions.md` / `pending-instructions.md`
- `_memory/health/sync-drift.json`
- `Second Brain/00 Kontext/Dialog.md`
- `Second Brain/10 Projekte/*.md`
- `Second Brain/30 Tutorials/_MOC Tutorials.md`
- `Second Brain/40 Regeln/_MOC Regeln.md`

**Warum eine Whitelist?** Vorfall am 2026-04-26: ohne Whitelist hat
der Auto-Sync alte lokale Inhaltsversionen blind committet und gepusht
(„Phantom-Modifications"). Seitdem darf der Auto-Commit **nur** diese
Pfade anfassen. Alles andere bleibt uncommitted und löst beim
nächsten Drift-Check eine Warnung aus, wenn es länger als ein paar
Läufe liegen bleibt.

Wichtig: Der Commit nutzt **explizite Pathspecs**:

```bash
git commit -- "${WHITELISTED_PATHS[@]}"
```

Das committet **genau** diese Pfade aus der Working-Copy, **unabhängig
vom Staging-Status anderer Files**. Verhindert, dass ein paralleler
User-Workflow (`git add A B; git commit ...`) vom Auto-Sync vereinnahmt
wird.

**Phase 2 — Defensiver Pull:**

```bash
git pull --rebase --autostash origin main
```

Sollte nach erfolgreicher Phase 0.4-Konvergenz ein No-Op sein.
Defensiver Doppelt-Check.

**Phase 2b — Approval-Marker-Check (R2-Pfade):** Wenn der lokale
Branch Commits enthält, die R2-Pfade ändern (regex matcht
`_rules/`, `specs/`, `CLAUDE.md`, `agent/`, `gateway/`, `tools/`,
`nexus-sync.sh`), erwartet das System einen Approval-Marker unter
`_memory/approvals/`. Default-Modus: nur loggen. Mit
`touch _memory/approvals/.enforce` wird der Push hart gestoppt, falls
kein Marker existiert. Schutz vor versehentlichen Architektur-
Änderungen ohne User-Freigabe.

**Phase 3 — Push:**

```bash
git push origin main --quiet
```

Pusht alle lokalen Commits nach GitHub.

**Phase 4 — Heartbeat erneuern (siehe Abschnitt 6).**

**Phase 4b — Drift-Report:** Zählt uncommittete Dateien außerhalb der
Whitelist. Bei mehr als 5 → Warnung im Log und in
`_memory/logs/drift-pending-manual.log`.

**Phase 4c — Health-JSON schreiben:** Maschinenlesbarer Sync-Snapshot
nach `_memory/health/sync-drift.json`. Wird vom Doctor-Skript gelesen.

**Phase 5 — `.last_sync_local`:** Inline-Python aktualisiert
`.config/.last_sync_local` mit Timestamp und Hostname.

**Phase 6 — Heartbeat-Migrations-Cleanup:** Temporäres Skript, das
das eigene getrackte Heartbeat-File aus main entfernt (Übergangsphase
2026-05-24). Wenn alle Macs migriert sind, kann der ganze Block raus.

**Phase 7 — Self-Applying Konvergenz:**

```bash
scripts/cortex-converge.sh
```

Prüft idempotent, ob dieser Mac dem Kollektiv-Soll entspricht
(Cortex-Web geklont? launchd-Jobs installiert? …). Konvergenz-Schritte
sind im Skript-Manifest gepflegt. Fehler hier blockieren den Sync
nicht — nur loggen.

### 5.3 Anti-Spam-Alarm-Mechanismus

Wenn echte Divergenz vorliegt:

1. macOS-Notification (`osascript -e 'display notification ...'`).
2. Telegram-Alarm (über die Bot-API, Bot-Token aus
   `tools/telegram-bridge/.env`).
3. Marker-File `_memory/.divergence-alarmed` setzen.

Der Marker verhindert, dass der nächste 5-Minuten-Lauf erneut alarmiert
— der Alarm ist `ALARM_REPEAT_SECONDS` (Default 3600 s = 1 h) lang
stumm. Nach Ablauf wird der Alarm einmal **wiederholt** („DIVERGENZ
PERSISTIERT"), damit langlebige Drift nicht stundenlang verschwiegen
wird (Vorfall M5 2026-05-13).

---

## 6. Heartbeat-Refs — wie wissen Macs voneinander?

### 6.1 Das Problem

Mehrere Macs laufen parallel den `nexus-sync.sh` alle 5 Minuten. Wenn
zwei Macs **gleichzeitig** versuchen, ein File zu committen, gibt es
einen Push-Race. Lösung: **Heartbeats** — jeder Mac signalisiert „ich
bin gerade aktiv", andere Macs sehen das und skippen.

### 6.2 Die Lösung früher (bis 2026-05-24): File-Heartbeats

Jeder Mac schrieb `.config/heartbeats/<hostname>.heartbeat` (Unix-
Timestamp als Inhalt) und committete das per Auto-Sync. **Problem:**
~700 Commits/Tag, die nur Heartbeat-Timestamps enthielten — die ganze
Git-Historie war Heartbeat-Müll. Plus: Multi-Writer-Konflikte, wenn
zwei Macs simultan ihre Heartbeats committeten.

### 6.3 Die Lösung jetzt (seit 2026-05-24): Heartbeat-Refs

Statt File-Commits auf `main` nutzt jeder Mac einen **eigenen
Git-Ref** außerhalb von `main`:

```
refs/heartbeats/cluster-mini-02
refs/heartbeats/ssmd-macbookpro-m5
refs/heartbeats/praxis-studio
…
```

Jeder Ref enthält einen **parent-losen Commit** (keine Historie), dessen
Commit-Message der Unix-Timestamp ist. Schreiben:

```bash
git commit-tree $(git hash-object -t tree /dev/null) -m "$timestamp"
git push --force origin "$commit_sha:refs/heartbeats/$hostname"
```

**Auseinandergenommen:**

- `git hash-object -t tree /dev/null` — erzeugt das SHA des **leeren
  Tree-Objekts**. `/dev/null` als Input = leere Datei. Wir wollen
  keinen Inhalt, nur einen Commit als „Timestamp-Träger".
- `git commit-tree <tree-sha> -m "<message>"` — erzeugt einen Commit
  **ohne Parent** (low-level Git-Befehl, normalerweise versteckt
  hinter `git commit`). Output: SHA des neuen Commits.
- `git push --force origin "$sha:refs/heartbeats/$host"` — pusht den
  Commit-SHA direkt auf den genannten Remote-Ref. **`--force`** ist
  hier nicht gefährlich, weil **jeder Mac nur seinen eigenen Ref
  schreibt** (`refs/heartbeats/<hostname>` enthält den Hostname).

Lesen:

```bash
git fetch -q origin '+refs/heartbeats/*:refs/heartbeats/*'

# Für jeden anderen Mac:
other_time=$(git log -1 --format=%s "refs/heartbeats/$other_host")
age=$((NOW - other_time))
if [ $age -lt 90 ]; then
    # Anderer Mac war in den letzten 90 s aktiv → diesen Lauf skippen
fi
```

**Auseinandergenommen:**

- `git fetch -q origin '+refs/heartbeats/*:refs/heartbeats/*'` —
  holt alle Heartbeat-Refs vom Remote. Das `+` am Anfang = „force
  update" (überschreibe lokale Refs, falls sie divergent sind). `-q`
  = quiet, keine Ausgabe.
- `git log -1 --format=%s "refs/heartbeats/$other_host"` —
  `-1` = nur 1 Commit, `--format=%s` = nur die Subject-Zeile
  (= unser Timestamp). So liest man den Timestamp aus dem Commit, ohne
  irgendeine Datei zu materialisieren.

**Vorteile gegenüber File-Heartbeats:**

- **Kein Müll in `main`** — Heartbeats sind außerhalb der Branch-Historie.
- **Kein Multi-Writer-Konflikt** — jeder Mac schreibt nur seinen
  eigenen Ref.
- **Server-side GC** — alte Heartbeat-Commits werden von GitHub
  garbage-collected, weil sie unreachable sind (`--force` macht die
  alten Commits unreferenced).
- **Unsichtbar für `git log main`** — kein Noise.

### 6.4 Lokaler Lese-Cache

Für Werkzeuge, die schnell ohne `git fetch` lesen wollen (Gateway,
Doctor-Skript), materialisiert das Sync-Skript den Heartbeat auch als
**File** unter `.config/heartbeats/<host>.heartbeat`. Diese Files sind
in `.gitignore` (auf migrierten Macs) und werden nach jedem Fetch
neu geschrieben. Keine Quelle der Wahrheit, nur Cache.

---

## 7. Cortex-Web-Mirror-Sync — `cw-mirror-sync.sh`

### 7.1 Warum ein eigener Sync?

Cortex-Web hat eine **andere Anforderung** als Nexus:

| | Nexus | Cortex-Web |
|---|---|---|
| Bearbeitet auf | jedem Mac | meist Cluster-Mini-02 oder Mac-Studio |
| Auto-Commit | ja (Whitelist) | **nein** |
| Auto-Push | ja | **nein** |
| Rolle der anderen Macs | gleichberechtigte Editoren | **Mirror** (nur lesen) |

Cortex-Web wird per **Konvention** nur von einem Mac gleichzeitig aktiv
bearbeitet — siehe Regel CW-009 in `Cortex-Web/_config/RULES.md`. Die
anderen Macs halten nur den aktuellen Stand bereit, damit jederzeit
**Promotion** möglich ist (z.B. ein nützliches Tool aus `~/Cortex/
projects/file-renamer/` in den Cortex-Web-Trunk übernehmen, direkt
vom lokalen Mac aus).

### 7.2 Was tut `cw-mirror-sync.sh`?

```bash
DIRTY=$(git status --porcelain | head -1)
if [ -n "$DIRTY" ]; then
    echo "active-edit" > .cw-mirror-state
    exit 0     # SKIP, hier wird gerade bearbeitet
fi

git fetch --quiet origin main

LOCAL=$(git rev-parse HEAD)
REMOTE=$(git rev-parse origin/main)
BASE=$(git merge-base HEAD origin/main)

if [ "$LOCAL" = "$REMOTE" ]; then
    echo "in-sync $(date)" > .cw-mirror-state   # alles ok
elif [ "$LOCAL" = "$BASE" ]; then
    git merge --ff-only origin/main             # fast-forward
elif [ "$REMOTE" = "$BASE" ]; then
    echo "local-ahead" > .cw-mirror-state       # bin der aktive Mac, brauche Push
else
    echo "divergence" > .cw-mirror-state        # echte Divergenz
    touch .cw-mirror-divergence
    exit 1
fi
```

**Auseinandergenommen:**

- **`set -uo pipefail`** im Header — `-u` = ungesetzte Variable nutzen
  ist Fehler, `-o pipefail` = wenn ein Pipe-Glied scheitert, scheitert
  die ganze Pipe (sonst sieht man nur den Exit-Code des letzten Glieds).
  Beachte: **`set -e` fehlt absichtlich**, weil das Skript bei jedem
  Fehler selbst entscheidet, was es tut (Stop-und-Marker vs. Skip).
- `git status --porcelain | head -1` — gibt's irgendwas Geändertes?
  Wir brauchen nur die erste Zeile zur Erkennung, `head -1` spart
  CPU bei großen Repos.
- `git merge --ff-only origin/main` — **nur** fast-forwarden (keinen
  Merge-Commit). Wenn FF nicht möglich, schlägt der Befehl fehl statt
  irgendwas zu erfinden.
- `touch .cw-mirror-divergence` — File mit aktuellem Timestamp anlegen,
  ohne Inhalt. Reiner Marker für „letztes Mal Divergenz gesehen".

### 7.3 Drei mögliche `.cw-mirror-state`-Werte

| Wert | Bedeutung |
|---|---|
| `in-sync <timestamp>` | Mirror ist aktuell |
| `active-edit` | Lokale uncommittete Änderungen → hier wird gerade gearbeitet |
| `local-ahead <timestamp>` | Lokale Commits, die noch nicht gepusht sind |
| `divergence <timestamp>` | Lokale UND Remote-Commits divergieren — manuell mergen |

### 7.4 Setup eines neuen Mirror-Macs

```bash
cd ~/Cortex/projects
git clone git@github.com:Sanexio/cortex-web.git Cortex-Web

# launchd-Job aktivieren
cp Cortex-Web/tools/cw-mirror-sync.plist \
   ~/Library/LaunchAgents/com.cortex.cw-mirror.plist
launchctl load ~/Library/LaunchAgents/com.cortex.cw-mirror.plist

# In devices.json eintragen: "role": "mirror" für Cortex-Web
```

**Erklärung von `launchctl load`:** `launchctl` ist die CLI für
`launchd`, macOS' Job-System (Equivalent von systemd/cron auf Linux).
`load` parst die `.plist`-Datei und registriert den Job. Mit `RunAtLoad
true` läuft er sofort einmal. `launchctl unload` stoppt + deregistriert.
Moderner ist `launchctl bootstrap gui/$UID <plist>` /
`launchctl bootout`, beide Varianten arbeiten parallel.

---

## 8. Symmetrie und Asymmetrie — Nexus vs. Cortex-Web

| Aspekt | Nexus-Sync | Cortex-Web-Mirror-Sync |
|---|---|---|
| Trigger | launchd alle 5 Min | launchd alle 5 Min |
| Direction | bidirektional (pull + push) | **pull-only** |
| Auto-Commit | ja (Whitelist) | nein |
| Multi-Writer-Schutz | Heartbeat-Refs | per Konvention (1 aktiver Mac) |
| Konflikt-Handling | Auto-Konvergenz + Auto-Resolve | Stop + Marker + manuell |
| Alarm | macOS + Telegram | nur Log + Marker-File |
| Health-JSON | ja (`_memory/health/sync-drift.json`) | nein (`.cw-mirror-state` reicht) |

**Warum diese Asymmetrie?** Nexus ist „selbst-koordiniertes Multi-
Writer-System" — alle Macs sind potenziell aktive Editoren, das System
muss das fehlerrobust handhaben. Cortex-Web ist „1-Writer-mit-Mirrors"
— viel einfachere Anforderungen, also viel einfacheres Skript.

---

## 9. Diagnose-Workflow — wenn der Sync klemmt

### 9.1 Erste Anlaufstelle: Health-JSON

```bash
cat ~/Cortex/Nexus/_memory/health/sync-drift.json | jq .
```

Beispiel-Output:

```json
{
  "timestamp": "2026-05-26T18:30:00Z",
  "hostname": "ssmd-macbookpro-m5",
  "head": "b0fa2cf9",
  "remote_head": "b0fa2cf9",
  "dirty_count": 0,
  "non_whitelist_drift_count": 0,
  "active_r2_tasks": 0,
  "approval_markers": 0,
  "approval_enforce": false,
  "outgoing_r2_diff": false
}
```

**Was bedeutet das?**

- **`head` vs. `remote_head`** — gleich = synchron, ungleich =
  Divergenz oder Backlog.
- **`dirty_count`** — uncommittete Files. >0 ist normal kurzzeitig,
  länger anhaltend = entweder gewollt (Du arbeitest) oder Drift.
- **`non_whitelist_drift_count`** — Files mit Änderungen, die NICHT
  per Auto-Commit erfasst werden. >0 = manueller Commit nötig.
- **`outgoing_r2_diff`** — `true` heißt: lokal sind R2-Pfade geändert
  und stehen für den Push bereit. Im Enforce-Mode bräuchte das
  Approval-Marker.

### 9.2 Logs

```bash
tail -50 ~/Cortex/Nexus/_memory/logs/nexus-sync.log
tail -50 ~/Cortex/projects/Cortex-Web/_archive/_mirror-logs/cw-mirror-sync.log
```

**Was suchen?**

- `SYNC: OK` — letzter Lauf erfolgreich.
- `WAIT: <host> war vor Xs aktiv` — Heartbeat-Skip, normal.
- `DIVERGENZ:` — auto-konvergenz versucht es.
- `AUTO-KONVERGENZ erfolgreich` — Auto-Rebase hat geklappt.
- `ECHTER INHALTS-KONFLIKT in <file>` — manuelles Mergen nötig.
- `ALARM gesendet` — User wurde informiert.
- `DRIFT WARNUNG: N uncommittete Datei(en)` — manueller Commit nötig.

### 9.3 launchd-Status

```bash
launchctl list | grep cortex
```

Output (Felder: PID | Exit-Code | Label):

- PID = `-` → Job ist registriert aber gerade nicht laufend.
- PID = `12345` → läuft gerade.
- Exit-Code 0 → letzter Lauf erfolgreich.
- Exit-Code ≠ 0 → fehlerhaft, ins Log schauen.

### 9.4 Manueller Sync-Lauf zur Diagnose

```bash
bash ~/Cortex/Nexus/nexus-sync.sh
bash ~/Cortex/projects/Cortex-Web/tools/cw-mirror-sync.sh
```

Direkt im Terminal laufen lassen statt warten auf den 5-Minuten-Takt.
Output landet in den oben genannten Log-Files; das Skript selbst gibt
in den meisten Phasen nichts auf das Terminal aus (weil
`exec >> "$LOG_FILE" 2>&1` umleitet).

### 9.5 Status auf anderen Macs prüfen

Per Tailscale-SSH:

```bash
ssh ssmd@100.127.125.48 \
  'cd ~/Cortex/Nexus && git log --oneline -1 && cat _memory/health/sync-drift.json'
```

**Auseinandergenommen:**

- `ssh ssmd@<ip>` — Verbindung über Tailscale-IP, User `ssmd`.
- `'cd ~/Cortex/Nexus && ...'` — Remote-Befehl in einfachen
  Anführungszeichen, damit die lokale Shell nicht expandiert. `~` wird
  von der Remote-Shell als Home-Verzeichnis aufgelöst.
- `&&` — nur den nächsten Befehl ausführen, wenn `cd` erfolgreich.

---

## 10. Bekannte Probleme und Workarounds

### 10.1 Magic-DNS funktioniert nicht überall

**Symptom:** `ssh ssmd@cluster-mini-02` oder `ssh ssmd@cluster-mini-02.
piranha-marlin.ts.net` löst nicht auf.
**Workaround:** Tailscale-IPs direkt nutzen (`100.x.x.x`). IPs stehen
in `devices.json` unter `network.mesh_ip_v4`.
**Root Cause unklar.** Magic-DNS-Setting in Tailscale-Admin, lokaler
macOS-Resolver, `scutil --dns`-State, oder `/etc/resolver/` Konfig.

### 10.2 SSH-Auth zwischen Macs ist drift-anfällig

**Symptom:** `Permission denied (publickey,password,keyboard-
interactive)` beim Versuch, auf einen anderen Mac zu sshen.
**Ursache:** SSH-Keys werden auf jedem Mac unabhängig generiert.
`authorized_keys` muss aktiv gepflegt werden. Nach Mac-Migration
(Migrationsassistent) kann ein alter Hostname die Auth verschieben.
**Workaround:** `ssh-copy-id ssmd@<ip>` einmalig pro Mac-Paar, mit
funktionierender Passwort-Auth. Oder Tailscale-SSH (`tailscale ssh
ssmd@<host>`) — nutzt eigenes Auth-System.

### 10.3 Auto-Sync stoppt nach Mac-Migration

**Symptom:** Auf einem frisch migrierten Mac läuft `nexus-sync` nicht
mehr.
**Diagnose-Reihenfolge** (in dieser Reihenfolge prüfen):

1. `launchctl list | grep cortex` — ist der Job registriert?
2. `ls -la ~/Library/LaunchAgents/com.cortex.*` — sind die plists da?
3. `cat /etc/hosts` — siehe Memory `feedback_migration_etc_hosts_
   selfloop.md`: Migrations-Assistant kann alten Hostnamen als
   `127.0.0.1` eintragen → SSH/Bonjour zum Vorgänger-Mac bricht.
4. `tail -100 ~/Cortex/Nexus/_memory/logs/nexus-sync.log` — letzte
   Fehler.

### 10.4 Telegram-Statusmeldungen kommen nur von einem Mac

**Symptom:** Nur Cluster-Mini-02 schickt Welle-Ende-Telegram-Status,
andere Macs nicht.
**Status:** Bekannter Bug, Diagnose ausstehend. Memory-Anker:
`project_telegram_only_cluster_mini_02.md`.
**Workaround:** Wichtige Statusmeldungen redundant von Cluster-Mini-02
aus schicken oder beim Hauptarbeitsplatz bleiben.

### 10.5 Persistierende Divergenz nach „Notebook hochklappen"

**Symptom:** Mac war 6 h aus. Beim Hochklappen meldet sich `nexus-sync`
mit „DIVERGENZ PERSISTIERT" obwohl nichts manuell geändert wurde.
**Ursache:** Während der Mac aus war, ist Remote weitergelaufen.
Lokaler Stand ist Vor-Stand. Erste paar Sync-Läufe melden Divergenz,
weil sie versuchen, eigene Commits (die alten Heartbeats?) zu rebasen.
**Workaround:** Meist self-heilend nach 1-2 Läufen. Wenn nicht:

```bash
cd ~/Cortex/Nexus
git status              # was ist lokal?
git fetch
git log HEAD..origin/main --oneline   # was kommt rein?
git pull --rebase --autostash
```

---

## 11. Welche Repos sind wirklich „auf jedem Mac"?

Nicht alle Repos liegen auf allen Macs. Stand 2026-05-26:

| Repo | Auf welchen Macs? | Rolle der Macs |
|---|---|---|
| `Sanexio/nexus` (~/Cortex/Nexus) | **alle** | gleichberechtigte Editoren |
| `Sanexio/cortex-web` (~/Cortex/projects/Cortex-Web) | alle (`primary` oder `mirror`) | nur Cluster-Mini-02 und Mac-Studio bearbeiten, andere mirroren |
| `Sanexio/praxiszentrum-theme` (Praxis-Theme) | **Cluster-Mini-02** (Local Flywheel) | Single-Host (Memory-Anker `feedback_migration_etc_hosts_selfloop.md` Kontext) |
| `Juvantis/juvantis-web/theme` (Shopify-Theme) | Cluster-Mini-02 | Single-Host |
| Restliche Projekt-Repos | je nach `devices.json` `primary`-Flag | je Projekt unterschiedlich |

`devices.json` ist die autoritative Antwort — wer hat was, wo, mit
welcher Rolle.

---

## 12. Konfiguration aller Sync-Komponenten — Quick-Reference

| Komponente | Wo? |
|---|---|
| Nexus-Sync-Skript | `~/Cortex/Nexus/nexus-sync.sh` |
| Nexus-Sync-plist | `~/Library/LaunchAgents/com.cortex.nexus-sync.plist` |
| Nexus-Sync-Log | `~/Cortex/Nexus/_memory/logs/nexus-sync.log` |
| Nexus-Sync-Healthcheck-plist | `~/Library/LaunchAgents/com.cortex.nexus-sync-healthcheck.plist` |
| Health-JSON | `~/Cortex/Nexus/_memory/health/sync-drift.json` |
| Heartbeat-Refs (Remote) | `refs/heartbeats/<host>` auf `Sanexio/nexus` |
| Heartbeat-Cache (lokal) | `~/Cortex/Nexus/.config/heartbeats/<host>.heartbeat` |
| Geräte-Registry | `~/Cortex/Nexus/.config/devices.json` |
| Drift-Report | `~/Cortex/Nexus/_memory/logs/drift-pending-manual.log` |
| Alarm-Marker | `~/Cortex/Nexus/_memory/.divergence-alarmed` |
| Approval-Marker-Verzeichnis | `~/Cortex/Nexus/_memory/approvals/` |
| Cortex-Web-Mirror-Skript | `~/Cortex/projects/Cortex-Web/tools/cw-mirror-sync.sh` |
| Cortex-Web-Mirror-plist | `~/Library/LaunchAgents/com.cortex.cw-mirror.plist` |
| Cortex-Web-Mirror-Log | `~/Cortex/projects/Cortex-Web/_archive/_mirror-logs/cw-mirror-sync.log` |
| Cortex-Web-Mirror-State | `~/Cortex/projects/Cortex-Web/.cw-mirror-state` |
| Cortex-Web-Divergenz-Marker | `~/Cortex/projects/Cortex-Web/.cw-mirror-divergence` |
| Telegram-Bridge-plist | `~/Library/LaunchAgents/com.cortex.telegram-bridge.plist` |
| Telegram-Bot-Token | `~/Cortex/Nexus/tools/telegram-bridge/.env` |

---

## 13. Was du jetzt beherrschst

Nach diesem Modul solltest du in der Lage sein:

- Die drei Schichten (Tailscale, Git/GitHub, launchd) zuverlässig
  auseinanderzuhalten.
- Den Unterschied zwischen Nexus-Sync (bidirektional, Whitelist) und
  Cortex-Web-Mirror (pull-only, Konvention) zu erklären.
- Heartbeat-Refs als ephemeren Multi-Writer-Schutz nachzuvollziehen.
- Einen Sync-Klemmer per Health-JSON, Log und `launchctl list` zu
  diagnostizieren.
- Die bekannten Probleme (Magic-DNS, SSH-Auth, Migration) und ihre
  Workarounds zu erkennen.
- Die Autorität von `devices.json` zu respektieren — alles andere
  ist nachgelagerte Dokumentation und kann driften.

---

## 14. Wo geht's weiter?

- **Modul 02 — Multi-Device Setup:** Wie ein neuer Mac aufgenommen
  wird (klonen, bootstrap, devices.json eintragen).
- **Modul 08 — Phoenix-Stack:** Was das alles strukturell unter der
  Haube macht (Lean v3, R0-R3).
- **Modul 12 — Self-Applying Konvergenz:** Wie `cortex-converge.sh`
  jeden Mac auf das Kollektiv-Soll bringt.
- **Cortex-Web Modul 02 — Multi-Device-Mirror:** Die Cortex-Web-spezi-
  fische Sicht auf das Mirror-Modell (CW-009).
- **Netzwerk & Sysadmin Modul 09 — Cortex-Mesh-Tailscale:** Tailscale-
  Setup im Detail (Tags, Subnet-Routes, exit-nodes).
