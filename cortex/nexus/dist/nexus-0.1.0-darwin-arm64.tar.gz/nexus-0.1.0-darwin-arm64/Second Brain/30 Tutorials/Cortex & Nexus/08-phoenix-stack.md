---
title: Phoenix-Stack — Architektur nach dem Reset 2026-05-09
domain: Cortex & Nexus
created: 2026-05-09
context: Phoenix-Reset (Hard-Reset von V1/V2-Drift) — neuer Stack agent/Python + gateway/Bun + Connexio + Cron
related:
  - 01-architektur-und-philosophie.md
  - 03-memory-layers.md
  - 04-trust-tiers-und-autonomie.md
  - 06-cortex-autonomy-v2.md
  - 07-cortex-autonomy-v3.md
---

# Phoenix-Stack — Cortex/Nexus nach dem Reset 2026-05-09

> Modul 08 — Architektur des aktuellen Stacks. Ersetzt nicht 06/07
> (die bleiben als historischer Pfad), sondern erklärt, was nach dem
> radikalen Reset vom 8./9. Mai 2026 stehengeblieben ist und warum.

> [!info] Lesezeit: 15 Min Übersicht · zugehörige Code-Touren ~30 Min
> Voraussetzung: Modul 01 (Architektur), Modul 03 (Memory-Layers)

---

## 1. Warum gab es den Reset?

V1 (`tools/cortex-*`) und V2 (`tools/cortex-cron`, `tools/telegram-bridge`,
`tools/cortex-mode/v2`) wuchsen über Sprints A bis F so weit, dass:

- 17 000+ Files in `_archive/upstream/openclaw/` als „Pattern-Referenz"
  herumlagen, nie gelesen, nur Plattenplatz (242 MB).
- Mehrere parallele Memory-Systeme existierten: `_memory/MEMORY.md`,
  `_memory/QUICK.md`, `_rules/GLOBAL_RULES.md`, plus geräte-lokale
  `~/.claude/projects/-*/memory/`. Drift war strukturell vorprogrammiert.
- Telegram-Bridge V2 hatte Tier-3-Bypass-Pfade, die im Sprint-G-Audit
  als unhaltbar markiert wurden.
- Skills entstanden ad hoc als Shell-Skripte, ohne gemeinsamen Engine,
  ohne Memory-Anbindung, ohne Doctor-Sicht.

Der Reset war kein Refactor, sondern ein **Hard-Cut**: 46 500 LOC alter
Steuerung gelöscht, 3 016 LOC neuer Stack auf einer klar gezeichneten
Architektur — siehe [[01-architektur-und-philosophie]].

---

## 2. Die fünf Bausteine

```
┌──────────────────────────────────────────────────────────────────┐
│ Cortex/Nexus                                                     │
│                                                                  │
│  ┌────────────┐   ┌────────────┐   ┌──────────────────────────┐ │
│  │  agent/    │   │ gateway/   │   │ Second Brain/30 Tutorials│ │
│  │  Python    │   │ TypeScript │   │ Obsidian-Vault            │ │
│  │            │   │ Bun        │   │ (Wissen, single source)   │ │
│  └─────┬──────┘   └─────┬──────┘   └──────────────────────────┘ │
│        │                │                                        │
│        ├── skills/      ├── channels/telegram                    │
│        ├── memory/      └── channels/<future>                    │
│        ├── connexio/                                             │
│        ├── cron/                                                 │
│        └── connexio_outbound/  (geplant)                         │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ _memory/                                                    │ │
│  │  ├── memory.db        SQLite-FTS5 (sessions, patterns,      │ │
│  │  │                    user_facts, skill_runs)               │ │
│  │  ├── spawn-queue.db   SQLite (Telegram /spawn)              │ │
│  │  ├── connexio-audit.log  (Append-only Read-Surface-Audit)   │ │
│  │  └── cron-state.json + cron-tier3-tokens.json               │ │
│  └────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

| Baustein | Sprache | Aufgabe |
|---|---|---|
| **agent/** | Python 3.14 | Skill-Engine, Memory-Store, Connexio-Kernel, Cron-Runner. Logisches Stammhirn. |
| **gateway/** | TypeScript / Bun | Channels nach außen — primär Telegram-V3 (`/spawn`, `/verdict`, Plain-Text-Bridge als Terminal-Eingabe). |
| **Second Brain** | Obsidian | Vault — alle Tutorials, MOCs, Konzept-Files. Single Source of Truth für Wissen. |
| **_memory/** | SQLite + JSON | Strukturierte Memory-Layer. Keine MD-Files mehr für Patterns/Sessions, nur DB. |
| **Connexio** | Python | Read-Only-Wissens-Surface für externe KIs (Codex, Cursor) — MCP + HTTP, Pfad-Whitelist, BLOCKED_TAGS-Filter. |

---

## 3. Skill-Engine (`agent/skills/engine.py`)

Skills sind die einzige Form, in der Cortex Aktionen ausführt — kein
freies Bash-Skript-Verzeichnis mehr. Die Engine bietet:

- **Discovery**: alle `@skill(name=...)`-decorierten Funktionen unter
  `agent/skills/builtin/` werden beim Import registriert.
- **Run**: einheitlicher Einstieg `engine.run(name, args, store=...)`,
  schreibt jeden Lauf in `skill_runs`-Tabelle.
- **CLI**: `cortex-agent skill list` / `cortex-agent skill run <name> --args '{...}'`.

### Die zehn aktuellen Skills

| Skill | Zweck |
|---|---|
| **doctor** | 10-Punkte-Health-Check (Mode-State, Memory-DB, USER.md, Vault, Backup-Branch, Skill-Registry, Git-Workspace) |
| **session-end** | Welle-Ende-Debrief in Memory schreiben, Volltext > 2 KB nach `_archive/sessions/<YYYY-MM>/` |
| **sanitizer** | VACUUM, Sessions > 90 Tage archivieren, Spawn-Queue-Cutoff 30 Tage, MEMORY.md-Cap-Warnung (200 LOC / 8 k Tokens) |
| **curator** | Memory-Curation — facts, sessions, pending-Items |
| **tutorial-curator** | Vault-Drift-Audit (numbering, broken-links, orphans) — orphan-check ist transitiv vom MOC + Landings |
| **pattern-miner** | Token-Frequency aus letzten Sessions + optional Anthropic-API-Call (claude-haiku-4-5). Vorschläge gehen nach `_memory/curator-queue.md`, kein Auto-Add. |
| **scheduler** | LaunchAgent-Status anzeigen (`com.cortex.*` Plists in `~/Library/LaunchAgents`) |
| **cron** | Phoenix-Cron — TOML-Recipes, Tier-3-Token-Mechanik (siehe §6) |
| **connexio** | Read-Only-Surface healthcheck/audit-tail/server-start/mcp-cmd/keygen |
| **spawn** | Spawn-Queue füllen (Telegram → Mac), enqueue/list/cancel/get |

---

## 4. Memory-DB (`_memory/memory.db`)

SQLite mit FTS5. Schema:

| Tabelle | Inhalt |
|---|---|
| `sessions` + FTS-Mirror | Welle-Ende-Debriefs, ≤ 2 KB pro Eintrag |
| `patterns` + FTS-Mirror | Vom pattern-miner extrahierte / vom User kuratierte Muster (`name`, `slug`, `body`, `tags`) |
| `user_facts` | USER-Profil-Fakten (key/value, kategoriebasiert) |
| `skills` | Skill-Registry-Snapshot |
| `skill_runs` | Audit-Log: jeder Run mit args, result-head, ok-Flag, Timestamp |
| `meta` | DB-Version, Schema-Migrationen |

Wichtige Eigenschaften:

- **Connexio liest die DB nur read-only** (`sqlite3.connect(file:...?mode=ro&immutable=0, uri=True)`).
- **Größenkontrolle**: `sanitizer` läuft nightly via Cron, hält DB unter
  Token-/Größen-Caps.
- **Patterns sind nicht mehr MD-Files.** Alte `_memory/patterns/*.md`
  wurden beim Reset gelöscht. Tutorials, die darauf verlinkten, wurden
  auf `cortex-agent memory search "<term>"` umgestellt.

---

## 5. Connexio Read-Only-Surface

Externe KIs (Codex, Cursor, andere Claude-Sessions) sollen Cortex-Wissen
**lesen**, aber nichts schreiben können. Connexio ist die Antwort.

### Sicherheits-Layer (hardcoded, nicht configurable)

1. **DB-Ebene**: `sqlite3.connect(..., uri=True)` mit `?mode=ro` —
   physisch unmöglich zu schreiben.
2. **Pfad-Whitelist**: nur `USER.md`, `KNOWLEDGE.md`, `_projects/INDEX.md`,
   `golden_rules`-Essenz, `_projects/<id>/SESSION_RESUME.md`, Vault-Tutorials.
3. **BLOCKED_TAGS**: `{medizin, patient, steuer, secret}` — Patterns mit
   diesen Tags werden gefiltert.
4. **Loopback-only**: HTTP-Server bindet auf `127.0.0.1`.
5. **API-Key-Auth**: `_memory/connexio.key` (gitignored), Header
   `X-Connexio-Key`.
6. **Audit-Log**: `_memory/connexio-audit.log`, append-only, jeder
   Request mit Endpoint + Größe + Dauer.

### Schnittstellen

- **MCP-Server** (`agent.connexio.mcp_server`) — 7 Read-Only-Tools:
  `get_user_profile`, `list_projects`, `get_project`, `get_golden_rules`,
  `search_patterns`, `get_recent_sessions`, `get_tutorial`.
- **HTTP-Server** (`agent.connexio.http_server`) — `/context`, `/search`,
  `/project/<id>`. Praktisch: `/context?project=praxis-webseite&max_tokens=4000`
  liefert genau einen Self-Onboarding-Block.

### Smoke-Test-Recipe

```bash
KEY=$(cat _memory/connexio.key)
.venv/bin/cortex-agent skill run connexio --args '{"action":"server-start","host":"127.0.0.1","port":7766}' &
sleep 2
curl -s -H "X-Connexio-Key: $KEY" "http://127.0.0.1:7766/context?project=praxis-webseite&max_tokens=2000"
curl -s -o /dev/null -w "%{http_code}\n" "http://127.0.0.1:7766/context"   # → 401
pkill -f "connexio.*server-start"
```

---

## 6. Phoenix-Cron + Tier-3-Token-Mechanik

`agent/cron/runner.py` lädt TOML-Recipes aus `agent/cron/recipes/`,
matcht Schedule (5-Felder-cron) gegen jetzt, führt fällige Recipes aus.

### Recipe-Format

```toml
# agent/cron/recipes/nightly-sanitizer.toml
name = "nightly-sanitizer"
schedule = "0 3 * * *"
skill = "sanitizer"
args = { dry_run = false }
host_filter = "any"
tier3_ops = []
```

### Tier-3-Token

Recipes mit `tier3_ops = ["git-push"]` etc. laufen **nur**, wenn ein
Token vorliegt. Der User vergibt das Token explizit:

```bash
cortex-agent skill run cron --args '{"action":"grant-token","op":"git-push","expires_in_minutes":60}'
```

Das Recipe konsumiert das Token atomar (`consume_tier3_token`). Damit
kann z. B. `nexus-push` automatisiert laufen, aber nicht ungewollt.

### LaunchAgent

`com.cortex.phoenix-cron.plist` ruft alle 300 s
`cortex-agent skill run cron --args '{"action":"tick"}'` auf. Die Tick-
Logik prüft pro Recipe: due-Schedule? schon in dieser Minute gelaufen?
falls nein → ausführen + Result in `_memory/cron-state.json` schreiben.

### Initial-Recipes

| Recipe | Schedule | Was |
|---|---|---|
| `nexus-pull` | `*/30 * * * *` | `git pull --ff-only` (Multi-Device-Sync) |
| `nightly-sanitizer` | `0 3 * * *` | DB-Wachstumskontrolle |
| `tutorial-curator-weekly` | `0 4 * * 0` | Vault-Drift-Audit |
| `nexus-push` (off) | `0 4 * * *` | nur mit Tier-3-Token |

---

## 7. Telegram-V3 (`gateway/channels/telegram/`)

V3 ersetzt die V2-Bridge ohne Tier-3-Bypass. Die wichtigsten Handler:

- `/spawn <gerät> "<auftrag>"` → schreibt in `spawn-queue.db`,
  `spawn_watcher.py` (Daemon pro Mac) konsumiert + startet
  `claude` mit dem Auftrag.
- `/verdict <id> yes|no` → User antwortet auf Permission-Request
  vom Mac.
- `/spawn-list`, `/spawn-cancel <id>` — Queue-Inspektion.
- **Plain-Text-Bridge** (`notifications/claude/channel`): Telegram
  agiert als Terminal-Eingabe-Surrogat — Mac sendet eine Frage, User
  antwortet im Chat, Claude empfängt die Antwort.

V3 ist code-fertig, Live-Smokes brauchen den Bot-Token in
`gateway/.env` (Tier-3 Secret).

---

## 8. Praktische Befehle

```bash
# Health
cortex-agent skill run doctor

# Skills inspizieren
cortex-agent skill list
cortex-agent skill run <name> --args '{...}'

# Memory direkt
cortex-agent memory search "fluid type scale"
cortex-agent memory facts
cortex-agent memory add-fact <kind> <key> <value>

# Mode
cortex-agent mode get
cortex-agent mode set autonomy   # oder safe

# Cron
cortex-agent skill run cron --args '{"action":"list"}'
cortex-agent skill run cron --args '{"action":"tick"}'                              # echte Zeit
cortex-agent skill run cron --args '{"action":"tick","force_now":"2026-05-09T03:00:00Z","dry_run":true}'
cortex-agent skill run cron --args '{"action":"grant-token","op":"git-push"}'

# Connexio
cortex-agent skill run connexio --args '{"action":"healthcheck"}'
cortex-agent skill run connexio --args '{"action":"audit-tail"}'

# Telegram-Gateway standalone
cd gateway && bun run telegram
```

---

## 9. Was bleibt offen

Stand 2026-05-09 nach Polish-Welle:

- **Live-Smokes (Tier-3)**: Bot-Token in `gateway/.env`, V3-Bridge in
  `~/.claude.json` registrieren, LaunchAgents auf SSMD/M5/Studio.
- **C5 — Connexio Outbound** (geplant): Adapter, mit denen Cortex
  externe KIs aufruft (OpenAI, Ollama, Gemini, Anthropic-Outbound).
  Use-Case: Bildgenerierung, lange Kontexte, lokale Inferenz.
- **Self-Learning-Skills**: Hermes-Pattern, Skills aus erfolgreichen
  Sessions ableiten — bewusst nach C5 verschoben.

---

## 10. Verwandte Notizen

- [[01-architektur-und-philosophie]] — Container-Modell, Trennung portabel/lokal
- [[03-memory-layers]] — Hot/Warm/Cold-Schichten, Token-Caps
- [[04-trust-tiers-und-autonomie]] — Tier-3-Hardstops, was sich geändert hat
- [[06-cortex-autonomy-v2]] — historischer Pfad (Sprint E, V2)
- [[07-cortex-autonomy-v3]] — Sprint F, V3-Foundation
- [[Arbeitsweise & Prozess/02-selbstregulierende-memory-systeme]] — wie Memory-Layer zusammenspielen
