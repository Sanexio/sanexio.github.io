# Claude + Codex — Autonome Projekt-Abarbeitung (Konzept)

> **Status:** Entwurf 2026-05-31 (Stracke-Trigger). Noch nicht freigegeben.
> Erweitert das bestehende `claude-codex-cooperation`-Peer-Modell um
> **eigenständige End-to-End-Abarbeitung kompletter Projekte**, gesteuert
> durch ein gemeinsames Token-Budget und harte Tier-3-Eskalation.
>
> **Anwendung:** Stracke gibt Projekt-Spec rein, Claude+Codex arbeiten es
> bis Done ab, ohne Reibung außerhalb der drei Tier-3-Kategorien.

---

## 1. Zielbild

**Eingabe:** Ein Projekt-Manifest (neues oder bestehendes Cortex-Projekt).
**Ausgabe:** Fertiges Projekt im definierten Zielzustand, alle Tests grün,
Push erfolgt, Telegram-Push an Stracke „Done".

Zwischen Eingabe und Ausgabe **keine Rückfragen** außer:
- echte Ambiguität (zwei plausible Architekturen, beide sinnvoll)
- Tier-3-Trigger (Secrets, Geld, externer Empfänger)
- Test/Build-Failure, der eine Spec-Änderung verlangt

**Token-Nutzung:** beide Agenten verbrauchen ihr jeweiliges Provider-Limit
(Anthropic für Claude, OpenAI für Codex) bis **maximal 97 %** des
relevanten Zeitfensters, ohne sich gegenseitig zu blockieren.

---

## 2. Reibungsbild (warum das heute nicht klappt)

| Reibungsquelle | Heute | Künftig |
|---|---|---|
| Claude fragt bei Tier-1-Ops zurück | ja (Drift) | nein (PreToolUse-Hook-Auto-Allow) |
| Codex hat keinen Plan, wann Claude dran ist | manuell via Outbox | strukturierte `handoff_to_agent`-Queue mit Lease |
| Token-Limits unbekannt → Agent läuft ins Rate-Limit | ja | Provider-Telemetrie zieht aktuelle Restwerte, pausiert bei 97 % |
| Welle-Ende-Push fehlt | ja (nur Mini-02) | Stop-Hook auf jedem Mac, sendet Telegram |
| Lease-Race zwischen den Agenten | unklar | DB-basierter Lease mit TTL |
| Eskalation bei Blocker | manuell | strukturierter Blocker-Task + Telegram |

---

## 3. Architektur (Komponenten)

```
┌─────────────────────────────────────────────────────────────┐
│                  Stracke → Projekt-Manifest                 │
└──────────────────────────┬──────────────────────────────────┘
                           ↓
                ┌──────────────────┐
                │ project-manifest │  YAML, in projects/<x>/.cortex/manifest.yaml
                └──────────┬───────┘
                           ↓
                ┌──────────────────────┐
                │  task-decomposer     │  Python-Skill (im cortex-agent)
                │  zerlegt Manifest →  │  schreibt Sub-Tasks in Connexio-DB
                │  N kleine Tasks      │  mit assigned_to=claude|codex
                └──────────┬───────────┘
                           ↓
   ┌───────────────────────┴───────────────────────┐
   ↓                                               ↓
┌──────────────┐                          ┌──────────────┐
│  Claude-Loop │  ← Polling der Inbox →   │  Codex-Loop  │
│  (Anthropic) │                          │  (OpenAI)    │
└──────┬───────┘                          └──────┬───────┘
       │                                         │
       │   ┌─────────────────────────────────┐   │
       └──→│  budget-broker (Single SoT)     │←──┘
           │  zieht Provider-Telemetrie,     │
           │  vergibt/verweigert Tokens      │
           └─────────────────────────────────┘
                           │
                           ↓
                ┌──────────────────────┐
                │ Telegram-Bridge      │  bei Done / Blocker
                └──────────────────────┘
```

### 3.1 Neue Komponenten

| Komponente | Pfad (geplant) | Zweck |
|---|---|---|
| **project-manifest** | `projects/<x>/.cortex/manifest.yaml` | Beschreibt Ziel, allowed_paths, Test-Befehle, Definition-of-Done. |
| **task-decomposer** | `agent/skills/builtin/decompose_project.py` | Liest Manifest, schreibt N Sub-Tasks in `task_store`. |
| **budget-broker** | `agent/connexio/budget_broker.py` | Hält Provider-Restbudgets, vergibt Slots pro Agent. |
| **claude-runner** | (Claude-Code-CLI in Loop-Mode, via `/loop`) | Pollt Inbox, arbeitet Tasks ab. |
| **codex-runner** | (Codex-CLI in Loop-Mode) | Analog für Codex. |
| **done-pusher** | Claude-Code-Stop-Hook | Sendet Telegram am Welle-Ende. |
| **blocker-escalator** | `agent/connexio/blocker_escalate.py` | Bei Tier-3 oder hartem Failure: Stracke per Telegram + Pause. |

### 3.2 Wiederverwendete Komponenten

- `agent/connexio/task_store.py` — bestehende Task-DB.
- `agent/connexio/lease_store.py` — bestehender Lease-Mechanismus.
- `agent/connexio/session_digest.py:send_telegram` — bestehender Telegram-Push.
- `tools/cortex-mode/bin/inject.sh` — bestehender Mode-Hook.

---

## 4. Token-Budget-Mechanik

### 4.1 Quellen der Telemetrie

| Provider | Quelle | Frequenz |
|---|---|---|
| Anthropic | Response-Header `anthropic-ratelimit-tokens-remaining`, `…-requests-remaining` | jeder API-Call |
| OpenAI | Response-Header `x-ratelimit-remaining-tokens`, `…-requests` | jeder API-Call |

Plus: tägliche/wöchentliche Token-Gesamtbudgets aus den Provider-Plänen
(z.B. Anthropic Max, OpenAI Plus). Diese sind **nicht** als Header
verfügbar — müssen aus Account-Dashboard manuell ins Konfig-File
(`.config/token-budgets.yaml`) eingetragen werden und alle 7 Tage von
Stracke aktualisiert.

### 4.2 Budget-Broker-Logik

Vor jedem Agenten-Turn:

```python
def request_slot(agent: Literal["claude", "codex"], estimated_tokens: int) -> SlotDecision:
    budget = budget_store.current(agent)
    pct_used = (budget.consumed / budget.weekly_limit) * 100
    if pct_used >= 97.0:
        return SlotDecision(allow=False, reason="weekly_budget_ceiling")
    if budget.rpm_remaining < 5:
        return SlotDecision(allow=False, reason="rpm_low", retry_in=60)
    return SlotDecision(allow=True, soft_cap_pct=pct_used)
```

Bei `allow=False, reason=weekly_budget_ceiling`: **Pause des Agents bis
Reset-Zeitpunkt** (i.d.R. Wochen-Reset Sonntag-Mitternacht). Der andere
Agent läuft weiter, wenn dort noch Budget ist.

Bei `allow=False, reason=rpm_low`: Backoff, dann Retry.

### 4.3 Faire Verteilung

Wenn beide Agenten Tasks aus derselben Queue ziehen, wird **task-affinity**
beachtet (s. 5.2). Wenn beide für dieselbe Task qualifiziert sind, gewinnt
der mit dem **höheren Rest-Budget**, damit das knappere Budget geschont
wird.

### 4.4 Sichtbarkeit

Tägliches Mini-Dashboard via Telegram (Cron 07:00 lokal):
```
🪙 Budget heute
 Claude:  64 % verbraucht (Wochenlimit Anthropic)
 Codex:   41 % verbraucht (Wochenlimit OpenAI)
 Pause:   nein
```

---

## 5. Task-Format

### 5.1 Manifest (Eingabe)

`projects/<x>/.cortex/manifest.yaml`:

```yaml
version: 1
project: cortex-web-ärzteliste
goal: "CRUD-UI für Ärzte-Stammdaten, anschlussfähig an Tenant-DB"
definition_of_done:
  - tests:                 "bun test"
  - lint:                  "bun run lint"
  - typecheck:             "bun run typecheck"
  - manual_check:          false   # autonom OK
constraints:
  allowed_paths:
    - "projects/cortex-web/apps/web/src/areas/aerzte/**"
    - "projects/cortex-web/apps/web/tests/aerzte/**"
  forbidden_paths:
    - "Nexus/**"
    - "projects/sanexio-tenant/**"
  risk_level_cap: R1
deadline: 2026-06-15T18:00:00Z
preferred_agent: claude   # für UI-heavy; codex für backend-heavy
fallback_agent: codex
```

### 5.2 Sub-Task (Decomposer-Output)

```yaml
id: aerzte-001
parent: cortex-web-ärzteliste
title: "Schema-Migration aerzte-Tabelle"
assigned_to: codex     # decomposer wählt nach affinity
allowed_paths: ["projects/cortex-web/apps/web/migrations/**"]
risk_level: R1
base_commit: a1b2c3d
estimated_tokens: 8000
depends_on: []
```

### 5.3 State-Machine

`pending → claimed → in_progress → review → done | blocked | failed`

- `claimed` setzt einen Lease (TTL 15 Min). Wenn Lease abläuft, freier Task.
- `review`-Phase: anderer Agent reviewed Diff. Approve/Reject.
- `blocked`: trigger Telegram-Eskalation.

---

## 6. Hand-off-Protokoll

Statt Markdown-Outbox: **Connexio `handoff_to_agent`** (geplante Erweiterung
in cortex-lean-v3).

```python
connexio.handoff_to_agent(
    task_id="aerzte-001",
    from_agent="claude",
    to_agent="codex",
    payload={
        "context": "UI fertig, brauche jetzt das Backend-Endpoint",
        "files_touched": [...],
        "next_step": "POST /api/aerzte"
    }
)
```

Atomar, audited, ohne File-IO-Race.

---

## 7. Eskalation und Stop

### 7.1 Auto-Stop-Trigger (Agent pausiert selbst)

- Tier-3-Op (Secrets, Geld, externe Empfänger).
- Token-Budget ≥ 97 %.
- Test/Build-Failure, der Spec-Änderung verlangt.
- Architektur-Verzweigung mit zwei plausiblen Pfaden.
- `forbidden_paths`-Verletzung (sollte vom Pre-Check abgefangen werden).
- Lease-Konflikt mit fremdem Agenten.

### 7.2 Eskalations-Pfad

```
Agent → blocker_escalate.py → blocker-Task in Connexio + Telegram-Push
      → Stracke entscheidet via Telegram (oder Slash-Command in CLI)
      → release_block(task_id, decision)
      → Agent nimmt Arbeit wieder auf
```

Telegram-Format:
```
🛑 BLOCKER: aerzte-001 (cortex-web)
 Agent:    claude
 Grund:    Tier-3 — neuer .env-Eintrag nötig (DATABASE_URL)
 Vorschlag: DATABASE_URL=postgres://... als TENANT_DB_URL
 Antworten: /resume aerzte-001 yes  ODER  /resume aerzte-001 reject "begründung"
```

### 7.3 Stop nach Done

Bei `done`-Übergang: Welle-Ende-Push an Stracke mit Diff-Summary,
verbrauchten Tokens, Zeit.

---

## 8. Sicherheits-Grenzen (unverändert)

| Grenze | Quelle |
|---|---|
| Tier-3 nie autonom | `agent/modes/tier3.md` |
| Nexus-Kern niemals von Codex direkt | `_rules/multi-ai-boundaries.md` |
| Nexus-Kern von Claude nur über R2-Approval | `_rules/ai-cooperation.md` |
| Push erst nach grünen Tests | `_rules/verification.md` |
| Geräte-Lease pro Repo | `agent/connexio/lease_store.py` |

**Wichtig:** Autonome Abarbeitung **hebt Tier-3 nicht auf**. Sie unterdrückt
nur die Reibung in den drei pauschal freigegebenen Bereichen.

---

## 9. PreToolUse-Hook (das eigentliche Drift-Heilmittel)

Heute fragt Claude-Code trotz Autonomy zu oft zurück, weil der
Anthropic-Systemprompt „ask for confirmation by default" sagt. Lösung:
ein **PreToolUse-Hook**, der für definierte Tool-Calls automatisch
`permissionDecision: allow` zurückgibt.

```json
"hooks": {
  "PreToolUse": [{
    "matcher": "Bash|Edit|Write",
    "hooks": [{ "type": "command",
                "command": "bash $HOME/Cortex/Nexus/tools/cortex-mode/bin/auto_allow.sh" }]
  }]
}
```

`auto_allow.sh` liest den Tool-Call-JSON, prüft gegen eine Allowlist
(Bash-Muster, Edit-Pfade) und antwortet mit:
```json
{"permissionDecision": "allow", "reason": "Tier-1 — pauschal freigegeben"}
```

Damit umgeht der User die Permission-Prompts, ohne die Tier-3-Hardstops
zu schwächen (für Tier-3 fängt der Hook ab und gibt `ask` zurück).

---

## 10. Reporting

### 10.1 Live (während Bearbeitung)

- Stille im Default. Kein Telegram-Spam pro Task.
- Telegram-Push nur bei: Blocker, Done, Token-Schwelle (90 % weekly).

### 10.2 Tägliches Digest (07:00 lokal)

Telegram:
```
📊 Tages-Digest 2026-06-01
 Projekt cortex-web-aerzteliste:
   12 Tasks done, 3 in_progress, 1 blocked (aerzte-008)
 Projekt smartq-dashboard:
   3 Tasks done, queue leer
 Budget: Claude 64 %, Codex 41 %
```

### 10.3 Welle-Ende-Push pro Mac

Stop-Hook in `~/.claude/settings.json` auf jedem Mac:
```json
"Stop": [{
  "matcher": "",
  "hooks": [{ "type": "command",
              "command": "python3 $HOME/Cortex/Nexus/tools/wave-end-push.py" }]
}]
```

Heilt parallel die Telegram-Mini-02-only-Drift.

---

## 11. Umsetzungs-Roadmap (Wellen)

| Welle | Inhalt | Aufwand |
|---|---|---|
| **W1 — Drift-Fix** | (a) PreToolUse-auto-allow-Hook auf jedem Mac. (b) Stop-Hook mit Telegram-Push auf jedem Mac. (c) `connexio-inbox-notify`-LaunchAgent auf jedem Mac. (d) install_bootstrap.sh als Single-Shot-Setup. | 1 Tag |
| **W2 — Manifest + Decomposer** | `manifest.yaml`-Format final, `decompose_project.py` als Skill, Test mit einem kleinen Projekt. | 2 Tage |
| **W3 — Budget-Broker** | Provider-Telemetrie-Scraper, Budget-Store-DB, Slot-Vergabe. | 3 Tage |
| **W4 — handoff_to_agent + Lease** | Connexio-Write-Surface für Hand-off, Lease-TTL, atomares Update. | 3 Tage |
| **W5 — Codex-Runner-Loop** | Codex-CLI-Wrapper, Inbox-Polling, Auto-Resume. | 2 Tage |
| **W6 — Blocker-Eskalation + Telegram-Slash-Commands** | `/resume`, `/reject` in Telegram. | 1 Tag |
| **W7 — Pilot** | Ein echtes Projekt (z.B. `aerzteliste`) End-to-End durchziehen, Metriken sammeln. | 1 Tag + Pilot-Laufzeit |

**Gesamt:** ~13 Engineering-Tage über mehrere Wochen verteilt.

---

## 12. Offene Fragen (vor Freigabe)

1. **Multi-Mac-Koordination:** Wenn beide Macs parallel Codex-Runner haben, wie wird der Lease zwischen ihnen koordiniert? — Vorschlag: Connexio-DB als Single SoT mit `machine`-Feld.
2. **Codex-CLI im Headless-Mode:** Funktioniert das überhaupt zuverlässig? Stracke muss bei Codex prüfen.
3. **Budget-Telemetrie OpenAI:** Sind die Header zuverlässig genug? Fallback auf manuellen Eintrag pro Tag?
4. **Welche Mac übernimmt die Single-Source-Komponenten (budget-broker, decomposer)?** Vorschlag: Cluster-Mini-02 als Always-On-Server, andere Macs als Worker.
5. **Was passiert bei Manifest-Konflikt** zwischen `definition_of_done` und Realität (z.B. Tests funktionieren nicht reproduzierbar)? — Vorschlag: nach 3 Failures auto-Blocker mit „spec_drift".

---

## 13. Was dieses Konzept NICHT macht

- Es macht **keine** der Tier-3-Operationen autonom (Secrets, Geld, externe Empfänger bleiben Hardstop).
- Es macht **keine** Nexus-Schreibops ohne R2-Approval.
- Es macht **keine** Auto-Merges in fremden Repos.
- Es ist **kein** Multi-Tenant-Framework — Single-User (Stracke).

---

## 14. Querverweise

- `specs/claude-codex-cooperation/00_KONZEPT.md` — Peer-Modell (Vorgänger).
- `specs/cortex-lean-v3/` — Connexio-Write-Surface (Voraussetzung W4).
- `_rules/ai-cooperation.md` — bestehende Schreibregeln.
- `_rules/multi-ai-boundaries.md` — Grenzen für andere KIs.
- `agent/modes/tier3.md` — Hardstop-Definition (unverändert).
- Tutorial Nr. 14 (`Cortex & Nexus/14-cortex-nexus-vollstaendige-arbeitsweise.md`) — Architektur-Übersicht.
