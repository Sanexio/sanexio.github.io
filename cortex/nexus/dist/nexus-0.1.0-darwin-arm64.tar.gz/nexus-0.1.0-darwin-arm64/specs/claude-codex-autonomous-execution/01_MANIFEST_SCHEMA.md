# Manifest-Schema — `projects/<x>/.cortex/manifest.yaml`

> Stand 2026-05-31. Eingabe-Format für autonome Projekt-Abarbeitung.
> Schemaversion 1.

## Minimal-Beispiel

```yaml
version: 1
project: file-renamer-iteration-3
goal: "OCR-Fallback für PDFs ohne Text-Layer, plus Performance-Doppel"
```

## Vollständiges Beispiel

```yaml
version: 1
project: file-renamer-iteration-3
goal: "OCR-Fallback für PDFs ohne Text-Layer, plus Performance-Doppel"

definition_of_done:
  - tests:        "pytest tests/"
  - lint:         "ruff check ."
  - typecheck:    "mypy src/"
  - manual_check: false

constraints:
  allowed_paths:
    - "projects/file-renamer/src/**"
    - "projects/file-renamer/tests/**"
  forbidden_paths:
    - "Nexus/**"
    - "**/.env"
  risk_level_cap: R1

deadline: 2026-06-15T18:00:00Z
preferred_agent: codex      # affinity hint; decomposer kann pro task overriden
fallback_agent: claude

subtasks:
  - id: fr3-001
    title: "OCR-Fallback-Pfad mit tesseract"
    assigned_to: codex
    allowed_paths: ["projects/file-renamer/src/ocr/**"]
    acceptance_criteria:
      - "pytest tests/test_ocr.py grün"
      - "PDF ohne Text-Layer wird per tesseract behandelt"
    estimated_tokens: 6000

  - id: fr3-002
    title: "Performance-Bench — verdoppeln auf >= 40 PDF/min"
    assigned_to: claude
    allowed_paths: ["projects/file-renamer/src/runner/**", "projects/file-renamer/tests/perf/**"]
    depends_on: ["fr3-001"]
    acceptance_criteria:
      - "tests/perf/test_throughput.py meldet >= 40 PDF/min auf M5"
    estimated_tokens: 8000
```

## Felder

### Top-Level (Pflicht)

| Feld | Typ | Beschreibung |
|---|---|---|
| `version` | int | Schemaversion, derzeit `1`. |
| `project` | str | Kurzname (kebab-case). |
| `goal` | str | Was das Projekt am Ende erreichen soll, in 1 Satz. |

### Top-Level (optional)

| Feld | Typ | Default |
|---|---|---|
| `definition_of_done` | list of {key: command} | leer |
| `constraints.allowed_paths` | list of glob | leer (= überall) |
| `constraints.forbidden_paths` | list of glob | `["Nexus/**", "**/.env"]` |
| `constraints.risk_level_cap` | enum R0/R1/R2 | R1 |
| `deadline` | ISO-8601 | `null` |
| `preferred_agent` | `claude|codex` | `claude` |
| `fallback_agent` | `claude|codex` | `codex` |
| `subtasks` | list of subtask | leer |

### Sub-Task

| Feld | Typ | Default |
|---|---|---|
| `id` | str | auto: `<project>-NNN` |
| `title` | str | **Pflicht** |
| `assigned_to` | `claude|codex|either` | `either` |
| `allowed_paths` | list | erbt von Top-Level |
| `acceptance_criteria` | list | leer |
| `depends_on` | list of subtask-ids | leer |
| `estimated_tokens` | int | 5000 |
| `risk_level` | R0/R1/R2 | erbt von `constraints.risk_level_cap` |

## Validierungs-Regeln

1. **Tier-3-Pfade** in `allowed_paths` → reject (R3 darf nicht aus Manifest kommen).
2. **`forbidden_paths`** wird IMMER mit `["Nexus/**", "**/.env", "**/.claude.json", "**/.ssh/**"]` ge-OR'd, auch wenn das Manifest weniger nennt.
3. **`assigned_to`** muss `claude`, `codex` oder `either` sein (siehe `ALLOWED_SENDER`).
4. **`risk_level_cap`** > R2 → reject.
5. **Subtask-IDs** müssen eindeutig innerhalb eines Manifests sein.
6. **`depends_on`** darf nur auf andere IDs im selben Manifest verweisen.

## Wie der Decomposer das Manifest verarbeitet

Skill `decompose-project`:

1. Manifest lesen, validieren.
2. Für jeden Subtask: `task_store.create_task(...)` mit allen geerbten Defaults aufgelöst.
3. `depends_on` wird als `acceptance_criteria`-Hinweis zugefügt (Lease-Coordination kommt in W4).
4. Rückgabe: Liste der erzeugten task-IDs + Affinity-Übersicht.

Dry-Run-Modus: `args.dry_run=true` → erzeugt keine Tasks, gibt nur das geplante Mapping aus.
