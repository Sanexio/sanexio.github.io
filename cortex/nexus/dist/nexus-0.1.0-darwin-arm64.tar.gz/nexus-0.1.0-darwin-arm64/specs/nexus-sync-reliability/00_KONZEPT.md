# Nexus-Sync Reliability — Konzept

> Status: **Implemented 2026-05-13**
> Zweck: Folge-Fix zum Multi-Device-Sync-Vorfall vom 2026-05-13.

## Incident

`nexus-sync.sh` verglich HEAD blind gegen `origin/main` und versuchte auf
dem aktuell ausgecheckten Branch einen Rebase. Auf dem M5 lief Codex auf
einem Feature-Branch mit uncommitted Heartbeat-Datei; dadurch hing der
Auto-Sync stundenlang fest, waehrend `main` mehrere Commits hinter
GitHub/Cluster-Mini-02 lag.

Der akute Fix ist `de7a510`: Wenn HEAD nicht `main` ist, wird nur der lokale
`main`-Ref fast-forwarded und der Lauf mit `BRANCH-SKIP` beendet.

## Folge-Fix

Die zweite Luecke war Alarm-Stille: Der Divergenz-Marker verhinderte
5-Minuten-Spam, unterdrueckte aber auch persistierende Drift ueber viele
Stunden. Der Marker darf daempfen, nicht verschweigen.

Regel:

- Erstalarm bei echter Divergenz setzt `_memory/.divergence-alarmed`.
- Folge-Laeufe innerhalb `NEXUS_SYNC_ALARM_REPEAT_SECONDS` loggen nur
  `ALARM unterdrueckt`.
- Nach Ablauf des Intervalls wird ein erneuter macOS-/Telegram-Reminder
  `DIVERGENZ PERSISTIERT` gesendet und der Marker aktualisiert.
- Default-Intervall: 3600 Sekunden. Tests koennen es per Env-Var senken.

## Konsolidierung

`agent/cron/recipes/nexus-pull.toml` ist deaktiviert. `nexus-sync.sh` ist der
kanonische Sync-Mechanismus, weil er branch-aware ist und Heartbeat,
Auto-Resolve, Health-JSON und Alarmierung in einem Pfad haelt.

## Verification

- `bash -n nexus-sync.sh`
- Temp-Repo-Smoke: branch-aware Feature-Branch-Lauf aktualisiert `main` via
  `MAIN-FF` und beendet mit `BRANCH-SKIP`.
- Temp-Repo-Smoke: echte Divergenz erzeugt Erstalarm, zweiten Lauf mit
  unterdruecktem Alarm und nach gealtertem Marker einen
  `DIVERGENZ PERSISTIERT`-Reminder.
- `python3 -m tomllib agent/cron/recipes/nexus-pull.toml`
- `git diff --check`
