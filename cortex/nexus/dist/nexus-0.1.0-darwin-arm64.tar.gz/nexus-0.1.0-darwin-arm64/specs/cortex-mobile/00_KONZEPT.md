---
type: spec-cortex-layer-project-stub
status: stub-2026-05-31
date: 2026-05-31
parent: ../cortex-platform/00_VISION_UND_ROADMAP.md (§10.10 + Phase 6)
owner: Dr. Stracke / Sanexio GmbH
license_status: proprietär (Juvantis-App-Funktionalität); spätere Generika-Schicht ggf. Open Source — Klärung in 03_PROJECT_OSS_CLASSIFICATION.md
---

# cortex-mobile — Cortex-Layer-Projekt (Stub)

> **Stub-Status 2026-05-31:** Spec angelegt nach §10.10-Entscheidung („Juvantis-App
> als eigenes Cortex-Layer-Projekt aufsetzen statt in Cortex-Web subsumieren").
> Inhaltliche Ausarbeitung kommt in eigener Welle, wenn Phase 6 (Cortex-Layer-
> Wachstum) gestartet wird oder wenn die Juvantis-App-Entwicklung auf
> Cluster-Mini-04 den Stub-Bedarf konkret macht.

## 1. Zweck

`cortex-mobile/` ist das Plattform-Slot für **iOS/App-Komponenten** innerhalb
des Cortex Layers. Erstes konsumierendes Projekt: die **Juvantis-App** (B2C-
Patienten-Frontend für Bluttests/DHT/Body-Checks, Anbindung an Juvantis-
Shopify und Patienten-Daten-Sharing).

## 2. Abgrenzung gegenüber Cortex-Web

| Aspekt | Cortex-Web | cortex-mobile |
|---|---|---|
| Plattform | Web (WordPress + Shopify + Astro) | iOS (perspektivisch + Android) |
| Lifecycle | git push → Adapter → Live-Deploy | App-Store-Review-Zyklus + Versions-Sprünge |
| Schema-Quelle | `trunk/schema/` (5 JSON-Schemas) | eigene App-State-Schemas (TBD) |
| Tenant-Slots | `sites/<tenant>/` | `apps/<tenant>/` (Konvention) |
| Build-Pipeline | Bun + Node-Adapter | Xcode + Fastlane + TestFlight (TBD) |

## 3. Juvantis-App-Status

Aktuell (2026-05-31): Juvantis-App-Entwicklung läuft auf Cluster-Mini-04
als Codex+Claude Co-Programming Sandbox unter `~/Cortex/projects/Juvantis/`.
Der Code lebt heute dort, nicht in cortex-mobile. **Migration in
cortex-mobile/-Slot erfolgt erst wenn:**

1. Ein zweites App-Projekt (anderer Tenant oder anderer Use-Case) Bedarf erzeugt — vorher ist Generalisierung verfrüht (siehe `feedback_lean_core_skill_periphery.md`).
2. Eine erste lauffähige Juvantis-App-Version existiert, an der das Slot-Schema kalibriert werden kann.

## 4. Open-Source-Frage (§10.1-Auftrag)

Juvantis-App selbst ist **proprietär** (Stracke-Aussage §10.1: „Juvantis-Shopify
Seite und die App bleiben proprietär"). Was an cortex-mobile **Open Source**
sein könnte ist die **generische App-Slot-Mechanik** (Build-Skripte,
Schema-Helper, Tenant-Trennung-Pattern für Apps) — analog zu Cortex-Web's
Trennung „Trunk + Adapter OSS / Tenant-Daten proprietär".

Klärung: kommt in `03_PROJECT_OSS_CLASSIFICATION.md` (eigene Klassifikations-Welle).

## 5. Stub-Inhalt

Dieses Dokument ist absichtlich klein. Ausarbeitung folgt erst bei aktiver
Welle 6 (Cortex Layer wächst, siehe `cortex-platform/00_VISION_UND_ROADMAP.md`
§11). Bis dahin reicht der Stub als:
- Anker im SYSTEM_MAP + _projects/INDEX
- Hinweis dass Juvantis-App nicht in Cortex-Web wandert
- Platzhalter für spätere Schema-/Adapter-/Build-Spezifikation

## 6. Querverweise

- `cortex-platform/00_VISION_UND_ROADMAP.md` §11 Phase 6
- `cortex-platform/02_OPEN_DECISIONS_RECOMMENDATIONS.md` §10.10
- `_projects/INDEX.md` (Eintrag wird in dieser Welle ergänzt)
