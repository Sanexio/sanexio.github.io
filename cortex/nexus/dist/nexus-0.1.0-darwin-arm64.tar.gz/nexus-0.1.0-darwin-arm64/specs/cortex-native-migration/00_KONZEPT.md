# Cortex-Native-Migration

> **Status:** Konzept + Wellen-Plan (2026-05-16).
> **Anlass:** Stracke-Feststellung — viele Custom-Komponenten duplizieren
> heute eingebaute Claude-Code-Funktionalität. Memory-Lesson
> `feedback_check_builtin_before_custom.md` (2026-05-16) festigt das
> Prinzip: vor Custom-Bau zuerst Standard-Plattform prüfen.

## Strategische Rollenteilung (Stracke-Festlegung 2026-05-16)

Bewusste Zweiteilung statt Komplett-Ablösung:

| Pfad | Rolle | Tool |
|---|---|---|
| **Info-Terminal** | Cortex-Mesh-Status, Permission-Approvals, Tier-3-Notifications, Geräte-Übersicht | Telegram-Bridge (custom — bleibt) |
| **Project-Work** | Live-Session-Mirror, Mobile-Steuerung laufender Sessions, Multi-Mac-Koordination | `claude remote-control` + `claude.ai/code` (native) |

Custom-Bridge wird nicht entsorgt, sondern auf ihre Stärke fokussiert. Wir
nutzen sie als pull-only Statusfenster und Permission-Approval-Channel,
nicht mehr als universelles Mobile-Interface.

## Welle R1 — Telegram-Bridge als Info-Terminal + Remote-Control für Project-Work

### Status: 2026-05-16, läuft

**Telegram-Bridge:**

- M5: Bridge installiert im `BRIDGE_MODE=passive` (nur reply-MCP, kein Polling). ✅
- Mac-Studio: bun installiert ✅, `gateway/.env` fehlt noch — User-Tier-3-Aktion.
- Cluster-Mini-02: läuft schon (Leader-Mac). Soll `BRIDGE_MODE=poll` in `gateway/.env` ergänzen, damit Default-passive nicht greift.
- Cluster-Mini-04: gleiches Setup wie Mac-Studio (Tier-3-Aktion).

**Remote-Control:**

Aktivierung pro Mac:

```bash
# Pro Session:
claude remote-control --spawn worktree

# Oder Auto-Start in Claude Code:
/config → "Enable Remote Control for all sessions" = true
```

Mobile-Zugriff: Spacebar im Terminal → QR-Code mit Claude-App scannen, oder `claude.ai/code` im Browser öffnen.

**Verbleibende Aufgabe für R1:**

- Cluster-Mini-02 `BRIDGE_MODE=poll` (Tier-3, User-Aktion).
- Pro Mac einmal `claude remote-control` testen, Auto-Start aktivieren.
- Tutorial 10 (Channel-Router) + Tutorial 14 (Recovery) um Remote-Control + Info-Terminal-Rolle ergänzen → siehe R6.

## Welle R2 — Cron-Recipes auf native CronCreate

### Status: geplant

**Heute:**

`agent/cron/recipes/*.toml` (TOML-Files) + `agent/cron/runner.py` (Python) + `com.cortex.phoenix-cron.plist` (LaunchAgent — nicht installiert).

Aktive Recipes:
- `nightly-sanitizer.toml`
- `tutorial-curator-weekly.toml`
- `connexio-inbox-notify.toml`
- (`nexus-pull.toml` deaktiviert — der LaunchAgent `com.cortex.nexus-sync.plist` macht das schon, ist genuin Cortex-spezifisch und BLEIBT).

**Migration:**

Native Claude-Code-Tools: `CronCreate`, `CronList`, `CronDelete`. Plus `/schedule`-Skill.

Mapping:

| Recipe | Native Cron-Job |
|---|---|
| `nightly-sanitizer` (täglich 3:30) | `CronCreate` mit `cortex-agent skill run sanitizer`, schedule `30 3 * * *` |
| `tutorial-curator-weekly` (wöchentlich) | `CronCreate` mit `cortex-agent skill run tutorial-curator`, schedule `0 4 * * 0` |
| `connexio-inbox-notify` (stündlich) | entfällt zugunsten von Real-Time-Notification über Remote-Control |
| `nexus-sync.sh` (alle 5 Min) | **bleibt LaunchAgent** — Git-Pull ist Cortex-Vault-spezifisch |

**Implementierung:**

1. Ein einmaliges Setup-Skript `tools/cortex-mode/bin/install_native_crons.sh`, das `CronCreate` für jede Recipe ausführt (via `claude` CLI in einer kurzlebigen Session).
2. `agent/cron/recipes/*.toml` mit `enabled = false` markieren (historische Referenz, nicht laufen lassen).
3. `agent/cron/runner.py` → deprecated-Marker im Docstring.
4. LaunchAgent-Plist `com.cortex.phoenix-cron.plist` aus `agent/cron/launchagents/` entfernen.

**Aufwand:** ~2 h. **Effekt:** ~500 Zeilen Python-Cron-Engine obsolet.

## Welle R3 — Spawn-System teil-stilllegen

### Status: geplant

**Heute:**

`agent/connexio/spawn_queue.py`, `spawn_watcher.py`, `spawn_forward.py`, `gateway/lib/spawn-queue.ts`. Bedient Telegram-`/spawn`-Kommando.

**Rollenteilung nach R1:**

- **Bridge-Spawn (bleibt)** — für Tier-3-Approval-Notifications, Permission-Requests. Cortex-spezifischer Workflow (lesson `feedback_check_builtin_before_custom.md` §„Custom-Workflows die über Standard hinaus").
- **Project-Spawn (nativ)** — für ad-hoc Session-Starts auf einem anderen Mac. `claude agents --bg` + `SendMessage`.

**Migration:**

1. `/spawn` in Bridge-Handlern auf Background-Notification-Only reduzieren (kein Code-Execution mehr aus Telegram heraus; nur Trigger ans Approval-Flow).
2. `agent/connexio/spawn_*.py` als "Permission-Notification-Subsystem" umetikettieren.
3. Background-Execution via native Tools dokumentieren — Beispiel-Workflow.

**Was bleibt:**

- Permission-Approval-Loop via Telegram `/verdict <id> yes|no` — das ist Cortex-Domain.
- Audit-Log für jede Spawn-Anfrage (R2-Compliance).

**Was raus:**

- Custom Spawn-Watcher als Daemon.
- Custom Spawn-Forward zwischen Macs (geht über `claude agents` + `SendMessage`).

**Aufwand:** ~4 h. **Effekt:** ~800 Zeilen Python.

## Welle R4 — Task-Tracking auf TaskCreate hybridisieren

### Status: geplant

**Heute:**

`agent/connexio/task_store.py` (~600 Zeilen) + `_memory/tasks-mirror/*.json` (gitversionierte Cross-Device-Tasks) + SQLite `_memory/tasks.db`.

**Native Tools:** `TaskCreate`, `TaskGet`, `TaskList`, `TaskOutput`, `TaskStop`, `TaskUpdate`.

**Hybridisierung:**

- **Claude-interne Tasks** (in einer Session): vollständig über `TaskCreate`-Tool, keine eigene Persistenz.
- **Multi-AI-Tasks** (Codex-Handoff, Cross-Device): `_memory/tasks-mirror/task-*.json` bleibt, weil Codex und andere KIs nicht in Claude Code's Task-State greifen. State-Machine-Logik in `task_store.py` reduziert auf Mirror + Validation.

**Migration:**

1. CLAUDE.md + AC §11 dokumentieren: Claude-interne Tasks → `TaskCreate`, Multi-AI-Tasks → Mirror.
2. `task_store.py` schlanker — entferne CRUD-Logik, behalte Schema-Validation und JSON-Mirror-Schreiben.
3. Connexio-MCP-Tools `handoff_to_agent`, `inbox_for_agent` weiter bedienen (cross-AI).

**Aufwand:** ~3 h. **Effekt:** ~450 Zeilen weniger Custom-Code.

## Welle R5 — Cortex-Skills als native Skills neu bauen

### Status: geplant

**Heute:**

13 Python-`@skill`-Funktionen in `agent/skills/builtin/`, aufrufbar via `cortex-agent skill run <name>`.

**Native Skills:** `~/.claude/skills/<name>/SKILL.md` mit beliebigem Code (Bash/Python/etc.). Werden von Claude Code automatisch geladen und können als Slash-Commands oder Auto-Trigger genutzt werden.

**Migration pro Skill:**

| Cortex-Skill | Native-Konversion |
|---|---|
| `doctor` | `~/.claude/skills/cortex-doctor/SKILL.md` mit Bash-Logik aus heutigem Python. Slash-Command `/cortex-doctor`. |
| `sanitizer` | `~/.claude/skills/cortex-sanitizer/SKILL.md`. Cron-getriggert via R2. |
| `capture-lesson` | `~/.claude/skills/cortex-capture-lesson/SKILL.md`. Slash-Command-Style mit Frontmatter-Args. |
| `tutorial-curator` | `~/.claude/skills/cortex-tutorial-curator/SKILL.md`. Wöchentliches Cron via R2. |
| `session-end`, `session-start` | Hooks (`SessionStart`/`Stop`) sind nativ — direkt in `~/.claude/settings.json` registrieren statt eigener Skill. |
| `pattern-miner` | bleibt experimentell, später als nativer Background-Agent. |
| `cron`, `scheduler` | obsolet durch R2 (native CronCreate/CronList). |
| `connexio`, `spawn`, `outbound` | Sonderfall — Multi-AI-Bridge bleibt Cortex-spezifisch. |
| `curator` | Stub heute, wird bei Bedarf nativer Skill. |

**Vorteil:** Skills sind dann ohne `cortex-agent` aufrufbar, ohne Python-Venv-Aktivierung, direkt aus jeder Claude-Session.

**Aufwand:** ~6 h (pro Skill ~30 Min Konversion + Test).

## Welle R6 — Tutorials auf neue Architektur aktualisieren

### Status: laufend (heute begonnen)

**Tutorials, die Updates brauchen:**

- **Modul 10 Channel-Router:** klare Rollendefinition Bridge = Info-Terminal vs Remote-Control = Project-Work.
- **Modul 06 Selbstlernendes System:** Hinweis auf nativen Auto-Memory.
- **Modul 08 Connexio:** Anti-Duplication-Hinweis (TaskCreate vs Multi-AI-Mirror).
- **Modul 09 Self-Learning-Layer:** Skill-Konversion-Pfad (R5).
- **Modul 13 Slash-Commands:** native Tools (`TaskCreate`, `CronCreate`, `ScheduleWakeup`) ergänzen.
- **Modul 14 Notfall + Recovery:** Remote-Control-Pfad als Recovery-Option.
- **Modul 15 Erweitern + Sichern:** dieser Migration-Spec verlinkt.

**Aufwand:** ~3 h.

## Reihenfolge-Empfehlung

R1 → R6 (Tutorials) → R2 → R4 → R3 → R5

- R1 zuerst (sofortiger Mobile-Access via Remote-Control).
- R6 Tutorials direkt danach, damit die neue Architektur dokumentiert ist, bevor Code-Migration läuft.
- R2 Cron-native: kleine Welle, hohes Reduktions-Verhältnis.
- R4 Task-Hybrid: mittel.
- R3 Spawn-Reduktion: erfordert Klarheit über Permission-Approval-Flow.
- R5 Skill-Konversion: ressourcenintensiv, am Ende, nachdem alle anderen Wellen die Cortex-Skill-Aufrufe lichter gemacht haben.

## Auswirkungen auf Public-Skeleton (`specs/cortex-public-skeleton/`)

Public-Variante wird mit der nativen Migration **deutlich schlanker**:
- Keine custom Bridge zwingend (Public-Teilnehmer nutzen `claude remote-control`).
- Keine eigene Cron-Engine.
- Keine custom Task-Store.

Was Public-Cortex behält:
- `_rules/`-Familie (Governance).
- Vault-Sync via Git.
- Spec-Sammlung.
- Cortex-Doctor, -Sanitizer als native Skills (R5).

## Code-Reduktions-Schätzung

| Welle | Custom-Code raus | Native-Adapter dazu | Netto |
|---|---|---|---|
| R1 | Bridge wird Info-Terminal — keine Reduktion, nur Rollenklärung | 0 | 0 |
| R2 | ~500 Zeilen | ~50 Zeilen | -450 |
| R3 | ~800 Zeilen | ~150 Zeilen | -650 |
| R4 | ~450 Zeilen | ~100 Zeilen | -350 |
| R5 | ~1500 Zeilen | ~600 Zeilen native Skills | -900 |
| R6 | nur Doku | nur Doku | 0 |
| **Gesamt** | ~3250 Zeilen | ~900 Zeilen | **~-2350 Zeilen** |

Realistischer als die früheren 4000 — wir behalten ja gezielt was nützlich ist.

## Querverweise

- Memory-Lesson: `feedback_check_builtin_before_custom.md` — Standard-Plattform-First-Prinzip.
- Public-Skeleton-Spec: `specs/cortex-public-skeleton/00_KONZEPT.md` — profitiert direkt von dieser Migration.
- Architecture-Refactor-Audit: `specs/architecture-refactor-2026-05/00_AUDIT.md` — vorausgegangener Refactor in der Cortex-Codebase.
