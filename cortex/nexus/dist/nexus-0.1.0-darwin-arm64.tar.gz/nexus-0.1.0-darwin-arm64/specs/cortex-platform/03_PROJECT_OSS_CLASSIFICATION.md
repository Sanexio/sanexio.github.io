---
type: spec-decision-package
status: decided-2026-05-31
date: 2026-05-31
decided_date: 2026-05-31
parent: 02_OPEN_DECISIONS_RECOMMENDATIONS.md (§10.1-Folgeauftrag)
owner: Dr. Stracke / Sanexio GmbH
---

> **STATUS:** Alle 16 Projekte sind am 2026-05-31 von Dr. Stracke klassifiziert.
> Antworten unten an jedem Punkt; konsolidierte Übersicht siehe Tabelle am Ende.
>
> **Kernpattern (Punkte 6/7/8 — Stracke-Originaltext „wie bei 6"):**
> „Skills, Hooks, Regeln etc... und Schablone OSS — Rest als privater Tenant".
> Das ist das **Framework/Tenant-Split-Pattern** und gilt analog zu Cortex-Web
> (Trunk + Adapter = OSS, `sites/<tenant>/` = privat). Wird als universelles
> Cortex-Layer-Aufnahme-Kriterium in `00_VISION_UND_ROADMAP.md` §4 verankert.
>
> **Konsolidierte Klassifikation:**
>
> | # | Projekt | Klassifikation | Konkret |
> |---|---|---|---|
> | 1 | Nexus | proprietär | bleibt public bis Build-Pipeline läuft, dann private |
> | 2a | Cortex-Web Praxiswebseite-Framework | OSS | bleibt public, §10.9-Welle raubt Stracke-Sites |
> | 2b | Cortex-Web Juvantis-Webseite-Slot | proprietär | wandert nach `sanexio-tenant` |
> | 3 | Sanexio-Tenant | proprietär (private) | unverändert |
> | 4 | praxis-webseite Theme | OSS | Tenant-Trennung + LICENSE + public-Switch nötig |
> | 5 | Juvantis | proprietär | unverändert |
> | 6 | Desk | **SPLIT** | Framework (Skills/Hooks/Regeln/Schablone) → neues OSS-Repo `cortex-desk`; Tenant-Inhalt → `sanexio-tenant/desk/` |
> | 7 | Praxis-QM | **SPLIT** | Framework → `cortex-qm` (OSS); QM-Inhalt → `sanexio-tenant/qm/` |
> | 8 | file-renamer | **SPLIT** | Framework → `cortex-rename` (OSS); Renaming-Regeln → `sanexio-tenant/rename-rules/` |
> | 9 | smartq-dashboard | **privat** | Patient-Daten-Scope, kein Distributionswert |
> | 10 | mail-connector | **privat** | Stracke-Praxis-Tunnel |
> | 11 | Telegram-Bridge | proprietär (in Nexus) | Spin-Off-Kandidat Phase 6 |
> | 12 | Gaming | privat | unverändert |
> | 13 | ARCHIV | privat | unverändert |
> | 14 | cortex-agent | proprietär (Teil Nexus) | Klon-Ordner aufräumen oder als git-worktree |
> | 15 | Praxis Monitoring + praxis-com-v1-archive | privat | unverändert |
> | 16 | cortex-mobile | gemischt | Juvantis-App-Code proprietär, generische Slot-Mechanik OSS-fähig wenn 2. konsumierendes Projekt kommt |
>
> **Daraus abgeleitete Folge-Wellen** (priorisiert nach Distributionswert):
> 1. **Cortex-Web Welle 1.3+1.5b**: Stracke-Sites + Juvantis-Webseite raus aus cortex-web, in sanexio-tenant rein (§10.9) → cortex-web bleibt sauber OSS.
> 2. **praxis-webseite Theme Anonymisierungs-Welle** → public-Switch.
> 3. **cortex-desk / cortex-qm / cortex-rename Repo-Anlage** mit Framework/Tenant-Split (drei neue OSS-Repos, jeweils mit Tenant-Inhalts-Migration nach sanexio-tenant).
> 4. **Nexus → private Repo-Switch** sobald Build-Pipeline (Phase 2) läuft.
> 5. **Phase 6 Spin-Off-Bewertungen**: Telegram-Bridge → cortex-bridge?, cortex-mobile-Slot-Mechanik?

---


# Projekt-OSS-Klassifikation — was wird Open Source, was bleibt proprietär

> **Auftrag:** Dr. Stracke nach §10.1-Entscheidung (2026-05-31, OSS-Distributionsmodell
> Aware-Health/Aniva-Style): „gehe doch nochmals alle Projekte durch und frage
> mich direkt, was als Open Source verwendet werden soll."
>
> **Vorgehen:** Pro Projekt eine Empfehlung mit Begründung. Du setzt darunter
> A/B/C oder eigene Klarstellung (wie bei §10). Erst nach Bestätigung wird die
> Klassifikation in `00_VISION_UND_ROADMAP.md` + `_projects/INDEX.md` final
> verankert.

## Klassifikations-Schema

- **OSS** = Open Source, Repo public (LICENSE: MIT oder Apache 2.0), Distribution
  als Distributionsmittel im Aware-Health/Aniva-Modell (gewinnt Ärzte für
  Sanexio-Plattform-Anbindung).
- **proprietär** = Sanexio-Hoheit, Source closed, kommerzielle Plattform-
  Komponente oder Sanexio-Geheim-Logik.
- **privat (Stracke-only)** = Persönlich, Praxis-intern, nicht-distributiv,
  kein Plattform-Bezug.

---

## 1. **Nexus**

- **Heute:** öffentliches GitHub-Repo `Sanexio/nexus`, enthält Stracke-Privates.
- **Empfehlung:** **proprietär**. Stracke-Originaltext §10.1: „Alles außer der
  Praxiswebseite mit den noch zu entwickelnden Tools soll proprietäre Software
  von Sanexio bleiben." → Nexus ist Plattform-Kern, klar proprietär.
- **Implikation:** Phase 2 Nexus-Build-Pipeline läuft wie geplant (Bun-Bundle +
  Python-Bytecode, §10.2-A). Repo wird perspektivisch von public auf private
  umgestellt nach Build-Pipeline-Stabilisierung. Übergang heute noch public,
  weil Stracke selbst auf Multi-Mac-Setup darauf angewiesen ist; sobald
  Build-Pipeline läuft, wechselt der Distributions-Pfad auf signierte
  Binaries und das Source-Repo geht private.

**Antwort Dr. Stracke: korrekt**

---

## 2. **Cortex-Web**

- **Heute:** öffentliches Repo `Sanexio/cortex-web`, OSS-Launch durch 2026-05-26.
  Enthält **Praxiswebseite-Teil** (`sites/praxis-webseite/` + Theme + Adapter)
  UND **Juvantis-Webseite-Teil** (`sites/juvantis-webseite/`).
- **Empfehlung:** **SPLIT — Praxiswebseite-Teil OSS, Juvantis-Webseite-Teil
  proprietär.**
  - **Praxiswebseite-Teil + Trunk + Adapter + Schemas + Tools = OSS**, weil
    Stracke-Originaltext §10.1: „Der Teil der OpenSource aktuell sein soll
    ist der Teil von Cortex Web, bei dem es um die Praxiswebseite geht".
  - **Juvantis-Webseite-Teil = proprietär**, weil Stracke §10.1: „Juvantis-
    Shopify Seite und die App bleiben proprietär".
- **Implikation:** §10.9-Entscheidung (Stracke-Sites raus aus cortex-web)
  bekommt eine Erweiterung: nicht nur Stracke-Sites, sondern auch das
  Juvantis-Webseite-Slot-Material muss raus. Konkret: Migration von
  `sites/praxis-webseite/` UND `sites/juvantis-webseite/` nach
  `Sanexio/sanexio-tenant`. Cortex-Web bleibt mit generischem
  Praxis-Framework + `sites/_examples/` als Demo.

**Antwort Dr. Stracke: korrekt**

---

## 3. **Sanexio-Tenant**

- **Heute:** privates Repo `Sanexio/sanexio-tenant`, Skelett seit 2026-05-24,
  Inhalt-Migration steht aus.
- **Empfehlung:** **proprietär (sogar private, nicht nur closed-source)**.
  Enthält Stracke-Tenant-Daten + zukünftig praxis-spezifische Konfigurationen.
  Niemals OSS.
- **Implikation:** Repo bleibt private. Welle 1.3 Inhalts-Migration (Praxis-/
  Juvantis-Daten aus Cortex-Web raus, in Sanexio-Tenant rein) als R1-Stracke-
  Welle.

**Antwort Dr. Stracke: korrekt**

---

## 4. **praxis-webseite** (Theme `Sanexio/praxiszentrum-theme`)

- **Heute:** dedicated repo `Sanexio/praxiszentrum-theme`, Blocksy-Child-Theme
  für WordPress, Local-Flywheel-Setup, HWG-konform.
- **Empfehlung:** **OSS** als Cortex-Layer-Distributionsmittel.
  Begründung: das ist genau das Aware-Health-/Aniva-Modell — ein
  HWG-konformes Praxis-Theme, das andere Ärzte 1:1 oder leicht angepasst
  nutzen können. Gratis-Theme zieht Ärzte ins Sanexio-Netzwerk; Sanexio-/
  Juvantis-Bindung via Footer-Pointer + Juvantis-Patienten-Onboarding-Flow.
  **Tenant-Trennung Pflicht** vor OSS-Switch: keine Praxis-Stracke-Inhalte,
  keine Telefonnummern, keine Team-Fotos im OSS-Repo — nur generisches
  Theme + Demo-Content.
- **Implikation:** Repo-Visibility-Switch auf public + LICENSE (MIT oder
  Apache 2.0) + Anonymisierungs-Welle (alle Stracke-Spezifika via tenant-
  config rauslösen, siehe Memory `feedback_schema_constants_are_architecture`).
  Das ist die nächste große Welle nach §10-Entscheidungs-Konsolidierung.

**Antwort Dr. Stracke: korrekt**

---

## 5. **Juvantis** (Repo `Sanexio/juvantis`)

- **Heute:** privates Repo `Sanexio/juvantis`, Juvantis-Produkte (DHT, Bluttests,
  Body-Checks), Shopify-Theme + Patienten-Plattform.
- **Empfehlung:** **proprietär**. Stracke-Originaltext §10.1: „Juvantis-Shopify
  Seite und die App bleiben proprietär und haben als Zielgruppe letzten Endes
  den Enduser - also Patient:innen". Das ist der Cashflow-Kern des
  Geschäftsmodells (Patienten-Abrechnung, Test-Bestellungen).
- **Implikation:** Repo bleibt private. Juvantis-App (cortex-mobile) und
  Juvantis-Webseite (heute in cortex-web → wird in sanexio-tenant migriert)
  bleiben proprietär.

**Antwort Dr. Stracke: korrekt**

---

## 6. **Desk** (`Sanexio/desk` · `~/Cortex/Desk`)

- **Heute:** 3. Top-Level-Verzeichnis seit 2026-05-22 (vormals `projects/doc-
  workflow`), produktiv auf SSMD-MacBookPro Intel.
- **Empfehlung:** **bedingt OSS-fähig — Klärung nötig**. Wenn Desk ein
  generisches Praxis-Dokumenten-Workflow-Tool ist (z.B. PDF-Verarbeitung,
  OCR, Renaming), passt es als „cortex-desk" ins OSS-Aware-Health-Modell.
  Wenn es Praxis-Stracke-spezifische Schreibtisch-Logik enthält (z.B.
  Patient-Inbox, SmartQ-Hooks), eher proprietär. **Stracke entscheidet
  basierend auf Inhalt.**
- **Frage:** ist Desk in Richtung „generisches Arzt-Dokumenten-Workflow-Tool"
  ausgerichtet, oder ist es Praxis-Stracke-Schreibtisch mit Tenant-Daten?

**Antwort Dr. Stracke: skills, hooks, regeln etc...  und schablone OSS - rest als privater tenant **

---

## 7. **Praxis-QM** (`~/Cortex/projects/praxis-qm`)

- **Heute:** Qualitätsmanagement-Tool für Praxis Dr. Stracke, lokal auf Intel-MBP.
- **Empfehlung:** **OSS-fähig als „cortex-qm"**. QM ist regulatorisch für
  jede Praxis Pflicht (ISO 9001 / G-BA / KV-Vorgaben) — ein generisches
  Praxis-QM-Tool ist klassischer Open-Source-Aware-Health-Distributions-
  kandidat. **Tenant-Trennung Pflicht** (Stracke-spezifische Anweisungen,
  konkrete Mitarbeiter, Patient-relevante QM-Punkte müssen raus).
- **Implikation:** Welle „QM-Tenant-Trennung" vor OSS-Repo-Switch. Praxis-
  Stracke-QM-Daten kommen nach `sanexio-tenant/qm/`, das generische
  Framework nach `Sanexio/cortex-qm` (neues OSS-Repo).

**Antwort Dr. Stracke: wie bei 6**

---

## 8. **file-renamer** (`~/Cortex/projects/file-renamer`)

- **Heute:** lokales Renaming-Tool, vermutlich für Praxis-Dokumente.
- **Empfehlung:** **OSS-fähig**, sehr generisch. Klassisches Tool, das jede
  Arztpraxis mit Papier-/PDF-Workflow gebrauchen kann. Aber **Klärung nötig**:
  ist das in einem Zustand, in dem es als eigenständiges OSS-Tool taugt,
  oder ist es Stracke-Quick-Hack-Niveau?
- **Implikation:** Wenn OSS-fähig: Repo-Anlage `Sanexio/file-renamer` (oder
  „cortex-rename") + LICENSE + README. Wenn Quick-Hack: bleibt privat bis
  Welle „Cleanup + Generalize" durch.

**Antwort Dr. Stracke: wie bei 6**

---

## 9. **smartq-dashboard** (`~/Cortex/projects/smartq-dashboard`)

- **Heute:** Dashboard für SmartQ (Praxis-Software). Wo wird das eingebunden?
- **Empfehlung:** **bedingt OSS-fähig — komplex**. SmartQ ist proprietäre
  Praxis-Verwaltungssoftware. Ein Open-Source-Dashboard, das andere
  SmartQ-User auch nutzen können, hat klaren Distributionswert (Ärzte mit
  SmartQ = Sanexio-Zielgruppe). Aber: das Dashboard zieht ggf. Patient-Daten
  → DSGVO-relevant. Wenn das Dashboard nur **Aggregate** verarbeitet (z.B.
  Umsatzstatistik, Termin-Auslastung) ohne Patient-Identifikation: OSS-fähig.
  Wenn es Patient-Level-Daten verarbeitet: proprietär oder gar nicht
  veröffentlichen.
- **Frage:** verarbeitet smartq-dashboard Patient-Identifikatoren oder nur
  aggregierte Praxis-Metriken?

**Antwort Dr. Stracke: privat**

---

## 10. **mail-connector** (`~/Cortex/projects/mail-connector`)

- **Heute:** auf M5 vorhanden, Inhalt unklar (vermutlich Mail-Integration
  für Connexio oder für SmartQ).
- **Empfehlung:** **Klärung nötig**. Wenn es generisch Mail → strukturierte
  Daten parst, OSS-fähig als „cortex-mail". Wenn es Praxis-Mail-Konten
  (Stracke-spezifisch) konsumiert, proprietär oder privat.
- **Frage:** ist mail-connector ein Generika-Tool oder ein Stracke-Praxis-
  Tunnel?

**Antwort Dr. Stracke: privat**

---

## 11. **Telegram-Bridge** (`Nexus/gateway/channels/telegram` + `Nexus/tools/telegram-bridge`)

- **Heute:** in Nexus geparkt (gateway-Schicht), läuft auf Cluster-Mini-02
  als produktiver Bot.
- **Empfehlung:** **derzeit proprietär** (in Nexus), aber **Kandidat für
  Spin-Off als „cortex-bridge"** in Phase 6 (Cortex Layer wächst). Eine
  generische Praxis-Kommunikations-Bridge (Telegram + Mail + iOS-Push) als
  OSS-Tool wäre starker Distributionsmittel-Kandidat (Aware-Health hat
  ähnliches). Aber Spin-Off erst, wenn die Bridge stabil ist + ein zweites
  konsumierendes Projekt Bedarf erzeugt.
- **Implikation:** für heute proprietär in Nexus-Repo. Phase-6-Welle prüft
  Spin-Off-Reife.

**Antwort Dr. Stracke: folge Deiner Entscheidung**

---

## 12. **Gaming** (`~/Cortex/projects/Gaming`)

- **Heute:** Hobby, auf Cluster-Mini-02.
- **Empfehlung:** **privat (nicht-distributiv)**. Kein Plattform-Bezug,
  bleibt im persönlichen Workspace ohne Repo-Veröffentlichung.

**Antwort Dr. Stracke: korrekt**

---

## 13. **ARCHIV** (`~/Cortex/projects/ARCHIV`)

- **Heute:** Archiv-Ordner, vermutlich abgelegte Projekt-Snapshots.
- **Empfehlung:** **privat**. Kein Distributionswert.

**Antwort Dr. Stracke:korrekt**

---

## 14. **cortex-agent** (`~/Cortex/Nexus/agent`, auch als `~/Cortex/projects/cortex-agent`-Klon auf C-M-02)

- **Heute:** Teil von Nexus (Agent-Loop, Skills, Memory, Connexio).
- **Empfehlung:** **proprietär** (Teil von Nexus, siehe §1). Nicht doppelt
  bewerten — auf C-M-02 ist es nur ein Klon des Nexus-internen Pfads.
  Der Klon-Ordner sollte aufgeräumt oder als git-worktree des Nexus-Repos
  geführt werden.

**Antwort Dr. Stracke:korrekt**

---

## 15. **Praxis Monitoring + praxis-com-v1-archive** (auf C-M-02)

- **Heute:** Stracke-spezifische Monitoring-/Archiv-Ordner.
- **Empfehlung:** **privat (Stracke-only)**. Keine Distribution.

**Antwort Dr. Stracke:korrekt**

---

## 16. **cortex-mobile** (neu in dieser Welle angelegt, `Nexus/specs/cortex-mobile/`)

- **Heute:** Spec-Stub seit 2026-05-31 (§10.10).
- **Empfehlung:** **gemischt**. Der konkrete Juvantis-App-Code = proprietär.
  Die **generische App-Slot-Mechanik** (Build-Skripte, Schema-Helper,
  Tenant-Trennung-Pattern für Apps) = OSS-fähig wenn ein zweites
  konsumierendes Projekt Bedarf zeigt. Heute Stub ohne Code.

**Antwort Dr. Stracke:korrekt**

---

## Zusammenfassung der Empfehlung (zur schnelleren Sichtung)

| Projekt | Empfehlung | Begründung kurz |
|---|---|---|
| Nexus | proprietär | Plattform-Kern (Stracke §10.1) |
| Cortex-Web Praxiswebseite-Teil | OSS | Aware-Health-Distributionsmittel |
| Cortex-Web Juvantis-Webseite-Teil | proprietär | Juvantis bleibt proprietär (Stracke §10.1) |
| Sanexio-Tenant | proprietär (privat-Repo) | Tenant-Daten |
| praxis-webseite Theme | OSS | Aware-Health-Distributionsmittel |
| Juvantis | proprietär | Cashflow-Kern, Stracke §10.1 |
| Desk | bedingt OSS | hängt am Inhalt — Frage offen |
| Praxis-QM | OSS-fähig nach Tenant-Trennung | regulatorisch wertvoll |
| file-renamer | bedingt OSS | hängt am Reife-Grad — Frage offen |
| smartq-dashboard | bedingt OSS | hängt an DSGVO-Daten-Scope — Frage offen |
| mail-connector | bedingt OSS | hängt am Generika-Grad — Frage offen |
| Telegram-Bridge | proprietär (vorerst) | Spin-Off in Phase 6 prüfen |
| Gaming | privat | kein Distributionswert |
| ARCHIV | privat | kein Distributionswert |
| cortex-agent | proprietär (Teil Nexus) | doppelt bewerten unnötig |
| Praxis-Monitoring + Archive | privat | Stracke-only |
| cortex-mobile | gemischt (App proprietär, Slot-Mechanik evtl. OSS) | Frage später |
Antwort Dr. Stracke: siehe Antworten oben
---

## Was nach Stracke-Bestätigung passiert

1. Klassifikation in `00_VISION_UND_ROADMAP.md` final verankern (§4 Cortex Layer + §5 User-Layer + neues §15 Repo-Visibility-Matrix).
2. `_projects/INDEX.md` um Spalte „License" / „Distribution" erweitern.
3. Pro OSS-Kandidat: Tenant-Trennungs-Welle planen (vor Public-Switch).
4. Pro proprietär-Markierung: Repo-Visibility checken (manche heute public, müssen private werden — z.B. Nexus, Cortex-Web Juvantis-Teil-Migration).

## Tier-3-Hinweis

Diese Klassifikation hat keine Echtgeld-Wirkung. R3-Business im weiteren
Sinn (Sanexio-Strategie), aber kein Bank/Bezahl-Trigger.
