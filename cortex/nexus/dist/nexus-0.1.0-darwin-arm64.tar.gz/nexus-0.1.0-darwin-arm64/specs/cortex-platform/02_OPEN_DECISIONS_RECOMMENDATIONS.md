---
type: spec-decision-package
status: decided-2026-05-31
date: 2026-05-31
decided_date: 2026-05-31
parent: 00_VISION_UND_ROADMAP.md (§10)
owner: Dr. Stracke / Sanexio GmbH
---

> **STATUS:** Alle 10 Punkte sind am 2026-05-31 von Dr. Stracke entschieden.
>
> Zusammenfassung (Antwort-Block jeweils unten an jedem Punkt):
> - §10.1 Lizenz-Modell → **Open Source** (Praxiswebseite-Teil von Cortex-Web + alle zukünftigen Praxis-Tools); Geschäftsmodell ist **Distributionsnetzwerk** (Aware-Health/Aniva-Style: Ärzte gewinnen wir mit Gratis-Tools, Cashflow läuft über Juvantis-Patienten-Plattform)
> - §10.2 Build-Stack → A (Bun-Bundle + Python-Bytecode, später .pkg)
> - §10.3 Update-Pfad → C (Hybrid: Auto-Check + Notification + manueller Klick)
> - §10.4 Tenant-Identity → B in Phase 5 (manuelle Sanexio-Prüfung), später C (Vertrauensnetzwerk) — gilt für Juvantis-Plattform-Anbindung, nicht für OSS-Tools (jeder Arzt darf OSS-Tools nutzen)
> - §10.5 Datenschutz → A (strikt on-prem)
> - §10.6 Wirtschaftliche Trennlinie → A (alles bei Sanexio GmbH)
> - §10.7 Tutorials-Öffentlichkeit → A (vollständig public via docs.cortex-plattform.org)
> - §10.8 Beitragsmodell → A (streng kuratiert, 2-Reviews-Required)
> - §10.9 Cortex-Web-Spaltung → A (Stracke-Sites raus aus cortex-web in sanexio-tenant)
> - §10.10 Juvantis-App → B (eigenes Cortex-Layer-Projekt `cortex-mobile/`) — **Stracke hat „gleich ab"-Direktive gegeben, Spec-Stub wird in dieser Welle angelegt**
>
> **Major Architecture Shift:** §10.1 ersetzt das ursprüngliche Plattform-Modell „Closed Binary mit Lizenz-Token" durch ein **OSS-Distributionsmodell**. Das ändert die Roadmap-Implikationen für Phase 3 (Cortex-CLI braucht keine Lizenz-Token-Validation mehr) und §10.4 (Tenant-Identity gilt nur noch für proprietäre Juvantis-Plattform-Anbindung).
>
> **Nächste Welle:** Stracke's §10.1-Auftrag „gehe alle Projekte durch + frage mich was Open Source sein soll" wird umgesetzt in `03_PROJECT_OSS_CLASSIFICATION.md` (separater Decision-Pass pro Projekt).


# Cortex-Plattform — §10 Offene Entscheidungen + Claude-Empfehlungen

> Ziel: jede der 10 in `00_VISION_UND_ROADMAP.md` §10 offenen Architektur-
> Entscheidungen mit Stand, Optionen, Implikationen und einer Claude-
> Empfehlung versehen, damit Dr. Stracke sie sequenziell durchgehen und
> haken kann. Erst nach Entscheidung kann Phase 2 (Nexus-Build) und
> Phase 3 (Cortex-CLI) starten.

---

## §10.1 — Lizenz-Modell für Nexus

**Stand:** offen. Vorgänger-Spec sprach von „Sanexio Nexus Runtime License".

**Optionen:**
- **A) SaaS-Subscription** (monatlich/jährlich, pro Tenant) — Cashflow vorhersehbar, kontinuierlicher Support nötig
- **B) Einmal-Lizenz pro Sitz/Praxis** — niedrigere Eintrittshürde, aber kein Wiederholungs-Cashflow
- **C) Praxis-Lizenz mit unbegrenzten Sitzen** (= eine Praxis bekommt eine Lizenz, alle Ärzte/Mitarbeiter dürfen sie nutzen) — fair für Praxis, schwerer kalibrierbar
- **D) Freemium** (Cortex Layer + eingeschränktes Nexus gratis, Vollversion bezahlt) — Onboarding-freundlich, Risiko: Gratis-User bleiben Gratis-User

**Claude-Empfehlung:** **C + jährlich**. Praxis-Lizenz vermeidet das „pro-Sitz-Zählen" (in Hausarztpraxen mit Vertretungs-/Teilzeitärzten administrativ unerquicklich). Jährliche Zahlung passt zum medizinischen Steuerjahr-Rhythmus. Konkurrenzprodukte wie SmartQ rechnen ähnlich (Praxis-basiert). Skalierung später via gestaffelte Praxisgrößen-Tarife (Solo-Praxis / Gemeinschaftspraxis / MVZ).

**Implikation für Code:** Lizenz-Token muss praxis-bound sein (`tenant_id` + `practice_size_tier`), nicht user-bound.

Antwort Dr. Stacke: ich möchte zunächst ein Open-Source Modell daraus machen. Damit du die Hintergründe verstehst, möchte ich an dieser Stelle
schon einmal das Geschäftsmodell beschreiben: Letzten Endes geht es darum ein Distributionsnetzwerk aufzubauen, welches an Cortex Web und 
Juvantis angedockt wird. Die Juvantis-Shopify Seite und die App bleiben propietär und haben als Zielgruppe letzten Endes den Enduser - also
Patient:innen; Ärzte können prizipiell sich hieran beteiligen, indem Sie ihren Patienten die Infrastruktur zur Verfügung stellen und sich ihre
Patienten auf der Plattform anmelden. Die Ärtze können dann die Blutentnahme und die Werte selbst abrechnen; die Daten sollen aber über die 
Juvantis Plattform mit den Patienten geteilt werden. Noch besser ist eine Kooperation mit den Ärzten, die für die Blutentnahmen entlohnt 
werden, aber die Abrechnung über Sanexio selbst erfolgt; wenn du schauen willst, wie das Konzept prinzipiell funktionieren soll, dann schaue
dir an wie es Aware-Health und Aniva machen, dann hast du eine Vorstellung davon. 
Um die Ärtze für die Plattform und das Netzwerk zu gewinnen soll alles, was mit digitaler Infrastruktur über die Praxiswebseite abgebildet 
werden kann als OpenSource zur Verfügung gestellt werden. Ggfs. wechseln wir hier im weiteren Verlauf zu einem Freemium Modell, aber zunächst
soll es Open Source sein. Noch mal für Dich: Der Teil der OpenSource aktuell sein soll ist der Teil von Cotex Web, bei dem es um die 
Praxiswebseite geht - alle Funktionaliäten der Webseite, die wir im weiteren Verlauf ausbauen, sollen den Ärzten über Sanexio zur Verfügung 
gestellt werden, damit sie es nahtlos selbst implementieren können. Ziel ist aber, dass die Verbindung zu Sanexio und Juvantis bestehen bleibt
und wir über die Freie Software, die wir anderen Ärzten zur Verfügung stellen User für die Juvantis Plattform generieren. 
Alles außer der Praxiswebseite mit den noch zu entwickelnden Tools soll proprietäre Software  von Sanexio bleiben. 
Mein Vorschlag hier, um zu verstehen, was Opensource sein soll und was nicht, gehe doch noch mals alle Projekte durch und frage mich direkt, 
was als Open Source verwendet werden soll. 
---

## §10.2 — Build-/Deploy-Stack für Nexus-Closed-Binary

**Stand:** offen. Heutiger Source-Stack: Bun (TypeScript) + Python 3.14 + Bash + SQLite. Vault: Obsidian-Markdown.

**Optionen:**
- **A) Bun-Bundle + Python-Bytecode** — `.pyc` + Bun-binary für Gateway/Agent, Bash bleibt lesbar (kein Schutz dort)
- **B) PyInstaller / Nuitka für Python + Bun-Compile** — Python wird zu native binary, schwerer reverse-engineerbar
- **C) Docker-Container** — alles in Image gepackt, signiert, distributed via Docker Hub Private oder eigene Registry
- **D) macOS-.pkg-Installer mit signiertem Bundle** — native macOS-Erfahrung, App Store-fähig

**Claude-Empfehlung:** **A** als Phase-2-MVP, **D** als Phase-3-Polish.  
Begründung: Bun-Bundle ist heute schon Teil der Codebasis (`gateway/`). Python-Bytecode ist schwach, aber genug für „nicht trivial lesbar" — Schutz primär juristisch (Lizenz), nicht technisch (Memory §00_VISION §12: „akzeptieren, dass technische Hürde imperfekt ist"). Docker fügt eine Layer Komplexität hinzu, die Stracke-Macs (nicht-Linux-erfahrene Ärzte) nicht wollen. PKG-Installer kommt später, wenn Cortex-CLI stabil ist.

**Implikation:** Phase 2 = Bun-Bundle-Build-Script + py_compile-Pipeline + Manifest-Sign mit `codesign`. Schutz-Hürde gegen Reverse-Engineering bleibt niedrig — Tier-Schutz ist die Lizenz, nicht Crypto.

Antwort Dr. Stacke: ich folge Deiner Empfehlung
---

## §10.3 — Update-Pfad: Auto-Update vs. manuelles `cortex update`

**Optionen:**
- **A) Auto-Update App-Store-Stil** — User merkt nichts, Sanexio-Push bestimmt Tempo
- **B) `cortex update` manuell** — User-Kontrolle, Stracke-Eindruck: "Mac-User wollen das so"
- **C) Hybrid:** Auto-Check + Notification + manueller Klick

**Claude-Empfehlung:** **C**. Auto-Check täglich, Notification via macOS-Notification-Center bei verfügbarer Version, Update läuft erst nach User-Bestätigung. Verhindert „Update überrascht User während Patient-Termin" + ermöglicht Sanexio, Sicherheits-Updates schnell auszurollen.

**Implikation:** `cortex-cli` braucht Background-LaunchAgent + UI-Hook für Notification.

Anwort Dr. Stacke: ich folge Deiner Empfehlung
---

## §10.4 — Tenant-Identity: Wie wird ein neuer Tenant geprüft?

**Optionen:**
- **A) Approbationsnummer-Validierung** gegen Ärztekammer-API — wenn API existiert
- **B) Sanexio-manuelle Prüfung** — Dr. Stracke (oder Sanexio-Team) prüft jeden Tenant initial
- **C) Vertrauensnetzwerk** — bestehende Tenants können neue einladen, mit Sanexio-Veto-Recht
- **D) Kein Check** — nur Lizenz-Zahlung, jeder bekommt Token

**Claude-Empfehlung:** **B in Phase 5 (Pilot mit 1–3 Tenants)**, später **C** wenn Skalierung kommt. **A** ist technisch fragil (Ärztekammer-APIs sind regional zerstückelt, BÄK hat keinen zentralen Validation-Endpoint).

**Implikation:** Sanexio-Onboarding-Inbox + Tenant-Registry-Tabelle. Keine technische API-Integration in Phase 2/3 nötig.

Antwort Dr. Stracke: ich folge Deiner Empfehlung
---

## §10.5 — Datenschutz: Tenant-Daten on-prem vs. optional Cloud-synced

**Optionen:**
- **A) Strikt on-prem** — Tenant-Daten verlassen den Mac nie, kein Cloud-Sync
- **B) Optional Cloud-Sync via Sanexio-eigenem Server** — Tenant kann zustimmen, Daten landen in Sanexio-Cloud
- **C) Optional Cloud-Sync via Tenant-eigener Cloud** (iCloud / Tenant's privater Server) — Sanexio sieht nichts

**Claude-Empfehlung:** **A für Phase 5**. DSGVO-Komplexität bei B ist erheblich (Auftragsverarbeitungs-Vertrag, BDSG, Patient-Einwilligungen). Sanexio-Cloud zu betreiben heißt Sanexio wird DSGVO-Verantwortlicher für Tenant-Daten = Haftungs-Eskalation. **C** ist technisch attraktiv aber operativ schwer (iCloud-Sync ist nicht audit-fähig). Strict on-prem = klares Marketing-Argument („Ihre Patientendaten verlassen Ihre Praxis nicht").

Multi-Mac-Sync **innerhalb einer Praxis** (Tenant hat 3 Macs in seiner Praxis): erlaubt über Tailscale-Mesh oder identischen Sync-Mechanismus wie heute Stracke nutzt. Das ist immer noch on-prem (kein externer Server).

**Implikation:** Nexus-Sync braucht eine `tenant_local_only`-Flag, die externe Push-Targets (GitHub) sperrt; alternativ jeder Tenant nutzt eigenes private GitHub für Multi-Mac.

Antowrt Dr. Stracke: ich folge Deiner Empfehlung
---

## §10.6 — Wirtschaftliche Trennlinie Praxis Dr. Stracke ↔ Sanexio GmbH

**Stand:** offen. Heute alles Stracke. Lizenz-Einnahmen aus Plattform sollen wo landen?

**Optionen:**
- **A) Alles bei Sanexio GmbH** — Lizenz-Einnahmen, Plattform-Entwicklung, Cortex-Praxis-Praxis-spezifische Verträge
- **B) Sanexio bekommt Plattform-Lizenz, Praxis bekommt Praxis-spezifische Verträge** (z.B. wenn Sanexio Cortex-Praxis-Service an einzelne Praxen verkauft, fließt das durch Praxis Dr. Stracke)
- **C) Split-Modell** — feste prozentuale Aufteilung zwischen Sanexio und Praxis

**Claude-Empfehlung:** **A**. Sanexio GmbH ist das Plattform-Vehikel (so der Spec-Header), Praxis Dr. Stracke ist Kunde/Tenant Nr. 1. Klare Trennung erleichtert Steuer- und Sozialversicherungs-Themen. Praxis bezahlt Sanexio die normale Tenant-Lizenz.

**Implikation:** Sanexio-Buchhaltung muss separat geführt werden; Praxis ist Tenant in der gleichen Datenbank wie spätere externe Tenants. Tier-3-Boundary: Sanexio-Konten ≠ Praxis-Konten — `agent/modes/tier3.md` muss das ggf. präzisieren.

Antwort Dr. Stracke: ich folge Deiner Empfehlung
---

## §10.7 — Tutorials-Öffentlichkeit: vollständig public oder lizenzgebunden

**Optionen:**
- **A) Vollständig public** — `docs.cortex-plattform.org` zeigt alle Tutorials lesbar ohne Login
- **B) Teaser public + Volltext nur für Lizenznehmer** — Marketing-Demos public, „echte" Inhalte Login-pflichtig
- **C) Strikt lizenzgebunden** — nur Tenant kann Tutorials lesen

**Claude-Empfehlung:** **A**. Tutorials sind Sanexio-Marketing („sehen Sie wie modern, ärztefreundlich, durchdacht das ist") → muss frei zugänglich sein, sonst gewinnt es keine Mund-zu-Mund-Empfehlung. Was lizenzgebunden bleibt: Second Brain (Praxis-internes Wissen, Tier-Strukturen, Konkrete Konfigurationen).

**Implikation:** Tutorials werden statisch generiert (z.B. Astro/MkDocs aus `Second Brain/30 Tutorials/`) und nach `docs.cortex-plattform.org` gepublished. Build-Pipeline triggern bei Push auf `main` in Nexus-Repo (intern, da Source closed bleibt — Trigger via signiertem CI-Webhook).

Antwort Dr. Stracke: ich folge Deiner Empfehlung
---

## §10.8 — Beitragsmodell für Cortex Layer (PR-Review-Pipeline)

**Optionen:**
- **A) Streng kuratiert** — jeder PR braucht Sanexio-Review (Stracke + 1 Co-Maintainer), 2-Personen-Approval
- **B) Trusted-Contributors-Pool** — bekannte Contributors dürfen direkt mergen
- **C) Locker** — alle PRs werden zügig gemerged, später aufgeräumt

**Claude-Empfehlung:** **A in Phase 4–5**. Cortex-Web als erstes OSS-Projekt braucht Qualitäts-Anker (Sanexio-Reputation hängt am Code). Später **B** wenn Vertrauen aufgebaut. **C** würde Sanexio's Markenversprechen unterminieren.

**Implikation:** GitHub-Branch-Protection auf `Sanexio/cortex-web/main` mit „2 reviews required, code-owners required". Code-Owner-Datei pflegen.

Antwort Dr. Stracke: ich folge Deiner Entscheidung
---

## §10.9 — Cortex-Web-Restspaltung: Stracke-Sites bleiben oder gehen raus?

**Heute (Stand 2026-05-31):**
- `sites/praxis-webseite/` und `sites/juvantis-webseite/` sind weiterhin im Open-Source-Repo `Sanexio/cortex-web` (kein History-Cleanup vor OSS-Launch durchgeführt — laut PHOENIX_RESUME ist OSS-Launch 2026-05-26 trotzdem durch).
- Heute Vormittag (2026-05-31) auf den Drift-Macs entdeckt: das filter-repo der OSS-Welle hat Tenant-Daten **aus der History** entfernt, aber `sites/praxis-webseite/` ist nicht weg.

**Optionen:**
- **A) Stracke-Sites raus aus cortex-web, in Sanexio-Tenant rein** — sauber, OSS-Repo enthält nur generisches Material + `sites/_examples/`. Verlust: keine Live-Beispiele im Public-Repo.
- **B) Stracke-Sites bleiben als „Sanexio-Example-Tenant"** — OSS-Repo zeigt live, wie ein Tenant aussieht (Demo-Wert hoch). Risiko: Tenant-Daten leaken (Memory `feedback_distribution_is_own_axis`).
- **C) Hybrid:** Stracke-Sites bleiben in einem geschützten Sub-Repo `cortex-web-examples` (private Submodule), Public-Repo zeigt nur Stubs.

**Claude-Empfehlung:** **A**. Praxis-Webseite ist HWG-Berufsordnungs-relevant (siehe Cortex-Web `CLAUDE.md`: „HWG-/Berufsordnungs-konform, keine Preise, kein Anpreisen") — wenn das in Public-Repo liegt, kann jeder Konkurrent das 1:1 spiegeln. Juvantis-Site hat Shop-Spezifika (DHT-Produkte), die nicht generisch sind. „Live-Demo" lässt sich später als `sites/_demo-praxis/` mit Fake-Daten bauen, falls Marketing das braucht.

**Implikation:** Phase 2-Welle in Cortex-Web: `sites/praxis-webseite/` + `sites/juvantis-webseite/` rüberziehen nach `Sanexio/sanexio-tenant`. Adapter-Konfiguration muss Tenant-Pfad-Helper (`tenant-path.{sh,mjs}`) konsumieren — das ist Welle 1.5 abgeschlossen.

Antworte Dr. Stacke: ich folge Deiner Empfehlung
---

## §10.10 — Juvantis-App: Cortex-Web subsumieren oder eigenes Cortex-Layer-Projekt?

**Stand:** Juvantis ist heute eigenes Projekt unter `~/Cortex/projects/Juvantis/`. Juvantis-Webseite ist als `sites/juvantis-webseite/` in Cortex-Web. Eine iOS/App-Komponente steht noch aus.

**Optionen:**
- **A) Juvantis-App als `sites/juvantis-app/` in Cortex-Web** — alles unter einem Trunk, ein Schema
- **B) Eigenes Cortex-Layer-Projekt `cortex-mobile/`** — iOS/App-Generika-Framework, mehrere Tenants später bedienbar
- **C) Bleibt unter `Juvantis/`** — projekt-spezifisch, nie generalisiert

**Claude-Empfehlung:** **B**. App-Entwicklung hat fundamental andere Lifecycle-Mechanik als Web (App-Store-Reviews, Versions-Sprünge, Build-Pipelines). In Cortex-Web subsumieren würde den Web-Trunk verunreinigen. Als eigenes Cortex-Layer-Projekt aufsetzen lässt es später für andere Praxen/Shops wiederverwendbar werden (parallel zu Cortex-Web).

**Implikation:** Phase 6 (Cortex Layer wächst) wird um `cortex-mobile/` erweitert. Juvantis-Spezifika bleiben im Sanexio-Tenant unter `tenant-data/juvantis-app/`. Aktuell laufende Juvantis-App-Arbeit auf Cluster-Mini-04 (Codex+Claude Co-Programming) bleibt unverändert; nur das Ziel-Repo verschiebt sich später.

Antwort Dr. Stacke: ich folge Deiner Entscheidung; gleich hier mit dem ersten Punkt ab - das sollte dem nicht widersprechen
---

## Vorschlag Vorgehen

1. Dr. Stracke geht diese 10 Punkte einzeln durch und setzt eine Entscheidung (A/B/C/D pro Punkt).
2. Pro entschiedenem Punkt: Memory-Update mit Begründung, devices.json/specs-Update wo nötig.
3. Erst dann Phase 2 (Nexus-Build) und Phase 3 (Cortex-CLI) starten.
4. **Kein-Stop**-Empfehlungen aus dieser Liste: §10.2 (Build-Stack) ist Voraussetzung für Phase 2; §10.4 (Tenant-Identity) ist Voraussetzung für Phase 5; alle anderen können während Phase 2/3 parallel entschieden werden.

## Tier-3-Hinweis

Diese Entscheidungen sind R3-Business (Stracke-Hoheit). Claude hat hier nicht gemerged, nicht freigegeben, nichts vorab umgesetzt — nur recherchiert + strukturiert.
