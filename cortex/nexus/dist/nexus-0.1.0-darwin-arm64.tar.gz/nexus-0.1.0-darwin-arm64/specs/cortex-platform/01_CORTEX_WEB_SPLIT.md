---
type: spec-adr
status: phase-1-complete-2026-05-24
decision: Option A (zwei Repos) — bestätigt 2026-05-24, ausgeführt am gleichen Tag
date: 2026-05-24
parent: 00_VISION_UND_ROADMAP.md (§10.9)
owner: Dr. Stracke / Sanexio GmbH
---

# Cortex-Web-Spaltung — Architektur-Entscheidung

> **STATUS-UPDATE 2026-05-24 abend:** Phase 1 (alle 5 Sub-Wellen) ist
> abgeschlossen. Tenant-Trennung ist operativ.
>
> - 1.1 ✅ `_examples/`-Demo + tenant-path-Helper (Bash) + Slot-Vertrag
> - 1.2 ✅ Privates Repo `Sanexio/sanexio-tenant` angelegt + Skelett
> - 1.3 ✅ Migration via `git filter-repo`: 131 Commits + 332 Files in
>          Sanexio-Tenant; Cortex-Web bereinigt (kein History-Rewrite —
>          Force-Push ist Welle 2.x vor OSS-Launch)
> - 1.4 ✅ 3 neue Konvergenz-Steps (sanexio_tenant_clone,
>          sanexio_tenant_mirror_launchd, cortex_tenant_dir_envvar);
>          devices.json auf Cluster-Mini-02 + Mac-Studio nachgezogen
> - 1.5 ✅ JS-Helper `tenant-path.mjs`, Pilot-Adapter `build-team.mjs`
>          umgestellt, README + LICENSE (Apache 2.0) + CONTRIBUTING,
>          Tutorial-Modul 05-tenant-trennung.md
>
> **Was bleibt** (Phase 2, eigene Wellen):
> - Restliche Adapter umstellen (~10 Adapter, hartcodierte
>   trunk/content-Pfade → tenantPath())
> - 67 Linter-Treffer abarbeiten (Renames, README-Anonymisierungen,
>   Spec-Evidence-Markierungen)
> - History-Cleanup auf cortex-web/main vor öffentlichem OSS-Launch
> - Juvantis-App-Subsumption (§10.10)
> - Plattform-Entscheidungen §10 (Lizenz, Build-Stack, Tenant-Identity)


> **Kontext:** §10.9 des Plattform-Specs fordert eine Entscheidung, wie
> Stracke-spezifische Tenant-Daten von der generischen Cortex-Layer-
> Framework-Codebasis getrennt werden. Diese Trennung ist Voraussetzung
> für den Open-Source-Launch von Cortex-Web.

---

## 1. Inventur — was steckt heute im Repo?

Vollständige Bestandsaufnahme von `~/Cortex/projects/Cortex-Web/` (Stand 2026-05-24):

### Generisches Framework (Open-Source-fähig, kein Stracke-Bezug)

| Pfad | Inhalt | Bemerkung |
|------|--------|-----------|
| `trunk/schema/` | 5 JSON-Schemas (page, product, team-member, component, media) | rein generisch |
| `adapters/wordpress/` | Build-Skripte für WP-Pages, Services, Team | generisch |
| `adapters/shopify/` | Build-Skripte für Templates, Pages | generisch |
| `adapters/astro/` | team-to-astro, build.mjs | generisch (neu Welle S80) |
| `adapters/ios/` | README (Platzhalter für Phase Pios) | leer |
| `tools/` (24 Skripte) | validate, sync-*, mirror-sync, promote-to-trunk, … | überwiegend generisch (Ausnahme: shopify-authorize.sh hat Stracke-Spuren) |
| `_integration-slots/` | Slot-System (heute eingeführt) | generisch |
| `_config/RULES.md` | CW-001 … CW-009 | generisch |
| `_rules/ARCHITECTURE.md`, `WORKING_MODE.md`, `PRE_FLIGHT_CHECKLIST.md` | generisches Architekten-Modus-Material | überwiegend generisch, mit Stracke-Beispielen |
| `specs/bridge-strategy/`, `cross-site-transfer/`, `phase-*/` | Strategie-Dokumente | meist generisch mit Stracke-Bezug-Markierungen |

### Stracke-Tenant-Daten (Praxis Dr. Stracke + Sanexio/Juvantis)

| Pfad | Inhalt | Größe |
|------|--------|-------|
| `trunk/content/team/dr-*.yaml` | 7 Arzt-Profile der Praxis | ~32 KB |
| `trunk/content/pages/praxis/*.yaml` | Praxis-Stracke-Seiten (Standorte, Service, Aktuelles, …) | großer Teil der 396 KB Pages |
| `trunk/content/pages/juvantis/*.yaml` | Juvantis-Site-Pages | (Rest der 396 KB) |
| `trunk/content/products/` | Juvantis-Produkte (DHT, Bluttests, …) | ~44 KB |
| `trunk/media/` | Praxisfotos, Produktbilder (Metadata-Registry) | klein, aber zeigt auf private Bilder |
| `sites/praxis-webseite/` | komplettes Praxis-WP-Theme `praxiszentrum` | **215 Files** |
| `sites/juvantis-webseite/` | Juvantis-Site-Docs + SHOPIFY_THEME_POINTER | 15 Files |
| `sites/sanexio-github-io/` | Sanexio-Hauptseite (Astro) | 4 Files |

### Bereits richtig getrennt
- `_media-source/` ist gitignored — lokal Original-Medien, korrekt.
- `adapters/*/.backups/` gitignored — Backup-Artefakte.

---

## 2. Drei Spaltungs-Optionen

### Option A — Strikte Repo-Spaltung (zwei Repos)

```
Sanexio/cortex-web              ← Public, Framework only
└── trunk/_examples/            ← Demo-Tenant-Inhalt (1 Beispiel-Praxis)

Sanexio/sanexio-tenant          ← Privat, Stracke-Daten
├── trunk/content/              ← Praxis + Juvantis Content
└── sites/                      ← Theme-Codebasen
```

User-Workflow:
```
~/Cortex/projects/
├── Cortex-Web/                 ← Public-Clone (Mirror auf allen Macs)
└── Sanexio-Tenant/             ← Private-Clone (nur Stracke-Macs)
```

Adapter werden konfigurierbar:
```bash
CORTEX_TENANT_DIR=$HOME/Cortex/projects/Sanexio-Tenant \
  bash tools/sync-wp.sh
```

**Pro:** maximale Sauberkeit; Public-Repo ist sofort OSS-ready; klare Verantwortungs-Trennung; Stracke-Daten in privatem GitHub-Repo verfügbar für Multi-Mac-Sync.

**Contra:** Stracke arbeitet immer mit zwei Repos parallel; Pfad-Konfiguration in Adaptern muss generisch werden; bestehende Specs/Tutorials brauchen Pfad-Updates; git-Historie-Migration braucht `git filter-repo`.

---

### Option B — Monorepo mit `.tenant/`-Verzeichnis

```
Sanexio/cortex-web (gleiches Repo)
├── trunk/_examples/            ← Demo-Inhalt (im Repo, public)
├── trunk/_examples/team/*.yaml
├── trunk/_examples/pages/*.yaml
├── .tenant/                    ← Stracke-Daten (gitignored)
│   ├── trunk/
│   └── sites/
└── adapters/                   ← lesen wahlweise aus .tenant/ oder _examples/
```

**Pro:** ein Repo, weniger Onboarding-Komplexität; Stracke-Daten bleiben unsichtbar im Public-Repo.

**Contra:** Stracke-Daten brauchen anderen Sync-Mechanismus (NAS/iCloud) → kein Git-Tracking → Multi-Mac-Sync wird fragil; wenn versehentlich `git add .tenant/` läuft, sind echte Daten im Public-Push → schwerer Reput-Schaden; keine Historie für Stracke-Tenant-Daten.

---

### Option C — Subtree-Hybrid

```
Sanexio/cortex-web              ← Public Framework
└── (kein .tenant/)

Sanexio/sanexio-tenant          ← Privat, Tenant-Daten
```

Auf Stracke-Macs wird das Tenant-Repo per `git subtree add` als Unter-Verzeichnis `_tenant/` ins Cortex-Web eingebettet. Sync-Workflow:
- `git subtree pull --prefix=_tenant sanexio-tenant main` für Updates
- `git subtree push --prefix=_tenant sanexio-tenant main` für Beiträge

**Pro:** lokal ein Verzeichnis-Baum (wie heute), zwei Remotes; Historie bleibt erhalten in beiden Repos.

**Contra:** `git subtree` ist eines der fehleranfälligsten Git-Features (Konflikte, Push/Pull-Semantik); auf jedem Mac komplexer Re-Setup nötig; nicht skalierbar bei mehreren Tenants.

---

## 3. Empfehlung — Option A

**Begründung:**

1. **Multi-Mac-Sync für Stracke ist Pflicht** (heute schon: 2 primary Macs + 3 mirror). Das schließt Option B aus, weil ohne Git-Sync der Tenant keine konsistente Multi-Device-Story hat.
2. **Open-Source-Hygiene** ist mit Option A am wenigsten anfällig für Unfälle. Ein versehentlich committetes Patient-Foto in einem Public-Repo wäre ein Reputations- und ggf. DSGVO-Vorfall — Option B macht diesen Unfall pro Commit möglich.
3. **Option C (Subtree)** verlangt von jedem Stracke-Mac komplexe Initialisierung und erzeugt schwer debuggbare Konflikt-Klassen. Multi-Tenant-Skalierung schlecht.
4. **Option A entspricht der Zwiebel-Architektur** aus dem Hauptspec direkt: Tenant-Layer ist außen, Cortex-Layer-Projekt ist innen, beide haben eigene Lifecycle.

**Trade-off akzeptieren:** Stracke arbeitet ab Phase 1 mit zwei Cortex-Web-bezogenen Repos. Das ist eine bewusste Komplexitäts-Kosten gegen Hygiene + Skalierbarkeit.

---

## 4. Konkrete Migration (Roadmap)

**Phase 1.1 — Vorbereitung *(1 Welle, ~30 Min)***
- `_examples/`-Skelett in Cortex-Web anlegen: 1 anonymisierter „Beispiel-Arzt" + 1 „Beispiel-Praxis-Seite" + 1 „Beispiel-Produkt".
- Adapter um `CORTEX_TENANT_DIR`-ENV-Variable erweitern (Default: `./trunk/_examples`, override = Stracke-Tenant-Pfad).
- `_integration-slots/`-Vertrag um Tenant-Awareness erweitern: Slot deklariert „operates-on: framework | tenant".

**Phase 1.2 — Repo-Anlage *(1 Welle)***
- Privates GitHub-Repo `Sanexio/sanexio-tenant` anlegen.
- Lokales Repo `~/Cortex/projects/Sanexio-Tenant/` initialisieren mit Skelett:
  ```
  Sanexio-Tenant/
  ├── README.md
  ├── trunk/
  │   ├── content/
  │   ├── media/
  │   └── design/    ← Stracke-spezifische Tokens (Praxisfarben)
  └── sites/
  ```

**Phase 1.3 — Migration mit Historie *(1 Welle, sensibel)***
- `git filter-repo --path trunk/content/ --path sites/` auf einer Cortex-Web-Kopie → extrahierter Stracke-Branch.
- In Sanexio-Tenant-Repo importieren.
- Im Original-Cortex-Web: `git rm` der Tenant-Daten (mit Verweis auf Sanexio-Tenant in CHANGELOG).
- Verify: kein Stracke-Inhalt mehr im Public-Repo, alle Adapter laufen mit `CORTEX_TENANT_DIR=…/Sanexio-Tenant`.

**Phase 1.4 — Mirror-Setup für Tenant-Repo *(1 Welle)***
- Cortex-Web-Mirror-Sync analog auf Sanexio-Tenant erweitern? Nein — Tenant-Repo wird wie ein normales Projekt manuell behandelt (Push nach Bearbeitung). Mirror nur für Public-Repo.
- Stracke-Konvergenz-Schritt ergänzen: `sanexio_tenant_clone` (nur auf Stracke-Macs aktiv, via Tenant-Identity-Marker).

**Phase 1.5 — Doku-Update + OSS-Launch-Bereitschaft *(1 Welle)***
- Cortex-Web-README: deklarierte OSS-Lizenz (MIT/Apache, Entscheidung §10.1 im Hauptspec).
- `CONTRIBUTING.md` + `CODE_OF_CONDUCT.md`.
- Tutorials in Nexus ergänzen: `_tutorials/cortex-web/05-tenant-trennung.md`.

---

## 5. Konsequenzen für laufende Arbeit

**Sofort gilt:**
- **Keine neuen Stracke-spezifischen Content-Files** in `trunk/content/` mehr — alle Neueinträge gehen in den vorbereiteten Pfad (heute noch `trunk/content/`, ab Phase 1.3 in `Sanexio-Tenant`).
- **Adapter dürfen ab sofort keine hardcodierten Pfade** zu `trunk/content/team/dr-stracke.yaml` o.ä. mehr aufnehmen. ENV-Variable oder Argument.
- **Heutige `_integration-slots/`-Slots**: `file-renamer-cli` ist generisch (passt zu Public-Cortex-Web), `drift-sync-as-trunk` ist Tenant-aware (lese-/schreibt auf Tenant-Daten). Letzteren Slot beim Promotion-Test-Run als „operates-on: tenant" markieren.

**Während der Migration:**
- Cortex-Web bleibt für Stracke unter `Sanexio/cortex-web` — kein Repo-Rename.
- Sanexio-Tenant ist ein NEUES Repo, das schrittweise befüllt wird.
- Phase 1.3 ist die sensible Welle — Punkt of no return; Backup vor `filter-repo`.

**Nach Phase 1.5:**
- Cortex-Web ist OSS-Ready (technisch). Launch-Zeitpunkt ist separate Entscheidung (§10 Lizenz, §11 Phase 4).
- Stracke arbeitet mit zwei Repos: ein Pull/Push-Zyklus mehr pro Welle.

---

## 6. Risiken

| Risiko | Schwere | Gegenmaßnahme |
|--------|---------|---------------|
| `git filter-repo` zerstört Historie irreversibel | hoch | Vor Welle 1.3 vollständigen `cortex-web-pre-split-2026-XX-XX`-Branch auf GitHub anlegen als Backup |
| Adapter-Pfad-Refactor übersieht eine hardcodierte Stelle | mittel | Pre-Commit-Linter: `grep -rE "(stracke|westend|gpmedical)" adapters/ tools/` muss leer sein |
| Mirror-Sync greift auf altem Cortex-Web-Stand mit Stracke-Daten | niedrig | nach Welle 1.3 sofort allen Macs `git pull --hard` + force-update; alte Mirror-States invalidieren |
| Sanexio-Tenant-Repo wird versehentlich public gestellt | hoch | GitHub-Repo-Settings „Private" + Schutz vor Visibility-Wechsel; nur Stracke-Account schreibberechtigt |

---

## 7. Offene Detail-Entscheidungen

1. **Lizenz** für Sanexio-Tenant-Repo (nicht für Public, aber für interne Doku): „Sanexio-internal" reicht.
2. **Was passiert mit `sites/sanexio-github-io/`?** Sanexio-Hauptseite ist Sanexio-Eigentum, aber generischer als Praxis. Mögliche Wege: bleibt in Cortex-Web als Sanexio-Reference-Site, oder zieht mit nach Sanexio-Tenant.
3. **`_archive/sessions/`** im Cortex-Web — sind Stracke-Session-Notizen. Mitziehen nach Sanexio-Tenant (Verlauf der Stracke-Welle), oder im Public-Repo lassen (Beispiel-Historie für OSS-Nutzer)?
4. **`docs/`** im Cortex-Web — vermutlich generisch, prüfen vor Phase 1.3.
5. **Welche Adapter-Konfiguration?** ENV-Variable `CORTEX_TENANT_DIR` (vorgeschlagen) oder eine `cortex-web.config.json` im Repo-Root mit Pfad?

---

## 8. Nächster konkreter Schritt

Wenn Option A freigegeben wird:

**T+1 Welle:** Phase 1.1 starten — `_examples/`-Skelett anlegen, Adapter-ENV-Variable einführen, Slot-Vertrag erweitern. Ist eine ~30-Min-Welle, kein Risiko.

Erst danach Phase 1.2+ als eigene Wellen mit klarer Backup-Disziplin.
