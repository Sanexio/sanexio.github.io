---
project: Cortex-Plattform
phase: Phase 1 ✅ (2026-05-24). Phase 2 🟢 komplett — Wellen 2.0–2.5 ✅ 2026-05-31, 2.7a ✅ 2026-05-31, 2.7b ✅ 2026-06-01 (Notarization arm64+x64 beide Accepted: Nexus-Subm 102c961d arm64 + 1c818919 x64, Cortex-CLI-Subm 498fd806 x64; Apple-ID `bm@westend-hausarzt.de`, Team-ID `QYC7S8YGXV`, Keychain-Profile cortex-notary, Setup-Doku `_rules/apple-developer-credentials.md`). 2.6 ✅ 2026-06-01 (code-side) — gateway/src/license/check.ts mit 24h-Cache-TTL + 48h-stale-while-revalidate; Endpoint-Setup-Stub in cortex-cli/server/ (verify.php für GoDaddy), Hosting bleibt User-Aktion. Phase 3 🟢 komplett — Wellen 3.0–3.6a ✅ 2026-05-31 + 3.6b x64 + 3.6d + 3.6e ✅ 2026-06-01 (cortex-cli MVP, Distribution auf sanexio.github.io live + smoke-tested) + 3.6c arm64 ✅ 2026-06-01 (Cluster-Mini-02: echte Ursache = Bun-Compile-Trailing-Padding nach LC_CODE_SIGNATURE, nicht .mjs-vs-.ts-Entry; Fix `trim_bun_padding()` in cortex-cli/dist/build.sh HEAD `d99130e`; arm64 adhoc + strict-validation verified; Dev-ID-Roundtrip auf M5 ausstehend). Phase 4 OSS-Release-Polish weitgehend durch (OSS-Launch 2026-05-26, Welle 1.3+1.5b 2026-05-31, Welle 1.5c + CoC 2026-05-31, Demo-Tenant-Ausbau 2026-05-31). Phase 5 🟢 Welle 5.0 ✅ 2026-06-01 — Spec 05_TENANT_ONBOARDING.md mit Akteur-Rollen + 7-Stationen-Lebenszyklus + Wellen 5.1–5.6; Welle 5.1ff. ⏳ wartet auf Phase-3.6e-Endpunkt-Hosting (User) + Pilot-Tenant-Sitzung auf Cluster-Mini-04.
last_session: 2026-06-01 (Welle 3.6c-arm64 echte Ursache diagnostiziert + gefixt auf Cluster-Mini-02: Bun-Compile-Trailing-Padding nach LC_CODE_SIGNATURE, trim_bun_padding() in cortex-cli/dist/build.sh; vorherige Sessions: Nexus 2.7b Notarization, Cortex-CLI 3.6d Distribution, Phase 5 Welle 5.0 Tenant-Onboarding-Spec)
trigger_phrase: "Cortex-Plattform fortsetzen"
---

# Cortex-Plattform — Session-Resume

## Trigger für die nächste Session

Sage zu Claude:

> **Cortex-Plattform fortsetzen**

Claude lädt dann (in dieser Reihenfolge):

1. `~/Cortex/Nexus/CLAUDE.md` (Standard-Init)
2. `~/Cortex/Nexus/_rules/AUTONOMY_CONTRACT.md` (R0–R3, Tier-3)
3. `~/Cortex/Nexus/specs/cortex-platform/00_VISION_UND_ROADMAP.md` (Plattform-Vision)
4. `~/Cortex/Nexus/specs/cortex-platform/01_CORTEX_WEB_SPLIT.md` (ADR + Phase-1-Status)
5. **Diese Datei** (`SESSION_RESUME.md`) — letzter Stand + nächste Welle

---

## Wo wir stehen (2026-05-31, Welle 1.5c Doku-Welle + Phase-4-CoC)

> **Begriffs-Klärung:** „Phase 2" hat in dieser Datei historisch zwei
> Bedeutungen gehabt — (a) der Phasen-Begriff aus `00_VISION_UND_ROADMAP.md`
> §11 (Nexus-Build-Pipeline, eigene Welle) und (b) der interne
> Post-Split-Cleanup-Block, der unten als „Welle 1–15" zählt. Ab heute
> nennen wir (b) konsistent „Welle 1–15 (Post-Split-Cleanup)" und
> reservieren „Phase N" für die Vision-Roadmap-Phasen.

**Vision-Roadmap-Status (gemäß `00_VISION_UND_ROADMAP.md` §11):**

| Phase | Inhalt | Status |
|-------|--------|--------|
| 0 | Vision-Konsolidierung | ✅ (Spec freigegeben) |
| 1 | Tenant-Trennung im Code | ✅ 2026-05-24 |
| 2 | Nexus-Build-Pipeline (signiertes Binary, Lizenz-Token) | 🟡 Wellen 2.0–2.5 ✅ 2026-05-31 (Voll-Pipeline-Build: Spec, Bun-Compile, py_compile, MANIFEST, Tarball, codesign, install.sh; 31M Tarball, voller Install-Roundtrip getestet); 2.6 (Lizenz-Token) + 2.7 (Apple Dev-ID) blockiert |
| 3 | Cortex-CLI MVP (`cortex install/init/update/status`) | 🟡 Wellen 3.0–3.6a ✅ 2026-05-31 (alle MVP-Sub-Commands implementiert + Bun-Bundle baut 60M Standalone-Bin); 3.6b–f offen (Cross-Platform, codesign, Hosting, Online-Validierung, LaunchAgent-Auto-Install) |
| 4 | Cortex-Web Open-Source-Release | 🟡 Hauptarbeit durch — OSS-Launch (2026-05-26), Tenant-Migration (Welle 1.3+1.5b, 2026-05-31), Doku-Refs (Welle 1.5c, 2026-05-31), CODE_OF_CONDUCT.md (2026-05-31). Offen: Demo-Tenant-Befüllung in `sites/_examples/praxis-demo/`, Sanexio-Blog-Ankündigung |
| 5 | Tenant-Onboarding für externe Ärzte | 🟢 Welle 5.0 ✅ 2026-06-01 (Spec `05_TENANT_ONBOARDING.md`); 5.1ff. ⏳ |
| 6 | Cortex Layer wächst (rollend) | 🟡 läuft (cortex-rename, cortex-qm, cortex-desk Skelette 2026-05-31) |

**Post-Split-Cleanup-Wellen 1–15: KOMPLETT.** Linter 67→0, Pre-Commit-
Hook, Role-Keys shop/practice, upstream_source, tenant-config-
Parametrisierung, Doku-Cleanup, OSS-Launch filter-repo.

**OSS-Launch DURCH** (2026-05-26): filter-repo hat `trunk/content`,
`trunk/media`, `sites/praxis-webseite`, `sites/juvantis-webseite`,
`projects` aus der gesamten History gescrubbt. Force-Push auf origin/main
+ pre-tenant-split-2026-05-24. Repo-Größe 86M→34M, 220→130 Commits.
Bundle-Backup: `~/Cortex/_archive/cortex-web-pre-oss/`.

**Welle 1.3+1.5b (§10.9 final, 2026-05-31, cw `9783d41`):** verankert den
am OSS-Launch durchgeführten Migrations-Zustand. Tenant-Sites
(`praxis-webseite` 46M, `juvantis-webseite` 1.7M) liegen final im
Sanexio-Tenant-Repo, `lint-no-tenant-leaks --strict` 0 Treffer in 7
Framework-Pfaden.

**Welle 1.5c (Doku-Refs, 2026-05-31, cw `6fd7092`):** 7 Doku-Files
(`CLAUDE.md`, `AGENTS.md`, `PROJECT.md`, `_rules/ARCHITECTURE.md`,
`_rules/PRE_FLIGHT_CHECKLIST.md`, `_rules/WORKING_MODE.md`,
`docs/cross-site-transfer.md`) auf Tenant-Pfad-Konvention nachgezogen.
Snapshot-in-time Files (CHANGELOG, specs/bridge-strategy/, specs/phase-4/+5/,
tools/oss-launch-filter.sh) bewusst nicht angefasst.

**Phase 4 Polish (2026-05-31, cw `6fbbf00`):** `CODE_OF_CONDUCT.md`
(Contributor Covenant 2.1, deutsche Adaption) angelegt; CONTRIBUTING.md
CoC-Sektion auf Pointer reduziert.

**Demo-Tenant-Ausbau (2026-05-31, cw `13aa960`):** `trunk/_examples/`
als kanonische OSS-Demo-Quelle ausgebaut (2 weitere Team-Member +
Legal-Page-Stub + README-Update); `sites/_examples/` (Welle-1.5b-Stub)
auf Verweis-Datei umgestellt. Smokes alle grün (validate, build-team,
build-page-hub).

**Phase 3 Welle 3.0 (2026-05-31, cortex-cli erst-Commit):** Spec
`Nexus/specs/cortex-cli/00_KONZEPT.md` angelegt. Repo
`~/Cortex/projects/cortex-cli/` lokal + `Sanexio/cortex-cli` auf
GitHub (PRIVATE bis OSS-Launch-Readiness). Bun-basierte Sub-Commands:
`status` (read-only Plattform-Stand, exit 1 bei Drift),
`--version` (Bun + OS + Arch), `--help` (Sub-Command-Übersicht +
Roadmap-Pointer). Placeholder-Router für `install/init/update/add/
contribute` mit exit 2 + klarer Welle-3.1+-Hinweis-Meldung. LICENSE
Apache 2.0 (voller Text), CODE_OF_CONDUCT.md aus cortex-web
übernommen, OSS_PREP.md mit Welle-3.0–3.6-Plan.

**Phase 3 Wellen 3.1–3.6a (2026-05-31, cortex-cli HEAD `28aa01c`):**
Alle MVP-Sub-Commands implementiert + Bun-Bundle-Build:

- `install` (3.1): idempotent `~/.cortex/`-Bootstrap (root + projects
  + state + meta.json mit Install-Timestamp).
- `init --license <token>` (3.2): Offline-Format-Check
  (`XXXX-YYYY-ZZZZ`-Pattern), schreibt `~/.cortex/license.json` +
  legt `.tenant/` an. Online-Validierung gegen
  `cortex.sanexio.de/api/v1/license/verify` ist TODO Welle 3.6e.
- `update [--check|--apply]` (3.3): Stub-Manifest gegen geplante
  cortex.sanexio.de-URL, persistiert State unter
  `~/.cortex/state/last-update-check.json`. Heute „keine Updates
  verfügbar" (Quelle nicht live). LaunchAgent-Template
  (`dist/de.sanexio.cortex-update-check.plist.template`) für
  §10.3-Hybrid liegt bereit; Auto-Install in Welle 3.6f.
- `add <project>` (3.4): Git-Clone vom Sanexio-GitHub nach
  `~/.cortex/projects/<name>/`. Statische Bekannt-Liste:
  cortex-web/-rename/-qm/-desk/-cli. Dynamisches Manifest = Welle 3.6.
- `contribute <project>` (3.5): plattform-spezifischer Browser-Open
  (`open`/`xdg-open`/`start`) auf GitHub-Compare-URL.
- Bun-Bundle (3.6a): `dist/build.sh` baut 60M Standalone-Bin für
  Host-Target. Bug-Fix: BAKED_VERSION zur Build-Zeit eingebacken,
  weil Bun-`/$bunfs/`-Bundle kein package.json zur Runtime hat.

Smoke-Roundtrip auf M5 grün: install → init → status (exit 0) →
update --check → bundle build → standalone-bin alle grün.

**Phase 2 Wellen 2.0–2.5 (2026-05-31, SSMD-MacBookPro-M5):** Voll-
Pipeline für Nexus-Build durch. 6 zusammenhängende Wellen in einer
Session:

- **Welle 2.0:** `specs/cortex-platform/04_NEXUS_BUILD_PIPELINE.md`
  (operative Welle-Steuerung, 9 Abschnitte); `dist/`-Skelett (README,
  build.sh-Stub, MANIFEST.template.json, .gitignore); §10.2 Option A
  final; Inventur 11/7/4 (rein/raus/templates); 5 offene Fragen.
- **Welle 2.1:** Bun-Compile `gateway/` läuft.
  `gateway/bin/nexus-gateway.ts` Wrapper-Bin mit `--version`/`--help`/
  Dynamic-Dispatch zu `channels/telegram/channel.ts`. baked-version-
  Pattern via `gateway/src/baked-version.{ts,example.ts}` (generated
  gitignored, template committed). 61M Standalone-Binary, Smoke
  `nexus-gateway --version` zeigt Build-Konstanten korrekt.
- **Welle 2.2:** py_compile mit `--invalidation-mode unchecked-hash`
  (Python 3.14 kennt `unchecked-timestamp` nicht — Lesson). 74 `.pyc`
  in agent/+_lib/, `.py` raus. Bash + Markdown + Config + Top-Level-
  Files ins Bundle kopiert. 4149 Files insgesamt.
- **Welle 2.3:** `dist/gen-manifest.sh` als separater Generator (Bash-
  args + Python-Inline-JSON-Build). MANIFEST.json mit 4150 File-
  Einträgen (sha256 + size + sortiert), Code-Sign-Info, License-
  Endpoint, Install-Hints (preserve_paths).
- **Welle 2.4:** ad-hoc `codesign --sign -` der Binary VOR MANIFEST
  (Reihenfolge-Fix: signieren ändert sha256). Tarball mit
  `COPYFILE_DISABLE=1` (verhindert ._-AppleDouble-Pollution). Tarball
  31M, sha256-Sum daneben.
- **Welle 2.5:** `dist/install.sh` für Test-Mac. 8 Steps: sha256-Check,
  Extract in mktemp, MANIFEST-Hash-Verify aller 4150 Files (Python),
  codesign-Verify, target-prep mit `--force`-Upgrade-Modus,
  preserve_paths-Sicherung + Restore via tar-Pipe, Move-Install,
  Smoke. Voller Roundtrip `/tmp/nexus-test-install/` grün.

**Build-Stack:** Bun 1.3.13 (TypeScript) + Python 3.14 (`_compileall -b
-f --invalidation-mode unchecked-hash`) + macOS `codesign` (ad-hoc) +
`tar` (`COPYFILE_DISABLE=1`).

**Offen:** Welle 2.6 (Lizenz-Token-Validierung gegen
`cortex.sanexio.de/api/v1/license/verify`, blockiert durch cortex-cli
Welle 3.6e — Endpoint nicht live), Welle 2.7 (Apple Developer-ID +
Notarization, blockiert durch Cert-Setup-User-Aufgabe).

| Repo | Stand | Inhalt |
|------|-------|--------|
| `Sanexio/cortex-web` | Post-OSS HEAD `de217b0` | History clean, Linter strict 0, Pre-Commit aktiv |
| `Sanexio/sanexio-tenant` | Welle 15 HEAD | tenant.config.json vollständig, Role-Keys migriert |
| `Sanexio/nexus` | (diese Welle) | Plattform-Spec auf Post-OSS aktualisiert |
| `Sanexio/cortex-web` Backup-Branch | `pre-tenant-split-2026-05-24` | History-Anker (pre-filter-repo) |

**⚠ Re-Clone erforderlich** auf allen Macs außer dem, auf dem der
OSS-Launch lief. `git pull` schlägt fehl (force-pushed History).
Anleitung: siehe `Cortex-Web/SESSION_RESUME.md` §3.

### Heute erledigt (chronologisch)

1. **Adapter-Refactor** (`6870b19`): 4 Tenant-Loader auf `tenantPath()`
   umgestellt (build-page-hub, shopify/build-page, shopify/build-template,
   astro/team-to-astro).
2. **theme-path-Helper** (`995b0aa`): zweite Helper-Schicht — Mac-spezifische
   Theme-Pfade entkoppelt, 3 Adapter umgestellt.
3. **Demo-Hub-Page** (`0a707d8`): `trunk/_examples/.../leistungen.yaml` —
   build-page-hub jetzt im Demo-Modus grün.
4. **Linter-Welle 1** (`39cccca`): Adapter-/Tool-/Schema-Doku anonymisiert,
   8 Files raus.
5. **Linter-Welle 2** (`772af0f`): `evidence/**` als dokumentarisch markiert,
   `specs/REFERENCE_TENANT_EVIDENCE.md` angelegt, 20 Files raus.
6. **Linter-Welle 3** (`92ce3a1`): Linter Self-Exclude, page-juvantis-
   Kommentar, cw-transfer-Help, review/screenshots-Headlines — 4 Files raus.
7. **Tenant-Config-Helper** (`33621f1`): dritte Helper-Schicht, 3 Tools
   umgestellt (shopify-authorize, drift-sync/hwg-curate, review/hwg-scan).
   Linter 35→32.
8. **Cross-Repo-Move** (cw `389e68e`, tenant `71a11ef`): 6 Files aus
   Cortex-Web/tools/ nach Sanexio-Tenant/tools/ verschoben — probe-doctolib,
   probe-home-doctolib, local-wp-setup/ (4 Files: mu-plugins + nginx-README).
   Repo-Source-Pfad in `cortex-dev-auth.php` aktualisiert. Linter 32→26,
   `tools/` jetzt clean.
9. **_config + _rules anonymisiert** (cw `6c280d3`): "Dr. Stracke" →
   "Tenant-Operator", Rechtsrahmen-Begründung in CW-005 verallgemeinert
   (Konkretisierungen via `<tenant>/_meta/rechtsrahmen.md`), Views/Domains
   neutralisiert. 4 Files raus, Linter 26→22. `_config + _rules` clean.
10. **Historische Spec-Pfade exkludiert** (cw `be496b2`): Linter erweitert
    um `specs/phase-N/`, `bridge-strategy/`, `content-bridge-v1/`,
    `session-N/`. Konvention in REFERENCE_TENANT_EVIDENCE.md verankert
    inkl. Naming-Regel für neue lebende Specs (nicht phase-/session-N).
    12 Files raus, Linter 22→10.
11. **Linter-Welle 8** (cw `bf1b28c`, 2026-05-25 09:50): Cross-Site-
    Transfer + Drift-Sync Specs anonymisiert (9 Files raus). Linter 10→1.
    Letztes verbleibendes File: `trunk/schema/product.schema.json` mit
    `cta_url`-Pattern `sanexio.eu`.
12. **Welle 9 — Architektur cta_url-Schema** (cw `f3db0b0`, 2026-05-25, Option C):
    - Schema-Pattern entkoppelt: `^(/|https://sanexio\.eu/)` → `^(/|https://)`.
    - Validierung in Build-Step verlagert: `adapters/wordpress/build.mjs` liest
      `cta.allowed_external_cta_domains` aus `tenant.config.json`, prüft
      externe Praxis-CTAs gegen die Whitelist (exit-code 4 bei Verstoß).
    - `tenant.config.json` neu im Sanexio-Tenant angelegt
      (Whitelist: `["sanexio.eu"]`).
    - Demo-Tenant-Config + Demo-Produkt aktualisiert.
    - `tools/validate.sh` nach Welle 1.3 nachgezogen: nutzt jetzt
      `tenant_path()` statt hartcodiertes `trunk/content/products`.
    - Verifikation: validate.sh = OK (1 demo, 11 real), Linter strict = 0.
13. **Welle 10 — Pre-Commit-Hook** (cw `5cd937d`, 2026-05-25):
    - `tools/git-hooks/pre-commit` ruft `lint-no-tenant-leaks.sh --strict`.
    - `tools/install-git-hooks.sh` setzt idempotent `core.hooksPath =
      tools/git-hooks` (pro Mac einmal laufen lassen, weil `.git/config`
      lokal-only ist).
    - Negativ-Test grün (Fake-Leak in `tools/_hook-test-leak.md` →
      Commit blockiert mit exit 1, HEAD unverändert).
14. **Welle 11 — Konvergenz-Step** (nexus HEAD, 2026-05-25):
    - Neuer Step `cortex_web_git_hooks` in `scripts/cortex-converge.sh`
      zwischen `cortex_web_devices_known` und `sanexio_tenant_clone`.
    - Idempotent: NOOP wenn `core.hooksPath = tools/git-hooks`, sonst
      APPLIED über `( cd "$cw_dir" && bash "$installer" )`. Dry-Run zeigt
      DRY-Hinweis ohne State-Mutation. SKIP wenn Cortex-Web fehlt oder
      Installer nicht executable.
    - Test-Matrix auf M5 durchlaufen (NOOP/APPLIED/DRY-RUN alle grün).
    - Andere Macs ziehen den Hook beim nächsten `cortex-converge`-Lauf
      automatisch.
15. **Welle 12 — Role-Keys abstrahiert** (cw `d749090` + tenant `b37f63f`,
    2026-05-25, Pfad A „voller Symmetrie-Schwung"):
    - `juvantis` (tenant-brand) → `shop` (rolle)
    - `praxis` (tenant-spezifisches Wort) → `practice` (rolle)
    - 4 Schemas: page (site-Enum + slugs + status_*), product
      (views.{shop,practice}), team-member (image_asset_shop +
      profile_urls), media (sites)
    - 6 Renderer git-mv'd: page-shop, product-shop,
      template-shop-ueber-uns (shopify) + product-practice,
      service-practice, team-practice (wordpress) — inkl.
      Function-Renames + Renderer-Registry-Keys
    - ~20 Tools/Adapter umgestellt (drift-sync, review, cw-transfer,
      build-page-hub, extract-/build-Pfade)
    - 70 Tenant-YAMLs + 4 Demo-YAMLs migriert via BSD-sed-Skript
    - praxis-example/ → practice-example/ (Demo-Dir-Rename)
    - Push-Reihenfolge atomar: tenant zuerst (sonst bricht validate
      gegen alte schema-required-Listen), dann cortex-web, dann nexus.
    - Verifikation: Demo+Tenant validate grün, Linter strict 0,
      Shopify+WP-Build smoke grün, cta-Whitelist-Negativ-Test
      (Welle 9) bleibt grün mit neuer Property-Path-Message.
    - Naming-Deviation vs Backlog: Backlog skizzierte `tenant-shop`,
      finaler Name ist `shop` (single-token, matched bisheriges
      single-token-Pattern).

16. **Welle 13 — sanexio-Brand-Token raus** (cw `fffb643` + tenant
    `6a1b459`, 2026-05-25):
    - Schema-Renames: `sanexio_source` → `upstream_source`
      (Provenance-Block), `site: sanexio` → `site: hub`,
      `status_sanexio` → `status_hub`. 2 Schemas (page, product).
    - 40 Tenant-YAMLs mit `sanexio_source`-Block migriert.
    - 1 Demo-YAML migriert.
    - 7 Drift-Sync-Code-Pfade umgestellt (sync, detect, backfill,
      provenance, trunk-walker, cw-transfer + Astro-README).
    - Bewusst NICHT in Welle 13: `SANEXIO_REPO`-Pfad-Konstante
      + `vendor: "Sanexio"` in product-shop — kommen in Welle 15
      als tenant-config-Parametrisierung.

### Direkt-Einstieg in die nächste Session

Alle Post-Split-Cleanup-Wellen (1–15) + OSS-Launch + Welle 1.3+1.5b
(Tenant-Migration) + Welle 1.5c (Doku-Refs) + Phase-4-CoC sind durch.

Konkrete Folge-Wellen (jeweils eigene Sessions sinnvoll):

- **Phase 4 Demo-Tenant-Befüllung** — `sites/_examples/praxis-demo/`
  + ggf. `juvantis-demo/` mit anonymisierten Fake-Praxis-Daten füllen,
  damit OSS-Demo „Dr. Demo, Westend" ohne Tenant-Repo lauffähig ist.
  Stub-README existiert seit Welle 1.5b (siehe `sites/_examples/README.md`).
- **Phase 2 — Nexus-Build-Pipeline** 🟡 Wellen 2.0–2.5 ✅ 2026-05-31 —
  Voll-Pipeline durch: 61M Standalone-Binary, 4150-File-Bundle, 31M
  Tarball mit ad-hoc-codesign, install.sh-Roundtrip verifiziert.
  Operatives Spec: `specs/cortex-platform/04_NEXUS_BUILD_PIPELINE.md`.
  Offen: 2.6 Lizenz-Token-Validierung (blockiert durch cortex-cli
  Welle 3.6e — cortex.sanexio.de-Endpoint live), 2.7 Apple-Developer-
  ID + Notarization (User-Cert-Setup).
  Trigger: „Cortex-Plattform Phase 2 fortsetzen".
- **Phase 3 — Cortex-CLI MVP** (4–6 Wochen, parallel zu Phase 2) —
  `cortex install/init/update/status`, Distribution-Skript an
  `cortex.sanexio.de`.
- **§10-Business-Entscheidungen** (Lizenz-Modell, Build-Stack,
  Update-Pfad, Tenant-Identity, Datenschutz, Tutorials-Öffentlichkeit,
  Cortex-CLI-Distribution, Juvantis-App-Subsumption).
- **Re-Clone der anderen Macs** nach OSS-Launch-History-Rewrite
  (User-Aufgabe, nicht Claude-automatisierbar — siehe
  `feedback_filter_repo_breaks_auto_ff.md`).

---

## Phase-2-Backlog (sortiert nach Risiko/Aufwand)

### Klein (1 Welle, ~30 Min, kein Risiko)

- **§10.10 Juvantis-App-Subsumption diskutieren** — ADR ähnlich
  `01_CORTEX_WEB_SPLIT.md`: wird die iOS-App ein Sub-Pfad in Cortex-Web
  (`sites/juvantis-app/`) oder ein eigenes Cortex-Layer-Projekt
  (`cortex-mobile/`)? Heute nur Spec, keine Code-Bewegung.
- **Plattform-§10-Entscheidungen** anfangen (z.B. Lizenz-Modell für
  Nexus — Subscription? Einmal-Lizenz? Pro-Sitz?). Business-Diskussion,
  keine Code-Welle.

### Mittel (jeweils 1–2 Wellen, geringes Risiko)

- ~~**Restliche Adapter migrieren**~~ — erledigt 2026-05-24
  (Cortex-Web `6870b19`). Migriert wurden die 4 Adapter, die aktiv aus
  `trunk/content/` lesen: `wordpress/build-page-hub.mjs`,
  `shopify/build-page.mjs`, `shopify/build-template.mjs`,
  `astro/team-to-astro.mjs`. Nicht migriert (kein Bedarf): CLI-Arg-
  basierte Adapter (User übergibt Pfad), Push/Diff/Extract-Adapter
  (lesen nicht aus Trunk).
- ~~**THEME_PATH-Defaults verallgemeinern**~~ — erledigt 2026-05-24
  (Cortex-Web `995b0aa`). `tools/lib/theme-path.mjs` analog tenant-path:
  CORTEX_THEME_PATH > THEME_PATH-Legacy (WARN) > `~/.cortex/theme-path`
  > `<repo>/.demo-theme` (auto-mkdir, gitignored). Drei Adapter
  (`build-page-hub`, `diff-team`, `team-to-wp`) umgestellt. Roundtrip
  team-to-wp → diff-team im Demo-Modus = EQUAL.
- ~~**Linter-Treffer abarbeiten**~~ — erledigt 2026-05-25: 67 → 0 (-100 %).
  Welle 8 + Welle 9 schlossen die letzten Sub-Wellen ab. Strict-Modus
  läuft lokal grün, Pre-Commit-Aktivierung ist die nächste kleine Welle.
  - Sub-Welle 1 (`39cccca`): Adapter-/Tool-/Schema-Doku anonymisiert
    (8 Files raus).
  - Sub-Welle 2 (`772af0f`): `specs/**/evidence/**` als dokumentarisch
    markiert, Linter exkludiert sie jetzt; zentrales Konventionsdoc
    `specs/REFERENCE_TENANT_EVIDENCE.md` angelegt (20 Files raus).
  - Sub-Welle 3 (`92ce3a1`): Linter Self-Exclude, page-juvantis-Kommentar,
    cw-transfer-Help-String, review/screenshots-Headlines (4 Files raus).
  Verbleibende 10 Treffer in 2 offenen Sub-Wellen:
  - Sub-Welle 4 (`33621f1`): Tenant-Config-Helper als 3. Helper-Schicht
    (`tools/lib/tenant-config.mjs` + `trunk/_examples/tenant.config.json`).
    shopify-authorize.sh, drift-sync/hwg-curate.mjs, review/hwg-scan.mjs
    refactoriert — 3 Files raus.
  - ~~Architektur-Welle „cta_url-Schema-Parametrisierung"~~: erledigt 2026-05-25
    (Welle 9). Option C umgesetzt: Schema-Pattern relaxed auf `^(/|https://)`,
    Build-Time-Whitelist-Check in `adapters/wordpress/build.mjs` gegen
    `cta.allowed_external_cta_domains` aus `tenant.config.json`.
    Negativ-Test grün (exit 4 bei fremder Domain).
  - ~~Cross-Repo-Move~~: erledigt 2026-05-24 (cw `389e68e`, tenant `71a11ef`).
    6 Files verschoben: `tools/probe-doctolib.mjs`, `probe-home-doctolib.mjs`,
    `tools/local-wp-setup/*` (4 Files). `tools/` jetzt clean.
  - ~~`_config` + `_rules` anonymisiert~~: erledigt 2026-05-24 (cw `6c280d3`).
    CW-003/005/006/PRIO-001 in `_config/RULES.md` neutralisiert,
    `_rules/ARCHITECTURE`/`PRE_FLIGHT_CHECKLIST`/`WORKING_MODE`
    Empfänger/Rollen-Neutralisierung. `_config` + `_rules` jetzt clean.
  - ~~Historische Spec-Pfade exkludiert~~: erledigt 2026-05-25 (cw `be496b2`).
    Linter excludiert `specs/phase-N/`, `bridge-strategy/`,
    `content-bridge-v1/`, `session-N/`; REFERENCE_TENANT_EVIDENCE.md
    fortgeschrieben mit Naming-Regel für neue lebende Specs (12 Files raus).
  - Spec-Hauptfiles (21 Files in `specs/`): SPEC.md, ARCHITECTURE.md,
    PATTERNS.md etc. — größere Anonymisierungs-Welle, jede Spec lesen
    und neutralisieren.
  - Architektur-Doku in `_rules/` (3) und `_config/` (1): user-Beteiligung
    bei Doctolib-/Praxis-Konzepten.
  - `adapters/shopify/lib/renderers/page-juvantis.mjs` Rename auf
    `page-tenant-shop.mjs` ist eine eigene Architektur-Welle (Schema-
    Bruch, juvantis-Site-Enum ist tief im Trunk-Schema verwoben).

### Groß (eigene Welle, koordiniert, mit Backup)

- ~~**History-Cleanup auf `Sanexio/cortex-web/main`**~~ — erledigt 2026-05-26
  (OSS-Launch). filter-repo + Force-Push + Bundle-Backup. Re-Clone auf
  anderen Macs steht noch aus (User-Aufgabe).

### Strategisch (Business-Entscheidungen, kein Zeitdruck)

- **§10.1 Lizenz-Modell für Nexus** (Subscription/Einmal/Pro-Sitz?)
- **§10.2 Build-Stack** für Nexus-Closed-Binary (Bun-bundle? Docker?)
- **§10.3 Update-Pfad** (Auto-Update vs. manuelles `cortex update`)
- **§10.4 Tenant-Identity-Prüfung** (Approbation? Sanexio-Vertrag?)
- **§10.5 Datenschutz Tenant-Daten** (lokal vs. cloud-synced)
- **§10.6 Wirtschaftliche Trennlinie** Praxis Stracke ↔ Sanexio GmbH
- **§10.7 Tutorials-Öffentlichkeit** (vollständig public oder nur für Lizenznehmer)
- **§10.8 Cortex-CLI** als Distributions-Tool (`cortex install/update/status`)

---

## Wichtige Anker für die nächste Session

- **Helper-Trio** für Tenant-Auflösung (alle in `tools/lib/`):
  1. `tenant-path.{sh,mjs}` — Tenant-Daten-Pfad (`trunk/content/...`)
  2. `theme-path.mjs` — Local-WP-Theme-Pfad (Schreib-/Diff-Ziel)
  3. `tenant-config.mjs` — funktionale Konstanten (Shop-Domain,
     OAuth-Client-ID, etc.) aus `<tenant>/tenant.config.json`.
     CLI-Modus für Bash: `bun tools/lib/tenant-config.mjs <key>`.
  Jeder Adapter MUSS darüber lesen, nicht hartcodieren.
- **Konvergenz-Schritte** in `Nexus/scripts/cortex-converge.sh`:
  7 Steps aktiv. Neue Steps via `step_*`-Funktion + Eintrag in
  `CONVERGE_STEPS`-Array. Tier-3-konform (keine Secrets/Auth-Ops).
- **Slot-System** (`_integration-slots/`) — Bedingung für neue Tools
  im Cortex-Web. `operates_on: framework|tenant|both` ist Pflicht.
- **Linter** (`tools/lint-no-tenant-leaks.sh`): strict-clean, Pre-Commit-
  Hook aktiv (Welle 10). Installer: `tools/install-git-hooks.sh`.
- **Auto-Memory** `project_sanexio_cortex_business_model.md` hat den
  Pointer-Stand vom 2026-05-24 abend.

## Wenn etwas unklar wird

- Vision-Big-Picture: `00_VISION_UND_ROADMAP.md` §3 Zwiebel-Modell-Diagramm
- Warum-zwei-Repos: `01_CORTEX_WEB_SPLIT.md` §3 Empfehlung
- Tenant-Begriff erklären: `_tutorials/cortex-web/05-tenant-trennung.md` §1–§3
- Konvergenz-Pattern: `_tutorials/cortex-nexus/12-self-applying-konvergenz.md`
- Slot-Pattern: `_tutorials/cortex-web/03-integration-slots.md`

## Selbstverständliches

- **Vor jedem Edit**: `git pull --ff-only` in beiden betroffenen Repos.
- **Mac-Hostname** bestimmt heute die Bearbeitungs-Rolle (Cluster-Mini-02
  und Mac-Studio sind primary für CW + Tenant; M5 ist primary für Tenant
  + mirror für CW; Intel-MBP + Cluster-Mini-04 sind nur mirror für CW).
- **Welle-Ende-Debrief** wie in AUTONOMY_CONTRACT (WAS GEMACHT · WAS GELERNT · STRATEGISCHE WAHLEN).
