---
type: spec
status: draft-v0.1
date: 2026-05-24
predecessor: specs/cortex-public-skeleton/00_KONZEPT.md (2026-05-16)
owner: Dr. Stracke / Sanexio GmbH
---

# Cortex-Plattform — Vision, Architektur, Roadmap

> **Status:** Draft v0.1, Konzeptphase. Erstentwurf vom 2026-05-24.
> Iterativ zu verfeinern — alle Entscheidungen unter „Offene Fragen" sind
> bewusst nicht vorab gefällt.
>
> **Ablösung des Vorgänger-Specs:** Dieses Dokument löst das Modell aus
> `specs/cortex-public-skeleton/00_KONZEPT.md` (2026-05-16) ab. Der dortige
> Ansatz „Public Skeleton = abgespeckte Nexus-Variante mit austauschbarem
> User-Layer" wird ersetzt durch das **Zwiebel-Modell** (Nexus = closed
> core, Cortex Layer = open source), siehe Abschnitt 3.

---

## 1. Vision

Cortex wird das Sanexio-Plattform-Produkt: ein dezentralisiertes,
intelligentes Arbeitssystem, das Wissen, Datenflüsse und Automatisierung
über verteilte Geräte hinweg orchestriert. Es entsteht mit einem
**closed Kern** (**Nexus**, proprietär Sanexio) und einer **offenen
Erweiterungs-Schicht** (**Cortex Layer**, Open Source), an der die
Community mitarbeitet.

**Geschäftsmodell (Stracke §10.1 / 2026-05-31, Aware-Health-/Aniva-Style):**
Cortex Layer (insbesondere Praxiswebseite + zukünftige Praxis-Tools) wird
**Open Source** und dient als Distributionsmittel — Sanexio gewinnt damit
Ärzte für sein Netzwerk. Cashflow läuft NICHT über Cortex-Lizenz, sondern
über die **proprietäre Juvantis-Plattform** (B2C-Patienten-Frontend für
Bluttests, DHT, Body-Checks, Abrechnung). Ärzte stellen ihren Patienten
die Juvantis-Anbindung zur Verfügung; Patienten registrieren sich, Tests
werden über Sanexio abgerechnet (entweder Arzt-rechnet-selbst-ab- oder
Sanexio-Kooperationsmodell mit Arzt-Entlohnung).

**Erste Cortex-Layer-Anwendung (OSS):** Cortex-Web — der Trunk-/Adapter-Stack
für rechtlich getrennte Webseiten mit geteilter Substanz. Praxiswebseite-
Teil ist OSS-Distributionsmittel; der Juvantis-Webseite-Slot bleibt
proprietär (Migration nach `sanexio-tenant`).

---

## 2. Nexus — der closed Kern

Nexus ist der **Steuerungs- und Integrations-Kern** der Plattform. Was Nexus
ist, in einem Mission-Statement-Bündel (Original-Vorgabe Dr. Stracke
2026-05-24, kondensiert):

> **Code, Framework, Protokoll, Agent, Layer, Kernel, Interface, Netzwerk,
> Architektur, Engine, Knotenpunkt, Infrastruktur, Systemkern, Plattform,
> Netz aus Diensten, Laufzeitumgebung, Steuerlayer, Matrix, Signalnetzwerk,
> semantischer Layer, autonomer Datenpfad.**

Funktional destilliert:

| Rolle | Was Nexus tut |
|-------|---------------|
| **Verbinden** | Eine Code-Basis, die alle Systeme (Macs, MCPs, externe APIs, Patient-Pfade, Web-Trunk, App-Stores) miteinander spricht |
| **Verknüpfen** | Daten aus verteilten Quellen werden intelligent zueinander in Bezug gesetzt |
| **Auffindbar machen** | Ein Protokoll, alles im Cortex eindeutig adressierbar zu machen (Memory-Layers, Vault-Refs, Slot-IDs, Heartbeats) |
| **Zentral zusammenführen** | Agent-Loop holt Informationen aus verteilten Channels in einen kohärenten Zustand |
| **Koordinieren** | Datenströme zwischen Komponenten (Sync, Skills, Cron, Telegram-Bridge) werden orchestriert |
| **Adaptiv interagieren** | Module sind miteinander komponierbar und reagieren auf Umgebungs-Signale (Mode-Hook, Convergence) |
| **Steuern** | Dynamische Prozessketten von Erkennung über Entscheidung zu Ausführung |
| **Sichtbar/Steuerbar machen** | Health-JSON, Heartbeat-Refs, Konvergenz-Logs, Cortex-Mode-State |
| **Semantik organisieren** | Memory-Layers + Glossary + AUTONOMY_CONTRACT als maschinenlesbare Beziehungsstruktur |

**Geschlossenheit (= Sanexio-Hoheit):**
- Source ist nicht offen.
- User können Nexus weder verändern noch (im Source) lesen.
- Verteilung erfolgt als kompiliertes/verpacktes Artefakt mit Lese-Lizenz
  („Sanexio Nexus Runtime License" — Modell offen, siehe §10).
- Ausschließliche Verfügungsgewalt: Dr. Stracke (Sanexio GmbH).

---

## 3. Zwiebel-Architektur

```
                   ╔════════════════════════════════════════╗
                   ║              USER-LAYER                 ║
                   ║  (eigene Branches, eigene Daten,        ║
                   ║   eigene Site-/App-Konfigurationen)     ║
                   ║                                         ║
                   ║   ┌─────────────────────────────────┐   ║
                   ║   │       CORTEX LAYER              │   ║
                   ║   │       (Open Source)             │   ║
                   ║   │                                  │   ║
                   ║   │  ┌──── Cortex-Web ──────┐       │   ║
                   ║   │  │ Trunk + Adapter +    │       │   ║
                   ║   │  │ Integration-Slots    │       │   ║
                   ║   │  └──────────────────────┘       │   ║
                   ║   │                                  │   ║
                   ║   │  ┌──── (weitere CL-Projekte) ─┐ │   ║
                   ║   │  │  z.B. Cortex-Praxis,        │ │   ║
                   ║   │  │  Cortex-QM, Cortex-Bridge   │ │   ║
                   ║   │  └─────────────────────────────┘ │   ║
                   ║   │                                  │   ║
                   ║   │   ┌────── NEXUS ──────┐         │   ║
                   ║   │   │ (Closed Core)      │         │   ║
                   ║   │   │  Stracke-exklusiv  │         │   ║
                   ║   │   │  - Agent           │         │   ║
                   ║   │   │  - Memory-Engine   │         │   ║
                   ║   │   │  - Sync-Mechanik   │         │   ║
                   ║   │   │  - Skills-Registry │         │   ║
                   ║   │   │  - Mode-System     │         │   ║
                   ║   │   │  - Konvergenz      │         │   ║
                   ║   │   │  - Connexio (RO-API)│        │   ║
                   ║   │   │  - Second Brain    │         │   ║
                   ║   │   │    + Tutorials     │         │   ║
                   ║   │   └────────────────────┘         │   ║
                   ║   └──────────────────────────────────┘   ║
                   ╚════════════════════════════════════════╝
```

**Lese-Regel:** Innen ist closed, je weiter außen, desto offener.

- **Nexus (Kern):** geschlossen, alleinige Verfügung Sanexio. Inkl.
  Second Brain (Knowledge-Vault) + Tutorial-System.
- **Cortex Layer (Schicht):** Open Source, Mitwirkung durch Community
  möglich. Aktuell ein Projekt (Cortex-Web), weitere geplant.
- **User-Layer (außen):** Tenant-eigene Branches/Daten/Konfigurationen,
  liegen lokal beim Nutzer und werden nicht zentral verteilt.

---

## 4. Cortex Layer — was darf hier wohnen?

**Universelles Aufnahme-Pattern (Stracke-Entscheidung 2026-05-31 in
`03_PROJECT_OSS_CLASSIFICATION.md` Punkte 6/7/8 — „Framework/Tenant-Split"):**

> „Skills, Hooks, Regeln etc... und Schablone OSS — Rest als privater Tenant."

Jedes Cortex-Layer-Projekt wird in zwei Schichten geteilt:
- **Generische Schicht (OSS)**: Skills, Hooks, Regeln, Schablonen, Adapter,
  Schemas, Tools. Liegt in einem öffentlichen `Sanexio/cortex-<name>`-Repo
  (LICENSE: MIT oder Apache 2.0). Wirkt als Distributionsmittel (Aware-
  Health/Aniva-Modell).
- **Tenant-Inhalt (privat)**: Konkrete Konfigurationen, Patient-bezogene
  Daten, Praxis-Spezifika. Liegt in `Sanexio/sanexio-tenant/<projekt>/`
  (privates Repo) oder einer äquivalenten Tenant-Hoheit.

Aufnahme-Kriterium für ein neues Cortex-Layer-Projekt:

1. **Framework/Tenant-Split umsetzbar** (Schichten klar trennbar — siehe
   Punkte 6/7/8 in `03_PROJECT_OSS_CLASSIFICATION.md`).
2. **Vom Nexus konsumierend**, nicht implementierend (Skills/APIs nutzen,
   nicht Kernfunktionen ersetzen).
3. **Open-Source-fähig nach Tenant-Trennung** (keine medizinischen/personen-
   bezogenen Daten, keine Sanexio-Geheim-Logik im Framework-Repo).
4. **Eigenständig** lauffähig mit Demo-Tenant-Daten.

**Heute (Cortex Layer v0.1):**
- `cortex-web/` — Trunk + Adapter-Framework für Multi-Site-Web-Content (OSS, public).

**Beschlossen 2026-05-31, kommt in Phase 6 (Cortex Layer v1.0):**
- `cortex-desk/` — generisches Praxis-Verwaltungsschicht-Framework (OSS-Repo,
  Welle 3 Phase A 2026-05-31, heute private). Tenant-Inhalt →
  `sanexio-tenant/desk/`.
- `cortex-qm/` — generisches Praxis-Qualitätsmanagement-Framework (OSS-Repo,
  Welle 3 Phase A 2026-05-31, heute private). Tenant-Inhalt →
  `sanexio-tenant/qm/`.
- `cortex-rename/` — generisches File-Renaming-Framework (OSS-Repo,
  Welle 3 Phase A 2026-05-31, heute private). Tenant-Inhalt (Stracke-
  Renaming-Regeln) → `sanexio-tenant/rename-rules/`.
- `praxis-webseite` Theme (`Sanexio/praxiszentrum-theme`) — heute private,
  wird nach Anonymisierungs-Welle public OSS.

**Spin-Off-Kandidaten (Phase 6, Bewertung wenn Bedarf konkret):**
- `cortex-bridge/` — heute in Nexus als `gateway/channels/telegram` +
  `tools/telegram-bridge`; OSS-Spin-Off wenn 2. konsumierendes Projekt
  Bedarf zeigt.
- `cortex-mobile/` — Stub seit 2026-05-31 (siehe `cortex-mobile/00_KONZEPT.md`);
  generische App-Slot-Mechanik OSS-fähig, konkrete Juvantis-App-Code
  proprietär.

---

## 5. User-Layer — wie nutzt jemand das System?

Ein Tenant (z.B. eine Partner-Praxis, eine andere Sanexio-Filiale, oder
ein einzelner Arzt) bekommt:

```
~/Cortex/
├── Nexus/                  ← Closed-Binary-Install via Cortex-CLI
│                              (read-only, von Sanexio signiert)
├── projects/
│   ├── Cortex-Web/        ← Git-Clone vom Open-Source-Repo
│   │   (eigene Branches, eigene sites/<tenant>/-Daten)
│   └── …                  ← weitere Cortex-Layer-Projekte
└── .tenant/                ← Tenant-eigene Konfiguration
    ├── identity.json       (Tenant-ID, Kontakt, Lizenz-Token)
    ├── devices.json        (eigene Geräte-Registry)
    └── memory/             (eigenes User.md, eigene Memories)
```

**Branch-Modell für User:**
- Cortex-Web: eigener `main` lokal, syncen gegen Sanexio-Upstream-`main`.
- Eigene Features als lokale Feature-Branches.
- Beitrag zur Sanexio-Upstream: Pull-Request über GitHub (wie übliches
  OSS-Modell).
- Nexus: nicht forkbar. Updates kommen als signierte Releases von Sanexio.

---

## 6. Aktuelles vs. Ziel-Modell — die Lücke

| Aspekt | Heute (Mai 2026) | Ziel-Modell (Plattform) |
|--------|------------------|--------------------------|
| Nexus-Repo | öffentlich auf GitHub (`Sanexio/nexus`), enthält Stracke-Privates | Closed Binary + Cortex-CLI-Installer |
| Cortex-Web-Repo | öffentlich, aber enthält `sites/praxis-webseite/` + `sites/juvantis-webseite/` (Tenant-Daten von Stracke) | Open-Source-Framework + `sites/_examples/` als Demo; Stracke-Sites in `.tenant/`-Variante |
| Tenant-Trennung | nicht existent (alles ist „Stracke") | Strikt: Tenant-Daten in `.tenant/`, Code-Repos enthalten nur generisches Material |
| Distribution | manuell (`git clone`) | Cortex-CLI (`cortex install`, `cortex update`) |
| Lizenz | unklar | Cortex Layer: MIT/Apache. Nexus: kommerzielle Sanexio-Runtime-Lizenz |
| User-Identität | nur Stracke | Lizenz-Token pro Tenant, signiert von Sanexio |
| Konvergenz-Skript | weiß nur von Stracke-Devices | Multi-Tenant: Konvergenz arbeitet gegen Tenant-Manifest |
| Second Brain | im Nexus-Repo | bleibt in Nexus (Closed Binary), Tutorials werden separat als Public-Read-Only veröffentlicht |

---

## 7. Tutorials & Second Brain — Sonderfall

Dr.-Stracke-Aussage: „In Nexus soll auch das Second Brain liegen mit dem
Tutorial."

Daraus folgt eine Architektur-Verzweigung:
- **Wenn Second Brain in Nexus liegt** und Nexus closed ist, sind die
  Tutorials für andere Ärzte nicht lesbar — Widerspruch zum Bildungs-Wert
  der Plattform.
- **Vorschlag:** Tutorials sind **lesbar** (read-only Public View, z.B.
  als statisch generierte Website unter `docs.cortex-plattform.org` oder
  als Public-GitHub-Mirror), aber **editierbar nur in Nexus** (closed).
  Sanexio kuratiert, User können nicht direkt schreiben — Feedback per
  Issue/PR an Sanexio.
- Second Brain (Vault) bleibt closed (enthält Praxis-Wissen, Patient-
  Strukturen).

Klärungsbedarf: ist „Second Brain" = Tutorial-Quelle oder zusätzlicher
internal Knowledge-Vault? Dr. Stracke entscheidet.

---

## 8. Distribution-Mechanismus

**Sanexio Cortex-CLI** (geplant) als zentrale User-Tool:

```bash
# Installation auf einem neuen Mac
curl -fsSL https://cortex.sanexio.de/install.sh | sh

# Initialisierung mit Lizenz-Token
cortex init --license XXXX-YYYY-ZZZZ

# Updates ziehen (Nexus + Cortex Layer)
cortex update

# Status
cortex status

# Cortex-Layer-Projekt hinzufügen
cortex add cortex-web

# Beitrag vorschlagen (öffnet Browser zum GitHub-PR)
cortex contribute cortex-web
```

Hinter den Kulissen:
- Nexus = Pre-Built Binary (Bun-bundled JS + Python-Bytecode) +
  signierter Manifest.
- Cortex-Layer-Projekte = Git-Clones vom Sanexio-GitHub.
- Tenant-Daten unter `~/.cortex/.tenant/` (Stracke-Pendant: alles unter
  `~/Cortex/` selbst).

---

## 9. Architektur-Verschiebung gegenüber Mai-2026-Spec

| Mai-2026 (`cortex-public-skeleton`) | Mai 2026 (heutiges Spec) |
|-------------------------------------|---------------------------|
| Nexus = abgespeckte Public-Variante mit austauschbarem User-Layer | Nexus = closed Binary, nicht forkbar |
| User-Layer in Nexus selbst tauschbar (USER.md ausgetauscht) | User-Layer = `.tenant/`-Verzeichnis außerhalb von Nexus |
| Tutorials in Public-Skeleton | Tutorials als Public-Read-Only-View, Source closed |
| Cortex-Web nicht als separater Layer benannt | Cortex Layer ist eigene Schicht, Cortex-Web ist ihr erstes Projekt |

Konsequenz: Mai-Spec `cortex-public-skeleton/` wird **als historisches Konzept-
Dokument archiviert** (Hinweis dort einfügen, dass es vom Plattform-Spec
abgelöst wird). Die dortige Inventur (was-ist-generisch-vs-stracke-spezifisch)
bleibt als Ausgangsmaterial für Phase 2 wertvoll.

---

## 10. Architektur-Entscheidungen — DECIDED 2026-05-31

> **Status:** Alle 10 Punkte sind am 2026-05-31 von Dr. Stracke entschieden.
> Volldetail + Begründung: `02_OPEN_DECISIONS_RECOMMENDATIONS.md`.
>
> **Major Shift §10.1:** Ursprüngliches „Closed Binary mit Lizenz-Token"-
> Modell wurde durch **OSS-Distributionsmodell Aware-Health/Aniva-Style**
> ersetzt: Praxiswebseite-Teil von Cortex-Web + alle zukünftigen Praxis-
> Tools werden Open Source und dienen als Distributionsmittel, um Ärzte ins
> Sanexio-Netzwerk zu ziehen. Cashflow läuft über Juvantis-Plattform
> (Patienten-Tests, Blutwerte, Abrechnung) — nicht über Cortex-Lizenz.
> Nexus bleibt Closed Binary (proprietär Sanexio).
>
> **Folgeauftrag:** Projekt-für-Projekt-Klassifikation (OSS / proprietär /
> privat) in `03_PROJECT_OSS_CLASSIFICATION.md`. Bis zur Bestätigung gilt
> die dortige Empfehlungs-Tabelle als Arbeits-Grundlage.

Historisch — diese Punkte waren offen bis 2026-05-31:

1. **Lizenz-Modell für Nexus**: SaaS-Subscription? Einmal-Lizenz? Pro-Sitz?
   Tenant-/Praxis-basiert?
2. **Build-/Deploy-Stack für Nexus-Closed-Binary**: Bun-bundle? Native
   Compilation? Docker? PyInstaller?
3. **Update-Pfad**: Auto-Update (App-Store-Modell), oder manuelles
   `cortex update`?
4. **Tenant-Identity**: Wie wird ein neuer Tenant geprüft, dass er
   tatsächlich Arzt ist (Approbation? Sanexio-Vertrag?)?
5. **Datenschutz für Tenant-Daten**: bleiben sie lokal (Tenant-on-prem)
   oder optional Cloud-synced?
6. **Wirtschaftliche Trennlinie zwischen Praxis Dr. Stracke und Sanexio
   GmbH** für diese Plattform (Lizenz-Einnahmen → wo?).
7. **Tutorials-Öffentlichkeit**: vollständig public oder nur für Tenant-
   Lizenznehmer?
8. **Beitragsmodell für Cortex Layer**: wie viel Sanexio-Kuration ist
   nötig? Welche PR-Review-Pipeline?
9. **Spaltung von Cortex-Web heute**: bleiben Stracke-spezifische Sites
   (praxis-webseite, juvantis-webseite) im Open-Source-Repo (als
   „Sanexio-Example-Tenant") oder werden sie ausgelagert?
10. **Juvantis-App** (deine heutige Klarstellung): wird sie ebenfalls
    in Cortex-Web als `sites/juvantis-app/` subsumiert, oder als
    separates Cortex-Layer-Projekt `cortex-mobile/` aufgesetzt?

---

## 11. Roadmap — Phasen

> Phasen sind sequentiell konzipiert, aber überlappend ausführbar.
> Zeit-Schätzungen sind grobe Anhaltspunkte, abhängig von verfügbaren
> Wochenenden.

### Phase 0 — Vision-Konsolidierung *(jetzt — ca. 1 Woche)*
- **Output:** Dieses Dokument freigegeben.
- Vorgänger-Spec `cortex-public-skeleton/` als historisch markieren.
- Entscheidungen unter §10 erste Tranche gefällt: mindestens #4
  (Tenant-Identity-Konzept) und #9 (Cortex-Web-Spaltung).
- `_projects/INDEX.md` ergänzt um Cortex-Plattform-Eintrag.

### Phase 1 — Tenant-Trennung im Code ✅ **abgeschlossen 2026-05-24**
- ✅ Inventur in `01_CORTEX_WEB_SPLIT.md` (statt `.tenant/` wurde
  Option A „zwei Repos" gewählt — `Sanexio/cortex-web` public,
  `Sanexio/sanexio-tenant` privat)
- ✅ Tenant-Path-Helper (`tools/lib/tenant-path.{sh,mjs}`) +
  Konvergenz-Steps auf Stracke-Macs
- ✅ Pilot-Adapter `build-team.mjs` umgestellt; Refactor restlicher
  Adapter ist Phase 2 (geringeres Risiko, da Pattern etabliert)
- ✅ devices.json um Sanexio-Tenant-Eintrag ergänzt (3 Stracke-Macs)
- Details + 5-Sub-Wellen-Verlauf siehe `01_CORTEX_WEB_SPLIT.md` Status-Update

### Phase 2 — Nexus-Build-Pipeline *(ca. 4–8 Wochen)*
- Entscheidung §10.2 (Build-Stack) treffen.
- Bauen: Nexus als signiertes Binary (oder eigene Bun-Bundle-Variante)
  paketieren.
- Internes Test-Deployment auf 2. Test-Mac (kein Source-Zugriff).
- Lizenz-Token-Validierung integrieren.

### Phase 3 — Cortex-CLI MVP *(parallel zu Phase 2, ca. 4–6 Wochen)*
- `cortex install`, `cortex init`, `cortex update`, `cortex status`.
- Distribution-Skript an `cortex.sanexio.de` (oder Sub-Domain).
- Erste interne Tester (Sanexio-Team / vertrauenswürdige Ärzte).

### Phase 4 — Cortex-Web Open-Source-Release *(ca. 4 Wochen nach Phase 1)*
- Repo `Sanexio/cortex-web` aufräumen: nur Trunk-Framework + Adapter +
  Examples.
- README, LICENSE (MIT/Apache), CONTRIBUTING.md, CODE_OF_CONDUCT.md.
- Demo-Site mit Sanexio als Example-Tenant.
- Sanexio-Website-Pointer + Sanexio-Blog-Ankündigung.

### Phase 5 — Tenant-Onboarding für externe Ärzte *(ca. 8 Wochen nach Phase 3)*

**Welle-Plan + Detail-Spec:** `05_TENANT_ONBOARDING.md` (Welle 5.0 abgeschlossen 2026-06-01).

- 5.0 Spec angelegt — Akteur-Rollen (Sanexio/Arzt/System), Lebenszyklus mit 7 Stationen, Wellen 5.1–5.6
- 5.1 Pilot-Tenant „Test-Praxis" auf Cluster-Mini-04 (kein Echt-Patient, voller Lebenszyklus)
- 5.2 Tenant-Template-Schablone aus Sanexio-Tenant anonymisiert ableiten
- 5.3 `cortex onboard` Sub-Command — geführter Erst-Setup-Dialog
- 5.4 Erste reale Tenant-Installation (begleitet, Stracke + 1 externer Arzt)
- 5.5 Onboarding-Tutorial auf `docs.cortex-plattform.org` (oder `sanexio.github.io/cortex/docs/`)
- 5.6 Self-Service-Skalierung auf drei weitere Tenants

### Phase 6 — Cortex Layer wächst *(rollend)*
- Weitere Cortex-Layer-Projekte aus heutigem `projects/`-Bestand
  promoten: `cortex-praxis/`, `cortex-bridge/`, ggf. `cortex-mobile/`.
- Promotion-Pipeline (heute in Cortex-Web als `_integration-slots/`)
  zur Cross-Cortex-Layer-Mechanik verallgemeinern.

---

## 12. Risiken

| Risiko | Schwere | Gegenmaßnahme |
|--------|---------|---------------|
| **Tenant-Trennung greift nicht durchgängig** — Stracke-Patient-Daten leaken in Open-Source-Repo | hoch | Pre-Commit-Linter, Phase 1 darf nicht abkürzen; jeder PR vom Open-Source-Repo durchläuft Sanexio-Review |
| **Nexus-Binary-Schutz wird unterlaufen** (Reverse-Engineering) | mittel | Schutz primär über Lizenz-Recht, nicht über Krypto; akzeptieren, dass technische Hürde imperfekt ist |
| **Community zerfasert Cortex Layer in inkompatible Forks** | mittel | Sanexio-Kuration als Upstream-Wächter; semantic versioning; klare API-Verträge im `_integration-slots/`-System |
| **Lizenz-Modell scheitert** (zu teuer oder zu billig für Markt) | mittel | Phase-3-MVP mit 1–3 Test-Tenants nutzen, um Modell zu kalibrieren |
| **Phase 1 (Tenant-Trennung) zieht sich über Monate**, blockiert alles | hoch | Strict-Scope: nur „Stracke heraustrennen" zählt, generische Refactorings parken |
| **Multi-AI-Boundary (Codex/Claude/Cursor)** funktioniert für Tenants nicht | niedrig | bleibt Sanexio-intern, Tenant nutzt Claude Code monolithisch |

---

## 13. Nächste konkrete Schritte (T+1 Welle)

1. Dr.-Stracke-Freigabe für dieses Spec einholen (eventuell mit
   Iteration v0.2).
2. `_projects/INDEX.md` ergänzen: Cortex-Plattform als Top-Level-Eintrag
   neben Nexus, Desk, Cortex-Web.
3. `specs/cortex-public-skeleton/00_KONZEPT.md` Frontmatter-Status auf
   `superseded-by: specs/cortex-platform/00_VISION_UND_ROADMAP.md`.
4. Entscheidung §10.9 (Cortex-Web-Spaltung) als erste Architektur-
   Verzweigung adressieren — sonst geht der heute angefangene CW-009-
   Slot-Mechanismus in die falsche Richtung (Tenant-Inhalt vermischt mit
   Framework-Code).
5. Memory-Eintrag `project_sanexio_cortex_business_model.md` aktualisieren:
   Pointer auf dieses Spec, Zwiebel-Modell statt Public-Skeleton-Variante.
6. Telegram-Bridge-Welle-Ende-Push so erweitern, dass „Plattform-Wellen"
   visuell als solche erkennbar sind (Tag).

---

## 14. Glossar

- **Tenant** — ein Endnutzer der Plattform (Sanexio selbst, eine Partner-
  Praxis, ein einzelner Arzt). Jeder Tenant hat eigene `.tenant/`-Daten.
- **Cortex Layer** — Open-Source-Schicht der Plattform, enthält
  Anwendungs-Projekte (heute: Cortex-Web).
- **Nexus** — geschlossener Kern, Sanexio-Hoheit. Heute Source-Repo;
  Ziel: signiertes Binary mit Lizenz-Validierung.
- **Cortex-CLI** — geplantes User-Tool zur Plattform-Installation und
  -Pflege.
- **Promotion-Pipeline** — heute in Cortex-Web (`_integration-slots/`),
  später ggf. zur generischen Cortex-Layer-Mechanik erweitert.
- **Konvergenz** — selbst-anwendender Drift-Heilungs-Mechanismus, der
  jeden Mac in den Soll-Zustand bringt (siehe `_tutorials/cortex-nexus/12-self-applying-konvergenz.md`).
- **Second Brain** — Knowledge-Vault innerhalb von Nexus (Obsidian-Format).
  Tutorial-Material lebt hier, wird aber unter `docs.cortex-plattform.org`
  als Public-Read-Only-View veröffentlicht (geplant).
