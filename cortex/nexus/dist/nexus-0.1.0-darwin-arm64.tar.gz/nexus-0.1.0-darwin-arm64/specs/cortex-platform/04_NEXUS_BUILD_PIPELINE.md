---
phase: 2
status: 🟢 Wellen 2.0–2.5 + 2.6 (code-side) + 2.7a + 2.7b ✅ — 2026-05-31/06-01; Re-Build mit Notarize zur Distribution offen
welle_plan:
  - 2.0  Setup-Spec + dist-Skelett + Inventur ✅ 2026-05-31
  - 2.1  Bun-Compile gateway/ + Smoke-Test ✅ 2026-05-31
  - 2.2  py_compile agent/ + Data-Pack ✅ 2026-05-31
  - 2.3  MANIFEST-Generator + sha256-Stamping ✅ 2026-05-31
  - 2.4  Tarball-Wrap + ad-hoc codesign ✅ 2026-05-31
  - 2.5  install-Skript für Test-Mac ✅ 2026-05-31
  - 2.6  Lizenz-Token-Validierung Code-Side ✅ 2026-06-01 (gateway/src/license/check.ts + nexus-gateway.ts validateLicense()-Call; 24h-Cache-TTL + stale-while-revalidate 48h); Endpoint-Live + Re-Build = User-Aktion
  - 2.7a Apple Developer-ID-Codesign ✅ 2026-05-31
  - 2.7b Apple Notarization (arm64 + x64) ✅ 2026-06-01 — Submissions 102c961d (arm64) + 1c818919 (x64), beide Accepted; Nexus-Gateway-Bundle hat zufällig 0 Trailing-Padding-Bytes (Welle-3.6c-arm64-Diagnose hat gezeigt: Padding-Größe ist Bundle-modul-abhängig, nicht Entry-Endung-abhängig)
referenz:
  - 00_VISION_UND_ROADMAP.md §11 (Phase-2-Definition)
  - 02_OPEN_DECISIONS_RECOMMENDATIONS.md §10.2 (Build-Stack — entschieden)
  - 03_PROJECT_OSS_CLASSIFICATION.md §1 Z.45 (Nexus → private Repo-Switch nach Phase 2)
trigger_phrase: "Cortex-Plattform Phase 2 fortsetzen"
---

# Phase 2 — Nexus-Build-Pipeline

> **Zweck dieses Spec.** Phase 2 paketiert Nexus als signiertes Binär-
> Bundle, sodass es auf einem Test-Mac ohne Source-Zugriff läuft. Damit
> wird der Repo-Visibility-Switch von public auf private möglich (siehe
> `03_PROJECT_OSS_CLASSIFICATION.md` §1: „Nexus → private Repo-Switch
> sobald Build-Pipeline (Phase 2) läuft").
>
> Diese Datei ist die **operative Welle-Steuerung**. Die strategische
> Vision steht in `00_VISION_UND_ROADMAP.md` §11.4.

---

## §1 Build-Stack — final entschieden

§10.2 (`02_OPEN_DECISIONS_RECOMMENDATIONS.md`) ist freigegeben (Dr. Stracke
2026-05-31): **Option A — Bun-Bundle + Python-Bytecode**.

| Quelltyp        | Pfad in Nexus            | Build-Werkzeug                       | Output                                  |
|-----------------|--------------------------|--------------------------------------|-----------------------------------------|
| TypeScript/Bun  | `gateway/`               | `bun build --compile --target=…`     | Standalone-Binary `bin/nexus-gateway`   |
| Python 3.14     | `agent/`, `_lib/`        | `python -m compileall -b -f --invalidation-mode unchecked-timestamp` | `.pyc`-Tree (entfernt `.py`)            |
| Bash            | `scripts/`, `tools/`, `nexus-sync.sh` | unverändert übernommen   | bleibt lesbar (Schutz nicht möglich)    |
| Markdown/Config | `_rules/`, `_memory/`, `_projects/`, `Second Brain/`, `specs/`, `skills/`, `.config/` | unverändert übernommen | Data-Files im Bundle                    |

**Schutz-Modell.** Bytecode senkt die Reverse-Engineering-Hürde nur
moderat (`uncompyle6` & Co. existieren). Der eigentliche Schutz bleibt
**juristisch**: Lizenz-Vertrag + Sanexio-Hoheit über Source-Repo. Krypto
ist hier kein Selbstzweck — siehe Vision §12 „akzeptieren, dass
technische Hürde imperfekt ist".

---

## §2 Inventur — was kommt ins Bundle, was nicht

### Im Bundle (Tarball-Inhalt)

```
nexus-bundle-<version>-<arch>/
├── MANIFEST.json             # generiert: file-list, sha256, version
├── bin/
│   └── nexus-gateway         # Bun-Compile aus gateway/
├── agent/                    # nur .pyc, keine .py
├── _lib/                     # nur .pyc
├── scripts/                  # bash, unverändert
├── tools/                    # bash, unverändert
├── nexus-sync.sh             # bash, unverändert
├── _rules/                   # Markdown
├── _memory/                  # Markdown (ohne memory.db — gitignored Lokal-State)
├── _projects/INDEX.md        # nur die Index-Datei, keine `_projects/<projekt>/`
├── specs/                    # Markdown (nur freigegebene Specs, keine drafts)
├── skills/                   # .skill-ZIPs
├── Second Brain/30 Tutorials/  # Tutorial-Vault
├── .config/devices.json.template  # Template, kein User-State
├── CLAUDE.md
├── SYSTEM_MAP.md
└── HANDOVER_PHOENIX.md
```

### Explizit NICHT im Bundle

- `.git/` — Source-Repo-Metadaten (würde den ganzen Schutz aufheben)
- `.venv/` — Lokal-Python, User installiert eigene
- `_memory/memory.db`, `_memory/spawn-queue.db`, `_memory/logs/` — Lokal-State (gitignored)
- `_archive/` — historisch, nicht laufend benötigt
- `Nexus-lesson-persistence/`, `Nexus-sync-alarm/` — getrennte Arbeitskopien
- `.codex/`, `.obsidian/` — Tool-Konfiguration des Source-Setups
- `.gitignore`, `pyproject.toml`, `uv.lock` — Build-Zeit-Files (Tenant baut nicht selbst)
- `*.plist` (LaunchAgent-Plists im Root) — werden vom Install-Skript aus Templates erzeugt
- `agent/`-Quelldateien (`*.py`) — nach `compileall` gelöscht

### Templates statt Lokal-State

`_lib/`-Konfiguration, `LaunchAgents/`-Plists, `.config/devices.json` haben
heute Lokal-State. Im Bundle liegen `.template`-Varianten; das
Install-Skript materialisiert sie pro Tenant-Mac.

---

## §3 Bundle-Format

**Tarball + Manifest + ad-hoc-Signatur** (Welle 2.4).

Begründung gegen PKG-Installer für MVP: PKG verlangt Apple Developer-ID
+ Notarization-Pipeline, die heute noch nicht steht (siehe §10.7 offen).
Tarball + `install.sh` ist niedrigschwellig und macht Phase 2 unabhängig
von Apple-Cert-Setup. PKG kommt in Phase 3 (Cortex-CLI als Distributor)
oder in einer dedizierten Welle 2.7+.

### Verzeichnis-Layout im Tarball

```
nexus-<version>-<arch>.tar.gz       # signed (codesign --detached)
nexus-<version>-<arch>.tar.gz.sig   # ad-hoc-Signatur (Welle 2.4)
nexus-<version>-<arch>.tar.gz.sha256 # sha256-Sum
```

### MANIFEST.json — Format

```json
{
  "version": "0.1.0",
  "build_date": "2026-06-15T10:00:00Z",
  "build_host": "Cluster-Mini-02",
  "arch": "darwin-arm64",
  "files": [
    { "path": "bin/nexus-gateway", "sha256": "…", "size": 62914560 },
    { "path": "agent/__init__.pyc", "sha256": "…", "size": 142 }
  ],
  "code_sign": {
    "identity": "Developer ID Application: Sanexio GmbH (XXXXXXXX)",
    "ad_hoc": false,
    "notarized": false
  },
  "license": {
    "verify_endpoint": "https://cortex.sanexio.de/api/v1/license/verify",
    "required_token_format": "XXXX-YYYY-ZZZZ"
  }
}
```

`MANIFEST.json` wird in Welle 2.3 automatisch erzeugt und ist im
Tarball mit drin — `install.sh` prüft alle Files gegen die Hashes,
bevor sie nach `~/.nexus/` extrahiert werden.

---

## §4 Welle-Plan 2.0 – 2.7

| Welle | Inhalt | Output | Status |
|-------|--------|--------|--------|
| **2.0** | Setup-Spec (dieses File) + `dist/`-Skelett + Inventur-Tabelle | dieses Spec, `dist/build.sh`-Stub, `dist/README.md`, `dist/MANIFEST.template.json` | ✅ 2026-05-31 |
| **2.1** | Bun-Compile `gateway/` → `bin/nexus-gateway`. baked-version-Pattern aus cortex-cli. Wrapper-Bin `bin/nexus-gateway.ts` mit `--version`/`--help`/Dispatch | `dist/build.sh` Step 1+2, `gateway/bin/nexus-gateway.ts`, `gateway/src/baked-version.{ts,example.ts}` | ✅ 2026-05-31 |
| **2.2** | `compileall -b -f --invalidation-mode unchecked-hash` für `agent/` + `_lib/`. Bash + Markdown + Config kopieren | `dist/build.sh` Step 3+4+5 | ✅ 2026-05-31 |
| **2.3** | MANIFEST-Generator (Bash-args + Python-JSON-Build), walks Bundle-Dir, generiert JSON mit sha256 + size | `dist/gen-manifest.sh` | ✅ 2026-05-31 |
| **2.4** | Tarball-Wrap (`tar czf` + `COPYFILE_DISABLE=1`) + ad-hoc `codesign --sign -` der Binary (VOR MANIFEST, sonst Hash-Mismatch) | signed Tarball + sha256-Sum | ✅ 2026-05-31 |
| **2.5** | `dist/install.sh` für Test-Mac: sha256-Check, Extract, MANIFEST-Verify, codesign-Verify, preserve_paths-Logik, fresh-install + `--force`-Upgrade | `dist/install.sh` | ✅ 2026-05-31 |
| **2.x-Polish** | Cross-Platform-Build (darwin-arm64 + darwin-x64 in einer Pipeline, default Host, via `ARCHS="arm64 x64" bash dist/build.sh`) — analog cortex-cli Welle 3.6b. Bun lädt x64-Runtime on-demand, beide Mach-O verified. Tarball-Pair: arm64 31M, x64 34M | `dist/build.sh` Outer-Loop | ✅ 2026-05-31 |
| 2.6 | Lizenz-Token-Validierung gegen `cortex.sanexio.de/api/v1/license/verify` (blockiert durch Welle 3.6e in cortex-cli — Endpoint-Hosting) | Lizenz-Hook in `nexus-gateway`-Start | ⏳ blockiert |
| **2.7a** | Echter Developer-ID-Codesign (Cert ist im Keychain, build.sh mit `CORTEX_SIGN_MODE=dev-id CORTEX_SIGN_IDENTITY="Developer ID Application: Siegbert Stracke (QYC7S8YGXV)"`). Authority-Chain bis Apple Root CA, Apple-Timestamp, TeamIdentifier QYC7S8YGXV verified. | gateway dev-id-signed | ✅ 2026-05-31 |
| **2.7b** | Notarization via `xcrun notarytool submit` (Apple-ID `bm@westend-hausarzt.de`, Team-ID `QYC7S8YGXV`, Keychain-Profile `cortex-notary`). **arm64 + x64 beide Accepted** auf SSMD-MacBookPro-M5: arm64 Submission `102c961d-09ef-4046-afaf-69531518ba92`, x64 Submission `1c818919-5fce-494e-87d3-8c26e01d6f23`, 2026-06-01. Tarballs (nexus-0.1.0-darwin-arm64.tar.gz 32M, nexus-0.1.0-darwin-x64.tar.gz 35M) mit MANIFEST.code_sign.notarized=true. arm64 funktionierte hier zufällig, weil das Nexus-Bundle (72 modules) exakt 0 Bytes Trailing-Padding hatte. Welle 3.6c-arm64-Diagnose (cortex-cli, 2026-06-01, Mini-02) hat den echten Bug isoliert: Bun-Compile schreibt n Null-Bytes hinter LC_CODE_SIGNATURE, Padding-Größe abhängig von Code-Signature-Blob-Größe; Fix ist `truncate -s dataoff+datasize` vor `codesign`. Entry-Endung (.ts vs .mjs) ist irrelevant. | arm64 + x64 notarized; nachträglich auch generischer Trim-Patch für Nexus übernehmbar (heute nicht nötig, weil 0-Padding-Bundle) | ✅ 2026-06-01 |

### Test-Smoke-Roundtrip (Akzeptanz-Kriterium Welle 2.5)

Auf einem **dedizierten Test-Mac** (nicht Stracke-primary, kein Cortex-
Source-Clone) muss folgendes funktionieren:

1. `curl -L https://cortex.sanexio.de/nexus/install.sh | bash` (lokal:
   Tarball + install.sh über Tailscale-SCP).
2. `~/.nexus/bin/nexus-gateway --version` zeigt `0.1.0`.
3. `~/.nexus/scripts/cortex-converge.sh status` läuft grün.
4. `python -m agent.bootstrap` startet (System-Python 3.14, eigenes
   venv, requirements aus Bundle-eigener Lock-File).

Wenn alle vier Punkte grün, ist Phase 2 funktional durch und der
Nexus-Repo-Visibility-Switch von public → private wird vorbereitet.

---

## §5 Test-Mac-Strategie

**Frage:** Welcher Mac wird der Test-Mac?

| Kandidat | Status | Eignung |
|----------|--------|---------|
| Cluster-Mini-04 | online seit 2026-05-15 | passt — heute noch nicht primary für Cortex-Web, kein historischer Source-Bestand |
| Intel-MBP | offline seit Migration → M5 | reaktivierbar; Memory `feedback_migration_etc_hosts_selfloop.md` beachten |
| Neuer dedizierter VM | Apple-Silicon-VM via UTM | sauberste Lösung, kein User-Setup-Kontaminieren |

**Empfehlung Welle 2.0:** Cluster-Mini-04 als physischen Test-Mac
benutzen (existiert, online, Tailscale-erreichbar). VM-Variante als
Backup, falls Cluster-Mini-04 doch andere Aufgaben übernimmt.

**Wichtig:** Test-Mac darf **nicht** `git clone Sanexio/nexus` haben.
Phase-2-Test ist nur valide, wenn der Test-Mac keinen Source-Zugriff
hat — sonst testet er nicht das Bundle, sondern den Source-Workflow.

---

## §6 Distribution — wie kommt das Bundle auf den Test-Mac?

**Welle-2.5-Pfad (lokal, ohne Hosting):**

```
build-Mac (Cluster-Mini-02) → tar.gz → scp via Tailscale → Test-Mac (Cluster-Mini-04)
```

**Welle-2.6+-Pfad (Distribution via cortex-cli, hängt von Welle 3.6d ab):**

```
build-Mac → tar.gz + sha256 → cortex.sanexio.de/nexus/
Test-Mac: cortex install nexus → cortex-cli zieht Tarball + Verify + Extract
```

Bis `cortex.sanexio.de` live ist (cortex-cli Welle 3.6d), bleibt die
SCP-Variante der Hauptpfad. Das ist OK für Phase-2-MVP — Distribution
ist Phase-3-Hauptaufgabe.

**Beachte Memory-Lesson** `feedback_distribution_is_own_axis.md`:
Multi-Mac-Distribution ist eine eigene Achse, kein Build-Nebenprodukt.
Phase 2 baut das **Artefakt**, Phase 3 (cortex-cli) baut die
**Distribution**. Die beiden Pfade dürfen nicht vermischt werden.

---

## §7 Offene Fragen

1. **Apple Developer-ID** — hat Sanexio GmbH einen Apple-Developer-
   Account? Notarization erfordert das. Wenn nein, blockiert Welle 2.7
   bis das geklärt ist. Ad-hoc-codesign (Welle 2.4) funktioniert ohne.
2. **Cross-Compile** — bauen wir gleich `darwin-arm64` + `darwin-x64`
   oder nur Host? cortex-cli Welle 3.6b hat die gleiche offene Frage
   (heute nur Host-Target). Wahrscheinlich darwin-arm64 reicht für
   2026-Apple-Silicon-Welt, x64 als Fallback wenn jemand Intel-Mac hat.
3. **Lizenz-Hook-Tiefe** — verifiziert `nexus-gateway` bei jedem Start?
   Bei jedem Tag? Beim Mac-Boot? Cache-Strategie? — wird in Welle 2.6
   final entschieden, hängt am `cortex.sanexio.de`-Endpoint-Design.
4. **Tutorial-Vault-Update-Mechanik** — `Second Brain/30 Tutorials/`
   ist im Bundle drin. Bei Tutorial-Updates: muss der ganze Bundle
   neu gebaut werden? Oder gibt es ein separates Tutorial-Update?
   Welle 2.5 entscheidet: heute Bundle-Update = neu installieren.
5. **`_memory/`-State-Migration** — bei Bundle-Update soll Tenant-
   lokales `memory.db` erhalten bleiben. `install.sh` muss das
   beachten (nicht über bestehendes `~/.nexus/_memory/` schreiben).

---

## §8 Wenn etwas unklar wird

- **Build-Stack-Detail:** `02_OPEN_DECISIONS_RECOMMENDATIONS.md` §10.2
- **Bun-Compile-Pattern:** `~/Cortex/projects/cortex-cli/dist/build.sh`
  (Vorbild: baked-version-Trick wegen `/$bunfs/`-Bundle-Eigenheit)
- **Memory-Lesson Bun-Bundle:** `memory/feedback_bun_compile_no_package_json_access.md`
- **Vision-Big-Picture:** `00_VISION_UND_ROADMAP.md` §3 + §11.4
- **OSS-Klassifikation:** `03_PROJECT_OSS_CLASSIFICATION.md` §1 (Repo-Switch-Bedingung)

---

## §9 Welle-Ende-Debriefs

### 2.0 (2026-05-31) — Setup

**WAS GEMACHT:**
- Spec `04_NEXUS_BUILD_PIPELINE.md` angelegt; §10.2 (Build-Stack
  Option A) final verankert; Inventur (11 Pfade rein, 7 raus,
  4 Templates); Bundle-Format (signierter Tarball + MANIFEST + sha256);
  Welle-Plan 2.0–2.7; Test-Mac-Empfehlung Cluster-Mini-04; 5 offene
  Fragen dokumentiert; `dist/`-Skelett angelegt (Stub-Files).

**WAS GELERNT:**
- „Phase 2" hatte zwei historisch driftende Bedeutungen (Post-Split-
  Cleanup-Block vs. Nexus-Build-Pipeline). → Anker: dieses Spec selbst.

### 2.1–2.5 (2026-05-31) — Voll-Pipeline-Build

**WAS GEMACHT:**
- **Welle 2.1:** Bun-Compile gateway/ läuft. Wrapper-Bin
  `gateway/bin/nexus-gateway.ts` (Argv-Parsing für `--version`/`--help`,
  Dynamic-Dispatch zu `channels/telegram/channel.ts`). baked-version-
  Pattern via `gateway/src/baked-version.{ts,example.ts}` (gitignored
  generated + committed template). Smoke: `nexus-gateway 0.1.0` mit
  build_date/host/git_sha/bun/platform.
- **Welle 2.2:** py_compile mit `--invalidation-mode unchecked-hash`
  (Python 3.14 kennt `unchecked-timestamp` nicht). 74 `.pyc`-Files
  in agent/+_lib/, `.py` raus. Bash + Markdown + Config kopiert.
- **Welle 2.3:** `dist/gen-manifest.sh` walks Bundle-Dir und schreibt
  MANIFEST.json (4150 File-Einträge mit sha256+size). Bash-args + Python-
  Inline-JSON-Build.
- **Welle 2.4:** ad-hoc `codesign --sign -` der Binary VOR MANIFEST
  (Reihenfolge-Fix: signieren ändert sha256). Tarball mit
  `COPYFILE_DISABLE=1` (verhindert macOS extended-attr-Pollution).
  Tarball 31M (von 61M Binary + 4149 Files komprimiert), sha256-Sum.
- **Welle 2.5:** `dist/install.sh` für Test-Mac. sha256-Check, Extract,
  MANIFEST-Hash-Verify (alle 4150 Files), codesign-Verify, target-prep
  mit `--force`-Upgrade-Modus, preserve_paths-Logik (memory.db,
  devices.json bleiben erhalten beim Upgrade). Smoke nach
  `/tmp/nexus-test-install/` grün — voller Roundtrip durch.

**WAS GELERNT:**
- Python 3.14 `compileall --invalidation-mode` akzeptiert nur
  `checked-hash`, `timestamp`, `unchecked-hash` (NICHT `unchecked-
  timestamp`). → Anker: `memory/feedback_compileall_invalidation_mode.md`.
- codesign muss VOR MANIFEST-Generation laufen, sonst stimmt der sha256
  der Binary nicht mehr und install-Verify schlägt fehl. → Anker:
  `memory/feedback_codesign_before_manifest.md`.
- `COPYFILE_DISABLE=1 tar` ist auf macOS Pflicht, sonst kommen
  `._<file>`-AppleDouble-Resource-Fork-Files in den Tarball und
  pollute den Tenant-Mac-Extract. → Anker:
  `memory/feedback_macos_tar_copyfile_disable.md`.

**STRATEGISCHE WAHLEN:**
- baked-version.ts via `.gitignore` + `.example.ts`-Template statt
  committed mit Welle-Wert (wie cortex-cli es tut). Sauberer für
  Multi-Mac-Pull (keine merge conflicts auf auto-generated Files).
- install.sh fresh-install-default mit `--force`-Override für Upgrade.
  Echter Upgrade-Pfad (atomic-replace, rollback) bleibt Welle 2.6+.
