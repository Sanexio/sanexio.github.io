---
phase: 5
status: 🟢 Welle 5.0 ✅ 2026-06-01, Welle 5.1 weitgehend ✅ 2026-06-02 (8/9 Schritte grün, Lessons in §4). Wellen 5.1b/5.1c/5.2ff. ⏳
welle_plan:
  - 5.0  Spec + Akteur-Rollen + Pre-Conditions ✅ 2026-06-01
  - 5.1  Pilot-Tenant „Test-Praxis" auf Cluster-Mini-04 🟢 weitgehend ✅ 2026-06-02 (8/9 Schritte; 7 Lessons protokolliert; nexus-gateway-Test offen weil Nexus-Distribution fehlt)
  - 5.1b cortex-cli Bundle mit add.mjs-HTTPS-Default-Fix neu signen + deployen
  - 5.1c Nexus-Distribution-Tarballs auf Pages bringen (Welle-2.6 Bundle-Side)
  - 5.2  Tenant-Template-Schablone aus Sanexio-Tenant ableiten (anonymisiert)
  - 5.3  `cortex onboard` Sub-Command — geführter Erst-Setup-Dialog
  - 5.4  Erste reale Tenant-Installation (begleitet, Stracke + 1 externer Arzt)
  - 5.5  Onboarding-Tutorial auf docs.cortex-plattform.org (oder GitHub Pages)
  - 5.6  Skalierungs-Schritt: Self-Service-Onboarding für drei weitere Tenants
referenz:
  - 00_VISION_UND_ROADMAP.md §11 (Phase-5-Definition)
  - 03_PROJECT_OSS_CLASSIFICATION.md §1 (was OSS, was Tenant-privat)
  - 04_NEXUS_BUILD_PIPELINE.md §1 (signiertes Bundle Phase 2)
  - cortex-cli/OSS_PREP.md (CLI-MVP-Status)
trigger_phrase: "Cortex-Plattform Phase 5 fortsetzen"
---

# Phase 5 — Tenant-Onboarding für externe Ärzte

> **Zweck:** dem ersten externen Arzt eine produktive Cortex-Instanz
> aufsetzen, vom Erst-Kontakt bis zum laufenden Nexus-Gateway, ohne
> dass Stracke jede Datei manuell einrichten muss.
>
> **Heutiges Modell (vor Phase 5):** Stracke ist gleichzeitig
> Sanexio-Betreiber, Praxis-Inhaber und Cortex-Entwickler. Es gibt
> genau einen Tenant (Praxis Dr. Stracke). Phase 5 entkoppelt diese
> Rollen.

## §1 Akteur-Rollen

| Rolle | Wer | Aufgabe in Phase 5 |
|---|---|---|
| **Sanexio** | Stracke | Lizenz ausstellen, Identität prüfen, Begleitung bei den ersten 1–3 Tenants |
| **Externer Arzt** | „Dr. Mustermann" | Installation auf eigenem Mac, eigene Inhalte einpflegen, eigene Domain |
| **Cortex-System** | Cortex-CLI + Nexus + Cortex-Web | technische Plattform; muss Self-Service-tauglich sein |

Zentrale Trennung: **Tenant-Inhalte gehören dem Arzt, Cortex-System
bleibt in Sanexio-Hand.** Der Arzt darf seinen Tenant-Inhalt jederzeit
exportieren und mitnehmen. Das Cortex-System (Nexus-Kern, signierte
Binaries) bleibt unter Sanexio-Kontrolle.

## §2 Voraussetzungen (Stand 2026-06-01)

Was vor Welle 5.1 (Pilot-Tenant) funktionieren muss:

- ✅ Phase 1 — Tenant-Trennung im Code
- ✅ Phase 2 Wellen 2.0–2.5 + 2.6 (code-side) + 2.7a + 2.7b — Nexus baut, signiert, notarisiert
- ✅ Phase 3 Wellen 3.0–3.6a + 3.6b + 3.6d + 3.6e — Cortex-CLI installiert + initialisiert + updated
- ✅ Phase 4 — Cortex-Web ist OSS, Demo-Tenant existiert

Offene Voraussetzungen vor Welle 5.4 (erste reale Installation):

- ⏳ Lizenz-Endpunkt live auf `cortex.sanexio.de/api/v1/license/verify`
  (Phase 3.6e User-Aktion: PHP-Stub hochladen)
- ⏳ Nexus-Bundle mit Welle-2.6-Code (License-Hook) gebaut + signiert
  + auf Distribution-URL verfügbar
- ⏳ Tenant-Identitäts-Verfahren festgelegt (siehe §5)

## §3 Lebenszyklus eines Tenants

```
┌────────────────────────────────────────────────────────────────┐
│  1. Kontakt + Identitäts-Prüfung (Stracke ↔ Arzt)              │
│     Approbation, Praxis-Daten, Anschrift                       │
├────────────────────────────────────────────────────────────────┤
│  2. Lizenz-Ausstellung (Stracke)                               │
│     Token im Format XXXX-YYYY-ZZZZ generieren                  │
│     Eintrag in cortex.sanexio.de tokens.json                   │
│     Tenant-Repo „<praxisname>-tenant" auf GitHub (Sanexio-Org) │
│     mit Schreibrecht für den Arzt                              │
├────────────────────────────────────────────────────────────────┤
│  3. Erst-Installation (Arzt, auf eigenem Mac)                  │
│     curl -fsSL https://cortex.sanexio.de/install.sh | sh       │
│     cortex init --license XXXX-YYYY-ZZZZ                       │
│     cortex add cortex-web                                      │
├────────────────────────────────────────────────────────────────┤
│  4. Tenant-Inhalte einpflegen (Arzt, begleitet)                │
│     Team-Profile, Leistungen, Pages, Impressum                 │
│     git clone <tenant-repo> → trunk/_examples/ als Vorlage     │
├────────────────────────────────────────────────────────────────┤
│  5. Erst-Veröffentlichung (Arzt)                               │
│     Eigene Domain auf eigenes Hosting (WordPress/Astro/Shopify)│
│     Tenant-Repo treibt Build, Hosting bleibt Arzt-Wahl         │
├────────────────────────────────────────────────────────────────┤
│  6. Laufender Betrieb (Arzt selbstständig, Sanexio-Updates)    │
│     Auto-Update via cortex update + LaunchAgent (Welle 3.6f)   │
│     Bei Problemen: GitHub-Issue auf Sanexio/cortex-cli         │
├────────────────────────────────────────────────────────────────┤
│  7. Optional: Abbruch / Daten-Export (Arzt)                    │
│     git clone tenant-repo → Inhalte gehören dem Arzt           │
│     Lizenz auf Sanexio-Seite revoken                           │
└────────────────────────────────────────────────────────────────┘
```

## §4 Wellen-Plan im Detail

### Welle 5.0 — Spec (diese Datei) ✅ 2026-06-01

Vision festschreiben, Wellen-Plan, Akteur-Rollen.

### Welle 5.1 — Pilot-Tenant „Test-Praxis" 🟢 weitgehend ✅ 2026-06-02

Auf Cluster-Mini-04 (Apple-Silicon-Mini, User `clusteradm`, ohne
Bau-Werkzeuge) Lebenszyklus aus §3 in einer Sandbox (`~/welle-5.1-pilot/`)
durchgespielt.

**Was gegrün ist:**

| Schritt | Stand | Detail |
|---|---|---|
| `cortex install` via `curl…\|sh` mit Quarantine-Bit | ✅ | sha256 verified `dd43b4044e28d8ae…`, arm64-Bundle (notarisiert nach Welle 3.6c-arm64-Fix) |
| Binary-Verifikation auf Pilot-Mac | ✅ | `spctl --assess --type install`: `accepted, source=Notarized Developer ID`; Authority-Chain bis Apple Root CA |
| `cortex init --license` Offline-Pfad | ✅ | Endpunkt unerreichbar → license.json mit `validated_at=null` + `online_error`-Vermerk + Hinweis-Text für späteren Re-Try |
| `cortex init --license` Online-Pfad gegen Mock | ✅ | Python-Mock-Endpunkt auf 127.0.0.1:8765, license.json mit tenant_id, tenant_name, features, expires_at, validated_against |
| `cortex add cortex-web` | ⚠ | SSH-Default scheitert auf frischem Mac ohne GitHub-Key — siehe Lesson 1; HTTPS-Workaround manuell gemacht |
| `validate.sh` mit Pilot-Tenant | ✅ | nach `brew install bun` + `bun install`: 1 Beispiel-Produkt-Datei sauber validiert |
| `build-team.mjs` (WordPress-Adapter) | ✅ | 3 Quelldateien → JSON mit Schema-Version + Renderer-Hinweis |
| `build-page-hub.mjs` (WordPress-Adapter) | ✅ | 4 PHP-Dateien (Impressum + Leistungen je DE/EN) in `.demo-theme/inc/data/` |
| `nexus-gateway`-Start mit Lizenz-Check | ❌ | Nexus-Bundle nicht auf Distribution-Endpunkt verfügbar — Welle 2.6 ist nur Code-Side; siehe Lesson 5 |

**Lessons (gehören in die Folge-Wellen):**

1. **`cortex add` benutzte SSH-URL als Default** — externe Tenants
   haben typischerweise keinen GitHub-SSH-Key. Fix: HTTPS als Default,
   `CORTEX_ADD_PROTO=ssh` als Opt-In. Code-Patch ist in
   `src/commands/add.mjs` (Welle 5.1b, Commit folgt). Welle 5.1b
   re-deployt das Bundle.
2. **Tenants brauchen Bun lokal** — `validate.sh` und die
   Adapter-Skripte (`bun adapters/wordpress/build-*.mjs`) erfordern
   Bun. Heute ist im `install.sh`-Bundle-Modus der Bun-Check
   übersprungen, weil cortex-cli die Runtime eingebakt hat. Aber für
   Cortex-Web-Builds braucht der Tenant Bun separat.
   Optionen: (a) Bun-Check auch im Bundle-Modus, (b) Cortex-Web
   selbst als Standalone-Bundle, (c) klare Doku-Stelle im Onboarding-
   Tutorial.
3. **Build-Skripte liegen unter `adapters/wordpress/`**, nicht im
   `tools/`-Top-Level. Die Tutorial-Doku muss präzise URLs nennen,
   sonst scheitern Endnutzer am Pfad.
4. **`validate.sh` produziert kosmetische JSON-Schema-Warnungen**
   („unknown format date-time"). Nicht blockierend, aber unprofessionell.
   Fix-Welle: Schema-Refs anpassen oder Warning-Filter.
5. **Nexus-Distribution-Bundle fehlt.** Nexus 2.7b ist auf M5
   notarisiert worden (Submissions `102c961d`/`1c818919`), aber die
   Tarballs sind nicht auf gh-pages oder `cortex.sanexio.de/dist/`
   deployt. Ohne das kann der Pilot den Gateway-Lifecycle nicht
   testen. Welle 5.1c: Nexus-Tarballs auf Distribution-Endpunkt
   bringen (analog cortex-cli-Pattern).
6. **PATH-Hinweis nach `cortex install`** — Endnutzer übersieht das
   leicht. Onboarding-Tutorial muss explizit auf das ~/.zshrc-Add
   hinweisen, oder install.sh könnte das automatisieren.
7. **Tenant-Repo war hier ein lokaler `cp -r` aus
   `cortex-web/trunk/_examples/`** — nicht ein eigenes GitHub-Repo.
   Echte Tenant-Repo-Anlage (per Template) ist Welle 5.2.
8. **`Sanexio/cortex-web` ist auf GitHub noch privat** (Stand
   2026-06-02). Welle-4-Plan sagt OSS-Launch ist durch (History
   gefilter-repot, Tenant-Migration abgeschlossen, CoC angelegt),
   aber die Repo-Visibility-Flag wurde nicht auf public geflipt.
   Folge: weder SSH- noch HTTPS-Clone funktionieren ohne Auth-
   Setup auf dem Tenant-Mac. Externe Tenants scheitern.
   Fix-Welle (Phase 4 Restpolish, eigene Welle): `gh repo edit
   Sanexio/cortex-web --visibility public` durch Stracke. Erst
   danach ist `cortex add cortex-web` für Endnutzer ohne
   Zusatz-Konfiguration durchführbar.

**Konsequenz:** Welle 5.1 bleibt als „weitgehend ✅" markiert
(8 von 9 Schritten grün). Welle 5.2 + 5.3 dürfen starten, sobald
Welle 5.1b (Bundle mit add.mjs-Fix) deployt ist UND `cortex-web`
auf GitHub auf public geflippt ist (Lesson 8). Welle 5.1c
(Nexus-Distribution) ist Voraussetzung für den nexus-gateway-Test
in Welle 5.4.

### Welle 5.2 — Tenant-Template-Schablone

Aus dem heutigen `Sanexio-Tenant`-Repo eine **anonymisierte
Schablone** ableiten. Inhalte raus, Struktur + Schema-Beispiele rein.

Schablone gehört in ein eigenes Repo `Sanexio/cortex-tenant-template`
(öffentlich). Neuer Tenant erstellt sein eigenes Repo per:

```bash
gh repo create Sanexio/dr-mustermann-tenant \
  --template Sanexio/cortex-tenant-template \
  --private --confirm
```

Memory-Anker: `feedback_framework_tenant_split.md` zeigt das Pattern.

### Welle 5.3 — `cortex onboard` Sub-Command

Geführter Erst-Setup-Dialog im Cortex-CLI. Heute besteht der
Onboarding-Flow aus mehreren manuellen Schritten (`install`, `init`,
`add`). Welle 5.3 bündelt das in einen interaktiven Wizard:

```
$ cortex onboard
Cortex-Setup Schritt 1/5 — Lizenz
  Lizenz-Schlüssel (XXXX-YYYY-ZZZZ): ____

Cortex-Setup Schritt 2/5 — Tenant-Repo
  Tenant-Repo (Sanexio/dein-tenant): ____
  Schreibrechte werden geprüft …

Cortex-Setup Schritt 3/5 — Cortex-Web-Layer
  Cortex-Web wird geklont nach ~/.cortex/projects/cortex-web …

Cortex-Setup Schritt 4/5 — LaunchAgent für Auto-Update
  [j/N] LaunchAgent installieren? j

Cortex-Setup Schritt 5/5 — Smoke-Test
  ✓ cortex install
  ✓ cortex init
  ✓ cortex status
  ✓ cortex add cortex-web

Setup abgeschlossen. Nächster Schritt: cortex status
```

Implementation als `src/commands/onboard.mjs`. Welle-3.6e
init-Logic + Welle-3.6f LaunchAgent-Logic + Welle-3.4 add-Logic
werden gewrappt.

### Welle 5.4 — Erste reale Tenant-Installation

Mit einem konkreten externen Arzt, vor Ort oder remote per
Bildschirmfreigabe, durchspielen. Stracke führt, der Arzt klickt
selbst. Alle Reibungsstellen werden protokolliert + flossen in
Welle 5.5.

### Welle 5.5 — Onboarding-Tutorial

Auf `docs.cortex-plattform.org` oder als Subpath von
`sanexio.github.io/cortex/docs/` (analog dem heutigen Distribution-
Pattern für install.sh). Inhalt:

- Voraussetzungen (Mac, macOS-Version, Apple-Developer-Cert nicht
  nötig auf Arzt-Seite, Domain optional)
- Schritt-für-Schritt mit Screenshots
- Häufige Fehler + Diagnose
- DSGVO-Hinweise für Patient-Daten-Pflege
- Wie eigenes Tenant-Repo gepflegt wird (Git-Basics)

### Welle 5.6 — Skalierung auf drei weitere Tenants

Self-Service-Onboarding ohne Stracke-Hand-Holding. Wenn drei Ärzte
ohne Eskalation an Stracke das System produktiv bringen, ist
Phase 5 abgeschlossen und Phase 6 (rollende Cortex-Layer-
Erweiterung) übernimmt.

## §5 Identitäts-Verfahren

> ⏳ Entscheidung offen — wird in Welle 5.1 fixiert.

Optionen:

- **A) Approbations-Urkunde** als PDF an Stracke. Manuelle Prüfung.
- **B) Bundesärztekammer-Suche** (öffentlich) gegen Praxis-Daten.
- **C) Eintragung im Arztverzeichnis Bayerns/Hessens/etc.** — Quelle
  variiert pro Bundesland.
- **D) Notarielle Bestätigung** (für hochpreisige Tenant-Pakete).

Empfehlung für MVP: A + B kombiniert. C+D später bei Bedarf.

Tenant-Voraussetzung für Lizenz-Ausstellung:
1. Praktizierender Arzt mit gültiger Approbation
2. Eigene Praxis (Niederlassung oder MVZ-Anstellung)
3. Schriftliche Bestätigung der DSGVO-Verantwortung für die eigene
   Patient-Datenpflege

## §6 Sicherheits- und DSGVO-Pflichten

- **Patient-Daten bleiben beim Arzt.** Cortex-Web-Tenant-Repo enthält
  nur öffentlich-zeigbares Material (Team-Profile, Leistungen,
  Impressum). Patient-Akten leben **nicht** im Tenant-Repo, sondern
  im praxiseigenen System (Doctor-Workflow oder ähnliches).
- **Lizenz-Token ist Praxis-gebunden.** Token-Teilung mit Kollegen
  ist Vertragsbruch — entspricht Software-Lizenz-Vergehen.
- **Sanexio sieht keine Tenant-Inhalte.** Endpunkt-Aufrufe an
  `cortex.sanexio.de/api/v1/license/verify` enthalten nur den Token,
  keine Tenant-Daten.
- **DSGVO-Auftragsverarbeitung NICHT nötig** für die Cortex-CLI- und
  Nexus-Komponenten, weil Sanexio dort keine Patient-Daten verarbeitet.
  Klar dokumentieren im Onboarding-Tutorial.

## §7 Eskalations-Pfade

| Problem | Wer löst es |
|---|---|
| `cortex install` failt (curl-sh-Bug, macOS-Version) | GitHub-Issue auf Sanexio/cortex-cli — Stracke + Claude |
| Lizenz nicht akzeptiert | Stracke prüft `tokens.json` auf cortex.sanexio.de |
| Tenant-Repo-Schreibrechte fehlen | Stracke fügt Arzt-GitHub-User als Collaborator hinzu |
| Patient-Daten-Frage (DSGVO) | Arzt selbst, ggf. DSGVO-Berater |
| Domain-/Hosting-Problem | Arzt mit seinem Hosting-Anbieter |
| Cortex-Web Schema-Fehler beim Build | GitHub-Issue auf Sanexio/cortex-web |
| Tenant-Inhalts-Frage („wie schreibe ich X") | Onboarding-Tutorial Kapitel — wenn Lücke, ergänzen |

## §8 Offene Fragen

1. **Preis-Modell** — Phase-5-Spec klärt das nicht. Es gibt ein
   eigenes Welle-Kommunikations-/Vertrieb-Konzept, das parallel
   entsteht.
2. **Identity-Verfahren-Detail** — siehe §5, in Welle 5.1 final.
3. **Cortex-Plattform-Domain** — `docs.cortex-plattform.org` ist
   heute nicht registriert. Alternativ Subdomain
   `docs.cortex.sanexio.de` oder Pfad `sanexio.github.io/cortex/docs/`.
4. **Multi-Mac-Tenant** — wenn ein Arzt zwei Macs hat (Praxis +
   Mobil), wie wird die Lizenz dort verteilt? Eine Lizenz pro Praxis
   oder pro Mac? Empfehlung: pro Praxis, beliebig viele Macs.
5. **Tenant-Abrechnung** — wenn Welle 5.6 abgeschlossen ist, wird
   irgendwann eine Sanexio-Rechnungsstellung an Tenants nötig. Das
   gehört in eine eigene Welle, **nicht** in Phase 5, weil es
   Bank-/Bezahl-Infrastruktur berührt (Tier-3-Hardstop bei
   Schreibops, eigene Sicherheits-Welle).

## §9 Querverweise

- Memory `feedback_framework_tenant_split.md` — Pattern für Tenant-
  Repo-Trennung.
- Memory `project_apple_developer_apple_id.md` — Apple-Developer-
  Membership liegt bei Sanexio, nicht bei Tenants.
- `04_NEXUS_BUILD_PIPELINE.md` §1 — was im signierten Bundle steckt.
- `cortex-cli/server/README.md` — Lizenz-Endpunkt-Deployment.
- `Sanexio-Tenant`-Repo — Vorbild für Tenant-Layout.
