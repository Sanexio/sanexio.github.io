# Rules-Consolidation — Plan (Entwurf 2026-05-31)

> **Ziel:** `_rules/` von 15 Files (Stand nach Stub-Kill 2026-05-31) auf
> 6 reduzieren, ohne Inhalt zu verlieren. Heilt Stracke-Beschwerde
> „System ist überladen, Claude verliert den Überblick".

## Ziel-Architektur (15 → 6)

| Neues File | Zieht ein | Größe (geschätzt) |
|---|---|---|
| `AUTONOMY_CONTRACT.md` (erweitert) | + `risk-levels.md` (§Risiko) + `modes.md` (§Mode-Matrix) + `stop-conditions.md` (§Stop) + `tasks.md` (§Task-Manifest) + `verification.md` (§Verifikation) + `retention.md` (§Anti-Müll) + `sync-policy.md` (§Sync) | ~600 Zeilen |
| `glossary.md` (unverändert) | — | 109 Zeilen |
| `user-directives.md` (unverändert) | — | 93 Zeilen |
| `ai-cooperation.md` | + `multi-ai-boundaries.md` (§Andere KIs) + `lesson-anchors.md` (§Lesson-Persistenz) | ~250 Zeilen |
| `security.md` (unverändert) | — | 61 Zeilen |
| `medical-domain.md` (unverändert) | — | 56 Zeilen |

**Ergebnis:** 6 Files statt 15. Tier-A bleibt 4 Files (AUTONOMY_CONTRACT, glossary, user-directives, security). `ai-cooperation` + `medical-domain` als Tier-C.

## Risiken / Migrations-Aufwand

Querverweise auf die alten Files existieren in:
- `CLAUDE.md`
- `SYSTEM_MAP.md`
- Tutorial 14 (`Cortex & Nexus/14-cortex-nexus-vollstaendige-arbeitsweise.md`)
- mehrere `_memory/`-Files
- `agent/modes/autonomy.md`, `agent/modes/safe.md`, `agent/modes/tier3.md`
- mehrere `specs/`-Files
- mehrere Tutorials in `Second Brain/30 Tutorials/`

Pro abgeschaffter Datei: ~10–30 Stellen zu aktualisieren. Gesamt für 9 abgeschaffte Files: ~150 Edit-Stellen. Brauchbar mit Python-Skript (Regex-Replace + Fragment-Anchor wo möglich).

## Schritte

1. **Mapping-Datei** schreiben (`01_MAPPING.md`): für jede abgeschaffte Datei: Quelle → Ziel-Datei + Ziel-Abschnitt-Anker.
2. **Migration-Skript** (`02_migrate.py`): kopiert Inhalte in Zielsektionen, ersetzt Querverweise repo-weit, verschiebt Quellen nach `_archive/rules-pre-consolidation-2026-05-31/`.
3. **Dry-Run** auf Branch `rules-consolidation`.
4. **Verifikation**: `grep -RIln "_rules/<abgeschafftes_file>"` muss 0 ergeben.
5. **Tutorial 14 Abschnitt 3.2** updaten.
6. **Memory-Index** (`MEMORY.md` im Claude-Auto-Memory) updaten.
7. Merge auf main, push.

## Was NICHT in dieser Welle

- Keine inhaltlichen Regel-Änderungen — nur Restrukturierung.
- Keine Änderung an `agent/modes/*.md` (Tier-3 + autonomy + safe bleiben Single Source).
- Kein Touch an `desk/`-Sub-Verzeichnis.

## Aufwand

~1 Tag (Mapping 2h, Skript 3h, Verifikation+Tutorial-Update 3h). Nicht in einem Rutsch mit anderen Wellen, weil das Risiko von Querverweis-Drift mit jeder parallelen Änderung steigt.
