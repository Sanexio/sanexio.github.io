# Cortex Public-Skeleton — Konzept (Stub) — SUPERSEDED

> **Status:** SUPERSEDED am 2026-05-24 durch
> `specs/cortex-platform/00_VISION_UND_ROADMAP.md`. Das hier beschriebene
> Modell „Nexus = abgespeckte Public-Variante mit austauschbarem User-Layer"
> ist nicht mehr aktuell. Aktuelles Modell: **Zwiebel-Architektur** mit
> Nexus = closed core, Cortex Layer (Open Source) drumherum, User-Layer
> ganz außen.
>
> Diese Datei bleibt als historisches Konzept-Dokument bestehen — die
> Inventur weiter unten (was-ist-generisch-vs-stracke-spezifisch) ist für
> Phase 1 Tenant-Trennung des Platform-Specs weiterhin nützlich.
>
> **Original-Status:** Stub, Konzeptphase.
> **Stand:** 2026-05-16.
> **Anlass:** Strategische Vorgabe von Dr. Stracke 2026-05-15
> (Tutorial-Welle-1-Review): Cortex soll als Sanexio-Geschäftsmodell ein
> dezentralisiertes Ärzte-Netzwerk-Tool werden. Andere Mediziner können
> eine abgespeckte Public-Version über GitHub herunterladen und auf
> ihrem lokalen Rechner ausführen. Voll-Nexus bleibt unter Dr. Strackes
> alleiniger Kontrolle.

## Ziel

Ein generischer, abgespeckter Cortex-Stack („Public Skeleton"), der:

- Open Source / Sanexio-Lizenz auf GitHub liegt
- vom Teilnehmer lokal geklont und mit eigenen Credentials betrieben wird
- die Kern-Mechaniken (Agent-Loop, Mode-System, Skills, Sync, Connexio)
  unverändert erhält
- den **User-Layer austauschbar** macht (Profil, Praxis-Domain,
  Geräte-Registry)
- **keine** Stracke-spezifischen Daten enthält (Patient-Tags, SmartQ,
  praxis-webseite, …)

## Was Public ist (✅ generisch, ohne Stracke-Bezug)

Nach Abschluss des Architecture-Refactor 2026-05-16 (Priorität 1–3) sind
diese Files generisch und 1:1 übernehmbar:

- `agent/` (Loop, Skills-Engine, Memory-Store, Provider-Adapter,
  Connexio-Kernel, Cron-Runner) — bis auf wenige Pfad-Konstanten.
- `gateway/` (TS/Bun-Router, Channel-Abstraktion).
- `tools/cortex-mode/` (Mode-Hook, Helper-Skripte).
- `nexus-sync.sh` + `com.cortex.nexus-sync.plist`.
- `_rules/`:
  - `AUTONOMY_CONTRACT.md` (Index)
  - `glossary.md`
  - `risk-levels.md`, `modes.md`, `stop-conditions.md`, `tasks.md`,
    `verification.md`, `retention.md`, `ai-cooperation.md`,
    `multi-ai-boundaries.md`, `lesson-anchors.md`
  - `tier3.md` (Tier-3 generisch, evtl. ohne medizinische Beispiele)
  - `sync-policy.md`, `security.md`
- `agent/modes/` (autonomy.md, safe.md, tier3.md).
- `agent/memory/golden_rules.py` (Parser + Tier-3-Renderer).
- `_memory/golden-rules.md` (Aggregat-Snapshot).
- `specs/architecture-refactor-2026-05/` (Audit als Public-Referenz).

## Was Private bleibt (🔒 Stracke-only)

- `_memory/USER.md` (Stracke-Profil) → im Public-Skeleton durch
  `USER.md.template` ersetzt.
- `_memory/KNOWLEDGE.md` → Template ohne Stracke-Vault-Symlinks.
- `_rules/user-directives.md` (Stracke-Pauschal-Freigabe 2026-05-09).
- `_rules/medical-domain.md` (DSGVO, BLOCKED_TAGS, SmartQ).
- `.config/devices.json` (Stracke-Mac-Inventar) → leeres Template im
  Public-Skeleton.
- `Second Brain/` (Stracke-Vault) → in der Public-Variante leer oder
  Beispiel-Vault.
- `PHOENIX_RESUME.md`, `HANDOVER_PHOENIX.md` (Stracke-Snapshot, →
  `_archive/`).
- `projects/` und `_lib/` (Stracke-Werkprojekte und Domain-Lib für
  Medizin/Steuer).

## Was generalisierbar ist (🔧)

Mit kleinem Refactor public-tauglich zu machen:

- `agent/skills/builtin/doctor.py` — POLICY_FILES als Config laden statt
  hartcodieren.
- `agent/skills/builtin/tutorial_curator.py` — Vault-Wurzel als
  Konfigurations-Parameter.
- `CLAUDE.md` — Stracke-spezifische Note „praxis-webseite-Korrektur"
  entfernen; Geräte-Quick-Reference verallgemeinern.
- `SYSTEM_MAP.md` — Cortex-Mesh-Abschnitt als Beispiel/Vorlage markieren.
- `tier3.md` — Beispiele („SmartQ", „Patientenmails") gegen generische
  Platzhalter tauschen.

## Repo-Struktur (Vorschlag)

```
Sanexio/cortex-public                 ← öffentliches Repo
├── README.md                          ← Onboarding für Teilnehmer
├── LICENSE                            ← Sanexio-Lizenz
├── nexus-skeleton/                    ← Skeleton-Snapshot
│   ├── _rules/                        ← Pflicht-Lese-Stack (generisch)
│   ├── agent/                         ← Agent + Gateway
│   ├── tools/
│   ├── nexus-sync.sh
│   ├── pyproject.toml
│   └── …
├── docs/                              ← Setup-Anleitung
└── scripts/                           ← onboard-device.sh + Setup-Helper

Sanexio/nexus                          ← privates Stracke-Repo (bleibt)
└── (Voll-Stack inkl. medical-domain.md, USER.md, devices.json, Vault, …)
```

## Update-Pfad für Teilnehmer

- Teilnehmer pullt regelmäßig aus `Sanexio/cortex-public` (oder lokales
  Fork-Modell).
- Stracke kuratiert, was vom Privat-Nexus ins Public-Repo wandert
  (Filter über Allowlist-Path + Tag-Filter).
- **Public-Teilnehmer-Macs synchronisieren nicht direkt zum Stracke-Nexus.**
  Tailscale-Mesh + privater Sync-LaunchAgent bleiben Stracke-exklusiv.

## Lizenz- und Trust-Modell (offen)

Noch zu definieren:

- Lizenz-Wahl (Sanexio-Closed-Public? AGPL? Eigene Lizenz mit
  Compliance-Klauseln für medizinischen Einsatz?).
- DSGVO-/Compliance-Pflichten der Teilnehmer.
- Telemetrie/Opt-in für anonymisiertes Crash-Reporting an Sanexio
  (für Bug-Fixing der Public-Version).
- Update-Policy: rolling vs. tagged releases.
- Sicherheits-Audit-Frequenz vor jedem Release.

## Migrations-Plan (hoch-iterativ)

### Phase 1 — Vorarbeit (jetzt laufend, Architecture-Refactor 2026-05)

- ✅ Priorität 1: Geister-Pointer beheben, Glossar, Tier-3 Single Source.
- ✅ Priorität 2: AUTONOMY_CONTRACT-Aufspaltung, Mode-Files schlank,
  Skill-INDEX.
- 🔄 Priorität 3 (laufend): User-Layer auslagern, Skills-Disambiguierung,
  Sync-Policy konsolidiert.

### Phase 2 — Generalisierungs-Refactor (nach P3)

- `doctor.py` und `tutorial_curator.py` auf Config-Pfade umstellen.
- `tier3.md` Beispiele anonymisieren oder per Variable einsetzen.
- `CLAUDE.md` Stracke-Notes entfernen / als generisches Template
  formulieren.

### Phase 3 — Skeleton-Repo

- Neues Repo `Sanexio/cortex-public` anlegen.
- Generisches `Nexus/`-Snapshot (ohne Vault, USER.md-Template,
  devices.json-Template) committen.
- Onboarding-Doku schreiben.
- Erstem Test-Teilnehmer (Pilot) zur Verfügung stellen.

### Phase 4 — Lizenz + Compliance

- Lizenz-Wahl finalisieren.
- DSGVO-Hinweise für Teilnehmer-Macs.
- Telemetrie- und Update-Mechanismus.

### Phase 5 — Production

- Public Launch.
- Wartungs- und Update-Pipeline (Stracke kuratiert, Public-Repo aktualisiert).

## Querverweise

- Strategische Vision (Memory): `~/.claude/projects/-Users-ssmd-Cortex/memory/project_sanexio_cortex_business_model.md`.
- Audit-Befund F (Public-Skeleton-Mapping):
  `specs/architecture-refactor-2026-05/00_AUDIT.md` §F.
- Architecture-Refactor-Wellen: Priorität 1 (Commit `e4f36df`),
  Priorität 2 (Commit `708033c4`), Priorität 3 (in Arbeit).

## Offen

- Telegram-Bridge im Public-Modell: pro-Teilnehmer eigener Bot oder
  zentral?
- Connexio Multi-AI: dürfen Teilnehmer ihre eigene Codex-Instanz
  einbinden, oder ist Connexio-Bridge nur intern?
- Update-Pipeline: rolling? tagged? Snapshot-based?
- Pilot-Plan: welcher Mediziner zuerst, welche Mindest-Funktionalität
  für „MVP-Public"?

> Diese Datei ist ein Stub und wird beim Übergang zu Phase 2 ausgebaut.
> Inhaltliche Ergänzungen kommen aus den Sanexio-Geschäftsmodell-Sitzungen.
