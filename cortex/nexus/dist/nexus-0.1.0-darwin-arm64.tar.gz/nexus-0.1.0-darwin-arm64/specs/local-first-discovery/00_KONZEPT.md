# Local-First-Discovery — Konzept

> Status: **Implemented K1-K5 2026-05-13** (Bugs-Welle-Postmortem Dr. Stracke)
> Zweck: Anti-Drift-Architektur für Pfad-Annahmen. Verhindert, dass
> veraltete Memory-Geräte-Zuordnungen Claude zu redundanten Klonen,
> unnötigen SSH-Versuchen und falschen Push-Anweisungen führen.

---

## §0 Incident — was schiefgegangen ist (2026-05-13)

**Aufgabe:** Bugs-Welle (13 Drive-Bug-Reports auf der Praxis-Webseite
bearbeiten). Session lief auf `Cluster-Mini-02` (Home-Mac M2).

**Falsche Annahme:** Memory- und CLAUDE.md-Einträge sagten
*„SSMD-MacBookPro (praxis Intel): praxis-webseite, doc-workflow, Praxis-QM,
file-renamer, smartq-dashboard"*. Claude las das als „das praxis-webseite-
Repo lebt auf dem Intel-Mac und kann hier nicht direkt bearbeitet werden".

**Konsequenzen:**
1. `tailscale status` zeigte Intel-Mac offline → das schien die Annahme zu
   *bestätigen* („Intel-Mac unerreichbar, also gibt's hier kein Repo").
2. Repo redundant nach `~/Cortex/projects/praxis-webseite/` geklont.
3. Telegram-Push mit der falschen Story „Intel-Mac offline, bitte
   einschalten, dann auschecken und lokal testen".
4. User-Korrektur nötig: *„der Intel Mac hat mit diesem Projekt überhaupt
   nichts zu tun, totaler Schwachsinn"*.

**Was Claude übersehen hat:**
- Auf `Cluster-Mini-02` läuft seit Anfang Mai eine **Local-by-Flywheel-Site**
  `gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604.local` mit dem aktiven
  Theme `praxiszentrum`. Der Theme-Ordner ist bereits ein **Git-Checkout
  desselben Repos** `Sanexio/praxiszentrum-theme`.
- Drei Signale waren lokal greifbar, bevor SSH probiert wurde:
  - `~/Library/Application Support/Local/sites.json`
  - `~/Local Sites/<site>/app/public/wp-content/themes/praxiszentrum/`
  - `lsof -nP -iTCP -sTCP:LISTEN` zeigt nginx auf Port 10003 (Local).
- Diese Signale wurden erst nach der User-Korrektur erkannt.

---

## §1 Leitprinzipien

1. **Local-First.** Bevor remote SSH/Tailscale geprüft wird oder ein Repo
   geklont wird, scannt Claude die lokale Maschine auf bestehende Working-
   Copies des gesuchten Repos.
2. **Memory ist nicht autoritativ für Pfade.** Geräte- und Pfad-Aussagen
   im Memory haben TTL/Decay. Bei Pfad-relevanten Entscheidungen wird
   verifiziert, nicht zitiert.
3. **Single Source of Truth für Geräte-Zuordnung:** `Nexus/.config/devices.json`
   führt eine `projects:`-Liste pro Gerät. CLAUDE.md verweist auf diese
   Datei und zitiert sie NICHT als Hardcoded-Tabelle.
4. **Korrektur ist Pflicht-Memo.** Wenn ein Memory-Eintrag falsch sich
   erweist, schreibt Claude eine `_archive/auto-memory/`-Korrektur, kein
   stilles Überschreiben.

---

## §2 Pflicht-Discovery-Reihenfolge

Wenn Claude in einer Session den Pfad zu einem Projekt-Repo benötigt:

| Stufe | Quelle | Beispiel |
|-------|--------|----------|
| 1 | Aktuelle Working Directory (`pwd`) — passt sie schon? | `cd ~/Cortex && pwd` |
| 2 | `~/Cortex/projects/<projekt>/` existiert? | `ls ~/Cortex/projects/` |
| 3 | Local-by-Flywheel: `~/Library/Application Support/Local/sites.json` | siehe §3 |
| 4 | Andere lokale WP-Setups (MAMP, Docker, wp-env) | `ls /Applications/MAMP /Users/*/Sites` |
| 5 | `Nexus/.config/devices.json` (welcher Mac hat das Repo) | siehe §4 |
| 6 | GitHub direkt klonen (Fallback, wenn 1–5 alle Null) | `gh repo clone <org>/<repo>` |
| 7 | Tailscale-SSH zu einem anderen Mac | nur wenn 6 nicht passt |

**Stufe 7 ist die letzte Option, nicht die erste.** Auch bei einem Memory-
Hinweis „Repo liegt auf Mac X" wird zuerst Stufe 1–4 lokal gemacht.

---

## §3 Local-Flywheel-Site-Discovery (konkret)

```bash
# 1. Ist Local installiert?
ls ~/Library/Application\ Support/Local/sites.json 2>/dev/null

# 2. Welche Sites?
python3 -c "
import json, pathlib
p = pathlib.Path.home() / 'Library/Application Support/Local/sites.json'
data = json.loads(p.read_text())
for sid, s in data.items():
    print(f\"{s['name']}\\t{s['domain']}\\t{s['path']}\")
"

# 3. Für jede Site: gibt es einen Theme-Ordner, der Working-Copy des
#    gesuchten Repos ist?
for SITE in ~/Local\ Sites/*/; do
  for THEME in "$SITE"app/public/wp-content/themes/*/; do
    if [ -d "$THEME/.git" ]; then
      REMOTE=$(cd "$THEME" && git remote get-url origin 2>/dev/null)
      echo "$THEME -> $REMOTE"
    fi
  done
done
```

Diese drei Befehle sind verpflichtend, **bevor** ein WordPress-Theme-Repo
neu geklont wird.

---

## §4 `devices.json` — Projekt-Mapping

Aktueller Stand: `Nexus/.config/devices.json` listet Hostnames, aber keine
**Projekt-Spalte**. Die Geräte-Tabelle in CLAUDE.md führt Projekte hart-
codiert. **Drift-Quelle.**

**Vorschlag:** `devices.json` um eine `projects`-Liste je Gerät erweitern,
zusammen mit dem Stand des letzten Pulls/Edits.

```json
{
  "cluster-mini-02": {
    "role": "home (M2)",
    "tailscale_ip": "100.127.125.48",
    "projects": [
      {"name": "Cortex-Web", "path": "~/Cortex/projects/Cortex-Web", "primary": true},
      {"name": "Juvantis", "path": "~/Cortex/projects/Juvantis", "primary": true},
      {"name": "telegram-bridge", "path": "~/Cortex/projects/telegram-bridge", "primary": true},
      {"name": "praxis-webseite (theme: Sanexio/praxiszentrum-theme)",
       "path": "~/Local Sites/gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604/app/public/wp-content/themes/praxiszentrum",
       "primary": true,
       "host": "Local-Flywheel",
       "site_url": "https://gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604.local"}
    ],
    "last_updated": "2026-05-13"
  },
  "ssmd-macbookpro-intel": {
    "role": "praxis (Intel)",
    "tailscale_ip": "100.115.230.94",
    "projects": [
      {"name": "doc-workflow", "primary": true},
      {"name": "Praxis-QM", "primary": true},
      {"name": "file-renamer", "primary": true},
      {"name": "smartq-dashboard", "primary": true}
    ],
    "last_updated": "2026-05-13",
    "explicit_not_primary": ["praxis-webseite"]
  }
}
```

Die `explicit_not_primary`-Liste ist wichtig: sie verhindert Pattern-
Matching-Fehler („alles, was nach 'praxis' klingt, gehört auf Intel-Mac").

**CLAUDE.md ändert sich entsprechend:** statt Geräte-Tabelle mit Projekten
nur noch *„Geräte-Zuordnung: siehe `Nexus/.config/devices.json`. Pflicht-
Verifikation der `projects`-Liste bevor Pfad-Annahmen getroffen werden."*

---

## §5 Memory-Decay-Regel für Geräte-Facts

User-Memory-Einträge mit `type: project` haben bereits eine TTL (im
auto-memory-System sichtbar via `_archive/auto-memory/`). Pflicht-Erweiterung
für Pfad-Aussagen:

- Jede Memory-Notiz, die einen Pfad oder Geräte-Standort eines Repos
  behauptet, hat **TTL 14 Tage** mit Pflicht-Reverifikation.
- Bei Reverifikation: §2-Discovery laufen lassen. Bei Diskrepanz: alten
  Eintrag nach `_archive/auto-memory/<monat>/...md` archivieren und neuen
  schreiben — kein stilles Überschreiben.

---

## §6 Akzeptanzkriterien

1. ✅ `Nexus/.config/devices.json` enthält eine `projects:`-Liste je Gerät
   mit dem aktuellen Stand für mindestens `cluster-mini-02` und
   `ssmd-macbookpro-intel`.
2. ✅ `CLAUDE.md` global verweist auf `devices.json` und enthält keine
   hartcodierte Projekt-Tabelle mehr.
3. ✅ `Cortex/CLAUDE.md` (Projekt-Hub) ebenso aktualisiert.
4. ✅ Memory-Korrektur-Eintrag `reference_praxis_local_staging.md` ist
   geschrieben, alter Eintrag falls vorhanden archiviert.
5. ✅ Folge-Welle: §3-Discovery in den Cortex-Mode-Hook injizieren — bei
   Erwähnung „klone Repo X" prüft der Hook proaktiv §2-Stufen 1–4.

Codex-Implementierung 2026-05-13:

- `Nexus/.config/devices.json` fuehrt `projects` als strukturierte Liste mit
  `name`, `path`, `primary`, `host` fuer alle vier aktiven Geraete.
- `Cluster-Mini-02` enthaelt den Local-Flywheel-Theme-Pfad fuer
  `praxis-webseite` als primaere Working-Copy.
- `SSMD-MacBookPro` enthaelt `explicit_not_primary: ["praxis-webseite"]`.
- `tools/cortex-mode/bin/inject.sh` ruft
  `tools/cortex-mode/bin/local_first_discovery.py` auf. Der Helper scannt
  Local-by-Flywheel `sites.json`, Theme-Working-Copies und lokale
  `~/Cortex/projects`-Repos fuer clone-/repo-/theme-relevante Prompts.

---

## §7 Out-of-Scope (für diese Welle)

- Automatischer `devices.json`-Sync zwischen Macs (Welle: Cortex-Lean-V3-
  Folge-Spec).
- Vollständige Memory-TTL-Engine — der manuelle Archiv-Workflow reicht
  vorerst (Welle: Memory-V2).

---

## §8 Anweisung an Claude — operativ

1. Vor `git clone <repo>` immer §2 Stufen 1–4 ausführen.
2. Bei Bash-Operationen, die einen Projekt-Pfad referenzieren, NIE einen
   Pfad aus Memory blind übernehmen ohne `ls` / `git rev-parse` darauf.
3. Wenn ein Tailscale-Mac offline ist und ein Repo dort vermutet wird:
   das ist **kein Grund**, das Repo neu zu klonen, sondern ein Grund,
   Stufe 1–4 erneut zu prüfen.
4. Bei Drive/Browser-Bug-Reports gegen eine Live-Site: zuerst lokale
   Test-URL identifizieren (Local-Flywheel-sites.json), Branch dort
   auschecken, dann mit User-Abnahme arbeiten.
5. Memory-Eintrag, der widerlegt wurde, wird archiviert (nicht überschrieben)
   plus Neueintrag mit Reverifikations-Datum.
