# Local-First-Discovery Changelog

## 2026-05-13 — Codex K1/K5 Implementation

Task: `task-6f35b451a33a`

Implemented:

- `Nexus/.config/devices.json` now contains structured `projects` entries for
  all four active devices.
- `Cluster-Mini-02` explicitly lists the Local-by-Flywheel
  `praxis-webseite` theme checkout as the primary working copy for
  `Sanexio/praxiszentrum-theme`.
- `SSMD-MacBookPro` has `explicit_not_primary: ["praxis-webseite"]` as an
  anti-drift marker.
- `tools/cortex-mode/bin/local_first_discovery.py` scans Local-by-Flywheel
  `sites.json`, git theme working copies and local `~/Cortex/projects` repos.
- `tools/cortex-mode/bin/inject.sh` appends the helper output to
  `additionalContext` only for repo-/clone-/WordPress-/theme-sensitive prompts.

Verification:

- `python3 -m json.tool .config/devices.json`
- `python3 -m compileall tools/cortex-mode/bin/local_first_discovery.py`
- Hook smoke with a clone/theme prompt and a fake Local-by-Flywheel HOME.
