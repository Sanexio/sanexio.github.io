# HANDOFF an Codex — Cortex Lean v3 Umbau

> **Wenn Dr. Stracke sagt: „Schau dir die Übergabe in Connexio an" — diese Datei ist gemeint.**
>
> Versionsstand: 2026-05-13, Übergabe-Sender: Claude (cluster-mini-02).
> Empfaenger: Codex (vermutlich praxis-mac oder M5).
> Komplette Spec: `Nexus/specs/cortex-lean-v3/00_KONZEPT.md`.

---

## 0. Pre-Flight (vor jedem Bearbeitungsschritt)

```bash
cd ~/Cortex/Nexus
git pull --ff-only                    # State-First: aktuellen Stand holen
git status -sb                        # nichts darf dirty sein
hostname                              # fuer Lease-Eintrag
```

Wenn Connexio-MCP auf deinem Mac registriert ist (siehe §1):

```python
# Pre-Flight Lease-Check (verhindert Race mit Claude)
get_active_leases(repo="Sanexio/nexus", scope="cortex-lean-v3-l2")
# → wenn aktive Lease vorhanden: STOP, in Outbox melden
lease_project(repo="Sanexio/nexus", scope="cortex-lean-v3-l2",
              machine="<hostname>", agent="codex", ttl_seconds=10800)  # 3h
```

Wenn Connexio-MCP NICHT registriert ist: §1 zuerst erledigen, sonst kein
Lease-Schutz. Keine parallel laufenden Claude-Sessions am gleichen Repo.

## 1. Connexio-MCP in deine Codex-Config eintragen (R3 — User-Pflicht!)

Aktuelle Codex-Config auf M5 (`~/.codex/config.toml`) hat nur `blender-mcp`.
Connexio fehlt. **Diesen Edit darf nur Dr. Stracke machen** (Tier-3
Secret-Pfad).

Zeile, die Dr. Stracke in `~/.codex/config.toml` ergaenzen muss:

```toml
[mcp_servers.connexio]
command = "/Users/ssmd/Cortex/Nexus/.venv/bin/python"
args = ["-m", "agent.connexio.mcp_server"]
env = { CONNEXIO_AGENT_ID = "codex" }
```

(`CONNEXIO_AGENT_ID` ist eine Konvention fuer §3 unten — Codex weiss,
welcher Agent er gegenueber Connexio ist.)

## 2. Was du umsetzen sollst — Auftrags-Pakete

Volle Spec mit Begruendung: `Nexus/specs/cortex-lean-v3/00_KONZEPT.md`.
Hier die TL;DR Auftrags-Pakete:

### Paket A — Pflicht-Lesung halbieren (§7.5)

- `_rules/ai-cooperation.md` und `_rules/multi-ai-boundaries.md` als
  Kapitel 11+12 in `_rules/AUTONOMY_CONTRACT.md` integrieren.
- Beide Original-Files durch 5-Zeilen-Pointer-Stub ersetzen, der auf das
  Kapitel im Vertrag verweist.
- `Nexus/CLAUDE.md` Pflicht-Lesung-Block: nur `CLAUDE.md` + `AUTONOMY_CONTRACT.md`.

### Paket B — Cortex-Web SESSION_RESUME splitten (§7.6)

- Aktuell: 430 LOC.
- Ziel: ≤80 LOC + Cold-Archive `_archive/sessions/2026-05/sessions-S31-S55.md`.
- Behalten: §0a Pflicht-Lesung, §1 (HEAD-Status, max. 3 Wellen tief),
  §1.1 Phasen-Status-Tabelle, §5 Sofort-Status-Frage, §6 Verbote.
- Auslagern: §1.0 Sessions-S43-S54-Index, §1.2, §3-legacy, §7
  (Archiv-Index).

### Paket C — Sanitizer um TTL-Memory (§7.2)

`agent/skills/builtin/sanitizer.py`:

- Neuer Op `_archive_stale_memories(dry_run, ttl_overrides)`:
  - Scant `~/.claude/projects/-Users-cluster-mini-02-Cortex/memory/*.md`
    (Pfad ist host-spezifisch, also via `Path.home()` + Hostname-Detection,
    siehe §5).
  - Parst YAML-Frontmatter, liest `type` und `ttl_days` (oder Default-TTL
    pro Typ: project=14, feedback=180, reference=365, user=∞).
  - Eintraege mit `now - mtime > ttl_days` nach `_archive/auto-memory/<YYYY-MM>/`
    verschieben.
  - MEMORY.md-Index entsprechend bereinigen (Eintrag entfernen, Pointer
    auf Archiv-Pfad).
- Tabelle in der Sanitizer-Output-Section.
- Smoke-Test mit kuenstlich auf TTL=0 gesetztem Eintrag.

### Paket D — Doctor `--strict` (§7.3)

`agent/skills/builtin/doctor.py`:

- `--strict`-Flag: failed Check → exit-code 1 (statt nur informational).
- Neuer Check `_check_lease_consistency`: expired Leases, die noch active
  markiert sind (sollte nach `cleanup_expired_leases` immer 0 sein).

### Paket E — PHOENIX_RESUME als Live-View (§7.4)

`agent/connexio/roadmap.py` (neu):

- `render_roadmap()` — liest `tasks.db` + `_rules/`-Spec-Files,
  generiert Markdown-Tabelle pro Welle/Sprint.

`PHOENIX_RESUME.md`:

- Behaelt nur Pre-/Post-Roadmap-Block (Stand + Trigger-Befehl).
- §4 (Sprint-Status) wird durch ein Skript-Generated-Block ersetzt.

### Paket F — Outbox-Migration starten (§7.7)

- `projects/_ai-cooperation-outbox/README.md`: Deprecation-Hinweis ab
  2026-05-13, Loesch-Vorschlag fuer 2026-06-12.

### Paket G (NEU — von Claude entdeckt 2026-05-13) — Cross-Device-Task-Sync

**Problem:** `_memory/tasks.db` und `_memory/leases.db` sind gitignored.
Heisst: ein Task auf cluster-mini-02 ist auf M5 NICHT sichtbar. Damit
faellt die ganze Bridge in §3 S3 zusammen, sobald mehrere Macs im Spiel
sind.

**Loesungs-Vorschlag (zur Diskussion mit Dr. Stracke):**

1. **JSON-Mirror der tasks.db ins Repo:** Sanitizer / Cron exportiert
   `_memory/tasks.db` → `_memory/tasks-mirror/<task-id>.json` (gitignore
   Whitelist), commit + push pro Aenderung. Andere Macs ziehen via Pull,
   importieren zurueck in lokale DB.
2. **Connexio als HTTP-Service auf einem Master-Mac (cluster-mini-02):**
   andere Macs erreichen ueber Tailnet `http://cluster-mini-02:7766/...`.
   Read-Only fuer Codex bleibt, Write geht ueber API.
3. **Single-DB via SSHFS / NFS:** zentrale DB-Datei auf cluster-mini-02,
   andere Macs mounten. Risk: SQLite + Network-Filesystem ist heikel.

Entscheidung in Welle L2 mit Dr. Stracke. Bis dahin: **Tasks immer
zusaetzlich als Markdown-File im Repo committen** (so wie diese
HANDOFF-CODEX.md). DB ist nice-to-have, Repo ist Pflicht.

## 3. Acceptance-Criteria (verifizierbar)

1. `lease_project + release_lease + get_active_leases` funktionieren von
   Codex-Mac aus (per MCP-Smoke-Test im Codex-Repl).
2. `inbox_for_agent("codex")` liefert mindestens diesen Task —
   beachte §0G: nach Code-Pull muss der Task auch lokal in tasks.db landen.
3. `Sanitizer --strict` archiviert mindestens einen kuenstlich auf TTL=0
   gesetzten Test-Memory-Eintrag.
4. `doctor --strict` failt sauber bei kuenstlich erzeugtem Drift-Hit.
5. `Nexus/CLAUDE.md` Pflicht-Lesung-Block hat max. 2 Pointer.
6. `Cortex-Web/SESSION_RESUME.md` hat max. 80 LOC.
7. Welle in EINEM Commit pro Datei-Gruppe (Connexio | Sanitizer |
   Doctor | Pflicht-Lesung | Cortex-Web | Cross-Device-Sync), nicht ein
   Mega-Commit.
8. `git diff --stat` der Welle ≤ 1500 LOC (Schlankheits-Disziplin gilt
   fuer den Umbau selbst).

## 4. Was du NICHT machen sollst

- Keine Aenderung an `agent/cron/runner.py` (separate R2-Welle).
- Keine Loeschung von `_archive/`-Inhalten.
- Keine Aenderung an Telegram-V3-Gateway.
- Keine Aenderung an `_memory/USER.md` oder `_memory/KNOWLEDGE.md`.
- Keine R3-Operationen (Secrets, Cron, externe Empfaenger). Codex-MCP-Config
  in `~/.codex/config.toml` muss Dr. Stracke selbst editieren.

## 5. Decision-Log fuer Dr. Stracke (vor L2-Start)

Diese Punkte brauchen explizite Stracke-Freigabe:

1. **TTL-Defaults** — project=14d / feedback=180d / reference=365d /
   user=∞. Akzeptabel?
2. **AI_COOPERATION + MULTI_AI_BOUNDARIES in AUTONOMY_CONTRACT
   integrieren** — keine Inhalts-Aenderung, nur Konsolidierung.
   Akzeptabel?
3. **Outbox 30-Tage-Frist** vs. sofortiges Loeschen.
4. **Pflicht-Lesung 2 statt 4 Files**. Risiko: weniger Onboarding-Kontext.
5. **Cross-Device-Sync-Variante (§2-G)** — JSON-Mirror, HTTP-Service oder
   SSHFS?

## 6. Wenn du fertig bist

```python
# Status setzen
update_task_status(id="task-74331a710d43", status="review_requested",
                   note="Lean-v3 umgesetzt. Smoke-Tests passen. Review faellig.")

append_review(task_id="task-74331a710d43", reviewer="codex",
              verdict="needs_human_approval",
              notes="Acceptance-Criteria 1-8 erfuellt. Decision-Log §5 wartet.")

# Lease freigeben
release_lease(lease_id="<deine-lease-id>", agent="codex")
```

Plus: Telegram-Push an Dr. Stracke (Bot-Token im
`~/Cortex/Nexus/gateway/.env`, Chat-ID `8547497426`).

---

*HANDOFF v1 — 2026-05-13, geschrieben weil tasks.db nicht cross-device
synct (siehe Paket G). Markdown-File ist die zuverlaessige Brigde, bis
Paket G entschieden ist.*
