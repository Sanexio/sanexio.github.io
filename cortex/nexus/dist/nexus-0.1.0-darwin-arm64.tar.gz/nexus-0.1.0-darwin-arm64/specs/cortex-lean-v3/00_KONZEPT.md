# Cortex Lean v3 — Architektur-Reset gegen Drift, Redundanz und Memory-vs-State-Lücke

> Status: **Approval-pending** (Dr. Stracke 2026-05-13)
> Erstellt von: Claude (Cluster-Mini-02), zur Umsetzung an Codex.
> Vorgaengerkonzepte:
>   - `Nexus/specs/multi-device-multi-ai/00_KONZEPT.md`
>   - `Nexus/specs/claude-codex-cooperation/00_KONZEPT.md`

---

## 1. Anlass

Drei wiederholbare Fehler-Klassen sind in den letzten 5 Sessions aufgetreten:

### F1 — Memory ≠ State

**Symptom:** Empfehlungen basieren auf Memory-Notes (MEMORY.md, SESSION_RESUME),
die N Tage alt sind. Aktueller Code-/Git-/DB-Stand wird nicht verifiziert.
**Konkret 2026-05-13:** Praxis-Live-Push wurde als "fällig" gemeldet, war
aber bereits in einer Praxis-Mac-Session erledigt. Memory enthielt die alte
"local-only"-Notiz.

### F2 — KI-Race-Conditions

**Symptom:** Zwei KI-Sessions auf zwei Macs arbeiten parallel an demselben
Welle/Thema, ohne Lease oder Lock. Push-Konflikte.
**Konkret 2026-05-12:** Codex (Praxis-Mac) und Claude (Cluster-Mini-02)
haben Welle 2-B Cortex-Web parallel umgesetzt. Race-Resolution per
`git reset --hard` mit Verlust meiner Bonus-Inhalte.

### F3 — Doku-Overhead, der Erkenntnis verstellt

**Symptom:** 4–6 Pflicht-Lese-Files mit 200–600 Zeilen pro Session-Init.
PHOENIX_RESUME 320 LOC, Cortex-Web/SESSION_RESUME 430 LOC. KI verbringt
Token-Budget mit Doku-Lesen statt Aufgabe lösen. Wesentliches geht unter.

## 2. Ziele

- **Single Source of Truth = State**, nicht Memory.
- **Single-Bridge = Connexio**, nicht verteilte Markdown-Outboxes.
- **Lease-basierte Multi-Device-Ko-Ordination**, kein Best-Effort-Pull.
- **Pflicht-Lesungen halbiert**, Inhalte konsolidiert.
- **Memory mit Verfallsdatum**, automatisches Quarantining.

Nicht-Ziel: Hot-Reload aller bestehenden Dokumente. Migration ist
schrittweise (siehe §10 Roadmap).

## 3. Drei Saeulen

### S1 — State First, Memory Second

**Regel:** Bevor eine KI eine Empfehlung gibt oder eine Schreib-Aktion
plant, MUSS sie den Live-State der relevanten Quelle abfragen.

| Quelle           | State-Abfrage                                     |
|------------------|---------------------------------------------------|
| Git-Repo         | `git log -1`, `git status`, `git rev-list`        |
| Tailnet-Mac      | `ssh <mesh-name> 'git log -1 ...'`                |
| Datenbank        | `SELECT … FROM …`                                 |
| Live-Site        | `curl -sI`, `wget --spider`                       |
| Cron-State       | `cat _memory/cron-state.json`                     |

**Memory** ist NUR fuer Insights, Praeferenzen, Learnings, Konventionen —
also Wissen, das NICHT aus dem Live-State ableitbar ist.

**Konsequenz:** Memory-Eintraege wie "Welle 18 — local-only, kein Push"
sind anti-pattern. Push-Status gehoert in Git, nicht in Memory.

**Implementierungs-Hilfen:**
- Connexio liefert State-Abfrage-Helper: `connexio.get_repo_head(repo)`,
  `connexio.get_remote_diff(repo)`, `connexio.get_live_status(url)`.
- Memory-Reader markiert Eintraege mit `last_verified > 7 Tage` als
  ⚠️ STALE.

### S2 — One-Mac-At-A-Time per Lease

**Regel:** Vor Beginn einer R1/R2-Welle in einem Repo MUSS die KI eine
Lease in Connexio anfordern. Andere KIs sehen die Lease und stoppen.

**Lease-Schema:**

```
{
  "lease_id": "lse-...",
  "repo": "Sanexio/cortex-web" | "Sanexio/nexus" | ...,
  "scope": "welle-2-d-tier-r-migration",
  "machine": "cluster-mini-02",
  "agent": "claude" | "codex",
  "expires_at": "2026-05-13T08:00:00Z",   // default: now + 1h
  "renewable": true
}
```

**Hardcodierte Regeln:**
- Eine aktive Lease pro `(repo, scope)` zur gleichen Zeit.
- Lease laeuft automatisch nach `expires_at` aus (kein Lock-out bei
  toten Sessions).
- `release_lease` ist Pflicht am Welle-Ende.
- `get_active_leases` ist Pre-Flight-Pflicht vor Schreib-Aktionen.

**Konsequenz fuer F2-Race:** Codex haette `lease_project("cortex-web",
"welle-2-b-cleanup")` angefordert; Claude haette die Lease gesehen und
auf eine andere Welle geswitcht. Kein paralleles Arbeiten am selben Thema.

### S3 — Connexio als Single-Bridge

**Regel:** Alle KI-zu-KI-Kommunikation laeuft durch Connexio.
Markdown-Outbox ist deprecated (bleibt fuer 30 Tage als Read-Only-Archiv,
dann Loesch-Vorschlag).

**Connexio-Bridge-Surface (neu):**

| Tool                         | Zweck                                          |
|------------------------------|------------------------------------------------|
| `lease_project`              | Lease anfordern (siehe S2)                     |
| `release_lease`              | Lease freigeben                                |
| `get_active_leases`          | Pre-Flight, andere KIs sehen aktive Locks      |
| `handoff_to_agent`           | Direkter Auftrag an andere KI mit Spec-Pointer |
| `inbox_for_agent`            | Polling: hat eine andere KI mir einen Auftrag? |

`handoff_to_agent` ist im Wesentlichen ein `create_task` mit
`assigned_to=<other_agent>` + Notification-Marker, sodass die andere KI
beim naechsten `inbox_for_agent`-Poll Bescheid weiss.

**Konsequenz fuer F1+F2:** Anstelle von "schau in Outbox-File X" sagt
der User: "Schaue in Connexio: Claude hat eine Aufgabe fuer Dich!" Codex
ruft `inbox_for_agent("codex")` auf, bekommt Task-Pointer, liest Spec,
arbeitet ab, ruft `update_task_status` und `append_review` auf.

## 4. Schlankheits-Massnahmen

### M1 — Pflicht-Lesungen halbiert

**Heute (Phoenix-Stand 2026-05-12):** 4–6 Files je Session-Init.
**Ziel:** 2 Files: `Nexus/CLAUDE.md` (Haupt) + `Nexus/_rules/AUTONOMY_CONTRACT.md`
(R0–R3, State-First, Lease-Pflicht). Alles andere on-demand via Connexio.

`ai-cooperation.md` und `multi-ai-boundaries.md` werden in
`AUTONOMY_CONTRACT.md` integriert (= ein Vertrag, drei Kapitel).

### M2 — Memory mit Verfallsdatum

Jeder Memory-Eintrag bekommt:

```yaml
---
name: ...
type: feedback | user | project | reference
ttl_days: 14         # default fuer project, 365 fuer reference, infinite fuer user
last_verified: 2026-05-13
---
```

Memory-Reader markiert `now - last_verified > ttl_days` als STALE.
Memory-Sanitizer (Welle 4 vom 2026-05-12) bekommt Erweiterung:
TTL-abgelaufene Project-Memories nach `_archive/auto-memory/<YYYY-MM>/`.

**User-Memories und Reference-Memories** sind nicht von TTL betroffen.

### M3 — PHOENIX_RESUME als Live-View, nicht Markdown

PHOENIX_RESUME ist heute 320 LOC handgepflegtes Markdown. Stattdessen:

- Roadmap-Stand wird aus Connexio-Task-Store gerendert
  (`connexio.render_roadmap()` → Markdown-Tabelle).
- Statisches Vorwort (max. 50 LOC) bleibt im Repo, generierter Teil ist
  on-demand.

### M4 — Cortex-Web SESSION_RESUME aufteilen

430-LOC-Datei wird in:
- `Cortex-Web/SESSION_RESUME.md` (≤ 80 LOC, aktueller Stand + Pointers)
- `Cortex-Web/_archive/sessions/<YYYY-MM>/` (alle Sprint-Detail-Bloecke)

LL-053 Anti-Bloat war konzeptuell schon richtig — wird konsequent
durchgezogen.

### M5 — Doku-Drift-Detector zur Pflicht

Doctor-Skill hat bereits `_check_drift` (Welle 4). Neu:
- `cortex-agent skill run doctor --strict` blockt Welle-Ende, wenn
  Drift-Score > 0.
- Pre-Commit-Hook prueft Drift in geaenderten Pflicht-Files.

## 5. Sicherheits-Massnahmen

### Sec1 — Pull-Pflicht vor Edit

Jede Schreib-Aktion in einem getrackten Repo (`Sanexio/nexus`,
`Sanexio/cortex-web`, etc.) startet mit:

```bash
git pull --ff-only && [ "$(git status --porcelain)" = "" ] || STOP
```

Bereits in `nexus-sync.sh` Welle-3-Logik teilweise drin. Wird zur Pflicht
fuer ALLE Schreibaktionen, nicht nur Auto-Sync.

### Sec2 — Lease-Check vor Edit

Erweiterung von Sec1: vor Schreib-Aktion `get_active_leases(repo, scope)`
abfragen. Wenn aktive Lease von anderem Agent: STOP, Outbox-Vorschlag.

### Sec3 — State-Validation vor Empfehlung

Bevor eine KI behauptet "X ist faellig" / "Y ist offen" / "Z ist
unverify", muss sie den State der genannten Sache verifiziert haben
(Sec1+Sec2 sind die Schreib-Schutzpfade; das hier ist die Lese-Pflicht).

Implementiert als Selbst-Check-Regel im Mode-Hook. Verbotene Phrase:
"laut Memory ist …" (ohne Verifikations-Beweis).

### Sec4 — Tier-3 in der Datenbank festhalten

Bisher: Tier-3 ist nur im Mode-Hook injiziert. Neu: hardcoded
`forbidden_paths_global`-Liste in `task_store.py`, die jeder Task
implizit erbt:

- `~/.claude.json`
- `**/.env`, `**/.env.*`
- `~/.ssh/`, `~/.gnupg/`
- jede Datei mit `secret`, `token`, `password`, `api_key` im Pfadnamen

`create_task` rejectet Tasks, die diese Pfade in `allowed_paths` listen.

## 6. Migration des Codex-Outbox-Pfads

Das `projects/_ai-cooperation-outbox/`-Verzeichnis bleibt 30 Tage als
Read-Only-Referenz. Neue Vorschlaege gehen ueber `handoff_to_agent` in
Connexio. Nach 30 Tagen wird das Verzeichnis nach `_archive/` verschoben.

## 7. Konkrete Code-Aenderungen (fuer Codex)

Diese Welle soll Codex umsetzen:

### 7.1 Connexio Lease-/Handoff-Surface

Datei: `agent/connexio/lease_store.py` (neu)
- SQLite-Tabelle `leases` mit `lease_id, repo, scope, machine, agent,
  acquired_at, expires_at, released_at`.
- Funktionen: `acquire_lease`, `release_lease`, `get_active_leases`,
  `cleanup_expired_leases` (per Cron).
- Audit-Log in `_memory/audit/connexio-lease.jsonl`.

Datei: `agent/connexio/mcp_server.py` (erweitern)
- `+lease_project`, `+release_lease`, `+get_active_leases`
- `+handoff_to_agent` (= `create_task` mit `assigned_to=...` plus
  Notification-Marker)
- `+inbox_for_agent` (read-only: offene Tasks fuer mich)

Datei: `agent/connexio/task_store.py` (erweitern)
- `inbox_for_agent(agent_id)`: liefert Tasks mit
  `assigned_to=agent_id AND status IN (proposed, accepted, in_progress)`
- `forbidden_paths_global`-Konstante + Validation in `create_task`

### 7.2 Sanitizer-Erweiterung um TTL-Memory

Datei: `agent/skills/builtin/sanitizer.py` (erweitern)
- Neuer Op: `_archive_stale_memories` — scant
  `~/.claude/projects/.../memory/*.md`, parst Frontmatter,
  archiviert Eintraege mit abgelaufenem TTL nach
  `_archive/auto-memory/<YYYY-MM>/`. Default-TTLs: project=14, reference=365,
  user=infinite, feedback=180.
- MEMORY.md-Index entsprechend bereinigen (Eintrag entfernen, Pointer
  auf Archiv setzen).
- Tabelle in der Sanitizer-Output-Section.

### 7.3 Doctor-Strict-Mode

Datei: `agent/skills/builtin/doctor.py` (erweitern)
- `--strict`-Flag: failed Check ist nicht nur informational, sondern
  exit-code 1.
- Neuer Check: `_check_lease_consistency` — sind expired Leases noch
  active markiert?

### 7.4 PHOENIX_RESUME als Live-View

Datei: `agent/connexio/roadmap.py` (neu)
- `render_roadmap()`: liest `tasks.db` + `_rules/`-Spec-Files,
  generiert Markdown-Tabelle pro Welle/Sprint.

Datei: `PHOENIX_RESUME.md` (kuerzen)
- Behaelt nur §1 (Stand) + §3 (Trigger-Befehl). §4 (Sprint-Status)
  wird durch Generator ersetzt.

### 7.5 Pflicht-Lesung konsolidieren

Datei: `_rules/AUTONOMY_CONTRACT.md` (erweitern)
- Integriert Inhalt von `ai-cooperation.md` und `multi-ai-boundaries.md`
  als Kapitel 11 + 12.

Dateien: `ai-cooperation.md`, `multi-ai-boundaries.md` (loeschen, durch
Pointer-Stub ersetzen, der auf Kapitel im AUTONOMY_CONTRACT verweist).

Datei: `Nexus/CLAUDE.md` (Pflicht-Lesung-Block kuerzen)
- Pflicht-Files: nur `CLAUDE.md` + `AUTONOMY_CONTRACT.md`.

### 7.6 Cortex-Web SESSION_RESUME splitten

Datei: `projects/Cortex-Web/SESSION_RESUME.md` (kuerzen)
- Auf max. 80 LOC: aktueller Stand + Pointer auf Cold-Archive.
- Sprint-Detail-Bloecke S31–S55 nach `_archive/sessions/2026-05/`
  ausgliedern.

### 7.7 Outbox-Migration starten

Datei: `projects/_ai-cooperation-outbox/README.md` (Update)
- Hinweis: deprecated ab 2026-05-13, neue Vorschlaege via
  Connexio-`handoff_to_agent`.
- Erinnerung: Loesch-Vorschlag nach 30 Tagen.

### 7.8 (NEU) Cross-Device-Task-Sync — Bridge funktioniert sonst nicht

**Problem entdeckt 2026-05-13 nach L1.1-Lieferung:** `_memory/tasks.db`
und `_memory/leases.db` sind gitignored. Tasks auf Cluster-Mini-02 sind
auf M5/Praxis-Mac NICHT sichtbar. `inbox_for_agent("codex")` auf M5
liefert leeres Array, obwohl Claude einen Task fuer Codex angelegt hat.

**Damit faellt Saeule S3 (Connexio als Single-Bridge) zusammen, sobald
mehrere Macs im Spiel sind.**

**Drei Loesungs-Pfade fuer Dr.-Stracke-Entscheidung in L2:**

| Variante | Vorteil | Nachteil |
|---|---|---|
| A) JSON-Mirror der tasks.db ins Repo | Single Source of Truth = Git, simpel, Konflikt-Resolution per Diff | jeder Task-Write triggert Commit + Push, mehr Sync-Last |
| B) Connexio als HTTP-Service auf cluster-mini-02 (Master) | Single Source of Truth = laufender Service, einfache Reads | Verfuegbarkeit haengt am Master-Mac (offline = blind), HTTP-Auth-Komplexitaet |
| C) SQLite via SSHFS/NFS-Mount | DB-Layer transparent | SQLite + Netzwerk-FS ist seit Jahren als unzuverlaessig dokumentiert |

**Vorlaeufig (bis Entscheidung):** Tasks immer ZUSAETZLICH als
Markdown-File im Repo committen (Beispiel:
`Nexus/specs/cortex-lean-v3/HANDOFF-CODEX.md`). Die DB ist
nice-to-have, das Markdown ist Pflicht. Damit funktioniert der
„Schau in Connexio"-Workflow auch ohne MCP-Connectivity, indem Codex
nach `git pull` per `cat` liest.

Empfehlung Claude: **Variante A (JSON-Mirror)** — passt zur Saeule S1
(State-First, Git als Wahrheit) und braucht keine Service-Verfuegbarkeit.
Implementierung: Sanitizer-Hook bei tasks/leases-Write triggert
JSON-Export → `_memory/tasks-mirror/<id>.json` (whitelisted im
.gitignore) → automatischer Commit ueber existierenden Auto-Sync.

## 8. Acceptance-Criteria fuer Codex-Welle

1. `connexio.lease_project("test", "smoke")` funktioniert von Codex aus
   (per MCP).
2. `inbox_for_agent("codex")` liefert mindestens den Uebergabe-Task,
   den Claude angelegt hat.
3. Doctor `--strict` failt sauber bei kuenstlich erzeugtem Drift-Hit.
4. Sanitizer-Run archiviert mindestens einen kuenstlich auf TTL=0
   gesetzten Test-Memory-Eintrag.
5. `Nexus/CLAUDE.md` Pflicht-Lesung-Block hat max. 2 Pointer.
6. `Cortex-Web/SESSION_RESUME.md` hat max. 80 LOC.
7. `git diff --stat` der Welle ≤ 1500 LOC (Schlankheits-Disziplin
   gilt fuer den Umbau selbst).
8. Welle in EINEM Commit pro Datei-Gruppe (Connexio | Sanitizer |
   Doctor | Pflicht-Lesung | Cortex-Web), nicht ein Mega-Commit.

## 9. Was Codex NICHT machen soll

- Keine Aenderung an `agent/cron/runner.py` (separate R2-Welle).
- Keine Loeschung von `_archive/`-Inhalten.
- Keine Aenderung an Telegram-V3-Gateway.
- Keine Aenderung an USER.md / KNOWLEDGE.md.
- Keine R3-Operationen (Secrets, Cron, externe Empfaenger).

## 10. Roadmap

| Welle  | Inhalt                                                      | Owner    | Status |
|--------|-------------------------------------------------------------|----------|--------|
| L1     | Konzept-Approval (diese Datei)                              | Stracke  | ✅ 2026-05-13 |
| L1.1   | Bridge-Tools (Lease + Inbox + Handoff)                      | Claude   | ✅ 2026-05-13 |
| L1.2   | Codex-Handoff (Task `task-74331a710d43`)                    | Claude   | ✅ 2026-05-13 |
| L2     | Codex-Welle: §7.1–7.8 umsetzen                              | Codex    | ✅ 2026-05-13 (Pakete A/C/D/E/G + Bugfix gepusht) |
| L2-B   | Cortex-Web SESSION_RESUME ≤80 LOC (Codex-Selbst-Escape)     | Claude   | ✅ 2026-05-13 (67 LOC + Cold-Archive) |
| L3     | Live-Smoke: Lease-Test cluster-mini-02 ↔ praxis-mac          | Claude   | ✅ 2026-05-13 (lease_store mit JSON-Mirror analog task_store; Smoke roundtrip + simulierter Cross-Device-Import durchgespielt; Live-Test mit M5 in nächster Praxis-Mac-Session möglich) |
| L4     | Memory-TTL-Migration: bestehende Memories taggen             | Claude   | ✅ 2026-05-13 (cluster-mini-02 — 63 Memories scanned, 1 archiviert; pro Mac zu wiederholen, weil Memory lokal ist) |
| L5     | Outbox 30-Tage-Frist abwarten, dann Loeschen                 | beide    | ✅ 2026-05-28 (Outbox-Verzeichnis bereits entfernt; kein Lösch-Bedarf mehr) |
| L6     | Doku-Sweep: alte LL-Codes komplett durch R0–R3 ersetzen      | Claude   | ✅ 2026-05-13 (golden_rules.py von ~1500 auf ~365 Tokens reduziert, 12 LL-Codes → 0 in aktiver Steuerlogik; Mapping-Tabelle als Querreferenz behalten; safe.md + inject.sh + CLAUDE.md LL-Verweise weg) |

## 11. Decision-Log fuer Dr. Stracke

Diese Punkte brauchen explizite Stracke-Freigabe vor L2-Start:

1. **TTL-Defaults** — project=14d / feedback=180d / reference=365d /
   user=infinite. Akzeptabel?
2. **AI_COOPERATION + MULTI_AI_BOUNDARIES in AUTONOMY_CONTRACT
   integrieren** — keine Inhalts-Aenderung, nur Konsolidierung.
   Akzeptabel?
3. **Outbox 30-Tage-Frist** vs. sofortiges Loeschen. Vorschlag: 30 Tage
   wegen Codex-Lese-Gewohnheit.
4. **Pflicht-Lesung 2 statt 4 Files** — Risiko: weniger Onboarding-
   Kontext. Mitigations: Connexio liefert on-demand.

---

*Konzept v1 — 2026-05-13. Geschrieben in Cluster-Mini-02-Session als
Reaktion auf 3 Fehler-Klassen (Memory≠State, KI-Race, Doku-Overhead).
Uebergabe-Task an Codex liegt im Connexio-Task-Store unter
`assigned_to=codex` (Tool-Aufruf: `inbox_for_agent("codex")`).*
