# Drift-Cleanup Audit — Phoenix / AI-Cooperation

Erstellt: 2026-05-12
Status: Audit-Datei, noch kein Cleanup der bestehenden Drift-Treffer
Scope: Cortex/Nexus-Dokumentationsdrift nach Phoenix-Reset und vor
Claude-Codex-Kooperationsmodell

---

## 1. Kurzfazit

Der Drift ist real und sollte in einer eigenen Cleanup-Welle behoben werden.
Die kritischste Datei ist `Nexus/SYSTEM_MAP.md`, weil sie als Wegweiser
mehrere nicht mehr existierende Pfade nennt. `Cortex/AGENTS.md` ist ebenfalls
veraltet und verweist auf `Nexus/AGENTS.md`, das lokal nicht existiert.
`Cortex/CLAUDE.md` ist dagegen bereits korrekt und verweist auf
`Nexus/CLAUDE.md`.

Dieser Audit ist bewusst noch kein Cleanup. Er dokumentiert zuerst, was
gefunden wurde, damit der spaetere Fix in einem zusammenhaengenden Commit
erfolgen kann.

## 2. Verifizierte Existenzpruefung

Nicht vorhanden:

- `Nexus/AGENTS.md`
- `Nexus/_rules/INDEX.md`
- `Nexus/_rules/GLOBAL_RULES.md`
- `Nexus/_rules/SESSION_LIFECYCLE.md`
- `Nexus/_rules/MEMORY_LAYERS.md`
- `Nexus/_rules/FEHLERPROTOKOLL.md`
- `Nexus/_memory/MEMORY.md`
- `Nexus/_memory/patterns/`
- `Nexus/_skripte/cortex-cron/`

Vorhanden und aktuell relevant:

- `Nexus/CLAUDE.md`
- `Nexus/SYSTEM_MAP.md`
- `Nexus/_rules/multi-ai-boundaries.md`
- `Nexus/_rules/ai-cooperation.md`
- `Nexus/_rules/AUTONOMY_CONTRACT.md`
- `Nexus/agent/modes/autonomy.md`
- `Nexus/agent/modes/safe.md`
- `Nexus/agent/modes/tier3.md`
- `Nexus/agent/cron/`
- `Nexus/agent/memory/`
- `Nexus/agent/connexio/`
- `Nexus/gateway/`
- `Nexus/Second Brain/`

## 3. Echte Drift-Treffer mit hoher Prioritaet

### 3.1 `Cortex/AGENTS.md`

Problem:

- Verweist auf `Nexus/AGENTS.md` als Hauptsteuerung.
- `Nexus/AGENTS.md` existiert nicht.

Soll:

- Auf `Nexus/CLAUDE.md` verweisen.
- Optional Hinweis ergaenzen, dass Codex fuer Nexus-Kern-Aenderungen
  `Nexus/_rules/ai-cooperation.md` und `Nexus/_rules/AUTONOMY_CONTRACT.md`
  beachten soll.

### 3.2 `Nexus/SYSTEM_MAP.md`

Problem:

- Nennt in "Wo finde ich was?" mehrere nicht existierende Pfade.
- Nennt alte LL-/Tier-Struktur als aktuelle Top-Regel.
- Nennt altes Cron-Setup `_skripte/cortex-cron/`.

Betroffene Verweise:

- `Nexus/_rules/INDEX.md`
- `Nexus/_rules/GLOBAL_RULES.md`
- `Nexus/_rules/SESSION_LIFECYCLE.md`
- `Nexus/_rules/MEMORY_LAYERS.md`
- `Nexus/_rules/FEHLERPROTOKOLL.md`
- `Nexus/_memory/MEMORY.md`
- `Nexus/_memory/patterns/`
- `Nexus/_skripte/cortex-cron/`

Soll:

- Tabelle auf reale Phoenix-Pfade aktualisieren.
- Neue Regeln `ai-cooperation.md` und `AUTONOMY_CONTRACT.md` aufnehmen.
- Cron-Setup auf `Nexus/agent/cron/` und vorhandene Recipes verweisen.
- Memory-Beschreibung auf `Nexus/agent/memory/` und `_memory/memory.db`
  umstellen.
- Alte LL-/Tier-Hinweise als historische Referenz markieren oder entfernen.

### 3.3 `projects/Cortex-Web/CLAUDE.md`

Problem:

- Pflicht-Lesung verweist auf alte Nexus-Dateien:
  - `Nexus/_memory/MEMORY.md`
  - `Nexus/_rules/GLOBAL_RULES.md`
  - `Nexus/_rules/SESSION_LIFECYCLE.md`

Soll:

- Auf `Nexus/CLAUDE.md`, `Nexus/_rules/ai-cooperation.md`,
  `Nexus/_rules/AUTONOMY_CONTRACT.md`, `Nexus/_rules/multi-ai-boundaries.md`
  und projektlokale Regeln umstellen.
- Falls Projekt-Historie die alten Pfade bewusst dokumentiert, als
  "historisch/pre-Phoenix" markieren.

### 3.4 `projects/Cortex-Web/SESSION_RESUME.md`

Problem:

- Standard-Einstieg und Pflicht-Lesung referenzieren alte Nexus-Regeln und
  Memory-Dateien.

Soll:

- Einstieg auf reale Phoenix-Dateien aktualisieren.
- Alte historische Session-Blocks nicht vollstaendig umschreiben, sondern
  aktuelle Pflicht-Lesung klar separieren.

### 3.5 Projekt-Manifest-Dateien

Betroffene Dateien:

- `projects/Praxis-QM/PROJECT.md`
- `projects/doc-workflow/PROJECT.md`
- `projects/file-renamer/PROJECT.md`
- `projects/smartq-dashboard/PROJECT.md`

Problem:

- Referenzen auf globale Regeln, Memory oder Fehlerprotokoll zeigen auf
  verschwundene Nexus-Pfade.

Soll:

- Als Projekt-Dokumentationsdrift in einer spaeteren Projekt-Cleanup-Welle
  korrigieren.
- Nicht zusammen mit Nexus-Kern-Policy fixen, damit der erste Cleanup klein
  bleibt.

## 4. Echte Drift-Treffer mit mittlerer Prioritaet

### 4.1 Mode- und Tier-Vokabular

Fundorte:

- `Nexus/agent/modes/autonomy.md`
- `Nexus/agent/modes/safe.md`
- `Nexus/agent/modes/tier3.md`
- `Nexus/agent/modes/__init__.py`
- `Nexus/tools/cortex-mode/bin/inject.sh`
- `Nexus/agent/cron/runner.py`
- `Nexus/agent/cron/recipes/*.toml`
- `Nexus/agent/memory/golden_rules.py`
- `Nexus/agent/connexio/session_digest.py`

Problem:

- Das System verwendet noch Tier-3-Vokabular.
- Das neue Modell verwendet R0/R1/R2/R3 als Risikoachse.

Bewertung:

- Kein Sofort-Fix in Welle 1.
- Technische Umstellung betrifft Agent-/Cron-Code und muss in einer
  spaeteren R2-Welle geplant werden.
- Bis dahin kann `AUTONOMY_CONTRACT.md` als normative Uebersetzung dienen:
  Tier-3 entspricht nicht 1:1 R3, sondern wird schrittweise abgeloest.

### 4.2 `nexus-sync.sh`

Problem:

- Referenziert noch `tools/cortex-sanitizer/...`, obwohl `tools/` aktuell nur
  `cortex-mode`, `session-start-digest` und `telegram-inbox-hook` enthaelt.
- Hat keine Task-Lock- oder Approval-Marker-Logik.

Bewertung:

- Nicht in Welle 1 anfassen.
- Spaeter evolutionaer erweitern, nicht ersetzen.

## 5. Historische Referenzen, nicht sofort fixen

Folgende Bereiche enthalten alte Pfade oder Tier-Vokabular, sind aber
historische Doku, Tutorials oder Handover-Dateien:

- `Nexus/HANDOVER_PHOENIX.md`
- `Nexus/PHOENIX_RESUME.md`
- `Nexus/Second Brain/30 Tutorials/`
- `Nexus/Second Brain/40 Regeln/`
- `Nexus/Second Brain/70 Glossar/`
- `Nexus/_archive/`
- alte Sprint-Specs in Projektordnern

Empfehlung:

- Nicht im ersten Cleanup pauschal umschreiben.
- Stattdessen spaeter "historisch" / "pre-Phoenix" markieren, wenn die Datei
  als aktueller Einstieg missverstanden werden kann.

## 6. Korrektur zu Claude-Review

Claude schrieb in der Outbox-Antwort, Root-`Cortex/CLAUDE.md` verweise
ebenfalls auf `Nexus/AGENTS.md`. Das ist aktuell nicht korrekt.

Tatsaechlich:

- `Cortex/AGENTS.md` ist veraltet und verweist auf `Nexus/AGENTS.md`.
- `Cortex/CLAUDE.md` ist korrekt und verweist auf `Nexus/CLAUDE.md`.

Dieser Punkt sollte im spaeteren Cleanup beachtet werden, damit keine bereits
korrekte Datei unnoetig angefasst wird.

## 7. Aktueller Dirty-State

Zum Zeitpunkt dieser Welle war vor den neuen AI-Cooperation-Aenderungen bereits
folgender Nexus-Diff vorhanden:

- `_lib/extract/environment.json`

Beobachteter Inhalt:

- nur `_scan_timestamp` geaendert.

Bewertung:

- Vermutlich auto-generierter Drift.
- Nicht Teil dieser Welle.
- Nicht zuruecksetzen und nicht vereinnahmen.

## 8. Empfohlene Cleanup-Reihenfolge

### Cleanup A — aktueller Einstieg

1. `Cortex/AGENTS.md`
2. `Nexus/SYSTEM_MAP.md`
3. `projects/Cortex-Web/AGENTS.md` bei Bedarf nur um neue Task-Regeln
4. `projects/Cortex-Web/CLAUDE.md`
5. `projects/Cortex-Web/SESSION_RESUME.md`

### Cleanup B — Projekt-Manifeste

1. `projects/Praxis-QM/PROJECT.md`
2. `projects/doc-workflow/PROJECT.md`
3. `projects/file-renamer/PROJECT.md`
4. `projects/smartq-dashboard/PROJECT.md`

### Cleanup C — historische Tutorials / Glossar

Nur wenn sie als aktuelle Anleitungen genutzt werden. Sonst historisch
belassen.

### Cleanup D — technische Tier-zu-R-Migration

Eigene R2-Welle:

- Mode-Dateien.
- Agent-Cron.
- Session-Digest.
- Golden-Rules-Loader.
- Eventuell `nexus-sync.sh` Guards.

## 9. Nicht in diesem Audit umgesetzt

- Keine Aenderung an `SYSTEM_MAP.md`.
- Keine Aenderung an `Cortex/AGENTS.md`.
- Keine Aenderung an Projektdateien.
- Keine Aenderung an `nexus-sync.sh`.
- Keine Aenderung an Agent-/Cron-Code.

Diese Datei ist die Entscheidungsgrundlage fuer die naechste Cleanup-Welle.
