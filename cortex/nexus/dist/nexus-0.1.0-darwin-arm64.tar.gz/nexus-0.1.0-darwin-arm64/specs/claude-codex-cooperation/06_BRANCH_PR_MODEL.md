# Welle 6 — Codex Branch/PR-Modell fuer Nexus

> Status: **Spec, noch nicht aktiviert.**
> Vorbedingung: Welle 5 (Connexio Write-Surface) abgeschlossen.
> Zweck: kontrollierter Nexus-Schreibpfad fuer Codex, mit Branch/PR statt
> direktem Commit — Freigabe-Gate bleibt bei Dr. Stracke.

---

## 1. Grundregeln (aus ai-cooperation.md §2)

- Codex schreibt nie direkt auf `main`.
- Codex merged nie selbst.
- Claude darf reviewen, aber nicht final freigeben.
- Dr. Stracke ist der finale Merge-Gatekeeper.
- Tier-3-Wirkung (Cron, Secrets, Deploy) bleibt mode-unabhaengig gesperrt.

## 2. Branch-Naming

| Pattern                                | Sender | Beispiel                                       |
|----------------------------------------|--------|------------------------------------------------|
| `codex/<topic>-<id>`                   | Codex  | `codex/drift-cleanup-b-20260513`               |
| `claude/<topic>-<id>`                  | Claude | `claude/welle-5-connexio-write-20260514`       |
| `proposal/<sender>/<topic>-<id>`       | beide  | `proposal/codex/branch-pr-pilot-20260520`      |

- `<id>` = `YYYYMMDD` oder Task-Manifest-ID.
- Schreibungen lowercase, Bindestrich, kein ASCII-Punkt im Namen.
- Branch-Lifetime: bis Merge oder Reject, dann loeschen.

## 3. Pflicht-Inhalt eines Codex/Claude-PRs

Jeder PR enthaelt im Body:

1. **Task-Manifest-Pointer** auf `.cortex/tasks/<id>.yaml` (Projekt) oder
   `Nexus/specs/<sprint>/<id>.md` (Nexus-Vorschlag).
2. **Scope-Statement** (R0/R1/R2, allowed_paths, claimed_paths).
3. **Was umgesetzt wurde** + Evidence (Befehle, Tests, Screenshots).
4. **Risiko-/Drift-Hinweise** wenn vorhanden.
5. **Reviewer-Liste**: anderer Agent + Dr. Stracke.

PR-Titel: `<typ>(<scope>): <kurzbeschreibung>` — wie Commit-Convention.

## 4. CODEOWNERS-Schema (Vorschlag)

Wenn das Repo CODEOWNERS unterstuetzt, folgende Regel:

```text
# Nexus-Kern — Freigabe nur durch Dr. Stracke
/_rules/                     @sanexio-owner
/specs/                      @sanexio-owner
/agent/                      @sanexio-owner
/gateway/                    @sanexio-owner
/CLAUDE.md                   @sanexio-owner
/SYSTEM_MAP.md               @sanexio-owner

# Operationale Pfade — Codex/Claude duerfen vorschlagen, Merge bleibt manuell
/_archive/                   @sanexio-owner
/_memory/                    @sanexio-owner
```

`@sanexio-owner` wird zur Aktivierung der Welle 6 als GitHub-Team angelegt;
bis dahin ist die CODEOWNERS-Datei nicht ausgerollt.

## 5. Review-Pflicht-Matrix

| Aenderung                                 | Mindest-Review                          |
|-------------------------------------------|------------------------------------------|
| `_rules/*` (Policy)                       | Claude + Codex + Dr. Stracke (Merge)     |
| `agent/`, `gateway/`, `connexio/`         | Anderer Agent + Dr. Stracke (Merge)      |
| `SYSTEM_MAP.md`, `CLAUDE.md`              | Anderer Agent + Dr. Stracke (Merge)      |
| `specs/<welle>/` (neuer Vorschlag)        | Dr. Stracke (kein Agent-Veto)            |
| `Second Brain/30 Tutorials/` (Doku)       | Dr. Stracke direkt mergeable             |
| `_memory/USER.md`, `KNOWLEDGE.md`         | Dr. Stracke (R2, Wissensdatei)           |

## 6. Merge-Regeln

- `git merge --ff-only` oder `git merge --squash` — kein Merge-Commit-Spam.
- `main` bleibt linear (KONZEPT §9).
- Vor Merge: pull request status checks (sobald CI existiert: Doctor 13+/14 plus Skill-Tests).
- Push direkt auf `main` bleibt Notnagel — nur Dr. Stracke selbst.

## 7. Was diese Welle NICHT macht

- Keine automatischen GitHub Actions (separater Vorschlag).
- Kein Auto-Merge auf gruenem CI.
- Keine Tier-3-Auto-Approvals (Cron, Deploy, Secrets bleiben Stop).
- Keine Erweiterung des Codex-Schreibrechts auf `main` oder auf Tag-Operationen.

## 8. Aktivierung

1. Connexio Write-Surface (Welle 5) muss Task-Statuswechsel halten.
2. CODEOWNERS-Team `@sanexio-owner` von Dr. Stracke anlegen.
3. Diese Spec auf "approved" setzen (Outbox-Antwort von Dr. Stracke).
4. Erste Codex-PRs starten in `projects/Cortex-Web`, nicht in Nexus.
5. Nexus-PRs erst ab Welle 6b nach Pilot-Erfolg.

---

*Spec v0 — vorbereitet 2026-05-12. Aktivierung nach Welle 5.*
