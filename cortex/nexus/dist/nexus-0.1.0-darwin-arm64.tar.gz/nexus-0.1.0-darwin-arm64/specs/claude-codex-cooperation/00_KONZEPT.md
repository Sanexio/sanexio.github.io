# Claude-Codex-Kooperation — Konzept

> Status: **Approved for Welle 1 implementation 2026-05-12** (Dr. Stracke)
> Zweck: Kooperationsmodell fuer Claude und Codex in Cortex/Nexus, ohne
> Sync-Konflikte, Architektur-Drift oder unkontrollierte Nexus-Schreibzugriffe.

---

## 1. Kurzfassung

Cortex bleibt zweischichtig: `~/Cortex/Nexus/` ist der portable Wissens-,
Regel- und Agentenkern; `~/Cortex/projects/` ist die Arbeitsflaeche fuer
konkrete Projekte. Claude und Codex arbeiten kuenftig als Peer-Systeme:
beide duerfen analysieren, Vorschlaege schreiben und Reviews liefern. Fuer
den Nexus-Kern gilt jedoch: Umsetzung erst nach Freigabe durch Dr. Stracke.

Codex erhaelt damit keinen freien direkten Nexus-Schreibzugriff. Er darf
Nexus-Aenderungen ueber Outbox, strukturierte Vorschlaege, Reviews und spaeter
kontrollierte Branches/PRs einreichen. Claude ist nicht alleiniger
Entscheider, sondern ebenfalls Vorschlags- und Umsetzungs-Agent nach
Freigabe. Projektarbeit in `projects/<projekt>/` darf von Claude und Codex
selbststaendig bearbeitet werden, sofern Task-Scope, Git-Zustand und
Risiko-Level sauber sind.

## 2. Ausgangslage

Gesichert:

- `~/Cortex/` ist die lokale Huelle auf diesem Mac.
- `~/Cortex/Nexus/` ist ein Git-Repo und synchronisiert ueber GitHub als
  Single Source of Truth.
- `~/Cortex/projects/` enthaelt lokale Projekt-Repos und Projektordner.
- `Nexus/CLAUDE.md` ist die reale Hauptsteuerung.
- Connexio ist als read-only Kontextflaeche gebaut.
- `Nexus/_rules/multi-ai-boundaries.md` v1 setzt bisher eine harte
  Claude-Exklusivitaet fuer Nexus.
- Der Phoenix-Reset hat Drift erzeugt: mehrere Dokumente referenzieren alte
  Regel-, Memory- und Cron-Pfade.

Risiko:

- Autonomy Mode ist ohne formalen Vertrag zu stark von Prosa und
  Modellinterpretation abhaengig.
- Auto-Sync, lokale Runtime-Dateien und Multi-Device-Arbeit koennen sich ohne
  Task-Awareness gegenseitig stoeren.
- Alte Pfadverweise erzeugen falsche mentale Modelle fuer Claude, Codex und
  andere KIs.

## 3. Rollen

| Rolle | Aufgabe | Darf schreiben | Darf entscheiden |
|---|---|---|---|
| Dr. Stracke | Priorisierung, Freigabe, Konfliktentscheidung | alles | alles |
| Claude | Nexus-Vorschlaege, Reviews, Umsetzung nach Freigabe | Nexus nach Freigabe, projects | nicht allein bei R2/R3 |
| Codex | Projektarbeit, Reviews, Nexus-Vorschlaege | projects, Outbox; Nexus nur nach freigegebenem Modell | nicht allein bei R2/R3 |
| Connexio read | Kontext liefern | nichts | nichts |
| Connexio write (spaeter) | Task-/Review-Status schreiben | nur hardcoded Task-/Audit-Store | nichts |

Wichtig: Claude ist kein alleiniger Gatekeeper im Sinne einer Hierarchie.
Claude und Codex duerfen sich gegenseitig Aufgaben stellen und Reviews geben.
Bei Nexus-Kern-Umsetzung ist Dr. Stracke der Freigabe-Gatekeeper.

## 4. Risiko-Level

| Level | Bereich | Autonomie |
|---|---|---|
| R0 | Read-only Analyse, Status, Logs, Diff, Suche | frei |
| R1 | Schreiben in `~/Cortex/projects/<projekt>/` | frei, taskgebunden |
| R2 | Schreiben im Nexus-Kern | Vorschlag frei; Umsetzung nur nach Freigabe |
| R3 | ausserhalb Cortex, Secrets, Geld, Kreditkarten, destruktive Git-Ops, reale Aussenwirkung | nie autonom |

Beispiele:

- R0: `git status`, `git log`, `rg`, Datei lesen.
- R1: Code/Doku/Test in `projects/Cortex-Web`.
- R2: `Nexus/_rules/`, `Nexus/specs/`, `Nexus/CLAUDE.md`, `Nexus/SYSTEM_MAP.md`,
  Agent-, Gateway-, Connexio- oder Sync-Policy.
- R3: Passwoerter, API-Keys, Keychain, `~/.ssh`, Zahlvorgaenge,
  Kreditkarten, Schreibzugriff ausserhalb Cortex, `push --force`,
  `reset --hard`, echte Deployments mit Aussenwirkung, wenn nicht explizit
  freigegeben.

## 5. Mode x Risiko

| Mode | R0 | R1 | R2 | R3 |
|---|---|---|---|---|
| autonomy | autonom | autonom mit Debrief | Vorschlag/Review, Umsetzung nur nach Freigabe | STOP |
| safe | autonom | 4-Phasen-Workflow | 4-Phasen-Vorschlag, Umsetzung nur nach Freigabe | STOP |

`safe` aendert das Verhalten, nicht die Befugnis. R3 bleibt immer Stop.

## 6. Task- und Review-Protokoll

Aufgaben muessen bei Multi-Agent-, Multi-Device- oder Nexus-Arbeit als
Manifest beschrieben werden. Minimalfelder:

- `id`
- `title`
- `created_by`
- `assigned_to`
- `repo`
- `scope`
- `risk_level`
- `allowed_paths`
- `forbidden_paths`
- `claimed_paths`
- `base_commit`
- `machine`
- `status`
- `requires_human_approval`
- `acceptance_criteria`
- `evidence`
- `result`
- `next_action`

Erlaubte Statuswerte:

- `proposed`
- `accepted`
- `in_progress`
- `blocked`
- `review_requested`
- `approved`
- `done`
- `rejected`

Spaeter optional:

- `superseded`

## 7. Ablageorte

Hybrid-Modell:

- Projekt-Tasks: `projects/<projekt>/.cortex/tasks/`
- Projekt-Reviews: `projects/<projekt>/.cortex/reviews/`
- AI-Outbox: `projects/_ai-cooperation-outbox/`
- Nexus-Governance-Specs: `Nexus/specs/claude-codex-cooperation/`
- Nexus-Regeln: `Nexus/_rules/`
- Spaetere Runtime-Task-DB: `_memory/tasks/` oder Connexio-Task-Store, nur mit
  Audit-Log und Retention.

Codex darf Projekt-Tasks und Outbox-Dateien schreiben. Nexus-Governance-Dateien
werden erst nach Dr.-Stracke-Freigabe geschrieben.

## 8. Konfliktregeln

Automatisch stoppen bei:

- Git-Divergenz oder non-fast-forward-Zustand.
- Dirty Worktree mit fremden oder unerklaerten Aenderungen.
- Task will Pfade ausserhalb `allowed_paths` bearbeiten.
- R2-Umsetzung ohne Freigabe.
- R3-Beruehrung.
- Widerspruch zwischen Projektregel und Nexus-Policy.
- Unklare Zustaendigkeit zwischen Claude, Codex und Mensch.

Entscheidungsreihenfolge:

1. Dr. Stracke
2. freigegebene Nexus-Policy
3. Projekt-Policy
4. Task-Manifest
5. Agent-Default

## 9. Multi-Device-Sync

GitHub bleibt Single Source of Truth. `main` soll linear und
fast-forward-orientiert bleiben. Lokale Maschinen duerfen eigenstaendig Tasks
uebernehmen, aber nicht so, dass Sync-Konflikte wahrscheinlich werden.

MVP-Regeln:

- Task notiert `base_commit`.
- Task notiert `machine`.
- Task notiert `claimed_paths`.
- Vor Schreibarbeit: Git-Status pruefen.
- Bei fremdem Diff: Stop und melden.
- Bei Divergenz: kein Auto-Merge, kein Auto-Rebase.
- Bei R2: Umsetzung nur mit Approval-Marker oder expliziter Freigabe.

## 10. Sync-Strategie

`nexus-sync.sh` wird nicht in Welle 1 ersetzt. Es soll spaeter evolvieren,
weil es bereits wichtige Schutzlogik enthaelt:

- Heartbeat-Skip
- Auto-Add-Whitelist
- Pathspec-isolierte Auto-Commits
- Auto-Resolve nur fuer definierte generierte Dateien
- Log-Rotation

Spaetere Erweiterungen:

- Task-Lock-Check
- Approval-Marker-Check
- maschinenlesbarer Drift-Healthreport

## 11. Performance und Anti-Muell

Das System soll Runtime-Artefakte kontrollieren, bevor sie gross werden.
Retention wird als Policy festgelegt und spaeter technisch umgesetzt.

Vorgeschlagene Defaults:

| Pfad | Retention | Aktion |
|---|---|---|
| `_memory/logs/*.log` | 30 Tage oder 10 MB je Datei | rotieren/komprimieren |
| `_memory/spawn-queue.db` done/failed | 14 Tage | archivieren und vacuum |
| `_archive/autonomy/spawns/*` Rohdaten | 30 Tage | komprimieren; Summary behalten |
| `_memory/health/*.json` | latest + 7 datierte Snapshots | aelter entfernen |
| `_memory/audit/*.jsonl` | 90 Tage aktiv, danach komprimiert | append-only |

Sanitizer darf nur operationalen Muell anfassen, niemals Wissensdateien.

## 12. Roadmap

### Welle 1 — Dokumentarischer MVP

- Dieses Konzept.
- `AUTONOMY_CONTRACT.md`.
- `ai-cooperation.md`.
- `multi-ai-boundaries.md` v2.
- `task-template.yaml`.
- `01_DRIFT_CLEANUP.md`.

### Welle 2 — Drift-Cleanup

- Audit pruefen.
- Veraltete Pfade in Root-, Nexus- und Projekt-Dokumenten bereinigen.
- Ein zusammenhaengender Cleanup-Commit nach Freigabe.

### Welle 3 — Task-aware Sync

- `nexus-sync.sh` um Task-Lock und Approval-Marker erweitern.
- Healthreport fuer Drift.

### Welle 4 — Doctor und Retention

- `cortex-agent doctor` um Policy-, Drift-, Runtime- und Sync-Checks
  erweitern.
- Sanitizer/Retention mit harter Whitelist.

### Welle 5 — Connexio Write-Surface

- Nur Task-/Review-Status, kein freier File-Write.
- Audit-Log verpflichtend.

### Welle 6 — Codex Branch/PR-Modell fuer Nexus

- Nur nach Freigabe.
- Kein Merge durch Codex.
- Review durch Claude/Codex, finale Freigabe durch Dr. Stracke.

## 13. Nicht-Ziele dieser Welle

- Keine Aenderung an `nexus-sync.sh`.
- Keine Aenderung an Cron/LaunchAgents.
- Keine Connexio-Write-API.
- Kein freier Codex-Schreibzugriff in Nexus.
- Kein Drift-Cleanup an bestehenden Dokumenten ausser der Boundary-v2-Regel.

---

*Konzept v1 — erstellt aus Codex-Vorschlag, Claude-Review und Dr.-Stracke-Freigabe vom 2026-05-12.*
