---
spec: cortex-cli
phase: Phase 3 — Cortex-CLI MVP
status: w3.0-setup (2026-05-31)
owner: Sanexio GmbH / Claude (implementation)
parent: specs/cortex-platform/00_VISION_UND_ROADMAP.md §11 Phase 3
license: Apache-2.0 (OSS gemäß §10.1 OSS-Distributionsmodell)
build_stack: Bun-Bundle (§10.2)
update_pattern: Hybrid Auto-Check + Notification + manueller Klick (§10.3)
---

# Cortex-CLI — Konzept (MVP)

## 1. Zweck

Cortex-CLI ist das **User-zentrische Plattform-Tool** der Cortex-Plattform.
Ein einzelner Befehl (`cortex`) bündelt Installation, Initialisierung,
Update und Status-Abfrage über die gesamte Sanexio-Plattform-Schicht
(Nexus + Cortex Layer + Tenant-Daten).

Aware-Health/Aniva-Vorbild: ein **klares Marketing-Versprechen** —
„ein Befehl, eine Plattform" — als Distributions-Hebel für Ärzte, die
Cortex an ihrem Mac installieren wollen, ohne Shell-Skript-Detektivarbeit.

## 2. Sub-Commands (MVP-Scope)

| Command | Zweck | Phase | Risiko |
|---------|-------|-------|--------|
| `cortex --version` | Version + Bun-Runtime + Plattform-Hash | 3.0 | R0 |
| `cortex --help` | Sub-Command-Übersicht | 3.0 | R0 |
| `cortex status` | Plattform-Stand: Nexus-Version, Cortex-Layer-Projekte, Tenant-Pfad, Update-Verfügbarkeit | 3.0 | R0 (read-only) |
| `cortex install` | Erst-Installation (wird vom Bootstrap-Skript `install.sh` aufgerufen) | 3.1 | R1 (legt `~/.cortex/`-Struktur an) |
| `cortex init --license <token>` | Tenant-Initialisierung mit Lizenz-Token | 3.2 | R2 (Token-Validierung, schreibt `~/.cortex/license.json`) |
| `cortex update` | Update-Pfad ziehen (Nexus-Binary + Cortex-Layer-Projekte) | 3.3 | R2 (Schreib-Ops im `~/.cortex/`-Bereich) |
| `cortex add <project>` | Cortex-Layer-Projekt hinzufügen (Git-Clone vom Sanexio-GitHub) | 3.4 | R2 |
| `cortex contribute <project>` | PR-Workflow (öffnet Browser zum GitHub-PR-UI) | 3.5 | R1 (Browser-Open, kein Filesystem-Schreib) |

**Phase-3-MVP** = Sub-Commands 3.0 (status/version/help). Phase 3.1–3.5
sind Folge-Wellen, jeweils 1–2 Sessions.

## 3. Distributions-Architektur

### 3.1 Erst-Installation (User-Pfad)

```bash
# Ein Befehl, irgendein Mac:
curl -fsSL https://cortex.sanexio.de/install.sh | sh
```

`install.sh` (eigenes Sub-Projekt unter `cortex-cli/dist/install.sh`):
1. Bun-Runtime via Homebrew oder direkt installieren (falls fehlt)
2. Cortex-CLI-Bundle herunterladen (signiert, von cortex.sanexio.de
   gehostet)
3. Bundle nach `/usr/local/bin/cortex` (oder `~/bin/cortex`) entpacken
4. Erste Ausgabe: „Cortex installiert. Nächster Schritt:
   `cortex init --license <token>`"

### 3.2 Initialisierung mit Lizenz-Token (Tenant-Pfad)

```bash
cortex init --license XXXX-YYYY-ZZZZ
```

Validiert Token gegen Sanexio-Endpoint, legt `~/.cortex/license.json`
+ `~/.cortex/.tenant/`-Struktur an.

### 3.3 Update-Pfad (Hybrid §10.3)

- **Background-LaunchAgent** (`~/Library/LaunchAgents/de.sanexio.cortex-update-check.plist`):
  täglich gegen Sanexio-Endpoint prüfen, ob neue Version verfügbar
- **Bei verfügbarer Version:** macOS-Notification via `terminal-notifier`
  oder `osascript display notification`
- **User-Klick** triggert `cortex update --apply`
- Verhindert: „Update überrascht User während Patient-Termin"

### 3.4 Status (read-only)

```bash
cortex status
```

Ausgabe (Beispiel):
```
Cortex-Plattform 1.0.0-mvp (Bun 1.x, macOS 26.4)
Nexus:          v0.0.0 (closed binary noch nicht installiert)
Tenant:         ~/.cortex/.tenant/ (keine Tenant-Konfig)
Cortex Layer:   3 Projekte installiert (cortex-web, cortex-rename, cortex-qm)
Updates:        keine verfügbar (zuletzt geprüft: 2026-05-31 18:00)
Mode:           autonomy
```

Format: read-only, idempotent, exit 0 bei OK / exit 1 bei Drift.

## 4. Repo-Struktur

```
~/Cortex/projects/cortex-cli/          ← lokales Working-Repo
├── README.md
├── LICENSE                            ← Apache 2.0
├── CONTRIBUTING.md
├── CODE_OF_CONDUCT.md                 ← Contributor Covenant 2.1 DE
├── OSS_PREP.md                        ← Phasen-Plan bis OSS-Launch
├── package.json                       ← Bun-Build-Konfig
├── .gitignore
│
├── bin/
│   └── cortex.mjs                     ← Entry-Point (Bun-shebang)
│
├── src/
│   ├── commands/
│   │   ├── status.mjs                 ← cortex status
│   │   ├── version.mjs                ← cortex --version
│   │   └── help.mjs                   ← cortex --help
│   ├── lib/
│   │   ├── platform.mjs               ← Plattform-Info (Bun-Version, OS)
│   │   └── tenant.mjs                 ← Lese-Pfad ~/.cortex/.tenant/
│   └── router.mjs                     ← Sub-Command-Router
│
├── dist/
│   └── install.sh                     ← Bootstrap-Skript (kommt in Phase 3.1)
│
└── docs/
    └── ARCHITECTURE.md                ← (kommt rollend mit den Sub-Wellen)
```

GitHub-Repo: `Sanexio/cortex-cli` (privat zu Beginn, public-Switch bei
OSS-Launch-Readiness — analog zu `cortex-rename`, `cortex-qm`,
`cortex-desk`).

## 5. Repo-Konventionen

Übernommen aus `Sanexio/cortex-rename`-Skelett (2026-05-31):

- LICENSE: **Apache 2.0** (gleiche wie cortex-web)
- CODE_OF_CONDUCT: Contributor Covenant 2.1 (deutsch)
- OSS_PREP.md: Phasen-Plan A → B → C → public-Switch
- Framework/Tenant-Split-Pattern aus
  `Nexus/_memory/feedback_framework_tenant_split.md`:
  Cortex-CLI ist **reines Framework** (kein Tenant-Inhalt), die
  Tenant-Konfiguration lebt unter `~/.cortex/.tenant/` auf dem User-Mac.

## 6. Sub-Wellen-Plan

| Welle | Inhalt | Geschätzter Aufwand |
|-------|--------|---------------------|
| **3.0** | Setup: Spec, Repo-Skelett, Router, `status`/`--version`/`--help` Sub-Commands, Smoke | **diese Welle** (~1h) |
| 3.1 | `cortex install` + `dist/install.sh` Bootstrap | 2–3h |
| 3.2 | `cortex init --license <token>` + Token-Validierungs-Endpoint-Stub | 2–3h |
| 3.3 | `cortex update` + LaunchAgent + Notification (Hybrid §10.3) | 3–4h |
| 3.4 | `cortex add <project>` (Git-Clone vom Sanexio-GitHub) | 2h |
| 3.5 | `cortex contribute <project>` (Browser-Open via `open`-Befehl) | 1h |
| 3.6 | Bun-Bundle-Build-Pipeline + signiertes Release auf `cortex.sanexio.de` | 3–4h |

**Gesamt-MVP:** ~14–20h verteilt auf 6 Sessions, plus Wartezeit für
Test-Macs (Sanexio-Team / vertrauenswürdige Ärzte).

## 7. Test-Plan

- **Welle 3.0:** Smoke-Test lokal — `bun bin/cortex.mjs status`,
  `bun bin/cortex.mjs --version`, `bun bin/cortex.mjs --help`,
  Exit-Codes prüfen.
- **Ab Welle 3.1:** Integration-Test gegen einen **zweiten Test-Mac**
  (kein Source-Zugriff, nur Bootstrap-Skript laufen lassen).
- **Ab Welle 3.6:** Externe Tester (Sanexio-Team) installieren via
  `curl ... | sh`, geben Feedback über `gh issue create` im Repo.

## 8. Abhängigkeiten

- Bun ≥ 1.0 (Build-Runtime + Standalone-Binary-Target)
- macOS 13+ (Stracke-Macs Mindeststand)
- `gh` CLI (für Phase 3.4/3.5 Browser-Open zu PR-UI)
- Keine Node.js-Pflicht (Bun-only, gemäß §10.2)

## 9. Tier-3-Abgrenzung

Cortex-CLI berührt **kein Bank/Bezahl**. Lizenz-Token-Validierung
(Welle 3.2) ist read-only gegen Sanexio-Endpoint, kein Geld-Schreib-Op.
Daher kein Tier-3-Trigger; alle Wellen im Standard-Autonomy-Mode
fahrbar.

## 10. Querverweise

- Vision: `specs/cortex-platform/00_VISION_UND_ROADMAP.md` §8 + §11
- OSS-Entscheidung: `specs/cortex-platform/02_OPEN_DECISIONS_RECOMMENDATIONS.md` §10.1
- Build-Stack: §10.2 (Bun-Bundle + py_compile + codesign)
- Update-Pfad: §10.3 (Hybrid)
- OSS-Skelett-Vorlage: `~/Cortex/projects/cortex-rename/` (2026-05-31 angelegt)
- Framework/Tenant-Split-Pattern:
  `Nexus/_memory/feedback_framework_tenant_split.md`
