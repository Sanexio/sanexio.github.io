# Sync-Alarm-Eskalation — Konzept

> Stub, angelegt 2026-05-13. Aufzuhängen an: nächste Multi-Device-Sync-Welle.

## Motivation

Vorfall 2026-05-13: M5-`nexus-sync.sh` hängt 9 h fest auf einem Codex-
Feature-Branch (Rebase-Schleife gegen `origin/main` an uncommittetem
Heartbeat). Der Sync schreibt brav alle 5 min „DIVERGENZ" + „ALARM
unterdrueckt" ins Log, sendet aber **keine** aktive Benachrichtigung
nach dem ersten Alarm. User entdeckt den Drift erst durch Direktfrage.

Branch-aware Fix ist eingespielt (`de7a510`), das Symptom ist weg. Aber
das **Eskalations-Loch** bleibt: jede zukünftige Drift-Ursache hat
denselben blinden Fleck.

## Ziel

Drift > 30 min muss aktiv eskalieren:

1. **Erst-Alarm** (bisher): Telegram-Push beim ersten Auftreten der
   Divergenz. ✓ funktioniert.
2. **Re-Alarm** (neu): wenn nach 30 min derselbe Marker noch existiert,
   zweiter Push mit `[DRIFT-RE-ALARM]`-Prefix + Geräte-Liste.
3. **Eskalation** (neu): nach 2 h Stillstand auf gleichem Marker:
   `[DRIFT-KRITISCH]`-Push + Skript-Pause (kein weiterer Versuch) +
   Health-JSON-Flag `escalated: true`.

## Anforderungen

- Alarm-Marker (`_memory/.divergence-alarmed`) muss Timestamp tragen
  (heute: nur mtime des Files — reicht eigentlich; lesbar via `stat`).
- Re-Alarm-Logik im `send_divergence_alarm`-Pfad: vor dem „unterdrueckt"-
  Log prüfen, ob `now() - marker_mtime > 1800 s` (30 min) bzw. `> 7200 s`
  (2 h) → entsprechend `[DRIFT-RE-ALARM]` / `[DRIFT-KRITISCH]` Push.
- Anti-Spam: maximal 1 Push pro Eskalations-Stufe (Marker-Datei
  `.divergence-realarmed`, `.divergence-escalated`).

## Implementierungs-Skizze

```bash
# In send_divergence_alarm() oder im "unterdrueckt"-Zweig:
if [ -f "$ALARM_MARKER" ]; then
    AGE=$(( $(date +%s) - $(stat -f %m "$ALARM_MARKER") ))
    if [ "$AGE" -gt 7200 ] && [ ! -f "$ESC_MARKER" ]; then
        push "[DRIFT-KRITISCH] $host: Drift seit $((AGE/3600))h ungelöst, Sync wird pausiert"
        touch "$ESC_MARKER"
        exit 3
    elif [ "$AGE" -gt 1800 ] && [ ! -f "$REALARM_MARKER" ]; then
        push "[DRIFT-RE-ALARM] $host: Drift seit $((AGE/60))min ungelöst"
        touch "$REALARM_MARKER"
    fi
fi
```

## Open Questions

- Soll die Eskalation auch dann triggern, wenn der Drift „nur" auf einem
  Mac sichtbar ist (z.B. nur M5), oder muss er Mac-übergreifend
  korrelieren? Vorschlag: pro Gerät — sonst überlebt der Spec-Wert dieser
  ganzen Übung den nächsten Vorfall nicht.
- Eskalations-Reset: durch welchen Event? Erfolgreiche Konvergenz
  (`RECOVERY:` Log-Eintrag) → alle drei Marker entfernen. Klar definiert.

## Bezug

- Geschwister-Spec: `multi-device-multi-ai/00_KONZEPT.md`
- Patch-Anker: Commit `de7a510` (branch-aware FF)
- Memory: `feedback_nexus_sync_branch_aware.md`
