# Multi-Device-Multi-AI-Architektur — Konzept

> Status: **Approved 2026-05-10** (Dr. Stracke)
> Zweck: festlegen, wie Cortex/Nexus auf mehreren Macs gleichzeitig
> existiert und wie nicht-Claude-KIs (Codex, Cursor, Gemini-CLI etc.)
> mitarbeiten dürfen, ohne den Wissens-Stammhirn zu kompromittieren.

---

## §1 Leitprinzipien

1. **GitHub ist Single Source of Truth.** Kein eigenes Sync-Protokoll, kein
   Tailscale-Merge, kein rsync. Jede Maschine pullt vor dem Edit, pusht
   danach. Konflikte werden per Standard-Git-Workflow gelöst.
2. **Nexus = Stammhirn, exklusiv Claude.** Wissen, Regeln, Memory, Mode-State,
   Connexio-Surface, Skills. Andere KIs lesen Nexus, schreiben aber nie.
3. **Projekte = Arbeitsfläche, alle KIs.** `~/Cortex/projects/<projekt>/`
   ist Read-Write für Claude *und* für andere KIs (Codex, Cursor, …).
4. **Sequenzielle Bearbeitung.** Ein Projekt wird zu einem Zeitpunkt nur
   auf einem Mac aktiv bearbeitet. Parallel-Arbeit erst wenn Team-Modus
   kommt — dann Branching/PRs nachrüsten.

---

## §2 Repository-Topologie

```
GitHub (Sanexio org)
├── nexus            ← Stammhirn,  RW: Claude         · RO: andere KIs
├── cortex-web       ← Dach-Projekt, RW: alle         · enthält sites/{praxis-webseite, juvantis-shopify, sanexio-github-io}
├── (juvantis)       ← noch ohne Repo, Folge-Welle
└── ...

Lokal je Mac unter ~/Cortex/
├── Nexus/           ← Pflicht-Clone auf jedem Mac
└── projects/
    ├── Cortex-Web/  ← Clone wo gebraucht
    ├── Juvantis/    ← Clone wo gebraucht
    └── ...
```

**Geräte-Verteilung (Stand 2026-05-10):**

| Gerät                | Hostname            | Nexus | Cortex-Web | Juvantis | cortex-agent | Gaming |
|----------------------|---------------------|-------|------------|----------|--------------|--------|
| home (M2)            | Cluster-Mini-02     | ✅    | ✅         | ✅       | ✅           | ✅     |
| praxis-intel         | SSMD-MacBookPro     | ✅    | (planned)  | —        | —            | —      |
| praxis-mobile (M5)   | SSMD-MacBookPro-M5  | ✅    | (planned)  | —        | —            | —      |
| praxis-studio        | Mac-Studio          | ✅    | (planned)  | —        | —            | —      |

Voll-Registry: `Nexus/.config/devices.json` (Tailscale-Mesh, SSH-Methode).

---

## §3 Boundary-Enforcement (Nexus = RO für andere KIs)

Drei sich ergänzende Schichten:

### 3a Workspace-Trust (primär)

Andere KIs (Codex, Cursor, Cline, Continue, …) werden **immer mit dem
Projekt-Wurzelpfad als Workspace-Root** gestartet, nicht mit `~/Cortex/`.
Konkret:

```bash
# Codex/Cursor öffnen
cd ~/Cortex/projects/Cortex-Web
codex .          # oder: cursor .
```

Damit ist `~/Cortex/Nexus/` außerhalb des Workspaces — der Editor sieht
es technisch gar nicht. Auch wenn die KI nach `../Nexus/_memory/MEMORY.md`
greift, hat sie keine Permission im Tool-Context.

### 3b AGENTS.md-Regel (sekundär)

Jedes Projekt-Repo hat eine `AGENTS.md` im Root. Diese Datei wird von
Codex/Cursor/Gemini-CLI als Default-Onboarding gelesen. Sie enthält:

- Kurzbeschreibung des Projekts
- **Hard-Boundary:** „Schreibe niemals außerhalb dieses Repos. Insbesondere
  nicht in `~/Cortex/Nexus/` oder in `~/.claude/`."
- Verweis auf Nexus-Wissen via Connexio-MCP (read-only)
- Codex-Style-Hinweise (Sprache, Commit-Style, etc.)

### 3c Connexio-MCP-Surface (Wissens-Lesefenster)

Externe KIs greifen auf Cortex-Wissen ausschließlich über Connexio:

- MCP: `claude mcp add -s user connexio-readonly -- ...` (Claude-Code-Sessions)
- HTTP: `GET 127.0.0.1:7766/context?project=…` mit `X-Connexio-Key`-Header

Im Code ist Read-Only hardcoded (SQLite `mode=ro`, Pfad-Whitelist,
BLOCKED_TAGS-Filter, Audit-Log). Auch wenn die KI versucht zu schreiben,
schlägt es auf DB-Ebene fehl.

---

## §4 Cross-Device Pull/Push-Disziplin

### Vor jedem Session-Start auf einem Mac

```bash
# 1. Nexus aktualisieren (Pflicht — Claude liest hier seine Regeln)
cd ~/Cortex/Nexus && git pull --ff-only

# 2. Aktives Projekt aktualisieren
cd ~/Cortex/projects/Cortex-Web && git pull --ff-only
```

Bei Divergenz oder Konflikt: **STOP**, manuell auflösen, kein Auto-Reset.

### Nach jeder Session

- Commit (atomar, eine Welle = ein Commit oder kohärenter Commit-Block)
- `git push origin main`
- Erst dann darf der nächste Mac übernehmen

### Welcher Mac arbeitet gerade an welchem Projekt?

Single-Source-of-Truth-Heuristik: **wer den letzten Commit hat, war zuletzt
dran.** Bei Konflikt zeigt `git log --oneline -5` Klarheit. Solange keine
zwei Macs gleichzeitig arbeiten, gibt es keine Race Condition.

Optional (Folge-Welle): „project-lock"-Skill, der einen Marker in
`Nexus/_memory/active-sessions.json` setzt — aber für Solo-Betrieb
overengineered.

---

## §5 Onboarding eines neuen Macs

Schritt-für-Schritt für jeden Mac, der zur Cortex-Familie hinzukommt:

```bash
# 1. SSH-Key auf GitHub registriert? Falls nicht: gh auth login
gh auth status

# 2. Cortex-Wurzel anlegen
mkdir -p ~/Cortex && cd ~/Cortex

# 3. Nexus klonen (Pflicht, immer)
git clone git@github.com:Sanexio/nexus.git Nexus

# 4. Mode-State initialisieren (Default: autonomy)
mkdir -p ~/.claude/state
echo '{"mode":"autonomy"}' > ~/.claude/state/cortex-mode.json

# 5. Projekte nach Bedarf klonen
mkdir -p projects && cd projects
git clone git@github.com:Sanexio/cortex-web.git Cortex-Web
# weitere nach Bedarf

# 6. Pro Mac: Geräte-Eintrag in Nexus/.config/devices.json prüfen/ergänzen
#    (das macht Claude beim ersten Run automatisch via doctor-Skill)

# 7. Per-Device-Secrets (aus 1Password / sicherem Vault):
#    - GitHub-SSH-Key (~/.ssh/id_ed25519)
#    - Telegram-Bot-Token in Cortex/Nexus/gateway/.env (falls Telegram-Bridge)
#    - Cortex-Web Adapter-Secrets in projects/Cortex-Web/.env.local
#    Diese werden NIE über Git transportiert.
```

Resultat: der neue Mac kann „Projekt fortsetzen" für jedes geklonte Projekt
ausführen.

---

## §6 Was passiert wenn …

| Szenario | Verhalten |
|----------|-----------|
| Andere KI versucht Edit in `Nexus/`        | Workspace-Trust verhindert es. Falls doch erfolgt: Claude erkennt es beim nächsten `git pull` (nicht vom erwarteten Branch) und meldet — Recovery via `git revert`. |
| Zwei Macs editieren parallel das gleiche Projekt | Push der zweiten Maschine schlägt fehl (non-fast-forward). User muss manuell rebase/merge. Kein Auto-Resolve. |
| Mac war länger offline             | Erst `git pull --rebase`, dann arbeiten. Bei Divergenz Folge-Welle. |
| Connexio-MCP gibt sensible Daten preis      | BLOCKED_TAGS-Filter (medizin/patient/steuer/secret) greift bevor Antwort die DB verlässt. |
| Geheimer Inhalt rutscht in Commit          | `.gitignore` blockt `.env*` und `_media-source/**` projektübergreifend. Bei Verstoß: `git filter-repo` Folge-Welle. |

---

## §7 Was wir bewusst NICHT bauen

- **Kein eigener Sync-Daemon.** Git reicht.
- **Keine Live-Lock-Mechanismen** für sequenzielle Bearbeitung. Solo-Betrieb
  → keine Race Conditions.
- **Kein automatisches Sub-Module-Setup** für `Cortex-Web/sites/*`.
  Sites bleiben im Cortex-Web-Mono-Repo, weil sie geteilte Trunk-Daten haben.
- **Kein Mirror-Repo nur-für-andere-KIs.** Workspace-Trust + AGENTS.md
  + Connexio reichen.

---

## §8 Folge-Wellen (nicht jetzt)

1. **AGENTS.md-Standardisierung** über alle Projekte (Cortex-Web hat
   gleich nach diesem Konzept eine, Juvantis sobald Repo existiert).
2. **`bootstrap-mac.sh`** in `Nexus/scripts/` — automatisiert §5
   Schritte 2–6.
3. **Doctor-Skill-Erweiterung** um Multi-Device-Health: meldet wenn
   Nexus-HEAD lokal ≠ origin oder wenn ein bekanntes Projekt fehlt.
4. **Team-Modus** wenn mehrere Personen parallel arbeiten — dann
   Feature-Branches, PRs, evtl. CODEOWNERS in jedem Projekt.

---

*Konzept v1, Sprint Multi-AI-Architektur 2026-05-10. Vorgängerstand:
ad-hoc — Cortex-Web nur auf Cluster-Mini-02 verfügbar, andere KIs nicht
formal eingebunden.*
