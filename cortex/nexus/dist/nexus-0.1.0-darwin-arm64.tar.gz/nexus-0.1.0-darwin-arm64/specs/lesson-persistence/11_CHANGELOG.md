# Lesson-Persistence — Changelog

## 2026-05-13 — Codex Umsetzung task-95f52c4da0b8

### Implementiert

- Neuer Skill `capture-lesson` unter `agent/skills/builtin/capture_lesson.py`.
- `MEMORY.md`-Index wird bei Insert und Update automatisch gepflegt.
- Slug-, Kind- und Pflichtfeld-Validation verhindert halbe Memory-Eintraege.
- Append-only Audit-Log fuer Skill-Ergebnisse unter
  `_memory/audit/capture-lesson.jsonl`.
- Mode-Files `autonomy.md` und `safe.md` enthalten die Lesson-Anker-Regel.
- Neuer Hook-Helper `tools/cortex-mode/bin/lesson_audit.py` fuer
  Welle-Ende-Persistenz-Audits.
- `tools/cortex-mode/bin/inject.sh` liest Hook-stdin und injiziert den
  Audit-Block bei Welle-Ende-Triggern.

### Verification

- `python3 -m compileall agent/skills/builtin/capture_lesson.py tools/cortex-mode/bin/lesson_audit.py`
- `bash -n tools/cortex-mode/bin/inject.sh`
- `cortex-agent skill run capture-lesson` Smoke: Insert, Update,
  bad-slug reject, missing-fields reject.
- `lesson_audit.py` Smoke: leerer stdin, Welle-Ende-Trigger,
  no-trigger.
- `inject.sh` Smoke mit Welle-Ende-Phrase.
- `git diff --check`
