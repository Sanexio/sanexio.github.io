# Lesson-Persistence — Konzept

> Status: **Implemented K1-K4 2026-05-13** (Bugs-Welle-Folge Dr. Stracke)
> Zweck: schließt die strukturelle Drift-Quelle „WAS GELERNT-Bullets
> im Welle-Ende-Debrief sind nur Konversation, nicht persistent". Erzwingt
> dass jede Lesson entweder strukturell verankert oder explizit als
> ephemer markiert wird, bevor eine Welle als abgeschlossen gilt.

---

## §0 Incident — was die Lücke sichtbar gemacht hat

In jeder Welle schreibe ich „WAS GELERNT"-Bullets in den Welle-Ende-Debrief.
Diese leben **nur in der Konversation**. Wenn ich nicht aktiv eine
`feedback_*.md` / Spec / CLAUDE.md-Edit anlege, ist die Lesson nach
Session-Ende verloren — derselbe Fehler kann in einer Folge-Session
wieder auftreten.

Sichtbar gemacht durch User-Frage am 2026-05-13: „Die ganzen Dinge, die du
hier angeblich gelernt hast, fließen die dann auch in die zukünftigen
Tasks ein oder machst du die Fehler dann immer wieder?"

Konkrete Detail-Lessons aus der Bugs-Welle 2026-05-13 wurden erst NACH
dieser User-Frage als `feedback_*.md` festgehalten — vorher waren sie nur
Welle-Ende-Bullets. Drift war real.

---

## §1 Leitprinzipien

1. **Lessons brauchen einen Träger.** Eine echte Lesson ist entweder
   strukturell (Hook, Skill, CLAUDE.md-Edit, Spec) oder textuell
   (`feedback_*.md` mit Why+How-to-apply) verankert. Pure Welle-Ende-
   Bullets ohne Träger zählen nicht.
2. **Ephemere Lessons sind erlaubt — aber müssen markiert sein.** Nicht
   jede Beobachtung ist persistenz-würdig. Was nur den aktuellen
   Session-Kontext betrifft, wird explizit als `(ephemer)` markiert.
3. **Strukturell schlägt textuell.** Ein Hook der den richtigen Reminder
   bei Trigger automatisch injiziert ist robuster als eine Memo, die
   gelesen werden muss. Wo machbar: strukturell.

---

## §2 Verbindlicher Welle-Ende-Workflow

Aktueller Stand (Autonomy-Mode-File):
```
Welle-Ende-Debrief in 3 Blöcken: WAS GEMACHT · WAS GELERNT · STRATEGISCHE WAHLEN.
Default-Welle-Ende: nur „WAS GEMACHT", die anderen Blöcke nur wenn etwas
substantielles vorliegt.
```

Erweiterung (R2-Mode-File-Edit):

> Jeder Bullet im „WAS GELERNT"-Block hat einen Persistenz-Anker am
> Zeilen-Ende:
> - `→ feedback_<slug>.md` — Memory-Eintrag wurde in dieser Welle geschrieben
> - `→ specs/<slug>/`     — Spec-Update / neue Spec
> - `→ CLAUDE.md`         — Regel-Edit in einer der drei CLAUDE.md
> - `→ hook:<name>`       — strukturelle Absicherung im Mode-Hook
> - `(ephemer)`           — bewusst nur Session-Kontext, kein Träger
>
> Ohne Anker = unvollständiger Welle-Ende-Debrief = Welle gilt als
> nicht abgeschlossen.

---

## §3 `capture-lesson`-Skill

Neuer Skill `agent/skills/builtin/capture_lesson.py`. Schreibt eine Lesson
als `feedback_*.md` (oder `project_*.md` / `reference_*.md`) ins User-
Auto-Memory plus MEMORY.md-Index-Eintrag.

```bash
cortex-agent skill run capture-lesson --args '{
  "kind": "feedback",
  "slug": "multi_ai_connexio_diagnose",
  "title": "Vor Codex-schläft-Diagnose Branches + Mirror prüfen",
  "description": "Diagnose-Reihenfolge wenn ein Connexio-Handoff angeblich nicht angekommen ist",
  "rule": "Audit-Log auf main reicht nicht — Status-Updates leben auf Codex-Branches",
  "why": "Am 2026-05-13 zweimal als schläft diagnostiziert obwohl Codex auf Branch geliefert hatte",
  "how_to_apply": "git branch -r grep agent, gh pr list, git show <branch>:tasks-mirror/<id>.json"
}'
```

**Schema (Pflicht-Felder):**
- `kind`: einer aus `feedback`, `project`, `reference`, `user`
- `slug`: snake_case-Slug
- `title`: einzeilig
- `description`: einzeilig für MEMORY.md-Hook
- `rule` (feedback/project): die eigentliche Regel/Fakt
- `why` (feedback/project): Begründung, oft mit Vorfall
- `how_to_apply` (feedback): wann/wo greift die Regel

**Schreibziel:** `~/.claude/projects/<project-slug>/memory/<kind>_<slug>.md`
mit Frontmatter exakt nach den Memory-Regeln aus dem System-Prompt
(`name`, `description`, `type`). MEMORY.md-Index automatisch ergänzt.

**Validierung:** Schreibt nichts wenn `slug` Pfad-Komponenten enthält,
Frontmatter unvollständig ist, oder Eintrag mit gleichem Namen bereits
existiert (in dem Fall: Update statt Insert, mit Diff-Log).

---

## §4 Hook-Erweiterung: Welle-Ende-Gate

`tools/cortex-mode/bin/inject.sh` injiziert bereits Mode + Tier-3 +
Local-First-Discovery. Erweiterung: bei Welle-Ende-Trigger (Prompt
enthält „Session beenden" / „Phoenix fortsetzen" / Welle-Abschluss-
Phrasen) wird ein Persistenz-Audit der laufenden Session injiziert.

```
=== Session Persistenz-Audit ===
Neue feedback_*.md in dieser Session: 2 (multi_ai_connexio_diagnose, local_first_discovery)
Neue specs: 1 (local-first-discovery)
CLAUDE.md-Edits: 2 (Nexus/CLAUDE.md, Cortex/CLAUDE.md)
Hook-Erweiterungen: 1 (inject.sh local_first_discovery)
Pending im Welle-Ende-Debrief: jede Lesson ohne Anker = unvollständig
```

Bei `safe-mode` blockiert das Welle-Ende, bis alle Lessons einen Anker
haben. Bei `autonomy` wird gewarnt (kein Block, weil durchziehen ist
core), aber im Debrief-Output gerendert.

---

## §5 Akzeptanzkriterien

1. ✅ `agent/skills/builtin/capture_lesson.py` schreibt korrekt
   Frontmatter + MEMORY.md-Update + Audit-Log. Tests: Insert, Update,
   bad-slug-rejection, missing-fields-rejection.
2. ✅ Mode-Files `agent/modes/autonomy.md` + `safe.md` enthalten die §2-
   Regel (Lesson-Anker am Bullet-Ende, sonst unvollständig).
3. ✅ `tools/cortex-mode/bin/inject.sh` erkennt Welle-Ende-Trigger und
   injiziert §4-Persistenz-Audit-Block.
4. ✅ Helper-Script `tools/cortex-mode/bin/lesson_audit.py`: scant in der
   aktuellen Session geänderte Memory-Files + Specs + CLAUDE.md-Diffs
   (via git diff --since-session-start, Marker via launchctl-Sentinel).
5. ⏳ Nachgelagert (R1-Folge): `session-end`-Skill um Lesson-Anker-
   Validierung erweitern. Bei Lessons ohne Anker → automatischer
   capture-lesson-Vorschlag.

---

## §6 Nicht-Ziele

- Automatische LLM-basierte Lesson-Extraktion aus Welle-Ende-Bullets
  (zu fehleranfällig, oft Kontext-spezifische Beobachtungen).
- Lessons aus Codex/Cursor sessions — die nutzen Connexio-Inbox bereits;
  ihre eigenen Lessons sind out-of-scope, sie nutzen ihre eigenen
  Memory-Surfaces.

---

## §7 Anweisung an Codex (operativ)

1. Implementiere `capture-lesson`-Skill nach §3-Spec. Frontmatter-Format
   exakt aus dem Memory-System ableiten (siehe bestehende `feedback_*.md`
   im User-Auto-Memory unter
   `~/.claude/projects/-Users-cluster-mini-02-Cortex/memory/`).
2. Erweitere `autonomy.md` + `safe.md` Mode-Files um §2-Regel. Sprache:
   konsistent mit dem bestehenden Welle-Ende-Block.
3. Erweitere `inject.sh` analog zum Local-First-Discovery-Pattern
   (sentinel-File für „in Session geänderte Files" via launchd-marker
   oder einfach `git status --since-session`).
4. Verification:
   - `capture-lesson`-Skill End-to-End: 1 Insert + 1 Update + 1 reject
   - Mode-File: bash-syntax-check der enthaltenen Skripte
   - Hook: Smoke-Run mit Welle-Ende-Phrase, prüfe Output
   - `git diff --check`
5. PR analog #1 mit `requires_human_approval=True`.

---

## §8 Codex-Implementierung 2026-05-13

- `agent/skills/builtin/capture_lesson.py` implementiert Insert/Update,
  Slug- und Pflichtfeld-Validierung, Frontmatter mit `name`/`description`/
  `type`, MEMORY.md-Indexpflege und Audit-Log.
- `agent/modes/autonomy.md` und `agent/modes/safe.md` enthalten die
  Lesson-Anker-Regel fuer `WAS GELERNT`; Safe Mode blockiert, Autonomy
  rendert die Warnung sichtbar.
- `tools/cortex-mode/bin/lesson_audit.py` rendert einen scriptbaren
  Persistenz-Audit-Block aus Hook-JSON oder leerem stdin.
- `tools/cortex-mode/bin/inject.sh` liest Hook-stdin und injiziert den
  Audit-Block bei Welle-Ende-Triggern.

Offen bleibt §5.5 als R1-Folge: `session-end`-Skill mit automatischer
Lesson-Anker-Validierung und capture-lesson-Vorschlag.
