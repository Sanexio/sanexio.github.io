# Architecture-Refactor 2026-05 — Audit

> **Stand:** 2026-05-16 (Audit-Phase).
> **Anlass:** User-Anmerkungen in der Tutorial-Welle-1-Review (2026-05-15/16):
> Memory-/Regelwerk-Architektur ist überbläht, mehrere Quellen widersprechen
> sich, Public-Skeleton-Tauglichkeit für das Sanexio-Geschäftsmodell muss
> vorbereitet werden.
> **Methode:** Read-only Audit aller Kern-Steuerdateien, Specs und Skills.

## Executive Summary

1. **Drei Quellen sprechen über dasselbe.** Tier-3/R0-R3/Mode-Stoff existiert
   in mindestens fünf Trägern parallel (`AUTONOMY_CONTRACT.md`, `agent/modes/*.md`,
   `agent/memory/golden_rules.py`, mehrere Specs). **Tatsächliche Drift ist da**
   — Tier-3-Definition in `tier3.md` (3 Kategorien) ist enger als in
   `AUTONOMY_CONTRACT.md` §2 (7 Items) und in `golden_rules.py` (5 Items).

2. **Drei Welten von „Skills".** `agent/skills/builtin/*.py` (Python),
   `Nexus/skills/*.skill` (Claude-Code-Pakete) und `~/.claude/skills/`
   (installierte Variante). CLAUDE.md und SYSTEM_MAP.md zeigen je eine andere,
   keine erklärt den Unterschied.

3. **Pflicht-Lese-Plan nennt Pfade, die nicht (mehr) existieren.** Vier
   Steuerdateien verweisen auf `_archive/phoenix-pre-reset/golden_rules_essence.md`
   und `full-snapshot.tar.gz`, die in `_archive/phoenix-pre-reset/` lokal
   nicht (mehr) vorhanden sind. **Geister-Pointer.**

4. **Stracke-Spezifisches ist verstreut.** Praxis-Geräte-Tabelle in `USER.md`,
   dieselbe in `CLAUDE.md`, abweichend in `multi-device-multi-ai/00_KONZEPT.md`,
   authoritativ in `.config/devices.json`. SmartQ/Patient/Praxis-DSGVO-Bezüge
   verstreut. **Ein generisches Public-Skeleton lässt sich heute nicht sauber
   destillieren** — User-spezifisches muss aus mehreren Files herausgelöst werden.

5. **Implizite Spezial-Vokabel ohne Erklärung.** ~20 Begriffe in der
   Pflicht-Lesung ohne Definition (R0–R3, Tier-3, Welle, Phoenix, Lean v3,
   Hook, Lease, Heartbeat, FTS5, MCP, Connexio, Cron-Recipe, Approval-Marker,
   Wikilink, Outbox, Daemon, LaunchAgent, JSON, Spawn, Skill in zwei Bedeutungen).

---

## A. Duplikate (Auszug, vollständig in Audit-Detail)

| Datei A | Datei B/C | Was doppelt? | SSOT-Vorschlag |
|---|---|---|---|
| `_rules/AUTONOMY_CONTRACT.md` §2 | `specs/claude-codex-cooperation/00_KONZEPT.md` §4 | R0–R3-Definition | AC §2 |
| `_rules/AUTONOMY_CONTRACT.md` §2 R3-Liste | `agent/modes/tier3.md` | Tier-3-Hardstops mit Drift | Konflikt B1 |
| `_rules/AUTONOMY_CONTRACT.md` §2 R3-Liste | `agent/memory/golden_rules.py` TIER_3_HARDSTOPS | Dritte Variante | Konflikt B1 |
| `agent/modes/autonomy.md` Welle-Ende-Block | `agent/modes/safe.md` Welle-Ende-Block | Wortgleich kopiert | `_rules/lesson-anchors.md` |
| `CLAUDE.md` Geräte-Tabelle | `_memory/USER.md` Geräte-Tabelle | Hostname/Rolle/Projekte | `.config/devices.json` |
| `_rules/AUTONOMY_CONTRACT.md` §11+§12 | `CLAUDE.md` Multi-Device-Abschnitt | Multi-AI-Boundaries | AC §11+§12, CLAUDE.md → Pointer |
| `nexus-sync.sh` + 3 Specs + `CLAUDE.md` | – | Sync-Erklärung an 5 Stellen | `_rules/sync-policy.md` neu |
| `HANDOVER_PHOENIX.md` Tier-3-Genehmigungsliste | 3 oben + dies = vierte Tier-3-Variante | Snapshot-Drift | Snapshot-State markieren |

(20+ konkrete Stellen identifiziert.)

## B. Widersprüche

- **B1 Tier-3-Scope:** `tier3.md` (3 Kategorien, Negativliste) vs. AC §2 (7 Items, inkl. destruktive Git-Ops) vs. `golden_rules.py` (5 Items inkl. „Live-Deploys"). Die User-Direktive 2026-05-09 (pauschale Freigabe in `~/Cortex/`) ist in tier3.md sauber dokumentiert, in den anderen Quellen nicht nachgezogen.
- **B2 Stop-Bedingungen:** `autonomy.md` listet 4 Stops, AC §7 listet 9.
- **B3 „Nexus exklusiv Claude" vs. „Codex darf Vorschlagen":** `multi-device-multi-ai` §1.2 (v1, exklusiv) vs. AC §12.9 (v2, Codex darf Vorschlagen).
- **B4 Outbox vs. Connexio vs. `.cortex/`:** AC §11 erwähnt projektlokales `.cortex/tasks/`, Lean v3 will Outbox auslaufen, Connexio ist neuer Pfad — drei parallele Mechanismen.
- **B5 „Sync funktioniert" vs. M5-Vorfall:** CLAUDE.md impliziert Erfolg, der Eskalations-Loch ist offen (Spec ist Stub).
- **B6 Geister-Pointer:** 4 Dateien verweisen auf zwei nicht-existente Archiv-Dateien.
- **B7 Skill-Disambiguierung:** SYSTEM_MAP zeigt eine Welt, CLAUDE.md eine andere.

## C. Überfüllte Dateien

| Datei | Heute | Kern-Funktion | Vorschlag |
|---|---|---|---|
| `_rules/AUTONOMY_CONTRACT.md` | 504 Zeilen / 13 KB, 12 Kapitel | Vertrag + Mode-Matrix + Task-Schema + AI-Cooperation + Multi-AI-Boundaries + Retention + Verification | Aufspaltung in 10 fokussierte Files (~2 KB je) + Index |
| `CLAUDE.md` | 157 Zeilen / 6,4 KB | Session-Init + Stack + Geräte + Phoenix-Status + Local-First | Reduktion auf ~50 Zeilen, alles andere als Pointer |
| `_memory/USER.md` | 45 Zeilen mit gemischtem Stoff | Profil + Geräte + Sicherheit + Domäne | Reduktion auf ~30 Zeilen reines Profil |
| `agent/modes/autonomy.md` | 86 Zeilen | Mode-Briefing + User-Direktive + Lesson-Block | ~50 Zeilen + Auslagerung |
| `agent/memory/golden_rules.py` | 135 Zeilen, hardkodierte Listen | Renderer + Tier-3-Liste + Bug-Patterns + LL→R-Mapping | Parser statt Daten, Bug-Liste als Markdown |

## D. Fehlende Erklärungen — Glossar-Pflicht

Erkannte Begriffe ohne Erklärung in der Pflicht-Lesung: **R0–R3, State-First, Lease, Hook, Tier 3, Welle, Phoenix, Lean v3, FTS5, MCP, Connexio, Heartbeat, Approval-Marker, LaunchAgent, Wikilink, Cron-Recipe, Spawn, Outbox, Skill (zwei Welten)**. Vorschlag: `_rules/glossary.md` (~50 Zeilen, ein Begriff pro Zeile) wird Pflicht-Lese-Datei Nr. 3.

## E. Skills-Auffindbarkeit

- Drei Skill-Welten, keine erklärt den Unterschied.
- Keine Skill→Trigger-Map; Discovery nur per `cortex-agent skill list`.
- SYSTEM_MAP zeigt falsches Verzeichnis.
- Keine semantischen Verbindungen zwischen Skills (z.B. `capture_lesson` ↔ `session_end`).

Vorschlag: `agent/skills/INDEX.md` (auto-generiert von doctor-Skill) + Trigger-Annotationen im `@skill`-Decorator + `agent/workflows/*.yaml` für Skill-Ketten.

## F. Public-Skeleton-Mapping

Nach Refactor:
- **~80 % der Kern-Dateien sind Public-tauglich** (✅ generisch oder 🔧 leicht generalisierbar).
- **~20 % bleibt Stracke-Layer** (🔒 USER-Profil, devices.json, Praxis-Specs, Phoenix-Snapshots).

Saubere Trennung möglich durch:
- `_memory/USER.md` → nur Profil; Geräte-Tabelle weg.
- `_rules/user-directives.md` (Stracke-spezifisch, Hook injiziert).
- `_rules/security.md`, `_rules/medical-domain.md` (Stracke-only).
- doctor.py + tutorial_curator.py: Pfade aus Config statt hardcoded.
- Beispiele in tier3.md und golden_rules.py anonymisieren.

---

## Zielzustand-Schema (Vorschlag)

### Pflicht-Lesung (klein, generisch, public-tauglich)

```
CLAUDE.md                    ~50 Zeilen  Lead-In + Init-Workflow + Pointer
_rules/CORE.md               ~40 Zeilen  R0-R3 1-Satz-je-Level + Hierarchie
_rules/glossary.md           ~50 Zeilen  ~20 Begriffsdefinitionen
SYSTEM_MAP.md                ~80 Zeilen  Wo finde ich was
```

### Regel-Familie (on-demand, fokussiert)

```
_rules/risk-levels.md            R0-R3 Volldetail
_rules/modes.md                  Mode × Risiko-Matrix
_rules/stop-conditions.md        9 Stops + Anti-Drift-Phrasen
_rules/tasks.md                  State-Machine + Pflichtfelder + Pre-Flight
_rules/ai-cooperation.md         Claude×Codex-Peer-Modell
_rules/multi-ai-boundaries.md    Connexio-Bridge für andere KIs
_rules/tier3.md                  Single Source der Hardstop-Liste
_rules/retention.md              Logs, Queues, Audit-TTL
_rules/verification.md           Pre-done-Checks
_rules/lesson-anchors.md         Persistenz-Anker (heute dupliziert)
_rules/sync-policy.md            Heartbeat, Auto-Resolve, Re-Alarm
```

### Stracke-Layer (private, public-Variante ist Template)

```
_memory/USER.md                  reines Profil (~30 Zeilen)
_memory/KNOWLEDGE.md             Vault-Pointer-Index
_memory/recurring-bugs.md        GF-001..007 (heute hardkodiert in Python)
_rules/user-directives.md        User-Direktive 2026-05-09
_rules/security.md               Stracke-Sicherheitsregeln
_rules/medical-domain.md         Praxis-/Patient-Tags
.config/devices.json             Mac-Inventar (authoritativ)
```

### Skills + Workflows

```
agent/skills/engine.py
agent/skills/INDEX.md            auto-generiert: name|trigger|needs|related
agent/skills/builtin/*.py        (13 heute, mit Trigger-Annotationen)
agent/workflows/welle-ende.yaml  Skill-Ketten für wiederkehrende Abläufe
agent/workflows/session-start.yaml
```

### Effekt

- Pflicht-Lesung sinkt von heute 661 Zeilen auf ~120 (-82 %).
- Single-Sources-of-Truth pro Thema.
- Drift strukturell unmöglich gemacht (Tier-3 wird vom Hook UND vom Python aus derselben markdown gelesen).
- Public-Skeleton liegt 1 Refactor weit entfernt.

---

## Migrations-Empfehlung (priorisiert)

### Priorität 1 (sofort, low-risk, high-effect)

1. **Geister-Pointer beheben.** 4 Steuerdateien verweisen auf nicht-existente Archiv-Files. Entweder restoren oder Verweise entfernen.
2. **Glossar einführen.** `_rules/glossary.md` mit ~20 Begriffen. Pflicht-Lesung erweitern.
3. **Tier-3 als Single Source.** `golden_rules.py.TIER_3_HARDSTOPS` ersetzen durch Parser, der `tier3.md` liest. AC §2 R3-Liste auf 1-Satz-Verweis kürzen.

### Priorität 2 (mittelfristig, strukturell)

4. **AUTONOMY_CONTRACT.md aufspalten** in 8–10 fokussierte `_rules/*.md`-Files.
5. **autonomy.md / safe.md aufräumen** (Stop-Liste, User-Direktive, Lesson-Block).
6. **Skill-INDEX.md generieren** über doctor-Skill.

### Priorität 3 (Public-Skeleton-Vorbereitung)

7. **User-Layer auslagern** (USER.md reduzieren, doctor.py/tutorial_curator.py auf config-Pfade).
8. **Skill-Disambiguierung** (Nexus/skills/ vs. agent/skills/builtin).
9. **Spec-Konsolidierung Sync** (3 Specs → 1).

### Wartet (Spec-Abhängigkeiten)

10. Lean v3 L5 (Outbox-Frist 2026-06-12).
11. Lean v3 L4 (Memory-TTL pro Mac).
12. `sync-alarm-escalation` von Stub zu Implementierung.
