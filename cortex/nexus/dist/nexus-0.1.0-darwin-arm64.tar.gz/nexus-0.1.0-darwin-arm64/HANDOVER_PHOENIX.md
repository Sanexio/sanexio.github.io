# HANDOVER — Phoenix-Reset

> **Snapshot-Dokument vom 2026-05-09, Cluster-Mini-02.** Welle 0 bis 8
> abgeschlossen. Diese Datei ist die historische Bedienungs- und
> Verifikations-Anleitung für die Phoenix-Migration. Einige der hier
> referenzierten lokalen Snapshot-Pfade (`_archive/phoenix-pre-reset/
> full-snapshot.tar.gz`, `golden_rules_essence.md`) sind gitignored und
> daher Mac-spezifisch unterschiedlich vorhanden — vollständig nur auf
> Cluster-Mini-02. Aktive Quelle für die destillierten Goldenen Regeln:
> **`_memory/golden-rules.md`**. Notfall-Rollback nach Phoenix: GitHub-Branch
> **`pre-phoenix-reset-2026-05-08`**.

---

## §1 Was ist Phoenix?

Radikaler Reset des Nexus-Steuerwerks (`_rules/`, altes `_memory/`, alle
`tools/cortex-*` inkl. telegram-bridge V2). Ersetzt durch einen schlanken,
zweischichtigen Stack:

- **`agent/` (Python)** — Hermes-style Agent-Loop mit FTS5-Memory,
  Skills-Engine, Modes (autonomy / safe), Provider-Adapter (Anthropic).
- **`gateway/` (TypeScript / Bun)** — OpenClaw-style Channel-Router mit
  Pairing, Sandbox-Stub und Telegram-V3 als First Channel (MCP-Server +
  Long-Polling, Tool `reply()`).

Unverändert: `Second Brain/30 Tutorials/` (Wissens-Anker), `_lib/`,
`~/Cortex/projects/`, `~/.claude/skills/`.

---

## §2 Vorbedingungen

| Check                                       | Befehl                                                                |
|---------------------------------------------|-----------------------------------------------------------------------|
| Backup-Branch existiert auf `origin`        | `git -C ~/Cortex/Nexus branch -a \| grep pre-phoenix-reset-2026-05-08` |
| Tarball vorhanden                           | `ls ~/Cortex/Nexus/_archive/phoenix-pre-reset/full-snapshot.tar.gz`   |
| Goldene Regeln destilliert                  | `ls ~/Cortex/Nexus/_archive/phoenix-pre-reset/golden_rules_essence.md` |
| Telegram-Bridge V3 registriert              | `claude mcp list \| grep telegram-bridge`                              |
| ANTHROPIC_API_KEY gesetzt (für `cortex-agent run`) | `echo "${ANTHROPIC_API_KEY:0:8}…"`                              |

---

## §3 Wellen-Status

- [x] **Welle 0** — Backup & Safety Net (`ca78a00` + Branch `pre-phoenix-reset-2026-05-08`)
- [x] **Welle 1** — Hard-Delete (`4c3708a`, 431 Files / -46 500 LOC)
- [x] **Welle 2** — Hermes-Layer (`8c65590`, +1 924 LOC)
- [x] **Welle 3** — Built-in Skills Mini + LaunchAgents-Cleanup (`66973af`)
- [x] **Welle 4** — Gateway-Layer (`7c483a1`)
- [x] **Welle 5** — Telegram V3 + Cutover (`1ff1c8f`, Live-Push verifiziert)
- [x] **Welle 6** — Mode-Hook + finale CLAUDE.md (`62ba1d9`)
- [x] **Welle 7** — diese Datei
- [ ] **Welle 8** — End-to-End-Verifikation (folgt)

---

## §4 End-to-End-Verifikation (Welle 8 — auszuführen)

| # | Test | Befehl | Erwartung |
|---|------|--------|-----------|
| 1 | Mode-Switch | `cortex-agent mode set safe && cortex-agent mode get && cortex-agent mode set autonomy` | `safe` und dann `autonomy` |
| 2 | Memory persistiert | `cortex-agent memory add-fact contact phone "+49 1234"` → neue Session → `cortex-agent memory facts --kind contact` | enthält `+49 1234` |
| 3 | Skill-Liste | `cortex-agent skill list` | 3 Skills (curator, doctor, scheduler) |
| 4 | Doctor 10/10 | `cortex-agent skill run doctor` | nur die `Git-Workspace`-Zeile darf failen, wenn ungetrackte Files vorhanden |
| 5 | Telegram-Push | `mcp__telegram-bridge__reply chat_id=8547497426 text="Phoenix-V3-Test"` | Push erscheint auf iPhone |
| 6 | Inbound `/status` | iPhone → `/status` an `@sanexio_bot` | Bot antwortet mit Geräte-Info |
| 7 | Tier-3-Hardstop | beliebiger `git push --force` durch Claude | Hardstop, User-Freigabe verlangt |
| 8 | Vault unangetastet | `git -C ~/Cortex/Nexus diff pre-phoenix-reset-2026-05-08..main -- 'Second Brain/' '_tutorials/'` | leer |
| 9 | Geräte-Sync | SSMD-MacBookPro: `cd ~/Cortex/Nexus && git pull` | sauber, dann Tests 1+2+5 dort |
| 10 | Init-Tokens | `cortex-agent bootstrap --no-pull` | System-Block ≤ 2 000 Tokens |

---

## §5 Notfall-Rollback (full restore)

```bash
# 1. Phoenix-Stack stoppen
launchctl bootout gui/$(id -u) ~/Library/LaunchAgents/com.cortex.*.plist 2>/dev/null
claude mcp remove telegram-bridge -s user

# 2. Branch zurück auf Pre-Phoenix
cd ~/Cortex/Nexus
git fetch origin pre-phoenix-reset-2026-05-08
git checkout pre-phoenix-reset-2026-05-08
git branch -D main
git checkout -b main
git reset --hard pre-phoenix-reset-2026-05-08

# 3. Tarball-Files restoren (überschreibt agent/ und gateway/)
tar xzf _archive/phoenix-pre-reset/full-snapshot.tar.gz

# 4. LaunchAgents zurück
cp _archive/phoenix-pre-reset/launchagents/*.plist ~/Library/LaunchAgents/
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.cortex.nexus-sync.plist

# 5. Telegram-V2 MCP re-registrieren
set -a; source _archive/phoenix-pre-reset/telegram-bridge-state/.env.snapshot; set +a
claude mcp add -s user telegram-bridge \
  -e "TELEGRAM_BOT_TOKEN=$TELEGRAM_BOT_TOKEN" \
  -e "TELEGRAM_ALLOWED_CHAT_IDS=$TELEGRAM_ALLOWED_CHAT_IDS" \
  -- bun run /Users/cluster-mini-02/Cortex/Nexus/tools/telegram-bridge/telegram-channel.ts
```

⚠️ Schritt 2 (`reset --hard`) ist Tier-3 — nur mit explizitem User-OK ausführen.

---

## §6 Tier-3-Genehmigungsliste

Aktionen, die NICHT ohne User-OK ausgeführt werden dürfen (auch in Auto-Mode):

| Aktion | Wann nötig | Begründung |
|--------|------------|------------|
| `git push origin main` | nach Phoenix-Reset, vor Geräte-Sync | aktueller `main` enthält 7 Phoenix-Commits, die SSMD/Mac-Studio noch nicht haben — pushen würde sie ungewollt synchronisieren |
| `git push --force` jeglicher Art | nie automatisch | destruktiv |
| `claude mcp add/remove` | bei Bridge-Wechsel | modifiziert `~/.claude.json` |
| `.env`-Mutationen | bei Token-Rotation | Secret-Mutation |
| `rm -rf` von Production-Verzeichnissen | nie automatisch | destruktiv |
| LaunchAgent-Reinstall | nach Sprint-2-Skills | Daemon-Verhalten ändern |

---

## §7 Sprint-2-Backlog (offen)

### Skills (in `agent/skills/builtin/`)

- [ ] **sanitizer** — Token-Cap-Enforcement, Memory-DB-Vacuum
- [ ] **pattern-miner** — LLM-basiertes Pattern-Mining aus erfolgreichen Sessions
- [ ] **tutorial-curator** — Vault-Drift-Audit, Broken-Link-Check, Numbering
- [ ] **vault-audit** — Cross-Sprache- und Cross-Page-Konsistenz
- [ ] **session-search** — Volltext-Suche über alle Sessions im FTS5-Index
- [ ] **session-end** — Welle-Ende-Debrief + Session-Summary in Memory

### Gateway

- [ ] **MCP-Permission-Notifications** — yes/no-Verdicts via Telegram (V2-Feature)
- [ ] **Sandbox-Backends** — Docker, SSH (heute: nur subshell)
- [ ] **Spawn/Pause/Resume-Handler** — wie V2
- [ ] **Slack/Signal-Channels** — Channel-Plugin-Pattern erweitern
- [ ] **Companion-Apps** — macOS-MenuBar, iOS (OpenClaw-Pattern, sehr groß)

### Cron-Replacement

- [ ] **Phoenix-Cron** — neue LaunchAgents, die `cortex-agent skill run …`
  aufrufen (statt der gelöschten Bash-Skripte). Recipes als YAML in
  `agent/skills/cron/`.
- [ ] **nexus-sync re-implementiert** — als Phoenix-Cron-Recipe, mit
  Tier-3-Schutz (kein automatischer push ohne explizite Recipe-Flag).

### Aufräumen

- [ ] `~/Cortex/.claude/hooks/check-nexus-drift.sh` — referenziert ggf.
  gelöschte Pfade, prüfen + ggf. neu schreiben
- [x] `bootstrap.sh`, `migrate.sh`, `requirements-nexus.txt` —
  archiviert nach `_archive/phoenix-pre-reset/scripts/` (2026-05-09 / C4)
- [x] `_archive/phoenix-pre-reset/upstream/openclaw/` + `hermes-agent/`
  (zusammen 242 MB) — geloescht (2026-05-09 / C4); Architektur-Lehren
  bereits in agent/connexio + gateway/ baked-in
- [x] `nexus-sync.sh` ersetzt durch Phoenix-Cron-Recipes
  `agent/cron/recipes/{nexus-pull,nexus-push}.toml` (2026-05-09 / C4)

---

## §8 Sofort-Aufgabe für die nächste Session

1. **Pre-Pull**: `cd ~/Cortex/Nexus && git pull --ff-only`
2. **Doctor**: `cortex-agent skill run doctor` — alle 10 ✓ erwartet
3. **Welle 8 §4 Tabelle abarbeiten** — Tests 1-10 grün setzen
4. **Geräte-Sync** (Tier-3): `git push origin main` mit User-OK,
   dann auf SSMD-MacBookPro + Mac-Studio: `git pull --ff-only`
5. Bei Erfolg: ersten Sprint-2-Punkt aus §7 wählen

---

## §9 Pre-Phoenix-Wissen (wo nachschlagen)

- `_archive/phoenix-pre-reset/golden_rules_essence.md` — destillierte
  LL-Essenz (227 Zeilen) — Quelle für `agent/memory/golden_rules.py`
- `_archive/phoenix-pre-reset/full-snapshot.tar.gz` (17 MB) — komplettes
  Vor-Reset-Archiv: `tar tzf … | grep <pfad>`
- `_archive/phoenix-pre-reset/telegram-bridge-state/` — V2-State + .env-Snapshot
  + claude.json-Snapshot + cortex-mode.json-Snapshot
- `_archive/phoenix-pre-reset/launchagents/` — alte com.cortex.*-Plists
- `_archive/phoenix-pre-reset/scripts/` — Pre-Phoenix bootstrap.sh,
  migrate.sh, requirements-nexus.txt (2026-05-09 archiviert)
- Backup-Branch `pre-phoenix-reset-2026-05-08` auf `origin` — Git-Historie
  bis zum Reset
