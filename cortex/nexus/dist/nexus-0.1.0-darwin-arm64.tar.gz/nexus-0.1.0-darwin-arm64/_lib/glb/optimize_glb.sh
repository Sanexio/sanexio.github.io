#!/usr/bin/env bash
# optimize_glb.sh — Reduces .glb file size for fast web delivery (model-viewer / three.js).
#
# Pipeline (gltf-transform):
#   - dedup, prune, weld, resample
#   - texture resize (default 512px) + WebP compression
#   - NO mesh compression (EXT_meshopt_compression breaks model-viewer's
#     CDN bundle from unpkg — meshopt decoder is not auto-loaded there)
#
# Typical result: 4-5 MB Avaturn/Mixamo export → ~1 MB (textures dominate)
#
# Usage:
#   optimize_glb.sh <input.glb> [output.glb] [texture_size]
#
# Examples:
#   optimize_glb.sh ~/Downloads/model.glb
#       → writes model_opt.glb next to input, 512px textures
#   optimize_glb.sh ~/Downloads/model.glb /tmp/avatar.glb 256
#       → custom output path, 256px textures (more aggressive)
#
# Requirements: node + npx (uses npx --yes @gltf-transform/cli, no global install).

set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <input.glb> [output.glb] [texture_size]" >&2
  exit 1
fi

INPUT="$1"
if [[ ! -f "$INPUT" ]]; then
  echo "Error: input file not found: $INPUT" >&2
  exit 1
fi

# Default output: <input>_opt.glb in same directory
DEFAULT_OUT="${INPUT%.glb}_opt.glb"
OUTPUT="${2:-$DEFAULT_OUT}"
TEX_SIZE="${3:-512}"

# Load nvm if present (gltf-transform needs node)
if [[ -s "$HOME/.nvm/nvm.sh" ]]; then
  # shellcheck disable=SC1091
  source "$HOME/.nvm/nvm.sh"
fi

if ! command -v npx >/dev/null 2>&1; then
  echo "Error: npx not found. Install Node.js (e.g. via nvm)." >&2
  exit 1
fi

echo "▶ Optimizing: $INPUT"
echo "  → output:    $OUTPUT"
echo "  → textures:  ${TEX_SIZE}px WebP"
echo

npx --yes @gltf-transform/cli@latest optimize \
  "$INPUT" "$OUTPUT" \
  --texture-compress webp \
  --texture-size "$TEX_SIZE" \
  --simplify false \
  --compress false

echo
echo "✓ Done."
ls -lh "$INPUT" "$OUTPUT" | awk '{printf "  %-12s %s\n", $5, $NF}'
