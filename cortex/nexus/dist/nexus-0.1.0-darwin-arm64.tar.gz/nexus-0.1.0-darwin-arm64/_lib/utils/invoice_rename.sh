#!/bin/bash
# invoice-rename-v3.sh – Rechnungs-Umbenennungsskript V3
# Neuer Algorithmus: Alle Dateien verarbeiten, nur sinnvoll benennen
# Keine Ausschlusskriterien, nur korrekte Bezeichnung
#
# Nutzung:
#   ./invoice-rename-v3.sh    - Verarbeitet alle PDFs im Import-Verzeichnis
#
# ============================================================================
# GRUNDPRINZIPIEN - WICHTIG FÜR WEITERE ENTWICKLUNG
# ============================================================================
# Dieses Skript ist ein ERKLÄRENDES Skript. Bei allen Änderungen müssen
# folgende Prinzipien beachtet werden:
#
# 1. ERKLÄRUNGEN MÜSSEN VORHANDEN SEIN
#    - Jeder Verarbeitungsschritt muss mit erklärenden Ausgaben versehen werden
#    - Die Erklärungen erklären, was der Schritt macht und warum er wichtig ist
#
# 2. BENUTZERFREUNDLICHE AUSGABEN
#    - Alle Ausgaben müssen klar und verständlich sein
#    - Farbcodierung wird verwendet für bessere Lesbarkeit
#
# 3. STRUKTUR BEIBEHALTEN
#    - Die bestehende Struktur darf nicht grundlegend geändert werden
#    - Erklärungen sind Teil der Struktur, nicht optional
#
# 4. FEHLERBEHANDLUNG MIT ERKLÄRUNGEN
#    - Bei Fehlern muss erklärt werden, was schiefgelaufen ist
#    - Lösungsvorschläge müssen gegeben werden
#
# 5. PROTOKOLLIERUNG
#    - Wichtige Aktionen sollten protokolliert werden
#    - Am Ende sollte eine Zusammenfassung ausgegeben werden
#
# 6. WICHTIG: Diese Prinzipien sind NICHT optional - sie sind Teil der
#    Funktionalität des Skripts. Das Skript soll nicht nur umbenennen,
#    sondern auch LEHREN, wie Dokumentenverarbeitung funktioniert.
# ============================================================================

set -e

# === Konfiguration ===
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IMPORT_DIR="$SCRIPT_DIR/Invoice_Rename/import"
OUTPUT_DIR="$SCRIPT_DIR/Invoice_Rename/output"
DEBUG_DIR="$SCRIPT_DIR/Invoice_Rename/debug"

# Erstelle Verzeichnisse
mkdir -p "$IMPORT_DIR" "$OUTPUT_DIR" "$DEBUG_DIR"

# Farbcodierung
GREEN="\033[32m"; RED="\033[31m"; YELLOW="\033[33m"; BLUE="\033[34m"; CYAN="\033[36m"; MAGENTA="\033[35m"; NC="\033[0m"
ok(){ echo -e "${GREEN}✅ $*${NC}"; }
err(){ echo -e "${RED}❌ $*${NC}"; }
warn(){ echo -e "${YELLOW}⚠️  $*${NC}"; }
info(){ echo -e "${BLUE}ℹ️  $*${NC}"; }
explain(){ echo -e "${MAGENTA}📖 $*${NC}"; }
command(){ echo -e "${CYAN}🔧 Befehl: $*${NC}"; }
detail(){ echo -e "${CYAN}  → $*${NC}"; }

# === Logging-Funktionen ===
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$DEBUG_DIR/process_log.txt"
}

echo_status() {
    ok "$1"
}

echo_error() {
    err "$1"
}

# === Abhängigkeitsprüfung ===
check_dependencies() {
    explain "Abhängigkeitsprüfung: Das Skript benötigt bestimmte Tools, um PDFs zu verarbeiten. pdftotext extrahiert Text, gs (Ghostscript) komprimiert PDFs."
    local missing_deps=()
    
    # Erforderliche Tools
    for tool in pdftotext gs; do
        command "command -v $tool"
        if ! command -v "$tool" &>/dev/null; then
            missing_deps+=("$tool")
        else
            ok "$tool ist installiert"
        fi
    done
    
    # Optionale Tools
    local optional_tools=("tesseract" "pdftoppm" "magick" "convert")
    for tool in "${optional_tools[@]}"; do
        if command -v "$tool" &>/dev/null; then
            log "Optionale Abhängigkeit verfügbar: $tool"
        fi
    done
    
    if [[ ${#missing_deps[@]} -gt 0 ]]; then
        err "Fehlende Abhängigkeiten: ${missing_deps[*]}"
        explain "Die folgenden Tools fehlen und müssen installiert werden:"
        for tool in "${missing_deps[@]}"; do
            if [[ "$tool" == "pdftotext" ]]; then
                detail "  pdftotext: Teil von poppler - brew install poppler"
            elif [[ "$tool" == "gs" ]]; then
                detail "  gs (Ghostscript): brew install ghostscript"
            fi
        done
        exit 1
    fi
    ok "Alle Abhängigkeiten sind installiert"
}

# === Funktion zur Bereinigung von Sonderzeichen ===
clean_filename() {
    local filename="$1"
    # Entferne alle Sonderzeichen und ersetze durch Unterstriche
    echo "$filename" | sed 's/[^A-Za-z0-9]/_/g' | sed 's/__*/_/g' | sed 's/^_\|_$//g'
}

# === Neuer Algorithmus: Alle Dateien verarbeiten, nur sinnvoll benennen ===
get_document_type() {
    local pdf_content="$1"
    local filename="$2"
    local doc_type=""
    
    # Bestimme Dokumenttyp basierend auf Inhalt
    if echo "$pdf_content" | grep -qi "Rechnung\|Invoice\|Faktura"; then
        doc_type="Rechnung"
    elif echo "$pdf_content" | grep -qi "Mahnung\|Mahnschreiben"; then
        doc_type="Mahnung"
    elif echo "$pdf_content" | grep -qi "Kontoauszug\|Kontoauszüge"; then
        doc_type="Kontoauszug"
    elif echo "$pdf_content" | grep -qi "Lohnsteuerbescheinigung\|Lohnsteuerbescheid"; then
        doc_type="Lohnsteuerbescheinigung"
    elif echo "$pdf_content" | grep -qi "Meldebescheinigung"; then
        doc_type="Meldebescheinigung"
    elif echo "$pdf_content" | grep -qi "Arbeitsvertrag\|Honorarvertrag"; then
        doc_type="Vertrag"
    elif echo "$pdf_content" | grep -qi "Angebot\|Offer"; then
        doc_type="Angebot"
    elif echo "$pdf_content" | grep -qi "Parkticket\|Parking"; then
        doc_type="Parkticket"
    elif echo "$pdf_content" | grep -qi "Tankstelle\|Tank"; then
        doc_type="Tankstelle"
    elif echo "$pdf_content" | grep -qi "McDonald"; then
        doc_type="McDonald"
    elif echo "$pdf_content" | grep -qi "DocCheck"; then
        doc_type="DocCheck"
    elif echo "$pdf_content" | grep -qi "Rentenkompass"; then
        doc_type="Rentenkompass"
    elif echo "$pdf_content" | grep -qi "Bescheinigung\|Bescheid"; then
        doc_type="Bescheinigung"
    elif echo "$pdf_content" | grep -qi "Quittung\|Receipt"; then
        doc_type="Quittung"
    else
        # Fallback: Versuche aus Dateinamen zu erkennen
        if echo "$filename" | grep -qi "rechnung"; then
            doc_type="Rechnung"
        elif echo "$filename" | grep -qi "mahnung"; then
            doc_type="Mahnung"
        elif echo "$filename" | grep -qi "kontoauszug"; then
            doc_type="Kontoauszug"
        elif echo "$filename" | grep -qi "lohnsteuer"; then
            doc_type="Lohnsteuerbescheinigung"
        elif echo "$filename" | grep -qi "meldebescheinigung"; then
            doc_type="Meldebescheinigung"
        elif echo "$filename" | grep -qi "vertrag"; then
            doc_type="Vertrag"
        elif echo "$filename" | grep -qi "angebot"; then
            doc_type="Angebot"
        elif echo "$filename" | grep -qi "parkticket\|parking"; then
            doc_type="Parkticket"
        elif echo "$filename" | grep -qi "tankstelle\|tank"; then
            doc_type="Tankstelle"
        elif echo "$filename" | grep -qi "mcdonald"; then
            doc_type="McDonald"
        elif echo "$filename" | grep -qi "doccheck"; then
            doc_type="DocCheck"
        elif echo "$filename" | grep -qi "rentenkompass"; then
            doc_type="Rentenkompass"
        elif echo "$filename" | grep -qi "bescheinigung\|bescheid"; then
            doc_type="Bescheinigung"
        elif echo "$filename" | grep -qi "quittung"; then
            doc_type="Quittung"
        else
            doc_type="Dokument"
        fi
    fi
    
    echo "$doc_type"
}

# === OCR-Funktion ===
extract_text_with_ocr() {
    local file_path="$1"
    local temp_dir="$DEBUG_DIR/temp_ocr"
    local ocr_text=""
    
    if command -v tesseract &>/dev/null && command -v pdftoppm &>/dev/null; then
        mkdir -p "$temp_dir"
        if pdftoppm -png -r 300 -f 1 -l 1 "$file_path" "$temp_dir/page" 2>/dev/null; then
            log "OCR-Verarbeitung für: $(basename "$file_path")"
            for img in "$temp_dir"/page-*.png; do
                if [[ -f "$img" ]]; then
                    ocr_text=$(tesseract "$img" - -l deu+eng 2>/dev/null)
                    if [[ -n "$ocr_text" ]]; then
                        log "OCR erfolgreich für: $(basename "$file_path")"
                        break
                    fi
                fi
            done
            rm -f "$temp_dir"/page-*.png
        else
            log "PDF zu Bild Konvertierung fehlgeschlagen für: $(basename "$file_path")"
        fi
    fi
    
    echo "$ocr_text"
}

# === Datum-Extraktion ===
find_document_date() {
    local pdf_content="$1"
    local file_path="$2"
    local document_date=""
    local all_dates=()
    
    # Erweiterte Datum-Muster
    local date_patterns=(
        "Rechnungsdatum[^0-9]*([0-9]{1,2}[.-][0-9]{1,2}[.-][0-9]{4})"
        "Rechnung\s+Datum[^0-9]*([0-9]{1,2}[.-][0-9]{1,2}[.-][0-9]{4})"
        "Datum[^0-9]*([0-9]{1,2}[.-][0-9]{1,2}[.-][0-9]{4})"
        "Date[^0-9]*([0-9]{1,2}[.-][0-9]{1,2}[.-][0-9]{4})"
        "vom[^0-9]*([0-9]{1,2}[.-][0-9]{1,2}[.-][0-9]{4})"
        "den[^0-9]*([0-9]{1,2}[.-][0-9]{1,2}[.-][0-9]{4})"
        "am[^0-9]*([0-9]{1,2}[.-][0-9]{1,2}[.-][0-9]{4})"
        "Stand[^0-9]*([0-9]{1,2}[.-][0-9]{1,2}[.-][0-9]{4})"
    )
    
    # Suche nach expliziten Datumsfeldern
    for pattern in "${date_patterns[@]}"; do
        local found_dates=$(echo "$pdf_content" | grep -Eio "$pattern" | grep -Eo "[0-9]{1,2}[.-][0-9]{1,2}[.-][0-9]{4}")
        if [[ -n "$found_dates" ]]; then
            all_dates="$found_dates"
            break
        fi
    done
    
    # Fallback: Suche nach allen Datumsformaten
    if [[ -z "$all_dates" ]]; then
        local first_page_content=$(pdftotext -f 1 -l 1 "$file_path" - 2>/dev/null)
        if [[ -n "$first_page_content" ]]; then
            local line_count=$(echo "$first_page_content" | wc -l)
            if [[ "$line_count" -gt 0 ]]; then
                local search_lines=$((line_count / 2))
                if [[ "$search_lines" -lt 1 ]]; then
                    search_lines=1
                fi
                all_dates=$(echo "$first_page_content" | head -n "$search_lines" | grep -Eo "\b[0-9]{1,2}[.-][0-9]{1,2}[.-][0-9]{4}\b" | sort -r | head -n 10)
                local yyyy_dates=$(echo "$first_page_content" | head -n "$search_lines" | grep -Eo "\b[0-9]{4}[.-][0-9]{1,2}[.-][0-9]{1,2}\b" | sort -r | head -n 5)
                if [[ -n "$yyyy_dates" ]]; then
                    all_dates="$all_dates $yyyy_dates"
                fi
            fi
        fi
    fi
    
    # Überprüfung jedes Datums im angegebenen Intervall
    for date in $all_dates; do
        local year=$(echo "$date" | grep -Eo "[0-9]{4}" | head -n 1)
        if [[ "$year" -ge "$START_YEAR" && "$year" -le "$END_YEAR" ]]; then
            document_date="$date"
            break
        fi
    done
    
    # Fallback: Versuche Datum aus Dateinamen zu extrahieren
    if [[ -z "$document_date" || "$document_date" == "UNKNOWN" ]]; then
        local filename=$(basename "$file_path" .pdf)
        local filename_date=$(echo "$filename" | grep -Eo "[0-9]{6,8}" | head -n 1)
        if [[ -n "$filename_date" ]]; then
            if [[ ${#filename_date} -eq 8 ]]; then
                local day=${filename_date:0:2}
                local month=${filename_date:2:2}
                local year=${filename_date:4:4}
                if [[ "$year" -ge "$START_YEAR" && "$year" -le "$END_YEAR" ]]; then
                    document_date="${day}.${month}.${year}"
                fi
            elif [[ ${#filename_date} -eq 6 ]]; then
                local day=${filename_date:0:2}
                local month=${filename_date:2:2}
                local year="20${filename_date:4:2}"
                if [[ "$year" -ge "$START_YEAR" && "$year" -le "$END_YEAR" ]]; then
                    document_date="${day}.${month}.${year}"
                fi
            fi
        fi
    fi
    
    if [[ -z "$document_date" || "$document_date" == "UNKNOWN" ]]; then
        document_date="UNKNOWN"
    fi
    
    echo "$document_date"
}

# === Dokument-Informationen extrahieren ===
extract_document_info() {
    local pdf_content="$1"
    local document_number=""
    local document_amount=""
    local vendor_name=""
    
    # Dokumentnummer suchen
    local number_patterns=(
        "Rechnungsnummer[^0-9]*([A-Za-z0-9-]+)"
        "Rechnung\s+Nummer[^0-9]*([A-Za-z0-9-]+)"
        "Referenznummer[^0-9]*([A-Za-z0-9-]+)"
        "Referenz[^0-9]*([A-Za-z0-9-]+)"
        "Belegnummer[^0-9]*([A-Za-z0-9-]+)"
        "Dokumentnummer[^0-9]*([A-Za-z0-9-]+)"
        "Nr\.[^0-9]*([A-Za-z0-9-]+)"
        "No\.[^0-9]*([A-Za-z0-9-]+)"
    )
    
    for pattern in "${number_patterns[@]}"; do
        document_number=$(echo "$pdf_content" | grep -Eio "$pattern" | grep -Eo "[A-Za-z0-9-]+" | head -n 1)
        if [[ -n "$document_number" ]]; then
            break
        fi
    done
    
    # Betrag suchen
    local amount_patterns=(
        "Gesamtbetrag[^0-9]*([0-9,.-]+)"
        "Rechnungsbetrag[^0-9]*([0-9,.-]+)"
        "Summe[^0-9]*([0-9,.-]+)"
        "Total[^0-9]*([0-9,.-]+)"
        "Betrag[^0-9]*([0-9,.-]+)"
        "€[^0-9]*([0-9,.-]+)"
        "EUR[^0-9]*([0-9,.-]+)"
        "Euro[^0-9]*([0-9,.-]+)"
    )
    
    for pattern in "${amount_patterns[@]}"; do
        document_amount=$(echo "$pdf_content" | grep -Eio "$pattern" | grep -Eo "[0-9,.-]+" | head -n 1)
        if [[ -n "$document_amount" ]]; then
            document_amount=$(echo "$document_amount" | sed 's/[^0-9,.-]//g' | sed 's/,/./g')
            break
        fi
    done
    
    # Firmenname suchen
    vendor_name=$(echo "$pdf_content" | head -n 5 | grep -v "^$" | head -n 1 | sed 's/[^A-Za-z0-9\s-]//g' | cut -c1-25)
    
    # Fallback: Suche nach "GmbH", "AG", etc.
    if [[ -z "$vendor_name" || ${#vendor_name} -lt 3 ]]; then
        local company_patterns=(
            "([A-Za-z0-9\s-]+GmbH)"
            "([A-Za-z0-9\s-]+AG)"
            "([A-Za-z0-9\s-]+e\.K\.)"
            "([A-Za-z0-9\s-]+KG)"
            "([A-Za-z0-9\s-]+OHG)"
        )
        
        for pattern in "${company_patterns[@]}"; do
            local found_company=$(echo "$pdf_content" | grep -Eio "$pattern" | head -n 1 | sed 's/[^A-Za-z0-9\s-]//g' | cut -c1-25)
            if [[ -n "$found_company" && ${#found_company} -gt 3 ]]; then
                vendor_name="$found_company"
                break
            fi
        done
    fi
    
    echo "$document_number|$document_amount|$vendor_name"
}

# === PDF-Optimierung ===
optimize_pdf() {
    local input_file="$1"
    local output_file="$2"
    local temp_optimized="$DEBUG_DIR/temp_optimized.pdf"
    
    log "Optimiere PDF: $(basename "$input_file")"
    
    # PDF komprimieren
    if gs -sDEVICE=pdfwrite \
          -dCompatibilityLevel=1.4 \
          -dPDFSETTINGS=/ebook \
          -dNOPAUSE -dQUIET -dBATCH \
          -sOutputFile="$temp_optimized" "$input_file" 2>/dev/null; then
        
        # Finale Optimierung
        if gs -sDEVICE=pdfwrite \
              -dCompatibilityLevel=1.4 \
              -dPDFSETTINGS=/ebook \
              -dNOPAUSE -dQUIET -dBATCH \
              -sOutputFile="$output_file" "$temp_optimized" 2>/dev/null; then
            
            log "PDF erfolgreich optimiert: $(basename "$output_file")"
            rm -f "$temp_optimized"
            return 0
        fi
    fi
    
    # Fallback: Einfach kopieren
    if cp "$input_file" "$output_file" 2>/dev/null; then
        log "PDF kopiert (ohne Optimierung): $(basename "$output_file")"
        rm -f "$temp_optimized"
        return 0
    fi
    
    log "PDF-Optimierung fehlgeschlagen für: $(basename "$input_file")"
    rm -f "$temp_optimized"
    return 1
}

# === Datei-Verarbeitung ===
process_file() {
    local file="$1"
    local current_file="$2"
    local total_files="$3"
    
    info "Fortschritt: $current_file/$total_files - $(basename "$file")"
    log "Verarbeite Datei: $(basename "$file")"
    
    # Text extrahieren
    explain "Text-Extraktion: pdftotext extrahiert den Text aus dem PDF, damit Informationen wie Datum, Betrag und Firmenname erkannt werden können."
    command "pdftotext \"$file\" -"
    local pdf_content=$(pdftotext "$file" - 2>/dev/null)
    
    # OCR als Fallback
    if [[ -z "$pdf_content" || ${#pdf_content} -lt 50 ]]; then
        warn "Kein Text extrahiert, versuche OCR"
        explain "OCR (Optical Character Recognition): Wenn kein Text extrahiert werden kann, wird OCR verwendet, um Text aus Bildern im PDF zu erkennen."
        pdf_content=$(extract_text_with_ocr "$file")
        if [[ -n "$pdf_content" ]]; then
            log "Text extrahiert (${#pdf_content} Zeichen): $(basename "$file")"
        fi
    else
        log "Text extrahiert (${#pdf_content} Zeichen): $(basename "$file")"
    fi
    
    # Dokumenttyp bestimmen
    explain "Dokumenttyp-Erkennung: Das Skript sucht nach Schlüsselwörtern im Text, um den Dokumenttyp zu bestimmen (Rechnung, Mahnung, Kontoauszug, etc.)."
    local doc_type=$(get_document_type "$pdf_content" "$(basename "$file")")
    info "Dokumenttyp: $doc_type"
    log "Dokumenttyp: $doc_type"
    
    # Datum extrahieren
    explain "Datum-Extraktion: Das Skript sucht nach Datumsmustern im Text (DD.MM.YYYY, DD-MM-YYYY, etc.) und verwendet das erste gültige Datum im angegebenen Zeitraum."
    local document_date=$(find_document_date "$pdf_content" "$file")
    
    if [[ "$document_date" == "UNKNOWN" ]]; then
        log "Kein gültiges Datum gefunden für: $(basename "$file")"
        document_date="UNKNOWN"
    fi
    
    # Dokument-Informationen extrahieren
    local document_info=$(extract_document_info "$pdf_content")
    IFS='|' read -r document_number document_amount vendor_name <<< "$document_info"
    
    # Bereinige alle Werte
    doc_type=$(clean_filename "$doc_type")
    document_number=$(clean_filename "$document_number")
    document_amount=$(clean_filename "$document_amount")
    vendor_name=$(clean_filename "$vendor_name")
    
    # Erstelle neuen Dateinamen - KURZ und ÜBERSICHTLICH
    local new_name=""
    
    # Datum (DD.MM.YYYY)
    if [[ "$document_date" != "UNKNOWN" ]]; then
        new_name="${document_date}"
    else
        new_name="UNKNOWN_DATE"
    fi
    
    # Präfix
    new_name="${new_name}_${PREFIX}"
    
    # Dokumenttyp (max. 10 Zeichen)
    local short_doc_type=$(echo "$doc_type" | cut -c1-10)
    new_name="${new_name}_${short_doc_type}"
    
    # Betrag (nur wenn vorhanden, max. 10 Zeichen)
    if [[ -n "$document_amount" ]]; then
        local short_amount=$(echo "$document_amount" | cut -c1-10)
        new_name="${new_name}_${short_amount}EUR"
    fi
    
    # Firmenname (max. 15 Zeichen)
    if [[ -n "$vendor_name" ]]; then
        local short_vendor=$(echo "$vendor_name" | cut -c1-15)
        new_name="${new_name}_${short_vendor}"
    fi
    
    # Dokumentnummer (nur wenn vorhanden, max. 8 Zeichen)
    if [[ -n "$document_number" ]]; then
        local short_number=$(echo "$document_number" | cut -c1-8)
        new_name="${new_name}_${short_number}"
    fi
    
    new_name="${new_name}.pdf"
    
    # Optimiere und verschiebe die Datei
    explain "PDF-Optimierung: Ghostscript komprimiert das PDF, um die Dateigröße zu reduzieren, während die Qualität erhalten bleibt."
    if optimize_pdf "$file" "$OUTPUT_DIR/$new_name"; then
        log "Datei erfolgreich verarbeitet: $file -> $OUTPUT_DIR/$new_name"
        ok "Erfolgreich verarbeitet: $new_name"
        explain "Die Datei wurde erfolgreich umbenannt, optimiert und in das Ausgabeverzeichnis verschoben."
        return 0
    else
        log "Fehler bei der Verarbeitung: $(basename "$file")"
        err "Fehler bei der Verarbeitung: $(basename "$file")"
        explain "Die Verarbeitung ist fehlgeschlagen. Mögliche Ursachen: PDF ist beschädigt, keine Schreibrechte, oder Ghostscript-Fehler."
        return 1
    fi
}

# === Hauptprogramm ===
main() {
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}Rechnungs-Umbenennungsskript V3${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    explain "Willkommen beim Rechnungs-Umbenennungsskript! Dieses Skript analysiert PDF-Dateien, extrahiert Informationen (Datum, Betrag, Firmenname) und benennt sie sinnvoll um."
    echo ""
    
    # Abhängigkeiten prüfen
    check_dependencies
    
    # Benutzereingaben
    explain "Benutzereingaben: Sie werden nach dem Zeitraum und einem Präfix gefragt. Der Zeitraum bestimmt, welche Datumsangaben akzeptiert werden."
    info "Bitte geben Sie den Zeitraum und das Präfix ein:"
    read -p "$(echo -e ${BLUE}Frühestes Rechnungsjahr \(z.B. 2022\): ${NC})" START_YEAR
    explain "Der früheste Rechnungsjahr bestimmt, ab welchem Jahr Datumsangaben akzeptiert werden. Ältere Daten werden ignoriert."
    read -p "$(echo -e ${BLUE}Spätestes Rechnungsjahr \(z.B. 2023\): ${NC})" END_YEAR
    explain "Das späteste Rechnungsjahr bestimmt, bis zu welchem Jahr Datumsangaben akzeptiert werden. Neuere Daten werden ignoriert."
    read -p "$(echo -e ${BLUE}Präfix \(z.B. PRX, SNX, PRV\): ${NC})" PREFIX
    explain "Das Präfix wird jedem neuen Dateinamen vorangestellt, um Dateien zu kategorisieren (z.B. PRX für private Rechnungen)."
    
    log "=== Skript gestartet ==="
    log "Zeitraum: $START_YEAR - $END_YEAR"
    log "Präfix: $PREFIX"
    
    # Dateien finden
    explain "Dateisuche: Das Skript sucht nach allen PDF-Dateien im Import-Verzeichnis."
    command "find \"$IMPORT_DIR\" -name \"*.pdf\" -type f"
    local files=()
    while IFS= read -r -d '' file; do
        files+=("$file")
    done < <(find "$IMPORT_DIR" -name "*.pdf" -type f -print0)
    
    local total_files=${#files[@]}
    info "Insgesamt zu verarbeitende Dateien: $total_files"
    log "Insgesamt zu verarbeitende Dateien: $total_files"
    
    if [[ $total_files -eq 0 ]]; then
        warn "Keine PDF-Dateien im Import-Ordner gefunden: $IMPORT_DIR"
        explain "Das Import-Verzeichnis enthält keine PDF-Dateien. Bitte stellen Sie sicher, dass PDF-Dateien im Import-Verzeichnis vorhanden sind."
        exit 0
    fi
    
    # Verarbeitung
    local processed_count=0
    local error_count=0
    local start_time=$(date +%s)
    
    for i in "${!files[@]}"; do
        local file="${files[$i]}"
        local current_file=$((i + 1))
        
        if process_file "$file" "$current_file" "$total_files"; then
            processed_count=$((processed_count + 1))
        else
            error_count=$((error_count + 1))
        fi
    done
    
    # Zusammenfassung
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    log "========================================"
    log "Verarbeitung abgeschlossen."
    log "Gesamtzeit: $duration Sekunden"
    log "Erfolgreich verarbeitet: $processed_count"
    log "Fehler: $error_count"
    log "========================================"
    
    echo ""
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    ok "Verarbeitung abgeschlossen!"
    info "Erfolgreich verarbeitet: $processed_count"
    if [[ $error_count -gt 0 ]]; then
        warn "Fehler: $error_count"
    fi
    info "Gesamtzeit: $duration Sekunden"
    explain "Die Verarbeitung wurde abgeschlossen. Alle erfolgreich verarbeiteten Dateien befinden sich im Ausgabeverzeichnis: $OUTPUT_DIR"
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
}

# Skript ausführen
main "$@"
