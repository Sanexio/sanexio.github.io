#!/bin/bash

# === Pfadkonfiguration ===
IMPORT_DIR="/Volumes/USB EXTERN 3TB/SKRIPTE/fileOptimize/import"
OUTPUT_DIR="/Volumes/USB EXTERN 3TB/SKRIPTE/fileOptimize/output"
TEMP_IMAGES_DIR="$OUTPUT_DIR/temp_images"
TEMP_OCR_DIR="$OUTPUT_DIR/temp_ocr"
TEMP_CONVERT_DIR="$OUTPUT_DIR/temp_convert"
LOG_FILE="$OUTPUT_DIR/process_log.txt"

# === Vorbereitung ===
mkdir -p "$TEMP_IMAGES_DIR" "$TEMP_OCR_DIR" "$TEMP_CONVERT_DIR" "$OUTPUT_DIR"
> "$LOG_FILE"

# === Logging-Funktion ===
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

echo_status() {
    echo -e "\033[1;32m$1\033[0m"
}

# === Abhängigkeiten prüfen ===
REQUIRED_CMDS=("tesseract" "pdftoppm" "pdfunite" "gs" "magick" "wkhtmltopdf" "/Applications/LibreOffice.app/Contents/MacOS/soffice")

for cmd in "${REQUIRED_CMDS[@]}"; do
    if ! command -v $cmd &>/dev/null && [ ! -x "$cmd" ]; then
        echo "Fehlende Abhängigkeit: $cmd"
        exit 1
    fi
done

# === Hauptverarbeitung ===
for file in "$IMPORT_DIR"/*; do
    [ -f "$file" ] || continue

    filename=$(basename "$file")
    base="${filename%.*}"
    extension="${filename##*.}"
    extension_lower=$(echo "$extension" | tr '[:upper:]' '[:lower:]')

    TEMP_PDF="$TEMP_CONVERT_DIR/${base}_converted.pdf"
    OCR_PDF="$TEMP_OCR_DIR/${base}_OCR.pdf"
    FINAL_PDF="$OUTPUT_DIR/${base}_OPTIMIZE.pdf"

    log "Verarbeite: $filename"
    echo_status "Verarbeite Datei: $filename"

    case "$extension_lower" in
        pdf)
            log "PDF erkannt – führe OCR durch..."
            if pdftoppm -png -r 300 "$file" "$TEMP_IMAGES_DIR/page"; then
                for img in "$TEMP_IMAGES_DIR"/page-*.png; do
                    tesseract "$img" "${img%.png}" pdf
                done
                pdfunite "$TEMP_IMAGES_DIR"/page-*.pdf "$OCR_PDF"
                rm -f "$TEMP_IMAGES_DIR"/page-*
            else
                log "Fehler bei PDF zu Bild-Konvertierung"
                continue
            fi
            ;;

        jpg|jpeg|png|tiff|bmp|gif)
            log "Bild erkannt – konvertiere zu PDF + OCR..."
            if magick "$file" "$TEMP_PDF"; then
                tesseract "$file" "$OCR_PDF" pdf
            else
                log "Bildkonvertierung fehlgeschlagen"
                continue
            fi
            ;;

        doc|docx|odt|rtf|xls|xlsx|ods|ppt|pptx|key|numbers|pages|txt)
            log "Office-Datei erkannt – konvertiere zu PDF..."
            soffice="/Applications/LibreOffice.app/Contents/MacOS/soffice"
            if "$soffice" --headless --convert-to pdf "$file" --outdir "$TEMP_CONVERT_DIR"; then
                TEMP_PDF="$TEMP_CONVERT_DIR/${base}.pdf"
                tesseract "$TEMP_PDF" "$OCR_PDF" pdf
            else
                log "Fehler bei Office-Konvertierung"
                continue
            fi
            ;;

        html|htm)
            log "HTML-Datei erkannt – konvertiere zu PDF..."
            if wkhtmltopdf "$file" "$TEMP_PDF"; then
                tesseract "$TEMP_PDF" "$OCR_PDF" pdf
            else
                log "Fehler bei HTML-Konvertierung"
                continue
            fi
            ;;

        *)
            log "Nicht unterstützter Dateityp: $extension_lower – übersprungen"
            continue
            ;;
    esac

    # === Ghostscript-Kompression mit Optimierungslogik ===
log "Versuche aggressive Ghostscript-Kompression..."

# Temporäre Zieldatei
TEMP_GS_PDF="$OUTPUT_DIR/${base}_TEMP_OPTIMIZE.pdf"

gs -sDEVICE=pdfwrite \
   -dCompatibilityLevel=1.4 \
   -dPDFSETTINGS=/screen \
   -dColorImageDownsampleType=/Bicubic \
   -dColorImageResolution=72 \
   -dGrayImageDownsampleType=/Bicubic \
   -dGrayImageResolution=72 \
   -dMonoImageDownsampleType=/Subsample \
   -dMonoImageResolution=100 \
   -dAutoRotatePages=/None \
   -dUseCIEColor=false \
   -dDownsampleColorImages=true \
   -dDownsampleGrayImages=true \
   -dDownsampleMonoImages=true \
   -dCompressFonts=true \
   -dEmbedAllFonts=true \
   -dNOPAUSE -dQUIET -dBATCH \
   -sOutputFile="$TEMP_GS_PDF" "$OCR_PDF"


# Vergleich: Ist komprimierte Datei kleiner?
if [ -f "$TEMP_GS_PDF" ]; then
    SIZE_ORIG=$(stat -f%z "$OCR_PDF")
    SIZE_COMP=$(stat -f%z "$TEMP_GS_PDF")

    if [ "$SIZE_COMP" -lt "$SIZE_ORIG" ]; then
        mv "$TEMP_GS_PDF" "$FINAL_PDF"
        log "✔ Kompression erfolgreich: $(basename "$FINAL_PDF") (${SIZE_COMP} B < ${SIZE_ORIG} B)"
        echo_status "✔ Erfolgreich optimiert: $FINAL_PDF"
    else
        cp "$OCR_PDF" "$FINAL_PDF"
        rm -f "$TEMP_GS_PDF"
        log "✱ Kompression brachte keine Verbesserung – OCR-Version übernommen"
        echo_status "✱ OCR-Datei übernommen (keine Platzersparnis)"
    fi
else
    cp "$OCR_PDF" "$FINAL_PDF"
    log "✖ Ghostscript fehlgeschlagen – OCR-Version übernommen"
    echo_status "✖ Ghostscript fehlgeschlagen – OCR-Datei verwendet"
fi


done

log "===== Verarbeitung abgeschlossen ====="
echo_status "Alle Dateien wurden verarbeitet."

# === Zusammenfassung ===
log "===== Zusammenfassung ====="

optimized_files=($(find "$OUTPUT_DIR" -type f -name "*_OPTIMIZE.pdf"))

file_count=${#optimized_files[@]}
log "Anzahl erfolgreich optimierter Dateien: $file_count"
echo_status "Anzahl erfolgreich optimierter Dateien: $file_count"

if [ "$file_count" -gt 0 ]; then
    log "Liste optimierter Dateien:"
    for f in "${optimized_files[@]}"; do
        echo "$f" | tee -a "$LOG_FILE"
    done
fi


exit 0
