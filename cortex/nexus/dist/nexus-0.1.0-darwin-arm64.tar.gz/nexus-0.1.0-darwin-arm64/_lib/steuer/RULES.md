# Steuer / CashFlow — Tool-spezifische Regeln

> Extrahiert aus `Nexus/_rules/GLOBAL_RULES.md` §11 (Sprint Cleanup 2026-04-29).
> Co-located bei der Implementierung in `_lib/steuer/`. LL-IDs bleiben global gültig.
> Stand: Batch 10, 2026-03-22.

---

## LL-017: apoBank-Daten enthalten KEINE GKV-Erlöse

Die Kassenärztliche Vereinigung Hessen (KV Hessen) zahlt GKV-Honorare (~149 k/Jahr 2024)
NICHT über das apoBank-Geschäftskonto. Bei jeder CashFlow-/EÜR-Erstellung muss
explizit darauf hingewiesen werden, dass die Erlösseite unvollständig ist.

## LL-018: Vendor-Kategorie-Zuordnung (CashFlow)

Folgende Zuordnungen wurden empirisch validiert (Referenz: `241227_CashFlow.pdf`):

| Vendor | Kategorie | NICHT |
|---|---|---|
| ETERNO Frankfurt GmbH | **Raumkosten** | ~~IT_Telekom~~ |
| ETERNO Health GmbH | **IT_Telekom** | ~~Raumkosten~~ |
| Smart-Collectors | **Raumkosten** | ~~Inkasso/VSR~~ |
| Carmen Tan | **Raumkosten** (Garage) | ~~Reinigung~~ |
| HEID Immobilien | **Raumkosten** | ~~Beratung~~ |
| Maison Gaspard | **Raumkosten** | ~~Bewirtung~~ |
| Smow F GmbH | **Raumkosten** (Möbel) | ~~Praxisausstattung~~ |
| GRAFFIXXX | **Raumkosten** (Beschriftung) | ~~Marketing~~ |
| AmEx-Sammelzahlung | **Fuhrpark** | ~~VSR~~ |
| Laborgemeinschaft/Synlab | **Labor** | ~~Med_Bedarf~~ |
| Versorgungswerk LAEKH | **Personal** | ~~VSR~~ |
| ESt-Vorauszahlung (EINK.ST) | **Personal** | ~~FCK_Finanzamt~~ |
| FA Nachzahlungen | **FCK_Finanzamt** | ~~Personal~~ |
| FA sonstige Posten | **VSR** | ~~FCK_Finanzamt~~ |
| Google ADWORDS | **Marketing** | ~~IT/Software~~ |

## LL-019: Stracke-Einzahlungen ≠ Umsatz

Überweisungen VON Dr. Stracke AN die Praxis (`Durchlaufend_Umbuchung`, ~234 k/2024)
sind private Einlagen / Kapitalzuführungen. Diese dürfen NICHT als Erlöse gebucht werden.
Gewinnentnahmen (`Privat_Entnahme`, ~166 k/2024) sind die Gegenrichtung.

## LL-020: CashFlow-Kategorisierung persistiert

Die vollständige Kategorisierungslogik liegt in `cashflow_categorize.py`.
Bei zukünftigen Steuer-Sessions immer dieses Skript verwenden statt neu zu schreiben.

---

## CashFlow-Pipeline-Stand

- **`cashflow_categorize.py`**: Persistente Kategorisierungslogik für apoBank-Buchungen
- **Referenz:** `241227_CashFlow.pdf` (Kalkulation Dr. Stracke für 2024)
- **10 Kategorien:** Personal, Praxisbedarf, Raumkosten, IT_Telekom, Labor, VSR,
  Marketing, Fuhrpark, Gewinnvorauszahlung, FCK_Finanzamt
- **Vendor-Mapping:** 40+ Vendor→Kategorie-Zuordnungen empirisch validiert
- **ACHTUNG:** apoBank-Daten enthalten KEINE GKV-Erlöse (KV Hessen, separates Konto)
