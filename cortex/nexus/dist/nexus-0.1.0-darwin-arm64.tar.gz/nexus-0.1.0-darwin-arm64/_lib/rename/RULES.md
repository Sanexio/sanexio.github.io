# Rename — Tool-spezifische Regeln

> Extrahiert aus `Nexus/_rules/GLOBAL_RULES.md` §9 (Sprint Cleanup 2026-04-29).
> Co-located bei der Implementierung in `_lib/rename/`. LL-IDs bleiben global gültig.

---

## LL-012: IN/OUT-Parität (PFLICHT)

Die Anzahl der Dateien im Input-Ordner MUSS exakt der Anzahl im Output-Ordner entsprechen.
Keine Datei darf beim Umbenennen verloren gehen oder übersprungen werden.

- **Prüfung:** `validate_in_out_parity()` in `rename_utils.py`
- **Bei Verletzung:** Fehlermeldung, fehlende Dateien identifizieren und nachliefern
- **Ausnahme:** Dotfiles (`.DS_Store` etc.) werden bei der Zählung ignoriert

## LL-012: Duplikat-Konvention (Doppel-Unterstrich)

Wenn mehrere Input-Dateien denselben Ziel-Dateinamen erzeugen, werden sie wie folgt benannt:

| Vorkommen | Dateiname |
|-----------|-----------|
| 1. (Original) | `YYMMDD_Absender_Typ.pdf` |
| 2. (Duplikat) | `YYMMDD_Absender_Typ__1.pdf` |
| 3. (Duplikat) | `YYMMDD_Absender_Typ__2.pdf` |
| n. (Duplikat) | `YYMMDD_Absender_Typ__n-1.pdf` |

- **Trennzeichen:** Doppel-Unterstrich `__` (NICHT Einzel-Unterstrich `_`)
- **Nummerierung:** Ab 1, aufsteigend
- **Implementierung:** `handle_duplicate_names()` in `rename_utils.py`

## LL-013: Absender-Dopplung vermeiden (PFLICHT)

Jede rename-Funktion in `file_renamer.py` MUSS den Absendernamen aus
`rest`/`detail` entfernen, **bevor** sie ihn als Prefix voranstellt. Sonst entsteht
z.B. `KV_KV_Hessen` statt `KV_Hessen`.

**Checkliste für neue Regeln:**
1. Absendername als Prefix in den Zieldateinamen setzen
2. Absendername (und Varianten) aus `rest`/`detail` entfernen
3. Fallback-Detail definieren (z.B. `Schreiben`, `Rechnung`), falls `detail` leer wird
4. Ergebnis auf doppelte aufeinanderfolgende Wörter prüfen

## LL-014: Teilstring-Kollisionen bei Matchern ausschließen

Bei String-Matchern für Absenderkürzel muss explizit geprüft werden, ob andere
Absender den gesuchten Teilstring enthalten. Beispiel: `'KK_' in rest` matched
auch `BKK_` — daher: `'KK_' in rest and 'BKK' not in rest`.

---

## Pipeline-Stand (Batch 10, 2026-03-22)

- **`rename_utils.py`** (50 KB, 1370+ Zeilen): 24 Funktionen, 155+ PRX- / 115+ PRV- / 13 SNX-Keywords
- **`file_renamer.py`** (44 KB, 1020+ Zeilen): 78+ Vendor-Regeln in `build_rules()`
- **`sanitize_filename()`**: Automatische Nachkorrektur (KV-Dopplung, INTER PRX→PRV)
- **OCR-Pipeline**: Delegiert an `_lib/extract/universal_extract.py` (Multi-PSM, Caching) mit pdftotext-Fallback
- **Datumsextraktion**: 11 hierarchische Muster (`Datum:`, `Ausstellungsdatum:`, etc.)

## Pflicht: Regel-Update nach jeder Rename-Session

Wenn in einer Session umbenannt wird (file-renamer/IN → OUT), nach Abschluss
**neue Erkenntnisse in die persistenten Skripte übernehmen**:

- `rename_utils.py` — Keywords (PRX/PRV/SNX), apoBank-Kontonummern, Datumsvalidierung
- `file_renamer.py` — Vendor-Erkennungsregeln in `build_rules()`

Das ist NICHT optional. Jede Rename-Session endet mit Regel-Update.
Scheduled Task `rename-rules-audit` findet fehlende Updates.
