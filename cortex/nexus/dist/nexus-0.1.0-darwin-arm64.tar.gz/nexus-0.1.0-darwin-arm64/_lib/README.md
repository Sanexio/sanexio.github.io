# _lib/ — Shared Library für alle Projekte

Universelle Tools und Bibliotheken, die von **allen Projekten** in Claude-Sync genutzt werden.

## Verzeichnisstruktur

```
_lib/
├── README.md              ← Diese Datei
├── requirements.txt       ← Alle Python-Dependencies zentral
│
├── extract/               ← Universelle Textextraktion (PDF, OCR, Bilder)
│   ├── universal_extract.py   ← EIN Skript: PDF→Text, mit OCR-Fallback + Caching
│   ├── environment.json       ← Cache: Welche Tools/Libraries sind verfügbar?
│   └── .cache/                ← Extrahierte Texte (Hash-basiert)
│
├── pdf/                   ← PDF-Manipulation (merge, split, reduce, convert)
│   └── pdf_utils.py
│
├── rename/                ← Dateiumbenennung (von _shared/scripts/ migriert)
│   ├── rename_utils.py
│   └── file_renamer.py
│
├── validate/              ← Validierungs-Tools
│   └── validate_report.py
│
└── medical/               ← Medizinische Spezial-Tools
    └── extract_diagnoses.py
```

## Verwendung

### Textextraktion (für alle Projekte)
```bash
# Alle PDFs in einem Ordner extrahieren
python3 _lib/extract/universal_extract.py /pfad/zu/ordner/

# Einzelne PDF
python3 _lib/extract/universal_extract.py /pfad/zu/datei.pdf

# Ausgabe: JSON mit {dateiname: {pages: [...], method: "pdfplumber+ocr"}}
```

### Report-Validierung
```bash
python3 _lib/validate/validate_report.py /pfad/zum/bericht.txt
```

### Diagnosen-Extraktion
```bash
python3 _lib/medical/extract_diagnoses.py /pfad/zu/input/
```

### Dateiumbenennung
```bash
python3 _lib/rename/file_renamer.py --input /pfad/in --output /pfad/out --dry-run
```

## Prinzipien

- **Umgebungsadaptiv:** Scripts erkennen automatisch verfügbare Libraries und wählen die beste Methode
- **Caching:** Extrahierte Texte werden gecacht (Hash-basiert), keine doppelte Arbeit
- **Keine harten Abhängigkeiten:** Alles funktioniert mit Python 3.10+ Standardbibliothek als Minimum
- **Selbstlernend:** `environment.json` wird beim ersten Aufruf erstellt und bei Bedarf aktualisiert
