#!/bin/bash
# reducePDFsize.sh – Reduziert die Größe von PDF-Dateien durch Komprimierung
# Nutzung:
#   ./reducePDFsize.sh    - Komprimiert alle PDFs im Import-Verzeichnis
#
# ============================================================================
# GRUNDPRINZIPIEN - WICHTIG FÜR WEITERE ENTWICKLUNG
# ============================================================================
# Dieses Skript ist ein ERKLÄRENDES Skript. Bei allen Änderungen müssen
# folgende Prinzipien beachtet werden:
#
# 1. ERKLÄRUNGEN MÜSSEN VORHANDEN SEIN
#    - Jeder Verarbeitungsschritt muss mit erklärenden Ausgaben versehen werden
#    - Die Erklärungen erklären, was der Schritt macht und warum er wichtig ist
#
# 2. BENUTZERFREUNDLICHE AUSGABEN
#    - Alle Ausgaben müssen klar und verständlich sein
#    - Farbcodierung wird verwendet für bessere Lesbarkeit
#
# 3. STRUKTUR BEIBEHALTEN
#    - Die bestehende Struktur darf nicht grundlegend geändert werden
#    - Erklärungen sind Teil der Struktur, nicht optional
#
# 4. FEHLERBEHANDLUNG MIT ERKLÄRUNGEN
#    - Bei Fehlern muss erklärt werden, was schiefgelaufen ist
#    - Lösungsvorschläge müssen gegeben werden
#
# 5. WICHTIG: Diese Prinzipien sind NICHT optional - sie sind Teil der
#    Funktionalität des Skripts. Das Skript soll nicht nur komprimieren,
#    sondern auch LEHREN, wie PDF-Komprimierung funktioniert.
# ============================================================================

# Farbcodierung
GREEN="\033[32m"; RED="\033[31m"; YELLOW="\033[33m"; BLUE="\033[34m"; CYAN="\033[36m"; MAGENTA="\033[35m"; NC="\033[0m"
ok(){ echo -e "${GREEN}✅ $*${NC}"; }
err(){ echo -e "${RED}❌ $*${NC}"; }
warn(){ echo -e "${YELLOW}⚠️  $*${NC}"; }
info(){ echo -e "${BLUE}ℹ️  $*${NC}"; }
explain(){ echo -e "${MAGENTA}📖 $*${NC}"; }
command(){ echo -e "${CYAN}🔧 Befehl: $*${NC}"; }
detail(){ echo -e "${CYAN}  → $*${NC}"; }

# Pfadvariablen definieren
IMPORT_DIR="/Volumes/USB EXTERN 3TB/SKRIPTE/DESIZE/import"
OUTPUT_DIR="/Volumes/USB EXTERN 3TB/SKRIPTE/DESIZE/output"

# Prüfen, ob die Verzeichnisse existieren
explain "Verzeichnis-Prüfung: Das Skript prüft, ob die Import- und Output-Verzeichnisse existieren."
command "test -d \"$IMPORT_DIR\""
if [ ! -d "$IMPORT_DIR" ]; then
    err "Import-Verzeichnis existiert nicht: $IMPORT_DIR"
    explain "Das Import-Verzeichnis wurde nicht gefunden. Bitte erstellen Sie das Verzeichnis und fügen Sie PDF-Dateien hinzu."
    exit 1
fi
ok "Import-Verzeichnis gefunden: $IMPORT_DIR"

command "test -d \"$OUTPUT_DIR\""
if [ ! -d "$OUTPUT_DIR" ]; then
    err "Output-Verzeichnis existiert nicht: $OUTPUT_DIR"
    explain "Das Output-Verzeichnis wurde nicht gefunden. Bitte erstellen Sie das Verzeichnis, damit die komprimierten PDFs gespeichert werden können."
    exit 1
fi
ok "Output-Verzeichnis gefunden: $OUTPUT_DIR"

# Ghostscript prüfen
explain "Abhängigkeitsprüfung: Ghostscript (gs) ist das Tool, das PDFs komprimiert. Es muss installiert sein."
command "command -v gs"
if ! command -v gs &> /dev/null; then
    err "Ghostscript (gs) ist nicht installiert"
    explain "Ghostscript ist erforderlich, um PDFs zu komprimieren. Es reduziert die Dateigröße durch Optimierung der Bilder und Komprimierung."
    detail "Installation mit Homebrew:"
    detail "  brew install ghostscript"
    exit 1
fi
ok "Ghostscript ist installiert"

# PDF-Dateien im Import-Ordner verarbeiten
for pdf_file in "$IMPORT_DIR"/*.pdf; do
    # Überprüfen, ob überhaupt PDF-Dateien vorhanden sind
    if [ ! -e "$pdf_file" ]; then
        echo "Keine PDF-Dateien im Import-Ordner gefunden."
        exit 0
    fi

    # Basisname der Datei ohne Verzeichnis und Erweiterung
    base_name=$(basename "$pdf_file" .pdf)

    # Zielpfad für die komprimierte PDF
    output_file="$OUTPUT_DIR/${base_name}_compressed.pdf"

    info "Verarbeite: $(basename "$pdf_file")"

    # Ghostscript-Befehl zur Reduzierung der Dateigröße
    explain "PDF-Komprimierung: Ghostscript komprimiert das PDF mit der Einstellung '/printer', die eine gute Balance zwischen Qualität und Dateigröße bietet."
    command "gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=/printer -dNOPAUSE -dQUIET -dBATCH -sOutputFile=\"$output_file\" \"$pdf_file\""
    gs -sDEVICE=pdfwrite \
       -dCompatibilityLevel=1.4 \
       -dPDFSETTINGS=/printer \
       -dNOPAUSE -dQUIET -dBATCH \
       -sOutputFile="$output_file" "$pdf_file"

    # Ergebnis prüfen
    if [ $? -eq 0 ]; then
        ok "Erfolgreich verarbeitet: $(basename "$output_file")"
        explain "Die PDF-Datei wurde erfolgreich komprimiert. Die Dateigröße sollte reduziert sein, während die Qualität erhalten bleibt."
    else
        err "Fehler bei der Verarbeitung: $(basename "$pdf_file")"
        explain "Die Komprimierung ist fehlgeschlagen. Mögliche Ursachen: Die PDF-Datei ist beschädigt, geschützt oder es gibt ein Problem mit Ghostscript."
    fi

done

exit 0
