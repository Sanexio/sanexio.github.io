#!/bin/bash
# PDFtoTXT.sh – Konvertiert PDF-Dateien in Textdateien
# Nutzung:
#   ./PDFtoTXT.sh              - Konvertiert alle PDFs im Quellverzeichnis
#
# ============================================================================
# GRUNDPRINZIPIEN - WICHTIG FÜR WEITERE ENTWICKLUNG
# ============================================================================
# Dieses Skript ist ein ERKLÄRENDES Skript. Bei allen Änderungen müssen
# folgende Prinzipien beachtet werden:
#
# 1. ERKLÄRUNGEN MÜSSEN VORHANDEN SEIN
#    - Jeder Verarbeitungsschritt muss mit erklärenden Ausgaben versehen werden
#    - Die Erklärungen erklären, was der Schritt macht und warum er wichtig ist
#    - Beispiel: explain("PDF wird geladen: pdftotext extrahiert Text aus dem PDF")
#
# 2. BENUTZERFREUNDLICHE AUSGABEN
#    - Alle Ausgaben müssen klar und verständlich sein
#    - Farbcodierung wird verwendet für bessere Lesbarkeit
#
# 3. STRUKTUR BEIBEHALTEN
#    - Die bestehende Struktur darf nicht grundlegend geändert werden
#    - Erklärungen sind Teil der Struktur, nicht optional
#
# 4. FEHLERBEHANDLUNG MIT ERKLÄRUNGEN
#    - Bei Fehlern muss erklärt werden, was schiefgelaufen ist
#    - Lösungsvorschläge müssen gegeben werden
#
# 5. PROTOKOLLIERUNG
#    - Wichtige Aktionen sollten protokolliert werden
#    - Am Ende sollte eine Zusammenfassung ausgegeben werden
#
# 6. WICHTIG: Diese Prinzipien sind NICHT optional - sie sind Teil der
#    Funktionalität des Skripts. Das Skript soll nicht nur konvertieren,
#    sondern auch LEHREN, wie PDF-zu-Text-Konvertierung funktioniert.
# ============================================================================

set -euo pipefail

# Farbcodierung
GREEN="\033[32m"; RED="\033[31m"; YELLOW="\033[33m"; BLUE="\033[34m"; CYAN="\033[36m"; MAGENTA="\033[35m"; NC="\033[0m"
ok(){ echo -e "${GREEN}✅ $*${NC}"; }
err(){ echo -e "${RED}❌ $*${NC}"; }
warn(){ echo -e "${YELLOW}⚠️  $*${NC}"; }
info(){ echo -e "${BLUE}ℹ️  $*${NC}"; }
explain(){ echo -e "${MAGENTA}📖 $*${NC}"; }
command(){ echo -e "${CYAN}🔧 Befehl: $*${NC}"; }
detail(){ echo -e "${CYAN}  → $*${NC}"; }

# Protokollierungs-Arrays
declare -a ACTIONS_TAKEN=()
declare -a FAILED_ACTIONS=()

log_success() {
    local action="$1"
    local explanation="$2"
    ACTIONS_TAKEN+=("$action|$explanation")
}

log_failure() {
    local action="$1"
    local reason="$2"
    local suggestion="$3"
    FAILED_ACTIONS+=("$action|$reason|$suggestion")
}

print_summary_report() {
    echo ""
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}📋 ZUSAMMENFASSUNG - Was wurde gemacht?${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    if [[ ${#ACTIONS_TAKEN[@]} -gt 0 ]]; then
        echo -e "${GREEN}✅ ERFOLGREICH KONVERTIERTE DATEIEN:${NC}"
        echo ""
        local i=1
        for entry in "${ACTIONS_TAKEN[@]}"; do
            IFS='|' read -r action explanation <<< "$entry"
            echo -e "${GREEN}$i. $action${NC}"
            echo -e "   ${CYAN}Erklärung:${NC} $explanation"
            echo ""
            i=$((i + 1))
        done
    fi
    
    if [[ ${#FAILED_ACTIONS[@]} -gt 0 ]]; then
        echo -e "${RED}❌ FEHLGESCHLAGENE KONVERTIERUNGEN:${NC}"
        echo ""
        local i=1
        for entry in "${FAILED_ACTIONS[@]}"; do
            IFS='|' read -r action reason suggestion <<< "$entry"
            echo -e "${RED}$i. $action${NC}"
            echo -e "   ${YELLOW}Grund:${NC} $reason"
            echo -e "   ${CYAN}Lösungsvorschlag:${NC} $suggestion"
            echo ""
            i=$((i + 1))
        done
    fi
    
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    if [[ ${#ACTIONS_TAKEN[@]} -gt 0 && ${#FAILED_ACTIONS[@]} -eq 0 ]]; then
        echo -e "${GREEN}✅ Alle PDFs wurden erfolgreich konvertiert!${NC}"
    elif [[ ${#FAILED_ACTIONS[@]} -gt 0 ]]; then
        echo -e "${YELLOW}⚠️  Einige Dateien konnten nicht konvertiert werden.${NC}"
    fi
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo ""
}

# Prüfen, ob pdftotext installiert ist
explain "Abhängigkeitsprüfung: pdftotext ist ein Tool aus dem poppler-Paket, das Text aus PDF-Dateien extrahiert."
command "command -v pdftotext"
if ! command -v pdftotext &> /dev/null; then
    err "pdftotext ist nicht installiert"
    explain "pdftotext ist Teil des poppler-Pakets. Es muss installiert werden, um PDFs in Textdateien zu konvertieren."
    detail "Installation mit Homebrew:"
    detail "  brew install poppler"
    detail "Oder mit MacPorts:"
    detail "  sudo port install poppler"
    exit 1
fi
ok "pdftotext ist installiert"

# Quellverzeichnis
SOURCE_DIR="/Volumes/USB EXTERN 3TB/SKRIPTE/PDFtoTXT/PDF"
# Zielverzeichnis
TARGET_DIR="/Volumes/USB EXTERN 3TB/SKRIPTE/PDFtoTXT/TXT"

explain "Verzeichnis-Setup: Das Skript verwendet feste Verzeichnisse für Quell- und Zieldateien."
info "Quellverzeichnis: $SOURCE_DIR"
info "Zielverzeichnis: $TARGET_DIR"

# Prüfe ob Quellverzeichnis existiert
explain "Quellverzeichnis prüfen: Es wird geprüft, ob das Quellverzeichnis existiert und PDF-Dateien enthält."
command "test -d \"$SOURCE_DIR\""
if [[ ! -d "$SOURCE_DIR" ]]; then
    err "Quellverzeichnis existiert nicht: $SOURCE_DIR"
    explain "Das Quellverzeichnis wurde nicht gefunden. Bitte stellen Sie sicher, dass das Verzeichnis existiert und PDF-Dateien enthält."
    exit 1
fi

# Erstelle Zielverzeichnis, falls es nicht existiert
explain "Zielverzeichnis erstellen: Das Zielverzeichnis wird erstellt, falls es nicht existiert. Hier werden die konvertierten Textdateien gespeichert."
command "mkdir -p \"$TARGET_DIR\""
mkdir -p "$TARGET_DIR"
ok "Zielverzeichnis bereit: $TARGET_DIR"

# Konvertiere alle PDFs im Verzeichnis
explain "PDF-Konvertierung startet: Alle PDF-Dateien im Quellverzeichnis werden nacheinander in Textdateien konvertiert."
info "Konvertiere PDFs in $SOURCE_DIR..."
echo ""

file_count=0
success_count=0
error_count=0

for pdf_file in "$SOURCE_DIR"/*.pdf; do
    if [[ -f "$pdf_file" ]]; then
        file_count=$((file_count + 1))
        filename=$(basename "$pdf_file" .pdf)
        
        explain "PDF-Konvertierung: pdftotext extrahiert den Text aus dem PDF und behält dabei das Layout bei (-layout Option)."
        command "pdftotext -layout \"$pdf_file\" \"$TARGET_DIR/${filename}.txt\""
        
        if pdftotext -layout "$pdf_file" "$TARGET_DIR/${filename}.txt" 2>/dev/null; then
            ok "Konvertiert: $filename.pdf -> ${filename}.txt"
            log_success "$filename.pdf → ${filename}.txt" "Die PDF-Datei wurde erfolgreich in eine Textdatei konvertiert. Der Text wurde mit Layout-Informationen extrahiert."
            success_count=$((success_count + 1))
        else
            err "Fehler bei: $filename.pdf"
            explain "Die Konvertierung ist fehlgeschlagen. Mögliche Ursachen: Die PDF-Datei ist beschädigt, geschützt oder enthält keine extrahierbaren Texte."
            log_failure "$filename.pdf konvertieren" "Die Konvertierung ist fehlgeschlagen. Die PDF-Datei könnte beschädigt oder geschützt sein." "Prüfen Sie die PDF-Datei manuell. Versuchen Sie: pdftotext -layout \"$pdf_file\" -"
            error_count=$((error_count + 1))
        fi
    fi
done

if [[ $file_count -eq 0 ]]; then
    warn "Keine PDF-Dateien im Quellverzeichnis gefunden: $SOURCE_DIR"
    explain "Das Quellverzeichnis enthält keine PDF-Dateien. Bitte stellen Sie sicher, dass PDF-Dateien im Quellverzeichnis vorhanden sind."
else
    info "Verarbeitung abgeschlossen: $success_count erfolgreich, $error_count Fehler von $file_count Dateien"
fi

print_summary_report
info "Textdateien befinden sich in: $TARGET_DIR"