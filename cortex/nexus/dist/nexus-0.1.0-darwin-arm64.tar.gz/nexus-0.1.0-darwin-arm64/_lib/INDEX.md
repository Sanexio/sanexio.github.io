# _lib/ — Shared Library

Zentrale Tool-Bibliothek für alle Projekte im Claude-OS Ökosystem.
Alle wiederverwendbaren Skripte und Module gehören hierher.

## Module

| Ordner      | Beschreibung                                      | Hauptdatei(en)                   |
|-------------|---------------------------------------------------|----------------------------------|
| `extract/`  | PDF-Textextraktion + OCR + Cache                  | `universal_extract.py`           |
| `glb/`      | 3D-Modell-Optimierung für Web (model-viewer)      | `optimize_glb.sh`                |
| `medical/`  | Diagnosen-Extraktion, Befund-Tools                | `extract_diagnoses.py` u.a.      |
| `ocr/`      | OCR-Spezialtools (universal, robust)              | `pdf_ocr_universal.py` u.a.      |
| `pdf/`      | PDF-Manipulation (merge, split, reduce, extract)  | `pdf_utils.py`, `pdf_extract.py` |
| `rename/`   | Dateiumbenennung (kanonischer Pfad)               | `file_renamer.py`, `rename_utils.py` |
| `steuer/`   | CashFlow-Kategorisierung (apoBank → EÜR)          | `cashflow_categorize.py`         |
| `utils/`    | Hilfstools (Optimierung, Übersetzung, Rename)     | `invoice_rename.sh` u.a.         |
| `validate/` | Report-Validierung                                | `validate_report.py`             |

## Grundregel

**Nie neue Inline-Skripte in Projekten schreiben.** Verbesserungen gehören hierher.
Für OCR/PDF-Extraktion immer `extract/universal_extract.py` als Einstiegspunkt nutzen.

## Abhängigkeiten

Siehe `requirements.txt` für Python-Pakete.
