#!/usr/bin/env bash
# onboard-device.sh — Geräte-Eintrag in devices.json automatisch ergänzen,
#                     committen, pushen. Optional Tailscale + Claude Code.
#
# Usage: bash ~/Cortex/Nexus/scripts/onboard-device.sh
#
# Voraussetzungen:
#   - Nexus bereits geklont (~/Cortex/Nexus existiert)
#   - git-Auth funktioniert (gh oder ssh)
#   - Homebrew installiert (für Tailscale/Claude Code)

set -euo pipefail

NEXUS_ROOT="${NEXUS_ROOT:-$HOME/Cortex/Nexus}"
cd "$NEXUS_ROOT"

echo "==> Pull Nexus"
git pull --ff-only

HOSTNAME_LOCAL=$(scutil --get LocalHostName)
echo "==> Hostname: ${HOSTNAME_LOCAL}"

# devices.json patchen via Python (Mac-default /usr/bin/python3)
python3 - <<'PYEOF'
import json, subprocess, datetime, pathlib

p = pathlib.Path(".config/devices.json")
data = json.loads(p.read_text())

def sh(cmd):
    return subprocess.check_output(cmd, shell=True, text=True).strip()

hostname = sh("scutil --get LocalHostName")

if hostname in data["devices"]:
    print(f"==> Eintrag '{hostname}' existiert bereits — kein Patch.")
else:
    role = "home" if hostname.lower().startswith("cluster-mini") else "unspecified"
    arch = sh("uname -m")
    entry = {
        "hostname": hostname,
        "arch": arch,
        "chip": sh("sysctl -n machdep.cpu.brand_string"),
        "os_version": sh("sw_vers -productVersion"),
        "homebrew_prefix": "/opt/homebrew" if arch == "arm64" else "/usr/local",
        "python_path": sh("which python3 || echo /usr/bin/python3"),
        "role": role,
        "platform": "macos",
        "projects": [
            {"name": "Nexus", "path": "~/Cortex/Nexus", "primary": True, "host": "lokal"}
        ],
        "last_updated": datetime.date.today().isoformat(),
        "first_sync": datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "_note_bootstrap": f"Bootstrapped via onboard-device.sh, user '{sh('whoami')}'.",
        "network": {
            "mesh_name": None,
            "mesh_dns_current": None,
            "mesh_dns_planned": None,
            "mesh_ip_v4": None,
            "tailscale_tags": ["tag:cortex-admin", "tag:cortex-host-mac"],
            "ssh_port": 22,
            "ssh_user": sh("whoami"),
            "ssh_method": "tailscale-ssh",
            "mosh_enabled": False,
            "status": "not-yet-onboarded",
            "last_seen": None,
            "note": "Tailscale-Login + IP-Eintragung noch ausstehend (siehe Skript-Nachlauf)."
        }
    }
    data["devices"][hostname] = entry
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
    print(f"==> '{hostname}' eingetragen.")
PYEOF

# Commit + push falls Änderung
if ! git diff --quiet .config/devices.json; then
    git add .config/devices.json
    git commit -m "devices: ${HOSTNAME_LOCAL} via onboard-device.sh ergänzen"
    git push
    echo "==> devices.json gepusht"
else
    echo "==> devices.json unverändert"
fi

# Optional: Tailscale via Homebrew
if command -v brew >/dev/null 2>&1; then
    if ! [ -d /Applications/Tailscale.app ]; then
        echo "==> Tailscale installieren (native GUI-App via tailscale-app-cask) …"
        brew install --cask tailscale-app || echo "WARN: Tailscale-Install fehlgeschlagen — manuell nachholen"
    else
        echo "==> Tailscale bereits installiert"
    fi

    if ! [ -d /Applications/Claude.app ]; then
        echo "==> Claude Desktop installieren …"
        brew install --cask claude 2>/dev/null || echo "WARN: Cask 'claude' nicht verfügbar — manuell von claude.com/download laden"
    else
        echo "==> Claude bereits installiert"
    fi
else
    echo "WARN: brew nicht gefunden — Tailscale + Claude Code manuell installieren"
fi

# Cortex-Mode-Hook + Slash-Commands installieren (zwingend für funktionierenden Mode-Switch)
echo
echo "==> Cortex-Mode-Slash-Commands installieren"
bash "$NEXUS_ROOT/tools/cortex-mode/bin/install_slash_commands.sh"

echo
echo "==> Hook-Registration in ~/.claude/settings.json prüfen"
if jq -e '.hooks.UserPromptSubmit[] | select(.matcher == "") | .hooks[] | select(.type == "command") | .command' \
   "$HOME/.claude/settings.json" 2>/dev/null | grep -q inject.sh; then
    echo "  OK: Hook bereits registriert."
else
    echo "  WARN: Hook nicht registriert. Manuell ergänzen in ~/.claude/settings.json:"
    cat <<'JSONHINT'
  Hook-Snippet (in den hooks-Block mergen):
    "hooks": {
      "UserPromptSubmit": [
        {"matcher": "", "hooks": [{"type": "command",
          "command": "bash $HOME/Cortex/Nexus/tools/cortex-mode/bin/inject.sh",
          "timeout": 10}]}
      ]
    }
JSONHINT
fi

echo
echo "============================================================"
echo "FERTIG — noch manuell (interaktiv, einmalig):"
echo "  1) Tailscale: open -a Tailscale → Login mit GitHub/Apple"
echo "     Danach Tailscale-SSH-Server aktivieren: sudo tailscale up --ssh"
echo "  2) Claude Code: open -a Claude → Login"
echo "  3) Claude Code neu starten (oder /hooks öffnen),"
echo "     damit Slash-Commands + Hook geladen werden."
echo "  4) In Claude Code testen: /cortex-mode → muss aktuellen Mode zeigen."
echo "  5) Erste Session: cd ~/Cortex/Nexus && claude"
echo "============================================================"
