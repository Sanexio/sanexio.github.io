#!/usr/bin/env bash
# ============================================================
# desk-rollout-watch.sh — prüft, ob alle Macs die Desk-Regeln
# (_rules/desk/ in Nexus) gezogen haben, und meldet NUR bei Problem
# per Telegram an Dr. Stracke.
#
# Funktionsweise (kein SSH nötig):
#   Jeder Mac veröffentlicht beim nexus-sync seinen Heartbeat als
#   ephemeren Ref refs/heartbeats/<host> (Unix-Timestamp). Wenn dieser
#   Timestamp NACH dem Regel-Push liegt, hat der Mac seither (inkl.
#   pull --ff-only) gesynct → er hat die Regeln. Liegt er davor oder
#   fehlt der Heartbeat, ist der Rollout für diesen Mac nicht bestätigt.
#
#   Aufruf manuell:   bash scripts/desk-rollout-watch.sh [--verbose]
#   Periodisch:       LaunchAgent com.cortex.desk-rollout-watch (nur Mac-Studio)
#
# Läuft bewusst nur auf EINEM Watcher-Mac (sonst mehrfach-Alarme).
# ============================================================

set -uo pipefail

NEXUS_DIR="${NEXUS_DIR:-$HOME/Cortex/Nexus}"
# Watcher läuft nur auf EINEM Mac (sonst Mehrfach-Alarme). cluster-mini-02:
# hat gateway/.env (Telegram-Token), ist always-on und fährt den Cron-Runner.
WATCHER_HOST="${DESK_WATCH_HOST:-cluster-mini-02}"
RULES_PATH="_rules/desk/README.md"
RULES_COMMIT="b9927e32519e8a424175a532dfadc344919b2e41"
RULES_TS_FALLBACK=1779728969   # Commit-Zeit b9927e32 (25.05.2026 19:09)
LOG="$NEXUS_DIR/_memory/logs/desk-rollout-watch.log"
STATE="$NEXUS_DIR/_memory/.desk-rollout-watch-state"
VERBOSE=0; [ "${1:-}" = "--verbose" ] && VERBOSE=1

mkdir -p "$(dirname "$LOG")"
log() { printf '[%s] %s\n' "$(date '+%F %T')" "$*" >>"$LOG"; [ "$VERBOSE" -eq 1 ] && printf '%s\n' "$*"; }

cd "$NEXUS_DIR" 2>/dev/null || { log "ERR: NEXUS_DIR nicht erreichbar: $NEXUS_DIR"; exit 1; }

# Nur auf dem designierten Watcher-Mac laufen (verhindert Mehrfach-Alarme,
# falls das Skript je auf mehreren Macs getriggert wird).
SELF="$(hostname -s 2>/dev/null || hostname)"
SELF_LC="$(printf '%s' "$SELF" | tr '[:upper:]' '[:lower:]')"
WATCHER_LC="$(printf '%s' "$WATCHER_HOST" | tr '[:upper:]' '[:lower:]')"
if [ "$SELF_LC" != "$WATCHER_LC" ]; then
    log "SKIP: $SELF ist nicht der Watcher-Mac ($WATCHER_HOST)"
    exit 0
fi

# Frische Daten holen.
git fetch -q origin main 2>/dev/null || log "WARN: git fetch origin main fehlgeschlagen"
git fetch -q origin '+refs/heartbeats/*:refs/heartbeats/*' 2>/dev/null || log "WARN: heartbeat-fetch fehlgeschlagen"

# Zeitpunkt des Regel-Pushes bestimmen.
PUSH_TS="$(git log -1 --format=%ct "$RULES_COMMIT" 2>/dev/null)"
[ -z "$PUSH_TS" ] && PUSH_TS="$RULES_TS_FALLBACK"

problems=()

# 1) Liegen die Regeln überhaupt (noch) auf origin/main?
if ! git cat-file -e "origin/main:$RULES_PATH" 2>/dev/null; then
    problems+=("origin/main enthält _rules/desk NICHT (mehr) — Regeln fehlen am Remote")
fi

# 2) Erwartete macOS-Hosts aus devices.json (Single Source of Truth).
#    (while-read statt mapfile — kompatibel mit macOS-bash 3.2)
HOSTS=()
while IFS= read -r _h; do [ -n "$_h" ] && HOSTS+=("$_h"); done < <(python3 - "$NEXUS_DIR/.config/devices.json" 2>/dev/null <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    sys.exit(0)
for k, v in d.get("devices", {}).items():
    if str(v.get("platform", "")).lower().startswith("mac"):
        print(v.get("hostname", k))
PY
)
if [ "${#HOSTS[@]}" -eq 0 ]; then
    log "WARN: keine macOS-Hosts aus devices.json — fällt auf Heartbeat-Refs zurück"
    while IFS= read -r _h; do [ -n "$_h" ] && HOSTS+=("$_h"); done < <(git for-each-ref --format='%(refname)' refs/heartbeats/ | sed 's#refs/heartbeats/##')
fi

# 3) Pro Host: letzter Heartbeat vor/nach Regel-Push?
ok_hosts=()
for h in ${HOSTS[@]+"${HOSTS[@]}"}; do
    [ -z "$h" ] && continue
    ts="$(git cat-file -p "refs/heartbeats/$h" 2>/dev/null | tail -1 | tr -dc '0-9')"
    if [ -z "$ts" ]; then
        problems+=("$h: kein Heartbeat-Ref — Sync-Status unbekannt (Mac aus? Agent tot?)")
    elif [ "$ts" -le "$PUSH_TS" ]; then
        problems+=("$h: letzter Sync $(date -r "$ts" '+%d.%m %H:%M') liegt VOR Regel-Push ($(date -r "$PUSH_TS" '+%d.%m %H:%M')) — Regeln evtl. nicht gezogen")
    else
        ok_hosts+=("$h")
    fi
done

# 4) Ergebnis.
if [ "${#problems[@]}" -eq 0 ]; then
    log "OK — alle ${#HOSTS[@]} Macs (${ok_hosts[*]:-}) haben seit Regel-Push gesynct"
    rm -f "$STATE"
    exit 0
fi

# Anti-Spam: nur melden, wenn sich die Problemlage seit letztem Alarm geändert hat.
sig="$(printf '%s\n' "${problems[@]}" | sort | shasum 2>/dev/null | awk '{print $1}')"
prev="$(cat "$STATE" 2>/dev/null || echo '')"
log "PROBLEM(${#problems[@]}): ${problems[*]}"
if [ "$sig" = "$prev" ]; then
    log "  (unverändert seit letztem Alarm — kein erneuter Telegram-Push)"
    exit 0
fi

msg="*Desk-Regeln-Rollout — Achtung*
Nicht bestätigt auf $(( ${#problems[@]} )) Punkt(en):"
for p in "${problems[@]}"; do msg="$msg
• $p"; done
msg="$msg

OK: ${ok_hosts[*]:-keine}
(Quelle: refs/heartbeats vs. Regel-Push $(date -r "$PUSH_TS" '+%d.%m %H:%M'))"

PY_BIN="$NEXUS_DIR/.venv/bin/python"
[ -x "$PY_BIN" ] || PY_BIN="$(command -v python3)"
result="$(printf '%s' "$msg" | "$PY_BIN" -c 'import sys
from agent.connexio.session_digest import send_telegram
print(send_telegram(sys.stdin.read()))' 2>&1)"
log "  Telegram: $result"
case "$result" in
    *"'sent': True"*) printf '%s' "$sig" >"$STATE" ;;
    *) log "  WARN: Telegram-Versand nicht bestätigt — State NICHT gesetzt, Retry nächster Lauf" ;;
esac
exit 0
