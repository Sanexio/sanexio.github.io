#!/usr/bin/env bash
# bootstrap-mac.sh — Cortex auf einem neuen Mac einrichten.
#
# Usage:
#   bash bootstrap-mac.sh                     # nur Nexus
#   bash bootstrap-mac.sh cortex-web          # Nexus + Cortex-Web
#   bash bootstrap-mac.sh cortex-web juvantis # mehrere Projekte
#
# Voraussetzungen:
#   - GitHub-SSH-Key auf diesem Mac registriert (gh auth status muss OK sein)
#   - git, gh installiert (brew install git gh falls nötig)
#
# Was das Skript NICHT macht:
#   - Secrets verteilen (.env, Bot-Tokens, API-Keys → manuell)
#   - LaunchAgents installieren (separat: cron, spawn-watcher)
#   - cortex-agent venv aufsetzen (separat: cd Nexus && python3 -m venv .venv …)

set -euo pipefail

CORTEX_ROOT="${CORTEX_ROOT:-$HOME/Cortex}"
GH_ORG="${GH_ORG:-Sanexio}"
GH_PROTOCOL="${GH_PROTOCOL:-auto}"   # auto | ssh | https

echo "==> Cortex-Root: $CORTEX_ROOT"
echo "==> GitHub-Org:  $GH_ORG"

# 1. Auth-Modus bestimmen
detect_protocol() {
  if ssh -o BatchMode=yes -o ConnectTimeout=5 -T git@github.com 2>&1 | grep -q "successfully authenticated"; then
    echo "ssh"
  elif command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
    echo "https"
  else
    echo "none"
  fi
}

if [[ "$GH_PROTOCOL" == "auto" ]]; then
  GH_PROTOCOL=$(detect_protocol)
fi

case "$GH_PROTOCOL" in
  ssh)
    REPO_PREFIX="git@github.com:${GH_ORG}/"
    REPO_SUFFIX=".git"
    echo "==> Auth: SSH"
    ;;
  https)
    REPO_PREFIX="https://github.com/${GH_ORG}/"
    REPO_SUFFIX=".git"
    echo "==> Auth: HTTPS (via gh credential helper)"
    ;;
  *)
    echo "FEHLER: Weder SSH noch gh-HTTPS-Auth verfügbar. Setup: 'gh auth login' oder SSH-Key bei GitHub registrieren." >&2
    exit 1
    ;;
esac

# 2. Cortex-Wurzel
mkdir -p "$CORTEX_ROOT"
cd "$CORTEX_ROOT"

# 3. Nexus klonen oder aktualisieren
if [[ -d Nexus/.git ]]; then
  echo "==> Nexus existiert, pulling …"
  (cd Nexus && git pull --ff-only)
else
  echo "==> Klone Nexus …"
  git clone "${REPO_PREFIX}nexus${REPO_SUFFIX}" Nexus
fi

# 4. Mode-State (Default autonomy)
if [[ ! -f "$HOME/.claude/state/cortex-mode.json" ]]; then
  mkdir -p "$HOME/.claude/state"
  echo '{"mode":"autonomy"}' > "$HOME/.claude/state/cortex-mode.json"
  echo "==> Mode-State initialisiert auf autonomy"
fi

# 5. Optionale Projekte
mkdir -p projects
for proj in "$@"; do
  case "$proj" in
    cortex-web|Cortex-Web)
      target="projects/Cortex-Web"
      repo="cortex-web"
      ;;
    juvantis|Juvantis)
      target="projects/Juvantis"
      repo="juvantis"
      ;;
    *)
      echo "WARN: unbekanntes Projekt '$proj' — überspringe (Repo-Name in bootstrap-mac.sh nachpflegen)" >&2
      continue
      ;;
  esac
  if [[ -d "${target}/.git" ]]; then
    echo "==> ${target} existiert, pulling …"
    (cd "$target" && git pull --ff-only)
  else
    echo "==> Klone ${repo} → ${target}"
    git clone "${REPO_PREFIX}${repo}${REPO_SUFFIX}" "$target" || \
      echo "WARN: Repo ${repo} nicht erreichbar — evtl. noch nicht angelegt" >&2
  fi
done

echo
echo "==> Fertig."
echo
echo "Nächste manuelle Schritte:"
echo "  1. Geräte-Eintrag in Nexus/.config/devices.json prüfen/ergänzen"
echo "  2. Per-Mac-Secrets aus 1Password ziehen:"
echo "     - Nexus/gateway/.env (Telegram-Bot-Token, falls gewünscht)"
echo "     - projects/Cortex-Web/.env.local (Adapter-Secrets)"
echo "  3. Falls cortex-agent gebraucht wird: cd Nexus && python3 -m venv .venv && .venv/bin/pip install -e ."
echo "  4. Erste Claude-Code-Session: cd ~/Cortex/projects/<projekt> && claude"
