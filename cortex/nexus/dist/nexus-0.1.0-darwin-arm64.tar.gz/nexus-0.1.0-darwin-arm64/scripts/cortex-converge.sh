#!/usr/bin/env bash
# ============================================================
# cortex-converge.sh — Self-Applying-State pro Mac
# ============================================================
# Bringt diesen Mac in den Soll-Zustand, den das Kollektivgedächtnis
# (Nexus-Repo) als „so soll jeder Mac aussehen" hinterlegt hat.
#
# Idempotent: kann beliebig oft laufen. Schritte erkennen selbst, ob
# sie schon erledigt sind, und sind dann NOOP.
#
# Aufruf:
#   bash scripts/cortex-converge.sh                    # leise (nur Drift/Fehler logged)
#   bash scripts/cortex-converge.sh --verbose          # alles auf stdout
#   bash scripts/cortex-converge.sh --dry-run          # nur zeigen, was wäre
#   bash scripts/cortex-converge.sh --step <name>      # nur ein Schritt
#   bash scripts/cortex-converge.sh --list             # alle Schritte zeigen
#
# Wird auch automatisch vom nexus-sync.sh am Ende aufgerufen.
#
# Neue Schritte ergänzen: einfach eine neue Funktion `step_<name>()`
# unten anfügen und in CONVERGE_STEPS aufnehmen.
# Rückgabe-Codes der step-Funktionen:
#   0   = APPLIED  (Drift erkannt + behoben)
#   10  = NOOP     (Mac schon im Soll-Zustand)
#   20  = SKIP     (Schritt gilt nicht für diesen Mac/Plattform)
#   1   = FAIL     (Konvergenz misslungen — manueller Eingriff nötig)
# ============================================================

set -uo pipefail

NEXUS_DIR="${NEXUS_DIR:-$HOME/Cortex/Nexus}"
LOG_DIR="$NEXUS_DIR/_memory/logs"
LOG_FILE="$LOG_DIR/cortex-converge.log"
mkdir -p "$LOG_DIR"

VERBOSE=0
DRY_RUN=0
ONLY_STEP=""
LIST_ONLY=0

while [ $# -gt 0 ]; do
    case "$1" in
        --verbose|-v) VERBOSE=1; shift ;;
        --dry-run|-n) DRY_RUN=1; shift ;;
        --step)       ONLY_STEP="${2:-}"; shift 2 ;;
        --list)       LIST_ONLY=1; shift ;;
        --help|-h)
            sed -n '2,28p' "$0"
            exit 0
            ;;
        *) echo "Unknown flag: $1" >&2; exit 2 ;;
    esac
done

ts() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }
log_file() { printf "[%s] %s\n" "$(ts)" "$*" >> "$LOG_FILE"; }
log_stdout() { [ "$VERBOSE" -eq 1 ] && printf "%s\n" "$*"; }
log() { log_file "$*"; log_stdout "$*"; }

HOSTNAME_SHORT="$(hostname -s 2>/dev/null || hostname)"
PLATFORM="$(uname -s)"

# ============================================================
# Konvergenz-Schritte (idempotent)
# ============================================================

# --- Step: Cortex-Web als Mirror-Klon auf jedem Mac ---
step_cortex_web_clone() {
    local dest="$HOME/Cortex/projects/Cortex-Web"
    local repo_ssh="git@github.com:Sanexio/cortex-web.git"
    local repo_https="https://github.com/Sanexio/cortex-web.git"

    [ "$PLATFORM" = "Darwin" ] || return 20  # nur Macs
    [ -d "$dest/.git" ] && return 10          # schon vorhanden

    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde klonen → $dest"; return 0; }

    mkdir -p "$(dirname "$dest")"
    if git clone --quiet "$repo_ssh" "$dest" 2>/dev/null; then
        log "APPLIED: Cortex-Web geklont via SSH → $dest"
        return 0
    fi
    if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
        if git clone --quiet "$repo_https" "$dest" 2>/dev/null; then
            log "APPLIED: Cortex-Web geklont via HTTPS (gh-Token) → $dest"
            return 0
        fi
    fi
    log "FAIL: Cortex-Web-Klon misslungen (weder SSH noch gh-HTTPS) — manuell klären"
    return 1
}

# --- Step: Cortex-Web frisch pullen (vor Mirror-Setup) ---
# Henne-Ei-Lösung: der Mirror-Sync-launchd-Job braucht die cw-mirror-sync.plist,
# die nur via Cortex-Web-Repo verteilt wird. Beim allerersten Konvergenz-Lauf
# auf einem neu-geklonten Mac ist Cortex-Web vielleicht noch auf einem alten
# Stand ohne die Plist. Daher: pull-only sync hier, bevor mirror_launchd läuft.
# Bei lokaler Bearbeitung (dirty WT oder lokale Ahead-Commits): SKIP, weil
# Konvergenz sich nie in aktive Bearbeitung einmischt.
step_cortex_web_pull() {
    [ "$PLATFORM" = "Darwin" ] || return 20
    local cw_dir="$HOME/Cortex/projects/Cortex-Web"
    [ -d "$cw_dir/.git" ] || return 20

    cd "$cw_dir" || return 1

    # Dirty Working-Tree? Aktiv-Bearbeitungs-Mac → nicht stören.
    if [ -n "$(git status --porcelain 2>/dev/null | head -1)" ]; then
        return 20
    fi

    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde Cortex-Web FF-pullen"; return 0; }

    git fetch --quiet origin main 2>/dev/null || return 20
    local local_head remote_head base
    local_head=$(git rev-parse HEAD)
    remote_head=$(git rev-parse origin/main)
    base=$(git merge-base HEAD origin/main 2>/dev/null || echo "")

    [ "$local_head" = "$remote_head" ] && return 10
    # Lokale Ahead-Commits oder Divergenz → nicht anfassen
    [ "$local_head" != "$base" ] && return 20

    if git merge --ff-only origin/main >/dev/null 2>&1; then
        log "APPLIED: Cortex-Web FF auf $(git rev-parse --short HEAD)"
        return 0
    fi
    log "FAIL: Cortex-Web FF-merge fehlgeschlagen"
    return 1
}

# --- Step: cw-mirror-sync launchd-Job installieren ---
step_cortex_web_mirror_launchd() {
    [ "$PLATFORM" = "Darwin" ] || return 20

    local cw_dir="$HOME/Cortex/projects/Cortex-Web"
    local plist_src="$cw_dir/tools/cw-mirror-sync.plist"
    local plist_dst="$HOME/Library/LaunchAgents/com.cortex.cw-mirror.plist"
    local label="com.cortex.cw-mirror"

    if [ ! -d "$cw_dir" ]; then
        log "SKIP cw-mirror: $cw_dir fehlt — Cortex-Web nicht geklont auf diesem Mac"
        return 20
    fi
    if [ ! -f "$plist_src" ]; then
        log "SKIP cw-mirror: $plist_src fehlt — Cortex-Web evtl. auf Pre-Filter-History (kein cw-mirror-sync.plist im Repo)"
        return 20
    fi

    # Plist installiert + identisch + geladen?
    # Hinweis: launchctl list | grep -q stolpert über SIGPIPE bei pipefail
    # (grep -q schließt die Pipe früh → launchctl rc=141 → pipefail false).
    # Daher Output-Capture statt Pipeline.
    local already_loaded=0
    if [ -f "$plist_dst" ] && cmp -s "$plist_src" "$plist_dst"; then
        local launchctl_out
        launchctl_out=$(launchctl list 2>/dev/null || true)
        if [[ "$launchctl_out" == *"$label"* ]]; then
            already_loaded=1
        fi
    fi
    [ "$already_loaded" -eq 1 ] && return 10

    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde launchd-Job installieren → $plist_dst"; return 0; }

    mkdir -p "$HOME/Library/LaunchAgents"
    # Reload (idempotent): erst unload (falls geladen), dann kopieren, dann load.
    launchctl unload "$plist_dst" 2>/dev/null || true
    cp "$plist_src" "$plist_dst"
    if launchctl load "$plist_dst" 2>/dev/null; then
        log "APPLIED: cw-mirror launchd-Job installiert + geladen ($label)"
        return 0
    fi
    log "FAIL: launchctl load fehlgeschlagen für $plist_dst"
    return 1
}

# --- Step: devices.json prüft, ob dieser Mac Cortex-Web kennt ---
step_cortex_web_devices_known() {
    # Read-only-Check: warnt nur, wenn dieser Mac keinen CW-Eintrag hat.
    # Schreiben in devices.json macht das Skript NICHT (Konflikt-Vermeidung).
    local devices_json="$NEXUS_DIR/.config/devices.json"
    [ -f "$devices_json" ] || return 20

    if python3 - "$devices_json" "$HOSTNAME_SHORT" 2>/dev/null <<'PYEOF'
import json, sys
data = json.loads(open(sys.argv[1]).read())
host = sys.argv[2]
# Match case-insensitive über alle Devices-Keys
for key, dev in data.get("devices", {}).items():
    if key.lower() == host.lower() or dev.get("hostname", "").lower() == host.lower():
        for p in dev.get("projects", []):
            if p.get("name") == "Cortex-Web":
                sys.exit(10)  # known
        sys.exit(0)  # device known, but CW missing
sys.exit(20)  # device not known at all → SKIP (separate concern)
PYEOF
    then
        # exit 0 von python = device known, CW missing → APPLIED-status sinnlos, also FAIL-soft
        log "DRIFT: devices.json kennt $HOSTNAME_SHORT, aber Cortex-Web fehlt im projects-Array — bitte ergänzen"
        return 0
    else
        case $? in
            10) return 10 ;;  # NOOP
            20) return 20 ;;  # SKIP — Device nicht in devices.json
            *)  log "WARN: devices.json-Check fehlgeschlagen"; return 1 ;;
        esac
    fi
}

# ============================================================
# Sanexio-Tenant-Steps (nur auf Stracke-Macs aktiv)
# ============================================================
# Tenant ist privates Repo; nicht jeder Mac soll es klonen. Erkennung
# via devices.json: Mac ist Stracke-Mac, wenn er Sanexio-Tenant in
# seinem projects-Array hat.

is_sanexio_tenant_mac() {
    local devices_json="$NEXUS_DIR/.config/devices.json"
    [ -f "$devices_json" ] || return 1
    python3 - "$devices_json" "$HOSTNAME_SHORT" 2>/dev/null <<'PYEOF'
import json, sys
data = json.loads(open(sys.argv[1]).read())
host = sys.argv[2]
for key, dev in data.get("devices", {}).items():
    if key.lower() == host.lower() or dev.get("hostname", "").lower() == host.lower():
        for p in dev.get("projects", []):
            if p.get("name") == "Sanexio-Tenant":
                sys.exit(0)  # ja, Stracke-Mac
        sys.exit(1)  # Mac bekannt, aber kein Tenant
sys.exit(1)  # unbekannter Mac
PYEOF
}

# --- Step: Sanexio-Tenant klonen (nur Stracke-Macs) ---
step_sanexio_tenant_clone() {
    [ "$PLATFORM" = "Darwin" ] || return 20
    is_sanexio_tenant_mac || return 20

    local dest="$HOME/Cortex/projects/Sanexio-Tenant"
    local repo_ssh="git@github.com:Sanexio/sanexio-tenant.git"
    local repo_https="https://github.com/Sanexio/sanexio-tenant.git"

    [ -d "$dest/.git" ] && return 10

    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde Sanexio-Tenant klonen → $dest"; return 0; }

    mkdir -p "$(dirname "$dest")"
    if git clone --quiet "$repo_ssh" "$dest" 2>/dev/null; then
        log "APPLIED: Sanexio-Tenant geklont via SSH → $dest"
        return 0
    fi
    if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
        if git clone --quiet "$repo_https" "$dest" 2>/dev/null; then
            log "APPLIED: Sanexio-Tenant geklont via HTTPS (gh-Token) → $dest"
            return 0
        fi
    fi
    log "FAIL: Sanexio-Tenant-Klon misslungen (privates Repo, weder SSH noch gh-HTTPS-Auth)"
    return 1
}

# --- Step: tenant-mirror-sync launchd-Job installieren ---
step_sanexio_tenant_mirror_launchd() {
    [ "$PLATFORM" = "Darwin" ] || return 20
    is_sanexio_tenant_mac || return 20

    local tenant_dir="$HOME/Cortex/projects/Sanexio-Tenant"
    local plist_src="$tenant_dir/tools/tenant-mirror-sync.plist"
    local plist_dst="$HOME/Library/LaunchAgents/com.sanexio.tenant-mirror.plist"
    local label="com.sanexio.tenant-mirror"

    [ -d "$tenant_dir" ] || return 20
    [ -f "$plist_src" ] || return 20

    local already_loaded=0
    if [ -f "$plist_dst" ] && cmp -s "$plist_src" "$plist_dst"; then
        local launchctl_out
        launchctl_out=$(launchctl list 2>/dev/null || true)
        if [[ "$launchctl_out" == *"$label"* ]]; then
            already_loaded=1
        fi
    fi
    [ "$already_loaded" -eq 1 ] && return 10

    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde tenant-mirror launchd-Job installieren → $plist_dst"; return 0; }

    mkdir -p "$HOME/Library/LaunchAgents"
    launchctl unload "$plist_dst" 2>/dev/null || true
    cp "$plist_src" "$plist_dst"
    if launchctl load "$plist_dst" 2>/dev/null; then
        log "APPLIED: tenant-mirror launchd-Job installiert + geladen ($label)"
        return 0
    fi
    log "FAIL: launchctl load fehlgeschlagen für $plist_dst"
    return 1
}

# --- Step: CORTEX_TENANT_DIR in Shell-Init (zsh/bash) eintragen ---
step_cortex_tenant_dir_envvar() {
    [ "$PLATFORM" = "Darwin" ] || return 20
    is_sanexio_tenant_mac || return 20

    # Welche Shell-Init? zsh ist macOS-Default seit Catalina, .bashrc als Fallback.
    local rc_file=""
    if [ -f "$HOME/.zshrc" ]; then rc_file="$HOME/.zshrc";
    elif [ -f "$HOME/.bashrc" ]; then rc_file="$HOME/.bashrc";
    else rc_file="$HOME/.zshrc"; fi

    local marker_begin="# >>> Cortex-Tenant-Path (cortex-converge) >>>"
    local marker_end="# <<< Cortex-Tenant-Path (cortex-converge) <<<"

    # Bereits installiert?
    if [ -f "$rc_file" ] && grep -qF "$marker_begin" "$rc_file"; then
        return 10
    fi

    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde CORTEX_TENANT_DIR-Block in $rc_file einfügen"; return 0; }

    {
        echo ""
        echo "$marker_begin"
        echo "# Auto-managed by ~/Cortex/Nexus/scripts/cortex-converge.sh"
        echo "# Cortex-Web-Adapter (tools/lib/tenant-path.sh) lesen aus diesem Pfad."
        echo "export CORTEX_TENANT_DIR=\"\$HOME/Cortex/projects/Sanexio-Tenant\""
        echo "$marker_end"
    } >> "$rc_file"

    log "APPLIED: CORTEX_TENANT_DIR-Block in $rc_file eingefügt"
    return 0
}

# --- Step: Cortex-Web Git-Hooks aktivieren (Pre-Commit Linter) ---
# Setzt core.hooksPath = tools/git-hooks via tools/install-git-hooks.sh.
# Konfig ist .git/config-lokal, darum pro Mac via Konvergenz nachgezogen.
step_cortex_web_git_hooks() {
    [ "$PLATFORM" = "Darwin" ] || return 20
    local cw_dir="$HOME/Cortex/projects/Cortex-Web"
    [ -d "$cw_dir/.git" ] || return 20

    local installer="$cw_dir/tools/install-git-hooks.sh"
    local hooks_dir="$cw_dir/tools/git-hooks"
    [ -x "$installer" ] || return 20
    [ -d "$hooks_dir" ] || return 20

    local current
    current=$(git -C "$cw_dir" config --get core.hooksPath 2>/dev/null || true)
    if [ "$current" = "tools/git-hooks" ]; then
        return 10
    fi

    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde install-git-hooks.sh in $cw_dir laufen lassen (current core.hooksPath='$current')"; return 0; }

    # Installer nutzt git rev-parse --show-toplevel — muss innerhalb cortex-web laufen.
    if ( cd "$cw_dir" && bash "$installer" ) >/dev/null 2>&1; then
        log "APPLIED: Cortex-Web core.hooksPath → tools/git-hooks (pre-commit aktiv)"
        return 0
    fi
    log "FAIL: install-git-hooks.sh in $cw_dir fehlgeschlagen"
    return 1
}

# --- Step: cortex-rename als Klon auf jedem Mac ---
# Erstes Cortex-Layer-Repo aus Welle 3 (Stracke-Klassifikation 2026-05-31
# Punkt 8: file-renamer → Framework cortex-rename OSS, Engine bleibt
# Nexus-proprietär, Tenant-Inhalt in sanexio-tenant). Repo ist heute
# private, wird nach Phase D public — Klon-Schritt funktioniert in
# beiden Zuständen identisch (gh-Auth oder SSH-Schlüssel).
step_cortex_rename_clone() {
    _cortex_layer_clone "cortex-rename"
}

# --- Step: cortex-qm klonen ---
# Punkt 7 in OSS-Klassifikation: Praxis-QM-Framework, OSS-Layer-Projekt.
# Tenant-Inhalt in sanexio-tenant/qm/.
step_cortex_qm_clone() {
    _cortex_layer_clone "cortex-qm"
}

# --- Step: cortex-desk klonen ---
# Punkt 6 in OSS-Klassifikation: Praxis-Desk-Framework, OSS-Layer-Projekt.
# Tenant-Inhalt in sanexio-tenant/desk/.
step_cortex_desk_clone() {
    _cortex_layer_clone "cortex-desk"
}

# --- Step: cortex-cli klonen ---
# Phase 3 der Cortex-Plattform-Roadmap: User-zentrisches Plattform-Tool.
# Welle 3.0-3.6a auf M5 erstellt (2026-05-31). Repo private bis Welle 3.6c
# (codesign) + Stracke-Review.
step_cortex_cli_clone() {
    _cortex_layer_clone "cortex-cli"
}

# --- Helper: generischer Cortex-Layer-Projekt-Klon ---
# Klont $1 vom Sanexio-GitHub nach ~/Cortex/projects/$1. Idempotent.
# SSH bevorzugt, gh-HTTPS als Fallback (für Macs ohne SSH-Setup).
_cortex_layer_clone() {
    local name="$1"
    local dest="$HOME/Cortex/projects/${name}"
    local repo_ssh="git@github.com:Sanexio/${name}.git"
    local repo_https="https://github.com/Sanexio/${name}.git"

    [ "$PLATFORM" = "Darwin" ] || return 20
    [ -d "$dest/.git" ] && return 10

    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde klonen → $dest"; return 0; }

    mkdir -p "$(dirname "$dest")"
    if git clone --quiet "$repo_ssh" "$dest" 2>/dev/null; then
        log "APPLIED: ${name} geklont via SSH → $dest"
        return 0
    fi
    if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
        if git clone --quiet "$repo_https" "$dest" 2>/dev/null; then
            log "APPLIED: ${name} geklont via HTTPS (gh-Token) → $dest"
            return 0
        fi
    fi
    log "FAIL ${name}_clone: weder SSH noch gh-HTTPS — manuell klären"
    return 1
}

# --- Step: Codex-CLI installieren (idempotent, via brew cask) ---
# Codex CLI = OpenAI's Terminal-Coding-Agent (brew cask "codex").
# Verteilt sich automatisch auf jeden Mac mit Homebrew. Stracke-Direktive
# 2026-05-31: jeder Nexus-Rechner soll bei Bedarf Codex laufen lassen können.
# Schlägt fehl bei Permission-Issues auf /opt/homebrew (siehe C-M-04
# 2026-05-31: openclaw-Symlink blockiert clusteradm) — Step loggt FAIL +
# weicht aus, blockiert den Sync nicht.
step_codex_cli() {
    [ "$PLATFORM" = "Darwin" ] || return 20

    local brew=""
    [ -x "/opt/homebrew/bin/brew" ] && brew="/opt/homebrew/bin/brew"
    [ -z "$brew" ] && [ -x "/usr/local/bin/brew" ] && brew="/usr/local/bin/brew"
    if [ -z "$brew" ]; then
        log "SKIP codex_cli: brew nicht gefunden (weder /opt/homebrew/bin noch /usr/local/bin)"
        return 20
    fi

    local codex_bin=""
    [ -x "/opt/homebrew/bin/codex" ] && codex_bin="/opt/homebrew/bin/codex"
    [ -z "$codex_bin" ] && [ -x "/usr/local/bin/codex" ] && codex_bin="/usr/local/bin/codex"
    if [ -n "$codex_bin" ] && "$codex_bin" --version >/dev/null 2>&1; then
        return 10
    fi

    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde codex CLI installieren via $brew install --cask codex"; return 0; }

    if "$brew" install --cask codex >/dev/null 2>&1; then
        if [ -x "/opt/homebrew/bin/codex" ] && /opt/homebrew/bin/codex --version >/dev/null 2>&1; then
            log "APPLIED: codex CLI installiert via brew cask (/opt/homebrew/bin/codex)"
            return 0
        fi
        log "FAIL codex_cli: brew install lief durch, aber codex --version schlägt fehl (evtl. alter Symlink im Weg?)"
        return 1
    fi
    log "FAIL codex_cli: brew install --cask codex fehlgeschlagen (Permission-Issue auf brew-prefix?)"
    return 1
}

# --- Step: alle Projekt-Repos in ~/Cortex/projects/* FF-pullen ---
# Generischer Sync für alle Sub-Repos. Vermeidet, dass jedes neue
# Cortex-Layer-Repo (cortex-cli, cortex-qm, cortex-desk, …) einen eigenen
# *_pull-Step braucht. Cortex-Web hat weiter step_cortex_web_pull als
# spezifischen Vorlauf (gleicher Effekt, harmlose Redundanz).
#
# Verhalten:
#   - skipt dirty Working-Trees (lokale Bearbeitung wird NICHT überfahren)
#   - skipt Repos mit lokalen Ahead-Commits (Divergenz)
#   - ff-merged nur auf den aktuellen Branch, nur wenn er einen Upstream hat
#   - silent für clean+up-to-date Repos, loggt nur APPLIED + FAIL
step_projects_ff_sync() {
    [ "$PLATFORM" = "Darwin" ] || return 20
    local projects_dir="$HOME/Cortex/projects"
    [ -d "$projects_dir" ] || return 20

    local applied=0
    local skipped=0
    local failed=0
    local repo

    for repo in "$projects_dir"/*/; do
        [ -d "${repo}.git" ] || continue
        local name
        name=$(basename "$repo")

        (
            cd "$repo" || exit 1

            # Dirty? Aktiv-Bearbeitung → nicht stören.
            if [ -n "$(git status --porcelain 2>/dev/null | head -1)" ]; then
                exit 20
            fi

            # Upstream-Branch ermitteln
            local upstream
            upstream=$(git rev-parse --abbrev-ref --symbolic-full-name '@{u}' 2>/dev/null) || exit 20
            local remote="${upstream%%/*}"
            local remote_branch="${upstream#*/}"

            git fetch --quiet "$remote" "$remote_branch" 2>/dev/null || exit 20

            local local_head remote_head base
            local_head=$(git rev-parse HEAD)
            remote_head=$(git rev-parse "$upstream")
            base=$(git merge-base HEAD "$upstream" 2>/dev/null || echo "")

            [ "$local_head" = "$remote_head" ] && exit 10
            # Lokale Ahead-Commits oder Divergenz → nicht anfassen
            [ "$local_head" != "$base" ] && exit 20

            if git merge --ff-only "$upstream" >/dev/null 2>&1; then
                exit 0
            fi
            exit 1
        )
        local rc=$?
        case "$rc" in
            0)  log "APPLIED: $name FF auf $(cd "$repo" && git rev-parse --short HEAD)"
                applied=$((applied+1)) ;;
            10) : ;;  # up-to-date, silent
            20) skipped=$((skipped+1)) ;;
            *)  log "FAIL projects_ff_sync: $name FF-merge fehlgeschlagen (rc=$rc)"
                failed=$((failed+1)) ;;
        esac
    done

    [ "$failed" -gt 0 ] && return 1
    [ "$applied" -gt 0 ] && return 0
    return 10
}

# --- Step: Cluster-State-Recorder ---
# Schreibt aktuellen HEAD-Hash + Dirty-Status + Branch jedes Repos in
# Nexus/_state/cluster/<hostname>.json. Wird via nexus-sync.sh-Whitelist
# committet → andere Macs sehen, wer wo steht.
# Bricht Doppelarbeit ab, bevor sie passiert (siehe Welle 2026-06-01:
# Cluster-Mini-02 wollte Welle 2.7b ziehen, weil sie nicht wusste, dass
# M5 sie schon erledigt hatte — genau dieser Status wäre dort sichtbar).
step_record_cluster_state() {
    [ "$PLATFORM" = "Darwin" ] || return 20
    local state_dir="$NEXUS_DIR/_state/cluster"
    local hostname
    hostname=$(scutil --get LocalHostName 2>/dev/null || hostname -s)
    local state_file="$state_dir/${hostname}.json"
    mkdir -p "$state_dir"

    local tmp
    tmp=$(mktemp -t cluster-state.XXXXXX) || return 1

    local timestamp
    timestamp=$(date -u +%Y-%m-%dT%H:%M:%SZ)

    {
        echo "{"
        echo "  \"hostname\": \"$hostname\","
        echo "  \"recorded_at\": \"$timestamp\","
        echo "  \"repos\": {"
        local first=1
        local repo
        # Nexus selbst zuerst (immer da, fix verdrahtet)
        if [ -d "$NEXUS_DIR/.git" ]; then
            local nx_head nx_branch nx_dirty
            nx_head=$(cd "$NEXUS_DIR" && git rev-parse --short HEAD 2>/dev/null || echo "?")
            nx_branch=$(cd "$NEXUS_DIR" && git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "?")
            nx_dirty="false"
            [ -n "$(cd "$NEXUS_DIR" && git status --porcelain 2>/dev/null | head -1)" ] && nx_dirty="true"
            printf '    "Nexus": {"head": "%s", "branch": "%s", "dirty": %s}' "$nx_head" "$nx_branch" "$nx_dirty"
            first=0
        fi
        # Alle Projekte
        for repo in "$HOME/Cortex/projects"/*/; do
            [ -d "${repo}.git" ] || continue
            local name
            name=$(basename "$repo")
            local head branch dirty
            head=$(cd "$repo" && git rev-parse --short HEAD 2>/dev/null || echo "?")
            branch=$(cd "$repo" && git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "?")
            dirty="false"
            [ -n "$(cd "$repo" && git status --porcelain 2>/dev/null | head -1)" ] && dirty="true"
            if [ "$first" -eq 0 ]; then
                printf ',\n'
            fi
            printf '    "%s": {"head": "%s", "branch": "%s", "dirty": %s}' "$name" "$head" "$branch" "$dirty"
            first=0
        done
        echo ""
        echo "  }"
        echo "}"
    } > "$tmp"

    if [ -f "$state_file" ] && cmp -s "$tmp" "$state_file"; then
        rm -f "$tmp"
        return 10
    fi
    [ "$DRY_RUN" -eq 1 ] && { log "DRY: würde cluster-state schreiben → $state_file"; rm -f "$tmp"; return 0; }
    mv "$tmp" "$state_file"
    log "APPLIED: cluster-state für $hostname → $state_file"
    return 0
}

# ============================================================
# Liste aller Schritte (Reihenfolge = Ausführungsreihenfolge)
# Erweitern: neue step_*-Funktion definieren + hier eintragen.
# ============================================================
CONVERGE_STEPS=(
    "cortex_web_clone"
    "cortex_web_pull"
    "cortex_web_mirror_launchd"
    "cortex_web_devices_known"
    "cortex_web_git_hooks"
    "sanexio_tenant_clone"
    "sanexio_tenant_mirror_launchd"
    "cortex_tenant_dir_envvar"
    "codex_cli_install"
    "cortex_rename_clone"
    "cortex_qm_clone"
    "cortex_desk_clone"
    "cortex_cli_clone"
    "projects_ff_sync"
    "record_cluster_state"
)

# ============================================================
# Runner
# ============================================================
result_label() {
    case "$1" in
        0)  echo "APPLIED" ;;
        10) echo "NOOP" ;;
        20) echo "SKIP" ;;
        *)  echo "FAIL" ;;
    esac
}

run_step() {
    local name="$1"
    local fn="step_${name}"
    if ! declare -f "$fn" >/dev/null; then
        log "FAIL: unbekannter Schritt '$name'"
        return 1
    fi
    "$fn"
    local rc=$?
    local label
    label=$(result_label "$rc")
    case "$rc" in
        0|1)  log "STEP $name → $label" ;;
        10|20) log_stdout "STEP $name → $label" ;;
        *)    log "STEP $name → $label (rc=$rc)" ;;
    esac
    [ "$rc" -eq 1 ] && return 1
    return 0
}

if [ "$LIST_ONLY" -eq 1 ]; then
    printf "Bekannte Konvergenz-Schritte:\n"
    for s in "${CONVERGE_STEPS[@]}"; do printf "  - %s\n" "$s"; done
    exit 0
fi

log_stdout "[$HOSTNAME_SHORT] cortex-converge gestartet ($(ts))"
log_file   "RUN start host=$HOSTNAME_SHORT dry_run=$DRY_RUN only=${ONLY_STEP:-all}"

overall_rc=0
if [ -n "$ONLY_STEP" ]; then
    run_step "$ONLY_STEP" || overall_rc=1
else
    for s in "${CONVERGE_STEPS[@]}"; do
        run_step "$s" || overall_rc=1
    done
fi

log_file "RUN end host=$HOSTNAME_SHORT overall=$overall_rc"
exit $overall_rc
