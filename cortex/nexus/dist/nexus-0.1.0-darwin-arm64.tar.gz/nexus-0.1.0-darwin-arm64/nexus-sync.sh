#!/bin/bash
# ============================================================
# Nexus Auto-Sync — Git Pull/Push im Hintergrund
# ============================================================
# Wird alle 5 Minuten per launchd ausgefuehrt.
#
# Stufen (LL-049, seit 2026-04-25):
#   - Heartbeat-Check (Stufe 2): skipt Sync, wenn anderes Geraet kuerzlich aktiv
#   - Divergenz-Erkennung (Schicht 1): Drei-Punkte-Check vor Commit
#   - Aktive Konvergenz (Stufe 1): bei Divergenz erst Auto-Rebase versuchen,
#     Auto-Resolve fuer auto-generierte Files (DASHBOARD, Logs, Reports);
#     nur bei echten Inhalts-Konflikten Alarm
#   - Anti-Spam: Alarm nur einmal pro Divergenz-Phase
#
# Installation: cp plist nach ~/Library/LaunchAgents/, launchctl load.
# Deaktivieren: launchctl unload ~/Library/LaunchAgents/com.cortex.nexus-sync.plist
# ============================================================

NEXUS_DIR="$HOME/Cortex/Nexus"
LOG_FILE="$NEXUS_DIR/_memory/logs/nexus-sync.log"
LAST_SYNC_LOCAL="$NEXUS_DIR/.config/.last_sync_local"
ALARM_MARKER="$NEXUS_DIR/_memory/.divergence-alarmed"
HEARTBEAT_DIR="$NEXUS_DIR/.config/heartbeats"
HEARTBEAT_THRESHOLD=90  # Sek — andere Geraete als "aktiv" gelten, wenn juenger als das
ALARM_REPEAT_SECONDS="${NEXUS_SYNC_ALARM_REPEAT_SECONDS:-3600}"  # persistierende Divergenz nach 1h erneut melden
case "$ALARM_REPEAT_SECONDS" in
    ''|*[!0-9]*) ALARM_REPEAT_SECONDS=3600 ;;
esac

# === Welle 3 (2026-05-12) — Task-Lock + Approval-Marker + Health-JSON ===
# Pfade fuer Task-Awareness, Approval-Marker und maschinenlesbaren Drift-Report.
# Default ist MVP-soft: Checks warnen im Log und im Health-JSON, blockieren
# aber nicht. Mit `touch _memory/approvals/.enforce` werden die Checks hart
# (Push wird gestoppt, wenn R2-Outgoing-Diff ohne Approval-Marker existiert).
TASK_ACTIVE_DIR="$NEXUS_DIR/_memory/tasks/active"
APPROVAL_DIR="$NEXUS_DIR/_memory/approvals"
HEALTH_DIR="$NEXUS_DIR/_memory/health"
HEALTH_FILE="$HEALTH_DIR/sync-drift.json"
# R2-Pfade laut AUTONOMY_CONTRACT.md §2 — Outgoing-Diff in diesen Pfaden
# erwartet einen Approval-Marker.
R2_PATH_REGEX='^(_rules/|specs/|CLAUDE\.md$|SYSTEM_MAP\.md$|agent/|gateway/|tools/|nexus-sync\.sh$)'

# Auto-generierte Dateien, deren Konflikte beim Rebase gefahrlos mit "ours"
# aufgeloest werden duerfen (regenerieren sich beim naechsten Skript-Lauf).
# Cortex-Sanitizer-Pfade wurden im Phoenix-Reset 2026-05-08 entfernt; die
# entsprechenden Patterns sind in Welle 3 (2026-05-12) abgeraeumt worden.
AUTO_GEN_PATTERNS=(
    "Second Brain/DASHBOARD.md"
    "_memory/pending-questions.md"
    "_memory/pending-instructions.md"
    "_memory/health/sync-drift.json"
)
AUTO_GEN_GLOBS=(
    # Heartbeats (Uebergangsphase 2026-05-24): noch getrackt, solange nicht alle
    # Geraete das ref-basierte Skript fahren. Das neue Skript committet sie nicht
    # mehr (aus AUTO_ADD_WHITELIST entfernt), materialisiert sie aber als
    # Lese-Cache → sie sind auf umgestellten Geraeten "dirty". Als auto-gen
    # markiert, damit sie (a) nicht als manueller Drift gewertet werden und
    # (b) etwaige Rebase-Konflikte mit "ours" auto-aufgeloest werden.
    # Endgueltige Entfernung (git rm --cached) erst, wenn alle Geraete einen Ref
    # unter refs/heartbeats/* haben.
    ".config/heartbeats/*.heartbeat"
)

# Auto-Add-Whitelist (WV-002-Fix, seit 2026-04-28):
# NUR diese Pfade darf der Auto-Sync committen. Alle anderen Aenderungen
# bleiben uncommitted und muessen manuell ge-add'ed + committed werden.
# Das verhindert Phantom-Modifications, bei denen alte lokale Inhaltsversionen
# blind commited und gepushed wuerden (Vorfall 2026-04-26).
AUTO_ADD_WHITELIST=(
    # .config/heartbeats/*.heartbeat: ENTFERNT 2026-05-24 — Heartbeats syncen
    # jetzt ueber ephemere refs/heartbeats/<host> (siehe hb_publish/hb_fetch),
    # nicht mehr ueber main-Commits. Lokale Files sind gitignored Lese-Cache.
    "_memory/logs/*.log"
    "_memory/logs/*.err"
    "_memory/pending-questions.md"
    "_memory/pending-instructions.md"
    "_memory/health/sync-drift.json"
    # Cluster-State-Recorder (Welle 2026-06-01): jeder Mac schreibt
    # seinen HEAD-Hash pro Repo nach _state/cluster/<hostname>.json,
    # nexus-sync committet + synct → andere Macs sehen "wer steht wo"
    # beim Session-Start. Verhindert Doppelarbeit, wenn ein Repo bereits
    # auf einem anderen Mac weiterentwickelt wurde.
    "_state/cluster/*.json"
    "Second Brain/00 Kontext/Dialog.md"
    # LL-056 Backstop (2026-05-01): auto-generated Vault content from
    # sync-second-brain.py. Idempotenz-Helper im Skript verhindert Drift im
    # Normalfall; diese Pfade fangen Restmodifikationen ab, falls eine
    # substantielle MEMORY.md-Änderung tatsächlich anliegt und committet
    # werden muss. Glob-Match ist eng: nur die direkten Projekt-MDs und
    # die _MOC-Files dieser zwei Verzeichnisse.
    "Second Brain/10 Projekte/*.md"
    "Second Brain/30 Tutorials/_MOC Tutorials.md"
    "Second Brain/40 Regeln/_MOC Regeln.md"
)

# Log-Verzeichnis sicherstellen
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$HEARTBEAT_DIR"

# Maximal 1000 Zeilen im Log behalten
if [ -f "$LOG_FILE" ] && [ "$(wc -l < "$LOG_FILE")" -gt 1000 ]; then
    tail -500 "$LOG_FILE" > "${LOG_FILE}.tmp"
    mv "${LOG_FILE}.tmp" "$LOG_FILE"
fi

# Alle stdout/stderr ins Log umleiten
exec >> "$LOG_FILE" 2>&1

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

is_auto_gen_file() {
    local f="$1"
    local pattern
    for pattern in "${AUTO_GEN_PATTERNS[@]}"; do
        [ "$f" = "$pattern" ] && return 0
    done
    for pattern in "${AUTO_GEN_GLOBS[@]}"; do
        case "$f" in $pattern) return 0 ;; esac
    done
    return 1
}

is_auto_add_whitelisted() {
    # Prueft, ob ein Pfad in AUTO_ADD_WHITELIST steht (Bash-Glob-Match).
    local f="$1"
    local pattern
    for pattern in "${AUTO_ADD_WHITELIST[@]}"; do
        case "$f" in $pattern) return 0 ;; esac
    done
    return 1
}

# === Heartbeat-Refs (2026-05-24) ===
# Heartbeats sind ephemerer Koordinations-Zustand, KEINE Inhalts-Historie.
# Frueher (bis 2026-05-24) lag .config/heartbeats/<host>.heartbeat in der
# AUTO_ADD_WHITELIST → jeder Lauf jedes Geraets erzeugte einen Commit auf main
# (~700/Tag, ≈100% der Historie). Jetzt: jedes Geraet besitzt seinen eigenen
# Ref refs/heartbeats/<host> und macht NUR darauf force-update (parentloser
# Commit, Timestamp = Commit-Message). Kein Multi-Writer-Konflikt (jedes Geraet
# schreibt nur seinen Ref), kein Historie-Wachstum (force-update, alte Objekte
# werden server-seitig GC't), unsichtbar fuer `git log main`.
# Die lokalen .config/heartbeats/<host>.heartbeat bleiben als gitignored
# Lese-Cache erhalten — gateway/src/devices.ts, Doctor und Doku lesen sie
# unveraendert weiter; der Sync materialisiert sie nach jedem Fetch neu.

hb_fetch() {
    # Holt alle Geraete-Heartbeat-Refs vom Remote in lokale refs/heartbeats/*.
    git fetch -q origin '+refs/heartbeats/*:refs/heartbeats/*' 2>/dev/null || true
}

hb_publish() {
    # Veroeffentlicht den eigenen Heartbeat als force-update auf refs/heartbeats/<host>.
    # $1 = Unix-Timestamp. Braucht $HOSTNAME_SHORT (in 0.2 gesetzt).
    local ts="$1"
    local empty_tree commit refspec
    empty_tree=$(git hash-object -t tree /dev/null 2>/dev/null) || return 1
    commit=$(git commit-tree "$empty_tree" -m "$ts" 2>/dev/null) || return 1
    # Refspec via printf bauen (kein zsh-:modifier-Risiko; bash-safe ohnehin).
    refspec=$(printf '%s:refs/heartbeats/%s' "$commit" "$HOSTNAME_SHORT")
    git push -q --force origin "$refspec" 2>/dev/null
}

bootstrap_publish() {
    # Veroeffentlicht den aktuellen Bootstrap-Hash auf refs/bootstrap-applied/<host>.
    # $1 = vollstaendiger Commit-Hash (last_applied_hash). $2 = Unix-Timestamp.
    # Vom bootstrap-health-dashboard-Skill ausgewertet (Multi-Mac-Drift-Sicht).
    local applied_hash="$1"
    local ts="$2"
    local empty_tree commit refspec
    empty_tree=$(git hash-object -t tree /dev/null 2>/dev/null) || return 1
    # Subject = "hash|ts" damit beide Infos in einem Ref liegen.
    commit=$(git commit-tree "$empty_tree" -m "${applied_hash}|${ts}" 2>/dev/null) || return 1
    refspec=$(printf '%s:refs/bootstrap-applied/%s' "$commit" "$HOSTNAME_SHORT")
    git push -q --force origin "$refspec" 2>/dev/null
}

bootstrap_fetch() {
    # Holt alle Bootstrap-Applied-Refs vom Remote in lokale refs/bootstrap-applied/*.
    git fetch -q origin '+refs/bootstrap-applied/*:refs/bootstrap-applied/*' 2>/dev/null || true
}

hb_is_tracked() {
    # Ist .config/heartbeats/<host>.heartbeat aktuell im Git-Index getrackt?
    # Migrations-relevant: getrackte Files (= Altgeraet committet sie noch) duerfen
    # NICHT materialisiert werden, sonst werden sie dirty und die spaetere
    # Selbst-Bereinigung (git rm) loest beim Verteilen einen modify/delete-Konflikt
    # aus. Ungetrackte Files sind gitignored → freies Materialisieren erlaubt.
    git ls-files --error-unmatch ".config/heartbeats/$1.heartbeat" >/dev/null 2>&1
}

# === Welle 3 Helper (2026-05-12) ===

count_active_r2_tasks() {
    [ -d "$TASK_ACTIVE_DIR" ] || { echo 0; return; }
    local count=0
    local f
    for f in "$TASK_ACTIVE_DIR"/*.yaml; do
        [ -f "$f" ] || continue
        if grep -qE "^risk_level: *R2" "$f" 2>/dev/null && \
           grep -qE "^status: *in_progress" "$f" 2>/dev/null; then
            count=$((count + 1))
        fi
    done
    echo "$count"
}

count_approval_markers() {
    [ -d "$APPROVAL_DIR" ] || { echo 0; return; }
    local count=0
    local f
    for f in "$APPROVAL_DIR"/*.yaml; do
        [ -f "$f" ] && count=$((count + 1))
    done
    echo "$count"
}

approval_enforce_active() {
    [ -f "$APPROVAL_DIR/.enforce" ]
}

outgoing_r2_paths() {
    # Listet Pfade aus origin/main..HEAD, die in R2 fallen (eine pro Zeile).
    git log --name-only --pretty=format: origin/main..HEAD 2>/dev/null \
        | grep -E "$R2_PATH_REGEX" \
        | sort -u
}

write_health_json() {
    # Maschinenlesbarer Drift-/Sync-Snapshot. Doctor liest diese Datei.
    mkdir -p "$HEALTH_DIR"
    local head_sha remote_sha enforce active_r2 approval_count r2_outgoing dirty_count nonwl_count
    head_sha=$(git rev-parse --short HEAD 2>/dev/null || echo "")
    remote_sha=$(git rev-parse --short origin/main 2>/dev/null || echo "")
    if approval_enforce_active; then enforce=true; else enforce=false; fi
    active_r2=$(count_active_r2_tasks)
    approval_count=$(count_approval_markers)
    if [ -n "$(outgoing_r2_paths)" ]; then r2_outgoing=true; else r2_outgoing=false; fi
    dirty_count=$(git status --porcelain 2>/dev/null | wc -l | tr -d ' ')
    nonwl_count="${1:-0}"

    cat > "$HEALTH_FILE" <<EOF
{
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "hostname": "$(hostname -s)",
  "head": "${head_sha}",
  "remote_head": "${remote_sha}",
  "dirty_count": ${dirty_count},
  "non_whitelist_drift_count": ${nonwl_count},
  "active_r2_tasks": ${active_r2},
  "approval_markers": ${approval_count},
  "approval_enforce": ${enforce},
  "outgoing_r2_diff": ${r2_outgoing}
}
EOF
}

report_pending_manual_drift() {
    # Zaehlt Aenderungen, die NICHT in der Whitelist liegen — das sind die,
    # die manuell committet werden muessen. Schreibt ins Log + in eigenen
    # Drift-Report. Verhindert wiederkehrende 5-Tage-Drift (Vorfall 2026-04-30).
    local drift_count=0
    local drift_list=""
    local line path
    while IFS= read -r line; do
        [ -z "$line" ] && continue
        path="${line:3}"
        # Quoted paths entfernen
        path="${path%\"}"; path="${path#\"}"
        if ! is_auto_add_whitelisted "$path" && ! is_auto_gen_file "$path"; then
            drift_count=$((drift_count + 1))
            drift_list="${drift_list}${line}"$'\n'
        fi
    done < <(git status --porcelain)

    local drift_report="$NEXUS_DIR/_memory/logs/drift-pending-manual.log"
    if [ "$drift_count" -gt 5 ]; then
        log "DRIFT WARNUNG: ${drift_count} uncommittete Datei(en) ausserhalb Auto-Whitelist — bitte manuell committen"
        {
            echo "=== Drift-Report $(date '+%Y-%m-%d %H:%M:%S') auf $(hostname -s) ==="
            echo "Anzahl: ${drift_count}"
            echo "$drift_list"
            echo ""
        } > "$drift_report"
    elif [ -f "$drift_report" ]; then
        rm -f "$drift_report"
        log "DRIFT-RECOVERY: Drift-Report geloescht (Drift behoben)"
    fi
}

alarm_marker_mtime() {
    [ -f "$ALARM_MARKER" ] || { echo 0; return; }
    stat -f '%m' "$ALARM_MARKER" 2>/dev/null || stat -c '%Y' "$ALARM_MARKER" 2>/dev/null || echo 0
}

send_divergence_alarm() {
    local short_local="$1"
    local short_remote="$2"
    local short_base="$3"
    local reason="$4"
    local host_short
    host_short=$(hostname -s)
    local alarm_kind="DIVERGENZ"

    # Anti-Spam mit Wiederhol-Reminder:
    # Der Marker verhindert 5-Min-Spam, darf aber persistierende Drift nicht
    # stundenlang verschweigen (Vorfall 2026-05-13: 9 h Funkstille auf M5).
    if [ -f "$ALARM_MARKER" ]; then
        local marker_mtime marker_age next_repeat
        marker_mtime=$(alarm_marker_mtime)
        marker_age=0
        if [ "$marker_mtime" -gt 0 ] 2>/dev/null; then
            marker_age=$(($(date +%s) - marker_mtime))
        fi
        if [ "$marker_age" -lt "$ALARM_REPEAT_SECONDS" ]; then
            next_repeat=$((ALARM_REPEAT_SECONDS - marker_age))
            log "ALARM unterdrueckt (Marker existiert, age=${marker_age}s, repeat in ${next_repeat}s)"
            return 0
        fi
        alarm_kind="DIVERGENZ PERSISTIERT"
        log "ALARM wiederholt (Marker age=${marker_age}s >= repeat=${ALARM_REPEAT_SECONDS}s)"
    fi

    # macOS-Notification
    osascript -e "display notification \"${alarm_kind}: lokal ${short_local} <-> remote ${short_remote} — Sync gestoppt\" with title \"Nexus Sync ALARM\" sound name \"Sosumi\"" 2>/dev/null

    # Telegram-Alarm
    local tg_env="$NEXUS_DIR/tools/telegram-bridge/.env"
    if [ -f "$tg_env" ]; then
        local tg_token tg_chat
        tg_token=$(grep '^TELEGRAM_BOT_TOKEN=' "$tg_env" | cut -d= -f2- | tr -d '"' | tr -d "'")
        tg_chat=$(grep '^TELEGRAM_ALLOWED_CHAT_IDS=' "$tg_env" | cut -d= -f2- | tr -d '"' | tr -d "'" | cut -d, -f1)
        if [ -n "$tg_token" ] && [ -n "$tg_chat" ]; then
            local msg
            msg=$(printf '⚠️ Nexus-Sync %s\nGerät: %s\nGrund: %s\n\nlokal:  %s\nremote: %s\nbase:   %s\n\nLösung am betroffenen Gerät:\n  cd ~/Cortex/Nexus\n  git pull --rebase\n  # bei DASHBOARD-Konflikt: git rebase --skip\n  git push\n\nDanach läuft der Auto-Sync wieder. Auto-Konvergenz versucht es bei trivialen Fällen selbst — dieser Alarm bedeutet: echter Inhalts-Konflikt.\n\nHinweis: Bei weiter bestehender Divergenz wird dieser Reminder nach %s Sekunden erneut gesendet.' "$alarm_kind" "$host_short" "$reason" "$short_local" "$short_remote" "$short_base" "$ALARM_REPEAT_SECONDS")
            curl -s -X POST "https://api.telegram.org/bot${tg_token}/sendMessage" \
                --data-urlencode "chat_id=${tg_chat}" \
                --data-urlencode "text=${msg}" >/dev/null
        fi
    fi

    # Marker setzen, damit kein 5-Min-Spam
    printf '%s — %s: local=%s remote=%s reason=%s repeat_seconds=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$alarm_kind" "$short_local" "$short_remote" "$reason" "$ALARM_REPEAT_SECONDS" > "$ALARM_MARKER"
    log "ALARM gesendet/aktualisiert, Marker gesetzt"
}

# === Pre-Checks ===

if [ ! -d "$NEXUS_DIR/.git" ]; then
    log "FEHLER: $NEXUS_DIR ist kein Git-Repo"
    exit 1
fi

cd "$NEXUS_DIR"

if ! git ls-remote --exit-code origin &>/dev/null; then
    log "SKIP: GitHub nicht erreichbar (offline?)"
    exit 0
fi

# === 0.15. Phasen-Jitter (Anti-Lock, 2026-05-31) ===
# Wenn zwei Macs mit identischem StartInterval=300s im 30-40s-Abstand starten,
# blockieren sie sich gegenseitig dauerhaft via HEARTBEAT_THRESHOLD=90s (das
# "andere Geraet war vor X<90s aktiv → diesen Lauf ueberspringen"-Check). Vorfall
# C-M-02 wurde 7h lang von C-M-04 ausgesperrt). Random-Jitter 0-30s entkoppelt
# die Phasen ueber wenige Laeufe.
JITTER=$((RANDOM % 30))
[ "$JITTER" -gt 0 ] && sleep "$JITTER"

# === 0.2. Heartbeat-Check (Stufe 2): andere Geraete aktiv? ===
# Quelle der Liveness-Info sind seit 2026-05-24 die ephemeren Refs
# refs/heartbeats/<host> (siehe hb_fetch/hb_publish), NICHT mehr getrackte
# Dateien auf main. Die lokalen .config/heartbeats/<host>.heartbeat werden hier
# aus den Refs neu materialisiert (gitignored Lese-Cache fuer Gateway/Doctor).

HOSTNAME_SHORT=$(hostname -s)
OWN_HEARTBEAT="$HEARTBEAT_DIR/${HOSTNAME_SHORT}.heartbeat"
NOW=$(date +%s)
mkdir -p "$HEARTBEAT_DIR"

hb_fetch

# Migrations-Sicherheit (2026-05-24): getrackte Heartbeat-Cache-Files hart auf
# den committeten HEAD-Stand zuruecksetzen — verwirft Materialisierungs-"dirt"
# UND raeumt etwaige staged/unmerged Konflikt-Reste weg (Selbstheilung, falls ein
# autostash-pop einmal einen modify/delete-Rest hinterlassen hat). Dadurch
# bleiben getrackte Files immer sauber → jede eingehende Heartbeat-Loeschung
# (Selbst-Bereinigung) ist ein konfliktfreier Fast-Forward. Ungetrackte
# (gitignored) Cache-Files bleiben unberuehrt. No-Op, wenn nichts getrackt ist.
git checkout -q HEAD -- .config/heartbeats/ 2>/dev/null || true

for ref in $(git for-each-ref --format='%(refname)' refs/heartbeats/ 2>/dev/null); do
    other_host="${ref#refs/heartbeats/}"
    [ "$other_host" = "$HOSTNAME_SHORT" ] && continue
    other_time=$(git log -1 --format=%s "$ref" 2>/dev/null || echo 0)
    case "$other_time" in ''|*[!0-9]*) other_time=0 ;; esac
    # Lese-Cache NUR fuer ungetrackte Files materialisieren (getrackte werden vom
    # jeweiligen Altgeraet via Commit gepflegt und muessen sauber bleiben).
    hb_is_tracked "$other_host" || echo "$other_time" > "$HEARTBEAT_DIR/${other_host}.heartbeat"
    age=$((NOW - other_time))
    if [ "$age" -ge 0 ] && [ "$age" -lt "$HEARTBEAT_THRESHOLD" ]; then
        log "WAIT: $other_host war vor ${age}s aktiv (< ${HEARTBEAT_THRESHOLD}s) — diesen Lauf ueberspringen"
        hb_is_tracked "$HOSTNAME_SHORT" || echo "$NOW" > "$OWN_HEARTBEAT"
        hb_publish "$NOW" || log "WARN: heartbeat-ref push fehlgeschlagen"
        exit 0
    fi
done

# Eigenen Heartbeat schreiben (Cache nur wenn ungetrackt) + ephemerer Ref
hb_is_tracked "$HOSTNAME_SHORT" || echo "$NOW" > "$OWN_HEARTBEAT"
hb_publish "$NOW" || log "WARN: heartbeat-ref push fehlgeschlagen"

# === 0.3. Slash-Command-Self-Heal ===
# Halte ~/.claude/commands/{autonomy,safe,cortex}-mode.md mit den Repo-Templates
# synchron. Drift entsteht, wenn Repo-Templates aktualisiert wurden, aber
# install_slash_commands.sh seit dem Pull nicht erneut lief. Stiller No-Op,
# wenn Templates identisch sind.
#
# Vor 2026-05-19 stand dieser Block als 2a NACH Divergenz-Check + Pull.
# Folge: Bei Divergenz mit exit 2 (siehe 0.4) lief Self-Heal nie — auf
# Mac-Studio waren die Slash-Command-Templates 11 Tage lang im alten,
# defekten Stand, obwohl die korrekten Templates lokal im Repo lagen.
# Position vor Divergenz-Check ist sicher, weil dieser Block nur READ-only
# auf $NEXUS_DIR zugreift und ins HOME schreibt — kein Konflikt mit Git.
COMMANDS_SRC="$NEXUS_DIR/tools/cortex-mode/commands-template"
COMMANDS_DST="$HOME/.claude/commands"
if [ -d "$COMMANDS_SRC" ]; then
    mkdir -p "$COMMANDS_DST"
    slash_drift=0
    for tpl in "$COMMANDS_SRC"/*.md; do
        [ -f "$tpl" ] || continue
        name="$(basename "$tpl")"
        target="$COMMANDS_DST/$name"
        if [ ! -f "$target" ] || ! cmp -s "$tpl" "$target"; then
            cp -f "$tpl" "$target"
            slash_drift=$((slash_drift + 1))
        fi
    done
    if [ "$slash_drift" -gt 0 ]; then
        log "SLASH-HEAL: ${slash_drift} Slash-Command-Template(s) aktualisiert in $COMMANDS_DST"
    fi
fi

# === 0.4. Divergenz-Check + Aktive Konvergenz (Stufe 1) ===

git fetch origin main >/dev/null 2>&1

# Branch-aware Main-FF (Multi-Device-Sync, 2026-05-13):
# Wenn HEAD nicht auf main ist (z.B. Codex arbeitet auf Feature-Branch),
# main-Ref nur fast-forwarden — KEIN Rebase des aktuellen Branches gegen
# origin/main. Sonst hängt der Sync auf Feature-Branches dauerhaft fest
# (Vorfall M5 2026-05-13, 9 h Stillstand auf codex/local-first-discovery).
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
if [ -n "$CURRENT_BRANCH" ] && [ "$CURRENT_BRANCH" != "main" ] && [ "$CURRENT_BRANCH" != "HEAD" ]; then
    MAIN_LOCAL=$(git rev-parse main 2>/dev/null)
    MAIN_REMOTE=$(git rev-parse origin/main 2>/dev/null)
    if [ -n "$MAIN_LOCAL" ] && [ -n "$MAIN_REMOTE" ] && [ "$MAIN_LOCAL" != "$MAIN_REMOTE" ]; then
        if git merge-base --is-ancestor "$MAIN_LOCAL" "$MAIN_REMOTE" 2>/dev/null; then
            git branch -f main origin/main 2>/dev/null && \
                log "MAIN-FF: lokal main ${MAIN_LOCAL:0:7} -> ${MAIN_REMOTE:0:7} (HEAD bleibt auf $CURRENT_BRANCH)"
        else
            log "MAIN-DIVERGENT: lokal main ${MAIN_LOCAL:0:7} ist keine reine Vor-Version von origin/main ${MAIN_REMOTE:0:7} — kein FF, Skript überspringt Divergenz-Logik"
        fi
    fi
    log "BRANCH-SKIP: HEAD auf $CURRENT_BRANCH (nicht main) — Divergenz-/Rebase-Logik wird übersprungen, Heartbeat ist gesetzt"
    exit 0
fi

LOCAL_HEAD=$(git rev-parse HEAD 2>/dev/null)
REMOTE_HEAD=$(git rev-parse origin/main 2>/dev/null)
MERGE_BASE=$(git merge-base HEAD origin/main 2>/dev/null)

if [ -n "$LOCAL_HEAD" ] && [ -n "$REMOTE_HEAD" ] && [ -n "$MERGE_BASE" ]; then
    if [ "$LOCAL_HEAD" = "$REMOTE_HEAD" ] || \
       [ "$LOCAL_HEAD" = "$MERGE_BASE" ] || \
       [ "$REMOTE_HEAD" = "$MERGE_BASE" ]; then
        # OK: synchron, lokal hinter, oder lokal voraus — Recovery
        if [ -f "$ALARM_MARKER" ]; then
            rm -f "$ALARM_MARKER"
            log "RECOVERY: Divergenz aufgeloest, Alarm-Marker entfernt"
        fi
    else
        # Divergenz erkannt — Auto-Konvergenz versuchen
        SHORT_LOCAL=${LOCAL_HEAD:0:7}
        SHORT_REMOTE=${REMOTE_HEAD:0:7}
        SHORT_BASE=${MERGE_BASE:0:7}
        log "DIVERGENZ: lokal=$SHORT_LOCAL remote=$SHORT_REMOTE base=$SHORT_BASE — versuche Auto-Konvergenz"

        # --autostash (2026-05-19): heartbeat-File ist immer dirty zwischen
        # 0.2 (Heartbeat-Write) und 1 (Whitelist-Commit). Ohne autostash
        # bricht der Rebase mit "unstaged changes" ab und Macs laufen
        # endlos in DIVERGENZ + ALARM unterdrueckt (Vorfall M5 05:24-05:47).
        REBASE_OUTPUT=$(git pull --rebase --autostash origin main 2>&1)
        REBASE_STATUS=$?

        if [ $REBASE_STATUS -eq 0 ]; then
            log "AUTO-KONVERGENZ erfolgreich (rebase ohne Konflikt)"
            rm -f "$ALARM_MARKER"
        else
            # Konflikt — pruefe ob alle Konflikt-Dateien auto-generiert sind
            CONFLICTED=$(git diff --name-only --diff-filter=U)
            if [ -z "$CONFLICTED" ]; then
                # Rebase fehlgeschlagen, aber keine Konflikt-Files? Dann aborten
                log "AUTO-KONVERGENZ fehlgeschlagen (kein Konflikt-File sichtbar): $REBASE_OUTPUT"
                git rebase --abort 2>/dev/null
                send_divergence_alarm "$SHORT_LOCAL" "$SHORT_REMOTE" "$SHORT_BASE" "Rebase-Fehler ohne Konflikt-File"
                exit 2
            fi

            ALL_AUTO=true
            REAL_CONFLICT=""
            while IFS= read -r f; do
                [ -z "$f" ] && continue
                if ! is_auto_gen_file "$f"; then
                    ALL_AUTO=false
                    REAL_CONFLICT="$f"
                    break
                fi
            done <<< "$CONFLICTED"

            if [ "$ALL_AUTO" = true ]; then
                # Auto-Resolve: alle Konflikte sind auto-generierte Files
                log "AUTO-RESOLVE: alle Konflikt-Files sind auto-gen — nehme ours"
                while IFS= read -r f; do
                    [ -z "$f" ] && continue
                    git checkout --ours "$f" 2>/dev/null
                    git add "$f" 2>/dev/null
                done <<< "$CONFLICTED"
                CONT_OUTPUT=$(GIT_EDITOR=true git rebase --continue 2>&1)
                CONT_STATUS=$?
                if [ $CONT_STATUS -eq 0 ]; then
                    log "AUTO-KONVERGENZ erfolgreich nach Auto-Resolve"
                    rm -f "$ALARM_MARKER"
                else
                    log "AUTO-RESOLVE fehlgeschlagen — abort + alarm: $CONT_OUTPUT"
                    git rebase --abort 2>/dev/null
                    send_divergence_alarm "$SHORT_LOCAL" "$SHORT_REMOTE" "$SHORT_BASE" "Auto-Resolve fehlgeschlagen"
                    exit 2
                fi
            else
                # Echter Konflikt — abort + alarm
                log "ECHTER INHALTS-KONFLIKT in $REAL_CONFLICT — Sync gestoppt"
                git rebase --abort 2>/dev/null
                send_divergence_alarm "$SHORT_LOCAL" "$SHORT_REMOTE" "$SHORT_BASE" "Inhalts-Konflikt in $REAL_CONFLICT"
                exit 2
            fi
        fi
    fi
fi

# === 0.45. Post-Pull-Bootstrap (Self-Heal, 2026-05-31) ===
#
# Wenn der Pull bootstrap-relevante Files aktualisiert hat (Hooks,
# install_*-Skripte, LaunchAgent-Plists), ruft dieser Block automatisch
# install_bootstrap.sh auf. Damit verteilt sich jede Skript-Änderung,
# die Stracke von einem Mac pusht, auf alle anderen Macs in <= 10 Min,
# OHNE dass jemand auf den Ziel-Macs einloggen und manuell tippen muss.
#
# Heilt die wiederkehrende Bitte „auf jedem Mac bitte einmal bootstrap
# laufen lassen" und passt zur Memory-Direktive
# `feedback_nexus_always_latest.md` („nicht nachfragen, sondern Drift fixen").
#
# Self-Kill-Schutz: install_bootstrap.sh wird mit
# BOOTSTRAP_SKIP_NEXUS_SYNC=1 aufgerufen, damit der laufende nexus-sync-
# LaunchAgent sich nicht selbst unloaded.

BOOTSTRAP_STATE_FILE="$NEXUS_DIR/_memory/.bootstrap-state.json"
BOOTSTRAP_INSTALLER="$NEXUS_DIR/tools/cortex-mode/bin/install_bootstrap.sh"
BOOTSTRAP_PATHS=(
    "tools/cortex-mode/bin/install_bootstrap.sh"
    "tools/cortex-mode/bin/install_w1_hooks.sh"
    "tools/cortex-mode/bin/install_slash_commands.sh"
    "tools/cortex-mode/bin/auto_allow.py"
    "tools/cortex-mode/bin/wave_end_push.py"
    "tools/cortex-mode/bin/inject.sh"
    "tools/cortex-mode/commands-template"
    "com.cortex.nexus-sync.plist"
    "com.cortex.nexus-sync-healthcheck.plist"
    "com.cortex.connexio-inbox-notify.plist"
    "gateway/launchagents/install.sh"
)

if [ -x "$BOOTSTRAP_INSTALLER" ]; then
    # Letzter Commit-Hash, der irgendeinen bootstrap-relevanten Pfad berührt hat
    CURRENT_BOOTSTRAP_HASH=$(git log -1 --format=%H -- "${BOOTSTRAP_PATHS[@]}" 2>/dev/null)

    LAST_APPLIED_HASH=""
    if [ -f "$BOOTSTRAP_STATE_FILE" ]; then
        LAST_APPLIED_HASH=$(python3 -c "
import json,sys
try:
    print(json.load(open(sys.argv[1])).get('last_applied_hash',''))
except Exception:
    print('')
" "$BOOTSTRAP_STATE_FILE" 2>/dev/null)
    fi

    if [ -n "$CURRENT_BOOTSTRAP_HASH" ] && [ "$CURRENT_BOOTSTRAP_HASH" != "$LAST_APPLIED_HASH" ]; then
        log "POST-PULL-BOOTSTRAP: bootstrap-Files geändert (${LAST_APPLIED_HASH:0:7} -> ${CURRENT_BOOTSTRAP_HASH:0:7}) — führe install_bootstrap.sh aus"
        BOOTSTRAP_OUTPUT=$(BOOTSTRAP_SKIP_NEXUS_SYNC=1 bash "$BOOTSTRAP_INSTALLER" 2>&1)
        BOOTSTRAP_STATUS=$?
        if [ $BOOTSTRAP_STATUS -eq 0 ]; then
            mkdir -p "$(dirname "$BOOTSTRAP_STATE_FILE")"
            python3 -c "
import json,sys,time
json.dump({
    'last_applied_hash': sys.argv[1],
    'last_applied_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    'hostname': sys.argv[2],
}, open(sys.argv[3], 'w'), indent=2)
" "$CURRENT_BOOTSTRAP_HASH" "$(hostname -s)" "$BOOTSTRAP_STATE_FILE"
            log "POST-PULL-BOOTSTRAP: erfolgreich, Marker auf ${CURRENT_BOOTSTRAP_HASH:0:7}"
            # Multi-Mac-Sichtbarkeit: applied-Hash als Ref pushen, damit
            # bootstrap-health-dashboard auf jedem Mac sieht wer wann auf
            # welchem Hash steht.
            bootstrap_publish "$CURRENT_BOOTSTRAP_HASH" "$(date +%s)" \
                || log "WARN: bootstrap-applied-ref push fehlgeschlagen"
        else
            log "POST-PULL-BOOTSTRAP: FEHLER exit=$BOOTSTRAP_STATUS — Marker nicht gesetzt, Retry beim nächsten Lauf"
            log "POST-PULL-BOOTSTRAP-OUTPUT (gekürzt): $(echo "$BOOTSTRAP_OUTPUT" | tail -5 | tr '\n' '|')"
        fi
    fi
fi

# === 0.5. Second-Brain-Sync ===

if [ -x "$NEXUS_DIR/_skripte/sync-second-brain.py" ]; then
    SB_OUTPUT=$(python3 "$NEXUS_DIR/_skripte/sync-second-brain.py" --quiet 2>&1)
    SB_STATUS=$?
    if [ $SB_STATUS -ne 0 ]; then
        log "WARN: second-brain-sync fehlgeschlagen (exit $SB_STATUS): $SB_OUTPUT"
    fi
fi

# === 0.6. Task-Lock-Hinweis (Welle 3, soft) ===
# Wenn aktive R2-Tasks existieren, im Log vermerken. Der Auto-Sync-Commit
# selbst ist Whitelist-eng und kann keine R2-Pfade vereinnahmen — das Lock
# ist informativ, damit ein paralleler Welle-Sync nicht ueberraschend
# wirkt.
ACTIVE_R2_COUNT=$(count_active_r2_tasks)
if [ "$ACTIVE_R2_COUNT" -gt 0 ]; then
    log "TASK-LOCK: ${ACTIVE_R2_COUNT} aktive R2-Task(s) im Lauf — Auto-Sync bleibt Whitelist-eng"
fi

# === 1. Lokale Aenderungen committen (Whitelist-gefiltert, WV-002-Fix V2) ===
#
# WV-002 V2 (seit 2026-04-29 nach Vorfall Session 51):
# Vorher: `git add -- whitelisted; git commit -m ...` committete ALLES, was
# staged war — also auch Files, die der Nutzer manuell ge-add'ed hatte.
# Folge: User-Workflow `git add A B; git commit ...` wurde von Auto-Sync
# vereinnahmt — manuelle Commits gingen mit „Auto-sync: ... 1 Dateien"-Message
# unter.
#
# Fix: WHITELISTED_PATHS-Array sammeln + `git commit -- "${paths[@]}"` mit
# explizitem Pathspec. Das committet NUR die genannten Pfade aus der
# Working-Copy, unabhaengig vom restlichen Staging-Status. User-Stages
# bleiben unberuehrt.

WHITELISTED_PATHS=()
NON_WHITELIST_PATHS=()

while IFS= read -r line; do
    [ -z "$line" ] && continue
    # Pfad ab Position 4 (nach "XY ")
    p="${line:3}"
    # Renames "X -> Y" → wir nehmen den neuen Pfad Y
    case "$p" in *" -> "*) p="${p##* -> }" ;; esac
    # Quoting durch Git bei Sonderzeichen ("path with spaces") entfernen
    case "$p" in
        \"*\") p="${p#\"}"; p="${p%\"}" ;;
    esac

    if is_auto_add_whitelisted "$p"; then
        if [ -e "$p" ]; then
            WHITELISTED_PATHS+=("$p")
        else
            log "SKIP: Whitelist-Pfad fehlt lokal: $p"
        fi
    elif is_auto_gen_file "$p"; then
        : # auto-gen (z.B. Heartbeat-Cache): weder Auto-Commit noch manueller Drift
    else
        NON_WHITELIST_PATHS+=("$p")
    fi
done < <(git status --porcelain 2>/dev/null)

if [ ${#WHITELISTED_PATHS[@]} -gt 0 ]; then
    # Stage NUR die whitelisted Pfade — bestehender Staging-Status anderer Files bleibt unberuehrt
    git add -- "${WHITELISTED_PATHS[@]}" 2>/dev/null
    # Commit mit EXPLIZITER Pathspec — committet nur diese Pfade, ignoriert anderen Stage
    git commit --quiet -m "Auto-sync: $(date '+%Y-%m-%d %H:%M') — ${#WHITELISTED_PATHS[@]} Dateien geaendert" -- "${WHITELISTED_PATHS[@]}"
    log "COMMIT: ${#WHITELISTED_PATHS[@]} Dateien (Whitelist, pathspec-isoliert)"
fi

if [ ${#NON_WHITELIST_PATHS[@]} -gt 0 ]; then
    log "INFO: ${#NON_WHITELIST_PATHS[@]} Aenderungen ausserhalb Whitelist (manueller Commit erforderlich):"
    for p in "${NON_WHITELIST_PATHS[@]}"; do
        log "  - $p"
    done
fi

# === 2. Pull (defensiv, sollte nach Auto-Konvergenz no-op sein) ===

PULL_OUTPUT=$(git pull --rebase --autostash origin main 2>&1)
PULL_STATUS=$?

if [ $PULL_STATUS -ne 0 ]; then
    git rebase --abort 2>/dev/null
    log "KONFLIKT bei spaetem Pull — manuell loesen! Output: $PULL_OUTPUT"
    osascript -e 'display notification "Git-Konflikt im Nexus — bitte manuell loesen!" with title "Nexus Sync" sound name "Basso"' 2>/dev/null
    exit 1
fi

# === 2b. Approval-Marker-Check vor Push (Welle 3, 2026-05-12) ===
# Wenn HEAD..origin/main einen Diff in R2-Pfaden enthaelt, erwartet das
# Modell einen Approval-Marker unter _memory/approvals/. Default-Modus:
# log-only. Mit `touch _memory/approvals/.enforce` wird der Push hart
# gestoppt, wenn kein Marker existiert.
PUSH_BLOCKED_BY_APPROVAL=false
R2_OUTGOING=$(outgoing_r2_paths)
if [ -n "$R2_OUTGOING" ]; then
    APPROVAL_COUNT=$(count_approval_markers)
    if [ "$APPROVAL_COUNT" -gt 0 ]; then
        log "APPROVAL OK: ${APPROVAL_COUNT} Approval-Marker fuer R2-Outgoing-Diff vorhanden"
    else
        if approval_enforce_active; then
            log "APPROVAL FEHLT (enforce aktiv): R2-Outgoing-Diff ohne Approval-Marker — Push gestoppt"
            while IFS= read -r p; do log "  - $p"; done <<< "$R2_OUTGOING"
            PUSH_BLOCKED_BY_APPROVAL=true
        else
            log "APPROVAL FEHLT (soft): R2-Outgoing-Diff ohne Approval-Marker — informativ"
            while IFS= read -r p; do log "  - $p"; done <<< "$R2_OUTGOING"
        fi
    fi
fi

# === 3. Push ===

if [ "$PUSH_BLOCKED_BY_APPROVAL" = true ]; then
    log "PUSH: skipped (approval enforce gate)"
elif git status --porcelain origin/main..HEAD 2>/dev/null | grep -q .; then
    git push origin main --quiet 2>/dev/null
    PUSH_STATUS=$?
    if [ $PUSH_STATUS -eq 0 ]; then
        log "PUSH: Erfolgreich"
    else
        log "PUSH: Fehlgeschlagen (Status $PUSH_STATUS)"
    fi
else
    git push origin main --quiet 2>/dev/null
fi

log "SYNC: OK"

# === 4. Heartbeat erneuern (nach erfolgreichem Sync) ===
HB_NOW=$(date +%s)
hb_is_tracked "$HOSTNAME_SHORT" || echo "$HB_NOW" > "$OWN_HEARTBEAT"
hb_publish "$HB_NOW" || log "WARN: heartbeat-ref push fehlgeschlagen"

# === 4b. Drift-Report (manuell zu committende Aenderungen) ===
report_pending_manual_drift

# === 4c. Maschinenlesbarer Health-Snapshot (Welle 3, 2026-05-12) ===
write_health_json "${#NON_WHITELIST_PATHS[@]}"

# === 5. Lokalen Runtime-State aktualisieren ===
if command -v python3 >/dev/null 2>&1; then
    python3 - "$LAST_SYNC_LOCAL" "$(hostname -s)" <<'PYEOF' || log "WARN: .last_sync_local-Update fehlgeschlagen"
import json, sys
from datetime import datetime, timezone
from pathlib import Path

path = Path(sys.argv[1])
hostname = sys.argv[2]
now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

try:
    data = json.loads(path.read_text()) if path.exists() else {}
except Exception:
    data = {}

data["hostname"] = hostname
data["last_sync"] = now
if "first_sync" not in data:
    data["first_sync"] = now

path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
print(f".last_sync_local: {hostname}.last_sync = {now}")
PYEOF
fi

# === 6. Heartbeat-Migrations-Selbstbereinigung (2026-05-24, TEMPORAER) ===
# Entfernt das EIGENE getrackte Heartbeat-File aus main, sobald dieses Geraet
# ref-basiert laeuft (Selbst-Bereinigung, idempotent, mit Schonfrist). Jedes
# Geraet bereinigt nur sich selbst — kein manueller Eingriff an den Rechnern.
# Eigenstaendiges, loeschbares Skript: Status via `heartbeat-migration-cleanup.sh
# status`. Loeschbar, sobald der Status "ALLE BEREINIGT" meldet (dann auch diesen
# Block entfernen). No-Op, wenn das Skript fehlt oder schon bereinigt ist.
MIGRATION_CLEANUP="$NEXUS_DIR/tools/cortex-mode/bin/heartbeat-migration-cleanup.sh"
[ -x "$MIGRATION_CLEANUP" ] && bash "$MIGRATION_CLEANUP" >>"$LOG_FILE" 2>&1 || true

# === 7. Self-Applying-State (cortex-converge) ===
# Nach erfolgreichem Sync prüft cortex-converge.sh idempotent, ob dieser
# Mac dem Kollektiv-Soll entspricht (Cortex-Web geklont, launchd-Jobs
# installiert, …). Konvergenz-Schritte werden im Skript-Manifest gepflegt.
# Fehler hier dürfen den Sync nicht blockieren — nur loggen.
CONVERGE_SCRIPT="$NEXUS_DIR/scripts/cortex-converge.sh"
if [ -x "$CONVERGE_SCRIPT" ]; then
    "$CONVERGE_SCRIPT" >/dev/null 2>&1 \
        && log "CONVERGE: ok" \
        || log "CONVERGE: WARN — Konvergenz teilweise fehlgeschlagen, siehe _memory/logs/cortex-converge.log"
fi
