#!/usr/bin/env bash
# Stop-Hook (asyncRewake) — pollt _memory/telegram-inbox.jsonl im Background.
# Sobald eine ungelesene Nachricht (mit passender oder ohne Tag) auftaucht,
# druckt sie nach stdout und exit-Code 2 weckt Claude (AsyncRewake-Mechanismus).
#
# Wenn keine Nachricht in MAX_WAIT_S kommt, exit 0 — Claude bleibt schlafend.
# Beim naechsten Stop-Event startet ein neuer Watcher; idempotent.

set -euo pipefail

INBOX="${HOME}/Cortex/Nexus/_memory/telegram-inbox.jsonl"
ARCHIVE="${HOME}/Cortex/Nexus/_memory/telegram-inbox.consumed.jsonl"
PROCESSOR="${HOME}/Cortex/Nexus/tools/telegram-inbox-hook/process_inbox.py"
POLL_INTERVAL_S=3
MAX_WAIT_S=1700  # < 1800s Hook-Timeout, bissel Puffer

PYTHON_BIN="${HOME}/Cortex/Nexus/.venv/bin/python"
[[ -x "${PYTHON_BIN}" ]] || PYTHON_BIN="$(command -v python3 || true)"
[[ -n "${PYTHON_BIN}" ]] || exit 0

[[ -f "${PROCESSOR}" ]] || exit 0

elapsed=0
while [ "${elapsed}" -lt "${MAX_WAIT_S}" ]; do
  out="$("${PYTHON_BIN}" "${PROCESSOR}" "${INBOX}" "${ARCHIVE}")"
  rc=$?
  if [ "${rc}" -eq 2 ]; then
    printf '%s\n' "${out}"
    exit 2
  fi
  sleep "${POLL_INTERVAL_S}"
  elapsed=$(( elapsed + POLL_INTERVAL_S ))
done

exit 0
