"""Shared inbox-Processor fuer inject.sh + watch-rewake.sh.

Liest _memory/telegram-inbox.jsonl, filtert ungelesene Eintraege:

- Tag-Routing: Text-Praefix [tag] wird geparst. Nur Nachrichten ohne Tag
  oder mit Tag == local-hostname/alias werden vom aktuellen Mac konsumiert.
  Andere Tags bleiben fuer andere Sessions liegen.
- /end-Erkennung: Wenn eine konsumierte Nachricht "/end", "/quit",
  "session beenden", "session ende" enthaelt, wird ein expliziter Hint
  im Output ergaenzt — Claude soll mit session-end-Skill abschliessen.

CLI:
    python process_inbox.py <inbox-path> <archive-path>

Exit-Codes:
    0 — nichts (oder nur Fremd-Tags) zu konsumieren
    2 — etwas konsumiert, stdout enthaelt den Markdown-Block
"""

from __future__ import annotations

import fcntl
import json
import os
import re
import socket
import sys
from datetime import datetime, timezone
from pathlib import Path

TAG_RE = re.compile(r"^\s*\[([^\]]+)\]\s*", re.IGNORECASE)
END_PATTERNS = (
    "/end",
    "/quit",
    "/exit",
    "session beenden",
    "session ende",
    "ende session",
)

# Aliase muessen die in spawn_forward.HOST_ALIASES spiegeln, plus Convenience-
# Hostnames der lokalen Session.
LOCAL_ALIASES: dict[str, set[str]] = {
    "cluster-mini-02": {"home", "mini", "cluster", "cluster-mini-02"},
    "ssmd-macbookpro-m5": {"m5", "macbookpro-silicon", "ssmd-macbookpro-m5"},
    "ssmd-macbookpro": {"intel", "macbookpro-intel", "ssmd-macbookpro"},
    "mac-studio-von-macstudiozi2": {
        "studio",
        "macstudio",
        "praxis-studio",
        "mac-studio-von-macstudiozi2",
    },
}


def _local_aliases() -> set[str]:
    host = socket.gethostname().split(".")[0].lower()
    aliases = LOCAL_ALIASES.get(host, set()).copy()
    aliases.add(host)
    return aliases


def _parse_tag(text: str) -> tuple[str | None, str]:
    """Parst optionalen [tag]-Praefix. Returnt (tag-or-None, rest)."""
    m = TAG_RE.match(text)
    if not m:
        return None, text.strip()
    tag = m.group(1).strip().lower()
    rest = text[m.end():].strip()
    return tag, rest


def _is_end_command(text: str) -> bool:
    norm = text.strip().lower()
    return any(p == norm or norm.startswith(p + " ") for p in END_PATTERNS)


def _format_ts(ts: object) -> str:
    if isinstance(ts, (int, float)):
        v = ts / 1000 if ts > 1e12 else ts
        try:
            return datetime.fromtimestamp(v, tz=timezone.utc).isoformat()
        except (OSError, OverflowError, ValueError):
            return str(ts)
    return str(ts)


def main(argv: list[str]) -> int:
    if len(argv) < 3:
        print("usage: process_inbox.py <inbox> <archive>", file=sys.stderr)
        return 0
    inbox = Path(argv[1])
    archive = Path(argv[2])
    if not inbox.exists() or inbox.stat().st_size == 0:
        return 0

    # Race-Schutz: bei mehreren parallelen Sessions/Watchern auf demselben Mac
    # halten wir ein Lock auf eine Sidecar-Datei. Wer das Lock nicht bekommt,
    # skippt diesen Tick (nicht-blockierend).
    lock_path = inbox.with_suffix(inbox.suffix + ".lock")
    lock_fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT, 0o600)
    try:
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            os.close(lock_fd)
            return 0
        return _process_locked(inbox, archive)
    finally:
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
        except OSError:
            pass
        try:
            os.close(lock_fd)
        except OSError:
            pass


def _process_locked(inbox: Path, archive: Path) -> int:
    me = _local_aliases()

    all_entries: list[dict] = []
    for raw in inbox.read_text(encoding="utf-8").splitlines():
        raw = raw.strip()
        if not raw:
            continue
        try:
            entry = json.loads(raw)
        except json.JSONDecodeError:
            continue
        all_entries.append(entry)

    consumed_now: list[dict] = []
    end_requested = False

    for entry in all_entries:
        if entry.get("consumed"):
            continue
        text = entry.get("text") or ""
        tag, rest = _parse_tag(text)
        if tag is not None and tag not in me:
            # Nicht fuer diese Session — liegen lassen, andere Session konsumiert.
            continue
        # Konsumieren: ggf. mit aufgeloestem Tag-Prefix-stripped Text.
        entry_out = dict(entry)
        if tag is not None:
            entry_out["tag"] = tag
            entry_out["text"] = rest if rest else text
        consumed_now.append(entry_out)
        if _is_end_command(entry_out["text"]):
            end_requested = True

    if not consumed_now:
        return 0

    print("# 📱 Neue iPhone-/Telegram-Nachricht(en)")
    print(
        "Beantworte via curl an "
        "`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage` "
        "mit chat_id wie unten."
    )
    print()
    for e in consumed_now:
        ts_iso = _format_ts(e.get("ts"))
        chat = e.get("chat_id") or "?"
        tag = e.get("tag")
        header = f"## [{ts_iso}] chat={chat}"
        if tag:
            header += f" tag=[{tag}]"
        print(header)
        print((e.get("text") or "").strip())
        print()

    if end_requested:
        print("---")
        print(
            "🛑 **Session-Ende-Anforderung erkannt.** Schliess die Welle ab: "
            "(1) `cortex-agent skill run session-end --args '{\"project\":\"phoenix\",\"summary\":\"...\"}'`, "
            "(2) finalen Push an den User per Telegram-curl mit kurzer Wave-Bilanz, "
            "(3) Welle-Ende-Debrief im Chat hier. "
            "Die CLI selbst bleibt offen — User kann jederzeit die naechste Welle vom iPhone triggern."
        )
        print()

    # Archive + Inbox-Update: bei den konsumierten Eintraegen consumed=true setzen,
    # andere unveraendert lassen (Fremd-Tag bleibt liegen).
    consumed_ids = {id(e) for e in consumed_now}
    out_lines: list[str] = []
    archive.parent.mkdir(parents=True, exist_ok=True)
    with archive.open("a", encoding="utf-8") as af:
        for entry in all_entries:
            if entry.get("consumed"):
                out_lines.append(json.dumps(entry, ensure_ascii=False))
                continue
            text = entry.get("text") or ""
            tag, rest = _parse_tag(text)
            if tag is not None and tag not in me:
                # Fremd-Tag: liegen lassen.
                out_lines.append(json.dumps(entry, ensure_ascii=False))
                continue
            # Konsumieren — markieren + ins Archiv schreiben.
            new_entry = dict(entry)
            new_entry["consumed"] = True
            new_entry["consumed_at"] = datetime.now(tz=timezone.utc).isoformat()
            if tag is not None:
                new_entry["tag"] = tag
                new_entry["text"] = rest if rest else text
            af.write(json.dumps(new_entry, ensure_ascii=False) + "\n")

    # Inbox neu schreiben — nur Fremd-Tags + alte consumed bleiben.
    inbox.write_text(
        "\n".join(out_lines) + ("\n" if out_lines else ""),
        encoding="utf-8",
    )

    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
