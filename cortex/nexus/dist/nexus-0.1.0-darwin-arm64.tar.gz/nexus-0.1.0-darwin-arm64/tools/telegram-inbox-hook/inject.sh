#!/usr/bin/env bash
# UserPromptSubmit-Hook — injiziert ungelesene Telegram-Inbox-Eintraege
# als additionalContext, markiert sie danach als consumed.
#
# Logik in tools/telegram-inbox-hook/process_inbox.py (shared mit watch-rewake.sh).

set -euo pipefail

INBOX="${HOME}/Cortex/Nexus/_memory/telegram-inbox.jsonl"
ARCHIVE="${HOME}/Cortex/Nexus/_memory/telegram-inbox.consumed.jsonl"
PROCESSOR="${HOME}/Cortex/Nexus/tools/telegram-inbox-hook/process_inbox.py"

PYTHON_BIN="${HOME}/Cortex/Nexus/.venv/bin/python"
[[ -x "${PYTHON_BIN}" ]] || PYTHON_BIN="$(command -v python3 || true)"
[[ -n "${PYTHON_BIN}" ]] || exit 0

if [[ ! -s "${INBOX}" ]] || [[ ! -f "${PROCESSOR}" ]]; then
  exit 0
fi

# process_inbox liefert exit 2 wenn was konsumiert wurde, sonst 0.
# Output von stdout wird von Claude Code als additionalContext gewertet.
"${PYTHON_BIN}" "${PROCESSOR}" "${INBOX}" "${ARCHIVE}"
rc=$?
# UserPromptSubmit-Hook: exit 0 reicht, der Output wird trotzdem injiziert.
# Wir maskieren exit 2 → 0, damit der Hook nicht als blocking error gilt.
if [[ "${rc}" -eq 2 ]] || [[ "${rc}" -eq 0 ]]; then
  exit 0
fi
exit "${rc}"
