#!/usr/bin/env bash
# SessionStart-Hook — Pending-Digest sammeln und ans iPhone pushen.
#
# Wird vom Claude-Code-Hook `SessionStart` aufgerufen. Failure-tolerant:
# Hook darf die Session unter keinen Umstaenden blockieren oder verzoegern.
# Daher: Hard-Timeout, alle Errors -> exit 0.
#
# Output auf stdout wird beim SessionStart NICHT als additionalContext
# injiziert (anders als UserPromptSubmit) — wir loggen Diagnostik in eine
# Datei und liefern keinen Stdout-Output.

set -u

NEXUS="${HOME}/Cortex/Nexus"
LOG="${NEXUS}/_memory/logs/session-start-digest.log"
PYTHON_BIN="${NEXUS}/.venv/bin/python"

mkdir -p "$(dirname "${LOG}")"

# Soft-fail wenn venv nicht da
if [[ ! -x "${PYTHON_BIN}" ]]; then
  echo "[$(date -Iseconds)] skip: venv missing" >> "${LOG}"
  exit 0
fi

# Hard-Timeout 5 Sekunden — Hook darf nicht blockieren.
# macOS hat kein `timeout`, wir nutzen perl.
RESULT="$(
  cd "${NEXUS}" && perl -e '
    use POSIX ":sys_wait_h";
    my $pid = fork();
    if ($pid == 0) { exec(@ARGV); exit 127; }
    my $deadline = time() + 5;
    while (time() < $deadline) {
      my $r = waitpid($pid, WNOHANG);
      last if $r != 0;
      select(undef, undef, undef, 0.1);
    }
    if (waitpid($pid, WNOHANG) == 0) {
      kill "TERM", $pid;
      sleep 1;
      kill "KILL", $pid;
      print STDERR "TIMEOUT\n";
      exit 124;
    }
  ' -- "${PYTHON_BIN}" -m agent.connexio.session_digest 2>&1
)"
RC=$?

echo "[$(date -Iseconds)] rc=${RC}" >> "${LOG}"
if [[ -n "${RESULT}" ]]; then
  echo "${RESULT}" >> "${LOG}"
fi

exit 0
