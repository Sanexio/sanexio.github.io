#!/usr/bin/env bash
# mini04-prepare-autorestart.sh
#
# Setzt auf Cluster-Mini-04:
#   sudo pmset -a autorestart 1   (auto-boot nach Power-Loss)
#   sudo pmset -a womp 1          (Wake-on-Network, falls noch nicht aktiv)
#
# Hintergrund: M-Series Macs wachen via WoL NICHT aus Cold-Shutdown auf
# (siehe feedback_wol_m_series_shutdown.md). Mit autorestart=1 fährt der
# Mac nach einem echten Power-Cycle (z.B. via Smart-Plug) automatisch
# wieder hoch. womp=1 erlaubt zusätzlich Wake aus Sleep via Magic-Packet.
#
# Voraussetzung: Mini-04 ist online und SSH per Pubkey erreichbar
# (clusteradm@100.80.43.49 oder 192.168.178.32).
#
# Mac-Login-PW (clusteradm) muss als ENV-Var REMOTE_PW gesetzt sein,
# damit sudo nicht-interaktiv klappt. Niemals das PW in dieses Skript
# committen.
#
# Verwendung:
#   export REMOTE_PW='…'
#   bash ~/Cortex/Nexus/tools/mini04-prepare-autorestart.sh
#
# Verifikation nach Lauf: `pmset -g` → autorestart 1, womp 1

set -euo pipefail

HOST_OPTIONS=("100.80.43.49" "192.168.178.32" "cluster-mini-04.piranha-marlin.ts.net")
SSH_USER="clusteradm"
SSH_KEY="${HOME}/.ssh/id_ed25519"

if [[ -z "${REMOTE_PW:-}" ]]; then
  echo "FEHLER: REMOTE_PW (clusteradm-Login-PW) nicht gesetzt." >&2
  exit 1
fi

# Reachable host finden
HOST=""
for h in "${HOST_OPTIONS[@]}"; do
  if ssh -o BatchMode=yes -o ConnectTimeout=4 -i "$SSH_KEY" "${SSH_USER}@${h}" 'echo ok' >/dev/null 2>&1; then
    HOST="$h"
    echo "→ Mini-04 erreichbar über $HOST"
    break
  fi
done

if [[ -z "$HOST" ]]; then
  echo "FEHLER: Mini-04 ist nicht erreichbar (LAN+Tailnet+DNS alle tot)." >&2
  exit 2
fi

# expect für sudo-PW-Prompt
expect <<EOF
set timeout 20
log_user 1
spawn ssh -o BatchMode=yes -i ${SSH_KEY} -tt ${SSH_USER}@${HOST} "sudo -S -p 'SUDO:' /usr/bin/pmset -a autorestart 1 && sudo /usr/bin/pmset -a womp 1 && echo 'PMSET_APPLIED' && sudo /usr/bin/pmset -g | grep -E 'autorestart|womp'"
expect {
  "SUDO:" { send "\$env(REMOTE_PW)\r"; exp_continue }
  eof
}
EOF

echo "→ Verifikation abgeschlossen. Bei Smart-Plug-Power-Cycle bootet Mini-04 jetzt automatisch."
