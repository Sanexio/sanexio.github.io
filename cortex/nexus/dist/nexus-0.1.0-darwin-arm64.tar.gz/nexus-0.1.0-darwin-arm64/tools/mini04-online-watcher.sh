#!/usr/bin/env bash
# mini04-online-watcher.sh
#
# Pollt alle paar Minuten Mini-04. Sobald erreichbar (Tailscale ODER LAN),
# schickt einmalig eine Telegram-Nachricht an Dr. Stracke mit dem
# vorbereiteten One-Liner für mini04-prepare-autorestart.sh.
#
# Marker-File in ~/.cache/cortex/ verhindert Spam: erste Online-Detection
# setzt den Marker, weitere Runs überspringen. Wer den Watcher zurücksetzen
# will: rm ~/.cache/cortex/mini04-autorestart-prepared-marker.
#
# Verwendet wird der Bot-Token aus Nexus/gateway/.env (TELEGRAM_BOT_TOKEN).
# Chat-ID des Dr.-Stracke-Channels: 8547497426.

set -euo pipefail

MARKER="${HOME}/.cache/cortex/mini04-autorestart-prepared-marker"
LOG="${HOME}/.cache/cortex/mini04-watcher.log"
ENV_FILE="${HOME}/Cortex/Nexus/gateway/.env"
CHAT_ID="8547497426"

mkdir -p "$(dirname "$MARKER")"
exec >>"$LOG" 2>&1
echo "[$(date -Iseconds)] tick"

if [ -f "$MARKER" ]; then
  echo "  already notified ($(cat "$MARKER")), exiting."
  exit 0
fi

# Erreichbarkeit prüfen (LAN-IP zuerst, dann Tailnet-IP).
ONLINE=0
for target in 192.168.178.32 100.80.43.49; do
  if ping -c 1 -t 2 "$target" >/dev/null 2>&1; then
    ONLINE=1
    HOST="$target"
    break
  fi
done

if [ "$ONLINE" = "0" ]; then
  echo "  offline, sleeping."
  exit 0
fi

echo "  ONLINE via $HOST — sending Telegram notice."

# Token aus .env extrahieren, ohne ihn ins Log zu spülen.
if [ ! -r "$ENV_FILE" ]; then
  echo "  FEHLER: $ENV_FILE nicht lesbar."
  exit 1
fi
TOKEN=$(grep -E '^TELEGRAM_BOT_TOKEN=' "$ENV_FILE" | head -1 | cut -d= -f2- | tr -d '"'"'")
if [ -z "$TOKEN" ]; then
  echo "  FEHLER: TELEGRAM_BOT_TOKEN leer."
  exit 1
fi

MSG=$(cat <<EOM
🟢 <b>Mini-04 ist online</b> (via $HOST)

Autorestart-Setup vorbereiten:

<code>REMOTE_PW='…clusteradm-Login-PW…' bash ~/Cortex/Nexus/tools/mini04-prepare-autorestart.sh</code>

Nach erfolgreichem Lauf zeigt das Tool <code>autorestart 1</code> + <code>womp 1</code>. Danach ist Smart-Plug-Power-Cycle gleich Remote-Wake aus Cold-Off.

(Diese Nachricht kommt nur einmal — Marker in <code>~/.cache/cortex/mini04-autorestart-prepared-marker</code>.)
EOM
)

HTTP=$(curl -s -o /tmp/mini04-tg-resp.json -w "%{http_code}" \
  -d "chat_id=$CHAT_ID" \
  --data-urlencode "text=$MSG" \
  -d "parse_mode=HTML" \
  "https://api.telegram.org/bot${TOKEN}/sendMessage")

if [ "$HTTP" = "200" ]; then
  date -Iseconds > "$MARKER"
  echo "  Telegram OK, marker geschrieben."
else
  echo "  Telegram-Send fehlgeschlagen (HTTP $HTTP)."
  cat /tmp/mini04-tg-resp.json
fi
rm -f /tmp/mini04-tg-resp.json
