#!/usr/bin/env bash
# Single Source der distribution-sensitiven Pfade.
# Wird von allen Distribution-Guards gelesen:
#   - tools/cortex-mode/git-hooks/pre-commit-distribution.sh
#   - tools/cortex-mode/git-hooks/commit-msg-distribution.sh
#   - tools/cortex-mode/git-hooks/pre-push-distribution.sh
#   - tools/cortex-mode/bin/wave_end_push.py (über Python-Wrapper)
#   - agent/skills/builtin/doctor.py (über Python-Wrapper)
#   - agent/skills/builtin/bootstrap_health_dashboard.py
#
# Wenn hier ein Pfad hinzukommt, greifen alle Guards automatisch.
#
# Format: bash-Array DISTRIBUTION_PATHS (relativ zum Nexus-Root).
# Globs werden NICHT expandiert — git versteht die Pfade direkt
# als "Pfad-Präfix oder einzelne Datei".

DISTRIBUTION_PATHS=(
    "nexus-sync.sh"
    "tools/cortex-mode/bin/install_bootstrap.sh"
    "tools/cortex-mode/bin/install_w1_hooks.sh"
    "tools/cortex-mode/bin/install_slash_commands.sh"
    "tools/cortex-mode/bin/auto_allow.py"
    "tools/cortex-mode/bin/wave_end_push.py"
    "tools/cortex-mode/bin/inject.sh"
    "tools/cortex-mode/bin/test-bootstrap.sh"
    "tools/cortex-mode/commands-template"
    "tools/cortex-mode/git-hooks"
    "com.cortex.nexus-sync.plist"
    "com.cortex.nexus-sync-healthcheck.plist"
    "com.cortex.connexio-inbox-notify.plist"
    "com.cortex.bootstrap-health-dashboard.plist"
    "gateway/launchagents/install.sh"
    "agent/modes/autonomy.md"
    "agent/modes/safe.md"
    "agent/modes/tier3.md"
)

# Export für Sub-Skripte
export DISTRIBUTION_PATHS
