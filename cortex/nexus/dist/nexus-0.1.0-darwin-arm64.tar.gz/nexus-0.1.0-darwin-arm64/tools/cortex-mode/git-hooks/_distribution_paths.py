"""Single Source der distribution-sensitiven Pfade — Python-Variante.

Gespiegelt aus _distribution_paths.sh. Wird von Python-Tools gelesen:
  - tools/cortex-mode/bin/wave_end_push.py
  - agent/skills/builtin/doctor.py
  - agent/skills/builtin/bootstrap_health_dashboard.py

Wenn ein Pfad hinzukommt, MUSS er hier UND in _distribution_paths.sh
ergänzt werden — die beiden müssen konsistent bleiben.
"""

from __future__ import annotations

DISTRIBUTION_PATHS: tuple[str, ...] = (
    "nexus-sync.sh",
    "tools/cortex-mode/bin/install_bootstrap.sh",
    "tools/cortex-mode/bin/install_w1_hooks.sh",
    "tools/cortex-mode/bin/install_slash_commands.sh",
    "tools/cortex-mode/bin/auto_allow.py",
    "tools/cortex-mode/bin/wave_end_push.py",
    "tools/cortex-mode/bin/inject.sh",
    "tools/cortex-mode/bin/test-bootstrap.sh",
    "tools/cortex-mode/commands-template",
    "tools/cortex-mode/git-hooks",
    "com.cortex.nexus-sync.plist",
    "com.cortex.nexus-sync-healthcheck.plist",
    "com.cortex.connexio-inbox-notify.plist",
    "com.cortex.bootstrap-health-dashboard.plist",
    "gateway/launchagents/install.sh",
    "agent/modes/autonomy.md",
    "agent/modes/safe.md",
    "agent/modes/tier3.md",
)


def matches(file_path: str) -> bool:
    """True wenn file_path (repo-relativ) eine distribution-sensitive Datei ist
    oder unter einem distribution-sensitiven Verzeichnis-Präfix liegt."""
    fp = file_path.lstrip("./")
    for p in DISTRIBUTION_PATHS:
        if fp == p or fp.startswith(p + "/"):
            return True
    return False
