#!/usr/bin/env bash
# Pre-Commit-Soft-Reminder: wenn distribution-sensitive Files staged sind,
# warne im Terminal. Erzwingen passiert im commit-msg-Hook (s.u.).
#
# Bricht den Commit NICHT ab — Warnung only.

set -uo pipefail

HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HOOK_DIR/_distribution_paths.sh"

STAGED=$(git diff --cached --name-only)
[[ -z "$STAGED" ]] && exit 0

HIT=""
while IFS= read -r f; do
    [[ -z "$f" ]] && continue
    for p in "${DISTRIBUTION_PATHS[@]}"; do
        if [[ "$f" == "$p" || "$f" == "$p"/* ]]; then
            HIT+="  $f (matched: $p)"$'\n'
            break
        fi
    done
done <<< "$STAGED"

if [[ -n "$HIT" ]]; then
    echo "──────────────────────────────────────────────────────────────"
    echo "⚠  DISTRIBUTION-SENSITIVE FILES staged:"
    echo "$HIT"
    echo "→ Commit-Message MUSS einen Distribution-Block enthalten."
    echo "→ Template:"
    echo "    Distribution: auto                    (via nexus-sync.sh Post-Pull-Hook)"
    echo "    Distribution: manual: <Begründung>    (z.B. neue plist die manuelles Token-Setup braucht)"
    echo "    Distribution: n/a                     (Datei wirkt nur lokal, nicht auf andere Macs)"
    echo "──────────────────────────────────────────────────────────────"
fi

exit 0
