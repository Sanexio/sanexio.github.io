#!/usr/bin/env bash
# Commit-Msg-Hardlock: wenn distribution-sensitive Files staged sind,
# MUSS die Commit-Message einen 'Distribution:'-Block enthalten.
# Sonst: commit abgelehnt.
#
# Arg $1: Pfad zur temporären Commit-Message-Datei.

set -uo pipefail

HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HOOK_DIR/_distribution_paths.sh"

MSG_FILE="$1"

# 1. Prüfen ob distribution-Files staged
STAGED=$(git diff --cached --name-only)
TOUCHED_DISTRIBUTION=false
while IFS= read -r f; do
    [[ -z "$f" ]] && continue
    for p in "${DISTRIBUTION_PATHS[@]}"; do
        if [[ "$f" == "$p" || "$f" == "$p"/* ]]; then
            TOUCHED_DISTRIBUTION=true
            break 2
        fi
    done
done <<< "$STAGED"

if [[ "$TOUCHED_DISTRIBUTION" != "true" ]]; then
    exit 0
fi

# 2. Prüfen ob Commit-Message einen Distribution-Block hat
if grep -qE "^Distribution:[[:space:]]+(auto|manual:|n/a)" "$MSG_FILE"; then
    exit 0
fi

# 3. Reject mit klarer Anleitung
cat >&2 <<EOF
──────────────────────────────────────────────────────────────
✗ COMMIT REJECTED — Distribution-Block fehlt

Distribution-sensitive Files sind staged. Die Commit-Message MUSS
eine Zeile enthalten:

    Distribution: auto
        → Verteilung läuft automatisch via nexus-sync.sh
          Post-Pull-Bootstrap-Hook.

    Distribution: manual: <Begründung>
        → Andere Macs brauchen manuellen Eingriff (z.B. Token-Setup).
          Begründung ist Pflicht.

    Distribution: n/a
        → Datei wirkt nur lokal (keine Multi-Mac-Wirkung).
          Selten zutreffend bei distribution-sensitiven Pfaden.

Geänderte distribution-sensitive Files:
EOF
while IFS= read -r f; do
    [[ -z "$f" ]] && continue
    for p in "${DISTRIBUTION_PATHS[@]}"; do
        if [[ "$f" == "$p" || "$f" == "$p"/* ]]; then
            echo "    - $f" >&2
            break
        fi
    done
done <<< "$STAGED"
cat >&2 <<EOF

Fix: Commit-Message editieren (z.B. via 'git commit --amend' wenn
Soft-Cancel, oder gleich beim 'git commit -m' mit -m fortsetzen).
──────────────────────────────────────────────────────────────
EOF

exit 1
