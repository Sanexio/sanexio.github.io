#!/usr/bin/env bash
# Pre-Push-Hardlock: wenn die ausgehenden Commits distribution-sensitive
# Files berühren, MUSS ein gültiger Test-Marker existieren (= Content-Hash
# der aktuellen Working-Tree-Distribution-Files matched den gespeicherten
# Hash in _memory/.last-bootstrap-test.json).
#
# Sonst: Push abgelehnt mit klarer Anleitung zum Fix.

set -uo pipefail

HOOK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HOOK_DIR/_distribution_paths.sh"

REPO_ROOT=$(git rev-parse --show-toplevel)
MARKER="$REPO_ROOT/_memory/.last-bootstrap-test.json"

# stdin: <local_ref> <local_sha> <remote_ref> <remote_sha>
HAS_DISTRIBUTION_CHANGE=false
while read -r local_ref local_sha remote_ref remote_sha; do
    [[ -z "$local_sha" || "$local_sha" == "0000000000000000000000000000000000000000" ]] && continue

    if [[ "$remote_sha" == "0000000000000000000000000000000000000000" ]]; then
        # neuer Remote-Branch — alle Commits prüfen
        range="$local_sha"
        CHANGED=$(git diff-tree --no-commit-id --name-only -r "$local_sha")
    else
        range="$remote_sha..$local_sha"
        CHANGED=$(git diff --name-only "$range")
    fi

    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        for p in "${DISTRIBUTION_PATHS[@]}"; do
            if [[ "$f" == "$p" || "$f" == "$p"/* ]]; then
                HAS_DISTRIBUTION_CHANGE=true
                break 2
            fi
        done
    done <<< "$CHANGED"
done

if [[ "$HAS_DISTRIBUTION_CHANGE" != "true" ]]; then
    exit 0
fi

# Distribution-Change erkannt → Test-Marker validieren.
if [[ ! -f "$MARKER" ]]; then
    cat >&2 <<EOF
──────────────────────────────────────────────────────────────
✗ PUSH REJECTED — kein Test-Marker

Du pushst distribution-sensitive Files, hast install_bootstrap.sh
aber nicht im Dry-Run getestet.

Fix:
    bash $REPO_ROOT/tools/cortex-mode/bin/test-bootstrap.sh
    git push

──────────────────────────────────────────────────────────────
EOF
    exit 1
fi

# Marker existiert — prüfen ob er den aktuellen Stand widerspiegelt.
STORED_HASH=$(python3 -c "
import json,sys
print(json.load(open(sys.argv[1])).get('content_hash',''))
" "$MARKER" 2>/dev/null)

CURRENT_HASH=$(
    cd "$REPO_ROOT" || exit 1
    for p in "${DISTRIBUTION_PATHS[@]}"; do
        if [[ -f "$p" ]]; then
            sha256sum "$p" 2>/dev/null || shasum -a 256 "$p" 2>/dev/null
        elif [[ -d "$p" ]]; then
            find "$p" -type f -print0 | sort -z | xargs -0 sha256sum 2>/dev/null || \
                find "$p" -type f -print0 | sort -z | xargs -0 shasum -a 256 2>/dev/null
        fi
    done | (sha256sum 2>/dev/null || shasum -a 256) | awk '{print $1}'
)

if [[ "$STORED_HASH" == "$CURRENT_HASH" && -n "$CURRENT_HASH" ]]; then
    echo "[pre-push] Distribution-Test-Marker matched (${CURRENT_HASH:0:16}…) — push erlaubt." >&2
    exit 0
fi

cat >&2 <<EOF
──────────────────────────────────────────────────────────────
✗ PUSH REJECTED — Test-Marker veraltet

Distribution-Files wurden seit dem letzten test-bootstrap geändert.

  gespeichert:  ${STORED_HASH:0:32}…
  aktuell:      ${CURRENT_HASH:0:32}…

Fix:
    bash $REPO_ROOT/tools/cortex-mode/bin/test-bootstrap.sh
    git push

──────────────────────────────────────────────────────────────
EOF
exit 1
