---
description: Cortex-Mode auf safe setzen (4-Phasen-Workflow mit Phase-2-Approval-Gate)
allowed-tools: Bash
---

!`set -e; SCRIPT="$HOME/Cortex/Nexus/tools/cortex-mode/bin/set_mode.sh"; if [ -x "$SCRIPT" ]; then bash "$SCRIPT" safe; else mkdir -p "$HOME/.claude/state" && NOW=$(date -u +%Y-%m-%dT%H:%M:%SZ) && HOST=$(hostname -s) && printf '{\n  "mode": "safe",\n  "since": "%s",\n  "host": "%s",\n  "set_by": "slash-command-inline"\n}\n' "$NOW" "$HOST" > "$HOME/.claude/state/cortex-mode.json" && echo "Cortex-Mode auf **safe** gesetzt (Host: $HOST, Zeit: $NOW)." && echo && echo "Inline-Fallback aktiv — set_mode.sh fehlt unter $SCRIPT. Empfehlung: cd ~/Cortex/Nexus && git pull --ff-only && bash tools/cortex-mode/bin/install_slash_commands.sh"; fi`
