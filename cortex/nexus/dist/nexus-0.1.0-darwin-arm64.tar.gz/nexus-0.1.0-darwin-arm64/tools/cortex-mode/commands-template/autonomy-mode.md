---
description: Cortex-Mode auf autonomy setzen (durchziehen, kein Pre-Op-Block)
allowed-tools: Bash
---

!`set -e; SCRIPT="$HOME/Cortex/Nexus/tools/cortex-mode/bin/set_mode.sh"; if [ -x "$SCRIPT" ]; then bash "$SCRIPT" autonomy; else mkdir -p "$HOME/.claude/state" && NOW=$(date -u +%Y-%m-%dT%H:%M:%SZ) && HOST=$(hostname -s) && printf '{\n  "mode": "autonomy",\n  "since": "%s",\n  "host": "%s",\n  "set_by": "slash-command-inline"\n}\n' "$NOW" "$HOST" > "$HOME/.claude/state/cortex-mode.json" && echo "Cortex-Mode auf **autonomy** gesetzt (Host: $HOST, Zeit: $NOW)." && echo && echo "Inline-Fallback aktiv — set_mode.sh fehlt unter $SCRIPT. Empfehlung: cd ~/Cortex/Nexus && git pull --ff-only && bash tools/cortex-mode/bin/install_slash_commands.sh"; fi`
