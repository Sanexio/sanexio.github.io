---
description: Aktuellen Cortex-Mode anzeigen (autonomy oder safe)
allowed-tools: Bash
---

!`SCRIPT="$HOME/Cortex/Nexus/tools/cortex-mode/bin/set_mode.sh"; STATE="$HOME/.claude/state/cortex-mode.json"; if [ -x "$SCRIPT" ]; then bash "$SCRIPT" show; elif [ -f "$STATE" ]; then cat "$STATE"; else echo "State-File fehlt: $STATE"; echo "Wird beim nächsten Hook-Aufruf mit autonomy auto-init."; fi`
