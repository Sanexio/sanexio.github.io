# Nexus — Cortex Phoenix

> **Persönliche Arbeitsumgebung von Dr. Stracke** unter `~/Cortex/`.
> Wissens-Anker: `Second Brain/30 Tutorials/`. Geräte-lokale Projekte unter
> `~/Cortex/projects/`.
>
> **Mode-Verhalten** wird vom UserPromptSubmit-Hook
> `tools/cortex-mode/bin/inject.sh` als `additionalContext` injiziert
> (mode-File + tier3.md, ~960 Tokens).
> Default: **Autonomy** (`/safe-mode` schaltet auf 4-Phasen-Workflow).

---

## VORRANGIGE USER-REGEL — Tutorial-Explain-Mode (2026-05-26)

**Geräteübergreifend, mode-unabhängig, gilt sofort beim Session-Start.**
Jeder Bash-Befehl, jede Datei-Operation, jeder Tool-Aufruf bekommt eine
kurze Begründung („was tue ich, warum, welche Wirkung"). Erklärung
**vor oder unmittelbar nach** der Aktion, nicht erst am Welle-Ende.

**Tiefen-Vorgabe für Bash:** Befehle werden **auseinandergenommen** —
jedes Flag, jeder Operator (`|`, `&&`, `||`, `2>&1`, `$(...)`, Heredoc,
Quoting), jede Plattform-Falle (BSD vs. GNU) einzeln benannt. Bei
Ketten die Sicherheits-Eigenschaft (z.B. „`&&` schützt vor Push auf
failed commit") explizit nennen.

- Token spielen keine Rolle. Diese Regel **überschreibt** den
  „short and concise"-Default und den Autonomy-Anti-Drift-Block
  „Verbotene Strukturen → Mehrzeilige Pre-Op-Erklärungsblöcke".
- Stracke sagt explizit an, welche Erklärungen ins Tutorial-System
  (`_tutorials/`) wandern — **keine Automatik**.
- Autoritative Quelle: `_rules/user-directives.md` Abschnitt
  „Tutorial-Explain-Mode (2026-05-26, präzisiert 2026-05-26)".

---

## Init-Workflow (jede Session)

Pflicht-Lesung:

- `CLAUDE.md` — dieser Einstieg.
- `_rules/AUTONOMY_CONTRACT.md` — R0-R3, State-First, Lease, AI-Cooperation.
- `_rules/glossary.md` — knappe Definitionen aller Fachbegriffe (R0–R3,
  Hook, Lease, FTS5, MCP, Connexio, Tier-3, Welle, Phoenix, Skill, …).
- `_rules/user-directives.md` — vorrangige User-Regeln, u.a.
  **Tutorial-Explain-Mode** (jeden Schritt erklären, geräteübergreifend).

1. **Pre-Pull** (Lean v3 S1 State-First):
   ```bash
   cd ~/Cortex/Nexus && git pull --ff-only
   ```
   Bei Divergenz: STOPP, melden, kein Edit.

2. **Mode-State sicherstellen** (Auto-Init via Hook bei fehlendem File):
   ```bash
   cat ~/.claude/state/cortex-mode.json    # → mode=autonomy|safe
   ```

3. **Bei Bedarf on-demand nachladen**:
   - `_memory/USER.md` — Dr.-Stracke-Profil
   - `_memory/KNOWLEDGE.md` — Pointer-Index zum Vault
   - `_projects/INDEX.md` — Projekt-Tabelle
   - Vault `Second Brain/30 Tutorials/` — Tutorials nach Domäne

4. **Aktive Aufgabe** beginnen.

---

## Multi-Device + Multi-AI

Cortex existiert auf mehreren Macs gleichzeitig. **Sync ausschließlich
über GitHub** (`Sanexio/nexus`, `Sanexio/cortex-web`, …). Vor jedem Edit
`git pull --ff-only` in Nexus + im Projekt; nach jeder Welle `commit + push`.

**Boundary:** `~/Cortex/Nexus/` ist Claude-exklusiv. Andere KIs (Codex,
Cursor, Cline, Continue, Gemini-CLI) lesen Nexus nur über die
Connexio-MCP/HTTP-Surface (read-only, hardcoded). Schreiben dürfen sie
nur in `~/Cortex/projects/<projekt>/`. Workspace-Trust: andere KIs
werden mit dem Projekt-Wurzelpfad geöffnet, nie mit `~/Cortex/`.

Volle Architektur: `specs/multi-device-multi-ai/00_KONZEPT.md`.
Autoritative Kurzregel: `_rules/AUTONOMY_CONTRACT.md` Kapitel 12.

---

## Stack

| Komponente              | Pfad                                              | Sprache         |
|-------------------------|---------------------------------------------------|-----------------|
| **Agent (Hermes-style)**| `agent/`                                          | Python 3.14     |
| **Gateway (OpenClaw-style)** | `gateway/`                                   | TypeScript/Bun  |
| **Mode-Hook**           | `tools/cortex-mode/bin/inject.sh`                 | Bash            |
| **Memory-DB**           | `_memory/memory.db` (gitignored)                  | SQLite FTS5     |
| **Vault**               | `Second Brain/30 Tutorials/`                      | Obsidian        |

### Kommandos

```bash
cortex-agent bootstrap                # Mode + User + Skills + System-Block-Größe
cortex-agent run "<prompt>"           # Eine Loop-Iteration (braucht ANTHROPIC_API_KEY)
cortex-agent mode get | set autonomy|safe
cortex-agent skill list | run <name> [--args '{}']
cortex-agent memory search "<query>" | facts | add-fact <kind> <key> <value>

cd gateway && bun run telegram        # Telegram-V3 standalone
```

---

## Standard-Befehle

- **„Phoenix fortsetzen"** → liest `PHOENIX_RESUME.md` und setzt mit dem
  dort als „aktiv" markierten Connexio-Sprint-Punkt fort. Das ist der
  Default-Befehl für die nächsten Sessions.
- **„Projekt fortsetzen"** → lädt `<projekt>/SESSION_RESUME.md` und nimmt Arbeit auf.
- **„Session beenden"** → 6-Schritte-Abschluss inkl. Status-Dashboard.

---

## Mode-Switch

- `/safe-mode` → Architekten-Phasen mit Phase-2-Approval-Gate.
- `/autonomy-mode` → Default (durchziehen, Welle-Ende-Debrief).
- `/cortex-mode` → aktuellen Modus anzeigen.

State-File: `~/.claude/state/cortex-mode.json`. Auto-Init auf `autonomy`.

---

## Geräte-Zuordnung

**Single Source of Truth:** `Nexus/.config/devices.json` (Feld `projects:` je
Gerät). Diese Datei darf NICHT hartcodiert als Geräte/Projekt-Tabelle in
Markdown nachgepflegt werden — die Tabelle driftet schneller als devices.json.

**Pflicht-Verifikation vor Pfad-Annahmen** (Local-First-Discovery,
`specs/local-first-discovery/00_KONZEPT.md` §2):

1. `pwd` und `~/Cortex/projects/` — passt der Pfad schon?
2. Local-by-Flywheel: `~/Library/Application Support/Local/sites.json` —
   liegt das Repo als Theme-Ordner einer lokalen WP-Site?
3. Andere lokale WP-Setups (MAMP, Docker, wp-env).
4. `devices.json` (welcher Mac hat das Repo, wo).
5. GitHub-Klon als Fallback.
6. Tailscale-SSH zu anderem Mac — **letzte** Option, nicht erste.

Tailscale-Offline ist KEIN Grund, ein Repo zu klonen — sondern ein Grund,
Stufe 1-3 erneut zu prüfen.

| Hostname               | Rolle               | Quick-Reference                                  |
|------------------------|---------------------|--------------------------------------------------|
| Cluster-Mini-02        | home (M2)           | siehe `devices.json`. Hat Local-Flywheel.        |
| SSMD-MacBookPro        | praxis (Intel)      | siehe `devices.json`. Praxis-Backoffice.         |
| SSMD-MacBookPro-M5     | praxis-mobile       | siehe `devices.json`.                            |
| Mac-Studio             | praxis-studio       | siehe `devices.json`.                            |

**Wichtige Korrektur 2026-05-13:** `praxis-webseite` (= Theme
`Sanexio/praxiszentrum-theme`) lebt **NICHT** auf dem Intel-Mac, sondern
als Git-Working-Copy im Theme-Ordner einer Local-Flywheel-Site auf
`Cluster-Mini-02`:

```
~/Local Sites/gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604/
  app/public/wp-content/themes/praxiszentrum/   ← Git-Checkout
```

Test-URL lokal: `https://gpmedicalcenterwestend-7ded2f4ae8c4343d2029-202604.local`.
Älteres Memory mit gegenteiliger Aussage ist falsch und archiviert.

---

## Phoenix-Reset Status

Vollständiger Hard-Reset 2026-05-08/09 — alte Steuerungs-Files (`_rules/`,
altes `_memory/`, `tools/cortex-*`) entfernt. Backup auf GitHub im
`pre-phoenix-reset-2026-05-08`-Branch.

Übergabe-Datei für Folge-Sessions: `HANDOVER_PHOENIX.md` (Welle 7,
Snapshot-Doku).

Destillierte Goldene Regeln (LL→R-Mapping + Tier-3-Hardstops +
Wiederholungsfehler-Patterns GF-001..GF-007): `_memory/golden-rules.md`.
