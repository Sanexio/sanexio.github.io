# Glossar — Cortex/Nexus

> Knappe Definitionen der zentralen Fachbegriffe, die in CLAUDE.md,
> AUTONOMY_CONTRACT.md und im täglichen Betrieb vorkommen. Pflicht-Lesung
> Nr. 3 (nach CLAUDE.md und AUTONOMY_CONTRACT.md). Eine Zeile genügt — Detail
> steht in den jeweils verlinkten Files. Sortierung: alphabetisch.

## A

- **`.env`** — Konfigurationsdatei für umgebungsspezifische Variablen (API-Keys, Tokens, Pfade). Wird per `.gitignore` von Git ausgenommen, damit Secrets nicht commitet werden. Schreiben auf `.env`-Files ist Tier-3 (Secrets-Hardstop).
- **`@sanexio_bot`** — Telegram-Bot, über den du mit dem Cortex-System chatten kannst (Status abfragen, `/spawn`-Befehle).
- **AI-Cooperation** — Regelwerk in `AUTONOMY_CONTRACT.md` §11 für die Zusammenarbeit zwischen Claude und Codex (Peer-Modell, gegenseitige Reviews, Task-Übergabe).
- **`additionalContext`** — JSON-Feld, das ein UserPromptSubmit-Hook zurückgibt; sein Inhalt wird vor jedem Prompt an Claude angehängt.
- **Approval-Marker** — Leere Datei unter `_memory/approvals/<task-id>.approved`, die einer Task die R2-Schreibfreigabe gibt. Mit `_memory/approvals/.enforce` aktivierst du den harten Approval-Modus (Push wird ohne Marker blockiert).
- **Autonomy-Mode** — Default-Modus von Claude: Aufgabe durchziehen ohne Pre-Op-Block, Stop nur bei vier Triggern (siehe **Tier-3**). Wechsel mit `/safe-mode` / `/autonomy-mode`.

## C

- **Connexio** — Read-only-Schnittstelle (HTTP + MCP) und Task-Bridge, über die andere KIs (Codex, Cursor) Nexus lesen und Tasks an Claude/zueinander übergeben können, ohne direkten Schreibzugriff. Code: `agent/connexio/`.
- **Cortex** — Oberbegriff für das ganze System (Nexus + Projects + Second Brain + lokale Konfigs) auf deinem Mac. Liegt in `~/Cortex/`.
- **Cron-Recipe** — TOML-Datei in `agent/cron/recipes/`, die einen Cortex-Skill periodisch starten lässt (z.B. `nightly-sanitizer.toml`). Ausgeführt vom LaunchAgent-basierten Cron-Runner.

## D

- **Daemon** — Hintergrundprozess ohne Benutzeroberfläche, der dauerhaft oder periodisch läuft. Im Cortex-Kontext meistens als LaunchAgent gestartet.
- **devices.json** — Single Source of Truth für die Mac-Registry: pro Gerät Hostname, Rolle, Projekte, Tailscale-Mesh-Daten. Liegt in `.config/devices.json`.

## F

- **FTS5** — „Full-Text-Search v5", das Volltextsuch-Modul von SQLite. Wird in `_memory/memory.db` für Pattern-, Session- und Fact-Suche genutzt.

## G

- **Gateway** — TypeScript/Bun-Schicht (`gateway/`), die Channels (Telegram, künftig Slack, iPad, …) registriert und Nachrichten zum Agent routet. „OpenClaw-style".
- **Gitignore** — Datei `.gitignore`, in der Pfade aufgelistet werden, die Git ignoriert (nicht committet). Im Nexus: `_memory/memory.db`, `_archive/*`, `.env`, `.venv/` u.v.m.
- **Goldene Regeln** — Destillierte Lessons-Learned + Tier-3-Hardstops + Wiederholungsfehler-Patterns (GF-001..GF-007). Single Source: `_memory/golden-rules.md`. Wird vom Agent in den System-Prompt-Block gerendert.

## H

- **Heartbeat** — Zeitstempel-Datei pro Mac unter `.config/heartbeats/<host>.heartbeat`, die `nexus-sync.sh` aktualisiert. Andere Macs nutzen den Heartbeat, um zu erkennen ob ein anderer Mac aktuell aktiv ist (Cross-Device-Coordination).
- **Hermes-style** — Architektur-Begriff für die Agent-Schicht: minimaler, deterministischer Loop (System-Prompt → User-Prompt → LLM-Call → Antwort), keine verschachtelten Agent-Loops. Vorbild: das Hermes-Agent-Framework.
- **Hook** — Skript, das automatisch bei einem bestimmten Event ausgeführt wird. Im Cortex zentral: der **UserPromptSubmit-Hook** (`tools/cortex-mode/bin/inject.sh`), der bei jedem Prompt den aktuellen Modus + Tier-3-Block injiziert.

## J

- **JSON** — „JavaScript Object Notation", textuelles Format für strukturierte Daten (Schlüssel-Wert-Paare, Listen). Verbreitetes Austauschformat zwischen Programmen, leicht für Menschen lesbar. Beispiel: `.config/devices.json`, `tasks-mirror/task-*.json`.

## L

- **LaunchAgent** — macOS-Mechanismus (`launchd`) zum Starten von Skripten beim Boot oder in festen Intervallen. Cortex nutzt z.B. `com.cortex.nexus-sync.plist` für den Auto-Sync alle 5 Minuten.
- **Lean v3** — Architektur-Spec (`specs/cortex-lean-v3/`) gegen Drift und Redundanz. Drei Säulen: State First, One-Mac-At-A-Time per Lease, Memory mit Verfallsdatum.
- **Lease** — Schreibsperre auf ein Repo + Scope, die ein Mac/Agent für eine begrenzte Zeit (TTL) hält. Verhindert parallele Schreibzugriffe von mehreren Macs/KIs. Code: `agent/connexio/lease_store.py`.

## M

- **MCP** — „Model Context Protocol", Anthropic-Standard für Tool-Brücken zwischen LLM und externen Diensten. Im Cortex stellt z.B. `agent/connexio/mcp_server.py` MCP-Tools für andere KIs bereit (`get_user_profile`, `list_projects`, `handoff_to_agent`, …).
- **Mode-Block** — Markdown-Inhalt aus `agent/modes/autonomy.md` oder `safe.md`, der vom Hook in den System-Prompt injiziert wird und das Verhalten der Session prägt.

## N

- **Nexus** — Das Steuerwerk in Cortex (`~/Cortex/Nexus/`). Enthält Regeln, Agent-Code, Memory, Vault, Sync-Skripte. Ein Git-Repository (`Sanexio/nexus`).

## O

- **OpenClaw-style** — Architektur-Begriff für die Gateway-Schicht: kanalagnostischer Router mit Pairing-Store und Sandbox-Isolation für Inbound-Nachrichten. Vorbild: das OpenClaw-Projekt.
- **Outbox** — `~/Cortex/projects/_ai-cooperation-outbox/`. Ältere Markdown-basierte Übergabe-Inbox zwischen KIs. Wird ab 2026-06-12 durch Connexio-`handoff_to_agent` ersetzt.

## P

- **Phoenix** — Hard-Reset des Nexus-Steuerwerks am 2026-05-08/09. Alte `_rules/`, `_memory/` und `tools/cortex-*` wurden gelöscht und durch die aktuelle zweischichtige Agent+Gateway-Architektur ersetzt. Backup: GitHub-Branch `pre-phoenix-reset-2026-05-08`.
- **Pflicht-Lesung** — Drei Files, die jede KI-Session am Anfang liest: `CLAUDE.md`, `_rules/AUTONOMY_CONTRACT.md`, `_rules/glossary.md` (diese Datei).
- **Phoenix-Welle / Welle** — Eine abgeschlossene Bearbeitungs-Einheit im Phoenix-Sprint (z.B. „Welle 5 = Telegram-V3 + Cutover"). Endet mit Debrief + Commit + Push.
- **plist** — „Property List", macOS-XML-Format für Konfigurationsdateien. LaunchAgents werden als `.plist` geschrieben (z.B. `com.cortex.nexus-sync.plist`).

## R

- **R0 / R1 / R2 / R3** — Risikolevel für KI-Operationen (siehe `AUTONOMY_CONTRACT.md` §2): R0=nur Lesen (immer frei), R1=Projekte schreiben (`~/Cortex/projects/`, frei wenn Projekt-Regeln das erlauben), R2=Nexus-Kern schreiben (nur mit Freigabe), R3=Hardstop (Tier-3-Liste).

## S

- **Safe-Mode** — Architekten-Workflow in 4 Phasen mit Approval-Gate vor Phase 3 (Umsetzung). Wechsel mit `/safe-mode`. Detail: `agent/modes/safe.md`.
- **Sanitizer** — Skill, der alte Logs rotiert, Memory-DB vakuumiert und stale Spawn-Queue-Einträge archiviert. Aufruf: `cortex-agent skill run sanitizer`.
- **Second Brain** — Obsidian-Vault innerhalb Nexus (`Nexus/Second Brain/`). Wissensbasis mit Tutorials, Regeln, Sessions, Glossar.
- **Skill** — Im Cortex-Kontext zwei Bedeutungen:
  - **(Python-)Skill** = `@skill`-dekorierte Funktion in `agent/skills/builtin/`, aufrufbar via `cortex-agent skill run <name>`. Beispiele: `doctor`, `capture_lesson`, `sanitizer`.
  - **(Claude-Code-).skill-Paket** = ZIP-artiges Paket in `Nexus/skills/*.skill`, das in `~/.claude/skills/` entpackt wird. Beispiele: `frontend-design.skill`, `smartq-dashboard.skill`.
- **Spawn / Spawn-Queue** — Mechanismus, mit dem Telegram/iPad-Nachrichten an Cortex zwischengepuffert werden, bis ein Agent verfügbar ist. Code: `agent/connexio/spawn_queue.py`, `spawn_watcher.py`.
- **SSOT** — „Single Source of Truth". Prinzip: pro Information existiert genau eine authoritative Quelle. Verhindert Drift und Widersprüche.
- **State-First** — Lean-v3-Prinzip: vor Empfehlungen aktiven Status abfragen (`git log`, SSH, DB, curl) statt Memory zu vertrauen. Memory ist nur für Insights/Learnings.

## T

- **Tailscale** — Mesh-VPN-Dienst, der deine Macs in ein privates Netz verbindet. Cortex nutzt Tailscale für SSH zwischen Macs (z.B. `tailscale ssh cluster-mini-02`).
- **Task-Mirror** — JSON-Datei pro Task unter `_memory/tasks-mirror/task-<id>.json`, die mit Git committed wird. Damit sind Tasks cross-device sichtbar (lokale `tasks.db` ist nur Cache).
- **Tier (Tier-3)** — Risikoklasse für Operationen. **Tier-3** = Hardstop-Operationen, die immer Stop + User-Freigabe brauchen. Drei Kategorien: Secrets, Geld, externe Empfänger. Single Source: `agent/modes/tier3.md`.
- **TOML** — „Tom's Obvious, Minimal Language", Konfigurationsformat mit Schlüssel-Wert-Paaren und Sektionen. Beispiel: `pyproject.toml`, Cron-Recipes.

## U

- **uv** — Schneller Python-Paketmanager (Astral). Cortex nutzt `uv` statt `pip` für Dependency-Management (siehe `pyproject.toml` + `uv.lock`).

## V

- **Vault** — Synonym für „Second Brain". Obsidian-Wissensbasis innerhalb Nexus.

## W

- **Welle** → siehe **Phoenix-Welle**.
- **Wikilink** — Obsidian-Syntax `[[Ziel]]` für interne Verweise zwischen Markdown-Dateien im Vault. „Wikilinks brechen" = der Pfad in einem `[[Link]]` zeigt auf eine nicht existierende oder umbenannte Datei.
