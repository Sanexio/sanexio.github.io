# Modes — Autonomy und Safe

> **Mode × Risiko-Matrix** plus Mode-Switch-Mechanik. Detaillierte
> Verhaltens-Briefings: `agent/modes/autonomy.md` und `agent/modes/safe.md`
> (vom Hook injiziert).

## Matrix

| Mode | R0 | R1 | R2 | R3 |
|---|---|---|---|---|
| **autonomy** | frei | frei, taskgebunden | Vorschlag frei; Umsetzung nur nach Freigabe | STOP |
| **safe** | frei | Phase-2-Approval | Vorschlag/Spec mit Approval | STOP |

**Safe Mode ist ein Arbeitsstil, keine Rechteerweiterung.** Auch in Safe
gelten R0-R3 unverändert; Safe fügt nur ein Approval-Gate vor jeder
R1-Umsetzung dazu (Phase 2).

## Default und Lifecycle

- **Default-Mode:** autonomy. Auto-Init bei fehlendem State-File.
- **State-File:** `~/.claude/state/cortex-mode.json`, Schema
  `{mode, since, host, set_by}`.
- **Injection:** Bei jedem Prompt-Submit liest `tools/cortex-mode/bin/inject.sh`
  das State-File und injiziert den passenden Mode-Block plus
  `agent/modes/tier3.md` als `additionalContext`. Token-Budget ~960.

## Mode-Switch-Befehle

| Befehl | Wirkung |
|---|---|
| `/autonomy-mode` | Setzt `mode = autonomy`. Ab nächstem Prompt aktiv. |
| `/safe-mode` | Setzt `mode = safe`. Ab nächstem Prompt aktiv. |
| `/cortex-mode` | Zeigt aktuellen Stand an. |

CLI-Äquivalent:

```bash
cortex-agent mode get
cortex-agent mode set autonomy
cortex-agent mode set safe
```

Der Mode-Wechsel wirkt **nicht rückwirkend** auf die laufende Antwort,
sondern erst ab dem nächsten Submit.

## Wann welcher Mode

- **Autonomy** (Default): Routinearbeit, klare Aufgaben, Debugging,
  Refactoring innerhalb bekannter Pfade.
- **Safe**: Architektur-Entscheidungen, größere Refactor-Wellen, sensible
  R2-Themen, Multi-Step-Migrationen — überall wo das Phase-2-Gate die
  letzte Sicherung vor irreversiblen Aktionen ist.

Wechsel ist jederzeit möglich, lokal pro Mac, persistiert über Sessions.

## Querverweise

- Detail-Verhalten Autonomy: `agent/modes/autonomy.md`.
- Detail-Verhalten Safe: `agent/modes/safe.md`.
- Mode-unabhängige Hardstops: `agent/modes/tier3.md`.
- Stop-Bedingungen pro Mode: `_rules/stop-conditions.md`.
- User-spezifische Freigaben (Stracke 2026-05-09): `_rules/user-directives.md`.
