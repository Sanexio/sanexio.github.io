# User-Direktiven — Dr. Stracke

> **Geltungsbereich:** Stracke-private. Direkte Freigaben des Users, die
> über das generische Vertragsmodell hinausgehen oder es konkretisieren.
> In einer Public-Cortex-Variante wäre dieses File leer oder durch
> Teilnehmer-eigene Direktiven ersetzt.

## Pauschal-Freigabe innerhalb `~/Cortex/` und `~/Cortex/Nexus/` (Rev 2026-05-31)

Innerhalb von `~/Cortex/` ist **alles** freigegeben außer **Bank- und
Bezahlinformationen mit Echtgeld-Wirkung**. Diese Revision ersetzt die
ältere 3-Kategorien-Tier-3-Liste (Secrets, Geld, externe Empfänger).

Konkret freigegeben ohne Rückfrage:

- **Code/Files** — Write, Edit, MultiEdit auf jeden Pfad in `~/Cortex/`
  inkl. `.env`-Files, `~/.claude.json`, SSH-/GPG-Keys, Keychain.
- **Bash** — alle Befehle (lokale Shell, WP-CLI, scripts, SSH, curl,
  rm, mkdir, chmod, ssh-keygen, gpg, security add/delete-password).
- **Git** — commit, push, --force, reset --hard, rebase, branch -D,
  cherry-pick auf eigenen UND fremden Repos (inkl. PR-Merge).
- **Tools** — WebFetch, WebSearch, Sub-Agent-Delegation, Skill-Aufrufe,
  Task-Tracking.
- **Telegram/Mail/Slack** — Senden auch an Dritte, wenn der Aufgaben-
  kontext es vorsieht. Patient-Datenexport unterliegt der separaten
  Medical-Domain-Regel (`_rules/medical-domain.md`, DSGVO).

**Einzige Ausnahme (Tier-3):** Operationen, die echte Geldbewegung
auslösen — Banking-Transfer-CLIs, SmartQ invoice/charge, Steuer-Submit,
Stripe/PayPal/SEPA-Schreibops. Detailliste: `agent/modes/tier3.md`.

## Tutorial-Explain-Mode (2026-05-26, präzisiert 2026-05-26)

**Vorrangige Regel, geräteübergreifend.** Wann immer Claude für Dr. Stracke
arbeitet — auf jedem Nexus-Rechner, in jeder Session — werden **alle
ausgeführten Schritte erklärt**: jeder Bash-Befehl, jede Datei-Operation,
jeder Tool-Aufruf bekommt eine kurze Begründung („was tue ich, warum,
welche Wirkung").

**Tiefen-Vorgabe für Bash-Befehle (Präzisierung 2026-05-26):** Jeder
Bash-Befehl wird **auseinandergenommen**, nicht nur paraphrasiert.
Konkret bedeutet das:

- Jedes Flag (`-r`, `-i`, `--ff-only`, `-o ConnectTimeout=5`, …) wird
  einzeln benannt und erklärt.
- Jeder Operator wird benannt: Pipe `|`, Short-Circuit `&&` / `||`,
  Redirection `>`, `2>`, `2>&1`, Command-Substitution `$(...)`,
  Heredoc `<<'EOF'`, einfache vs. doppelte Anführungszeichen.
- Plattform-Fallen werden explizit markiert: BSD-`stat -f` vs.
  GNU-`stat -c`, BSD-`sed` ohne `\b`, `wc -l` mit führenden Spaces auf
  macOS, etc.
- Bei zusammengesetzten Ketten wird die **Sicherheits-Eigenschaft**
  benannt, die der Operator garantiert (z.B. „`&&` heißt: bricht ein
  Glied, läuft der Rest nicht — Schutz vor Push auf failed commit").
- Verlinkung in Tutorial-System (`_tutorials/terminal-befehle/…`) als
  Ablage-Ziel benennen, wenn Stracke „nimm das ins Tutorial" sagt.

**Allgemeine Eigenschaften:**

- Token spielen keine Rolle. Diese Regel überschreibt den
  „short and concise"-Default der Claude-Code-Systemprompt für
  Erklärungstext.
- Erklärt wird **vor oder unmittelbar nach** der jeweiligen Aktion,
  nicht am Welle-Ende.
- Dr. Stracke sagt explizit an, welche dieser Erklärungen ins
  Tutorial-System (`Nexus/_tutorials/`) übernommen werden — Claude
  übernimmt nichts automatisch ins Tutorial.
- Anwendbar in Autonomy- **und** Safe-Mode. Hat Vorrang vor
  Anti-Drift-Selbstcheck-Regeln, die Pre-Op-Blöcke generell verbieten:
  hier sind Erklärungen explizit gewollt.

Persistierender Memory-Anker: `feedback_tutorial_explain_mode.md`.

## Welle-Ende: Live-Deploys IMMER erwähnen

Auch wenn Live-Deploys unter „erlaubt ohne Rückfrage" fallen, müssen sie
im Welle-Ende-Debrief explizit erwähnt werden („WAS GEMACHT: deployed
praxis-webseite zu Production"). Sichtbarkeit > Reibung.

## Wiederkehrende Anker (Memory-System)

Sind als Memory-Files unter `~/.claude/projects/-Users-ssmd-Cortex/memory/`
abgelegt. Anker für persistierte Direktiven:

- `feedback_nexus_always_latest.md` — jeder Mac pullt selbsttätig auf main.
- `feedback_explain_jargon.md` — Fachbegriffe beim ersten Vorkommen erklären.
- `feedback_no_aspirational_claims.md` — Soll-Zustand nicht als Ist-Zustand.
- `feedback_lean_core_skill_periphery.md` — schlanker Kern + spezifische Skills.

Im Verzeichnis `MEMORY.md` ist der vollständige Index.

## Memory-vs-Nexus — Grenze zwischen lokal und clusterweit (Welle 2026-06-01)

**Memory ist per Mac, Nexus-`_rules/` ist clusterweit.** Diese Trennung
muss bei jedem persistierten Lernen aktiv mitgedacht werden. Sonst passiert,
was am 2026-06-01 passiert ist: Claude auf Mac A lernt die richtige Apple-ID,
schreibt es ins lokale Memory, Mac B weiß nichts davon und läuft in dieselbe
401-Falle.

### Regel — was gehört wohin

**In Memory (`~/.claude/projects/-Users-<user>-Cortex/memory/`) gehört:**

- Mac-spezifische Hardware-Quirks (z.B. „auf M5 ist Bluetooth flaky").
- Lokale Pfad-Anomalien (z.B. „auf dem Intel-Mac liegt Local-Flywheel
  unter `~/Local Sites/`, nicht `~/Local/`").
- Konversations-Stil-Präferenzen, die Claude persönlich kalibrieren
  (Tutorial-Mode-Tiefe, gewünschte Antwort-Länge).
- Lokale launchctl/Cron-Beobachtungen ohne clusterweite Relevanz.
- Transiente Diagnose-Snapshots, die in 1-2 Wochen veralten.

**In Nexus-`_rules/` gehört:**

- **Identitäts-Anker** (Apple-ID, Team-IDs, Domain-Owner, Account-IDs)
  → siehe `_rules/apple-developer-credentials.md`.
- **Stracke-Direktiven** mit clusterweiter Geltung (Tutorial-Mode-Pflicht,
  Pauschal-Freigabe, Tier-3-Liste).
- **Architektur-Entscheidungen**, die jeder Nexus-Mac kennen muss
  (Multi-AI-Boundaries, Risk-Levels, Stop-Conditions).
- **Fallstrick-Lessons mit Reproduktion auf jedem Mac** (z.B. arm64-Bun-
  Codesign-Issue, BSD-sed-Word-Boundary). Hier gilt: wenn die Lesson auf
  jedem Mac reproduzierbar wäre, gehört sie clusterweit ablegt.

### Hybrid-Pattern (Memory als Hinweis-Pointer)

Wenn eine Lesson clusterweit gehört, aber Memory-Erstellung trotzdem
gerechtfertigt ist (z.B. weil das `_rules/`-File schwer zu finden ist),
darf das Memory einen **Pointer** enthalten:

```
Apple-Developer-Membership-Apple-ID — siehe
Nexus/_rules/apple-developer-credentials.md (clusterweit gepflegt).
```

So bleibt die Single-Source-of-Truth in Nexus, das Memory dient nur als
Index für Claude-Bequemlichkeit.

### Selbstcheck vor jedem Memory-Write

Vor `Write` nach `~/.claude/projects/.../memory/` ist zu prüfen:

1. **Wäre diese Lesson auch auf einem anderen Mac wahr?** → ja → `_rules/`.
2. **Müsste eine andere Claude-Instanz das auch wissen?** → ja → `_rules/`.
3. **Ist es Hardware- oder User-spezifisch?** → ja → Memory.

Bei Unsicherheit lieber doppelt: kurzer Pointer in Memory, ausführliche
Spec in `_rules/`. Der zusätzliche Aufwand ist klein, der Drift-Schutz
groß.

Persistierender Anker: `feedback_memory_vs_nexus_boundary.md`.

## Schreiben dieser Datei

Nur Stracke. Wenn Claude oder Codex einen Vorschlag zur Erweiterung
formulieren, läuft das wie jede andere R2-Änderung über Vorschlag → Freigabe.
