# Lesson-Persistenz-Anker

> **Single Source** für den Welle-Ende-Debrief-Anker-Block. Wurde bis
> 2026-05-16 wortgleich in `agent/modes/autonomy.md` und `agent/modes/safe.md`
> dupliziert; ist jetzt hier zentral und wird von beiden Mode-Files
> referenziert.

## Anker-Regel

Jeder Bullet im Block **WAS GELERNT** im Welle-Ende-Debrief braucht am
Zeilen-Ende einen Persistenz-Anker. Das macht sichtbar, ob eine Lesson
wirklich abgesichert ist oder nur in der Session verpufft.

## Erlaubte Anker

- `-> feedback_<slug>.md` — Lesson als Memory-Eintrag geschrieben (Pfad:
  `~/.claude/projects/<projekt>/memory/feedback_<slug>.md`). Erzeugt
  typischerweise durch `cortex-agent skill run capture-lesson`.
- `-> specs/<slug>/` — Lesson als Spec verankert (Konzept-Datei oder
  Changelog-Eintrag im jeweiligen Spec-Ordner).
- `-> CLAUDE.md` — Lesson als Regel in eine CLAUDE.md eingearbeitet
  (Nexus-Root, Projekt-Root oder Projekt-Sub-CLAUDE.md).
- `-> hook:<name>` — Lesson strukturell in einem Hook/Skill abgesichert
  (z.B. `hook:lesson_audit`, `hook:local_first_discovery`).
- `(ephemer)` — bewusst nur Session-Kontext, kein persistenter Träger.
  Akzeptable Wahl, aber dokumentiert, dass die Lesson nicht über die
  Session hinaus wirkt.

## Mode-Verhalten

| Mode | Bei fehlendem Anker |
|---|---|
| **Autonomy** | Debrief wird nicht blockiert, aber der Audit-Helper (`tools/cortex-mode/bin/lesson_audit.py`) rendert die Lücke sichtbar im Debrief. |
| **Safe** | Welle-Ende ist nicht abschließbar. STOP, erst Anker setzen oder als `(ephemer)` markieren. |

## Beispiele

```
## WAS GELERNT
- Nexus-Sync greift nicht bei Feature-Branches, wenn nexus-sync.sh
  branch-aware-FF nicht aktiviert ist. -> specs/sync-alarm-escalation/
- User-Feedback: Fachbegriffe immer beim ersten Vorkommen erklären.
  -> feedback_explain_jargon.md
- Tailscale-SSH mit hostname schlägt fehl wenn MagicDNS unkonfiguriert
  ist; mit IP funktioniert es. (ephemer)
```

## Querverweise

- Verhalten der Anker-Validierung: `tools/cortex-mode/bin/lesson_audit.py`
  emittiert beim Hook-Trigger den Audit-Block.
- Mode-Einbindung: `agent/modes/autonomy.md` (warnend) und
  `agent/modes/safe.md` (blockierend).
- Spec: `specs/lesson-persistence/00_KONZEPT.md` — die Architektur dahinter.
