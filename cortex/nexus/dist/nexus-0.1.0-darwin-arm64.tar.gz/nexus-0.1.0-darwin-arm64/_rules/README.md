# `_rules/` — Policy-Schicht

> **Was hier liegt:** Geräteübergreifend gültige Policies. Alles
> GitHub-synced. Mode-/Risiko-/Stop-/AI-/Security-/Domain-Regeln.
>
> **Was hier NICHT liegt:** Mode-Briefings (`agent/modes/*.md`),
> Tier-3-Single-Source (`agent/modes/tier3.md`), Skill-Implementierungen
> (`agent/skills/builtin/`), Projekt-spezifische Regeln (`projects/<x>/.cortex/`).

## Hierarchie (nach Tragweite)

### Tier-A — Pflicht-Lesung jede Session

1. **`AUTONOMY_CONTRACT.md`** — Index aller Regeln. R0–R3, State-First, Lease, AI-Cooperation in Kurzform.
2. **`glossary.md`** — Begriffe (R0–R3, Hook, Lease, FTS5, MCP, Connexio, Tier-3, Welle, Phoenix, Skill, …).
3. **`user-directives.md`** — Stracke-Direktiven (Pauschal-Freigabe `~/Cortex/`, Tutorial-Explain-Mode). Höchste Priorität bei Kollision.
4. **`stop-conditions.md`** — Vollliste der Stop-Trigger, mode-unabhängig.

### Tier-B — Bei Bedarf nachlesen

5. **`risk-levels.md`** — R0–R3-Detail (mit Beispielen).
6. **`modes.md`** — Mode × Risiko-Matrix, Switch-Befehle.
7. **`tasks.md`** — Task-Manifest-Pflichtfelder + Pre-Flight.
8. **`verification.md`** — Was vor `done` geprüft werden muss.
9. **`retention.md`** — Anti-Müll, was wie lange behalten.
10. **`sync-policy.md`** — Runtime-Aggregat: wer pullt/pusht/wann.

### Tier-C — Domänen-spezifisch

11. **`ai-cooperation.md`** — Claude × Codex Peer-Modell, Outbox-Konvention.
12. **`multi-ai-boundaries.md`** — Andere KIs (Cursor, Cline, Continue, Gemini-CLI) am Nexus-Kern.
13. **`security.md`** — Tokens, Secrets, Logging.
14. **`medical-domain.md`** — DSGVO, Patient-Tags, SmartQ-Spezifika.
15. **`lesson-anchors.md`** — Wie `WAS GELERNT`-Bullets persistent verankert werden.
16. **`apple-developer-credentials.md`** — Apple-ID (`bm@westend-hausarzt.de`), Team-ID `QYC7S8YGXV`, Notarization-Profile-Setup pro Mac.

### Sub-Verzeichnis

- **`desk/`** — Regeln für `~/Cortex/Desk/` (Dokumenten-Eingangskorb). Separate Domäne mit eigener README.

## Was passierte 2026-05-31

- Pointer-Stubs `AI_COOPERATION.md` und `MULTI_AI_BOUNDARIES.md` entfernt (waren leere Compat-Pointer nach dem 2026-05-16-Rename auf lowercase). 14 Querverweise updated.
- Diese README erstmals angelegt.

## Geplante Konsolidierung

Siehe `specs/rules-consolidation/00_PLAN.md` (folgt) — Ziel-Architektur:
`AUTONOMY_CONTRACT.md` zieht `risk-levels`, `modes`, `tasks`, `verification`,
`retention`, `sync-policy` in eindeutige Abschnitte ein. Tier-C bleibt
separat. Damit Reduktion von 15 → 6 Files. Ausführung als eigenständige
Welle, nicht ad hoc, weil Querverweise in CLAUDE.md, SYSTEM_MAP.md,
Tutorials und Memory-Files mit-migriert werden müssen.
