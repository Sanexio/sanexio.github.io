# Retention und Anti-Müll

> Runtime-Artefakte sind Arbeitsmaterial, nicht Wissen. Sie brauchen
> harte Retention. Wissensdateien dagegen dürfen nicht durch Sanitizer
> oder Auto-Curator umgeschrieben werden.

## Default-Policy für Runtime-Artefakte

- **Logs rotieren.** `_memory/logs/*.log` und ähnliche werden vom
  `sanitizer`-Skill rotiert und nach Frist komprimiert oder gelöscht.
- **Queue-Entries archivieren.** Nach Abschluss eines Spawns landet der
  Eintrag im Archive, nicht im Active-Set.
- **Rohdaten komprimieren oder entfernen, Summaries behalten.** Lange
  Tool-Outputs nicht endlos im Speicher halten; die Lehre daraus
  destillieren und ablegen.
- **Health-Dateien begrenzen.** `_memory/health/sync-drift.json` und
  Verwandte sind Snapshots, nicht Verlaufsdaten. Sie werden überschrieben.
- **Audit-Logs append-only**, nach Frist komprimieren. `_memory/audit/*.jsonl`
  wachsen kontinuierlich; periodische Komprimierung.

## Wissensdateien (geschützt)

Folgende Pfade werden vom Sanitizer **nie** angetastet:

- `Second Brain/` (gesamter Vault).
- `_memory/USER.md`, `_memory/KNOWLEDGE.md`.
- `_memory/golden-rules.md`, `_memory/recurring-bugs.md` (zukünftig).
- `_rules/*` (alle Regel-Dateien).
- `agent/modes/*.md`.
- `~/.claude/projects/*/memory/*.md`.

Auto-kuratierendes Umschreiben dieser Dateien ist Pflicht-verboten —
sie werden nur manuell oder über bewusst aufgerufene Skills
(`tutorial_curator`, `capture_lesson`) verändert.

## TTL für Memory-Facts (Lean v3 §M3)

Facts in `_memory/memory.db` tragen ein `expires_at`-Feld. Nach Ablauf
landen sie in einer Quarantäne, nicht im aktiven Recall-Index. Details
in `specs/cortex-lean-v3/00_KONZEPT.md` §M3.

## Periodischer Cleanup

Aufruf über Cron-Recipe:

```bash
cortex-agent skill run sanitizer
```

Oder als nightly-Job via `agent/cron/recipes/nightly-sanitizer.toml`.

## Querverweise

- Sanitizer-Implementierung: `agent/skills/builtin/sanitizer.py`.
- Memory-Schema: `agent/memory/store.py`.
- Vault-Audit: `agent/skills/builtin/tutorial_curator.py`.
