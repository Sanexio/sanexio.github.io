# Autonomy Contract — Index

> **Status:** v2, 2026-05-16 (Aufspaltung in fokussierte `_rules/*.md`-Files).
> **Zweck:** Einstiegs-Index für den Betriebsvertrag. Enthält nur die
> Kern-Grundsätze + Regelkollision; alle Detail-Themen sind in eigene
> Dateien ausgegliedert.

## 1. Grundsatz

**Autonomy** bedeutet: innerhalb des freigegebenen Risiko- und Pfadrahmens
selbstständig arbeiten, verifizieren und knapp debreffen. Autonomy
bedeutet **nicht**: Sync-Konflikte riskieren, Nexus-Kern ohne Freigabe
ändern oder R3-Aktionen ausführen.

**Safe Mode** bedeutet: derselbe Rechte-Rahmen, aber expliziter
4-Phasen-Workflow mit Approval-Gate vor Umsetzung.

## 2. Mode × Risiko-Matrix (Kurzform)

| Mode | R0 | R1 | R2 | R3 |
|---|---|---|---|---|
| **autonomy** | frei | frei, taskgebunden | Vorschlag frei; Umsetzung nur nach Freigabe | STOP |
| **safe** | frei | Phase-2-Approval | Vorschlag/Spec mit Approval | STOP |

Safe Mode ist ein Arbeitsstil, keine Rechteerweiterung. Detail:
**[`_rules/modes.md`](modes.md)** und **[`_rules/risk-levels.md`](risk-levels.md)**.

## 3. Regelkollision — Entscheidungsreihenfolge

Bei Widerspruch gilt:

1. Dr. Stracke
2. Freigegebene Nexus-Policy (`_rules/`, `specs/`)
3. Projekt-Policy (Projekt-`CLAUDE.md` oder `.cortex/`-Regeln)
4. Task-Manifest
5. Agent-Default

Bei unauflösbarer Kollision: **Stop, Review anfordern.**

## 4. Detail-Themen — Verweise

| Thema | Datei |
|---|---|
| Risiko-Level R0-R3 (Volldetail) | [`_rules/risk-levels.md`](risk-levels.md) |
| Mode × Risiko + Switch-Befehle | [`_rules/modes.md`](modes.md) |
| Stop-Bedingungen (alle Modi) | [`_rules/stop-conditions.md`](stop-conditions.md) |
| Task-State-Machine + Pflichtfelder + Pre-Flight | [`_rules/tasks.md`](tasks.md) |
| Verifikation vor `done` | [`_rules/verification.md`](verification.md) |
| Retention für Runtime-Artefakte | [`_rules/retention.md`](retention.md) |
| AI-Cooperation (Claude × Codex Peer) | [`_rules/ai-cooperation.md`](ai-cooperation.md) |
| Multi-AI-Boundaries (andere KIs am Nexus) | [`_rules/multi-ai-boundaries.md`](multi-ai-boundaries.md) |
| Tier-3-Hardstops (R3-Detail-Liste) | [`agent/modes/tier3.md`](../agent/modes/tier3.md) |
| Persistenz-Anker für Welle-Ende-Lessons | [`_rules/lesson-anchors.md`](lesson-anchors.md) |
| User-Direktiven (Stracke-spezifisch) | [`_rules/user-directives.md`](user-directives.md) |
| Glossar | [`_rules/glossary.md`](glossary.md) |

## 5. Historie

- **v2 (2026-05-16):** Aufspaltung in fokussierte Files (Architecture-Refactor
  Priorität 2). Vorherige v1 hatte 504 Zeilen / 13 KB mit 12 Kapiteln gemischt;
  jetzt ist diese Index-Datei ~70 Zeilen, jedes Detail-Thema in eigener Datei.
  Spec: `specs/architecture-refactor-2026-05/`.
- **v1 (2026-05-12):** Erste konsolidierte Fassung nach Phoenix-Reset
  (siehe `HANDOVER_PHOENIX.md`).
