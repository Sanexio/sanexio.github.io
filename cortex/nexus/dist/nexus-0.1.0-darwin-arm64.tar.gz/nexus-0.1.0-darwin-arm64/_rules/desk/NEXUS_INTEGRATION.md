# Nexus-Integration

> Wie `Desk/` in das Nexus-Regelsystem eingebunden ist.

## Architekturprinzip

```
┌─────────────────────────────────────────────────────────┐
│  Cortex (lokaler Arbeitsordner auf jedem Gerät)         │
│  ┌─────────────────────────────────────────────────┐    │
│  │ Nexus/                                          │    │
│  │  - portabler Wissens- und Regelkern             │    │
│  │  - Git-Repo (origin: Sanexio/nexus)             │    │
│  │  - Single Source of Truth für globale Regeln    │    │
│  │  - Tool-Bibliothek (_lib)                       │    │
│  │  - Second-Brain (Obsidian-Vault)                │    │
│  └─────────────────────────────────────────────────┘    │
│                       ▲                                 │
│                       │ Pointer / Tool-Aufrufe          │
│                       │                                 │
│  ┌─────────────────────────────────────────────────┐    │
│  │ Desk/                                           │    │
│  │  - Verwaltungs-Schicht                          │    │
│  │  - Git-Repo (origin: Sanexio/desk)              │    │
│  │  - Operative Vorgangsdaten                      │    │
│  │  - Nutzt Nexus/_lib                             │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │ projects/                                       │    │
│  │  - Gerätespezifische Software-Projekte          │    │
│  └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
```

## Welche Nexus-Ressourcen Desk nutzt

### Globale Regeln (LL-001 ff., KON-001, TUT-001)

- Quelle: `Nexus/_rules/GLOBAL_RULES.md`
- In Desk: per Pointer-Verweis aus `Desk/DESK.md` und `Desk/_rules/DESK_RULES.md`
- Bei Sessionstart: Desk-Skill liest beide Dateien (Nexus + Desk)

### Tool-Bibliothek

| Tool | Pfad | Anwendung in Desk |
|---|---|---|
| `universal_extract.py` | `Nexus/_lib/extract/` | Textextraktion aus `Input/`-Ordnern |
| `extract_diagnoses.py` | `Nexus/_lib/medical/` | ICD-10-Diagnosen aus Befunden |
| `validate_report.py` | `Nexus/_lib/validate/` | Output-Validierung |
| `pdf_utils.py` | `Nexus/_lib/pdf/` | PDF-Manipulation |
| `rename/` | `Nexus/_lib/rename/` | Dateinamen-Normalisierung |
| `ocr/` | `Nexus/_lib/ocr/` | OCR-Pipeline |
| `steuer/` | `Nexus/_lib/steuer/` | Steuer-spezifische Tools |

**Aufrufmuster (cwd = `~/Cortex/`):**

```bash
python3 Nexus/_lib/extract/universal_extract.py Desk/Medizin/Input/
python3 Nexus/_lib/validate/validate_report.py Desk/Medizin/Output/<datei>
```

### Second-Brain-Verweise (Obsidian)

Im Obsidian-Vault `Nexus/Second Brain/` werden Desk-Vorgänge per
Wiki-Link referenziert (z.B. `[[Doc-Workflow]]` → künftig `[[Desk]]`).
Migration der bestehenden Links in `Nexus/Second Brain/` erfolgt im
Migrationsschritt (siehe `_archiv/migration_log_2026-05-22.md`).

## Regel-Hierarchie

Spezifischeres überschreibt Allgemeineres:

| Ebene | Datei | Status |
|---|---|---|
| 1 — Cortex global | `Nexus/_rules/GLOBAL_RULES.md` | Verbindlich |
| 2 — Desk | `Desk/_rules/DESK_RULES.md` | Verbindlich für Desk |
| 3 — Kategorie | `Desk/<Kategorie>/_config/RULES.md` | Verbindlich für Kategorie |
| 4 — Shared Subcat | `Nexus/_rules/_shared_subcategories/<sub>/RULES.md` (optional) | Basis für gemeinsame Subkategorien |
| 5 — Subkategorie | `Desk/<Kategorie>/_config/subcategories/<sub>/RULES.md` | Spezifischste Ebene |

## Fehlerprotokoll-Hierarchie

Identische Hierarchie wie Regeln:

| Ebene | Datei |
|---|---|
| Global | `Nexus/_rules/FEHLERPROTOKOLL.md` |
| Desk | `Desk/_config/FEHLERPROTOKOLL.md` |
| Kategorie | `Desk/<Kategorie>/_config/FEHLERPROTOKOLL.md` |
| Subkategorie | `Desk/<Kategorie>/_config/subcategories/<sub>/FEHLERPROTOKOLL.md` |

Bei jedem Sessionstart: alle vier Ebenen lesen.

## Verzicht auf Duplikate

**Was nicht in Desk dupliziert wird:**

- Tools (immer aus `Nexus/_lib/`)
- Globale Regeln LL-001 ff. (per Pointer referenziert)
- Tutorials / Konzepte (bleiben im Second Brain)
- Geräte-Inventar (`Nexus/.config/devices.json` — wird um Desk-Eintrag erweitert)

## Sync-Trennung

Nexus und Desk sind **getrennte Git-Repos** mit getrennten
LaunchAgents:

| Repo | Origin | LaunchAgent | Intervall |
|---|---|---|---|
| Nexus | `Sanexio/nexus` | `com.cortex.nexus-sync` | 5 min |
| Desk | `Sanexio/desk` | `com.cortex.desk-sync` | 5 min |

Konflikte zwischen Nexus und Desk sind ausgeschlossen, da sie
unterschiedliche Pfade bedienen. Beide Sync-Agents nutzen identische
Heartbeat- und Approval-Mechanik (siehe `Nexus/_rules/sync-policy.md`).

## Konsequenzen für den Sessionstart

Der `desk`-Skill triggert wie folgt:

```
1. Lese Desk/DESK.md
2. Lese Nexus/_rules/GLOBAL_RULES.md
3. Lese Desk/_rules/DESK_RULES.md
4. Lese Desk/_rules/NEXUS_INTEGRATION.md (diese Datei)
5. Bestimme Kategorie + Subkategorie aus Benutzeranweisung
6. Lese Desk/<Kategorie>/_config/RULES.md + FEHLERPROTOKOLL.md
7. Lese Desk/<Kategorie>/_config/subcategories/<sub>/RULES.md + WORKFLOW_CHECKLIST.md + FEHLERPROTOKOLL.md
8. Arbeite los — mit allen Regeln im Kontext
```
