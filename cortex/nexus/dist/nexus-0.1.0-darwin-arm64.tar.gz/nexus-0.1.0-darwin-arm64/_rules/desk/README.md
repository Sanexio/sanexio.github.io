# Desk-Regeln (Spiegel in Nexus)

> Portable Kopie der **Desk-Regeln**, damit sie auf allen Nexus-Rechnern
> verfügbar sind. Reitet auf dem bestehenden Nexus-GitHub-Sync mit —
> kein eigenes Desk-Repo, kein zusätzlicher LaunchAgent nötig.

## Was hier liegt

Nur das **Regelwerk** der Desk-Verwaltungsschicht (`~/Cortex/Desk/`):

- `DESK_RULES.md`, `NEXUS_INTEGRATION.md`, `retention-policy.md` — Desk-Grundregeln
- `_config/` — Desk-übergreifende Regeln + Workflow-Checkliste
- `Medizin/_config/` — Kategorie- und Subkategorie-Regeln, Workflow-Checklisten, Blueprints (Befundbericht-Template, Diagnosenliste)
- `VSR/_config/` — Verwaltung · Steuer · Recht: Regeln, Checklisten, Subkategorie-Regeln

## Was hier NICHT liegt (bleibt gerätelokal)

- **Operative Daten** — Befundberichte, Diagnosen, Atteste, Anwalts-/Steuervorgänge (`Medizin/Input|Output|ARCHIV`, `VSR/Input|Output`). Patienten-/Mandantendaten dürfen nicht nach GitHub.
- **Fehlerprotokolle** (`FEHLERPROTOKOLL.md`) — fallbasierte Lern-Logs mit Patientenbezug; bleiben in der lokalen Desk-Instanz.

## Anonymisierung

Nexus synct über GitHub (`Sanexio/nexus`). Zwei Regeldateien enthielten
echte Beispieldaten Dritter und wurden für den Spiegel anonymisiert:

- `Medizin/_config/RULES.md` — Patienten-Beispielnamen → fiktive Platzhalter
- `VSR/_config/subcategories/recht/gesellschaftsrecht/RULES.md` — Mitgesellschafter-Namen/Anschriften → Platzhalter

Die Originale mit echten Daten stehen unverändert in der lokalen Desk-Instanz.

## Quelle der Wahrheit & Aktualisierung

Maßgeblich ist die lokale `~/Cortex/Desk/`-Instanz. Dieser Spiegel ist ein
**manueller Snapshot** — bei Regeländerungen in Desk muss er neu gespiegelt
werden (inkl. erneuter Anonymisierung der beiden o. g. Dateien), sonst driftet er.

_Erstellt: 2026-05-25._
