# Desk — Übergreifende Regeln

> Gelten für alle Kategorien und Subkategorien innerhalb von `Desk/`.
> Spezifischeres Regelwerk in den Kategorien überschreibt diese Datei.

## D-001 — Sessionstart-Pflicht

Bei jedem Trigger des `desk`-Skills oder einer Sub-Workflow:

1. `Desk/DESK.md` lesen
2. `Nexus/_rules/GLOBAL_RULES.md` lesen (LL-023)
3. Diese Datei lesen
4. Arbeitsbereich (Kategorie + Subkategorie) bestimmen
5. Kategorie- und Subkategorie-Regeln + Fehlerprotokolle laden
6. Erst dann mit der Verarbeitung beginnen

## D-002 — Keine Erfindungen

Alle inhaltlichen Aussagen in Output-Dokumenten müssen aus den
Input-Dokumenten ableitbar sein. Fehlende Daten werden als solche
gekennzeichnet (z.B. "aus den vorliegenden Unterlagen nicht ableitbar").

## D-003 — Keine Meta-Kommentare

Output-Dokumente enthalten keine Hinweise auf:
- KI / Sprachmodell / Vorlagen / Templates
- Automatische Erstellung
- Bearbeitungshistorie der Datei

## D-004 — Tools aus Nexus, nicht duplizieren

Alle Verarbeitungstools (Extraktion, OCR, Validierung, Diagnosen-
Extraktion etc.) liegen ausschließlich in `Nexus/_lib/`. Desk ruft
diese Tools auf, kopiert sie aber niemals.

```bash
# RICHTIG:
python3 Nexus/_lib/extract/universal_extract.py Desk/Medizin/Input/

# FALSCH:
python3 Desk/_lib/extract/universal_extract.py ...
```

## D-005 — Patientenordner-Struktur

Sobald für einen Patienten/Mandanten ≥ 2 Output-Dateien existieren,
werden diese in einen eigenen Unterordner verschoben:

```
Output/<Nachname>_<Vorname>/
    <Nachname>_<Vorname>_<YYYY-MM-DD>_<Dokumenttyp>.<ext>
```

Transliteration: `ä→ae`, `ö→oe`, `ü→ue`, `ß→ss`.
Bei Namensgleichheit Geburtsjahr anhängen: `Mueller_Peter_1972`.

## D-006 — Dateinamen-Konvention

```
<Name>_<Datum>_<Dokumenttyp>.<ext>
```

- Datum bevorzugt ISO `YYYY-MM-DD` (neue Dokumente)
- Kurzform `YYMMDD` nur für Altbestand zulässig
- Mehrere Dokumente desselben Tages: thematisches Suffix
  (`_Befundbericht.pdf`, `_Vorbefunde_Onkologie.pdf`)

## D-007 — Fehler dokumentieren

Erkannte Fehler werden im passenden Fehlerprotokoll ergänzt:

| Ebene | Datei |
|---|---|
| Global | `Nexus/_rules/FEHLERPROTOKOLL.md` |
| Desk | `Desk/_config/FEHLERPROTOKOLL.md` |
| Kategorie | `Desk/<Kategorie>/_config/FEHLERPROTOKOLL.md` |
| Subkategorie | `Desk/<Kategorie>/_config/subcategories/<sub>/FEHLERPROTOKOLL.md` |

Pro neuem Fehler:
1. Fehler-ID vergeben (Schema `D-XXX`, `MED-CAT-XXX`, `MAF-XXX` etc.)
2. Beschreibung, Ursache, Auswirkung
3. Abgeleitete Regel formulieren
4. Regel in passender `RULES.md` ergänzen
5. Prüfpunkt in `WORKFLOW_CHECKLIST.md` aufnehmen

## D-008 — Sprache und Stil

| Adressat | Sprache | Stil |
|---|---|---|
| Patient | Deutsch | Klar, freundlich, allgemeinverständlich |
| Arzt / MDK | Deutsch, Fachsprache | Internistisch präzise, ICD-Codes zulässig |
| Krankenkasse | Deutsch | Fachsprache mit Erklärungen |
| Versorgungsamt | Deutsch | Fokus auf funktionelle Einschränkungen |
| Gericht / Anwalt | Deutsch | Sachlich-formal, vollständige Rechtsnormen |
| Finanzamt | Deutsch | Steuerrechtlich präzise, Paragraphen vollständig |

## D-009 — Output-Lebenszyklus

```
Input/ → (Verarbeitung) → Output/ → (Versand/Print) → ARCHIV/
```

- Eingehende Originale: nach Verarbeitung von `Input/` nach `ARCHIV/`
- Erzeugte Dokumente: bleiben in `Output/` (ggf. Patientenordner)
- ARCHIV ist read-only und git-versioniert

## D-010 — Datenschutz

Patientendaten und sensible Verwaltungsdaten verlassen Desk nur:
- Per verschlüsseltem Push in das eigene Git-Repo
- Per direktem Versand an den jeweils zuständigen Adressaten

Synchronisation läuft ausschließlich über GitHub-Repo `Sanexio/desk`
(privat). Kein Push in öffentliche Repos. Kein Cloud-Storage außer Git.

---

## Geltungsbereich pro Sub-Workflow

| Subworkflow | Hauptort | Output-Typen |
|---|---|---|
| `desk:befundberichte` | `Desk/Medizin/Input` | Strukturierter Befundbericht nach `MedReportTemplate.md` |
| `desk:amtsanfragen-medizin` | `Desk/Medizin/Input` | Antwortschreiben an Behörde |
| `desk:amtsanfragen-steuer` | `Desk/VSR/Input` | Antwortschreiben an Finanzamt |
| `desk:verwaltung-personal` | `Desk/VSR/Input` | Personalvorgänge |
| `desk:verwaltung-mietvertrag` | `Desk/VSR/Input` | Mietsachen |
| `desk:verwaltung-kv` | `Desk/VSR/Input` | KV-Mitteilungen |
| `desk:recht-anwaltskorrespondenz` | `Desk/VSR/Input` | Anwaltskorrespondenz |
| `desk:recht-datenschutz` | `Desk/VSR/Input` | Datenschutz |
| `desk:recht-gesellschaftsrecht` | `Desk/VSR/Input` | Gesellschaftsrecht (GbR-Vertrag etc.) |
