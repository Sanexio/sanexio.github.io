# Desk — Übergreifende Konfigurations-Regeln

> Operative Konfiguration für alle Desk-Workflows.
> Verbindliche Verhaltensregeln stehen in `Desk/_rules/DESK_RULES.md`.

---

## 1. Geltungsbereich

Diese Datei steuert die operative Konfiguration für alle Kategorien und
Subkategorien innerhalb von `Desk/`:

- `Desk/Medizin/` — medizinische Vorgänge (Befundberichte, Amtsanfragen)
- `Desk/VSR/` — Verwaltung · Steuer · Recht

Subkategorie-spezifische Regeln liegen in den jeweiligen Unterordnern
`_config/subcategories/<sub>/RULES.md`.

## 2. Verantwortlich

- **Praxisinhaber / Mandant:** Dr. med. Siegbert Stracke
- **Praxis:** GP Medical Center, Leerbachstraße 62, 60322 Frankfurt am Main
- **Skill:** `desk` (lädt automatisch alle relevanten Subkategorie-Regeln)

## 3. Allgemeine Stilregeln

- **Sprache:** Deutsch
- **Ton:** Kategorie-abhängig (siehe `_rules/DESK_RULES.md` D-008)
- **Zahlen:** Dezimal-Komma, Tausenderpunkt
- **Datum:** TT.MM.JJJJ (Fließtext) / YYYY-MM-DD (Dateinamen)
- **Währung:** Euro (€), zwei Nachkommastellen
- **Keine Erfindungen** — siehe `_rules/DESK_RULES.md` D-002

## 4. Tools (alle in `Nexus/_lib/`)

Alle Verarbeitungstools werden aus Nexus aufgerufen — nicht dupliziert.
Siehe `_rules/NEXUS_INTEGRATION.md` für die vollständige Aufstellung.

```bash
# Pflichtaufruf-Muster (cwd = ~/Cortex/):
python3 Nexus/_lib/extract/universal_extract.py Desk/<Kategorie>/Input/
```

## 5. Verzeichnishierarchie

```
Desk/
├── DESK.md
├── README.md
├── _rules/                ← Verhaltensregeln (DESK_RULES.md etc.)
├── _config/               ← Konfiguration (DIESE Datei)
│   ├── RULES.md
│   ├── FEHLERPROTOKOLL.md
│   └── WORKFLOW_CHECKLIST.md
├── _sync/                 ← Sync-Mechanismus
├── _archiv/               ← Migrations- und Konfigurationshistorie
│
├── Medizin/
│   ├── Input/             ← Eingehende Originale
│   ├── Output/            ← Ausgehende Dokumente (mit Patientenordnern)
│   ├── ARCHIV/            ← Archivierte Vorgänge
│   └── _config/
│       ├── RULES.md
│       ├── FEHLERPROTOKOLL.md
│       ├── WORKFLOW_CHECKLIST.md
│       └── subcategories/
│           ├── befundberichte/
│           └── amtsanfragen/
│
└── VSR/
    ├── Input/
    ├── Output/
    └── _config/
        ├── RULES.md
        ├── FEHLERPROTOKOLL.md
        ├── WORKFLOW_CHECKLIST.md
        └── subcategories/
            ├── verwaltung/
            ├── steuer/
            └── recht/
```

## 6. Regel-Hierarchie

| Ebene | Datei | Verbindlichkeit |
|---|---|---|
| 1 | `Nexus/_rules/GLOBAL_RULES.md` | Global Cortex |
| 2 | `Desk/_rules/DESK_RULES.md` | Desk-übergreifend |
| 3 | `Desk/_config/RULES.md` (DIESE Datei) | Desk-Konfiguration |
| 4 | `Desk/<Kategorie>/_config/RULES.md` | Kategorie |
| 5 | `Desk/<Kategorie>/_config/subcategories/<sub>/RULES.md` | Subkategorie |

Spezifischere Ebene überschreibt allgemeinere bei Konflikt.

## 7. Regel-Logbuch

| Datum | Regel-ID | Beschreibung |
|---|---|---|
| 2026-05-22 | D-001 bis D-010 | Initialer Desk-Regelsatz (siehe `_rules/DESK_RULES.md`) |
