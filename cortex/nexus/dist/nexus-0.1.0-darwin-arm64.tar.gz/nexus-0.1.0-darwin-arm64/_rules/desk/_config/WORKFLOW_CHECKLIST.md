# Workflow-Checkliste: Desk (Übergreifend)

> Diese Checkliste gilt für ALLE Desk-Verarbeitungen.
> Subkategorie-spezifische Schritte werden in den jeweiligen
> `_config/subcategories/<sub>/WORKFLOW_CHECKLIST.md` ergänzt.

---

## PHASE 0: SESSIONSTART (Pflicht bei jedem Trigger)

- [ ] `Desk/DESK.md` gelesen
- [ ] `Nexus/_rules/GLOBAL_RULES.md` gelesen (LL-023)
- [ ] `Desk/_rules/DESK_RULES.md` gelesen
- [ ] `Desk/_rules/NEXUS_INTEGRATION.md` bei Bedarf konsultiert

---

## PHASE 1: VORBEREITUNG

- [ ] Input-Ordner geprüft (`Desk/Medizin/Input/` oder `Desk/VSR/Input/`)
- [ ] Dateien eingelesen via `Nexus/_lib/extract/universal_extract.py`
- [ ] Dokumentart erkannt — Medizin oder VSR?
- [ ] Subkategorie bestimmt (Befundbericht, Amtsanfrage, KV-Mitteilung,
      Anwaltskorrespondenz, Steuer-Amtsanfrage, etc.)
- [ ] Fehlerprotokolle gelesen — alle vier Ebenen:
    - [ ] `Nexus/_rules/FEHLERPROTOKOLL.md`
    - [ ] `Desk/_config/FEHLERPROTOKOLL.md`
    - [ ] `Desk/<Kategorie>/_config/FEHLERPROTOKOLL.md`
    - [ ] `Desk/<Kategorie>/_config/subcategories/<sub>/FEHLERPROTOKOLL.md`

---

## PHASE 2: VERARBEITUNG

- [ ] Subkategorie-spezifische Regeln aus `_config/subcategories/` angewendet
- [ ] Blueprint-Vorlage geladen (falls vorhanden)
- [ ] Keine Daten erfunden — alle Inhalte aus Input-Dokumenten (D-002)
- [ ] Keine Meta-Kommentare über KI / Vorlagen (D-003)
- [ ] Diagnosen/Befunde korrekt extrahiert (bei Medizin)
- [ ] Bei Behörden-Antwortbriefen: aktuelle Praxisadresse Leerbachstr. 62
      verwendet (nicht alte Adresse aus Anfrage-Spiegelung)

---

## PHASE 3: QUALITÄTSSICHERUNG

- [ ] Ergebnis gegen Blueprint geprüft — Vollständigkeit?
- [ ] Validierung via `Nexus/_lib/validate/validate_report.py` (sofern relevant)
- [ ] Fehlerprotokoll-Abgleich — bekannte Fehlermuster geprüft?
- [ ] Bei neuen Fehlern: Fehlerprotokoll auf passender Ebene ergänzen

---

## PHASE 4: AUSGABE

- [ ] Ergebnis im richtigen Output-Ordner gespeichert
- [ ] Dateiname folgt Konvention: `<Name>_<YYYY-MM-DD>_<Dokumenttyp>.<ext>`
- [ ] **Patientenordner-Prüfung (D-005, MED-CAT-001):**
    - [ ] Hat dieser Patient/Mandant ≥ 2 Output-Dateien?
    - [ ] Falls ja: Ordner `<Nachname>_<Vorname>/` anlegen oder verwenden,
          alle zugehörigen Dateien dorthin verschieben
- [ ] Benutzer über Ergebnis informiert (computer://-Link bevorzugt)
