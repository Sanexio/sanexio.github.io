# Aufbewahrungs-Policy für Desk

> Regelt, wie lange Vorgangsdaten in Desk aufbewahrt werden und wann sie
> in `ARCHIV/` migrieren bzw. gelöscht werden.

## Rechtlicher Rahmen

| Dokumenttyp | Aufbewahrungsfrist | Rechtsgrundlage |
|---|---|---|
| Patientenakte | 10 Jahre nach letzter Behandlung | § 630f Abs. 3 BGB, § 10 Abs. 3 (M)BO-Ä |
| Röntgen / CT / MRT | 10 Jahre (Erwachsene); bis 28. Lebensjahr (Kinder) | § 28 RöV / § 85 StrlSchV |
| Bestrahlungspläne | 30 Jahre | § 85 StrlSchV |
| Steuerunterlagen (Praxis) | 10 Jahre | § 147 AO |
| Geschäftsbriefe | 6 Jahre | § 147 AO |
| Lohnunterlagen | 6 Jahre | § 41 EStG |
| Sozialversicherungsunterlagen | 10 Jahre (DRV) / 4 Jahre (KK) | § 28f SGB IV |
| GbR-Vertrag, Gesellschafterbeschlüsse | unbefristet (solange GbR besteht + 10 Jahre) | § 257 HGB analog |
| Anwaltskorrespondenz | 6 Jahre (idR) | § 50 BRAO |
| Mietvertrag | Mietzeit + 3 Jahre nach Beendigung | § 195 BGB |

## Praktische Umsetzung in Desk

### Phase 1 — Operativ (Input/Output)

Aktuelle Vorgänge, in Bearbeitung oder kürzlich abgeschlossen.

- `Input/` — Originale eingehender Dokumente
- `Output/` — erstellte Antworten/Berichte
- Verbleib: bis Vorgang abgeschlossen ist (typisch 0–90 Tage)

### Phase 2 — Archiv (ARCHIV/)

Abgeschlossene Vorgänge.

- `ARCHIV/<Jahr>/<Patient/Mandant>/` oder thematisch
- Verbleib: bis Aufbewahrungsfrist abläuft

### Phase 3 — Migration in Kaltarchiv

Vor Ablauf der Aufbewahrungsfrist:
- Export aus dem Git-Repo (PDF/A-konforme Konvertierung)
- Verlagerung auf externes Archiv (NAS / verschlüsselter Datenträger)
- Eintrag im Lösch-Log `_archiv/retention_log.md`

### Phase 4 — Löschung

Nach Ablauf der Aufbewahrungsfrist und schriftlicher Freigabe durch
Dr. Stracke:
- Hardlöschung aus Archiv
- Eintrag im Lösch-Log mit Datum, Vorgang, Grundlage

## Automatisierung (Backlog)

- [ ] `_sync/retention-check.sh` — listet einmal pro Quartal Vorgänge,
      die in Phase 3 wechseln
- [ ] `_archiv/retention_log.md` — strukturiertes Log
- [ ] Lösch-Freigabe-Workflow (Skill `desk:retention`)

## Datenschutz

- Vorgänge mit besonders schutzwürdigen Daten (genetische Befunde,
  HIV-Status, psychiatrische Diagnosen): zusätzlich verschlüsselt
  ablegen (`.age`-Verschlüsselung)
- Bei Löschung: kryptografisches Shreddern statt einfacher Löschung
