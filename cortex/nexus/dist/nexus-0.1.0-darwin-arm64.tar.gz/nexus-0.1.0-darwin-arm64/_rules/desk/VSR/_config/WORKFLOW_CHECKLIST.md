# Workflow-Checkliste: VSR (Verwaltung · Steuer · Recht)

**Diese Checkliste MUSS bei JEDER VSR-Dokumentenverarbeitung befolgt werden.**
Unterkategorie-spezifische Checklisten ergänzen diese.

---

## PHASE 1: VORBEREITUNG

- [ ] Input-Ordner (`VSR/Input/`) geprüft — Dateien identifiziert
- [ ] Dateien eingelesen (`_lib/extract/universal_extract.py` — KEIN Inline-OCR)
- [ ] Dokumentart bestimmt → Unterkategorie zuweisen (verwaltung / steuer / recht)
- [ ] Fehlerprotokoll gelesen (global + `VSR/_config/FEHLERPROTOKOLL.md`)
- [ ] Bei `steuer`: CashFlow-Kategorisierung `_lib/steuer/cashflow_categorize.py` nutzen (NICHT neu schreiben)
- [ ] Bei `recht`: Geltenden Gesellschaftsvertrag (PG-Vertrag vom 01.09.2025) als Referenz heranziehen

---

## PHASE 2: VERARBEITUNG

- [ ] Alle Zahlen und Angaben stammen ausschließlich aus den Input-Dokumenten
- [ ] Zahlenformat: Dezimal-Komma, Tausenderpunkt, Euro (€), zwei Nachkommastellen
- [ ] Datumsformat: TT.MM.JJJJ
- [ ] Bei `steuer`:
    - [ ] apoBank-Daten: Hinweis ergänzen, dass GKV-Erlöse (KV Hessen) NICHT enthalten sind (LL-017)
    - [ ] Stracke-Einzahlungen als private Einlagen buchen, NICHT als Erlöse (LL-019)
    - [ ] Vendor-Kategorien aus `cashflow_categorize.py` verwenden (LL-020)
- [ ] Bei `recht`:
    - [ ] Querprüfung gegen geltenden PG-Vertrag (§§ 2, 16, 18, 19, 21, 22 als Mindest-Check)
    - [ ] Schriftform sicherstellen (§ 22 PG-Vertrag)
    - [ ] Einstimmigkeit prüfen, wo erforderlich (§ 16 PG-Vertrag)
    - [ ] Schiedsklausel berücksichtigen (§ 21 PG-Vertrag)
    - [ ] Vollständige Zitierung der Rechtsnormen
- [ ] Bei `verwaltung`:
    - [ ] Mitteilungspflichten an KV (§ 33 Ärzte-ZV) prüfen
    - [ ] Datenschutz (DS-GVO) berücksichtigen
- [ ] Unterkategorie-spezifische Regeln angewendet

---

## PHASE 3: QUALITÄTSSICHERUNG

- [ ] Summen rechnerisch geprüft (bei steuerlichen Themen)
- [ ] Kategorisierungen gegen LL-018 Vendor-Mapping validiert (bei steuer)
- [ ] Bei `recht`: Vertragsverweise vollständig und korrekt zitiert
- [ ] Bei `recht`: Entwurfshinweis enthalten („ENTWURF — vor Unterzeichnung anwaltlich prüfen lassen") sofern nicht ausdrücklich anders verlangt
- [ ] Keine Meta-Kommentare vorhanden?
- [ ] Fehlerprotokoll-Abgleich — bekannte Fehlermuster geprüft?
- [ ] Bei neuen Fehlern: Fehlerprotokoll ergänzen

---

## PHASE 4: AUSGABE

- [ ] Ergebnis im `VSR/Output/<unterkategorie>/` gespeichert
- [ ] Dateiname folgt Konvention: `<JJMMTT>_<Name>_<Dokumenttyp>.<ext>`
- [ ] Bei rechtsrelevanten Dokumenten: zusätzlich PDF-Export für Unterzeichnung erstellen
- [ ] Benutzer über Ergebnis informiert
