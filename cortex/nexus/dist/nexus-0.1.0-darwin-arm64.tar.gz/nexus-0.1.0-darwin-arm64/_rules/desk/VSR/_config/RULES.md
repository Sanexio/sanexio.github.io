# VSR — Kategorie-Regeln (Verwaltung · Steuer · Recht)

Diese Regeln gelten für ALLE Unterkategorien im Bereich VSR.
Vormalige Kategorie `Steuern` wurde am 05.05.2026 in `VSR` umbenannt und um die Subkategorien `verwaltung` und `recht` erweitert.

---

## Allgemeine Angaben

- **Steuerpflichtiger / Mandant:** Dr. med. Siegbert Stracke
- **Praxis:** Praxiszentrum Dr. Stracke & Kollegen, Grüneburgweg 12, 60322 Frankfurt am Main
- **Praxisgemeinschaft:** Praxisgemeinschaft am Grüneburgweg 12 GbR (Vertrag vom 01.09.2025)
- **Geschäftsführender Gesellschafter:** Dr. med. Siegbert Stracke (Gesellschafterbeschluss vom 01.09.2025)
- **Steuerberater:** [wird ergänzt]
- **Steuernummer:** [wird ergänzt]
- **Hausanwalt / Fachanwalt Medizinrecht:** [wird ergänzt]

## Allgemeine Stilregeln

- **Sprache:** Deutsch, sachlich, juristisch / steuerrechtlich präzise
- **Ton:** Formal, korrekt, ohne Umgangssprache
- **Zahlen:** Dezimal-Komma, Tausenderpunkt (deutscher Standard)
- **Währung:** Euro (€), zwei Nachkommastellen
- **Datumsformat:** TT.MM.JJJJ
- **Rechtsnormen:** Vollständige Zitierung (z.B. „§ 728 BGB", „§ 33 Ärzte-ZV")
- **Keine Erfindungen:** Alle Sachverhaltsangaben stammen ausschließlich aus den Input-Dokumenten oder werden ausdrücklich als Annahme gekennzeichnet

## Unterkategorien

| Unterkategorie | Ordner | Zweck |
|---|---|---|
| Verwaltung | `subcategories/verwaltung/` | Verträge, Mietangelegenheiten, KV-Korrespondenz, Versicherungen, Personal-Verwaltung |
| Steuer | `subcategories/steuer/` | Steuererklärungen, Amtsanfragen, Steuerberater-Korrespondenz, GoBD-Themen |
| Recht | `subcategories/recht/` | Gesellschaftsverträge, Aufhebungs- und Auseinandersetzungsvereinbarungen, Schiedsverfahren, anwaltliche Korrespondenz, Datenschutz |

Die Sub-Subkategorien (z.B. `steuer/amtsanfragen/`) bleiben erhalten und werden bei Bedarf erweitert.

## Bestimmung der Unterkategorie

- „Anfrage Finanzamt" / „Steuerbescheid" → `steuer/amtsanfragen`
- „Gesellschaftsvertrag" / „Austritt" / „Aufhebung" / „Schiedsverfahren" → `recht/gesellschaftsrecht`
- „Mietvertrag" / „KV-Mitteilung" / „Personal" → `verwaltung`
- Bei Unklarheit: Routing nach Hauptthema. Bei Mischfällen Querverweis im Output.

## Juristische Sorgfaltspflichten (verbindlich für Subkategorie `recht`)

1. Alle erstellten Dokumente sind als Entwurf gekennzeichnet („ENTWURF — vor Unterzeichnung anwaltlich prüfen lassen") solange nicht ausdrücklich anders angewiesen.
2. Bei jeder gesellschaftsrechtlichen Maßnahme: Querprüfung gegen den geltenden Gesellschaftsvertrag (Schriftform, Einstimmigkeit, Fristen).
3. Bei Änderungen am Gesellschafterbestand: Mitteilungspflicht an die KV (§ 33 Ärzte-ZV) prüfen.
4. Datenschutzrechtliche Aspekte (DS-GVO, Patientendaten) bei jeder Personalmaßnahme oder jedem Gesellschafterwechsel mitdenken.
5. Schiedsklausel des Gesellschaftsvertrages (§ 21) bei Streitigkeiten beachten — vor jeder gerichtlichen Auseinandersetzung Schiedsverfahren.

---

*Dieses Dokument wird laufend erweitert.*
