# Amtsanfragen — Steuern-spezifische Regeln

Diese Regeln ergänzen die gemeinsame Amtsanfragen-Basis (`_global/_shared_subcategories/amtsanfragen/RULES.md`) um steuerliche Besonderheiten.

---

## 1. Typische Absender

| Absender | Typische Anfragen |
|---|---|
| Finanzamt | Beleganforderungen, Rückfragen zur Steuererklärung, Betriebsprüfung |
| Zoll | Einfuhrumsatzsteuer, Zollanfragen |

---

## 2. Briefkopf und Unterschrift

**Briefkopf:**
```
Dr. med. Siegbert Stracke
[Adresse — wird ergänzt]
Steuernummer: [wird ergänzt]
```

**Unterschriftszeile:**
```
Mit freundlichen Grüßen

Dr. med. Siegbert Stracke
```

*Hinweis: Falls der Steuerberater antwortet, dessen Briefkopf verwenden.*

---

## 3. Steuerliche Stilregeln

- **Fachsprache:** Steuerrechtliche Terminologie, §-Referenzen wo sinnvoll
- **Zahlen:** Euro-Beträge mit zwei Nachkommastellen, Dezimal-Komma, Tausenderpunkt
- **Belege:** Nur verifizierte Zahlen aus den Input-Dokumenten verwenden
- **Referenzen:** Steuerbescheid, Steuernummer und Veranlagungszeitraum korrekt angeben

---

## 4. Besonderheiten

- **Fristen:** Steuerrechtliche Fristen sind oft verbindlich — besonders hervorheben
- **Einspruchsfristen:** Bei Steuerbescheiden auf die Einspruchsfrist achten (1 Monat)
- **Steuerberater:** Falls ein Steuerberater bevollmächtigt ist, darauf verweisen

---

*Dieses Dokument wird laufend erweitert.*
