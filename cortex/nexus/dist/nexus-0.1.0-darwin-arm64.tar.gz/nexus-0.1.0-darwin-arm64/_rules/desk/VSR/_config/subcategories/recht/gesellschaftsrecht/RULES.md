# Sub-Subkategorie: Gesellschaftsrecht

Bezugsdokument: `Praxisgemeinschaftsvertrag vom 01.09.2025` + `Gesellschafterbeschluss vom 01.09.2025`.

## Beteiligte Gesellschafter (Stand 01.09.2025)

| # | Name | Fachrichtung | Praxisanschrift |
|---|---|---|---|
| 1 | Dr. med. Siegbert Stracke | Innere Medizin | Elly-Heuss-Knapp-Straße 1, 60438 Frankfurt am Main |
| 2 | [Mitgesellschafter:in 2] | Gynäkologie und Geburtshilfe | [Anschrift — lokal in Desk] |
| 3 | [Mitgesellschafter:in 3] | HNO-Heilkunde | [Anschrift — lokal in Desk] |
| 4 | [Mitgesellschafter:in 4] | Psychologische Psychotherapie | [Anschrift — lokal in Desk] |
| 5 | [Mitgesellschafter:in 5] | Psychologische Psychotherapie | [Anschrift — lokal in Desk] |

> **Anonymisiert für Nexus.** Namen und Anschriften der Mitgesellschafter sind
> personenbezogene Daten Dritter und werden NICHT nach GitHub synchronisiert.
> Die vollständige Gesellschafterliste steht in der lokalen Desk-Instanz:
> `Desk/VSR/_config/subcategories/recht/gesellschaftsrecht/RULES.md`.

Geschäftsführender Gesellschafter: Dr. med. Siegbert Stracke (Beschluss vom 01.09.2025).

## Wesentliche Vertragsnormen

- § 2 Abs. 2 — Ordentliche Kündigung: 6 Monate zum Quartalsende, Schriftform
- § 2 Abs. 3 — Außerordentliche Kündigung aus wichtigem Grund unberührt
- § 16 Abs. 2 — Beschlüsse einstimmig, je Partner eine Stimme
- § 18 — Ausscheidensgründe (Kündigung, Tod, Ausschluss, Berufsunfähigkeit, Praxisaufgabe, Insolvenz, Vollstreckung)
- § 19 — Fortsetzung mit verbleibenden Partnern; Abfindung Wert des Anteils, §§ 728, 728a BGB; fällig binnen 6 Monaten oder Halbjahresraten; Verzinsung Basiszinssatz
- § 21 — Schiedsverfahren VOR gerichtlicher Auseinandersetzung
- § 22 Abs. 1 — Schriftformerfordernis für Änderungen und Ergänzungen
- § 33 Ärzte-ZV — Mitteilung an die KV bei Änderungen am Gesellschafterbestand

## Pflichtbestandteile jeder Aufhebungs-/Austrittsdokumentation

1. Bezugnahme auf den PG-Vertrag vom 01.09.2025 (samt § und Absatz)
2. Genaue Bezeichnung von Austretendem und verbleibenden Gesellschaftern
3. Wirksamkeitsdatum (24:00 Uhr des letzten Tages)
4. Erklärung zur Fortführung der PG durch verbleibende Gesellschafter (§ 19 Abs. 1)
5. Regelung Abfindung (Verzicht oder Berechnungsmodus nach § 19 Abs. 2–4)
6. Übergabe Schlüssel / Zugangskarten / IT-Zugänge / Patientendaten
7. Datenschutz-Klausel (DS-GVO; Patientendaten werden vom Austretenden mitgenommen, da je Partner eigene Patientenkartei, § 1 Abs. 6 PG-Vertrag)
8. Schlussabrechnung Betriebskostenanteil bis Wirksamkeitsdatum
9. Schiedsklausel (§ 21 PG-Vertrag) übernehmen
10. Schriftform; Unterzeichnung durch ALLE 5 Gesellschafter
11. Ausfertigungs-Klausel (jeder Partner erhält ein Exemplar, vgl. § 22 Abs. 3 PG-Vertrag)

## Folge-Dokumente, die in der Regel gemeinsam zu erstellen sind

- Aufhebungs- und Auseinandersetzungsvereinbarung (Hauptdokument)
- Gesellschafterbeschluss zur Aufhebung (formaler Beschluss nach § 16)
- Übergabeprotokoll Schlüssel/Zugänge/Inventar (Anlage)
- Mitteilung an KV Hessen (§ 33 Ärzte-ZV)
- Information an Steuerberater
- Information an Hauptmieter (Mietkostenanteil)
- Information an gemeinsame Personalmitarbeiter (sofern betroffen)
