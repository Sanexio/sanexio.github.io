# Medizin — Kategorie-Regeln

Diese Regeln gelten für ALLE Unterkategorien im Bereich Medizin.

---

## Autor und Praxis

- **Arzt:** Dr. med. Siegbert Stracke
- **Fachrichtung:** Innere Medizin
- **Praxis:** Praxis Dr. Stracke und Kollegen, Grüneburgweg 12, 60322 Frankfurt am Main
- **Kontakt:** praxis@westend-hausarzt.de, Tel. 069 247574523, Fax 069 97206408

## Allgemeine medizinische Stilregeln

- **Sprache:** Deutsch, fachlich präzise, internistische Befundsprache
- **Ton:** Sachlich, ruhig, klinisch, ohne Polemik oder Umgangssprache
- **Zeitform:** Befunde im Präsens, Vorgeschichte im Perfekt/Präteritum
- **Zahlen/Einheiten:** Metrisch, Dezimal-Komma (deutscher Standard)
- **Keine Meta-Kommentare:** Kein Hinweis auf KI, Überarbeitung oder Vorlagen
- **Keine Erfindungen:** Alle Inhalte stammen ausschließlich aus den Input-Dokumenten

## Patientendaten

- Patientendaten werden ausschließlich aus den Input-Dokumenten entnommen
- Bei jedem Dokument: Geschlecht des Patienten identifizieren und geschlechtsspezifische Terminologie verwenden (siehe Fehlerprotokoll FP-003 in Befundberichte-Unterkategorie)

## Unterkategorien

Die spezifischen Verarbeitungsregeln befinden sich in den jeweiligen Unterkategorien unter `_config/subcategories/`:

| Unterkategorie | Ordner | Zweck |
|---|---|---|
| Befundberichte | `subcategories/befundberichte/` | Internistische Befundberichte nach Template |
| Amtsanfragen | `subcategories/amtsanfragen/` | Anfragen von Behörden und Krankenkassen beantworten |

## Bestimmung der Unterkategorie

Die Unterkategorie wird anhand der **Benutzeranweisung** und/oder des **Dokumentinhalts** bestimmt:

- „Befundbericht erstellen" → `befundberichte`
- „Amtsanfrage beantworten" / „Anfrage beantworten" → `amtsanfragen`
- „Zusammenfassung erstellen" → `befundberichte` (Aufgabentyp ZUSAMMENFASSUNG)
- Bei Unklarheit: Dokumentinhalt prüfen (Anfrage-Charakter = amtsanfragen, Befund = befundberichte)

---

## Output-Struktur — Patientenordner bei mehreren Dateien

**Regel (verbindlich seit 19.05.2026):**
Wenn für einen Patienten **zwei oder mehr** Output-Dateien existieren, werden diese **immer** in einen **eigenen Patientenordner** unter `Medizin/Output/` abgelegt. Einzelne Dateien bleiben weiterhin flach im Output-Verzeichnis.

### Identifikation des Patienten (Pflicht-Reihenfolge)

1. **Primär:** Nachname + Geburtsdatum aus dem Dateiinhalt extrahieren (Anker: `Patient(in):`, `Betrifft:`, `*DD.MM.YYYY`, `Geb. am:`, `Geboren:`, `Geburtsdatum:`).
2. **Sekundär:** Wenn Geburtsdatum fehlt, prüfen, ob im Output-Korpus genau ein DOB für diesen Nachnamen vorkommt → diesem zuordnen.
3. **Tertiär:** Dateinamen-Muster `<Nachname>_<Vorname>_<Datum>_*` (z. B. `Mueller_Juergen_2026-05-18_*`).

### Ordnername

```
<Nachname>_<Vorname>
```

- ASCII-Transliteration: `ä→ae`, `ö→oe`, `ü→ue`, `ß→ss` (z. B. `Mueller_Juergen`, nicht `Müller_Jürgen`)
- Bei Namensgleichheit kann das Geburtsjahr angehängt werden: `Mueller_Peter_1972`
- Keine Sonderzeichen, Leerzeichen oder Datums-Suffixe im Ordnernamen

### Dateinamen innerhalb des Ordners

Die bestehende Konvention bleibt unverändert:
```
<Nachname>_<Vorname>_<Datum>_<Dokumenttyp>.<ext>
```
- Datum im ISO-Format `YYYY-MM-DD` (neu) oder Kurzform `YYMMDD` (Altbestand)
- Mehrere Dokumente desselben Tages: thematisches Suffix (z. B. `_Befundbericht.pdf`, `_Krankheitsvorgeschichte.pdf`, `_Vorbefunde_Onkologie-Pneumologie.pdf`)

### Beispiel

```
Output/
├── Berg-Schmidt_Erika/
│   ├── Berg-Schmidt_Erika_2026-05-18_Befundbericht.txt
│   ├── Berg-Schmidt_Erika_2026-05-19_Befundbericht.pdf
│   ├── Berg-Schmidt_Erika_2026-05-19_Krankheitsvorgeschichte.pdf
│   ├── Berg-Schmidt_Erika_2026-05-19_Vorbefunde_Onkologie-Pneumologie.pdf
│   ├── Berg-Schmidt_Erika_2026-05-19_Vorbefunde_Endokrinologie-Osteoporose.pdf
│   ├── Berg-Schmidt_Erika_2026-05-19_Vorbefunde_Trauma-Augenheilkunde.pdf
│   └── Berg-Schmidt_Erika_2026-05-19_Vorbefunde_Hausarzt-Verlauf.pdf
└── Mustermann_2024-05-07_Befundbericht.txt       ← Einzelne Datei bleibt flach
```

### Migrationsroutine (für Altbestand)

Bei jeder Desk-Sitzung prüfen, ob durch neue Dateien ein Patient mehr als eine Datei im Output-Verzeichnis hat. Falls ja:
1. Ordner `<Nachname>_<Vorname>` anlegen, falls nicht vorhanden
2. **Alle** zugehörigen Dateien (auch die alte Einzeldatei) in den Ordner verschieben
3. Im Bericht an den Benutzer den neuen Pfad nennen

---

*Dieses Dokument wird laufend erweitert.*
