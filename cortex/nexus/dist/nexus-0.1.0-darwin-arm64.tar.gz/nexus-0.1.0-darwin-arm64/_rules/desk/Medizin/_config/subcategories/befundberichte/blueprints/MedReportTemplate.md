# MedReportTemplate

Anamnese: 
Die Patientin / Der Patient stellte sich zur internistischen Vorsorgeuntersuchung vor. Insgesamt besteht eine gute körperliche Belastbarkeit ohne relevante Einschränkungen; insbesondere wird eine Belastungsdyspnoe verneint. Eine B-Symptomatik wird nicht berichtet. Beschwerden im Sinne eines gastroösophagealen Refluxes bestehen nicht. Gelenkbeschwerden werden aktuell ebenfalls verneint. Auffällige Hautveränderungen sind nicht bekannt. Hinweise auf schlafbezogene Atemstörungen bestehen nicht.
Nykturie: 
Periphere Ödeme werden verneint. Das Körpergewicht ist nach Angaben der Patientin / des Patienten stabil.

Raucherstatus:
– Nie-Raucher / Nichtraucher, kein relevanter passiver Nikotinkontakt.
oder
– Aktiver Raucher; kumulative Rauchbelastung:  pack years.

Allergien:

Vormedikation: Siehe aktuelle Medikamentenliste.

Vorsorgeuntersuchungen:
Darmkrebsvorsorge:
Gynäkologische / urologische Vorsorge:
Hautkrebsscreening:

Impfstatus: 


Klinische Untersuchung

XX-jährige Patientin bzw. XX-jähriger Patient in unauffälligem Allgemein- und gutem Ernährungszustand.

Orientierende neurologische Untersuchung:
Kein Hinweis auf ein fokal-neurologisches Defizit. Keine Anisokorie, keine motorischen oder sensiblen Ausfälle. Kein Meningismus.

Psychischer Befund:
Gepflegtes Erscheinungsbild, altersentsprechender Kleidungsstil. Im Kontakt freundlich, zugewandt und gut mitteilungsfähig. Normale Stimmführung und unauffällige Sprachmodulation. Wach, bewusstseinsklar und vollständig orientiert.

Kopf-Hals-Bereich:
Keine Lippenzyanose, keine gestauten Halsvenen. Konjunktiven reizlos, kein Ikterus.
Sinus und Mastoid nicht druckschmerzhaft.
Palpatorisch keine suspekten Lymphknoten.

Pulmo:
Vesikuläres Atemgeräusch beidseits, keine Rasselgeräusche. Klopfschall sonor. Normale Lungengrenzen und regelrechte Zwerchfellbeweglichkeit.

Cor:
Herztöne rein und regelmäßig, ohne vitientypische oder zusätzliche Geräusche. Keine Strömungsgeräusche über den Karotiden. Orthotoper Herzspitzenstoß, kein tastbares Schwirren. Halsvenen nicht gestaut, hepatojugulärer Reflux negativ. Keine peripheren Ödeme.

Abdomen:
Unauffällige Inspektion, keine auffällige Venenzeichnung. Abdomen weich, nicht druckschmerzhaft, keine Abwehrspannung, kein Peritonismus. Rege Darmgeräusche in allen Quadranten.


Sonographische Untersuchungen:

Schilddrüse
Beidseits normkonfigurierte Schilddrüse mit regulärem Organvolumen (rechter Schilddrüsenlappen: … Milliliter, linker Schilddrüsenlappen: … Milliliter). Homogene Parenchymstruktur ohne Anhalt für relevante Inhomogenitäten oder suspekte Knoten.
Isthmus regulär, ohne fokale Läsionen.
Keine vergrößerten zervikalen Lymphknoten; parathyreoidale Strukturen unauffällig.
Durchblutung regulär.
Epithelkörperchen beidseits normkonfiguriert darstellbar.

Carotisduplex
Regelrechte antegrade Strömungsverhältnisse in der Arteria carotis communis, Arteria carotis interna und Arteria carotis externa beidseits sowie in den Arteriae vertebrales.
Keine Plaquebildung in der Karotisbifurkation.
Keine Flussbeschleunigung, keine hämodynamisch relevante Stenose.
Die Intima-Media-Dicke liegt beidseits unter 1 Millimeter.

Orientierende Echokardiographie
Normale systolische Pumpfunktion des linken Ventrikels. Kein Hinweis auf eine diastolische Funktionsstörung bei regelrechtem E/A-Verhältnis.
Geringgradige Mitralklappeninsuffizienz (Grad I).
Normkonfigurierte Herzhöhlen, kein Hinweis auf Rechtsherzbelastung.
Keine höhergradige Trikuspidalinsuffizienz.
Septumdicke normal.
Kein Perikarderguss.
Trikuspide Aortenklappe ohne strukturelle Auffälligkeiten.

Herz subxiphoidal (Konvexschallkopf)
Visuell normale Pumpfunktion des linken Ventrikels; keine Wandbewegungsstörungen in den darstellbaren Segmenten.
Kein Perikarderguss.
Mitral- und Aortenklappe visuell unauffällig.
Vena cava inferior 1,9 Zentimeter weit, atemmodulatorisch komprimierbar.
Beidseits kein Pleuraerguss.

Leber
Regelrechte Größe und Konfiguration. Glatte, gleichmäßige Leberkapsel.
Leberunterrand spitzwinklig (< 45 Grad).
Parenchym homogen, altersentsprechend, mit regelrechter Echogenität im Vergleich zur Nierenrinde.
ALTERNATIV: Leber mit homogen verdichtetem Binnenreflexmuster im Sinne einer Steatosis hepatis Grad 1.
Kein Hinweis auf fokale Läsionen oder inhomogene Parenchymanteile.
ALTERNATIV: Fokale Minderzellverfettungen in der Fossa vesicae biliaris sowie periportal.
Lebervenen normal weit, regelrechter Venenstern ohne Stauungszeichen.
Lobus caudatus normal dimensioniert ohne Anzeichen einer portalen Hypertension.
Linker Leberlappen mit regelrechter kardial mitbewegter Konfigurationsänderung.

Gallenblase und Gallenwege
Dünnwandige, nicht überdistendierte Gallenblase ohne Sludge oder Cholezystolithiasis.
Intra- und extrahepatische Gallenwege nicht erweitert.
Ductus hepatocholedochus normweit (ca. 0,5 Zentimeter).
Kein Hinweis auf ein „Doppelflintenphänomen“.

Portalvenöses System
Regelrechte Weite der Pfortader mit typischer T-förmiger Aufzweigung.
Hepatopetaler, laminarer Fluss ohne Beschleunigung oder Flussumkehr.
Keine Hinweise auf Pfortaderthrombose oder portale Hypertension.

Vena cava inferior
Durchmesser ca. 2,1 Zentimeter, atemmodulatorisch variabel, kein Hinweis auf Stauung.

Lebersegmentbeurteilung (soweit darstellbar)
Segmente II und III homogen.
Segment IV unauffällig; Ligamentum teres hepatis echoreich und avaskulär.
Segment I (Lobus caudatus) regelrechte Begrenzung zur Vena cava inferior.
Segmente V–VIII homogen ohne subdiaphragmale oder randständige Läsionen.

Nieren
Linke Niere: Orthotope Lage, kein Harnstau, keine Nephrolithiasis, keine freie Flüssigkeit. Normales Verhältnis zwischen Parenchym und Nierenbecken.
Rechte Niere: Orthotope Lage, kein Harnstau, keine Nephrolithiasis, keine freie Flüssigkeit. Parenchym-Nierenbecken-Verhältnis regelrecht.
Doppler auf beiden Seiten:
– Spitzengeschwindigkeit 0,7–1,5 Meter pro Sekunde
– Resistance Index 0,50–0,75

Pankreas
Pankreaskopf vollständig, Pankreaskorpus teilweise darstellbar. Normale Organform und glatte Kontur.
Anteroposteriore Ausdehnung des Pankreaskopfes 2,5 Zentimeter.
Parenchym homogen ohne Läsionen, Zysten oder Verkalkungen.
Hauptgang nicht erweitert (< 2 Millimeter).
Keine vergrößerten regionären Lymphknoten.

Milz
Normal große, homogen echoreiche Milz ohne fokale Läsionen, Zysten oder Verkalkungen.

Darm
Orientierender Darmschall ohne Anhalt für entzündliche Veränderungen.
Colon descendens mit unauffälliger Wanddicke.

Abdominelle Gefäße
Aorta abdominalis ohne Hinweis auf Aneurysma, Dissektion oder Wandauffälligkeiten. Transversaler Durchmesser etwa 1,8 Zentimeter.
Truncus coeliacus und Arteria mesenterica superior ohne relevante Stenose; Spitzengeschwindigkeit unter 2 Metern pro Sekunde.

Urogenitaltrakt
Harnblase mit etwa 300–400 Millilitern Füllvolumen, glatte Wand ohne Polypen oder Verdickungen.
Prostata etwa 25 Milliliter ohne Verkalkungen oder Raumforderungen.
Kein Harnaufstau.
Excavatio rectovesicalis bzw. Excavatio rectouterina frei von Flüssigkeit.
Keine vergrößerten Lymphknoten.

Beckenarterien beidseits
Arteria iliaca communis und Arteria iliaca externa beidseits mit triphasischem Flussprofil ohne relevante Plaquebildung.


Funktionsuntersuchungen:

ABI - Knöchel-Arm-Index-Messung
Die Messung des Knöchel-Arm-Indexes (ABI) ergab unauffällige Werte: 
Erläuterung: 0,9 – 1,3: Normal, keine Hinweise auf arterielle Verschlusskrankheit.
Kein Anhalt für pathologische Veränderungen im Bereich der peripheren arteriellen Durchblutung.

Ergometrie:
Stufenweise lineare Belastung bis auf  Watt.
Unter der Belastung zeigte sich ein normaler Herzfrequenz- sowie Blutdruckanstieg sowie keine signifikanten ST-Streckenveränderungen oder Rhythmusstörungen. 
Der Abbruch der Belastung erfolgte wegen peripherer Erschöpfung und Erreichen der Ausbelastungsfrequenz.
In der Erholungsphase zeigte sich ein adäquater Puls- sowie Blutdruckabfall. 
Insgesamt zeigte sich in der Ergometrie kein Zeichen einer signifikanten myokardialen Ischämie. 

Lungenfunktion:
Hier zeigte sich kein Anhalt für eine relevante restriktive oder obstruktive Lungenerkrankung. 


In der heutigen Vorsorgeuntersuchung zeigten sich bzgl. der kardiovaskulären Risikofaktoren keine nennenswerten Auffälligkeiten. 

In der heutigen Vorsorgeuntersuchung zeigten sich die bekannten kardiovaskulären Risikofaktoren unter der etablierten Therapie gut kontrolliert.
Die Blutdruckwerte sind unter der etablierten antihypertensiven Therapie adäquat eingestellt. 
Unter der bestehenden Statintherapie sind die LDL-Cholesterinwerte im Zielbereich.

Auf eine Ergometrie wurde bei geringer Vortestwahrscheinlichkeit für das Vorliegen einer relevanten koronaren Herzkrankheit verzichtet. 
Das Ruhe-EKG zeigte soweit keine Auffälligkeiten und die durchgeführte Lungenfunktion zeigte kein Anhalt für das Vorliegen einer obstruktiven oder restriktiven Lungenerkrankung. 

Auf eine Ergometrie wurde bei insgesamt stabilem Gefäßstatus und mutmaßlich zu erwartender fehlender Erreichbarkeit der erforderlichen Belastungsfrequenz und somit fehlender Aussagekraft verzichtet. Das Ruhe-EKG zeigte soweit keine Auffälligkeiten und die im Anschluss an die Belastung durchgeführte Lungenfunktion zeigte keinen Anhalt für das Vorliegen einer obstruktiven oder restriktiven Lungenerkrankung. 

Im Carotisduplex sowie im Sono Abdomen stellten sich die einsehbaren Gefäße ohne nennenswerte makroangiopathische Veränderungen dar. Insbesondere die Carotiden zeigten keine relevanten Plaques. Die Ergometrie ergab unter adäquater Ausbelastung kein Anhalt für das Vorliegen einer relevanten koronaren Herzkrankheit und die im Anschluss an die Belastung durchgeführte Lungenfunktion zeigte keinen Anhalt für das Vorliegen einer obstruktiven oder restriktiven Lungenerkrankung. 

Laborchemisch zeigte sich eine Hypercholesterinämie, die in der Gesamtschau der Befunde aktuell lediglich mit diätetischen und körperlichen Maßnahmen zu behandeln ist. Aus primärprophylaktischen Erwägungen kann die Gabe eines Statins erwogen werden.

Zusammenfassung der Sonographie:
Schilddrüse: Beidseits normale Größe und Konfiguration ohne suspekte Knoten oder Inhomogenitäten. Unauffälliges Durchblutungsmuster.
Schilddrüse: Verkleinertes Volumen und heterogenes Binnenreflexmuster im Sinne einer Autoimmunthyreopathie.
Schilddrüse: Sonographisch Struma diffusa mit vereinzelten zystischen Veränderungen. / Struma multinodosa.
Carotis-Duplex: Normale Strömungsverhältnisse ohne höhergradige Plaquebildung oder relevante Stenosen in den einsehbaren Anteilen.
Echokardiographie: Normale linksventrikuläre Funktion, keine relevanten Klappenveränderungen oder sonstige strukturelle Auffälligkeiten.
Abdominale Organe: Leber, Gallenblase, Nieren, Pankreas und Milz soweit unauffällig, keine suspekten Raumforderungen.
Darm/Bauchraum: Keine entzündlichen Veränderungen, normale Darmwanddicke, keine interenteritische Flüssigkeit, peritoneale Umschlagfalten frei von Flüssigkeit.
Abdominelle Gefäße: Unauffällige Aorta, Truncus coeliacus und A. mesenterica superior ohne relevante Stenosen oder Anomalien.
Becken- und Beingefäße: Keine höhergradige Plaquebildung.
Über weiterführende Vorsorgeuntersuchungen wie Darmkrebsscreening, Hautkrebsscreening sowie gynäkologische bzw. urologische Untersuchungen wurde gesprochen. 
Eine erneute Vorsorgeuntersuchung in diesem Umfang empfehle ich nach 2 Jahren. 
