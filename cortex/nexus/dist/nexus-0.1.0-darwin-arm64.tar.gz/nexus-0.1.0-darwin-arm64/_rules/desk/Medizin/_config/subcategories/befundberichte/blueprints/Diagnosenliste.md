# Vorlage: Diagnosenliste

Diese Vorlage definiert Struktur, Sortierung und Formatierung von Diagnosenlisten für internistische Arztbriefe. Siehe MedReportRules.md Abschnitt 5.

---

## Sortierung (Priorität)

1. **Erste Priorität:** Herz-Kreislauf, Schrittmacher, Rhythmusstörungen, KHK, Klappen, Kardiomyopathien, periphere Gefäßerkrankungen, Tumorerkrankungen  
2. **Zweite Priorität:** Organinsuffizienzen, endokrinologische und Stoffwechselerkrankungen, weitere relevante Diagnosen  
3. **Dritte Priorität:** Risikofaktoren (cvRF), Begleiterkrankungen geringeren Schweregrades  

---

## Formatierung

- **Hauptdiagnosen** als Überschrift (ohne Bindestrich am Zeilenanfang)
- **Unterpunkte** mit Bindestrich (-) und Leerzeichen eingerückt
- Mehrere Ebenen möglich
- Datumsangaben: TT.MM.JJJJ
- Typische Formulierungen: Z.n., aktuell, persistierend, V.a.

---

## Textvorlage (zum Ausfüllen aus Input-Daten)

```
DIAGNOSEN:

[1. Priorität: Herz-Kreislauf / Schrittmacher / Rhythmusstörungen / Tumore]
[Hauptdiagnose – z. B. Z.n. Schrittmacherimplantation (Modell) am TT.MM.JJJJ bei …]
[- OAK mit …]
[- Z.n. … am TT.MM.JJJJ]
[- aktuelle Therapie seit TT.MM.JJJJ]

[Hauptdiagnose – z. B. Koronare Herzerkrankung]
[- Z.n. Bypassoperation JJJJ …]
[- Z.n. PTCA/DES … am TT.MM.JJJJ]
[- aktuell …]

[2. Priorität: Organinsuffizienzen / Endokrinologie / Stoffwechsel]
[Hauptdiagnose]
[- Unterpunkt mit Details, Therapie, Befund]

[3. Priorität: Risikofaktoren und Begleiterkrankungen]
cvRF: [z. B. Arterielle Hypertonie, Hyperlipidämie]
[Weitere Begleiterkrankungen]
```

---

## Hinweise

- Alle Inhalte ausschließlich aus Dokumenten im Input-Ordner übernehmen.
- Keine Beispieldiagnosen erfinden; bei fehlendem Input keine Datei im Output-Ordner anlegen.
- Bei Extraktion aus Befunden: nur valide, aus Befunden ableitbare Diagnosen (siehe MedReportRules.md Abschnitt 5.6).
- Automatische Extraktion: `python system/extract_diagnoses.py` (nutzt erste PDF/TXT aus Input).
