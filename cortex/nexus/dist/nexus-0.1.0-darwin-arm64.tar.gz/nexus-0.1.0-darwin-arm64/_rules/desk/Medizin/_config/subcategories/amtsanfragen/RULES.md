# Amtsanfragen — Medizin-spezifische Regeln

Diese Regeln ergänzen die gemeinsame Amtsanfragen-Basis (`_global/_shared_subcategories/amtsanfragen/RULES.md`) um medizinische Besonderheiten.

---

## 1. Typische Absender

| Absender | Typische Anfragen |
|---|---|
| Krankenkasse (AOK, TK, Barmer etc.) | Befundanfragen, Arbeitsunfähigkeit, Reha-Anträge |
| MDK / MD (Medizinischer Dienst) | Begutachtungsanfragen, Pflegegrad |
| Rentenversicherung (DRV) | Erwerbsminderung, Reha-Bedarf |
| Versorgungsamt | GdB-Feststellung, Verschlimmerungsanträge |
| Berufsgenossenschaft | Arbeitsunfall, Berufskrankheit |
| Gericht | Befundberichte für Gutachten |
| Andere Ärzte | Befundanfragen, Konsilanfragen |

---

## 2. Briefkopf und Unterschrift

**Briefkopf:**
```
Dr. med. Siegbert Stracke
Facharzt für Innere Medizin
Praxis Dr. Stracke und Kollegen
Grüneburgweg 12
60322 Frankfurt am Main
Tel.: 069 247574523
Fax: 069 97206408
E-Mail: praxis@westend-hausarzt.de
```

**Unterschriftszeile:**
```
Mit freundlichen Grüßen

Dr. med. Siegbert Stracke
Facharzt für Innere Medizin
```

---

## 3. Medizinische Stilregeln für Antwortbriefe

- **Fachsprache:** Medizinische Terminologie verwenden, aber verständlich für den jeweiligen Adressaten
  - An MDK/Ärzte: volle Fachsprache, ICD-Codes zulässig
  - An Krankenkasse/Gericht: Fachsprache mit Erklärungen bei komplexen Begriffen
  - An Versorgungsamt: Fokus auf funktionelle Einschränkungen, allgemeinverständlich
- **Diagnosen:** Nach Priorität sortiert (wie in Befundberichten, Abschnitt 5.1 der Befundbericht-Regeln)
- **Befunde:** Nur aus den beigefügten Beleg-Dokumenten, keine Erfindungen
- **Datenschutz:** Nur die für die Anfrage relevanten medizinischen Informationen mitteilen

---

## 4. Typische Antwort-Muster

### 4.1 Befundanfrage einer Krankenkasse

```
Bezug nehmend auf Ihre Anfrage vom [Datum] (Az.: [Aktenzeichen]) zu
[Patient, geb. am TT.MM.JJJJ] berichte ich wie folgt:

[Patient] befindet sich seit [Datum] in meiner hausärztlichen Behandlung.

[Antworten auf die einzelnen Fragen]

Diagnosen:
[Diagnosenliste]

Beigefügt übersende ich:
[Anlagen]
```

### 4.2 MDK-Anfrage

```
Bezug nehmend auf Ihre Anfrage vom [Datum] (Az.: [Aktenzeichen])
zur Begutachtung von [Patient, geb. am TT.MM.JJJJ] nehme ich wie folgt Stellung:

[Strukturierte Beantwortung der MDK-Fragen]
```

### 4.3 Befundbericht für Gericht / Versorgungsamt

```
Bezug nehmend auf Ihr Ersuchen vom [Datum] (Az.: [Aktenzeichen])
erstatte ich folgenden Befundbericht über [Patient, geb. am TT.MM.JJJJ]:

Anamnese:
[...]

Diagnosen:
[...]

Funktionelle Einschränkungen:
[...]

Therapie:
[...]
```

---

## 5. Besonderheiten

- **Schweigepflichtentbindung:** Prüfen, ob im Anfrage-Dokument eine Schweigepflichtentbindung des Patienten vorliegt oder ob darauf verwiesen wird. Falls nicht: im Antwort-Entwurf vermerken.
- **Formulare:** Manche Anfragen enthalten Formulare/Vordrucke, die ausgefüllt werden sollen. In diesem Fall: Felder identifizieren und befüllen.
- **ICD-Codes:** Bei Anfragen, die explizit ICD-Codes fordern, diese aus den Belegen extrahieren und mit angeben.

---

## 6. Fehlerprotokoll

Medizin-spezifische Fehler bei Amtsanfragen werden in dieser Datei oder in `Medizin/_config/FEHLERPROTOKOLL.md` dokumentiert.

---

## 7. Arztbrief-Gliederung (Pflicht für medizinische Amtsanfragen)

Medizinische Antworten an Behörden (Krankenkasse, MDK, DRV, Versorgungsamt, Gericht, BG, Knappschaft etc.) werden **immer** in Form eines strukturierten Arztbriefes verfasst — auch wenn die Anfrage nur Einzelfragen enthält. Die Beantwortung der Einzelfragen wird in die Arztbrief-Struktur eingebettet.

### 7.1 Struktur

```
[Briefkopf — §2]

[Absender der Anfrage]

                                                    Frankfurt am Main, den [Datum]

Ihr Zeichen: [Aktenzeichen]
Versicherungsnummer: [soweit angegeben]
Betreff: [Betreff aus der Anfrage]
Patient: [Name, Vorname, geb. TT.MM.JJJJ]

Sehr geehrte Damen und Herren,

Bezug nehmend auf Ihre Anfrage vom [Datum] berichte ich über den
o.g. Patienten, der sich seit [Datum] in meiner hausärztlichen Behandlung
befindet, wie folgt:

Anamnese
--------
[Eigenanamnese, Familienanamnese, Sozialanamnese, Vegetative Anamnese,
Medikamentenanamnese soweit aus Belegen bekannt; Verlauf der relevanten
Erkrankung(en); aktuelle Beschwerden]

Untersuchungsbefunde
--------------------
[Körperlicher Untersuchungsbefund; apparative Befunde (Labor, EKG,
Sonographie, Bildgebung etc.); Vorbefunde externer Behandler mit
Quellangabe (Datum, Absender)]

Diagnosen
---------
[Priorisierte Diagnosenliste, ICD-10 soweit aus Belegen ableitbar]

Epikrise / Beurteilung
----------------------
[Medizinische Bewertung des Verlaufs; Zusammenführung der Befunde;
funktionelle Einschränkungen; Einordnung im Kontext der Anfrage]

Beantwortung der Einzelfragen
-----------------------------
Zu Frage 1: [Antwort, gestützt auf Beleg X]
Zu Frage 2: [Antwort, gestützt auf Beleg Y]
[...]

Empfehlung / Therapie
---------------------
[Aktuelle Therapie; Empfehlungen bzgl. weiterer Diagnostik, Therapie,
Reha, AU, Pflegebedarf o.ä. — passend zum Anfragekontext]

Mit freundlichen Grüßen

[Unterschriftszeile — §2]

Anlagen:
- [Liste der beigefügten Belege mit Datum und Absender]
```

### 7.2 Regeln zur Arztbrief-Form

- **Vollständigkeit:** Alle fünf Kernabschnitte (Anamnese, Untersuchungsbefunde, Diagnosen, Epikrise, Empfehlung) sind obligatorisch. Fehlende Daten werden explizit als „aus den vorliegenden Unterlagen nicht ableitbar" gekennzeichnet — keine Erfindungen.
- **Einzelfragen-Integration:** Der Abschnitt „Beantwortung der Einzelfragen" bleibt als eigener Block erhalten, auch wenn Teilantworten bereits in Anamnese/Befunden/Epikrise enthalten sind. Dort wird dann auf die entsprechenden Abschnitte verwiesen („siehe Untersuchungsbefunde").
- **Quellenzuordnung:** Jeder Befund, der aus einem externen Beleg stammt, wird zugeordnet (z.B. „Sonographie Abdomen vom TT.MM.JJJJ, Radiologie X").
- **Priorisierung der Diagnosen:** Nach klinischer Relevanz für die Anfrage (vgl. Befundbericht-RULES §5.1).
- **Stil:** Fachsprache mit Erklärungen bei komplexen Begriffen für Nicht-Mediziner-Adressaten (Krankenkasse, Versorgungsamt, Gericht).
- **Länge:** So kurz wie möglich, so vollständig wie nötig. Kein Füllmaterial.

### 7.3 Adressat-spezifische Schwerpunkte

| Adressat | Fokus Anamnese | Fokus Befunde | Fokus Epikrise/Empfehlung |
|---|---|---|---|
| Krankenkasse (inkl. Knappschaft KV) | Behandlungsverlauf, AU-Zeiten | Belegende Befunde für Leistungsanspruch | Medizinische Notwendigkeit, Therapieplan |
| MDK/MD | Funktionseinschränkungen, ADL | Objektivierbare Befunde | Pflegebedarf, Begutachtungsfrage |
| DRV / Knappschaft-Bahn-See | Erwerbsbiografie-relevante Daten | Leistungseinschränkungen | Erwerbsfähigkeit, Reha-Empfehlung |
| Versorgungsamt | Funktionelle Einschränkungen im Alltag | GdB-relevante Befunde | Einordnung Versorgungsmedizinische Grundsätze |
| Gericht / BG | Kausalität, zeitlicher Verlauf | Belegkette | Gutachterliche Einordnung |

---

*Dieses Dokument wird laufend erweitert.*
