# OBLIGATORISCHE WORKFLOW-CHECKLISTE

**Diese Checkliste MUSS bei JEDER Erstellung befolgt werden.**

---

## PHASE 1: VORBEREITUNG

### Schritt 1: Aufgabentyp bestimmen (Abschnitt 16)
- [ ] Welcher Aufgabentyp? BEFUNDBERICHT / ZUSAMMENFASSUNG / ANAMNESE-ZUSAMMENFASSUNG
- [ ] Bei BEFUNDBERICHT: MedReportTemplate.md aus blueprints-Ordner lesen
- [ ] Bei ZUSAMMENFASSUNG oder ANAMNESE: Kein Template nötig

### Schritt 2: Fehlerprotokoll lesen (Abschnitt 17)
- [ ] FEHLERPROTOKOLL.md gelesen
- [ ] Alle dokumentierten Prüfpunkte für den aktuellen Fall notiert
- [ ] Insbesondere: Temporale Logik beachten (FP-001)

### Schritt 3: Input analysieren
- [ ] Input-Ordner geprüft (mindestens 2 Methoden: ls, find)
- [ ] Alle Dateien identifiziert und Text extrahiert
- [ ] Dokumentart validiert (Abschnitt 12): Befundbericht? Auftragsdokument?
- [ ] Bei mehreren Dokumenten: Chronologische Reihenfolge erstellt

### Schritt 4: Temporale Analyse (Abschnitt 15) — NUR bei mehreren Dokumenten aus verschiedenen Zeiträumen
- [ ] Dokumente chronologisch geordnet
- [ ] Befunde identifiziert, die sich zwischen den Dokumenten verändert haben
- [ ] Für jeden veränderten Befund: Aktuellen Status bestimmt
- [ ] Zuordnung festgelegt: Was gehört in Befundabschnitt vs. Anamnese vs. Diagnosen?

### Schritt 4b: Fremdbefund-Integration (Abschnitt 20, FP-004) — bei vorliegenden externen Fachbefunden
- [ ] Inventur: Welche externen Fachbefunde (Carotisduplex, Echokardiographie, CT/MRT, etc.) liegen im Input vor?
- [ ] Zuordnung: Welcher Template-Abschnitt wird durch welchen Fremdbefund gespeist?
- [ ] Bei mehreren Befunden pro Abschnitt: Neuester Befund identifiziert
- [ ] Konkrete Messwerte aus Fremdbefund extrahiert (EF, IVS, Gradient, IMD, Flussgeschwindigkeiten, Plaque-Lokalisation, etc.)
- [ ] Fremdbefund-Inhalt im Stil des Templates formuliert — KEINE Verweis-Formulierungen
- [ ] Quellenangabe (Datum + Institution) optional als einleitender Satz

---

## PHASE 2: ERSTELLUNG

### Für BEFUNDBERICHT (Template-First):

**Anamnese** — alle Unterpunkte:
- [ ] Haupttext (Belastbarkeit, B-Symptomatik, etc.)
- [ ] Vorerkrankungen und Vorgeschichte (HIER gehören historische Befunde und Interventionen hin)
- [ ] Nykturie
- [ ] Raucherstatus
- [ ] Allergien
- [ ] Vormedikation
- [ ] Vorsorgeuntersuchungen
- [ ] Impfstatus

**Klinische Untersuchung** — alle Unterpunkte:
- [ ] Allgemeinzustand (Alter, Ernährungszustand)
- [ ] Orientierende neurologische Untersuchung
- [ ] Psychischer Befund
- [ ] Kopf-Hals-Bereich
- [ ] Pulmo
- [ ] Cor
- [ ] Abdomen

**Sonographische Untersuchungen** — ALLE Unterabschnitte:
- [ ] Schilddrüse (inkl. Isthmus, Epithelkörperchen)
- [ ] Carotisduplex → **ACHTUNG FP-001: Nur AKTUELLEN Status beschreiben!**
- [ ] Orientierende Echokardiographie
- [ ] Herz subxiphoidal (Konvexschallkopf)
- [ ] Leber (inkl. Lebersegmentbeurteilung)
- [ ] Gallenblase und Gallenwege
- [ ] Portalvenöses System
- [ ] Vena cava inferior
- [ ] Nieren (inkl. Doppler)
- [ ] Pankreas
- [ ] Milz
- [ ] Darm
- [ ] Abdominelle Gefäße
- [ ] Urogenitaltrakt
- [ ] Beckenarterien beidseits

**Funktionsuntersuchungen:**
- [ ] EKG (falls durchgeführt)
- [ ] Ergometrie (falls durchgeführt, sonst Verzicht-Formulierung)
- [ ] Lungenfunktion (falls durchgeführt)
- [ ] ABI (falls durchgeführt)

**Labor:**
- [ ] Laborwerte aus allen Input-Dokumenten mit Datum

**Zusammenfassung / Beurteilung:**
- [ ] Reflektiert den AKTUELLEN Status (nicht historische Befunde)

**Procedere**

**Diagnosen:**
- [ ] Nach Priorität sortiert (Abschnitt 5.1)
- [ ] Volltext- und ICD-Suche durchgeführt (Abschnitt 5.7)
- [ ] Z.n. für abgeschlossene Interventionen verwendet

### Für ZUSAMMENFASSUNG:
- [ ] Sachliche Zusammenfassung der Befunde in zeitlicher Reihenfolge
- [ ] Diagnosenliste nach Priorität (Abschnitt 5.1–5.3)

### Für ANAMNESE-ZUSAMMENFASSUNG:
- [ ] Diagnosenliste (immer zuerst)
- [ ] Chronologische Vorgeschichte

---

## PHASE 3: QUALITÄTSSICHERUNG

### Schritt 5: Temporale Konsistenz prüfen (Abschnitt 15.6)
- [ ] Beschreiben Befundabschnitte den AKTUELLEN Status?
- [ ] Sind operierte/therapierte Befunde als Z.n. in den Diagnosen?
- [ ] Ist die Vorgeschichte in der Anamnese (nicht im Befundabschnitt)?
- [ ] Ist die Zusammenfassung konsistent mit dem aktuellen Status?

### Schritt 5b: Geschlechtsspezifische Terminologie prüfen (FP-003)
- [ ] Geschlecht des Patienten identifiziert?
- [ ] Excavatio: „rectovesicalis" (m) oder „rectouterina" (w) korrekt gewählt? → **NIEMALS „Douglas-Raum" bei männlichen Patienten**
- [ ] Urogenitaltrakt geschlechtsangepasst (Prostata nur m, Uterus/Ovarien nur w)?
- [ ] Alle anatomischen Bezeichnungen im gesamten Bericht auf Geschlechtskonformität geprüft?

### Schritt 5c: Sektionsbezogene Befund-Integration prüfen (Abschnitt 21)
- [ ] Für jede Diagnose aus der Diagnosenliste: Ist sie auch im anatomisch-funktionellen Setting der zugehörigen Template-Sektion beschrieben? (z.B. Steatosis hepatis in Sono → Leber)
- [ ] Widerspricht eine Sektion ihrer eigenen Diagnose? (z.B. Sektion sagt „Leber unauffällig", Diagnose nennt Steatosis)
- [ ] Bei Sektionen ohne pathologischen Input (gar nichts / nur unauffälliger / nur Ausschluss-Formulierung): Vollständiger Normalbefund aus Template eingesetzt?
- [ ] Keine verknappten Platzhalter-Sätze wie „Leber unauffällig" anstelle des ausformulierten Normalbefundes?

### Schritt 6: Validierung
- [ ] Bei BEFUNDBERICHT: `python system/validate_report.py Output/<datei>.txt` ausführen
- [ ] Alle Fehler beheben
- [ ] Keine Meta-Kommentare vorhanden?
- [ ] Stil konsistent mit Dr. Stracke?
- [ ] Zahlen und Einheiten korrekt (Dezimal-Komma)?
- [ ] Keine Redundanzen?
- [ ] Keine erfundenen Daten?

### Schritt 7: Fehlerprotokoll-Abgleich
- [ ] Erstelltes Dokument gegen häufigste Fehlermuster aus FEHLERPROTOKOLL.md geprüft
- [ ] Bei neu erkannten Fehlern: FEHLERPROTOKOLL.md ergänzen

---

## WICHTIGE REGELN (Kurzfassung)

1. **NIEMALS** Abschnitte weglassen
2. **IMMER** Template-Normalbefunde verwenden wenn keine Input-Daten vorliegen
3. **NIEMALS** historische Befunde als aktuelle Befunde darstellen (FP-001)
4. **NIEMALS** Meta-Kommentare einfügen
5. **IMMER** vor dem Speichern validieren
6. **IMMER** Fehlerprotokoll vor Erstellung lesen
7. **NIEMALS** Daten erfinden
