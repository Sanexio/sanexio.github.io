# MedReportRules - Spezifische Arztbrief-Regeln

Dieses Dokument bündelt alle Regeln für die Erstellung und Anpassung internistischer Arztbriefe (z. B. für Dr. med. Siegbert Stracke).

Ziel:
- Konsistente, professionelle Arztbriefe in einheitlichem Stil.
- Texte sollen so wirken, als seien sie vollständig vom behandelnden Arzt selbst verfasst.
- Das Regelwerk wird laufend erweitert („lebendes Dokument“).

---

## 1. Allgemeine Stilregeln

**KRITISCH - OBLIGATORISCHER ERSTER SCHRITT BEI JEDER ANFRAGE:**
- **IMMER zuerst den Input-Ordner prüfen:** Bei JEDER Anfrage MUSS zuerst der Input-Ordner geprüft werden, um die zu verarbeitenden Dokumente zu identifizieren.
- **NUR Dokumente aus dem Input-Ordner verwenden:** Alle Informationen, Diagnosen, Befunde und Daten stammen AUSSCHLIESSLICH aus den Dokumenten im Input-Ordner.
- **Keine Beispiel-Daten:** Niemals generische Beispiele, Beispiel-Diagnosen oder fiktive Daten verwenden. Alle Inhalte müssen aus den tatsächlichen Input-Dateien stammen.
- **Dokumente verarbeiten:** PDF-Dateien, Textdateien, Bilder (JPG, PNG) und andere Dokumente im Input-Ordner müssen mit entsprechenden Methoden (OCR, Text-Extraktion) verarbeitet werden.
- **KEINE ERFINDUNGEN - Rückmeldung bei Problemen:** Wenn keine Daten im Input-Ordner vorhanden sind oder die Daten nicht verarbeitet werden können, um die Anfrage zu beantworten, MUSS eine klare Rückmeldung gegeben werden, was nicht funktioniert. NIEMALS einfach etwas erfinden, Beispiel-Daten verwenden oder fiktive Inhalte erstellen. Stattdessen: Benutzer informieren über fehlende Dateien, OCR-Probleme, unlesbare Dokumente oder andere Hindernisse.

- Sprache: Deutsch, fachlich präzise, internistische Befundsprache.
- Ton: sachlich, ruhig, klinisch, ohne Polemik oder Umgangssprache.
- Zeitform:
  - Befunde meist im Präsens („zeigt sich“, „besteht kein Anhalt für …“).
  - Vorgeschichte/Anamnese ggf. im Perfekt/Präteritum („hat berichtet“, „bestand“).
- Keine Meta-Kommentare:
  - Kein Hinweis darauf, dass der Text überarbeitet, angepasst oder von einer KI erstellt wurde.
  - Keine Formulierungen wie „im obigen Text“, „die Vorlage“, „dieser Text wurde modifiziert“.
- Kein Erklären des eigenen Vorgehens:
  - Ausgabe soll direkt in den Arztbrief kopiert werden können.

---

## 2. Strukturelle Vorgaben

Typische Gliederung eines internistischen Arztbriefs (anpassbar je nach Fall):

1. **Anamnese**
2. **Vorerkrankungen / Vorgeschichte** (falls relevant)
3. **Medikation / Allergien** (falls gewünscht)
4. **Klinische Untersuchung**
5. **Apparative Diagnostik**
   - Sonographische Untersuchung (Schilddrüse, Abdomen etc.)
   - EKG / Lufu / Ergometrie je nach Fall
6. **Zusammenfassung / Beurteilung**
7. **Empfehlung / Procedere**

Die Überschriften sollen kurz, klar und im Stil der bestehenden Briefe gehalten werden.

---

## 3. Konkrete Formulierungsregeln

- Positivbefunde klar benennen, unauffällige Befunde knapp halten:
  - „Leber mit homogenem Binnenreflexmuster, kein Anhalt für fokale Läsionen.“
  - „Im Carotisduplex kein Anhalt für hämodynamisch relevante Stenosen.“
- Übliche Phrasen:
  - „kein Anhalt für …“
  - „soweit einsehbar …“
  - „orthotop“
  - „regelrechte Strömungsverhältnisse“
  - „homogene Binnenreflexstruktur“
- Redundanzen vermeiden:
  - Keine mehrfachen Wiederholungen derselben Information in derselben Passage.
- Zahlen und Einheiten:
  - Metrisch, z. B. „0,5 cm“, „1,9 cm“, „0,7–1,5 m/s“.
  - Dezimal-Komma (deutscher Standard).

---

## 4. Umgang mit Vorgaben des Benutzers

- **„1:1 übernehmen und syntaktisch/semantisch anpassen"**
  - Inhalt erhalten.
  - Orthographie, Grammatik, Satzbau und Lesbarkeit verbessern.
  - Offensichtliche Doppelungen moderat reduzieren.
- **„Ausführlicher formulieren"**
  - Kontext und klinische Bedeutung besser herausarbeiten.
  - Logische Übergänge ergänzen.
  - Keine neuen Fakten erfinden.
- **„An PDF-Vorlage anpassen"**
  - Wortwahl, Rhythmus und Struktur der vorhandenen Arztbriefe nachahmen.
  - Auf typische Phrasen und Reihenfolge der Befunde achten.
- **Vollständige Template-Übernahme:**
  - **WICHTIG:** Der komplette Text aus dem Template (MedReportTemplate.md) wird immer übernommen.
  - Wenn keine spezifischen Informationen zu bestimmten Abschnitten vorhanden sind, werden die Normalbefunde aus dem Template verwendet.
  - Die gegebenen Input-Informationen werden entsprechend in den Brief eingefügt und angepasst.
  - Alle anderen Abschnitte spiegeln die Normalbefunde aus dem Template wider.
  - Dies gewährleistet vollständige und konsistente Arztbriefe mit allen Standardabschnitten.

- **Befundbericht: Template-First-Ansatz (alte Befunde in neues Template überführen):**
  - **Basis ist immer das MedReportTemplate.md** – nicht der Input-Befundbericht. Der Input liefert nur die Rohdaten.
  - **Arbeitsweise:** Jeden Abschnitt und Unterabschnitt des Templates der Reihe nach durchgehen. Den Template-Text als Grundlage nehmen und dort, wo der Input konkrete Befunde liefert, diese in den Stil des Template-Abschnitts überführen (nicht einfach abkopieren).
  - **Input-Befunde einspeisen:** Wo der Input konkrete Untersuchungsergebnisse hat (z. B. „Knoten TIRADS 2–3“, „geringe Plaquebildung“, „Nierenzysten BOSNIAK II–IIF“), werden diese in die Formulierung des entsprechenden Template-Abschnitts integriert. Die Template-Struktur (alle Sätze, alle Unterpunkte) bleibt erhalten.
  - **Fehlende Input-Daten → Normalbefund aus Template:** Wenn der Input zu einem Unterabschnitt nichts liefert (z. B. Isthmus Schilddrüse, Epithelkörperchen, Lebersegmentbeurteilung, Doppler Nieren, Excavatio rectovesicalis, Beckenarterien), wird der **vollständige Normalbefund-Text aus dem Template** übernommen. Es dürfen keine Abschnitte weggelassen werden.
  - **Keine Meta-Kommentare:** Formulierungen wie „(In den Unterlagen nicht durchgeführt)“, „(nicht spezifiziert)“, „(nicht gesondert beschrieben)“ sind verboten. Stattdessen: Entweder Input-Daten einbauen oder Template-Normalbefund verwenden. Bei nicht durchgeführten Untersuchungen (z. B. Ergometrie, Lufu) die Verzicht-Formulierungen aus dem Template-Zusammenfassungsteil nutzen (z. B. „Auf eine Ergometrie wurde bei … verzichtet. Das Ruhe-EKG zeigte soweit keine Auffälligkeiten …“).
  - **Reihenfolge und Gliederung:** Die exakte Reihenfolge der Abschnitte und Unterabschnitte des Templates muss eingehalten werden. Keine Zusammenfassung oder Umstellung von Abschnitten (z. B. „Orientierende Echokardiographie“ und „Herz subxiphoidal“ müssen getrennt bleiben).
  - **Mehrere Input-Dokumente:** Werden mehrere Dokumente (PDF, TXT, Bilder) in den Input-Ordner hochgeladen, muss der Befundbericht entsprechend aller verfügbaren Informationen erstellt werden. Sämtliche Inhalte aus allen im Input-Ordner abgelegten Dokumenten fließen in den Befundbericht ein. Die Dokumente werden vollständig ausgewertet; Befunde, Anamnese und Diagnosen werden zusammengeführt und priorisiert (ohne Redundanzen, chronologisch sinnvoll). Kein verarbeitbares Dokument darf ignoriert werden. Dokumente, die nicht verarbeitet werden können (z. B. gescannte PDFs ohne verfügbare OCR-Tools), sind dem Benutzer gesondert mitzuteilen.
  
  **OBLIGATORISCHE CHECKLISTE VOR JEDER ERSTELLUNG:**
  - [ ] Template vollständig gelesen und alle Abschnitte identifiziert
  - [ ] Anamnese mit allen Unterpunkten (Raucherstatus, Allergien, Vormedikation, Vorsorgeuntersuchungen, Impfstatus)
  - [ ] Klinische Untersuchung mit allen Unterpunkten (neurologisch, psychisch, Kopf-Hals, Pulmo, Cor, Abdomen)
  - [ ] Sonographische Untersuchungen mit ALLEN Unterabschnitten aus dem Template
  - [ ] Funktionsuntersuchungen (Ergometrie, Lungenfunktion)
  - [ ] Zusammenfassung / Beurteilung
  - [ ] Procedere
  - [ ] Validierung durchgeführt (alle Abschnitte vorhanden)

---

## 5. Diagnosenlisten

### 5.1 Sortierung und Priorisierung

Diagnosenlisten werden nach klinischer Wichtigkeit und Schweregrad sortiert:

1. **Erste Priorität:** Herz-Kreislauf-Erkrankungen und Tumorerkrankungen stehen immer an oberster Stelle
   - Schrittmacher-Implantationen und Rhythmusstörungen
   - Koronare Herzerkrankung (KHK) mit allen Interventionen
   - Klappenerkrankungen
   - Kardiomyopathien
   - Periphere Gefäßerkrankungen
   - Tumorerkrankungen (falls vorhanden)

2. **Zweite Priorität:** Andere internistische Erkrankungen nach Schweregrad
   - Organinsuffizienzen (z. B. Niereninsuffizienz)
   - Endokrinologische Erkrankungen
   - Stoffwechselerkrankungen
   - Weitere relevante Diagnosen

3. **Dritte Priorität:** Risikofaktoren und Begleiterkrankungen
   - Risikofaktoren (z. B. "cvRF: Arterielle Hypertonie, Hyperlipidämie")
   - Begleiterkrankungen geringeren Schweregrades

### 5.2 Ausführlichkeit und Detaillierungsgrad

Diagnosen werden im Sinne eines internistischen Arztbriefes sehr ausführlich dargestellt:

- **Chronologische Informationen:**
  - Datum von Interventionen (z. B. "am 05.09.2025")
  - Zeitpunkt von Therapiebeginn (z. B. "seit 15.09.2025")
  - Historische Entwicklung (z. B. "Z.n. Bypassoperation 2013")

- **Technische Details:**
  - Gerätetypen und Modelle (z. B. "Medtronic Astra XT DR MRI")
  - Größenangaben (z. B. "34 mm Evolut PRO plus-Klappe")
  - Verfahrensdetails (z. B. "PTCA/DES-Implantation")

- **Aktuelle Therapien:**
  - Medikamentöse Therapien mit Dosierung (z. B. "OAK mit Apixaban")
  - Aktuelle medikamentöse Einstellung (z. B. "antiarrhythmische Therapie mit Amiodaron seit 15.09.2025")

- **Aktuelle Befunde:**
  - Gegenwärtiger Zustand (z. B. "aktuell leicht eingeschränkte LV-Funktion")
  - Verlaufstendenzen (z. B. "gleichbleibend", "rückläufig")
  - Aktuelle Schweregrade (z. B. "mittelgradige Mitralklappeninsuffizienz")

- **Zustandsbeschreibungen:**
  - Verbleibende Befunde nach Interventionen (z. B. "verbliebener dünner Plastikkonnektionsschlauch")
  - Interventionsergebnisse (z. B. "gutes Interventionsergebnis", "erfolgreiche elektrische Kardioversion")

### 5.3 Strukturierung und Formatierung

- **Hauptdiagnosen** werden als Überschrift formuliert (fett oder hervorgehoben)
- **Unterpunkte** werden mit Bindestrich (-) eingerückt dargestellt
- **Mehrere Ebenen** sind möglich (Hauptdiagnose → Unterpunkt → weiterer Unterpunkt)
- Jede relevante Information wird als eigener Unterpunkt aufgeführt
- Logische Gruppierung verwandter Informationen unter einer Hauptdiagnose

### 5.4 Typische Formulierungen

- "Z.n." (Zustand nach) für abgeschlossene Interventionen
- "aktuell" für gegenwärtige Befunde und Zustände
- "persistierend" für fortbestehende Erkrankungen
- "V.a." (Verdacht auf) bei ungesicherten Diagnosen
- Präzise medizinische Terminologie entsprechend internistischem Standard
- Datumsangaben im Format "TT.MM.JJJJ"

### 5.5 Beispiel-Struktur

```
DIAGNOSEN:

Z.n. 2-Kammer-Herzschrittmacherimplantation (Medtronic Astra XT DR MRI) am 05.09.2025 bei AV-Block 3. Grades
Persistierendes Vorhofflimmern
- OAK mit Apixaban
- Z.n. Pulmonalvenenisolation am 08.08.2025
- Z.n. erfolgreicher elektrischer Kardioversion am 25.08.2025
- antiarrhythmische Therapie mit Amiodaron seit 15.09.2025
Koronare Herzerkrankung
- Z.n. Bypassoperation 2013 (IMA-RIA, ACVB-RD, ACVB-RPLS; ACVB-RCA)
- RCA und RPLS Verschluss
- Z.n. PTCA/DES-Implantation des proximalen RIA am 07.10.2024
- RIA Verschluss im mittleren Drittel, offener IMA-Bypass
Chronische Niereninsuffizienz
- V.a. sekundärer Hyperparathyreoidismus
cvRF: Arterielle Hypertonie, Hyperlipidämie
```

### 5.6 Ableitung von Diagnosen aus klinischen Befunden

Wenn klinische Befunde gegeben werden, sollen daraus **valide medizinische Diagnosen** für einen Arztbrief erstellt werden.

**Grundsätze:**

1. **Medizinische Validität:**
   - Diagnosen müssen korrekt aus den gegebenen Befunden abgeleitet werden
   - Nur gesicherte oder hinreichend wahrscheinliche Diagnosen formulieren
   - Bei Unsicherheit "V.a." (Verdacht auf) verwenden
   - Keine Spekulationen oder nicht belegbare Diagnosen erstellen

2. **Klinische Relevanz:**
   - Fokus auf medizinisch relevante Diagnosen
   - Unterscheidung zwischen Befunden und Diagnosen
   - Befunde beschreiben objektive Untersuchungsergebnisse
   - Diagnosen sind medizinische Interpretationen der Befunde

3. **Beispiele für die Ableitung:**
   - **Befund:** "Steatosis hepatis Grad 1" → **Diagnose:** "Steatosis hepatis Grad 1"
   - **Befund:** "Schilddrüsenknoten beidseits, TIRADS 1-2" → **Diagnose:** "Schilddrüsenknoten beidseits" (mit TIRADS-Klassifikation als Detail)
   - **Befund:** "Gallenblasenstein im Infundibulum, 1,7 cm" → **Diagnose:** "Cholelithiasis"
   - **Befund:** "Prostata 40 ml, echogene Spots" → **Diagnose:** "Benigne Prostatahyperplasie, Z.n. Prostatitis"
   - **Befund:** "Nierencyste links, unterer Pol" → **Diagnose:** "Nierencyste links" (nur wenn klinisch relevant)

4. **Priorisierung:**
   - Diagnosen nach Abschnitt 5.1 sortieren
   - Schweregrad und klinische Relevanz berücksichtigen
   - Risikofaktoren gesondert aufführen

5. **Formatierung:**
   - Diagnosen gemäß Abschnitt 5.3 strukturieren
   - Relevante Details als Unterpunkte aufführen
   - Präzise medizinische Terminologie verwenden

**Wichtig:** Die Diagnosenliste soll für einen Arztbrief geeignet sein und alle relevanten medizinischen Informationen enthalten, die aus den gegebenen Befunden abgeleitet werden können.

### 5.7 Obligatorische Volltext-Suche nach Diagnosen (ICD-relevant und medizinisch)

**KRITISCH – gilt für jede Diagnosenextraktion und jede Diagnosenliste:**

1. **Gesamte Unterlagen durchsuchen**
   - Es wird **niemals** nur ein Abschnitt mit der Überschrift „Diagnosen“ oder „ICD“ ausgewertet.
   - **Der gesamte Text** aller zu verarbeitenden Unterlagen (jede Seite, jeder Abschnitt, Fließtext, Listen, Befunde, Anamnese, Epikrise, Entlassungsbrief etc.) wird nach ICD-relevanten und medizinischen Diagnosen durchsucht.

2. **ICD-relevante Treffer**
   - Alle **ICD-10-Codes** (z. B. E11.9, I25.1, K76.0, R50.9, Z95.1) im Dokument werden erfasst.
   - Zu jedem Code wird der zugehörige Text (Zeile oder Kontext) als Diagnose übernommen; fehlt Text, wird der Code mit Standardbezeichnung (falls bekannt) oder als Code aufgeführt.
   - Auch Codes in Klammern, Tabellen, Fußzeilen und Anhängen zählen.

3. **Medizinische Diagnosebegriffe im Fließtext**
   - Der Volltext wird nach typischen **Diagnoseformulierungen** durchsucht, z. B.:
     - „Z.n.“, „Status nach“, „Zustand nach“
     - „V.a.“, „Verdacht auf“, „V. a.“
     - „chronische …“, „akute …“, „persistierende …“
     - Explizite Erkrankungsnamen (z. B. KHK, Vorhofflimmern, Hypertonie, Diabetes, Niereninsuffizienz, Steatosis hepatis, Cholelithiasis, COPD, Asthma, Anämie, Hyperlipidämie, Hepatitis, Arthrose, Depression)
     - Befundformulierungen, die einer Diagnose entsprechen (gemäß 5.6)
   - Jede Zeile bzw. jeder Satz, der einen solchen Begriff oder eine solche Formulierung enthält, wird als Kandidat für die Diagnosenliste geprüft und bei Relevanz aufgenommen.

4. **Mehrere Dateien**
   - Liegen im Input-Ordner **mehrere Unterlagen** (PDF, TXT), werden **alle** durchsucht; die gefundenen Diagnosen werden zusammengeführt, doppelt vorkommende bereinigt und priorisiert (5.1).

5. **Umsetzung im Skript**
   - Das Skript `system/extract_diagnoses.py` muss diese Volltext- und ICD-Suche implementieren (nicht nur einen „Diagnosen“-Abschnitt). Die Ausgabe ist eine einheitliche, priorisierte Diagnosenliste gemäß 5.1–5.3.

---

## 6. Erweiterbare Regeln („Regel-Logbuch")

Hier werden neue Regeln ergänzt, sobald sich bei der praktischen Nutzung Bedarf ergibt.

Beispiel-Format:

- **[2025-11-21] Neue Regel:** Bei Sonographie der Schilddrüse immer Volumen beider Lappen angeben, soweit verfügbar, und TIRADS-Klassifikation der Indexknoten benennen.
- **[2025-11-21] Neue Regel:** In der Zusammenfassung immer kurz Bezug auf relevante Vorerkrankungen (z. B. Apoplex, KHK-Risiko) nehmen.
- **[2025-01-XX] Neue Regel:** Wenn klinische Befunde gegeben werden, sollen daraus valide medizinische Diagnosen für einen Arztbrief erstellt werden. Die Diagnosen müssen medizinisch korrekt aus den Befunden abgeleitet werden und für die Verwendung in einem Arztbrief geeignet sein. Siehe auch Abschnitt 5.6 für detaillierte Anleitung.
- **[2025-01-XX] Neue Regel:** Bei medizinischen Vorunterlagen (z. B. Arztbriefe, Befunde, Untersuchungen) aus dem Input-Ordner wird eine komplette, relevante Zusammenfassung der Informationen in strukturierter Art erstellt. Die Zusammenfassung besteht aus zwei Hauptabschnitten: (1) Diagnosenliste (nach Priorität sortiert) und (2) chronologische Vorgeschichte. Siehe Abschnitt 10 für detaillierte Anleitung zur Erstellung strukturierter medizinischer Vorgeschichte aus Vorbefunden.
- **[2025-01-XX] Neue Regel:** Bei Befundberichten im Input-Ordner kann eine Zusammenfassung erstellt werden, die sich von der vollständigen Befundbericht-Erstellung nach Template unterscheidet. Die Zusammenfassung erfolgt im Sinne eines Arztbriefes mit sachlicher Auflistung der relevanten Befunde in zeitlicher Reihenfolge und anschließender Diagnosenliste. Der Benutzer unterscheidet explizit zwischen "Befundbericht erstellen" (mit Template) und "Zusammenfassung erstellen" (nach Abschnitt 11). Siehe Abschnitt 11 für detaillierte Anleitung.
- **[2025-12-23] Neue Regel:** Vor der Erstellung einer Zusammenfassung oder eines Befundberichts MUSS die Dokumentart der Input-Datei identifiziert und validiert werden. Auftragsdokumente (z.B. Gutachtenaufträge, Formulare S0080) dürfen NICHT als Befundberichte behandelt werden. Siehe Abschnitt 12 für detaillierte Anleitung zur Dokumentart-Erkennung.
- **[2025-12-23] Neue Regel:** Bei jedem Neustart des Programms oder Beginn einer neuen Sitzung MÜSSEN alle vorherigen Chat-Verläufe und Kontextinformationen gelöscht werden, um Verwechslungen und falsche Interpretationen zu vermeiden. Jede neue Aufgabe wird ohne Bezug zu vorherigen Aufgaben bearbeitet.
- **[2026-02-12] Neue Regel:** **Ausgaben immer im Output-Ordner:** Alle erstellten Dateien (Diagnosenlisten, Zusammenfassungen, Befundberichte, extrahierter OCR-Text) werden wie immer im Output-Ordner des Workspaces abgelegt, standardmäßig als .txt. Keine Ausgabe in anderen Ordnern; Pfad ist stets der Workspace-Ordner „Output“ (absolut).
- **[2026-02-12] Neue Regel:** Bei JEDER Anfrage MUSS zuerst der Input-Ordner geprüft werden. Alle Informationen, Diagnosen, Befunde und Daten stammen AUSSCHLIESSLICH aus den Dokumenten im Input-Ordner. Niemals generische Beispiele, Beispiel-Diagnosen oder fiktive Daten verwenden. PDF-Dateien, Textdateien, Bilder (JPG, PNG) und andere Dokumente im Input-Ordner müssen mit entsprechenden Methoden (OCR, Text-Extraktion) verarbeitet werden.
- **[2026-02-12] Neue Regel:** Wenn keine Daten im Input-Ordner vorhanden sind oder die Daten nicht verarbeitet werden können, um die Anfrage zu beantworten, MUSS eine klare Rückmeldung gegeben werden, was nicht funktioniert. NIEMALS einfach etwas erfinden, Beispiel-Daten verwenden oder fiktive Inhalte erstellen. Stattdessen: Benutzer informieren über fehlende Dateien, OCR-Probleme, unlesbare Dokumente oder andere Hindernisse.
- **[2026-02-12] Neue Regel:** Wenn keine Informationen im Input-Ordner vorhanden sind oder die benötigten Informationen (z.B. Anamnese-Daten) in den Input-Dateien fehlen, MUSS eine Fehlermeldung ausgegeben werden, die klar angibt, dass im Input-Ordner keine Informationen vorliegen. In diesem Fall darf KEINE Datei im Output-Ordner erstellt werden. Die Fehlermeldung soll präzise beschreiben, welche Informationen fehlen.
- **[2026-02-17] Neue Regel:** **OBLIGATORISCHE INPUT-ORDNER-PRÜFUNG:** Bei JEDER Anfrage zur Erstellung eines Befundberichts, einer Zusammenfassung oder zur Verarbeitung von Dokumenten MUSS der Input-Ordner IMMER zuerst geprüft werden. Verwende `_lib/extract/universal_extract.py` für die Erkennung und Extraktion aller Dateien im Input-Ordner. Der vollständige Pfad zum Input-Ordner muss verwendet werden. Diese Regel verhindert, dass vorhandene PDFs oder andere Dateien übersehen werden.
- **[2026-02-17] Neue Regel:** **ERWARTUNG VON INPUT-DATEIEN:** Bei einer Anfrage zur Erstellung eines Befundberichts oder zur Bearbeitung von Dokumenten ist IMMER davon auszugehen, dass eine Datei im Input-Ordner vorhanden ist, die bearbeitet werden muss. Das universal_extract.py erkennt automatisch alle verfügbaren Dateien. Die Bearbeitung darf nur dann abgebrochen werden, wenn nach Extraktion definitiv keine Dateien gefunden werden können.
- **[2026-02-23] Neue Regel:** **DIAGNOSENLISTE – VOLLTEXT- UND ICD-SUCHE:** Alle Unterlagen werden nach ICD-relevanten und medizinischen Diagnosen durchsucht, nicht nur ein Abschnitt „Diagnosen“. Es gilt: (1) Gesamter Text jeder Datei durchsuchen, (2) alle ICD-10-Codes erfassen, (3) typische Diagnoseformulierungen (Z.n., V.a., Erkrankungsnamen) im Fließtext suchen, (4) bei mehreren Dateien im Input alle verarbeiten und Diagnosen zusammenführen. Siehe Abschnitt 5.7 und 9.
- **[2026-03-03] Neue Regel:** **BEFUNDBERICHT – TEMPLATE-FIRST-ANSATZ:** Bei der Erstellung eines Befundberichts ist das MedReportTemplate.md die Basis, nicht der Input-Befundbericht. Alte Befunde aus dem Input werden in die Template-Struktur überführt: Jeden Template-Abschnitt der Reihe nach durchgehen, Input-Befunde dort einspeisen, wo vorhanden; fehlende Input-Daten durch Template-Normalbefunde ersetzen. Keine Meta-Kommentare wie „(nicht durchgeführt)“ oder „(nicht spezifiziert)“. Alle Unterabschnitte des Templates (z. B. Lebersegmentbeurteilung, Doppler Nieren, Epithelkörperchen, Beckenarterien) müssen enthalten sein. Siehe Abschnitt 4 „Befundbericht: Template-First-Ansatz“.
- **[2026-03-06] Neue Regel:** **MEHRERE INPUT-DOKUMENTE:** Werden mehrere Dokumente (PDF, TXT, Bilder) in den Input-Ordner hochgeladen, muss der Befundbericht entsprechend aller Informationen erstellt werden. Sämtliche Informationen aus allen im Input-Ordner abgelegten Dokumenten fließen in den Befundbericht ein – gemäß Template-Struktur, Formulierungsregeln und Befundbericht-Vorgaben. Die Dokumente werden vollständig ausgewertet; Befunde, Anamnese und Diagnosen werden zusammengeführt und priorisiert (ohne Redundanzen, chronologisch sinnvoll). Kein Dokument darf ignoriert werden.
- **[2026-03-06] Neue Regel:** **NIEMALS ERGÄNZENDE QUELLEN VERWENDEN:** Wenn die Dokumente im Input-Ordner nicht verarbeitet werden können (z.B. gescannte PDFs ohne OCR, leerer Text), darf NIEMALS eine Datei aus einem anderen Ordner (Projekt-Root, temp_*, Output, etc.) als Ersatz verwendet werden. Insbesondere darf temp_extracted.txt, temp_output.txt oder ähnliche Dateien NICHT in den Input kopiert oder als Datenquelle genutzt werden – sie können von einem völlig anderen Dokument/Patienten stammen. Stattdessen: Klare Fehlermeldung ausgeben, keine Output-Datei erstellen.
- **[2026-02-19 / 2026-03-21 aktualisiert] Neue Regel:** **ROBUSTE INPUT-DATEI-ERKENNUNG:** Für die Erkennung und Extraktion von Input-Dateien wird `_lib/extract/universal_extract.py` verwendet. Dieses Tool erkennt automatisch die beste verfügbare Methode (pdfplumber, OCR via tesseract, pdftotext CLI-Fallback), cached Ergebnisse und funktioniert in allen Umgebungen. Es dürfen KEINE neuen Inline-Extraktionsskripte geschrieben werden. Verbesserungen gehören in `_lib/extract/universal_extract.py`. Siehe Abschnitt 14.

- **[2026-03-18] Neue Regel (FP-001):** **TEMPORALE LOGIK – BEFUNDAKTUALITÄT:** Wenn mehrere Input-Dokumente aus verschiedenen Zeiträumen vorliegen, MUSS vor der Erstellung eine chronologische Analyse erfolgen. Befundabschnitte (Sonographie, Klinische Untersuchung) beschreiben IMMER den AKTUELLEN Zustand – nicht historische Zustände. Wenn ein Befund durch eine Intervention beseitigt wurde (z.B. Stenose operiert), darf dieser im Befundabschnitt NICHT mehr als aktueller Befund beschrieben werden. Stattdessen: Post-OP Status im Befundabschnitt, Vorgeschichte/OP in der Anamnese, „Z.n.” in den Diagnosen. Siehe Abschnitt 15 für vollständige Regeln und Beispiele.
- **[2026-03-18] Neue Regel (FP-001):** **FEHLERPROTOKOLL LESEN:** Vor jeder Erstellung MUSS das FEHLERPROTOKOLL.md gelesen werden. Alle dort dokumentierten Prüfpunkte sind auf den aktuellen Fall anzuwenden. Bei Benutzerkorrekturen wird der Fehler protokolliert und eine Regel abgeleitet. Siehe Abschnitt 17.
- **[2026-03-18] Neue Regel:** **AUFGABENTYPEN-MATRIX:** Es gibt drei klar definierte Aufgabentypen: BEFUNDBERICHT (mit Template), ZUSAMMENFASSUNG (ohne Template, Befunde + Diagnosen) und ANAMNESE-ZUSAMMENFASSUNG (ohne Template, Diagnosen + Vorgeschichte). Der Aufgabentyp wird anhand der Benutzeranweisung bestimmt. Siehe Abschnitt 16 für die vollständige Matrix.

- **[2026-03-19] Neue Regel (FP-003):** **GESCHLECHTSSPEZIFISCHE ANATOMISCHE TERMINOLOGIE:** Bei JEDER Erstellung MUSS die anatomische Terminologie an das Geschlecht des Patienten angepasst werden. Konkret: (1) **Männliche Patienten:** „Excavatio rectovesicalis” — NIEMALS „Douglas-Raum” oder „Excavatio rectouterina”. (2) **Weibliche Patientinnen:** „Excavatio rectouterina” (= Douglas-Raum). (3) **Allgemein:** Alle geschlechtsspezifischen anatomischen Bezeichnungen prüfen: Prostata/Urogenitaltrakt nur bei Männern, Uterus/Ovarien/Adnexe nur bei Frauen. (4) **Template-Anpassung:** Das Template enthält geschlechtsneutrale Platzhalter („Excavatio rectovesicalis bzw. Excavatio rectouterina”) — bei der Erstellung MUSS die korrekte Variante gewählt werden. (5) **Input-Übernahme:** Auch wenn der Input-Text (z.B. aus Praxissoftware) eine falsche Bezeichnung enthält, MUSS die korrekte geschlechtsspezifische Terminologie verwendet werden. Siehe FEHLERPROTOKOLL FP-003.

- **[2026-04-20] Neue Regel:** **SEKTIONSBEZOGENE BEFUND-INTEGRATION UND NORMALBEFUND-PFLICHT:** Jede Diagnose bzw. jeder pathologische Befund aus dem Input-Ordner wird im anatomisch-funktionellen Setting der betroffenen Template-Sektion ausformuliert (z. B. Steatosis hepatis im Sono-Abschnitt „Leber" als Binnenreflexbefund, nicht nur in der Diagnosenliste). Liegt zu einer Sektion kein pathologischer Input vor (gar nichts, nur unauffällige Befunde oder Ausschluss-Formulierungen wie „Ausschluss Steatosis hepatis", „kein Anhalt für Hydronephrose"), wird der vollständige Normalbefund-Text aus dem MedReportTemplate übernommen. Verknappte Platzhaltersätze wie „Leber unauffällig" sind nicht zulässig. Mapping-Tabelle Befund → Zielsektion: siehe Abschnitt 21.3. Siehe Abschnitt 21.

- **[2026-04-17] Neue Regel (FP-004):** **INTEGRATION AKTUELLER FREMDBEFUNDE IN TEMPLATE-ABSCHNITTE:** Für jeden Template-Abschnitt (insbesondere Carotisduplex, orientierende Echokardiographie, CT-/MRT-Korrelate, Koloskopie-/Gastroskopie-Korrelate, spezifische Organsonographien) MUSS geprüft werden, ob im Input-Ordner ein externer Fachbefund vorliegt, der den jeweils aktuellsten Status dokumentiert. Falls ja, werden die konkreten Messwerte und Befundbeschreibungen aus diesem externen Befund DIREKT in den Template-Abschnitt integriert – im Stil des Templates, mit allen klinisch relevanten Zahlen (z.B. EF, Septumdicke, Klappengradienten, Intima-Media-Dicke, Plaque-Lokalisation, Flussgeschwindigkeiten). Liegen mehrere externe Befunde aus verschiedenen Zeiträumen vor, wird der NEUESTE als Grundlage verwendet; ältere Befunde fließen nur dort ein, wo sie zusätzlichen relevanten Inhalt liefern. Verweis-Formulierungen wie „erfolgt extern", „siehe Fremdbefund", „letzte externe Verlaufskontrolle" oder „auf eigene Untersuchung verzichtet" sind NICHT zulässig als Ersatz für die tatsächliche Befundintegration. Ein einleitender Satz mit Datum und Quelle ist erlaubt (z.B. „Duplexsonographie der Carotiden vom 28.03.2025 (MVZ CCB):"). Siehe FEHLERPROTOKOLL FP-004 und Abschnitt 20.

> Hinweis für den Benutzer:
> Wenn im Chat eine neue Regel formuliert wird (z. B. „Neue Regel: …”), diese hier manuell eintragen. Bei zukünftigen Arztbriefen gelten alle hier dokumentierten Regeln als verbindlich.
> Fehler werden im FEHLERPROTOKOLL.md dokumentiert und führen automatisch zu neuen Regeln in diesem Abschnitt.

---

## 7. Qualitätskontrolle

Vor dem endgültigen Versand eines Arztbriefes können folgende Punkte geprüft werden:

- [ ] Passt der Stil zu den bisherigen Arztbriefen?
- [ ] Gibt es Hinweise auf „Bearbeitung“, „Vorlage“ oder „KI“? (Wenn ja, entfernen.)
- [ ] Sind alle relevanten Diagnosen und Befunde korrekt und vollständig übernommen?
- [ ] Sind Wiederholungen und unnötige Redundanzen vermieden?
- [ ] Stimmen Einheiten, Zahlen und Dezimal-Kommas?

---

## 8. System-Ordner und Skripte

- **System-Ordner**: Alle Programmskripte, Apps und Tools zur Bearbeitung von Dateien werden im Ordner `system/` abgelegt.
- **Struktur**: Skripte sollten nach Funktion sinnvoll strukturiert und benannt werden (z. B. `pdf_extractor.py`, `text_processor.py`).
- **Zugriff**: Skripte im `system/`-Ordner können von der KI-Assistenz direkt verwendet werden, um Dateien zu verarbeiten, Informationen zu extrahieren oder andere automatisierte Aufgaben durchzuführen.
- **Dokumentation**: Komplexere Skripte sollten mit Kommentaren und Docstrings dokumentiert sein.

Beispiele für Skripte im `system/`-Ordner:
- PDF-Extraktionsskripte (`pdf_extractor.py`)
- Diagnosenextraktionsskripte (`extract_diagnoses.py`)
- Textverarbeitungs-Tools
- Formatkonverter
- Validierungs-Skripte (`validate_report.py`)

---

## 9. Diagnosenextraktion

### 9.1 Obligatorische Volltext- und ICD-Suche

Die Diagnosenextraktion **muss** den **gesamten Text** aller Unterlagen durchsuchen (siehe Abschnitt 5.7):

- **Volltext:** Jede Seite, jeder Abschnitt (Anamnese, Befunde, Epikrise, Entlassung, Listen) wird nach medizinischen Diagnosen und ICD-relevanten Angaben durchsucht.
- **ICD-10:** Alle vorkommenden ICD-10-Codes werden erfasst; der zugehörige Text wird der Diagnose zugeordnet.
- **Medizinische Begriffe:** Typische Formulierungen (Z.n., V.a., chronische/akute Erkrankungen, konkrete Krankheitsbezeichnungen) werden im gesamten Dokument gesucht und als Diagnosenkandidaten erfasst.
- **Mehrere Dateien:** Alle PDF- und TXT-Dateien im Input-Ordner werden verarbeitet; Diagnosen werden zusammengeführt und priorisiert.

Es ist **nicht zulässig**, nur einen Abschnitt mit der Überschrift „Diagnosen“ oder „ICD“ auszulesen und den Rest zu ignorieren.

### 9.2 Automatische Diagnosenextraktion (Skript)

Das Skript `system/extract_diagnoses.py` implementiert diese Volltext- und ICD-Suche.

**Funktionen:**
- Durchsucht den **gesamten** Text aller angegebenen bzw. im Input-Ordner liegenden Dateien
- Erkennt ICD-10-Codes und zugehörige Bezeichnungen
- Erkennt Diagnoseformulierungen und Erkrankungsnamen im Fließtext
- Sortiert Diagnosen nach Priorität gemäß Abschnitt 5.1
- Bereinigt Duplikate und formatiert gemäß Abschnitt 5.3
- Speichert die Diagnosenliste im Output-Ordner

**Verwendung:**
```bash
python system/extract_diagnoses.py [input_datei.pdf] [output_datei.txt]
```

Ohne Dateinamen: Alle PDF- und TXT-Dateien im Input-Ordner werden durchsucht, Diagnosen zusammengeführt.

**Einschränkungen:**
- Text-PDFs: direkte Extraktion; gescannte PDFs: OCR (z. B. `pdf_ocr.py`) vorher ausführen oder Text als TXT bereitstellen.

### 9.3 Integration in den Workflow

Die Diagnosenextraktion kann als separater Schritt vor oder nach der Arztbrief-Erstellung durchgeführt werden:

1. **Vor der Arztbrief-Erstellung:**
   - Diagnosen aus Input-Dateien extrahieren
   - Diagnosenliste als Referenz für die Arztbrief-Erstellung verwenden

2. **Nach der Arztbrief-Erstellung:**
   - Diagnosen aus dem fertigen Arztbrief extrahieren
   - Validierung der Diagnosenliste gegen den Arztbrief

### 9.4 Manuelle Nachbearbeitung

Die automatisch extrahierte Diagnosenliste sollte immer manuell überprüft und ggf. angepasst werden:
- Vollständigkeit prüfen
- Priorisierung überprüfen
- Formatierung gemäß Abschnitt 5.3 anpassen
- Fehlende Details ergänzen (Daten, Therapien, etc.)

---

## 10. Erstellung strukturierter medizinischer Vorgeschichte aus Vorbefunden

### 10.1 Zweck und Anwendung

Bei der Zusammenfassung von Vorbefunden aus dem Input-Ordner wird eine strukturierte medizinische Vorgeschichte erstellt, die im Output-Ordner ausgegeben wird. **WICHTIG:** Für diesen Prozess wird das MedReportTemplate NICHT benötigt.

### 10.2 Struktur der Vorgeschichte

Die strukturierte medizinische Vorgeschichte besteht aus zwei Hauptabschnitten:

1. **Diagnosenliste** (immer zuerst)
2. **Chronologische Vorgeschichte** (anschließend)

### 10.3 Diagnosenliste

Die Diagnosenliste wird **immer als erstes** erstellt und folgt diesen Prinzipien:

- **Ausführlichkeit:** Sehr detaillierte Darstellung aller Diagnosen mit allen relevanten Informationen
- **Medizinische Gliederung:** Diagnosen werden nach medizinischen Kriterien strukturiert und gegliedert:
  - **Erste Priorität:** Herz-Kreislauf-Erkrankungen und Tumorerkrankungen
  - **Zweite Priorität:** Organinsuffizienzen, endokrinologische und Stoffwechselerkrankungen
  - **Dritte Priorität:** Risikofaktoren und Begleiterkrankungen
- **Strukturierung:** 
  - Hauptdiagnosen als Überschriften
  - Unterpunkte mit Bindestrich (-) eingerückt
  - Mehrere Ebenen möglich
- **Detaillierungsgrad:** 
  - Chronologische Informationen (Daten von Interventionen, Therapiebeginn)
  - Technische Details (Gerätetypen, Größenangaben, Verfahrensdetails)
  - Aktuelle Therapien (mit Dosierung)
  - Aktuelle Befunde und Zustandsbeschreibungen
- **Formatierung:** Siehe Abschnitt 5.3 für Details zur Formatierung

### 10.4 Chronologische Vorgeschichte

Nach der Diagnosenliste wird die Vorgeschichte **chronologisch** aufgelistet:

- **Zeitliche Reihenfolge:** Ereignisse werden in chronologischer Reihenfolge dargestellt (älteste zuerst oder neueste zuerst, je nach Kontext)
- **Vollständigkeit:** Alle relevanten medizinischen Ereignisse, Untersuchungen, Interventionen und Therapien werden erfasst
- **Klinische Relevanz:** Fokus auf medizinisch relevante Informationen
- **Stil:** Sachlich, präzise, in medizinischer Fachsprache
- **Struktur:** Klare Gliederung nach Zeitabschnitten oder Ereignissen

### 10.5 Workflow

1. **Input:** Vorbefunde aus dem Input-Ordner lesen
2. **Verarbeitung:** 
   - Zuerst Diagnosenliste erstellen (nach Abschnitt 10.3)
   - Dann chronologische Vorgeschichte erstellen (nach Abschnitt 10.4)
3. **Output:** Strukturierte Vorgeschichte als .txt-Datei im Output-Ordner speichern

### 10.6 Unterschiede zum Arztbrief-Prozess

- **Kein Template:** Das MedReportTemplate wird für diesen Prozess NICHT verwendet
- **Fokus:** Strukturierte Zusammenfassung der Vorgeschichte, nicht vollständiger Arztbrief
- **Ziel:** Übersichtliche Darstellung der medizinischen Vorgeschichte für spätere Verwendung

---

## 11. Zusammenfassung von Befundberichten

### 11.1 Zweck und Anwendung

Bei Befundberichten im Input-Ordner kann eine **Zusammenfassung** erstellt werden, die sich von der vollständigen Befundbericht-Erstellung nach Template unterscheidet. **WICHTIG:** Der Benutzer unterscheidet explizit zwischen:
- **"Befundbericht erstellen"** → Verwendung des MedReportTemplate.md (wie bisher)
- **"Zusammenfassung erstellen"** → Anwendung dieser Regel (Abschnitt 11)

### 11.2 Struktur der Zusammenfassung

Die Zusammenfassung eines Befundberichts besteht aus zwei Hauptabschnitten:

1. **Zusammenfassung der Befunde** (sachliche Auflistung der relevanten Befunde in zeitlicher Reihenfolge)
2. **Diagnosenliste** (am Ende der Zusammenfassung)

### 11.3 Zusammenfassung der Befunde

Die Zusammenfassung erfolgt im Sinne eines Arztbriefes mit **sachlicher Auflistung der relevanten Befunde in zeitlicher Reihenfolge**:

- **Stil:** Sachlich, präzise, im Stil eines Arztbriefes (nicht anamnestisch)
- **Struktur:** Chronologische Auflistung der relevanten Befunde nach Zeitpunkt der Untersuchung
- **Relevanz:** Nur medizinisch relevante Informationen aufnehmen
- **Zeitform:** Präsens für aktuelle Befunde, Perfekt/Präteritum für vergangene Untersuchungen
- **Zeitliche Reihenfolge:** Befunde werden chronologisch aufgelistet (älteste zuerst oder neueste zuerst, je nach Kontext)
- **Kein Template:** Die Zusammenfassung erfolgt **nicht** nach dem MedReportTemplate.md
- **Ziel:** Übersichtliche, sachliche Darstellung der Befunde für einen Arztbrief

### 11.4 Diagnosenliste

Am Ende der anamnestischen Zusammenfassung wird eine **Auflistung der relevanten Diagnosen** für einen Arztbrief erstellt:

- **Priorisierung:** Nach Abschnitt 5.1 sortiert (Herz-Kreislauf/Tumore → Organinsuffizienzen → Risikofaktoren)
- **Ausführlichkeit:** Gemäß Abschnitt 5.2 und 5.3 strukturiert
- **Formatierung:** Hauptdiagnosen als Überschriften, Unterpunkte mit Bindestrich (-) eingerückt
- **Medizinische Validität:** Nur valide Diagnosen aus den Befunden ableiten (siehe Abschnitt 5.6)

### 11.5 Workflow

1. **Input:** Befundbericht aus dem Input-Ordner lesen
2. **Verarbeitung:**
   - Zuerst sachliche Zusammenfassung der Befunde in zeitlicher Reihenfolge erstellen (nach Abschnitt 11.3)
   - Dann Diagnosenliste erstellen (nach Abschnitt 11.4)
3. **Output:** Zusammenfassung als .txt-Datei im Output-Ordner speichern

### 11.6 Unterschiede zur Befundbericht-Erstellung

- **Kein Template:** Das MedReportTemplate.md wird für Zusammenfassungen **NICHT** verwendet
- **Fokus:** Kurze, relevante Übersicht statt vollständiger Befundbericht
- **Stil:** Anamnestisch statt strukturierter Befundbericht
- **Ziel:** Schnelle Übersicht der relevanten Befunde und Diagnosen

### 11.7 Beispiel-Struktur

```
ZUSAMMENFASSUNG:

[Sachliche Auflistung der relevanten Befunde in zeitlicher Reihenfolge]

DIAGNOSEN:

[Strukturierte Diagnosenliste nach Abschnitt 5.1-5.3]
```

---

## 12. Dokumentart-Erkennung und Validierung

### 12.1 Zweck und Anwendung

Vor der Erstellung einer Zusammenfassung oder eines Befundberichts MUSS die Dokumentart der Input-Datei korrekt identifiziert und validiert werden. Dies verhindert Fehler, bei denen Auftragsdokumente fälschlicherweise als Befundberichte behandelt werden.

### 12.2 Typische Dokumentarten

**Befundberichte (sollten verarbeitet werden):**
- Arztbriefe
- Entlassungsberichte
- Untersuchungsbefunde
- Befundberichte von Fachärzten
- Laborbefunde
- Bildgebende Befunde
- Typische Überschriften: "Befundbericht", "Untersuchungsbefund", "Diagnosen", "Epikrise", "Entlassungsbericht"

**Auftragsdokumente (dürfen NICHT als Befundberichte behandelt werden):**
- Gutachtenaufträge (z.B. Deutsche Rentenversicherung)
- Formulare zur Erstellung von Gutachten (z.B. S0080)
- Überweisungsschreiben
- Typische Formulierungen: "wir bitten Sie zu untersuchen", "Gutachtenauftrag", "Begutachtung", "Auftrag zur Erstellung"

**Anlagen/Beilagen:**
- Vorgutachten (als Anlage zu Auftragsdokumenten)
- Voruntersuchungen (als Beilage)
- Diese sollten nur verarbeitet werden, wenn sie explizit als Hauptinhalt identifiziert werden

### 12.3 Obligatorische Validierung vor der Verarbeitung

**SCHRITT 1: Dokumentart-Erkennung**
- Lese die ersten 3-5 Seiten der PDF/Textdatei
- Suche nach typischen Schlüsselwörtern:
  - **Befundbericht-Indikatoren:** "Befundbericht", "Untersuchungsbefund", "Diagnosen", "Epikrise", "Entlassungsbericht", "Untersuchung vom"
  - **Auftragsdokument-Indikatoren:** "Gutachtenauftrag", "wir bitten Sie", "zu untersuchen", "Begutachtung", "S0080", "Auftrag zur Erstellung"
- Identifiziere die Dokumentart eindeutig

**SCHRITT 2: Validierung**
- Wenn Auftragsdokument erkannt wird:
  - **STOPPE** die Verarbeitung
  - **WARNE** den Benutzer: "Die Datei scheint ein Auftragsdokument zu sein, kein Befundbericht. Soll ich die Anlagen/Beilagen verarbeiten oder warten Sie auf einen fertigen Befundbericht?"
  - **WARTE** auf Benutzerbestätigung
- Wenn Befundbericht erkannt wird:
  - **FORTFAHRE** mit der normalen Verarbeitung
- Wenn unklar:
  - **FRAGE** den Benutzer nach Klärung
  - **WARTE** auf Bestätigung

**SCHRITT 3: Strukturanalyse (bei Befundberichten)**
- Prüfe, ob typische Befundbericht-Strukturen vorhanden sind:
  - Anamnese
  - Untersuchungsbefunde
  - Diagnosen
  - Epikrise/Zusammenfassung
- Wenn keine typischen Strukturen gefunden werden:
  - **WARNE** den Benutzer
  - **FRAGE** nach Bestätigung

### 12.4 Fehlervermeidung

**NIEMALS:**
- Auftragsdokumente als Befundberichte behandeln
- Anlagen/Beilagen als Hauptinhalt behandeln, ohne zu prüfen, ob sie der Hauptinhalt sind
- Ohne Validierung mit der Verarbeitung beginnen
- Bei unklarer Dokumentart einfach weitermachen

**IMMER:**
- Dokumentart vor der Verarbeitung identifizieren
- Bei Auftragsdokumenten den Benutzer warnen und um Bestätigung fragen
- Bei unklarer Dokumentart den Benutzer fragen
- Die erkannte Dokumentart dem Benutzer mitteilen

### 12.5 Beispiel-Workflow

```
1. PDF im Input-Ordner gefunden
2. Erste 3 Seiten lesen
3. Schlüsselwörter suchen:
   - Gefunden: "wir bitten Sie zu untersuchen", "Gutachtenauftrag", "S0080"
   - → Auftragsdokument erkannt
4. Benutzer warnen:
   "WARNUNG: Die Datei scheint ein Gutachtenauftrag zu sein, kein Befundbericht.
   Die PDF enthält Formulare zur Erstellung eines Gutachtens.
   Soll ich:
   a) Die Anlagen/Beilagen in der PDF verarbeiten?
   b) Warten Sie auf einen fertigen Befundbericht?
   c) Etwas anderes?"
5. Warten auf Benutzerbestätigung
6. Erst nach Bestätigung mit Verarbeitung fortfahren
```

### 12.6 Integration in bestehende Workflows

Diese Validierung MUSS vor jedem der folgenden Workflows durchgeführt werden:
- Erstellung einer Zusammenfassung (Abschnitt 11)
- Erstellung eines Befundberichts nach Template (Abschnitt 10)
- Extraktion von Diagnosen (Abschnitt 9)
- Erstellung einer strukturierten Vorgeschichte (Abschnitt 10)

---

## 13. Chat-Verlauf und Kontext-Management

### 13.1 Zweck und Anwendung

Bei jedem Neustart des Programms oder Beginn einer neuen Sitzung MÜSSEN alle vorherigen Chat-Verläufe und Kontextinformationen gelöscht werden, um Verwechslungen und falsche Interpretationen zu vermeiden.

### 13.2 Obligatorische Regeln

**Bei Neustart/Beginn neuer Sitzung:**
- Alle vorherigen Chat-Verläufe werden gelöscht
- Alle Kontextinformationen aus vorherigen Aufgaben werden verworfen
- Keine Annahmen über vorherige Aufgaben werden getroffen
- Jede neue Aufgabe wird ohne Bezug zu vorherigen Aufgaben bearbeitet

**Bei neuen Aufgaben:**
- Prüfe IMMER den aktuellen Input-Ordner-Inhalt
- Verwende NUR Informationen aus der aktuellen Input-Datei
- Verlasse dich NICHT auf Informationen aus vorherigen Chats
- Bei Unklarheiten: FRAGE den Benutzer, suche NICHT in Chat-Verläufen

### 13.3 Fehlervermeidung

**NIEMALS:**
- Informationen aus vorherigen Chats für neue Aufgaben verwenden
- Annahmen über vorherige Aufgaben treffen
- Alte Kontextinformationen für neue Aufgaben nutzen

**IMMER:**
- Bei Neustart mit leerem Kontext beginnen
- Nur aktuelle Input-Dateien verwenden
- Bei Unklarheiten den Benutzer fragen

---

## 14. Input-Datei-Erkennung und Textextraktion

Für die Erkennung und Extraktion von Input-Dateien wird ausschließlich das
universelle Extraktions-Tool verwendet:

```bash
python3 _lib/extract/universal_extract.py <Input-Ordner-Pfad>
```

Dieses Tool erkennt automatisch die beste verfügbare Methode (pdfplumber, OCR,
CLI-Fallback), cached Ergebnisse und funktioniert in allen Umgebungen (Cowork,
Cursor, Windows, Linux). Es dürfen KEINE neuen Inline-Extraktionsskripte
geschrieben werden — Verbesserungen gehören in `_lib/extract/universal_extract.py`.

---

## 15. Temporale Logik und Befundaktualität

### 15.1 Grundprinzip

Wenn mehrere Input-Dokumente aus verschiedenen Zeiträumen vorliegen, MUSS eine chronologische Analyse erfolgen. **Jeder Befundabschnitt im Arztbrief beschreibt den AKTUELLEN Zustand des Patienten, nicht historische Zustände.** Historische Informationen gehören in die Anamnese und die Diagnosen.

### 15.2 Obligatorische Chronologie-Analyse

**VOR der Erstellung eines Befundberichts:**
1. Alle Input-Dokumente chronologisch ordnen (nach Untersuchungs-/Aufnahmedatum)
2. Für jeden relevanten Befund prüfen: Hat sich dieser Zustand zwischen den Dokumenten verändert?
3. Veränderungen klassifizieren: Intervention (OP, Prozedur), Therapie (Medikamente), Spontanverlauf

**Ergebnis:** Eine Liste von Befunden, die sich verändert haben, mit Angabe des aktuellen Status.

### 15.3 Zuordnungsregeln: Welcher Befund gehört wohin?

**Grundregel:** Ein Befund, der durch eine Intervention BESEITIGT wurde, darf NICHT mehr als aktueller Befund beschrieben werden.

| Situation | Befundabschnitt (Sono, Klinik) | Anamnese | Diagnosen |
|-----------|-------------------------------|----------|-----------|
| Befund unverändert | Aktuellen Befund beschreiben | Erwähnen falls relevant | Aufnehmen |
| Befund durch OP beseitigt | NUR post-OP Status | Vorgeschichte + OP beschreiben | Z.n. [Intervention] |
| Befund durch Therapie verbessert | Aktuellen (verbesserten) Befund | Therapieverlauf beschreiben | Aktuellen Status + Therapie |
| Befund neu aufgetreten | Aktuellen Befund beschreiben | Neue Symptome beschreiben | Aufnehmen |
| Befund progredient | Aktuellen (verschlechterten) Befund | Verlauf beschreiben | Aktuellen Schweregrad |

### 15.4 Beispiel: Carotisstenose mit Z.n. OP

**FALSCH (vermischt Zeitebenen):**
> Carotisduplex: Auf der linken Seite grobschollige kalzifizierende Plaques im Bereich der Bifurkation. Im Bereich der A. carotis interna auf der linken Seite die vorbekannte Stenose mit einer PSV von knapp 320 cm/sec und somit einer höhergradigen Stenose >70%. Nachtrag: Am 10.09.2024 erfolgte eine Eversionsendarteriektomie [...]

**RICHTIG (aktueller Status im Befund, Historie in Anamnese):**
> Carotisduplex: Z.n. Eversionsendarteriektomie der A. carotis interna links am 10.09.2024. Postoperativ regelrechte Rekonstruktion der ACC, ACI und ACE links ohne hämodynamisch relevante Stenosen oder Intimalefzen (FKDS vom 12.09.2024). Auf der rechten Seite weicher Plaque im Bereich des Abgangs der ACI ohne relevante Strömungsbeschleunigung.

> Anamnese: [...] Weiterhin bestand eine hochgradige Stenose der A. carotis interna links (NASCET 80–90%), die im Verlauf aus einer vormals ca. 40%igen Stenose progredient war (04/2024: PSV 320 cm/sec). Am 10.09.2024 erfolgte eine Eversionsendarteriektomie in Plexusanästhesie an der Universitätsmedizin Frankfurt mit gutem operativem Ergebnis [...]

### 15.5 Spezialfälle

**Befundbericht bezieht sich auf EINE Untersuchung, zusätzlich liegen Fremdbefunde vor:**
- Die Sonographie-Abschnitte beschreiben NUR die eigene Untersuchung
- Fremdbefunde (z.B. Entlassungsbrief Krankenhaus) fließen in Anamnese, Diagnosen und Zusammenfassung ein
- Wenn ein Fremdbefund einen AKTUELLEREN Status zeigt als die eigene Untersuchung: Im Befundabschnitt den eigenen Befund beschreiben UND den aktuelleren Fremdbefund als Update ergänzen

**Mehrere eigene Untersuchungen zu verschiedenen Zeitpunkten:**
- Der Befundbericht bezieht sich auf die LETZTE eigene Untersuchung
- Vorherige Untersuchungen gehen in die Anamnese/Verlauf ein

### 15.6 Checkliste „Temporale Konsistenz" (VOR Fertigstellung)

- [ ] Gibt es Befunde, die durch Interventionen/Therapien seit der Untersuchung verändert wurden?
- [ ] Falls ja: Beschreiben die Befundabschnitte den AKTUELLEN Status (nicht den historischen)?
- [ ] Sind historische Befunde korrekt in der Anamnese dargestellt?
- [ ] Verwenden die Diagnosen korrekt „Z.n." für abgeschlossene Interventionen?
- [ ] Ist die Zusammenfassung konsistent mit dem aktuellen Status?

---

## 16. Aufgabentypen-Matrix

### 16.1 Übersicht der Aufgabentypen

Es gibt drei klar definierte Aufgabentypen mit jeweils eigenem Workflow:

| Auslöser (Benutzer sagt) | Aufgabentyp | Template benötigt? | Hauptabschnitte |
|--------------------------|-------------|-------------------|-----------------|
| „Befundbericht erstellen" | BEFUNDBERICHT | Ja (MedReportTemplate.md) | Vollständiger Bericht nach Template |
| „Zusammenfassung erstellen" | ZUSAMMENFASSUNG | Nein | Befundzusammenfassung + Diagnosenliste |
| „Anamnese erstellen" / „Vorgeschichte" | ANAMNESE-ZUSAMMENFASSUNG | Nein | Diagnosenliste + chronologische Vorgeschichte |

### 16.2 Aufgabentyp: BEFUNDBERICHT

**Auslöser:** „Befundbericht erstellen", „Arztbrief erstellen"
**Template:** MedReportTemplate.md (PFLICHT)
**Methode:** Template-First-Ansatz (Abschnitt 4)
**Abschnitte:** Alle Abschnitte aus dem Template (Anamnese, Klinische Untersuchung, Sonographie, Funktionsuntersuchungen, Labor, Zusammenfassung, Procedere)
**Validierung:** validate_report.py PFLICHT
**Temporale Logik:** Abschnitt 15 anwenden

### 16.3 Aufgabentyp: ZUSAMMENFASSUNG

**Auslöser:** „Zusammenfassung erstellen", „Befunde zusammenfassen"
**Template:** KEINES
**Methode:** Sachliche Auflistung der Befunde + Diagnosenliste (Abschnitt 11)
**Abschnitte:**
1. Sachliche Zusammenfassung der relevanten Befunde in zeitlicher Reihenfolge
2. Diagnosenliste (nach Abschnitt 5.1–5.3 priorisiert)
**Validierung:** Manuelle Prüfung auf Vollständigkeit
**Temporale Logik:** Chronologisch, aktuellster Status hervorheben

### 16.4 Aufgabentyp: ANAMNESE-ZUSAMMENFASSUNG

**Auslöser:** „Anamnese erstellen", „Vorgeschichte erstellen", „Krankengeschichte zusammenfassen"
**Template:** KEINES
**Methode:** Strukturierte medizinische Vorgeschichte (Abschnitt 10)
**Abschnitte:**
1. Diagnosenliste (immer zuerst, nach Abschnitt 5.1–5.3 priorisiert)
2. Chronologische Vorgeschichte (Anamnese als Fließtext)
**Validierung:** Manuelle Prüfung auf Vollständigkeit
**Temporale Logik:** Chronologisch, älteste Ereignisse zuerst

### 16.5 Gemeinsame Regeln für alle Aufgabentypen

Unabhängig vom Aufgabentyp gelten IMMER:
- Input-Ordner zuerst prüfen (Abschnitt 1)
- Dokumentart validieren (Abschnitt 12)
- Diagnosenliste nach Priorität sortieren (Abschnitt 5.1)
- Volltext- und ICD-Suche (Abschnitt 5.7)
- Keine erfundenen Daten (Abschnitt 1)
- Fehlerprotokoll lesen und Prüfpunkte anwenden (Abschnitt 17)
- Temporale Logik anwenden (Abschnitt 15)
- Ausgabe im Output-Ordner als .txt

---

## 17. Selbstlernendes Fehlerprotokoll-System

### 17.1 Zweck

Das Fehlerprotokoll (`FEHLERPROTOKOLL.md`) ist ein lebendes Dokument, das aus Fehlern konkrete, anwendbare Regeln ableitet. Es bildet eine Feedbackschleife zwischen Fehlererkennung und Regelverbesserung.

### 17.2 Feedbackschleife

```
Fehler erkannt
    ↓
FEHLERPROTOKOLL.md: Fehler dokumentieren (ID, Beschreibung, Ursache, Korrektur)
    ↓
Konkrete Regel ableiten
    ↓
MedReportRules.md: Regel in Abschnitt 6 (Regel-Logbuch) eintragen
    ↓
WORKFLOW_CHECKLIST.md: Prüfpunkt ergänzen (falls anwendbar)
    ↓
Bei nächster Erstellung: Fehlerprotokoll lesen → Prüfpunkte anwenden
```

### 17.3 Obligatorischer Workflow

**VOR jeder Erstellung:**
1. FEHLERPROTOKOLL.md lesen
2. Alle dort dokumentierten Prüfpunkte auf den aktuellen Fall anwenden
3. Insbesondere: Fehler desselben Typs (z.B. temporale Vermischung, Dokumentart-Verwechslung) aktiv vermeiden

**NACH jeder Erstellung (Selbstprüfung):**
1. Erstelltes Dokument gegen die häufigsten Fehlermuster aus dem Protokoll prüfen
2. Bei neu erkannten Fehlern: Fehlerprotokoll ergänzen

**BEI Benutzerfeedback:**
1. Korrektur des Benutzers als neuen Fehler dokumentieren
2. Regel ableiten und in MedReportRules.md eintragen
3. Bestätigung an Benutzer: „Fehler als FP-XXX protokolliert, Regel abgeleitet."

### 17.4 Fehler-Kategorien

| Kategorie | Beschreibung | Beispiele |
|-----------|-------------|-----------|
| TEMPORAL | Vermischung von Zeitebenen | Prä-OP Befund als aktuell dargestellt |
| DOKUMENTART | Falsche Dokumentart verarbeitet | Gutachtenauftrag als Befundbericht |
| VOLLSTÄNDIGKEIT | Fehlende Abschnitte oder Informationen | Template-Abschnitt vergessen |
| FAKTEN | Erfundene oder falsche Informationen | Diagnose ohne Quellenbeleg |
| STIL | Stilistische Fehler | Meta-Kommentare, KI-Hinweise |
| STRUKTUR | Falsche Zuordnung zu Abschnitten | Befund in Anamnese statt Sonographie |

---

## 20. Integration aktueller Fremdbefunde in Template-Abschnitte

### 20.1 Grundprinzip

Jeder sonographische oder apparative Template-Abschnitt wird mit dem **aktuellsten verfügbaren Befund** gefüllt — unabhängig davon, ob dieser aus einer eigenen Untersuchung oder aus einem externen Fachbefund im Input-Ordner stammt.

**Die Template-Struktur wird beibehalten, aber die Befundwerte stammen aus dem jeweils neuesten vorliegenden Befund.**

Verweis-Formulierungen wie „erfolgt extern", „siehe Fremdbefund", „letzte externe Verlaufskontrolle", „auf eigene Untersuchung verzichtet" oder „bekannter Status" sind NICHT zulässig als Ersatz für die Befundintegration.

### 20.2 Betroffene Template-Abschnitte

Diese Regel gilt insbesondere für die folgenden Template-Abschnitte, wenn im Input externe Fachbefunde vorliegen:

| Template-Abschnitt | Typische externe Quellen |
|---|---|
| Carotisduplex | Angiologie, Kardiologie (MVZ CCB, Krankenhaus) |
| Orientierende Echokardiographie | Kardiologie, Herzzentrum |
| Herz subxiphoidal | Kardiologie |
| Abdominelle Gefäße / Aorta | Gefäßchirurgie, CT-Angiographie |
| Nieren / Urogenitaltrakt | Urologie, Radiologie |
| Schilddrüse | Endokrinologie, Radiologie |
| Ergometrie / Belastungs-EKG | Kardiologie |
| Lungenfunktion | Pneumologie |
| Gallenblase / Leber / Pankreas | Gastroenterologie, CT/MRT |

### 20.3 Integrations-Workflow

**Schritt 1: Fremdbefund-Inventur**
Vor der Erstellung wird geprüft, welche externen Fachbefunde im Input-Ordner vorliegen und welche Template-Abschnitte sie betreffen.

**Schritt 2: Chronologische Zuordnung**
Bei mehreren externen Befunden zum selben Abschnitt: den NEUESTEN als Grundlage verwenden. Ältere Befunde fließen nur ein, wenn sie relevanten Zusatzinhalt liefern (z.B. Verlaufsdynamik, Ersterhebung eines Befundes).

**Schritt 3: Integration in Template-Struktur**
Die konkreten Messwerte und Befundbeschreibungen werden in den Template-Abschnitt überführt — nicht 1:1 kopiert, sondern im Stil des Templates formuliert. Alle klinisch relevanten Zahlen müssen übernommen werden (z.B. EF, IVS, Gradienten, Flussgeschwindigkeiten, Intima-Media-Dicke, Plaque-Lokalisationen).

**Schritt 4: Quellenangabe (optional, empfohlen)**
Ein einleitender Satz mit Datum und Quelle ist zulässig und oft hilfreich:
- „Duplexsonographie der Carotiden vom 28.03.2025 (MVZ CCB):"
- „Echokardiographie vom 15.12.2025 (Kardiologie):"

Der Rest des Abschnitts folgt dem normalen Template-Stil mit konkreten Messwerten.

### 20.4 Priorisierung bei mehreren Befunden

| Situation | Regel |
|---|---|
| Eigene Untersuchung am Berichtstag UND aktueller Fremdbefund | Eigene Untersuchung; Fremdbefund nur ergänzend wenn weiterführender Inhalt |
| Eigene Untersuchung ist älter als Fremdbefund | NEUESTEN Befund verwenden (auch wenn extern) |
| Mehrere externe Fremdbefunde | NEUESTEN Befund als Basis; ältere bei Verlaufsrelevanz |
| Keine eigene Untersuchung, nur Fremdbefund | Fremdbefund vollständig integrieren |
| Keine eigene Untersuchung, kein Fremdbefund | Template-Normalbefund (nur wenn klinisch plausibel — bei bekannter Pathologie: Abschnitt kurz mit bekanntem Status benennen, mit Datum) |

### 20.5 Beispiele

**Falsch (Verweis-Formulierung):**
> Carotisduplex
> Bei bekannter ausgeprägter Carotissklerose mit bis mittelgradiger Abgangsstenose der Arteria carotis interna links erfolgt die Verlaufskontrolle extern. Die Intima-Media-Dicke wurde in der letzten externen Verlaufskontrolle entsprechend dokumentiert.

**Richtig (Integration):**
> Carotisduplex (Duplexsonographie vom 28.03.2025, MVZ CCB):
> Regelrechter Fluss in Arteria carotis communis, Arteria carotis interna und Arteria carotis externa beidseits. Arteria vertebralis beidseits orthograd durchströmt. Beidseits ausgeprägte Plaquebildung mit bis mittelgradiger Abgangsstenose der Arteria carotis interna links; aktuell keine hämodynamisch relevante Flussbeschleunigung.

**Falsch (Allgemein-Aussage ohne Messwerte):**
> Orientierende Echokardiographie
> Normale systolische Pumpfunktion des linken Ventrikels bei hypertropher, nicht obstruktiver Kardiomyopathie.

**Richtig (Integration mit Messwerten):**
> Orientierende Echokardiographie (Echokardiographie vom 28.03.2025, MVZ CCB):
> Normale systolische Pumpfunktion des linken Ventrikels (EF 61 Prozent). Interventrikuläres Septum 15 Millimeter bei bekannter hypertropher, nicht obstruktiver Kardiomyopathie. Linker Ventrikel 54 Millimeter, rechter Ventrikel 30 Millimeter. Linker Vorhof 44 × 53 Millimeter (Fläche 23,1 cm²). Biologischer Aortenklappenersatz mit Gradient 22/12 mmHg, Aorteninsuffizienz Grad 0–I, Mitralinsuffizienz Grad 0–I. TAPSE 24 Millimeter. E/A 1,50, E/E' lateral 6,9, E/E' septal 11,6. Kein Perikarderguss.

### 20.6 Abgrenzung zur Sektion „Im Verlauf eingegangene externe Befunde"

Eine zusätzliche Sektion „Im Verlauf eingegangene externe Befunde" am Ende des Berichts ist NUR dann sinnvoll, wenn externe Befunde Informationen enthalten, die **keinem Template-Abschnitt zugeordnet** werden können (z.B. Pathologie-Histologien, narrative Arztbrief-Beurteilungen). Befunde, die einem Template-Abschnitt zugeordnet werden können, werden dort integriert — nicht zusätzlich in einer Verlaufs-Sektion dupliziert.

### 20.7 Zusammenspiel mit FP-001 (Temporale Logik)

Diese Regel ergänzt FP-001. Die temporale Logik verlangt, dass Befundabschnitte den AKTUELLEN Status widerspiegeln — dies schließt ausdrücklich externe aktuellere Befunde ein. Das Berichtsdatum ist dabei NICHT limitierend: Ein Befundbericht darf externe Befunde integrieren, die zeitlich nach dem Untersuchungstag des Hauptautors entstanden sind, sofern sie den aktuellen Status besser dokumentieren. Der Bericht ist in diesem Fall als zusammenfassender aktueller Befundbericht zu verstehen.

---

## 21. Sektionsbezogene Befund-Integration und Normalbefund-Pflicht

### 21.1 Grundprinzip

Jede Diagnose bzw. jeder pathologische Befund aus dem Input wird im **anatomisch-funktionellen Setting** der betroffenen Template-Sektion ausformuliert — nicht nur in der Diagnosenliste aufgeführt. Die Sektion „spricht" in ihrer eigenen Terminologie (Sonographie, Ergometrie, Lungenfunktion, Klinik, Labor, Anamnese).

Konkret:
- Eine Steatosis hepatis wird im Sonographie-Abschnitt **Leber** als Binnenreflexbefund formuliert (z.B. „Leber mit homogen verdichtetem Binnenreflexmuster im Sinne einer Steatosis hepatis Grad 1"), nicht nur als Diagnose gelistet.
- Eine höhergradige Carotisstenose wird im **Carotisduplex**-Abschnitt mit Flussparametern beschrieben, nicht nur in der Diagnosenliste.
- Eine linksventrikuläre Hypertrophie wird in der **orientierenden Echokardiographie** mit Septumdicke/LV-Geometrie beschrieben.
- Eine Cholelithiasis wird im Abschnitt **Gallenblase und Gallenwege** beschrieben (Steinzahl, -größe, Wandstatus).
- Eine obstruktive Ventilationsstörung wird in der **Lungenfunktion** mit Messwerten (FEV1, FEV1/FVC) ausformuliert.
- Eine Adipositas wird im Anamnese-/Klinik-Abschnitt (Ernährungszustand, Körpergewicht) angegeben, die Diagnose zusätzlich in der Diagnosenliste.

Die Diagnosenliste fasst die klinische Interpretation zusammen; sie ersetzt nicht die Beschreibung in der Untersuchungssektion.

### 21.2 Normalbefund-Pflicht bei Fehlen pathologischer Inhalte

Wenn der Input zu einer Sektion bzw. zu einem Organsystem:
1. **gar nichts enthält**, oder
2. **den Abschnitt erwähnt, aber keinerlei pathologische Beobachtung liefert** (z.B. „Leber soweit einsehbar unauffällig"), oder
3. **nur eine Ausschluss-Formulierung liefert** (z.B. „Ausschluss Steatosis hepatis", „kein Anhalt für Hydronephrose"),

→ wird der **vollständige Normalbefund-Text aus dem MedReportTemplate** für die entsprechende Sektion übernommen. Kürzungen oder verknappte Platzhaltersätze wie „Leber unauffällig" sind nicht zulässig, solange das Template einen ausformulierten Normalbefund bereithält.

**Begründung:** Der ausformulierte Normalbefund dokumentiert auch implizit, welche Strukturen tatsächlich beurteilt wurden (z.B. Lebervenen, Venenstern, Lobus caudatus, Ligamentum teres) — eine reine „unauffällig"-Notiz tut das nicht.

### 21.3 Mapping-Tabelle Befund/Diagnose → Template-Sektion

Nicht erschöpfend; bei neuen Befundarten ist zu ergänzen.

| Befund / Diagnose | Primärsektion (Integration) | Sekundär (Diagnosenliste / Zusammenfassung) |
|---|---|---|
| Steatosis hepatis (Grad I–III) | Sonographie → Leber | Diagnosenliste |
| Fokale Leberläsion, Zyste, Hämangiom | Sonographie → Leber | Diagnosenliste falls klinisch relevant |
| Cholelithiasis, Gallenblasenpolyp | Sonographie → Gallenblase und Gallenwege | Diagnosenliste |
| DHC-Erweiterung | Sonographie → Gallenblase und Gallenwege | Diagnosenliste |
| Schilddrüsenknoten / -zyste (TIRADS) | Sonographie → Schilddrüse | Diagnosenliste (mit TIRADS-Klassifikation) |
| Struma diffusa / multinodosa, Autoimmunthyreopathie | Sonographie → Schilddrüse | Diagnosenliste |
| Carotisplaque, -stenose, IMT-Erhöhung | Sonographie → Carotisduplex | Diagnosenliste (NASCET %) |
| LV-Funktionsstörung, Klappenvitium, Hypertrophie | Sonographie → Orientierende Echokardiographie | Diagnosenliste |
| Perikarderguss / Perikard-Lamelle | Sonographie → Echokardiographie + Herz subxiphoidal | Diagnosenliste |
| Aortensklerose / -aneurysma | Sonographie → Abdominelle Gefäße | Diagnosenliste (Durchmesser) |
| AVK-Hinweis, Beckenarterien-Plaque | Sonographie → Beckenarterien + Funktionsuntersuchungen → ABI | Diagnosenliste |
| Nierenzyste (BOSNIAK), Nephrolithiasis, Hydronephrose | Sonographie → Nieren | Diagnosenliste |
| Niereninsuffizienz (GFR-Reduktion) | Labor + Sonographie → Nieren (Parenchym) | Diagnosenliste (Stadium) |
| Prostatahyperplasie, -verkalkungen | Sonographie → Urogenitaltrakt | Diagnosenliste |
| Myom, Ovarialzyste | Sonographie → Urogenitaltrakt | Diagnosenliste |
| Pankreas-Auffälligkeit (Zyste, Verkalkung, Läsion) | Sonographie → Pankreas | Diagnosenliste |
| Splenomegalie, Milzzyste | Sonographie → Milz | Diagnosenliste |
| Darmwandverdickung, Divertikulose | Sonographie → Darm | Diagnosenliste |
| Myokardischämie-Hinweis | Funktionsuntersuchungen → Ergometrie | Diagnosenliste |
| Obstruktive / restriktive Ventilationsstörung | Funktionsuntersuchungen → Lungenfunktion | Diagnosenliste |
| ABI-Auffälligkeit | Funktionsuntersuchungen → ABI | Diagnosenliste |
| Hypertonie, Adipositas | Anamnese + Klinische Untersuchung (Allgemeinzustand) | Diagnosenliste / cvRF |
| Diabetes mellitus | Anamnese + Labor (HbA1c, Nüchternglu.) | Diagnosenliste |
| Hypercholesterinämie | Labor + Zusammenfassung | Diagnosenliste / cvRF |
| Z.n. OP, Z.n. Stent, Z.n. Intervention | Anamnese (Vorerkrankungen) + betroffene Sektion (Post-Status) | Diagnosenliste als Z.n. |

### 21.4 Anti-Pattern

Falsch:
> Leber: unauffällig.
> Diagnosen: Steatosis hepatis Grad 1.

→ Widerspruch und Inkonsistenz: Die Diagnose ist nicht in der Sono-Sektion beschrieben, die Sono-Sektion enthält nicht den tatsächlichen Befund.

Richtig:
> Leber mit homogen verdichtetem Binnenreflexmuster im Sinne einer Steatosis hepatis Grad 1. Regelrechte Größe, spitzwinkliger Unterrand, Lebervenen normal weit, regelrechter Venenstern ohne Stauungszeichen. Kein Hinweis auf fokale Läsionen.
> Diagnosen: Steatosis hepatis Grad 1.

### 21.5 Zusammenspiel mit Abschnitt 4, 5 und 20

- **Abschnitt 4 (Template-First):** Struktur wird gewahrt, jede Sektion ist Pflicht.
- **Abschnitt 5 (Diagnosenliste):** Diagnosen stehen zusätzlich in der Diagnosenliste; die Integration in die Sektion ersetzt die Diagnose nicht.
- **Abschnitt 20 (Fremdbefunde):** Fremdbefunde werden sektional integriert (Messwerte in der zugehörigen Sektion). Abschnitt 21 definiert die Zielsektion für verschiedene Befundarten.

---

Dieses Dokument ist bewusst so angelegt, dass es über die Zeit erweitert wird. Neue Regeln sollen mit Datum und kurzer Begründung ergänzt werden, um die Konsistenz der Arztbriefe langfristig zu sichern.


