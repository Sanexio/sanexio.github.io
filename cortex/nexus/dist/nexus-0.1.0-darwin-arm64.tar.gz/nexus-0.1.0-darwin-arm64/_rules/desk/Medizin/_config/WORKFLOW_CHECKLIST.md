# Workflow-Checkliste: Medizin

**Diese Checkliste MUSS bei JEDER medizinischen Dokumentenverarbeitung befolgt werden.**
Unterkategorie-spezifische Checklisten (z.B. `subcategories/befundberichte/WORKFLOW_CHECKLIST.md`) ergänzen diese.

---

## PHASE 1: VORBEREITUNG

- [ ] Input-Ordner (`Medizin/Input/`) geprüft — Dateien identifiziert
- [ ] Dateien eingelesen (`_lib/extract/universal_extract.py` — KEIN Inline-OCR)
- [ ] Dokumentart bestimmt → Unterkategorie zuweisen (befundberichte / amtsanfragen)
- [ ] Fehlerprotokoll gelesen (global + `Medizin/_config/FEHLERPROTOKOLL.md`)
- [ ] Unterkategorie-Regeln und Checkliste geladen

---

## PHASE 2: VERARBEITUNG

- [ ] Patientendaten aus Input extrahiert (Name, Geburtsdatum, Geschlecht)
- [ ] Geschlecht identifiziert → geschlechtsspezifische Terminologie verwenden
- [ ] Diagnosen aus Input-Dokumenten extrahiert (ICD-10 wenn vorhanden)
- [ ] Alle Inhalte stammen ausschließlich aus den Input-Dokumenten — KEINE Erfindungen
- [ ] Fachsprachliche Konsistenz geprüft (Befundsprache, Zeitformen)
- [ ] Unterkategorie-spezifische Regeln angewendet

---

## PHASE 3: QUALITÄTSSICHERUNG

- [ ] Ergebnis gegen Blueprint-Vorlage geprüft (wenn vorhanden)
- [ ] Patientendaten korrekt übernommen (Name, Datum, Geschlecht)?
- [ ] Keine Meta-Kommentare vorhanden (kein Hinweis auf KI)?
- [ ] Fehlerprotokoll-Abgleich — bekannte Fehlermuster geprüft?
- [ ] Bei neuen Fehlern: Fehlerprotokoll ergänzen

---

## PHASE 4: AUSGABE

- [ ] Ergebnis im `Medizin/Output/` gespeichert
- [ ] Dateiname folgt Konvention: `<Name>_<Datum>_<Dokumenttyp>.<ext>`
- [ ] **Patientenordner-Prüfung:** Hat dieser Patient ≥ 2 Dateien im Output? Falls ja: Ordner `<Nachname>_<Vorname>/` anlegen oder verwenden und alle zugehörigen Dateien hineinverschieben (siehe `RULES.md` → „Output-Struktur — Patientenordner bei mehreren Dateien")
- [ ] Benutzer über Ergebnis informiert
