# Security-Regeln

> Token-, Secret- und Auth-Hygiene. Ergänzt die Tier-3-Hardstops
> (`agent/modes/tier3.md`) auf Vertragsebene.

## Token-Handling

- **Nur App-Passwords/Tokens an Claude weitergeben** — niemals
  Admin-Passwörter oder Master-Credentials.
- Tokens werden in `.env`-Dateien lokal gehalten, niemals committet
  (siehe `.gitignore`-Pattern).
- Token-Rotation: bei Verdacht auf Leak sofortiges Revoke + Re-Issue.
  Rotation gilt als R3-Operation (Tier-3 Kategorie 1: Secrets).

## Secrets-Hygiene

Verboten — als Tier-3 hardstop in `agent/modes/tier3.md` festgelegt:

- `.env`-Files überschreiben oder neu anlegen.
- `~/.claude.json` schreiben.
- API-Keys, Bot-Tokens, Passwörter committen oder loggen.
- SSH-/GPG-Keys generieren oder rotieren.
- Keychain-Einträge ändern.

Erlaubt:

- `.env`-Dateien **lesen**, um Werte zu nutzen (z.B. via `os.environ`).
- Tokens **in Memory** halten und an APIs senden.
- Token-Existenz prüfen (`echo "${TOKEN:0:8}…"` für Maskierte Diagnose).

## Logging

- **Secrets niemals loggen.** Bei automatischen Logs (`_memory/logs/`)
  vor dem Schreiben prüfen, ob Tokens/Passwörter im String sind.
- Beispiele für sichere Diagnose-Logs:
  - `echo "API_KEY=${API_KEY:0:8}… (length ${#API_KEY})"`
  - In Python: `logger.info(f"key prefix={key[:8]}…")`
- Audit-Logs (`_memory/audit/*.jsonl`) sind ebenfalls Pflicht-secrets-frei.

## Connexio-Whitelist

Die Connexio-Whitelist (`agent/connexio/kernel.py::READABLE_ROOTS`) darf
zur Laufzeit **nicht** um Patient-, Medizin-, Steuer-, Secret- oder
Auth-Kontexte erweitert werden. Solche Erweiterungen sind R3 und brauchen
explizite Stracke-Freigabe + Spec-Eintrag.

Die `BLOCKED_FILE_PATTERNS` decken bereits ab: `.env`, `.tar.gz`,
`id_rsa`, `id_ed25519`, `.pem`, `.key`, `~/.claude.json`,
`telegram-bridge-state`, `spawn-queue.db`, `connexio-audit`.

## DSGVO

DSGVO-Pflicht bei allen Patient-bezogenen Inhalten. Detail-Regeln (Tags,
Schreibverbot in Patient-Kontexten, Anonymisierung): siehe
`_rules/medical-domain.md` (Stracke-spezifisch).

## Public-Skeleton-Hinweis

Diese Datei ist generisch verwendbar — die Regeln gelten für jeden Cortex.
Stracke-spezifische Erweiterungen (Medizin-Domain) liegen separat in
`_rules/medical-domain.md` und sind in einer Public-Variante austauschbar.
