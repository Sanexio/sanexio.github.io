# AI-Cooperation — Claude × Codex Peer-Modell

> Wie Claude und Codex zusammenarbeiten. Sammelt AC §11 in einer
> fokussierten Datei. Die Grenze für **andere** KIs (Cursor, Cline,
> Continue, Gemini-CLI) am Nexus-Kern liegt in
> `_rules/multi-ai-boundaries.md`.

## Grundsatz

Claude und Codex arbeiten als **Peer-Systeme**. Beide dürfen analysieren,
Vorschläge formulieren, Reviews schreiben und einander Aufgaben stellen.
Keines der Systeme entscheidet allein über Nexus-Kern-Änderungen. Dr.
Stracke gibt Nexus-Kern-Umsetzungen und R3-Aktionen frei.

## Schreibbereiche

**Frei für Claude und Codex** (sofern Risiko-Level ≤ R1 und Git sauber):

- `~/Cortex/projects/<projekt>/`
- `~/Cortex/projects/_ai-cooperation-outbox/`
- projektlokale `.cortex/tasks/` und `.cortex/reviews/`

**Nicht erlaubt ohne Freigabe** (R2, alles unter `~/Cortex/Nexus/`):

- direkter Nexus-Dateieingriff
- Nexus-Commit
- Nexus-Push
- Änderung an Regel-, Agent-, Gateway-, Connexio-, Sync- oder
  Cron-Logik

**Immer R3** (siehe `_rules/risk-levels.md` und `agent/modes/tier3.md`):
Secrets/Auth, Zahlvorgänge, Schreibzugriff außerhalb Cortex, destruktive
Git-Historienoperationen in fremden Repos, echte Deployments mit
Außenwirkung, Systemdienste/LaunchAgents/Cron.

## Gegenseitige Aufgaben

**Claude kann Codex Aufgaben stellen:**

- Projektimplementierung.
- Test/Review.
- Diff-Audit.
- Vorschlag für Nexus-Regel oder Spec.

**Codex kann Claude Aufgaben stellen:**

- Nexus-Regel aktualisieren.
- Architekturentscheidung vorbereiten.
- Connexio/Gateway/Agent-Änderung bewerten.
- Drift im Nexus dokumentieren.

Aufgaben werden als Outbox-Datei oder Task-Manifest formuliert. Für R2
muss klar sein: was ist nur Vorschlag, was wäre Umsetzung, welche Freigabe
fehlt.

## Task-Scope (Peer-Tasks)

Jeder Multi-Agent-Task nennt:

- `allowed_paths`
- `forbidden_paths`
- `claimed_paths`
- `base_commit`
- `risk_level`
- `machine`

Agenten dürfen nicht stillschweigend über den Scope hinausgehen. Bei
Knappheit: `blocked` setzen oder Review anfordern. Vollständige
Pflichtfelder: `_rules/tasks.md`.

## Review-Regeln

Review ist Pflicht bei:

- R2.
- Architekturentscheidungen.
- Sync-/Cron-/Connexio-/Agent-Änderungen.
- neuen Schreiboberflächen.
- Security-, Secret- oder Deploy-Themen.

Review-Ergebnis (Verdict): `approved` | `rejected` | `blocked` |
`needs_human_approval`.

## Outbox-Konvention

- **Ort:** `~/Cortex/projects/_ai-cooperation-outbox/`.
- **Dateiname:** `YYYY-MM-DD_<sender>-to-<receiver>_<topic>.md`.
- **Nach Abschluss:** nach `_done/` verschieben. Vorschlag: 12 Monate
  behalten, danach komprimieren/archivieren.

**Outbox-Status:** Markdown-basierte Übergaben gelten als Vorschlag, nicht
als autoritative Policy. Mit Lean v3 (Spec `specs/cortex-lean-v3/`) wird
die Outbox durch Connexio-`handoff_to_agent` ersetzt — Übergang läuft
bis 2026-06-12.

## Connexio (Peer-Kanal)

Connexio bleibt für Kontext **read-only**. Eine spätere Write-Surface
darf nur Task-/Review-Status schreiben:

- `create_task`
- `update_task_status`
- `append_review`
- `list_open_tasks`

Kein generisches `write_file`. Schreibziele sind hardcoded. Audit-Log
ist Pflicht.

## Multi-Device

GitHub bleibt Single Source of Truth. Maschinen dürfen Tasks locken,
solange keine Sync-Konflikte entstehen. Mindestregeln:

- `base_commit` festhalten.
- `machine` festhalten.
- `claimed_paths` festhalten.
- Bei Divergenz stoppen.
- Keine automatischen Merges.
- Keine Nexus-Umsetzung ohne Freigabe.

Lease-Mechanik: `agent/connexio/lease_store.py`.

## Verbotene Abkürzungen

- Boundary-Regeln nicht informell umgehen.
- Keine Connexio-Whitelist-Erweiterung für sensible Tags.
- Keine Projektarbeit direkt in Nexus ablegen.
- Keine R2-Änderung als „kleinen Fix" tarnen.
- Kein automatisches Aufräumen von Wissensdateien.

## Pilot

Pilot für das Kooperationsmodell:

- `projects/Cortex-Web`
- `projects/_ai-cooperation-outbox`
- `Nexus/specs/claude-codex-cooperation`

Technische Integration kommt erst nach dokumentarischer Stabilisierung.

## Querverweise

- Multi-AI-Boundaries (andere KIs): `_rules/multi-ai-boundaries.md`.
- Risiko-Level: `_rules/risk-levels.md`.
- Task-Format: `_rules/tasks.md`.
- Connexio-Architektur: `specs/cortex-lean-v3/`, `agent/connexio/`.
