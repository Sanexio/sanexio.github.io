# Multi-AI Boundaries

> Wie andere KIs (Codex, Cursor, Cline, Continue, Gemini-CLI, künftige)
> sich gegenüber dem Nexus-Kern zu verhalten haben. Die engere
> Kooperationsregel zwischen Claude und Codex liegt in
> `_rules/ai-cooperation.md`.

## Grundsatz

`~/Cortex/Nexus/` ist der portable Wissens-, Regel- und Agentenkern.
Dieser Bereich bleibt besonders geschützt. Andere KIs dürfen den
Nexus-Kern **nicht frei direkt bearbeiten**. Sie dürfen aber kontrolliert
Vorschläge, Reviews und später freigegebene Branch-/PR-Entwürfe liefern.

Die Boundary schützt den Nexus-Kern vor unkontrolliertem
Filesystem-Schreiben. Sie verbietet nicht die Zusammenarbeit.

## Harte Schreibgrenzen

**`~/Cortex/Nexus/` ist R2:**

- Analyse erlaubt, wenn durch User, Claude oder Task-Manifest beauftragt.
- Vorschläge erlaubt.
- Reviews erlaubt.
- **Umsetzung nur nach Freigabe durch Dr. Stracke.**
- Freier direkter Filesystem-Schreibzugriff durch Codex/Cursor/Cline/andere
  bleibt verboten.

Keine KI darf Nexus-Kern-Änderungen als Routine-Projektarbeit behandeln.

**`~/Cortex/projects/<projekt>/` ist R1:**

- Claude und Codex dürfen schreiben.
- Sequenzielle Bearbeitung, kein Parallel-Edit an denselben Pfaden.
- Task-Scope, Git-Status und Projektregeln müssen eingehalten werden.

**R3 bleibt immer freigabepflichtig** (siehe `agent/modes/tier3.md`).

## Erlaubte Nexus-Vorschlagswege

Erlaubt:

- Outbox-Datei unter `~/Cortex/projects/_ai-cooperation-outbox/`.
- Review-Kommentar in projektlokalem `.cortex/reviews/`.
- Task-Manifest in projektlokalem `.cortex/tasks/`.
- Später: Branch oder PR für Nexus-Vorschlag, aber nur nach expliziter
  Freigabe pro Task.

Nicht erlaubt:

- Direkter Nexus-Edit ohne Freigabe.
- Direkter Merge durch Codex.
- Automatischer Nexus-Push ohne Approval-Marker.
- Umgehen der Boundary durch relative Pfade wie `../Nexus/...`.

## Connexio (Lese-Surface)

Connexio bleibt **read-only** für Kontext. Es darf keine freie
Dateischreib-API bereitstellen.

Eine spätere Connexio Write-Surface darf nur Task-/Review-Status
schreiben:

- Hardcoded Zielpfade.
- Audit-Log Pflicht.
- Keine Whitelist-Erweiterung für sensible Inhalte zur Laufzeit.
- Keine generische `write_file`-Operation.

Implementierung: `agent/connexio/http_server.py` (Loopback REST),
`agent/connexio/mcp_server.py` (MCP-Tools).

## Workspace-Trust

Nicht-Claude-KIs werden normalerweise mit dem Projekt-Wurzelpfad als
Workspace gestartet, **nicht** mit `~/Cortex/`.

Beispiel:

```bash
cd ~/Cortex/projects/Cortex-Web
codex .
```

Wenn Codex ausnahmsweise in `~/Cortex/` arbeitet, gelten diese
Boundary-Regeln statt der impliziten Workspace-Abgrenzung.

## Git und Sync

GitHub bleibt Single Source of Truth.

**Vor Schreibarbeit:**

- Git-Status lesen.
- Fremde Diffs melden.
- `base_commit` für Task festhalten.
- Bei Divergenz stoppen.

**Nach Arbeit:**

- Verifikation dokumentieren.
- Commit/Push nur innerhalb freigegebenem Risiko-Level.
- Bei R2 nur nach Freigabe.

**Kein Auto-Merge und kein stilles Auto-Rebase** bei Governance- oder
Architekturdateien.

## Entscheidungsreihenfolge bei Widerspruch

1. Dr. Stracke
2. Freigegebene Nexus-Policy (`_rules/`, `specs/`)
3. Projekt-Policy
4. Task-Manifest
5. Agent-Default

Bei unklarer Auslegung: Stop und Review anfordern.

## Was weiterhin verboten ist

- `chmod` oder Dateirechte als Boundary-Ersatz einsetzen.
- Connexio-Pfad-Whitelist für Patient-/Medizin-/Steuer-/Secret-/Auth-Inhalte
  erweitern.
- R2-Änderungen als R1-Projektarbeit deklarieren.
- Fremde lokale Änderungen zurücksetzen.
- Grenzen aufweichen, nur weil ein Agent es praktisch findet.

## Was neu erlaubt ist (gegenüber v1)

- Codex darf Nexus-Änderungen vorschlagen.
- Claude und Codex dürfen sich gegenseitig Reviews schreiben.
- Branch-/PR-Vorschläge für Nexus sind später möglich, wenn ein Task
  sie explizit freigibt.
- Die finale Nexus-Umsetzung liegt bei Dr.-Stracke-Freigabe, nicht bei
  einer Agenten-Hierarchie.

## Querverweise

- Claude-Codex-Peer-Modell: `_rules/ai-cooperation.md`.
- Risiko-Level: `_rules/risk-levels.md`.
- Stop-Bedingungen: `_rules/stop-conditions.md`.
- Connexio-Tasks/Lease-Tools: `agent/connexio/`.
