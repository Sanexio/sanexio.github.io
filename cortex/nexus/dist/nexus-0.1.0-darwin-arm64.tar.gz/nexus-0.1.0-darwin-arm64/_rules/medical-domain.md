# Medizin-Domain (Stracke-spezifisch)

> **Geltungsbereich:** Stracke-private. Hartcodierte Boundary für
> Patienten-bezogene Inhalte. In einer Public-Cortex-Variante würde
> dieses File je nach Teilnehmer-Beruf ausgetauscht oder leer bleiben.

## Praxisgemeinschaft vs. Gemeinschaftspraxis

Dr. Stracke betreibt eine **Praxisgemeinschaft**, nicht eine
Gemeinschaftspraxis. Konsequenz:

- **Keine gemeinsame Patientenakte zulässig.**
- Daten-Schnittstellen zwischen Behandler dürfen Patient-Identitäten
  nicht über die rechtliche Trennung hinweg teilen.
- Beim Schreiben von Tools/Skripten in diesem Kontext: Cross-Doctor-Joins
  sind unzulässig.

## BLOCKED_TAGS bei Connexio

Connexio-Pattern-Search (`agent/connexio/kernel.py::BLOCKED_TAGS`) filtert
Memory-/Vault-Hits mit diesen Tags aus den Ergebnissen, die andere KIs
über die MCP-Surface ziehen:

- `medizin`
- `patient`
- `steuer`
- `secret`
- `auth`
- `credential`

Diese Liste darf nicht zur Laufzeit erweitert werden (siehe
`_rules/security.md`). Strukturelle Änderung erfordert R2-Freigabe.

## DSGVO-Pflichten

- **Patient-bezogene Inhalte gehören nicht in den Vault** — nicht in
  Markdown, nicht in Memory-DB. Anonymisierung ist Pflicht, wenn ein
  Workflow Patient-Daten berührt.
- **Patient-Mails** als Tier-3-Hardstop (Kategorie 3: externe Empfänger)
  in `agent/modes/tier3.md` definiert. Keine automatischen Versendungen.
- **Patient-Datenexport** als Tier-3.
- Logs, die Patient-Inhalte berühren könnten, werden vom Sanitizer
  bevorzugt komprimiert oder anonymisiert.

## SmartQ-Integration

SmartQ ist Stracke-internes Buchhaltungs-/Quartal-Tool. Schreibops gegen
SmartQ sind R3 (Geld-Operationen Kategorie 2). Lesezugriff ist R0.

Skill: `skills/smartq-dashboard.skill` (Claude-Code-Paket).

## Querverweise

- Allgemeine Security-Regeln: `_rules/security.md`.
- Tier-3-Hardstops: `agent/modes/tier3.md`.
- Connexio-Kernel mit BLOCKED_TAGS: `agent/connexio/kernel.py`.
