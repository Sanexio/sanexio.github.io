# Tasks — State-Machine, Pflichtfelder, Pre-Flight

> Format und Lebenszyklus für Multi-Agent-/R2-Tasks. Sammelt AC §4-§6
> in einer fokussierten Datei.

## State-Machine

Erlaubte Statuswerte:

- `proposed` — Aufgabe vorgeschlagen, noch nicht angenommen.
- `accepted` — Scope, Risiko, Pfade und Base-Commit sind akzeptiert.
- `in_progress` — genau ein Agent/eine Maschine arbeitet.
- `blocked` — Agent stoppt mit Grund.
- `review_requested` — Ergebnis liegt zur Prüfung vor.
- `approved` — Review/Freigabe erteilt.
- `done` — abgeschlossen und dokumentiert.
- `rejected` — verworfen mit Begründung.

## Erlaubte Übergänge

```
proposed         → accepted | rejected
accepted         → in_progress | rejected
in_progress      → blocked | review_requested
blocked          → accepted | rejected
review_requested → approved | rejected
approved         → done
done             → (terminal)
rejected         → (terminal)
```

## Pflichtfelder

Jede Multi-Agent-/R2-Task trägt:

- `id`
- `title`
- `created_by`
- `assigned_to`
- `repo`
- `scope`
- `risk_level`
- `allowed_paths`
- `forbidden_paths`
- `claimed_paths`
- `base_commit`
- `machine`
- `status`
- `requires_human_approval`
- `acceptance_criteria`
- `evidence`
- `result`
- `next_action`
- `updated_at`

`allowed_paths` ist Pflicht für:

- R2-Tasks.
- Multi-Agent-Tasks.
- Multi-Device-Tasks.
- Tasks mit Commit/Push.

Für einfache R1-Projektarbeit darf `allowed_paths` das Projekt-Repo als
Ganzes sein.

## Persistenz

- **Lokal:** SQLite `_memory/tasks.db` (gitignored, pro Mac).
- **Cross-Device:** `_memory/tasks-mirror/task-<id>.json` (gitversioniert).
- **Audit:** `_memory/audit/connexio-write.jsonl` (append-only, gitignored).

Der Task-Mirror ist authoritativ — bei Konflikt zwischen lokaler DB und
Mirror gewinnt der Mirror nach Pull.

## Pre-Flight vor Schreibarbeit

Vor jeder R1/R2-Schreibarbeit:

1. Git-Status lesen.
2. Fremde oder unerklärte Diffs melden und stoppen.
3. `base_commit` notieren oder bestätigen.
4. `allowed_paths` und `forbidden_paths` prüfen.
5. Risiko-Level bestimmen.
6. Bei R2/R3 Freigabe prüfen.

**Kein Auto-Stash, kein Auto-Reset, kein Auto-Merge für fremde Arbeit.**

## Querverweise

- Risiko-Level: `_rules/risk-levels.md`.
- Stop-Bedingungen: `_rules/stop-conditions.md`.
- Verifikation vor `done`: `_rules/verification.md`.
- Connexio-Task-Surface: `agent/connexio/task_store.py`,
  `agent/connexio/mcp_server.py` (`handoff_to_agent`, `inbox_for_agent`,
  `lease_project`).
