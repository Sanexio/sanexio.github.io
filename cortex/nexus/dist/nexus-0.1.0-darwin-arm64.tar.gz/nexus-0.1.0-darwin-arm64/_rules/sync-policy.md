# Sync-Policy

> Runtime-Aggregat aller Multi-Device-Sync-Regeln. Die drei zugrunde-
> liegenden Specs (`nexus-sync-reliability`, `sync-alarm-escalation`,
> `multi-device-multi-ai` §4) bleiben als Architektur-Quellen erhalten;
> diese Datei sammelt die operativen Regeln für den täglichen Betrieb.

## Grundsatz

GitHub bleibt Single Source of Truth für Nexus (Repo `Sanexio/nexus`) und
jedes Projekt-Repo. Sync läuft ausschließlich über `git pull --ff-only`
und `git push`, niemals über filesystem-direktes Kopieren zwischen Macs.

Jeder Mac mit Cortex/Nexus pullt selbsttätig auf `main` — der LaunchAgent
`com.cortex.nexus-sync` ist Pflicht-Setup für jedes Gerät
(siehe `scripts/onboard-device.sh`).

## Pre-Pull vor Edits

Vor jedem R1/R2-Schreibvorgang in Nexus:

```bash
cd ~/Cortex/Nexus && git pull --ff-only
```

Bei Divergenz: **STOP**, nicht editieren, Lage klären (siehe Recovery).

## Auto-Sync (`nexus-sync.sh` + LaunchAgent)

Alle 5 Minuten via `com.cortex.nexus-sync.plist`:

1. **Heartbeat-Check.** Liest die Liveness aller anderen Macs aus den
   ephemeren Refs `refs/heartbeats/<host>` (seit 2026-05-24; vorher getrackte
   Dateien auf `main`). Wenn ein anderer Mac innerhalb 90 s aktiv war: Sync
   skippen, um Race zu vermeiden. Jeder Mac force-updatet nur seinen eigenen
   Ref (parentloser Commit, Timestamp = Message) → kein Multi-Writer-Konflikt,
   kein Historie-Wachstum, keine main-Commits. Die lokalen
   `.config/heartbeats/<host>.heartbeat` bleiben als Lese-Cache
   (Gateway/Doctor lesen sie) und werden nach jedem Fetch neu materialisiert.
   **Übergang:** Solange nicht alle Geräte das ref-basierte Skript fahren,
   bleiben die Heartbeat-Dateien noch getrackt (sonst bekommen alte Geräte beim
   Committen ihrer eigenen Datei einen modify/delete-Konflikt). Sie sind als
   auto-gen markiert (kein Drift-Alarm, Auto-Resolve). Das ref-basierte Skript
   hält getrackte Heartbeat-Files immer sauber (verwirft Cache-„dirt" zu
   Lauf-Beginn via `git checkout HEAD --`, materialisiert nur ungetrackte Files)
   → eingehende Löschungen sind konfliktfreie Fast-Forwards.
   **Automatische Selbst-Bereinigung:** `tools/cortex-mode/bin/heartbeat-migration-cleanup.sh`
   (von nexus-sync.sh, Abschnitt 6, aufgerufen) entfernt das EIGENE Heartbeat-File
   jedes Geräts aus dem Tracking, sobald das Gerät ref-basiert läuft + eine
   Schonfrist abgelaufen ist. Kein manueller Eingriff an den Rechnern nötig;
   schlafende Geräte bereinigen sich, sobald sie online kommen. Status/Abschluss:
   `heartbeat-migration-cleanup.sh status` (→ `_memory/health/heartbeat-migration.json`).
   Sobald „ALLE BEREINIGT": Skript + Abschnitt 6 löschbar.
2. **Branch-Check.** Auf einem Feature-Branch wird kein Auto-Merge
   versucht; Heartbeat wird trotzdem aktualisiert.
3. **Drei-Punkte-Diff** gegen `origin/main` (ahead/behind). Bei `behind > 0`:
   `git pull --ff-only` versuchen.
4. **Auto-Resolve** für Auto-generierte Files (DASHBOARD.md,
   pending-questions.md, health/sync-drift.json, …): bei Rebase-Konflikt
   wird die lokale Version übernommen.
5. **Auto-Commit-Whitelist.** Nur diese Pfade werden vom Sync-Skript
   selbst committet:
   - `_memory/logs/*.log`, `*.err`
   - `_memory/pending-questions.md`, `pending-instructions.md`
   - `_memory/health/sync-drift.json`
   - `Second Brain/00 Kontext/Dialog.md`
   - `Second Brain/10 Projekte/*.md`
   - `Second Brain/30 Tutorials/_MOC Tutorials.md`
   - `Second Brain/40 Regeln/_MOC Regeln.md`
   Alle anderen inhaltlichen Änderungen müssen manuell committet werden.
6. **Alarm** bei persistenter Divergenz (>1 h ohne Auflösung): Telegram-Push
   an User-Channel. Re-Alarm-Eskalation laut
   `specs/sync-alarm-escalation/`.

## Approval-Marker für R2-Outgoing

Mit `_memory/approvals/.enforce` aktivierst du den harten Approval-Modus:
Pushes mit Diff in R2-Pfaden (`_rules/`, `specs/`, `CLAUDE.md`,
`SYSTEM_MAP.md`, `agent/`, `gateway/`, `tools/`, `nexus-sync.sh`) werden
blockiert, wenn kein Approval-Marker
(`_memory/approvals/<task-id>.approved`) für die Task existiert.

Default-Verhalten ist weich: Lücke wird im Sync-Log gemeldet, Push läuft
durch. Hart-Modus ist die Option für Phasen erhöhter Vorsicht.

## Bei Divergenz / Stuck-State

| Symptom | Recovery |
|---|---|
| `git pull --ff-only` lehnt mit Divergenz ab | Branch-Stand mit `git log --oneline` prüfen, ungeplante lokale Commits identifizieren, bei Bedarf rebasen oder stashen. Nicht reset-hard'en, wenn Inhalt unklar ist. |
| Sync-Log zeigt `BRANCH-SKIP` über lange Zeit | Mac ist auf Feature-Branch hängengeblieben (Vorfall M5 2026-05-13). Aktion: auf `main` checkouten, FF-Pull, alten Branch klären. |
| Heartbeat eines Macs ist >24 h alt | Mac vermutlich offline oder LaunchAgent nicht geladen. Tailscale-Status prüfen, `launchctl list \| grep cortex` auf dem betroffenen Mac. |
| Approval-Marker fehlt, Push blockiert | Approval-Marker setzen (`touch _memory/approvals/<task-id>.approved`), oder Push ohne `.enforce` durchführen. |

## Querverweise — Specs

- **Architektur:** `specs/multi-device-multi-ai/00_KONZEPT.md` §4 (Sync-Layer).
- **Zuverlässigkeit:** `specs/nexus-sync-reliability/00_KONZEPT.md`
  (Heartbeat, Auto-Resolve, Whitelist-Schutz).
- **Alarm-Eskalation:** `specs/sync-alarm-escalation/00_KONZEPT.md`
  (Re-Alarm, kritischer Push bei persistentem Drift).
- **Konzept-Refactor:** `specs/architecture-refactor-2026-05/00_AUDIT.md` §C
  (Konsolidierungs-Vorschlag).

## Querverweise — Implementierung

- Sync-Skript: `nexus-sync.sh`.
- LaunchAgent-Vorlage: `com.cortex.nexus-sync.plist`.
- Onboarding: `scripts/onboard-device.sh`.
- Health-Check: `cortex-agent skill run doctor` (Sync-Check + Lease-Konsistenz).
