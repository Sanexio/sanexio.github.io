# Risiko-Level R0-R3

> **Authoritative Detail-Definition** der vier Risiko-Level. Wird von
> `_rules/AUTONOMY_CONTRACT.md` (Index) und `_rules/modes.md` (Matrix)
> referenziert.

## R0 — Read-only

Erlaubt ohne Rückfrage:

- Dateien lesen.
- `rg`, `find`, `ls`, `sed`, `cat`.
- `git status`, `git log`, `git diff`, `git remote -v`, `git branch`.
- Lokale Größen-/Strukturprüfung.

R0 ist mode-unabhängig immer frei. Es gibt keinen Grund für Stop bei R0.

## R1 — Cortex-Projektarbeit

**Scope:** Schreiben innerhalb `~/Cortex/projects/<projekt>/`.

Erlaubt ohne Rückfrage, sofern Task-Scope und Git-Zustand sauber sind:

- Schreiben in `~/Cortex/projects/<projekt>/`.
- Tests, Formatter, lokale Build-/Verify-Befehle.
- Projekt-Commits und Projekt-Pushes, wenn Projektregeln das erlauben.

Stop, wenn:

- Task würde außerhalb des Projekt-Repos schreiben.
- Git-Status zeigt fremde unerklärte Änderungen.
- Projekt-Regel verlangt Safe-/Approval-Modus.
- Deployment oder externe Wirkung fällt in R3.

## R2 — Nexus-Kern

**Scope:** alles unter `~/Cortex/Nexus/`.

Erlaubt ohne Rückfrage:

- Analyse.
- Vorschläge formulieren.
- Reviews schreiben.
- Outbox-Dateien außerhalb Nexus anlegen.

Nicht ohne Freigabe:

- Schreiben in `~/Cortex/Nexus/`.
- Änderung an Regeln, Specs, Agent, Gateway, Connexio, Sync, Cron,
  Mode-Hooks, Memory-Policy oder Device-Registry.
- Commit/Push von Nexus-Kern-Änderungen.
- Branch-/PR-Vorschläge nur nach expliziter Freigabe pro Task.

R2 ist der Default-Boundary-Schutz für die Plattform — andere KIs
arbeiten standardmäßig nie schreibend in R2 (siehe
`_rules/multi-ai-boundaries.md`).

## R3 — Hochrisiko

**Immer Stop und explizite Freigabe.** Authoritative Liste:
`agent/modes/tier3.md` (Single Source seit 2026-05-16, vom Hook injiziert
und vom `golden_rules.py`-Renderer geparst).

Drei Kategorien:

1. **Zugangsberechtigungen / Secrets** — `.env`-Files, `~/.claude.json`,
   API-Keys/Bot-Tokens/Passwörter, SSH-/GPG-Keys, Keychain.
2. **Geld-Operationen** — Accounting-Systeme (SmartQ, Steuern, Banking),
   reale Rechnungs-/Patient-Kommunikation, Preisänderungen mit
   Echtgeld-Wirkung.
3. **Externe Empfänger ohne User-Schleife** — Mails/SMS/Slack an Personen
   außer Dr. Stracke, GitHub-PR-Merge in fremden Repos, Webhooks an Dritte.

Ergänzend auf Vertragsebene (nicht in tier3.md): Erweiterung von
Connexio-Whitelists für Patient-, Medizin-, Steuer-, Secret- oder
Auth-Kontexte ist ebenfalls R3.

Was **nicht (mehr)** Tier-3 ist — die Negativliste in `tier3.md`
(User-Direktive 2026-05-09, siehe `_rules/user-directives.md`).
