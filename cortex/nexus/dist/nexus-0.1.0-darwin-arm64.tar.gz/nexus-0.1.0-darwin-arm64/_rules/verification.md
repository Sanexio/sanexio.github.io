# Verifikation vor `done`

> Was vor dem Abschluss einer Task laufen muss, damit `done` gesetzt
> werden darf. Knapper Prozess, kein Audit-Theater.

## Pflicht-Checks

Vor `done`:

- **Diff prüfen.** `git diff` über alle Pfade, die die Task angefasst hat.
  Keine ungewollten Beifang-Edits.
- **Tests/Checks laufen lassen** oder begründen, warum nicht. Bei
  Projekten mit Test-Suite: laufen lassen ist Default. Bei reinen
  Doku-Änderungen reicht eine Begründung „keine Tests applicable".
- **Evidence festhalten.** Im Task-Manifest oder finalen Bericht
  protokollieren: was wurde getan, welche Outputs, welche Commits.
- **Bei R2: Review/Freigabe referenzieren.** Approval-Marker
  (`_memory/approvals/<task-id>.approved`) oder explizite User-Freigabe
  im Chat. Ohne Referenz → Stop, kein `done`.

## Verifikations-Tiefe nach Risiko

| Risiko | Minimum-Verifikation |
|---|---|
| R0 | Output-Check. |
| R1 | Tests laufen lassen, Diff zeigen. |
| R2 | Smoke-Test des betroffenen Subsystems + Diff + Approval-Referenz. |
| R3 | Plus: explizite User-Bestätigung im Chat + Erwähnung im Welle-Ende-Debrief. |

## Welle-Ende-Debrief als Verifikation

Der Welle-Ende-Debrief (`agent/modes/autonomy.md`) ist Teil der
Verifikation. Pflichtblock: **WAS GEMACHT** (faktisch). Optional:
**WAS GELERNT** (mit Anker, siehe `_rules/lesson-anchors.md`) und
**STRATEGISCHE WAHLEN**.

Live-Deploys und andere R3-relevante Operationen müssen IMMER im
Welle-Ende-Debrief erwähnt werden, auch wenn sie unter
„erlaubt ohne Frage" fallen.

## Querverweise

- Stop-Bedingungen während der Arbeit: `_rules/stop-conditions.md`.
- Lesson-Anker im Debrief: `_rules/lesson-anchors.md`.
- Skill `session_end` rendert den Debrief mit Anker-Validierung
  (`agent/skills/builtin/session_end.py`).
