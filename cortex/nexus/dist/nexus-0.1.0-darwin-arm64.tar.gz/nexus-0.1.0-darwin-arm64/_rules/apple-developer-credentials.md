# Apple-Developer-Credentials — geräteübergreifend

> **Tier-C-Regel.** Apple-ID + Team-ID + Notarization-Profile-Setup.
> Verifiziert in Welle 2.7b (Cortex-Plattform, 2026-06-01).
> Speicherung: alles im macOS-Keychain, **nichts** in Files/Repos.

## Identitäts-Anker (clusterweit gültig)

| Feld          | Wert                                                          | Wofür                                    |
|---------------|---------------------------------------------------------------|------------------------------------------|
| **Apple-ID**  | `bm@westend-hausarzt.de`                                      | Apple-Developer-Membership, App-Spec-PWs |
| **Team-ID**   | `QYC7S8YGXV`                                                  | Codesign-Authority + Notarization-Submit |
| **Sign-Identity** | `Developer ID Application: Siegbert Stracke (QYC7S8YGXV)` | `CORTEX_SIGN_IDENTITY` für `build.sh`    |

**Wichtig:** Die iCloud-Apple-ID `stracke.md@me.com` ist **nicht** die
Developer-Account-Apple-ID — sie hat **keinen Zugriff** auf die
Membership von Team-ID `QYC7S8YGXV`. `xcrun notarytool store-credentials`
mit `stracke.md@me.com` liefert HTTP 401 (Welle-2.7b-Bug auf SSMD-MacBookPro-M5,
2026-06-01 — vor der Korrektur).

## Notarization-Profile-Setup (per Mac einmalig)

Apple-Keychain ist **nicht** iCloud-synct für `notarytool`-Profile —
das Profil muss auf jedem Mac existieren, der `dist/build.sh` mit
`CORTEX_NOTARIZE=1` ausführt.

### 1. App-Specific-Password generieren

Eine **gemeinsame** App-Spec-PW reicht clusterweit (Apple-ID ist überall
dieselbe). Generierung läuft auf https://appleid.apple.com unter
`bm@westend-hausarzt.de`:

1. Anmeldung mit `bm@westend-hausarzt.de` + 2FA.
2. „Anmelden und Sicherheit" → „App-spezifische Passwörter" → „Neu".
3. Bezeichnung z.B. `Cortex Notary`.
4. **PW exakt einmal** sichtbar — sofort sichern (Passwortmanager
   und/oder direkt in `store-credentials` piped).

### 2. `xcrun notarytool store-credentials` lokal

Auf jedem Mac mit Build-Funktion (`SSMD-MacBookPro-M5`,
`SSMD-MacBookPro` Intel, `Cluster-Mini-02`, `Mac-Studio`):

```bash
xcrun notarytool store-credentials cortex-notary \
  --apple-id "bm@westend-hausarzt.de" \
  --team-id "QYC7S8YGXV" \
  --password "<app-spec-pw>"
```

Apple validiert Online, dann speichert ins Login-Keychain.
**Voraussetzung:** Login-Keychain entsperrt. Auf headless SSH-Sessions
ist es default gesperrt → entweder per `security unlock-keychain`
vorher entsperren (braucht Login-PW) oder einmal in GUI-Session
einloggen.

### 3. Verifikation

```bash
xcrun notarytool history --keychain-profile cortex-notary
```

Sollte „Successfully received submission history" + Liste der
Submissions liefern (oder „No submission history." wenn noch nichts
gesubmittet wurde — beides ok).

## Build-Aufruf (Welle 2.7b und folgende)

```bash
cd ~/Cortex/projects/cortex-cli   # oder Nexus, oder anderes Bun-Bundle
CORTEX_SIGN_MODE=dev-id \
CORTEX_SIGN_IDENTITY="Developer ID Application: Siegbert Stracke (QYC7S8YGXV)" \
CORTEX_NOTARIZE=1 \
CORTEX_NOTARIZE_PROFILE=cortex-notary \
bash dist/build.sh
```

## Bekannte Issues

### arm64-Codesign-Issue (Bun-Compile)

Bun-Compile-Binaries auf arm64 lassen sich heute nicht zuverlässig mit
Developer-ID-Codesign signieren — `codesign --remove-signature` +
`codesign --sign --force --deep --options runtime --timestamp` bricht
mit „main executable failed strict validation". x64 funktioniert.
Persistenz-Anker: `memory/feedback_bun_compile_arm64_codesign_issue.md`.

→ `cortex-cli` arm64 ist Welle 3.6c-blocked; Nexus arm64 funktioniert
über TS-Wrapper-Strategie.

### spctl-Reject für CLI-Mach-O ohne Bundle

`spctl --assess --type execute` lehnt nackte Mach-O-CLI-Binaries trotz
korrekter Notarization ab („the code is valid but does not seem to be
an app"). Kein Bug — Gatekeeper-Execute-Pfad ist auf .app-Bundles
ausgelegt. Verifikation läuft über `codesign --verify` + `notarytool
history`. `xcrun stapler staple` funktioniert nicht auf nackten Mach-O.
Persistenz-Anker: `memory/feedback_spctl_reject_normal_for_macho_cli.md`.

## Tier-3-Klassifikation

Apple-Developer-Credentials sind **nicht Tier-3** (Tier-3-Rev 2026-05-31:
nur Bank/Bezahl). Apple-ID, Team-ID, App-Spec-PWs, Codesign-Identities
und Keychain-Profile dürfen frei gelesen, geschrieben, im Keychain
gespeichert und in `~/Cortex/` verwendet werden. Keychain-Speicherung
bleibt die Best-Practice (PWs nicht in Klartext-Files committen).
