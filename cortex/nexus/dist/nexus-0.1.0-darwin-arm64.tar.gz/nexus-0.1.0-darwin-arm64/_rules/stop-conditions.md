# Stop-Bedingungen

> Vollständige Liste der Trigger, bei denen ein Agent **sofort stoppen** muss.
> Mode-unabhängig. Autonomy.md zeigt eine verkürzte Default-Liste; safe.md
> ergänzt mode-spezifische Trigger (Phase-2-Approval-Gate). **Diese Datei ist
> die authoritative Vollliste.**

## Hardstop-Trigger (alle Modes)

1. **R3-Berührung.** Jede Operation, die in eine der drei Tier-3-Kategorien
   fällt (`agent/modes/tier3.md`). Tool-Call nicht auslösen, User informieren,
   explizite Freigabe abwarten.
2. **R2-Umsetzung ohne Freigabe.** Schreibvorbereitung in `~/Cortex/Nexus/`,
   ohne dass eine Task-/User-Freigabe vorliegt.
3. **Dirty Worktree mit fremdem Diff.** Git-Status zeigt Änderungen, die
   nicht vom aktuellen Agenten stammen und nicht erklärt sind.
4. **Git-Divergenz.** Lokaler Branch und Remote sind divergiert (nicht nur
   ahead). Pre-Pull war nicht fast-forward.
5. **Allowed-Paths-Verletzung.** Task will außerhalb der `allowed_paths`
   schreiben.
6. **Test/Verify scheitert und Fix liegt außerhalb Scope.** Fortfahren
   würde Scope-Drift sein.
7. **Architektur-Verzweigung.** Zwei plausible Architekturpfade, ohne dass
   eine freigegebene Entscheidung vorliegt.
8. **Projekt-vs.-Nexus-Widerspruch.** Projekt-Regel und Nexus-Policy
   kollidieren, keine eindeutige Auflösung.
9. **Token-/Kontext-Limit.** Verifikation kann nicht mehr sorgfältig laufen.

## Mode-spezifische Trigger

### Autonomy-Mode (zusätzlich)

- **Echte Ambiguität** (zwei plausible Pfade — nicht „könnte schiefgehen",
  sondern „beide sind sinnvoll").
- **Aufgabe erledigt** → Welle-Ende-Debrief.

### Safe-Mode (zusätzlich)

- **Phase-2-Approval-Gate** (immer, vor jeder Phase-3-Umsetzung).
- **Taktische Wahl** mit 2-3 plausiblen Pfaden → Optionen-Liste, dann
  warten.
- **Lern-Anlass** → WAS/WARUM/BEDEUTUNG-Erklärung vor Fortsetzung.
- **Konsistenz-Fehler in Phase 4** → STOP, Fix-Vorschlag, dann fortfahren.
- **WAS GELERNT ohne Persistenz-Anker** → STOP, erst Anker setzen oder als
  `(ephemer)` markieren (siehe `_rules/lesson-anchors.md`).

## Anti-Drift — Verbotene Phrasen im Autonomy-Mode

Diese Phrasen signalisieren unbeabsichtigtes Pre-Op-Verhalten und sind
verboten in autonomy:

- „Soll ich …?"
- „Möchtest du, dass ich …?"
- „Bevor ich anfange, …"
- „Welche Option …?" / „Option (a) … oder (b) …?" am Welle-Ende
- „Hier ist mein Plan, bevor ich anfange:"
- „Strategie:" / „Plan:" / „Mein Vorgehen:" als Pre-Op-Block
- „Ich werde nun …" (Pre-Op-Ankündigung)
- „Wenn du möchtest, kann ich auch …"

Verbotene Strukturen:

- Mehrzeilige Pre-Op-Erklärungsblöcke vor Tool-Calls (erlaubt:
  1-Zeilen-Phasenmarker).
- Numerierte Optionen-Listen am Welle-Ende ohne echte Ambiguität.
- Volltext-Wiederholung von Tool-Outputs nach Tool-Call.

In Safe-Mode sind Pre-Op-Erklärungen explizit erlaubt (WAS/WARUM/BEDEUTUNG).

## Verhalten bei Stop

1. Tool-Call nicht auslösen.
2. User informieren: was, warum gestoppt, welche Optionen.
3. Auf Freigabe oder Korrektur warten.
4. Bei Tier-3: zusätzlich im Welle-Ende-Debrief explizit erwähnen.

## Querverweise

- Tier-3-Detail: `agent/modes/tier3.md`.
- Risiko-Level: `_rules/risk-levels.md`.
- Mode-Briefings: `agent/modes/autonomy.md`, `agent/modes/safe.md`.
- Verifikation vor `done`: `_rules/verification.md`.
