# Projekt-Index

> Geräte-Zuordnung ist NICHT hier gepflegt — SSOT ist `.config/devices.json`.
> Diese Tabelle enthält Projekt-Status + Klassifikation (entschieden 2026-05-31
> in `specs/cortex-platform/03_PROJECT_OSS_CLASSIFICATION.md`).

**Klassifikation:** 🟢 OSS · 🔒 proprietär · 🏠 privat · ⚙️ SPLIT (Framework OSS + Tenant privat)

| Projekt                  | Repo / Pfad                                      | Klass. | Status            |
|--------------------------|--------------------------------------------------|--------|-------------------|
| **Cortex-Plattform** *(Meta)* | `specs/cortex-platform/`                    | —      | 📐 Vision-Spec — §10-Entscheidungen 2026-05-31 final, §10.1-Klassifikation 2026-05-31 final |
| **cortex-mobile** *(CL-Stub)* | `specs/cortex-mobile/`                      | ⚙️     | 🌱 Stub seit 2026-05-31 — App-Code proprietär, Slot-Mechanik OSS-Kandidat Phase 6 |
| **Nexus (Phoenix)**      | `Sanexio/nexus`                                  | 🔒     | 🏃 aktiv — heute public, bis Build-Pipeline läuft, dann private |
| **Cortex-Web Framework** | `Sanexio/cortex-web`                             | 🟢     | 🏃 aktiv — Praxiswebseite-Teil bleibt OSS; Welle 1.3+1.5b zieht Stracke- + Juvantis-Sites raus |
| **Cortex-Web Juvantis-Slot** | (in cortex-web, wandert)                     | 🔒     | ⏳ Migration nach sanexio-tenant ausstehend |
| **Sanexio-Tenant**       | `Sanexio/sanexio-tenant` (🔒 privat)             | 🔒     | 🏃 aktiv — Stracke-Tenant-Daten, Inhalt-Migration Welle 1.3 ausstehend |
| **praxis-webseite Theme**| `Sanexio/praxiszentrum-theme` (heute private)    | 🟢     | 🏃 produktiv — Anonymisierungs-Welle vor public-Switch ausstehend |
| **Juvantis**             | `Sanexio/juvantis`                               | 🔒     | 🏃 in Arbeit — Cashflow-Kern, bleibt proprietär |
| **Desk** *(3. Top-Level, Quell-Projekt)* | `Sanexio/desk` · `~/Cortex/Desk` (Mac-Studio) | ⚙️     | 🏃 produktiv — Framework rausgelöst nach `cortex-desk` 2026-05-31; Tenant-Migration nach `sanexio-tenant/desk/` in Phase B |
| **cortex-desk** *(Cortex-Layer, Welle 3 Phase A)* | `Sanexio/cortex-desk` · `~/Cortex/projects/cortex-desk` | 🟢 | 🌱 Skelett 2026-05-31 (private); Regelwerk D-001..D-010 + Medizin/VSR-Schema + 9 Sub-Workflows + Sprache-Stil-Matrix + 3 Tenant-Schablonen + Tooling-Integration-Doc; Tooling bleibt Nexus-proprietär |
| **Praxis-QM** *(Quell-Projekt)* | `~/Cortex/projects/Praxis-QM` (Mac-Studio)  | ⚙️     | 🏃 produktiv — Framework rausgelöst nach `cortex-qm` 2026-05-31; Tenant-Migration nach `sanexio-tenant/qm/` in Phase B |
| **cortex-qm** *(Cortex-Layer, Welle 3 Phase A)* | `Sanexio/cortex-qm` · `~/Cortex/projects/cortex-qm` | 🟢 | 🌱 Skelett 2026-05-31 (private); Regelwerk R-001..R-007 + Workflow + 12-Themen-Schema + Tenant-Schablonen + Tooling-Integration-Doc; Tooling bleibt Nexus-proprietär |
| **file-renamer** *(Quell-Projekt)* | `~/Cortex/projects/file-renamer`         | ⚙️     | 🏃 produktiv — Framework rausgelöst nach `cortex-rename` 2026-05-31; Tenant-Migration nach `sanexio-tenant/rename-rules/` in Phase B |
| **cortex-rename** *(Cortex-Layer, Welle 3 Phase A)* | `Sanexio/cortex-rename` · `~/Cortex/projects/cortex-rename` | 🟢 | 🌱 Skelett 2026-05-31 (private); Regelwerk + Workflow + Schema + Engine-Integration-Doc; Engine bleibt Nexus-proprietär |
| **smartq-dashboard**     | `~/Cortex/projects/smartq-dashboard`             | 🏠     | 🏃 produktiv — Patient-Daten-Scope, kein Distributionswert |
| **mail-connector**       | `~/Cortex/projects/mail-connector`               | 🏠     | 🏃 lokal — Stracke-Praxis-Tunnel |
| **Telegram-Bridge**      | in `Nexus/gateway/channels/telegram` + `Nexus/tools/telegram-bridge` | 🔒 | 🏃 produktiv — Spin-Off-Kandidat „cortex-bridge" Phase 6 |
| **Gaming**               | `~/Cortex/projects/Gaming`                       | 🏠     | 🎮 Hobby          |
| **ARCHIV**               | `~/Cortex/projects/ARCHIV`                       | 🏠     | 📦 Archiv         |
| **cortex-agent**         | `~/Cortex/Nexus/agent` (Klon auf C-M-02 aufräumen) | 🔒   | 🏃 Teil von Nexus |
| **Praxis-Monitoring + praxis-com-v1-archive** | (lokal auf C-M-02)              | 🏠     | 🏃/📦 Stracke-only |

> Aktive Projekte haben in der Regel einen `SESSION_RESUME.md` als Einstiegs-
> Punkt. „Projekt fortsetzen" lädt den Resume-Kontext.
>
> **Klassifikations-Detail** (Begründung pro Projekt): siehe
> `specs/cortex-platform/03_PROJECT_OSS_CLASSIFICATION.md`.
> **Pattern Framework/Tenant-Split**: `feedback_framework_tenant_split.md`.
