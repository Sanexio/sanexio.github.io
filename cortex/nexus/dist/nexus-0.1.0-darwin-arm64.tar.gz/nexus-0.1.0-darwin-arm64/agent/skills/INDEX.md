# Skills — Index

> Auto-generierter Index aller registrierten `@skill`-Funktionen in
> `agent/skills/builtin/`. Aufruf via `cortex-agent skill run <name>`.
> Letzte Generierung: 2026-05-16 (Architecture-Refactor Priorität 2 §3).

## Übersicht

| Skill | Version | Zweck |
|---|---|---|
| `capture-lesson` | 0.1.0 | Persistiert eine Lesson als Claude-Memory-Datei und aktualisiert `MEMORY.md`. |
| `connexio` | 0.1.0 | Connexio Read-Only-Surface (healthcheck, audit-tail, server-start, mcp-cmd, keygen). |
| `cron` | 0.1.0 | Phoenix-Cron — Recipe-Loader + Tick + Tier-3-Token-Verwaltung. |
| `curator` | 0.1.0 | Memory-Curation (facts, sessions, pending-Items). |
| `decompose-project` | 0.1.0 | Liest `projects/<x>/.cortex/manifest.yaml` (Schema v1) und erzeugt Connexio-Tasks pro Subtask. dry_run=true für Vorschau. |
| `doctor` | 0.3.0 | Health-Check des Phoenix-Setups inkl. Policy/Drift/Runtime/Sync/Lease-Consistency. |
| `outbound` | 0.1.0 | Connexio Outbound — externe KIs (anthropic, openai, ollama, gemini) aufrufen. |
| `pattern-miner` | 0.1.0 | Erkennt wiederkehrende Muster aus letzten Sessions (Heuristik + optional Anthropic-API). |
| `sanitizer` | 0.3.0 | Memory-Wachstumskontrolle (VACUUM, Sessions-Archiv, Spawn-Queue-Cutoff, MEMORY.md-Cap, TTL-Migration). |
| `scheduler` | 0.1.0 | LaunchAgent-Status anzeigen (`com.cortex.*` Plists in `~/Library/LaunchAgents`). |
| `session-end` | 0.1.0 | Welle-Ende-Debrief in Memory schreiben (Cap 2 KB, Volltext-Archiv ausgegliedert). |
| `session-start` | 0.1.0 | Session-Start-Digest — pending Spawns / Tier-3 / Cron-Failures ans iPhone. |
| `spawn` | 0.1.0 | Spawn-Queue füllen/inspizieren (enqueue, list, cancel, get). |
| `tutorial-curator` | 0.1.0 | Vault-Drift-Audit (numbering, broken-links, orphans) für `Second Brain/30 Tutorials`. |

## Modul-Pfade

| Skill | Modul |
|---|---|
| `capture-lesson` | `agent.skills.builtin.capture_lesson` |
| `connexio` | `agent.skills.builtin.connexio` |
| `cron` | `agent.skills.builtin.cron` |
| `curator` | `agent.skills.builtin.curator` |
| `decompose-project` | `agent.skills.builtin.decompose_project` |
| `doctor` | `agent.skills.builtin.doctor` |
| `outbound` | `agent.skills.builtin.outbound` |
| `pattern-miner` | `agent.skills.builtin.pattern_miner` |
| `sanitizer` | `agent.skills.builtin.sanitizer` |
| `scheduler` | `agent.skills.builtin.scheduler` |
| `session-end` | `agent.skills.builtin.session_end` |
| `session-start` | `agent.skills.builtin.session_start` |
| `spawn` | `agent.skills.builtin.spawn` |
| `tutorial-curator` | `agent.skills.builtin.tutorial_curator` |

## Aufruf-Beispiele

```bash
cortex-agent skill list                              # Übersicht zur Laufzeit
cortex-agent skill run doctor                         # 10-Punkte-Health-Check
cortex-agent skill run capture-lesson --args '{...}'  # Lesson persistieren
cortex-agent skill run sanitizer                      # Logs rotieren, DB vacuumen
```

## Verbindungen zwischen Skills (vorgesehene Ketten)

Diese Skill-Sequenzen sind heute manuell, sollen aber später als
`agent/workflows/*.yaml` strukturiert werden (siehe Audit-Empfehlung
in `specs/architecture-refactor-2026-05/00_AUDIT.md` §E):

- **Welle-Ende:** `capture-lesson` (für jedes Bullet ohne Anker) → `doctor`
  (Drift-Check) → `session-end` (Debrief in Memory).
- **Session-Start:** `session-start` (Digest) → `connexio` healthcheck →
  optional `sanitizer --dry-run` (Token-Cap-Auslastung).
- **Nightly:** `sanitizer` (Vakuum + Archiv) → `tutorial-curator` (Vault-Drift) → `pattern-miner` (Recall-Hits).

## Regenerierung

Dieses File ist heute manuell generiert (Python-Introspection über
`SkillEngine.discover()`). Zukünftige Welle: Skill `skill-index` (oder
Erweiterung des `doctor`-Skills), der den Aufruf bündelt:

```bash
cortex-agent skill run skill-index    # → schreibt agent/skills/INDEX.md
```

Bis dahin: bei Skill-Änderungen Index manuell neu generieren.

## Querverweise

- Skill-Engine: `agent/skills/engine.py` (`@skill`-Decorator, Discovery,
  Run-Logger).
- Memory-Schema für Skill-Run-Tracking: `agent/memory/store.py` Tabelle
  `skill_runs`.
- Audit-Befund zur Skill-Auffindbarkeit:
  `specs/architecture-refactor-2026-05/00_AUDIT.md` §E.
