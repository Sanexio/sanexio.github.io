#!/usr/bin/env bash
# install.sh — Phoenix-Cron LaunchAgent installieren.
# Idempotent: unload + load. Pfade sind hartkodiert auf cluster-mini-02-Pfade
# (entspricht aktuellem Phoenix-Stack-Standort). Auf anderen Geraeten Plist
# kopieren und Pfade anpassen.

set -euo pipefail
LABEL="com.cortex.phoenix-cron"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/${LABEL}.plist"
DST="${HOME}/Library/LaunchAgents/${LABEL}.plist"

if [[ ! -f "${SRC}" ]]; then
  echo "Plist fehlt: ${SRC}" >&2
  exit 1
fi

# Logs-Verzeichnis sicherstellen
mkdir -p "${HOME}/Cortex/Nexus/_memory/logs"

# Wenn schon geladen, erst abwerfen
if launchctl list | grep -q "${LABEL}"; then
  echo "Unload bestehende ${LABEL}"
  launchctl unload "${DST}" 2>/dev/null || true
fi

# Kopieren + Load
cp -f "${SRC}" "${DST}"
launchctl load "${DST}"

echo "✓ ${LABEL} geladen (alle 5 min cortex-agent skill run cron --tick)"
launchctl list | grep "${LABEL}" || echo "(noch nicht in der Liste — kann 1-2 Sek dauern)"
