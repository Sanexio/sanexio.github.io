#!/usr/bin/env bash
# install.sh — Spawn-Watcher LaunchAgent installieren.
# Idempotent: unload + load. Pfade werden aus ${HOME} live abgeleitet,
# damit das Script auf jedem Mac (Cluster-Mini-02, SSMD-MacBookPro,
# SSMD-MacBookPro-M5, Mac-Studio) ohne Anpassung funktioniert.

set -euo pipefail
LABEL="com.cortex.spawn-watcher"
DST="${HOME}/Library/LaunchAgents/${LABEL}.plist"
NEXUS="${HOME}/Cortex/Nexus"

if [[ ! -d "${NEXUS}" ]]; then
  echo "Nexus fehlt: ${NEXUS}" >&2
  exit 1
fi
if [[ ! -x "${NEXUS}/.venv/bin/python" ]]; then
  echo "Python-venv fehlt: ${NEXUS}/.venv/bin/python" >&2
  echo "Erst venv anlegen: cd ${NEXUS} && uv sync" >&2
  exit 1
fi

mkdir -p "${HOME}/Library/LaunchAgents"
mkdir -p "${NEXUS}/_memory/logs"

# Claude-Bin entdecken — auf manchen Macs in NVM/.local installiert,
# nicht im LaunchAgent-Standard-PATH erreichbar.
CLAUDE_BIN="$(command -v claude 2>/dev/null || true)"
if [[ -z "${CLAUDE_BIN}" ]]; then
  for cand in \
    "${HOME}/.claude/local/claude" \
    "${HOME}/.npm-global/bin/claude" \
    "/opt/homebrew/bin/claude" \
    "/usr/local/bin/claude" \
    ${HOME}/.nvm/versions/node/*/bin/claude; do
    if [[ -x "${cand}" ]]; then
      CLAUDE_BIN="${cand}"
      break
    fi
  done
fi
if [[ -z "${CLAUDE_BIN}" ]]; then
  echo "WARN: claude-CLI nicht gefunden — spawn_watcher wird beim ersten Pick failen." >&2
  CLAUDE_BIN="claude"
fi
CLAUDE_DIR="$(dirname "${CLAUDE_BIN}")"

if launchctl list | grep -q "${LABEL}"; then
  echo "Unload bestehende ${LABEL}"
  launchctl unload "${DST}" 2>/dev/null || true
fi

# Heuristik: Laptops ("macbook" im Hostname) bekommen `caffeinate -i`
# als Wrapper, damit der Mac nicht in Idle-Sleep geht waehrend der
# Watcher pollt. Desktops (Mini, Studio) brauchen das nicht.
HOSTNAME_LC="$(hostname -s | tr '[:upper:]' '[:lower:]')"
PROGARGS=""
if [[ "${HOSTNAME_LC}" == *macbook* ]]; then
  echo "  ↳ Laptop erkannt — caffeinate -i wird im LaunchAgent injiziert"
  PROGARGS="        <string>/usr/bin/caffeinate</string>
        <string>-i</string>
        <string>${NEXUS}/.venv/bin/python</string>"
else
  PROGARGS="        <string>${NEXUS}/.venv/bin/python</string>"
fi

cat > "${DST}" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>${LABEL}</string>

    <key>ProgramArguments</key>
    <array>
${PROGARGS}
        <string>-m</string>
        <string>agent.connexio.spawn_watcher</string>
        <string>--interval</string>
        <string>30</string>
    </array>

    <key>RunAtLoad</key>
    <true/>

    <key>KeepAlive</key>
    <true/>

    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>${NEXUS}/.venv/bin:${CLAUDE_DIR}:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin</string>
        <key>PYTHONPATH</key>
        <string>${NEXUS}</string>
        <key>CORTEX_CLAUDE_BIN</key>
        <string>${CLAUDE_BIN}</string>
    </dict>

    <key>WorkingDirectory</key>
    <string>${NEXUS}</string>

    <key>StandardOutPath</key>
    <string>${NEXUS}/_memory/logs/spawn-watcher.out.log</string>

    <key>StandardErrorPath</key>
    <string>${NEXUS}/_memory/logs/spawn-watcher.err.log</string>

    <key>ProcessType</key>
    <string>Background</string>

    <key>ThrottleInterval</key>
    <integer>10</integer>
</dict>
</plist>
PLIST

launchctl load "${DST}"

echo "✓ ${LABEL} geladen auf $(hostname -s) (KeepAlive, pollt spawn-queue.db alle 30 s)"
echo "  CORTEX_CLAUDE_BIN=${CLAUDE_BIN}"
sleep 1
launchctl list | grep "${LABEL}" || echo "(noch nicht in der Liste — kann 1-2 Sek dauern)"
