# Tier-3 Hardstops (minimal — Revision 2026-05-31)

> **Mode-unabhängig.** Gilt in Autonomy und Safe Mode.
>
> User-Direktive 2026-05-31: „Freigaben innerhalb von Cortex und Nexus
> sind erteilt, hier musst du nicht nachfragen. Einzige zwingende
> Ausnahme: Bank und Bezahlinformationen."
>
> Diese Revision ersetzt die alte 3-Kategorien-Liste (Secrets, Geld,
> externe Empfänger). Nur noch **eine** Kategorie bleibt Hardstop.

## Einzige Tier-3-Kategorie: Bank- und Bezahlinformationen

Operationen, die **echte Geldbewegung auslösen** oder Bank-/Bezahl-Daten
**aktiv schreiben/senden**. Vor einer solchen Operation: **STOP**, User
informieren, explizite Freigabe, dann ausführen.

Konkret:

- Schreibops in Accounting-Systeme mit Echtgeld-Wirkung (SmartQ
  invoice/charge, Steuer-Submit, Banking-Transfer-Aufrufe).
- Rechnungs-PDF-Versand an Patienten/Kunden (real money out).
- Preisänderungen in Live-Shops mit Echtgeld-Wirkung.
- Bank-API-Calls für Transfer, Lastschrift, Kreditkartenbelastung.
- Bezahl-CLI-Aufrufe (Stripe, PayPal, SEPA-Tools) mit Schreib-Effekt.

**Lesen** von Banking-/Buchhaltungs-Daten ist nicht Tier-3
(Buchhaltung braucht das ständig).

## Was ausdrücklich NICHT (mehr) Tier-3 ist

Alle folgenden Operationen sind in `~/Cortex/` und `~/Cortex/Nexus/`
**frei und ohne Rückfrage**:

- `.env`-Files (lesen, schreiben, überschreiben).
- `~/.claude.json` (MCP-Registrierung, Auth-Tokens).
- API-Keys / Bot-Tokens (lesen, schreiben, im Repo handhaben — Sicherung
  via `.gitignore` ist Verantwortung des Setups, nicht von Tier-3).
- SSH-/GPG-Keys (generieren, rotieren).
- Keychain-Einträge.
- `git push`, `--force`, `reset --hard`, `rebase`, `branch -D`.
- Live-Deploys eigener Projekte (Production-Push).
- WP-Admin-Schreibops auf Stracke-Domains.
- Figma-Edits, Google-Drive-Lösch-/Move-Ops auf User-eigenen Files.
- E-Mail/Slack/SMS-Versand (auch an Dritte — wenn der Aufgabenkontext
  das vorsieht, ist es Teil der Aufgabe).
- Patient-Datenexport an Dritte → unterliegt **DSGVO/Medical-Domain**,
  nicht Tier-3; siehe `_rules/medical-domain.md`.
- GitHub-Issue-Close / PR-Merge auch in fremden Repos.
- Telegram-Bridge-Sendungen.
- Sub-Agent-Delegation, WebFetch, WebSearch, lokale Skripte.

## Was bei Tier-3-Trigger passiert

1. Tool-Call NICHT auslösen.
2. User informieren: was würde passieren, warum es Tier 3 ist, was die
   Alternative wäre.
3. Auf explizites Go („push", „delete", „send", „yes", „transfer")
   warten.
4. Erst nach Freigabe ausführen.
5. Welle-Ende-Debrief: Tier-3-Op explizit erwähnen.

## Auto-Mode + Tier-3

Auto-Mode hebt Tier-3 NICHT auf. Aber Tier-3 ist jetzt extrem eng:
**nur** echte Geldbewegung. Alles andere ist erlaubt.

## Andere Schutzschichten (nicht Tier-3, aber bleiben)

- **Multi-AI-Boundaries** (`_rules/multi-ai-boundaries.md`): andere KIs
  (Cursor, Cline, Continue, Gemini-CLI) dürfen Nexus-Kern nicht
  schreiben — das ist KI-Grenze, nicht Tier-3.
- **R0–R3-Risiko-Level** (`_rules/risk-levels.md`): R-Level bleiben für
  Task-Manifeste relevant. Tier-3 ist die *Operations-Klassifikation*,
  R3 die *Task-Klassifikation* — überlappen weitgehend, aber nicht 1:1.
- **Medical-Domain** (`_rules/medical-domain.md`): DSGVO, Patient-Tags.
  Eigene Regelung, nicht Tier-3.
- **Distribution-Guards** (`tools/cortex-mode/git-hooks/`): pre-commit /
  commit-msg / pre-push erzwingen `Distribution:`-Block bei
  distribution-sensitiven Files.
