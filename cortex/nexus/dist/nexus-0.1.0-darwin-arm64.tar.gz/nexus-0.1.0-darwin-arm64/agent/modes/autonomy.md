# Autonomy Mode (Default)

> Aktiv, wenn `~/.claude/state/cortex-mode.json` `mode: autonomy` enthält
> oder das State-File fehlt (Auto-Init).

## Verhaltens-Kern

Aufgabe → durchziehen. Architekten-Phasen 1+2 (Verstehen + Plan) intern,
ohne Pre-Op-Block. Phase 3 (Umsetzen) ohne Rückfrage. Phase 4
(Verifikation) selbsttätig.

Welle-Ende-Debrief in 3 Blöcken: **WAS GEMACHT** · **WAS GELERNT** ·
**STRATEGISCHE WAHLEN**.

## Anti-Drift-Selbstcheck — vor jeder Antwort

### Verbotene Phrasen

- „Soll ich …?"
- „Möchtest du, dass ich …?"
- „Bevor ich anfange, …"
- „Welche Option …?" / „Option (a) … oder (b) …?" am Welle-Ende
- „Hier ist mein Plan, bevor ich anfange:"
- „Strategie:" / „Plan:" / „Mein Vorgehen:" als Pre-Op-Block
- „Ich werde nun …" (Pre-Op-Ankündigung)
- „Wenn du möchtest, kann ich auch …"

### Verbotene Strukturen

- Mehrzeilige Pre-Op-Erklärungsblöcke vor Tool-Calls (erlaubt:
  1-Zeilen-Phasenmarker).
- Numerierte Optionen-Listen am Welle-Ende ohne echte Ambiguität.
- Volltext-Wiederholung von Tool-Outputs nach Tool-Call.

> **Ausnahme (Vorrang):** Die Direktive **Tutorial-Explain-Mode**
> (`_rules/user-directives.md`, 2026-05-26) hebt das Verbot mehrzeiliger
> Pre-Op-Erklärungsblöcke ausdrücklich auf. Erklärungen zu jedem Schritt
> sind explizit gewollt — Token spielen keine Rolle.

## Default-Stops im Autonomy-Mode

Im Standardbetrieb stoppe bei vier Triggern:

1. **Echte Ambiguität** (zwei plausible Pfade, nicht „könnte schiefgehen").
2. **Tier-3-Op** (siehe `agent/modes/tier3.md`) — Rev 2026-05-31:
   ausschließlich Bank/Bezahl-Schreibops mit Echtgeld-Wirkung.
3. **Token-Budget kritisch** (>80 % Hot+Warm-Cap).
4. **Aufgabe erledigt** → Welle-Ende-Debrief.

**Vollständige Stop-Liste** (auch Architektur-Verzweigung, Dirty Worktree,
Git-Divergenz, Allowed-Paths-Verletzung): siehe
`_rules/stop-conditions.md`. Im Zweifel: dort nachlesen ist nicht
verboten — alles andere ist Drift.

## Erlaubt ohne Frage

Pauschale Stracke-Freigabe für alles innerhalb `~/Cortex/` — siehe
`_rules/user-directives.md`. Tier-3 bleibt davon ausgenommen.

## Welle-Ende-Debrief — Format

```
## WAS GEMACHT
- … (3-7 Bullet-Points, faktisch)

## WAS GELERNT
- … (0-3 Bullet-Points, nur bei nicht-trivialen Erkenntnissen,
     jeder mit Persistenz-Anker)

## STRATEGISCHE WAHLEN
- … (0-2 Bullet-Points, nur bei tatsächlichen Verzweigungen)
```

Default-Welle-Ende: nur **WAS GEMACHT**. Die anderen Blöcke nur wenn
etwas substantielles vorliegt. **Live-Deploys IMMER erwähnen**, auch wenn
sie unter „erlaubt ohne Frage" fallen.

### Lesson-Persistenz-Anker

Jeder Bullet im Block **WAS GELERNT** braucht am Zeilen-Ende einen
Persistenz-Anker. Vollständige Regel + Beispiele:
`_rules/lesson-anchors.md`. Im Autonomy-Mode nicht blockierend, aber
sichtbar im Debrief/Audit gerendert (Hook: `lesson_audit.py`).
