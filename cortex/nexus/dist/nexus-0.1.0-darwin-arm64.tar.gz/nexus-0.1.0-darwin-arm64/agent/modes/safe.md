# Safe Mode

> Aktiv per `/safe-mode` oder wenn `~/.claude/state/cortex-mode.json`
> `mode: safe` enthält. Schaltet auf 4-Phasen-Architekten-Workflow um.

## Verhaltens-Kern

Vier explizit markierte Phasen pro Aufgabe. Pre-Op-Erklärungen erlaubt
(volles WAS / WARUM / BEDEUTUNG-Tripel). Optionen-Listen erlaubt.
Phase-2 ist ein **Approval-Gate** — die Loop hält und wartet auf User-OK.

## Phasen

### Phase 1 — Verstehen

- Aufgabe in eigenen Worten paraphrasieren.
- Klärungs-Fragen erlaubt (max. 3, gebündelt).
- Output: 3-5 Sätze „Verständnis-Zusammenfassung".

### Phase 2 — Plan (APPROVAL-GATE)

- Konkrete Schritte als nummerierte Liste, mit Datei-Pfaden.
- Kritische Dateien benennen (zu erstellen/zu ändern).
- Optionen darstellen, wenn 2-3 plausible Pfade existieren.
- **STOP** — auf User-Bestätigung warten („go", „ok", oder spezifische
  Korrekturen).
- Vor Bestätigung kein einziger Schreib-Tool-Call.

### Phase 3 — Umsetzen

- Erst nach Phase-2-Freigabe.
- Pro nicht-trivialer Edit: kurze 1-Zeilen-Begründung
  („**Phase 3 → Schritt 4:** Lege X an, weil Y.").
- Bei Abweichungen vom Plan: kurz erklären, dann fortfahren.

### Phase 4 — Verifikation

- Konsistenz-Check zwingend: Cross-Page, Cross-Sprache, Tests
  (R1-Verifikation).
- Smoke-Test ausführen, Resultat zeigen.
- Vor „fertig"-Meldung: Ausgabe der relevanten Befehle und Outputs.
- Detail-Checks: `_rules/verification.md`.

## Stops im Safe Mode

1. **Phase-2-Plan** (Approval-Gate, immer).
2. **Tier-3-Op** (siehe `agent/modes/tier3.md`, immer).
3. **Taktische Wahl** mit 2-3 plausiblen Pfaden → Optionen-Liste, dann
   warten.
4. **Lern-Anlass** → WAS/WARUM/BEDEUTUNG-Erklärung.
5. **Konsistenz-Fehler in Phase 4** → STOP, Fix-Vorschlag, dann fortfahren.
6. **WAS GELERNT ohne Persistenz-Anker** → STOP, erst Anker setzen oder
   als `(ephemer)` markieren (`_rules/lesson-anchors.md`).

Vollständige mode-übergreifende Stop-Liste: `_rules/stop-conditions.md`.

## NICHT erlaubt im Safe Mode

- Direkt-Umsetzung ohne Phase-2-Approval.
- Mehrere Schreib-Ops ohne Diff-Show.
- Multi-Step-Pläne ohne Zwischen-Approval.
- Stillschweigendes Commit ohne Phase-4-Verifikation.

## Welle-Ende-Debrief — Lesson-Persistenz

Jeder Bullet im Block **WAS GELERNT** braucht am Zeilen-Ende einen
Persistenz-Anker. Vollständige Regel + Beispiele:
`_rules/lesson-anchors.md`. Im Safe-Mode **blockierend**: ohne Anker ist
der Welle-Ende-Debrief nicht abschließbar.

## Wechsel-Befehle

- `/autonomy-mode` → zurück auf Default.
- `/cortex-mode` → aktuellen Stand anzeigen.
- Trigger-Worte „Autonomy Mode" / „Safe Mode" im Chat werden auch erkannt.
