---
name: Dr. Stracke
role: Internist, Praxisinhaber, Sanexio GmbH
language: Deutsch
---

# User-Profil — Dr. Stracke

Internist mit eigener Praxis (Praxisgemeinschaft, **nicht** Gemeinschaftspraxis —
keine gemeinsame Patientenakte zulässig). Inhaber Sanexio GmbH.

## Geräte-Setup

**Single Source of Truth:** `.config/devices.json`. Diese Datei ist
maßgeblich für Hostname, Rolle, Projekte, Tailscale-Mesh-Daten.

Sprachgebrauch: „MacProIntel" = SSMD-MacBookPro · „Home-Mac" = Cluster-Mini-02.

## Arbeits-Präferenzen

- Antworten in vollständigem Hochdeutsch, keine Umgangssprache.
- Code-Kommentare in Englisch, User-Kommunikation in Deutsch.
- Local-First: Code + Content immer zuerst lokal, dann selektiver Push live.
- Hard-Delete statt Trash bei Cleanups (mit Backup-Heuristik <7 Tage geschützt).
- Bei Sprint-Freigaben: durchziehen ohne Zwischenfreigaben (Autonomy-Mode).
- Vertraue „fertig"/„erledigt"-Meldungen — nicht reflexartig nachverifizieren.
- Regelmäßige Status-Signale bei Operationen >30 Sekunden.

## Domänen-Kontext

- **Medizin** — Innere Medizin, Diagnostik, Befund-Handling.
- **Steuer/Buchhaltung** — SmartQ, Sanexio-Accounting.
- **Web-Stack** — WordPress (Blocksy/Praxis-Webseite), TypeScript/Bun, Python.
- **Tooling** — Obsidian (Vault `Second Brain/`), Figma, LocalWP, GoDaddy/cPanel-Hosting.

## Querverweise

- Sicherheits-Regeln (Tokens, Secrets): `_rules/security.md`.
- Medizin-Domain (DSGVO, Patient-Tags): `_rules/medical-domain.md`.
- User-Direktiven (Pauschal-Freigabe in `~/Cortex/`): `_rules/user-directives.md`.
- Geräte-Registry: `.config/devices.json`.
