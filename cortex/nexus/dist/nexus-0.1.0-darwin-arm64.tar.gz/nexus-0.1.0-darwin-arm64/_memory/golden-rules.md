# Goldene Regeln (Essenz, Lean v3)

> **Aggregat-Snapshot** für Connexio-MCP-Consumer (`get_golden_rules()`).
> Dieses File ist **kein Single-Source-of-Truth**. Die Quellen sind:
>
> - **Tier-3:** `agent/modes/tier3.md` (authoritativ, vom Hook injiziert,
>   vom Python-Renderer geparst).
> - **Wiederholungsfehler GF-001..GF-007:** `agent/memory/golden_rules.py`
>   (REPEAT_ERRORS-Konstante).
> - **LL→R-Mapping:** historische Querreferenz (Phoenix-Reset 2026-05-08),
>   wird hier konserviert.
>
> Wenn `tier3.md` oder die Bug-Patterns geändert werden, muss dieses File
> regeneriert werden (TODO: Skill `curator regenerate golden-rules`).
>
> **Stand:** 2026-05-16. Single-Source-Refactor abgeschlossen.

## Tier-3-Hardstops

Operationen, bei denen der Agent immer stoppen und auf explizite User-Freigabe
warten muss — mode-unabhängig.

- **Geld-Operationen** — Accounting, SmartQ, Steuern, Banking.
- **Drittsystem-Schreibops an externe Empfänger** — Mails/SMS/Slack an Personen
  außer Dr. Stracke; Schreibops auf fremde GitHub-Repos; PR-Merge in fremden
  Repos.
- **Secret-Mutationen** — `.env`-Files überschreiben oder neu anlegen,
  `~/.claude.json` schreiben, API-Keys/SSH-Keys/Passwörter committen oder
  loggen, Keychain-Einträge ändern.

**Was NICHT (mehr) Tier-3 ist** (User-Direktive 2026-05-09, pauschale Freigabe
in `~/Cortex/`):

- Destruktive Git-Ops auf eigenen Repos (`push --force`, `reset --hard`,
  `branch -D`, `rebase`, `clean -fd`).
- Live-Deploys eigener Projekte (praxis-webseite prod, Juvantis live,
  GitHub-Pages, Docker).
- WP-Admin-Schreibops auf eigenen Production-Domains.
- Figma-Edits in eigenen Files, Google-Drive-Ops auf eigenen Files.
- Telegram-Senden an User-Channel.
- Sub-Agent-Delegation, WebFetch, WebSearch.

Vollständige aktuelle Definition: `agent/modes/tier3.md`.
Verhalten + Risiko-Level (R0-R3) + State-First + Lease siehe
`_rules/AUTONOMY_CONTRACT.md` (autoritativ).
Anti-Drift-Selbstcheck siehe `agent/modes/autonomy.md`.

## Wiederholungsfehler-Patterns (Bug-Wissen)

Konkrete Bug-Patterns, die nicht in R0-R3 abbildbar sind und als
Wissens-Anker bleiben.

### GF-001 — OCR liefert leeres Ergebnis bei gedrehten/skewed PDFs

- **Regel:** Vor OCR Skew-Korrektur via OpenCV laufen lassen.
- **Why:** Tesseract-Confidence sinkt unter 30% bei >5° Schief — generiert
  leeren Text.
- **Apply:** `_lib/ocr/skew_correct.py` vor `_lib/ocr/extract.py` einfügen.

### GF-002 — WordPress-CLI `db query` bricht ab (Socket-Bug)

- **Regel:** `wp eval '$wpdb->query(...)'` verwenden statt `wp db query`.
- **Why:** LocalWP exposed mysql via Socket; `wp db query` ruft mysql-Subprocess auf.
- **Apply:** Pattern: `tools/_lib/wp_db_eval.sh` als Wrapper.

### GF-003 — Backup-Verlust durch `_backups/`-Sweep

- **Regel:** Bei Cleanup-Direktiven Alter-Heuristik auf Backup-Files anwenden.
- **Why:** Welle-I-Lehre 2026-05-05: pauschaler `_backups/`-rm löschte H-Backups.
- **Apply:** Skip-Liste: `_backups/*` mit mtime <7 Tage wird nicht angetastet.

### GF-004 — Git-Pull-Konflikt durch fehlenden Pre-Pull

- **Regel:** Vor jedem Edit in Nexus: `cd ~/Cortex/Nexus && git pull --ff-only`.
- **Why:** Andere Geräte (SSMD, Mac-Studio) committen parallel — divergiert sonst.
- **Apply:** Lean v3 S1 State-First. Pre-Pull Pflicht. Bei Divergenz STOPP.

### GF-005 — Mock-Tests grün, Prod-Migration rot

- **Regel:** Integrations-Tests gegen reale DB, nicht gegen Mocks.
- **Why:** Mock/Prod-Divergenz maskiert Schema-Bugs in Migrations.
- **Apply:** Bei DB-Tests: Docker-Postgres oder LocalWP-Sqlite, kein Mock.

### GF-006 — MCP-SDK Breaking-Change durch `^`-Range

- **Regel:** Im MCP-Bridge-`package.json`: SDK exakt pinnen (kein `^`).
- **Why:** TB-012: 1.17.0 → 1.18.0 brach Tool-Registrierung.
- **Apply:** `package.json`: `"@modelcontextprotocol/sdk": "1.17.0"` (exakt).

### GF-007 — Übersetzungs-Audit oberflächlich

- **Regel:** Body-Content gegen DE-Referenz prüfen, nicht nur Banner.
- **Why:** 2026-05-03: „Alle Pages übersetzt" war wahr für Banner, falsch für Body.
- **Apply:** Audit: `<p>`-Count + `diff(lang=de, lang=$X)` >0 → unvollständig.

## LL→R-Mapping (historische Querreferenz)

Für Sessions, die noch auf alte LL-Codes referenzieren:

| Alt | Neu |
|---|---|
| LL-021 Fertig = funktionstüchtig | R1-Verifikation (acceptance_criteria) |
| LL-023 Session-Init | CLAUDE.md §1 (2 Pflicht-Files) |
| LL-024 WAS/WARUM/BEDEUTUNG | Erklär-Tripel (semantisch erhalten) |
| LL-049 Pre-Pull vor Edit | AUTONOMY_CONTRACT §6 / Lean v3 S1 |
| LL-050 Destruktiv mit Freigabe | R3-Stop (AUTONOMY_CONTRACT §2) |
| LL-053 Memory-Hardgate | Lean v3 §M2 (TTL) + §M3 (HOT/COLD) |
| LL-055 Tier-1/2/3-System | R0/R1/R2/R3 (AUTONOMY_CONTRACT §2) |
| LL-058 Cross-Page-Konsistenz | bleibt domänenspezifisch (Praxis) |
| LL-060 Autonomy Mode v1 | `agent/modes/autonomy.md` |
| LL-061 Init-Slim | Lean v3 §M1 (Pflicht-Lesung halbiert) |
| LL-062 Mode-System | `autonomy.md` / `safe.md` / `tier3.md` |
| LL-066 Anti-Drift-Selbstcheck | `autonomy.md` „Anti-Drift" Block |
