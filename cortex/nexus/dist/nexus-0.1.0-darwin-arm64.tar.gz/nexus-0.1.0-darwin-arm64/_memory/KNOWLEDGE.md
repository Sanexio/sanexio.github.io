# Knowledge-Index — Wissens-Anker zum Vault

> Diese Datei ist ein Pointer-Index, kein Wissens-Container. Tiefe Inhalte
> liegen im Obsidian-Vault unter `Second Brain/30 Tutorials/` und werden
> via Skill `vault-audit` (Welle 3) konsistent gehalten.

## Tutorial-Domains (Symlinks unter `_tutorials/`)

| Symlink                  | Vault-Pfad                                        |
|--------------------------|---------------------------------------------------|
| arbeitsweise-prozess     | `Second Brain/30 Tutorials/Arbeitsweise & Prozess/` |
| blender                  | `Second Brain/30 Tutorials/Design/Blender & 3D/`  |
| cortex-nexus             | `Second Brain/30 Tutorials/Cortex & Nexus/`       |
| design                   | `Second Brain/30 Tutorials/Design/`               |
| gaming                   | `Second Brain/30 Tutorials/Gaming/`               |
| ios-programmierung       | `Second Brain/30 Tutorials/iOS & Swift/`          |
| ki-claude                | `Second Brain/30 Tutorials/KI & Claude/`          |
| netzwerk-sysadmin        | `Second Brain/30 Tutorials/Netzwerk & Sysadmin/`  |
| python                   | `Second Brain/30 Tutorials/Python/`               |
| shopify                  | `Second Brain/30 Tutorials/Webentwicklung/Shopify & Liquid/` |
| sicherheit-datenschutz   | `Second Brain/30 Tutorials/Sicherheit & Datenschutz/` |
| terminal-befehle         | `Second Brain/30 Tutorials/Terminal/`             |
| webdesign                | `Second Brain/30 Tutorials/Webentwicklung/Webdesign/` |
| webentwicklung           | `Second Brain/30 Tutorials/Webentwicklung/`       |
| wordpress                | `Second Brain/30 Tutorials/WordPress/`            |

## Pattern-Suche

Patterns liegen als FTS5-indexierte Records in `_memory/memory.db`. Suche:

```bash
cortex-agent memory search "pattern keyword"
```

## Goldene-Regeln-Quelle

- Canonical: `_memory/golden-rules.md` (Markdown, vom Hook + Connexio gelesen).
- Renderer: `agent/memory/golden_rules.py::system_prompt()` (rendert ein
  kompakteres Subset für den System-Block).

## Relevante Sprint-Archive

- `pre-phoenix-reset-2026-05-08`-Branch auf GitHub — vollständiger
  Pre-Phoenix-Stand, via `git checkout` zugänglich.
- `_archive/phoenix-pre-reset/` — lokale Snapshots (gitignored, daher
  Mac-spezifisch unterschiedlich gefüllt).
